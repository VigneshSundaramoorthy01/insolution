package com.isg.mw.mf.dao.utils.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;
import com.isg.mw.mf.dao.utils.MessageFormatUtility;

public class MessageFormatUtilityTest {

	@Test
	public void getEditCopyListPT01() {
		List<MessageFormatConfigMasterEntity> formatEntity = getMessageMasterFormatEntity();
		MessageFormatConfigMasterEntity masterEntity = formatEntity.get(0);
		List<MessageFormatConfigEditCopyEntity> list = MessageFormatUtility
				.getEditCopyList(getMessageMasterFormatEntity(), 123L);
		MessageFormatConfigEditCopyEntity entity = list.get(0);
		assertEquals(entity.getOwnerId(), masterEntity.getOwnerId());
		assertEquals(entity.getOwnerType(), masterEntity.getOwnerType());
		assertEquals(entity.getMsgType(), masterEntity.getMsgType());
		assertEquals(entity.getMsgFormat(), masterEntity.getMsgFormat());
		assertEquals(entity.getDescription(), masterEntity.getDescription());
		//assertEquals(entity.getCreatedBy(), masterEntity.getCreatedBy());
		assertEquals(entity.getBusinessRule(), masterEntity.getBusinessRule());

	}

	@Test
	public void getMasterListPT01() {
		List<MessageFormatConfigEditCopyEntity> formatEntity = getMessageEditCopyFormatEntity();
		MessageFormatConfigEditCopyEntity editEntity = formatEntity.get(0);
		List<MessageFormatConfigMasterEntity> list = MessageFormatUtility
				.getMasterList(getMessageEditCopyFormatEntity(), 123L);
		MessageFormatConfigMasterEntity entity = list.get(0);
		assertEquals(entity.getOwnerId(), editEntity.getOwnerId());
		assertEquals(entity.getOwnerType(), editEntity.getOwnerType());
		assertEquals(entity.getMsgType(), editEntity.getMsgType());
		assertEquals(entity.getMsgFormat(), editEntity.getMsgFormat());
		assertEquals(entity.getDescription(), editEntity.getDescription());
		//assertEquals(entity.getCreatedBy(), editEntity.getCreatedBy());
		assertEquals(entity.getBusinessRule(), editEntity.getBusinessRule());

	}

	private static List<MessageFormatConfigMasterEntity> getMessageMasterFormatEntity() {
		List<MessageFormatConfigMasterEntity> entities = new ArrayList<MessageFormatConfigMasterEntity>();
		MessageFormatConfigMasterEntity entity = new MessageFormatConfigMasterEntity();
		entity.setOwnerId(123L);
		entity.setOwnerType(OwnerType.SOURCE);
		entity.setMsgType("0200");
		entity.setMsgFormat("0200");
		entity.setDescription("This is utijlity class");
		entity.setCreatedBy("john");
		entity.setBusinessRule(IsgJsonUtils.getJsonString(getBusinessRule()));
		entities.add(entity);
		return entities;
	}

	private static BusinessRule getBusinessRule() {
		BusinessRule businessRule = new BusinessRule();
		businessRule.setClassName("Utility");
		businessRule.setMethodName("getUtility");
		return null;
	}

	private static List<MessageFormatConfigEditCopyEntity> getMessageEditCopyFormatEntity() {
		List<MessageFormatConfigEditCopyEntity> entities = new ArrayList<MessageFormatConfigEditCopyEntity>();
		MessageFormatConfigEditCopyEntity entity = new MessageFormatConfigEditCopyEntity();
		entity.setOwnerId(123L);
		entity.setOwnerType(OwnerType.SOURCE);
		entity.setMsgType("0200");
		entity.setMsgFormat("0200");
		entity.setDescription("This is utijlity class");
		entity.setCreatedBy("john");
		entity.setBusinessRule(IsgJsonUtils.getJsonString(getBusinessRule()));
		entities.add(entity);
		return entities;
	}

}
