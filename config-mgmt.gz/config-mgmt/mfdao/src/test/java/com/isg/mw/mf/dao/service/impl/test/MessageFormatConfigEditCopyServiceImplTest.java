package com.isg.mw.mf.dao.service.impl.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.repository.MessageFormatConfigEditCopyRepository;
import com.isg.mw.mf.dao.service.impl.MessageFormatConfigEditCopyServiceImpl;

public class MessageFormatConfigEditCopyServiceImplTest {

	@Mock
	private MessageFormatConfigEditCopyRepository mssageFormatConfigEditCopyRepository;

	@InjectMocks
	MessageFormatConfigEditCopyServiceImpl MessageFormatConfigEditCopyService;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getByOwnerAndOwnerType() {
		Mockito.when(mssageFormatConfigEditCopyRepository.getByOwner(Mockito.any(), Mockito.any()))
				.thenReturn(getMFCEditCopyEntity(123L, OwnerType.SOURCE));
		List<MessageFormatConfigModel> list = MessageFormatConfigEditCopyService.getByOwnerAndOwnerType(123L,
				OwnerType.SOURCE);
		assertNotNull(list);

	}

	@Test
	public void getByOwnerAndOwnerTypeWithMsgTypePT01() {
		Mockito.when(
				mssageFormatConfigEditCopyRepository.getByOwnerAndMsgType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(getMFCEditCopyEntity(123L, OwnerType.SOURCE));
		List<MessageFormatConfigModel> list = MessageFormatConfigEditCopyService.getByOwnerAndOwnerTypeWithMsgType(123L,
				OwnerType.SOURCE, "0200");
		assertNotNull(list);

	}

	@Test
	public void getByOwnerAndOwnerTypeWithMsgTypeNT01() {
		Mockito.when(
				mssageFormatConfigEditCopyRepository.getByOwnerAndMsgType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(new ArrayList<MessageFormatConfigEditCopyEntity>());
		List<MessageFormatConfigModel> list = MessageFormatConfigEditCopyService.getByOwnerAndOwnerTypeWithMsgType(123L,
				OwnerType.SOURCE, "0200");
		assertEquals(true, list.isEmpty());

	}

	@Test
	public void addPT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.save(Mockito.any()))
				.thenReturn(getMFCEditCopyEntity(123L, OwnerType.SOURCE).get(0));
		MessageFormatConfigModel add = MessageFormatConfigEditCopyService.add(getMFCModel(123L, OwnerType.SOURCE));
		assertNotNull(add);
	}

	@Test
	public void updatePT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.findById(Mockito.any()))
				.thenReturn(Optional.of(getMFCEditCopyEntity(123L, OwnerType.SOURCE).get(0)));
		Mockito.when(mssageFormatConfigEditCopyRepository.save(Mockito.any()))
				.thenReturn(getMFCEditCopyEntity(123L, OwnerType.SOURCE).get(0));
		MessageFormatConfigModel add = MessageFormatConfigEditCopyService.update(getMFCModel(123L, OwnerType.SOURCE));
		assertNotNull(add);
	}

	@Test
	public void getByIdPT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.findById(Mockito.any()))
				.thenReturn(Optional.of(getMFCEditCopyEntity(123L, OwnerType.SOURCE).get(0)));
		MessageFormatConfigEditCopyEntity entity = MessageFormatConfigEditCopyService.getById(124L);
		assertEquals(124L, entity.getId());
		assertNotNull(entity);

	}

	@Test
	public void getByIdNT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.findById(Mockito.any()))
				.thenReturn(Optional.ofNullable(null));
		MessageFormatConfigEditCopyEntity entity = MessageFormatConfigEditCopyService.getById(124L);
		assertNull(entity);

	}

	@Test
	public void getOwnerTypePT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.findById(Mockito.any()))
				.thenReturn(Optional.ofNullable(getMFCEditCopyEntity(123L, OwnerType.SOURCE).get(0)));
		OwnerType ownerType = MessageFormatConfigEditCopyService.getOwnerType(124L);
		assertEquals(OwnerType.SOURCE, ownerType);
	}

	@Test
	public void getOwnerTypeNT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.findById(Mockito.any()))
				.thenReturn(Optional.ofNullable(null));
		OwnerType ownerType = MessageFormatConfigEditCopyService.getOwnerType(124L);
		assertNull(ownerType);
	}

	@Test
	public void deleteByIdPT01() {
		MessageFormatConfigEditCopyService.deleteById(123L);
	}

	@Test
	public void deleteByOwnerPT01() {
		MessageFormatConfigEditCopyService.deleteByOwner(123L, OwnerType.SOURCE);
	}

	@Test
	public void isExistsPT01() {
		Mockito.when(mssageFormatConfigEditCopyRepository.isExists(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(true);
		boolean exists = MessageFormatConfigEditCopyService.isExists(123L, OwnerType.SOURCE, "0200");
		assertEquals(true, exists);
	}

	@Test
	public void isExistsPT02() {
		Mockito.when(mssageFormatConfigEditCopyRepository.isExists(Mockito.any(), Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(true);
		boolean exists = MessageFormatConfigEditCopyService.isExists(123L, 123L, OwnerType.SOURCE, "0200");
		assertEquals(true, exists);

	}

	private MessageFormatConfigModel getMFCModel(Long ownerId, OwnerType type) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(124L);
		model.setOwnerId(ownerId);
		model.setOwnerType(type);
		model.setCreatedBy("john");
		model.setMsgType("0200");
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");

		return model;
	}

	List<MessageFormatConfigEditCopyEntity> getMFCEditCopyEntity(Long editOwnerId, OwnerType type) {
		List<MessageFormatConfigEditCopyEntity> entities = new ArrayList<MessageFormatConfigEditCopyEntity>();
		MessageFormatConfigEditCopyEntity entity = new MessageFormatConfigEditCopyEntity();
		entity.setId(124L);
		entity.setOwnerId(editOwnerId);
		entity.setOwnerType(type);
		entity.setCreatedBy("john");
		entity.setMsgType("0200");
		entity.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		entities.add(entity);
		return entities;
	}

}
