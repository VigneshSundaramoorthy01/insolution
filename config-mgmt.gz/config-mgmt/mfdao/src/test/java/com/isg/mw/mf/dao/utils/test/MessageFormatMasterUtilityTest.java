package com.isg.mw.mf.dao.utils.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;
import com.isg.mw.mf.dao.utils.MessageFormatMasterUtility;

public class MessageFormatMasterUtilityTest {

	@Test
	public void getMessageFormatModelPT01() {
		MessageFormatConfigMasterEntity entity = getMessageFormatEntity();
		MessageFormatConfigModel model = MessageFormatMasterUtility.getMessageFormatModel(getMessageFormatEntity());
		assertEquals(model.getOwnerId(), entity.getOwnerId());
		assertEquals(model.getOwnerType(), entity.getOwnerType());
		assertEquals(model.getMsgType(), entity.getMsgType());
		assertEquals(model.getMsgFormat(), entity.getMsgFormat());
		assertEquals(model.getDescription(), entity.getDescription());
		assertEquals(model.getCreatedBy(), entity.getCreatedBy());
		assertEquals(model.getBusinessRule(),
				IsgJsonUtils.getObjectFromJsonString(entity.getBusinessRule(), BusinessRule.class));

	}

	@Test
	public void getMessageFormatEntityPT01() {
		MessageFormatConfigModel model = getMessageFormatModel();
		MessageFormatConfigMasterEntity entity = MessageFormatMasterUtility
				.getMessageFormatEntity(getMessageFormatModel());
		assertEquals(entity.getOwnerId(), model.getOwnerId());
		assertEquals(entity.getOwnerType(), model.getOwnerType());
		assertEquals(entity.getMsgType(), model.getMsgType());
		assertEquals(entity.getMsgFormat(), model.getMsgFormat());
		assertEquals(entity.getDescription(), model.getDescription());
		//assertEquals(entity.getCreatedBy(), model.getCreatedBy());
		assertEquals(entity.getBusinessRule(), IsgJsonUtils.getJsonString(model.getBusinessRule()));

	}

	@Test
	public void updateMessageFormatEntity() {

		MessageFormatConfigMasterEntity entity=getMessageFormatEntity();
		MessageFormatConfigModel model =getMessageFormatModel();
		MessageFormatMasterUtility.updateMessageFormatEntity(model, entity);
		assertEquals(entity.getOwnerId(), model.getOwnerId());
		assertEquals(entity.getOwnerType(), model.getOwnerType());
		assertEquals(entity.getMsgType(), model.getMsgType());
		assertEquals(entity.getMsgFormat(), model.getMsgFormat());
		assertEquals(entity.getDescription(), model.getDescription());
		//assertEquals(entity.getUpdatedBy(), model.getUpdatedBy());
		assertEquals(entity.getBusinessRule(), IsgJsonUtils.getJsonString(model.getBusinessRule()));

	}

	private static MessageFormatConfigMasterEntity getMessageFormatEntity() {
		MessageFormatConfigMasterEntity entity = new MessageFormatConfigMasterEntity();
		entity.setOwnerId(123L);
		entity.setOwnerType(OwnerType.SOURCE);
		entity.setMsgType("0200");
		entity.setMsgFormat("0200");
		entity.setDescription("This is utijlity class");
		entity.setCreatedBy("john");
		entity.setBusinessRule(IsgJsonUtils.getJsonString(getBusinessRule()));
		return entity;
	}

	private static BusinessRule getBusinessRule() {
		BusinessRule businessRule = new BusinessRule();
		businessRule.setClassName("Utility");
		businessRule.setMethodName("getUtility");
		return null;
	}

	public static MessageFormatConfigModel getMessageFormatModel() {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setOwnerId(123L);
		model.setOwnerType(OwnerType.SOURCE);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		model.setCreatedBy("john");
		model.setUpdatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}


}
