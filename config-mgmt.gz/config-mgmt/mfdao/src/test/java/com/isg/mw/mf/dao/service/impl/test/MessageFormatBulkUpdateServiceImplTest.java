package com.isg.mw.mf.dao.service.impl.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;
import com.isg.mw.mf.dao.repository.MessageFormatConfigEditCopyRepository;
import com.isg.mw.mf.dao.repository.MessageFormatConfigMasterRepository;
import com.isg.mw.mf.dao.service.impl.MessageFormatBulkUpdateServiceImpl;

public class MessageFormatBulkUpdateServiceImplTest {

	@Mock
	private MessageFormatConfigEditCopyRepository messageFormatConfigEditCopyRepository;

	@Mock
	private MessageFormatConfigMasterRepository messageFormatConfigMasterRepository;

	@InjectMocks
	private MessageFormatBulkUpdateServiceImpl messageFormatBulkUpdateService;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void moveEditCopyToMaster() {
		Mockito.when(messageFormatConfigEditCopyRepository.getByOwner(Mockito.any(), Mockito.any())).thenReturn(getMFCEditCopyEntity(123L,OwnerType.SOURCE));
		messageFormatBulkUpdateService.moveEditCopyToMaster(123L,123L , OwnerType.SOURCE);
	}
	
	@Test
	public void copyMasterToEditCopy() {
		Mockito.when(messageFormatConfigMasterRepository.getByOwner(Mockito.any(), Mockito.any())).thenReturn(getMFCMasterEntity(123L,OwnerType.SOURCE));
		messageFormatBulkUpdateService.copyMasterToEditCopy(123L,123L , OwnerType.SOURCE);
		
	}
	
	List<MessageFormatConfigEditCopyEntity> getMFCEditCopyEntity(Long editOwnerId, OwnerType type ){
		List<MessageFormatConfigEditCopyEntity> entities=new ArrayList<MessageFormatConfigEditCopyEntity>();
		MessageFormatConfigEditCopyEntity entity= new MessageFormatConfigEditCopyEntity();
		entity.setOwnerId(editOwnerId);
		entity.setOwnerType(type);
		entity.setCreatedBy("john");
		entity.setMsgType("0200");
		entity.setMsgFormat("01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		entities.add(entity);
		return entities;
	}

	List<MessageFormatConfigMasterEntity> getMFCMasterEntity(Long editOwnerId, OwnerType type ){
		List<MessageFormatConfigMasterEntity> entities=new ArrayList<MessageFormatConfigMasterEntity>();
		MessageFormatConfigMasterEntity entity= new MessageFormatConfigMasterEntity();
		entity.setOwnerId(editOwnerId);
		entity.setOwnerType(type);
		entity.setCreatedBy("john");
		entity.setMsgType("0200");
		entity.setMsgFormat("01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		entities.add(entity);
		return entities;
	}

}
