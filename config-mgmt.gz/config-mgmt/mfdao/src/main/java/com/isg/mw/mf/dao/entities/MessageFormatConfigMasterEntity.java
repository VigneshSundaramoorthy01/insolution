package com.isg.mw.mf.dao.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;
import com.isg.mw.core.model.constants.OwnerType;

import lombok.Getter;
import lombok.Setter;

/**
 * Message format configuration master entity
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
@Entity
@Table(name = "MESSAGE_FORMAT_CONFIG_MASTER")
public class MessageFormatConfigMasterEntity extends AuditInfoEntity {

	/**
	 * Primary id of the config
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	/**
	 * Configuration owner Id it will be configuration id of source / target
	 */
	@Column(name = "OWNER_ID")
	private Long ownerId;

	/**
	 * Configuration Owner Type
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "OWNER_TYPE", length = 12)
	private OwnerType ownerType;

	/**
	 * Message type
	 */
	@Column(name = "MSG_TYPE", length = 4)
	private String msgType;

	/**
	 * message format content of the file
	 */
	@Column(name = "MSG_FORMAT", length = 20000)
	private String msgFormat;

	/**
	 * description about message format
	 */
	@Column(name = "DESCRIPTION", length = 100)
	private String description;

	/**
	 * Business rule
	 */
	@Column(name = "BUSINESS_RULE", length = 320)
	private String businessRule;

}
