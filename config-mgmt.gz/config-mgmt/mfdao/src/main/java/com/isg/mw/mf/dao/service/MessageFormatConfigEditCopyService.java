package com.isg.mw.mf.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;

/**
 * Handles the message format rest API's for message format configuration edit
 * copy service
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatConfigEditCopyService {

	/**
	 * Retrieve the list of matching configurations with owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @return list of matching message format objects
	 */
	List<MessageFormatConfigModel> getByOwnerAndOwnerType(Long ownerId, OwnerType ownerType);

	/**
	 * Retrieve the list of matching configurations with owner id, owner type and
	 * message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return list of matching message format objects
	 */
	List<MessageFormatConfigModel> getByOwnerAndOwnerTypeWithMsgType(Long ownerId, OwnerType ownerType, String msgType);

	/**
	 * Add new message format model in db
	 * 
	 * @param model - message format configuration model
	 * @return added message format configuration model
	 */
	MessageFormatConfigModel add(MessageFormatConfigModel model);

	/**
	 * Update message format model in db
	 * 
	 * @param model - message format configuration model
	 * @return modified message format configuration model
	 */
	MessageFormatConfigModel update(MessageFormatConfigModel save);

	/**
	 * get the message format configuration model based on the id
	 * 
	 * @param id of the message format configuration model
	 * @return message format configuration model
	 */
	MessageFormatConfigEditCopyEntity getById(Long id);

	/**
	 * Delete message format from db with id
	 * 
	 * @param id - primary id
	 */
	void deleteById(Long id);

	/**
	 * Delete message format from db with owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 */
	void deleteByOwner(Long ownerId, OwnerType ownerType);

	/**
	 * Finds message format is exists or not with given owner id, owner type and
	 * message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if message format is exists and false if not exists
	 */
	boolean isExists(Long ownerId, OwnerType ownerType, String msgType);

	/**
	 * Finds message format is exists or not with given id, owner id, owner type and
	 * message type
	 * 
	 * @param id        - primary id
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if message format is exists and false if not exists
	 */
	boolean isExists(Long id, Long ownerId, OwnerType ownerType, String msgType);

	/**
	 * Get owner type with id
	 * 
	 * @param id - primary id
	 * @return type of owner
	 */
	OwnerType getOwnerType(Long id);

}
