package com.isg.mw.mf.dao.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.repository.MessageFormatConfigEditCopyRepository;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.mf.dao.utils.MessageFormatEditCopyUtility;

/**
 * Methods implementation for MessageFormatConfigEditCopyService
 * @author prasad_t026
 *
 */
@Service("messageFormatConfigEditCopyService")
public class MessageFormatConfigEditCopyServiceImpl implements MessageFormatConfigEditCopyService {

	@Autowired
	private MessageFormatConfigEditCopyRepository mssageFormatConfigEditCopyRepository;

	@Override
	public List<MessageFormatConfigModel> getByOwnerAndOwnerType(Long ownerId, OwnerType ownerType) {
		List<MessageFormatConfigEditCopyEntity> entities = mssageFormatConfigEditCopyRepository.getByOwner(ownerId, ownerType);
		List<MessageFormatConfigModel> models = new ArrayList<MessageFormatConfigModel>(entities.size());
		if(entities != null) {
			for(MessageFormatConfigEditCopyEntity entity: entities) {
				models.add( MessageFormatEditCopyUtility.getMessageFormatModel(entity) );
			}
		}
		return models;
	}

	@Override
	public List<MessageFormatConfigModel> getByOwnerAndOwnerTypeWithMsgType(Long ownerId, OwnerType ownerType,
			String msgType) {
		List<MessageFormatConfigEditCopyEntity> entities = mssageFormatConfigEditCopyRepository
				.getByOwnerAndMsgType(ownerId, ownerType, msgType);
		List<MessageFormatConfigModel> models = new ArrayList<MessageFormatConfigModel>(entities.size());
		if(entities != null) {
			for(MessageFormatConfigEditCopyEntity entity: entities) {
				models.add( MessageFormatEditCopyUtility.getMessageFormatModel(entity) );
			}
		}
		return models;
	}

	@Override
	public MessageFormatConfigModel add(MessageFormatConfigModel model) {
		MessageFormatConfigEditCopyEntity savedEntity = mssageFormatConfigEditCopyRepository
				.save(MessageFormatEditCopyUtility.getMessageFormatEntity(model));
		return MessageFormatEditCopyUtility.getMessageFormatModel(savedEntity);
	}

	@Override
	public MessageFormatConfigModel update(MessageFormatConfigModel model) {
		MessageFormatConfigEditCopyEntity entity = mssageFormatConfigEditCopyRepository.findById(model.getId()).get();
		MessageFormatEditCopyUtility.updateMessageFormatEntity(model, entity);
		MessageFormatConfigEditCopyEntity mfEntity = mssageFormatConfigEditCopyRepository.save(entity);
		return MessageFormatEditCopyUtility.getMessageFormatModel(mfEntity);
	}

	@Override
	public MessageFormatConfigEditCopyEntity getById(Long id) {
		Optional<MessageFormatConfigEditCopyEntity> op = mssageFormatConfigEditCopyRepository.findById(id);
		if(op.isPresent()) {
			return mssageFormatConfigEditCopyRepository.findById(id).get();
		}
		return null;
	}

	@Override
	public OwnerType getOwnerType(Long id) {
		MessageFormatConfigEditCopyEntity entity = getById(id);
		if(entity != null) {
			return entity.getOwnerType();
		}
		return null;
	}

	@Override
	public void deleteById(Long id) {
		mssageFormatConfigEditCopyRepository.deleteById(id);
	}

	@Override
	public void deleteByOwner(Long ownerId, OwnerType ownerType) {
		mssageFormatConfigEditCopyRepository.deleteByOwner(ownerId, ownerType);
	}

	@Override
	public boolean isExists(Long ownerId, OwnerType ownerType, String msgType) {
		return mssageFormatConfigEditCopyRepository.isExists(ownerId, ownerType, msgType);
	}

	@Override
	public boolean isExists(Long id, Long ownerId, OwnerType ownerType, String msgType) {
		return mssageFormatConfigEditCopyRepository.isExists(id, ownerId, ownerType, msgType);
	}

}
