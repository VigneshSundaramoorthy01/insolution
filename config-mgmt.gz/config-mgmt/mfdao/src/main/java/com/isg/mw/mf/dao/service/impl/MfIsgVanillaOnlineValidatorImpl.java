package com.isg.mw.mf.dao.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.constants.MFDaoMsgKeys;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.mf.dao.service.MfIsgVanillaOnlineValidator;

/**
 * Method implementation for class MfIsgVanillaOnlineValidator
 * @author prasad_t026
 *
 */
@Service("mfIsgVanillaOnlineValidator")
public class MfIsgVanillaOnlineValidatorImpl implements MfIsgVanillaOnlineValidator {

	@Autowired
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@Override
	public void addValidation(MessageFormatConfigModel addModel) {
		if (messageFormatConfigMasterService.isExists(addModel.getOwnerType(), addModel.getMsgType(),
				addModel.getMsgFormat())) {
			throw new ValidationException(MFDaoMsgKeys.MSGI_FORMAT_ALREADY_EXISTS);
		}
	}

	@Override
	public void modifyValidation(MessageFormatConfigModel updateModel) {
		if(messageFormatConfigMasterService.isUpdateExists(updateModel.getId(),updateModel.getOwnerType(),
				updateModel.getMsgType(), updateModel.getMsgFormat())) {
			throw new ValidationException(MFDaoMsgKeys.MSG_FORMAT_ALREADY_EXISTS, updateModel.getId());
		} 
	}

	@Override
	public void deleteValidation(Long id) {
		if (!messageFormatConfigMasterService.isExists(id)) {
			throw new ValidationException(MFDaoMsgKeys.OWNER_IS_NOT_EXISTS, id);
		}
	}
	
	@Override
	public OwnerType getOwnerType(Long id) {
		return messageFormatConfigMasterService.getOwnerType(id);
	}
	
}