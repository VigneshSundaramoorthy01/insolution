package com.isg.mw.mf.dao.service;

import com.isg.mw.core.model.constants.OwnerType;

/**
 * Copy data from message format configuration master to message format edit
 * copy and vice versa
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatBulkUpdateService {

	/**
	 * Copy edit copy to master with given edit and master id and owner type
	 * 
	 * @param editOwnerId   - edit copy owner id
	 * @param masterOwnerId - master owner id
	 * @param type          - owner type
	 */
	void moveEditCopyToMaster(Long editOwnerId, Long masterOwnerId, OwnerType type);

	/**
	 * Copy master to edit copy with given edit and master id and owner type
	 * 
	 * @param editOwnerId   - edit copy owner id
	 * @param masterOwnerId - master owner id
	 * @param type          - owner type
	 */
	void copyMasterToEditCopy(Long editOwnerId, Long masterOwnerId, OwnerType type);

}
