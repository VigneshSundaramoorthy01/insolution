package com.isg.mw.mf.dao.service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;

/**
 * Validates data (data which is coming from database) with hitting database for message format
 * 
 * @author prasad_t026
 */
public interface MfPrivateOnlineValidator {

	/**
	 * Validates data while adding new message format in db
	 * 
	 * @param model - message format configuration model
	 */
	void addValidation(MessageFormatConfigModel model);

	/**
	 * Validates data while modifying existing message format in db
	 * 
	 * @param model - message format configuration model
	 */
	void modifyValidation(MessageFormatConfigModel model);

	/**
	 * To get owner type
	 * 
	 * @param id - primary id
	 * @return owner type
	 */
	OwnerType getOwnerType(Long id);

}
