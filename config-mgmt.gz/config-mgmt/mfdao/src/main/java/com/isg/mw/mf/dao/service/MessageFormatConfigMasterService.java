package com.isg.mw.mf.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;

/**
 * Handles the message format rest API's for message format configuration master
 * service
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatConfigMasterService {

	/**
	 * Retrieve the list of matching configurations with owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @return list of matching message format objects
	 */
	List<MessageFormatConfigModel> getByOwnerAndOwnerType(Long ownerId, OwnerType ownerType);

	/**
	 * Retrieve the list of matching configurations with owner id, owner type and
	 * message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return list of matching message format objects
	 */
	List<MessageFormatConfigModel> getByOwnerAndOwnerTypeWithMsgType(Long ownerId, OwnerType ownerType, String msgType);

	/**
	 * Add new message format model in db
	 * 
	 * @param model - message format configuration model
	 * @return added message format configuration model
	 */
	MessageFormatConfigModel add(MessageFormatConfigModel model);

	/**
	 * Update message format model in db
	 * 
	 * @param model - message format configuration model
	 * @return modified message format configuration model
	 */
	MessageFormatConfigModel update(MessageFormatConfigModel model);

	/**
	 * Delete message format from db with id
	 * 
	 * @param id - primary id
	 */
	void deleteById(Long id);

	/**
	 * Delete message format from db with owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 */
	void deleteByOwner(Long ownerId, OwnerType ownerType);

	/**
	 * Finds message format is exists or not with given owner id, owner type,
	 * message type and message format
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @param msgFormat - message format
	 * @return true if message format is exists and false if not exists
	 */
	boolean isExists(Long ownerId, OwnerType ownerType, String msgType, String msgFormat);

	/**
	 * Finds message format is exists or not with given id, owner id, owner type,
	 * message type and message format
	 * 
	 * @param id        - primary id
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @param msgFormat - message format
	 * @return true if message format is exists and false if not exists
	 */
	boolean isExists(Long id, Long ownerId, OwnerType ownerType, String msgType, String msgFormat);

	/**
	 * Finds message format is exists or not with given id
	 * 
	 * @param id - primary id
	 * @return true if message format is exists and false if not exists
	 */
	boolean isExists(Long id);

	/**
	 * Get owner type with id
	 * 
	 * @param id - primary id
	 * @return type of owner
	 */
	OwnerType getOwnerType(Long id);

	/**
	 * Get message format entity with given id
	 * 
	 * @param id primary id
	 * @return message format entity
	 */
	MessageFormatConfigMasterEntity getById(Long id);
	/**
	 * Finds message format is exists or not with given  owner type,
	 * message type and message format
	 * 
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @param msgFormat - message format
	 * @return true if message format is exists and false if not exists
	 */
	boolean isExists(OwnerType ownerType, String msgType, String msgFormat);

	/**
	 * Finds message format is exists or not with given owner id, owner type,
	 * message type and message format
	 * 
	 * @param id        - primary id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @param msgFormat - message format
	 * @return true if message format is exists and false if not exists
	 */
	boolean isUpdateExists(Long id, OwnerType ownerType, String msgType, String msgFormat);

}
