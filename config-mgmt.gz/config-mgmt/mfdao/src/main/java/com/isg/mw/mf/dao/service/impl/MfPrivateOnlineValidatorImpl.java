package com.isg.mw.mf.dao.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.constants.MFDaoMsgKeys;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.mf.dao.service.MfPrivateOnlineValidator;

/**
 * Method implementation for class MfPrivateOnlineValidator
 * @author prasad_t026
 *
 */
@Service("mfPrivateOnlineValidator")
public class MfPrivateOnlineValidatorImpl implements MfPrivateOnlineValidator {

	@Autowired
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Override
	public void addValidation(MessageFormatConfigModel model) {
		if (messageFormatConfigEditCopyService.isExists(model.getOwnerId(), model.getOwnerType(), model.getMsgType())) {
			throw new ValidationException(MFDaoMsgKeys.MSG_FORMAT_ALREADY_EXISTS, model.getId());
		}

	}

	@Override
	public void modifyValidation(MessageFormatConfigModel model) {
		if (messageFormatConfigEditCopyService.isExists(model.getId(), model.getOwnerId(), model.getOwnerType(),
				model.getMsgType())) {
			throw new ValidationException(MFDaoMsgKeys.OWNER_IS_NOT_EXISTS, model.getId());
		}
	}

	@Override
	public OwnerType getOwnerType(Long id) {
		return messageFormatConfigEditCopyService.getOwnerType(id);
	}
	
}