package com.isg.mw.mf.dao.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;
import com.isg.mw.mf.dao.repository.MessageFormatConfigMasterRepository;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.mf.dao.utils.MessageFormatMasterUtility;

/**
 * Method implementation for MessageFormatConfigMasterService
 * 
 * @author prasad_t026
 *
 */
@Service("messageFormatConfigMasterService")
public class MessageFormatConfigMasterServiceImpl implements MessageFormatConfigMasterService {

	@Autowired
	private MessageFormatConfigMasterRepository messageFormatConfigMasterRepository;

	@Override
	public List<MessageFormatConfigModel> getByOwnerAndOwnerType(Long ownerId, OwnerType ownerType) {
		List<MessageFormatConfigMasterEntity> entities = messageFormatConfigMasterRepository.getByOwner(ownerId,
				ownerType);
		List<MessageFormatConfigModel> models = new ArrayList<MessageFormatConfigModel>(entities.size());
		if (entities != null) {
			for (MessageFormatConfigMasterEntity entity : entities) {
				models.add(MessageFormatMasterUtility.getMessageFormatModel(entity));
			}
		}
		return models;
	}

	@Override
	public List<MessageFormatConfigModel> getByOwnerAndOwnerTypeWithMsgType(Long ownerId, OwnerType ownerType,
			String msgType) {
		List<MessageFormatConfigMasterEntity> entities = null;
		if (ownerType == OwnerType.ISG_VANILLA) {
			entities = messageFormatConfigMasterRepository.getByMsgType(ownerType, msgType);
		} else {
			entities = messageFormatConfigMasterRepository.getByOwnerAndMsgType(ownerId, ownerType, msgType);
		}

		List<MessageFormatConfigModel> models = new ArrayList<MessageFormatConfigModel>(entities.size());
		if (entities != null) {
			for (MessageFormatConfigMasterEntity entity : entities) {
				models.add(MessageFormatMasterUtility.getMessageFormatModel(entity));
			}
		}
		return models;
	}

	@Override
	public MessageFormatConfigModel add(MessageFormatConfigModel model) {
		MessageFormatConfigMasterEntity savedEntity = messageFormatConfigMasterRepository
				.save(MessageFormatMasterUtility.getMessageFormatEntity(model));
		return MessageFormatMasterUtility.getMessageFormatModel(savedEntity);
	}

	@Override
	public MessageFormatConfigModel update(MessageFormatConfigModel model) {
		MessageFormatConfigMasterEntity entity = messageFormatConfigMasterRepository.findById(model.getId()).get();
		MessageFormatMasterUtility.updateMessageFormatEntity(model, entity);
		MessageFormatConfigMasterEntity mfEntity = messageFormatConfigMasterRepository.save(entity);
		return MessageFormatMasterUtility.getMessageFormatModel(mfEntity);
	}

	@Override
	public void deleteById(Long id) {
		messageFormatConfigMasterRepository.deleteById(id);
	}

	@Override
	public void deleteByOwner(Long ownerId, OwnerType ownerType) {
		messageFormatConfigMasterRepository.deleteByOwner(ownerId, ownerType);
	}

	@Override
	public boolean isExists(Long ownerId, OwnerType ownerType, String msgType, String msgFormat) {
		return messageFormatConfigMasterRepository.isExists(ownerId, ownerType, msgType, msgFormat);
	}

	@Override
	public boolean isExists(Long id, Long ownerId, OwnerType ownerType, String msgType, String msgFormat) {
		return messageFormatConfigMasterRepository.isExists(id, ownerId, ownerType, msgType, msgFormat);
	}

	@Override
	public boolean isExists(Long id) {
		return messageFormatConfigMasterRepository.isExists(id);
	}

	@Override
	public MessageFormatConfigMasterEntity getById(Long id) {
		Optional<MessageFormatConfigMasterEntity> op = messageFormatConfigMasterRepository.findById(id);
		if (op.isPresent()) {
			return messageFormatConfigMasterRepository.findById(id).get();
		}
		return null;
	}

	@Override
	public OwnerType getOwnerType(Long id) {
		MessageFormatConfigMasterEntity entity = getById(id);
		if (entity != null) {
			return entity.getOwnerType();
		}
		return null;
	}

	@Override
	public boolean isExists(OwnerType ownerType, String msgType, String msgFormat) {
		return messageFormatConfigMasterRepository.isExists(ownerType, msgType, msgFormat);
	}

	@Override
	public boolean isUpdateExists(Long id, OwnerType ownerType, String msgType, String msgFormat) {
		return messageFormatConfigMasterRepository.isUpdateExists(id, ownerType, msgType, msgFormat);
	}

}
