package com.isg.mw.mf.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;
import com.isg.mw.mf.dao.repository.MessageFormatConfigEditCopyRepository;
import com.isg.mw.mf.dao.repository.MessageFormatConfigMasterRepository;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.mf.dao.utils.MessageFormatUtility;

/**
 * method implementation for MessageFormatBulkUpdateService 
 * @author prasad_t026
 *
 */
@Service("messageFormatBulkUpdateService")
public class MessageFormatBulkUpdateServiceImpl implements MessageFormatBulkUpdateService {

	@Autowired 
	private MessageFormatConfigEditCopyRepository messageFormatConfigEditCopyRepository;

	@Autowired 
	private MessageFormatConfigMasterRepository messageFormatConfigMasterRepository;

	@Override
	public void moveEditCopyToMaster(Long editOwnerId, Long masterOwnerId, OwnerType type) {

		List<MessageFormatConfigEditCopyEntity> editList = messageFormatConfigEditCopyRepository.getByOwner(editOwnerId, type);
		List<MessageFormatConfigMasterEntity> masterList = MessageFormatUtility.getMasterList(editList, masterOwnerId);
		if(masterOwnerId != null) {
			messageFormatConfigMasterRepository.deleteByOwner(masterOwnerId, type);
		}
		if(masterList != null && !masterList.isEmpty()) {
			messageFormatConfigMasterRepository.saveAll(masterList);
		}
		if(editList != null && !editList.isEmpty()) {
			messageFormatConfigEditCopyRepository.deleteAll(editList);
		}
		
	}

	@Override
	public void copyMasterToEditCopy(Long editOwnerId, Long masterOwnerId, OwnerType type) {

		List<MessageFormatConfigMasterEntity> masterList = messageFormatConfigMasterRepository.getByOwner(masterOwnerId, type);
		List<MessageFormatConfigEditCopyEntity> editList = MessageFormatUtility.getEditCopyList(masterList, editOwnerId);
		if(editOwnerId != null) {
			messageFormatConfigEditCopyRepository.deleteByOwner(editOwnerId, type);
		}
		if(editList != null && !editList.isEmpty()) {
			messageFormatConfigEditCopyRepository.saveAll(editList);
		}
		
	}

}
