package com.isg.mw.mf.dao.service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;

/**
 * Validates data (data which is coming from database) with hitting database for
 * vanilla message format
 * 
 * @author prasad_t026
 *
 */
public interface MfIsgVanillaOnlineValidator {

	/**
	 * Validates data while adding new message format in db
	 * 
	 * @param model - message format configuration model
	 */
	void addValidation(MessageFormatConfigModel addModel);

	/**
	 * Validates data while modifying existing message format in db
	 * 
	 * @param model - message format configuration model
	 */
	void modifyValidation(MessageFormatConfigModel updateModel);

	/**
	 * Validates data while deleting existing message format from db
	 * 
	 * @param id
	 */
	void deleteValidation(Long id);

	/**
	 * To get owner type
	 * 
	 * @param id - primary id
	 * @return owner type
	 */
	OwnerType getOwnerType(Long id);

}
