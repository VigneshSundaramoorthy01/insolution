package com.isg.mw.mf.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;

/**
 * Repository interface to access and manage TargetConfigMasterEntity
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatConfigMasterRepository extends CrudRepository<MessageFormatConfigMasterEntity, Long> {

	/**
	 * Finds the matching configurations with the given owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @return list of configuration objects
	 */
	@Query("SELECT mf FROM MessageFormatConfigMasterEntity mf WHERE mf.ownerId = :ownerId and mf.ownerType = :ownerType")
	List<MessageFormatConfigMasterEntity> getByOwner(@Param("ownerId") Long ownerId,
			@Param("ownerType") OwnerType ownerType);

	/**
	 * Finds the matching configuration with the given owner id, owner type and
	 * message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return list of configuration objects
	 */
	@Query("SELECT mf FROM MessageFormatConfigMasterEntity mf WHERE mf.ownerId = :ownerId and mf.ownerType = :ownerType "
			+ "and mf.msgType = :msgType")
	List<MessageFormatConfigMasterEntity> getByOwnerAndMsgType(@Param("ownerId") Long ownerId,
			@Param("ownerType") OwnerType ownerType, @Param("msgType") String msgType);

	/**
	 * Finds the matching configurations with the given owner type and message type
	 * 
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return list of configuration objects
	 */
	@Query("SELECT mf FROM MessageFormatConfigMasterEntity mf WHERE mf.ownerType = :ownerType "
			+ "and mf.msgType = :msgType")
	List<MessageFormatConfigMasterEntity> getByMsgType(@Param("ownerType") OwnerType ownerType,
			@Param("msgType") String msgType);

	/**
	 * Delete configuration with given owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @return
	 */
	@Modifying
	@Query("DELETE FROM MessageFormatConfigMasterEntity mf WHERE mf.ownerId = :ownerId and mf.ownerType = :ownerType")
	int deleteByOwner(@Param("ownerId") Long ownerId, @Param("ownerType") OwnerType ownerType);

	/**
	 * Finds the matching configuration is exists or not with the given owner id,
	 * owner type and message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigMasterEntity mf WHERE "
			+ "mf.ownerId = :ownerId and mf.ownerType = :ownerType and mf.msgType = :msgType and mf.msgFormat = :msgFormat")
	boolean isExists(@Param("ownerId") Long ownerId, @Param("ownerType") OwnerType ownerType,
			@Param("msgType") String msgType, @Param("msgFormat") String msgFormat);

	/**
	 * Finds the matching configuration is exists or not with the given id, owner
	 * id, owner type and message type
	 * 
	 * @param id        - primary id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigMasterEntity mf WHERE "
			+ "mf.id != :id and mf.ownerId = :ownerId and mf.ownerType = :ownerType and mf.msgType = :msgType "
			+ "and mf.msgFormat = :msgFormat")
	boolean isExists(@Param("id") Long id, @Param("ownerId") Long ownerId, @Param("ownerType") OwnerType ownerType,
			@Param("msgType") String msgType, @Param("msgFormat") String msgFormat);

	/**
	 * Finds the matching configuration is exists or not with given id
	 * 
	 * @param id - primary id of configuration
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigMasterEntity mf WHERE mf.id = :id ")
	boolean isExists(@Param("id") Long id);

	/**
	 * Finds the matching configuration is exists or not with the given 
	 * owner type and message type
	 * 
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @param msgFormat - message format
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigMasterEntity mf WHERE "
			+ "mf.ownerType = :ownerType and mf.msgType = :msgType and mf.msgFormat = :msgFormat")
	boolean isExists(@Param("ownerType")OwnerType ownerType, @Param("msgType")String msgType, @Param("msgFormat")String msgFormat);

	/**
	 * Finds the matching configuration is exists or not with the given id, owner
	 * id, owner type and message type
	 * 
	 * @param id        - primary id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigMasterEntity mf WHERE "
			+ "mf.id != :id and mf.ownerType = :ownerType and mf.msgType = :msgType "
			+ "and mf.msgFormat = :msgFormat")
	boolean isUpdateExists(@Param("id")Long id, @Param("ownerType")OwnerType ownerType, @Param("msgType")String msgType, @Param("msgFormat")String msgFormat);

}
