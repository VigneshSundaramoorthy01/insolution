package com.isg.mw.mf.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;

/**
 * Repository interface to access and manage MessageFormatConfigEditCopyEntity
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatConfigEditCopyRepository extends CrudRepository<MessageFormatConfigEditCopyEntity, Long> {

	/**
	 * Finds the matching configurations with the given owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @return list of configuration objects
	 */
	@Query("SELECT mf FROM MessageFormatConfigEditCopyEntity mf WHERE mf.ownerId = :ownerId and mf.ownerType = :ownerType")
	List<MessageFormatConfigEditCopyEntity> getByOwner(@Param("ownerId") Long ownerId,
			@Param("ownerType") OwnerType ownerType);

	/**
	 * Finds the matching configuration with the given owner id, owner type and
	 * message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return list of configuration objects
	 */
	@Query("SELECT mf FROM MessageFormatConfigEditCopyEntity mf WHERE mf.ownerId = :ownerId and mf.ownerType = :ownerType "
			+ "and mf.msgType = :msgType")
	List<MessageFormatConfigEditCopyEntity> getByOwnerAndMsgType(@Param("ownerId") Long ownerId,
			@Param("ownerType") OwnerType ownerType, @Param("msgType") String msgType);

	/**
	 * Finds the matching configuration is exists or not with the given owner id,
	 * owner type and message type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigEditCopyEntity mf WHERE "
			+ "mf.ownerId = :ownerId and mf.ownerType = :ownerType and mf.msgType = :msgType")
	boolean isExists(@Param("ownerId") Long ownerId, @Param("ownerType") OwnerType ownerType,
			@Param("msgType") String msgType);

	/**
	 * Finds the matching configuration is exists or not with the given id, owner
	 * id, owner type and message type
	 * 
	 * @param id        - primary id
	 * @param ownerType - configuration type
	 * @param msgType   - message type
	 * @return true if exists and false id not exists
	 */
	@Query("SELECT CASE WHEN COUNT(mf) > 0 THEN true ELSE false END FROM MessageFormatConfigEditCopyEntity mf WHERE "
			+ "mf.id != :id and mf.ownerId = :ownerId and mf.ownerType = :ownerType and mf.msgType = :msgType")
	boolean isExists(@Param("id") Long id, @Param("ownerId") Long ownerId, @Param("ownerType") OwnerType ownerType,
			@Param("msgType") String msgType);

	/**
	 * Delete configuration with given owner id and owner type
	 * 
	 * @param ownerId   - configuration id
	 * @param ownerType - configuration type
	 * @return
	 */
	@Modifying
	@Query("DELETE FROM MessageFormatConfigEditCopyEntity mf WHERE mf.ownerId = :ownerId and mf.ownerType = :ownerType")
	int deleteByOwner(@Param("ownerId") Long ownerId, @Param("ownerType") OwnerType ownerType);

}
