package com.isg.mw.mf.dao.utils;

import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;

/**
 * Message format master utility which is used to convert message format
 * configuration master entity to message format configuration model and vice
 * versa and update message format configuration master entity
 * 
 * @author prasad_t026
 *
 */
public class MessageFormatMasterUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private MessageFormatMasterUtility() {

	}

	/**
	 * Converts Message format configuration master entity to Message format
	 * configuration model
	 * 
	 * @param entity - Message format configuration master entity
	 * @return model - Message format configuration model
	 */
	public static MessageFormatConfigModel getMessageFormatModel(MessageFormatConfigMasterEntity entity) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(entity.getId());
		model.setOwnerId(entity.getOwnerId());
		model.setOwnerType(entity.getOwnerType());
		model.setMsgType(entity.getMsgType());
		model.setMsgFormat(entity.getMsgFormat());
		model.setDescription(entity.getDescription());
		model.setCreatedBy(entity.getCreatedBy());
		model.setUpdatedBy(entity.getUpdatedBy());
		model.setCreatedAt(entity.getCreatedAt());
		model.setUpdatedAt(entity.getUpdatedAt());
		model.setBusinessRule(IsgJsonUtils.getObjectFromJsonString(entity.getBusinessRule(), BusinessRule.class));
		return model;
	}

	/**
	 * Converts Message format configuration model to Message format configuration
	 * master entity
	 * 
	 * @param model - Message format configuration model
	 * @return entity - Message format configuration master entity
	 */
	public static MessageFormatConfigMasterEntity getMessageFormatEntity(MessageFormatConfigModel model) {
		MessageFormatConfigMasterEntity entity = new MessageFormatConfigMasterEntity();
		entity.setOwnerId(model.getOwnerId());
		entity.setOwnerType(model.getOwnerType());
		entity.setMsgType(model.getMsgType());
		entity.setMsgFormat(model.getMsgFormat());
		entity.setDescription(model.getDescription());
		//entity.setCreatedBy(model.getCreatedBy());
		//entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setBusinessRule(IsgJsonUtils.getJsonString(model.getBusinessRule()));
		return entity;
	}

	/**
	 * Update Message format configuration master entity
	 * 
	 * @param model  - Message format configuration model
	 * @param entity - Message format configuration master entity
	 */
	public static void updateMessageFormatEntity(MessageFormatConfigModel model,
			MessageFormatConfigMasterEntity entity) {
		entity.setMsgType(model.getMsgType());
		entity.setMsgFormat(model.getMsgFormat());
		entity.setDescription(model.getDescription());
		//entity.setUpdatedBy(model.getUpdatedBy());
		//entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setBusinessRule(IsgJsonUtils.getJsonString(model.getBusinessRule()));
	}

}
