package com.isg.mw.mf.dao.utils;

import java.util.ArrayList;
import java.util.List;

import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.entities.MessageFormatConfigMasterEntity;

/**
 * Message format utility is used to convert Message format configuration edit
 * copy entity to Message format configuration master entity and vice versa
 * 
 * @author prasad_t026
 *
 */
public class MessageFormatUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private MessageFormatUtility() {
	}

	/**
	 * Used to get list of message format configuration edit copy entity from list
	 * of message format configuration master entity with edit copy owner id
	 * 
	 * @param masterList      - list of Message format configuration master entity
	 * @param editCopyOwnerId - edit copy configuration owner id
	 * @return editList -
	 */
	public static List<MessageFormatConfigEditCopyEntity> getEditCopyList(
			List<MessageFormatConfigMasterEntity> masterList, Long editCopyOwnerId) {

		List<MessageFormatConfigEditCopyEntity> editList = null;
		if (masterList != null && !masterList.isEmpty()) {
			editList = new ArrayList<MessageFormatConfigEditCopyEntity>(masterList.size());
			for (MessageFormatConfigMasterEntity master : masterList) {
				editList.add(getEditCopy(master, editCopyOwnerId));
			}
		}
		return editList;

	}

	/**
	 * Used to get list of message format configuration master entity from list of
	 * message format configuration edit copy entity with master owner id
	 * 
	 * @param editCopyList  - list of message format configuration edit copy entity
	 * @param masterOwnerId - master owner id
	 * @return masterList - list of message format configuration master entity
	 */
	public static List<MessageFormatConfigMasterEntity> getMasterList(
			List<MessageFormatConfigEditCopyEntity> editCopyList, Long masterOwnerId) {

		List<MessageFormatConfigMasterEntity> masterList = null;
		if (editCopyList != null && !editCopyList.isEmpty()) {
			masterList = new ArrayList<MessageFormatConfigMasterEntity>(editCopyList.size());
			for (MessageFormatConfigEditCopyEntity editCopy : editCopyList) {
				masterList.add(getMaster(editCopy, masterOwnerId));
			}
		}
		return masterList;

	}

	/**
	 * Converts message format configuration master entity into message format
	 * configuration edit copy entity with configuration id
	 * 
	 * @param master          - message format configuration master entity
	 * @param editCopyOwnerId - configuration id
	 * @return editCopy - message format configuration edit copy entity
	 */
	public static MessageFormatConfigEditCopyEntity getEditCopy(MessageFormatConfigMasterEntity master,
			Long editCopyOwnerId) {

		MessageFormatConfigEditCopyEntity editCopy = new MessageFormatConfigEditCopyEntity();
		//editCopy.setCreatedAt(master.getCreatedAt());
		//editCopy.setCreatedBy(master.getCreatedBy());
		editCopy.setDescription(master.getDescription());
		editCopy.setMsgFormat(master.getMsgFormat());
		editCopy.setMsgType(master.getMsgType());
		editCopy.setOwnerId(editCopyOwnerId);
		editCopy.setOwnerType(master.getOwnerType());
		//editCopy.setUpdatedAt(master.getUpdatedAt());
		//editCopy.setUpdatedBy(master.getUpdatedBy());
		editCopy.setBusinessRule(master.getBusinessRule());
		return editCopy;

	}

	/**
	 * Converts message format configuration edit copy entity into message format
	 * configuration master entity with configuration id
	 * 
	 * @param editCopy        - message format configuration edit copy entity
	 * @param editCopyOwnerId - configuration id
	 * @return master - message format configuration master entity
	 */
	public static MessageFormatConfigMasterEntity getMaster(MessageFormatConfigEditCopyEntity editCopy,
			Long masterOwnerId) {

		MessageFormatConfigMasterEntity master = new MessageFormatConfigMasterEntity();
		//master.setCreatedAt(editCopy.getCreatedAt());
		//master.setCreatedBy(editCopy.getCreatedBy());
		master.setDescription(editCopy.getDescription());
		master.setMsgFormat(editCopy.getMsgFormat());
		master.setMsgType(editCopy.getMsgType());
		master.setOwnerId(masterOwnerId);
		master.setOwnerType(editCopy.getOwnerType());
		//master.setUpdatedAt(editCopy.getUpdatedAt());
		//master.setUpdatedBy(editCopy.getUpdatedBy());
		master.setBusinessRule(editCopy.getBusinessRule());
		return master;

	}

}
