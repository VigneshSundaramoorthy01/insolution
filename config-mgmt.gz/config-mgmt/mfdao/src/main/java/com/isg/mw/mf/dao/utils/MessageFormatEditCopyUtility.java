package com.isg.mw.mf.dao.utils;

import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;

/**
 * Message format edit copy utility which is used to convert message format
 * configuration edit copy entity to message format configuration model and vice
 * versa and update message format configuration edit copy entity
 * 
 * @author prasad_t026
 *
 */
public class MessageFormatEditCopyUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private MessageFormatEditCopyUtility() {

	}

	/**
	 * Converts message format configuration edit copy entity to message format
	 * configuration model
	 * 
	 * @param entity - message format configuration edit copy entity
	 * @return model - message format configuration model
	 */
	public static MessageFormatConfigModel getMessageFormatModel(MessageFormatConfigEditCopyEntity entity) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(entity.getId());
		model.setOwnerId(entity.getOwnerId());
		model.setOwnerType(entity.getOwnerType());
		model.setMsgType(entity.getMsgType());
		model.setMsgFormat(entity.getMsgFormat());
		model.setDescription(entity.getDescription());
		model.setCreatedBy(entity.getCreatedBy());
		model.setUpdatedBy(entity.getUpdatedBy());
		model.setCreatedAt(entity.getCreatedAt());
		model.setUpdatedAt(entity.getUpdatedAt());
		model.setBusinessRule(IsgJsonUtils.getObjectFromJsonString(entity.getBusinessRule(), BusinessRule.class));
		return model;
	}

	/**
	 * Converts message format configuration model to message format configuration
	 * edit copy entity
	 * 
	 * @param model - message format configuration model
	 * @return entity - message format configuration edit copy entity
	 */
	public static MessageFormatConfigEditCopyEntity getMessageFormatEntity(MessageFormatConfigModel model) {
		MessageFormatConfigEditCopyEntity entity = new MessageFormatConfigEditCopyEntity();
		entity.setOwnerId(model.getOwnerId());
		entity.setOwnerType(model.getOwnerType());
		entity.setMsgType(model.getMsgType());
		entity.setMsgFormat(model.getMsgFormat());
		entity.setDescription(model.getDescription());
		//entity.setCreatedBy(model.getCreatedBy());
		//entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setBusinessRule(IsgJsonUtils.getJsonString(model.getBusinessRule()));
		return entity;
	}

	/**
	 * Update message format configuration edit copy entity
	 * 
	 * @param model  - message format configuration model
	 * @param entity - message format configuration edit copy entity
	 */
	public static void updateMessageFormatEntity(MessageFormatConfigModel model,
			MessageFormatConfigEditCopyEntity entity) {
		entity.setMsgType(model.getMsgType());
		entity.setMsgFormat(model.getMsgFormat());
		entity.setDescription(model.getDescription());
		//entity.setUpdatedBy(model.getUpdatedBy());
		//entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setBusinessRule(IsgJsonUtils.getJsonString(model.getBusinessRule()));
	}

}
