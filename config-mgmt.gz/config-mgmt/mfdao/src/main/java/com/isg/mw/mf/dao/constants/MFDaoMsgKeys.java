package com.isg.mw.mf.dao.constants;

/**
 * constants to refer keys from message resource bundle
 * 
 * @author sanchita3984
 *
 */
public interface MFDaoMsgKeys {

	/**
	 * The given combination with parent configuration, msgType, msgFormat already exists.
	 */
	String MSG_FORMAT_ALREADY_EXISTS = "mfp.dao.msg.format.allready.exists";
	
	/**
	 * The given combination with msgType, msgFormat already exists.
	 */
	String MSGI_FORMAT_ALREADY_EXISTS = "mfi.dao.msg.format.allready.exists";
	
	/**
	 * should used when owner is not exists with one argument
	 */
	String OWNER_IS_NOT_EXISTS = "mf.dao.owner.not.exists";

}
