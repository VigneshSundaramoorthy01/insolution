package com.isg.mw.security.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;
import com.isg.mw.security.dao.service.KeyProviderEditCopyService;
import com.isg.mw.security.dao.service.KeyProviderMasterService;
import com.isg.mw.security.dao.service.KeyProviderOnlineValidator;
import com.isg.mw.security.dao.utils.KeyProviderUtility;
import com.isg.mw.security.mgmt.constants.KeyProviderMgmtMsgKeys;
import com.isg.mw.security.mgmt.model.AddKeyProviderModel;
import com.isg.mw.security.mgmt.model.ModifyKeyProviderModel;
import com.isg.mw.security.mgmt.service.KeyProviderMgmtService;
import com.isg.mw.security.mgmt.utils.KeyProviderMgmtUtility;
import com.isg.mw.security.mgmt.validations.KeyProviderOfflineValidator;

/**
 * Class Implements {@link KeyProviderMgmtService} services
 * 
 * @author prasad_t026
 *
 */
@Service("keyProviderMgmtService")
@Transactional
public class KeyProviderMgmtServiceImpl implements KeyProviderMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private KeyProviderEditCopyService keyProviderEditCopyService;

	@Autowired
	private KeyProviderMasterService keyProviderMasterService;

	@Autowired
	private KeyProviderOnlineValidator keyProviderOnlineValidator;

	@Autowired
	private KeyProviderOfflineValidator keyProviderOfflineValidator;

	@Override
	public ResponseEntity<?> get(String name, String consumerType, SecurityKeyType keyType) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.GET_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		try {
			keyProviderOfflineValidator.get(name, consumerType, keyType);;
			Map<String, KeyProvider> map = new HashMap<String, KeyProvider>(2);
			 KeyProvider master = keyProviderMasterService.findByNameConsumerTypeAndKeyType(name, consumerType, keyType);
			if (master != null) {
				map.put("master", master);
			}
			KeyProvider editCopy = keyProviderEditCopyService.findByNameConsumerTypeAndKeyType(name, consumerType, keyType);
			if (editCopy != null) {
				map.put("editCopy", editCopy);
			}
			if (!map.isEmpty()) {
				response = new ResponseEntity<>(map, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.KP_NOT_FOUND_WITH_NAME);
				response = new ResponseEntity<>(errMsg, HttpStatus.NOT_FOUND);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getAll(String consumerType) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.GETALL_API_LOG_INFO));
		ResponseEntity<?> response = null;
		try {
			List<KeyProvider> all = keyProviderMasterService.getAllActive(consumerType);
			if (!all.isEmpty()) {
				response = new ResponseEntity<>(all, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.KP_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> add(AddKeyProviderModel configModel) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.ADD_API_LOG_INFO, configModel));
		ResponseEntity<?> response = null;
		try {
			KeyProvider model = KeyProviderMgmtUtility.getKeyProviderModel(configModel);
			keyProviderOfflineValidator.addValidation(model);
			keyProviderOnlineValidator.add(model);
			KeyProvider add = keyProviderEditCopyService.add(model);
			response = new ResponseEntity<>(add, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> modify(ModifyKeyProviderModel configModel) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.MODIFY_API_LOG_INFO, configModel));
		ResponseEntity<?> response = null;
		try {
			KeyProvider model = KeyProviderMgmtUtility.getKeyProviderModel(configModel);
			keyProviderOfflineValidator.modifyValidation(model);
			keyProviderOnlineValidator.modify(model);
			KeyProvider update = keyProviderEditCopyService.update(model);
			response = new ResponseEntity<>(update, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> submit(String name, String consumerType, SecurityKeyType keyType) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.SUBMIT_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		try {
			KeyProvider editCopy = keyProviderEditCopyService.findByNameConsumerTypeAndKeyType(name, consumerType, keyType);
			if (editCopy != null) {
				keyProviderOfflineValidator.submit(editCopy);
			}
			keyProviderOnlineValidator.submit(name, consumerType, keyType);
			String updateStatus = keyProviderEditCopyService.updateStatus(EditStatus.Submitted, name, consumerType, keyType);
			response = new ResponseEntity<>(updateStatus, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> lock(String name, String consumerType, SecurityKeyType keyType, LockedState lockedState) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.LOCK_API_LOG_INFO, name));

		ResponseEntity<?> response = null;
		try {
			keyProviderOfflineValidator.lock(name, consumerType, keyType, lockedState);
			keyProviderOnlineValidator.lock(name, consumerType, keyType, lockedState);
			LockedState lock = keyProviderMasterService.lock(name, consumerType, keyType, lockedState);
	
			response = new ResponseEntity<>(lock, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> verify(String name, String consumerType, SecurityKeyType keyType, boolean approved) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.VERIFY_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		try {
			keyProviderOfflineValidator.verify(name, consumerType, keyType, approved);
			keyProviderOnlineValidator.verify(name, consumerType, keyType,approved);
			if (approved) {
				KeyProviderEditCopyEntity editCopyEntity = keyProviderEditCopyService.get(name, consumerType, keyType);
				KeyProviderMasterEntity configMasterEntity = keyProviderMasterService.get(name, consumerType, keyType);
				if (configMasterEntity == null) {
					configMasterEntity = KeyProviderUtility.createMaster(editCopyEntity);
				}
				KeyProviderUtility.updateMaster(editCopyEntity,configMasterEntity);
				configMasterEntity = keyProviderMasterService.save(configMasterEntity);
				keyProviderEditCopyService.delete(editCopyEntity);
			} else {
				keyProviderEditCopyService.updateStatus(EditStatus.Inprogress,name, consumerType, keyType);
			}
			response = new ResponseEntity<>(approved, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> updateStatus(String statusStr,String name, String consumerType, SecurityKeyType keyType) {
		LOG.info(PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.UPDATE_STATUS_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		try {
			keyProviderOfflineValidator.updateValidation(statusStr, name, consumerType, keyType);
			keyProviderOnlineValidator.update(name, consumerType, keyType, statusStr);
			ConfigStatus status = ConfigStatus.getStatus(statusStr);

			if (status != null) {
				keyProviderMasterService.updateStatus(status, name, consumerType, keyType);
			} else {
				KeyProviderEditCopyEntity editCopyEntity = keyProviderEditCopyService.get(name, consumerType, keyType);
				KeyProviderMasterEntity configMasterEntity = keyProviderMasterService.get(name, consumerType, keyType);
				if (editCopyEntity == null) {
					editCopyEntity = new KeyProviderEditCopyEntity();
				}
				KeyProviderUtility.updateEditCopy(configMasterEntity, editCopyEntity);
				editCopyEntity = keyProviderEditCopyService.save(editCopyEntity);
			}
			response = new ResponseEntity<>(statusStr, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(KeyProviderMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	
}
