package com.isg.mw.security.mgmt.model;

import java.util.Map;

import com.isg.mw.security.dao.model.SecurityKeyType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Model use in save API which contain security key provider  fields
 * 
 * @author rahul3983
 *
 */
@Getter
@Setter
@ApiModel(description = "${swgr.kp.model.modify}")
public class ModifyKeyProviderModel {

	@ApiModelProperty(value = "${swgr.kp.model.modify.name.value}", required = true)
	private String name;

	@ApiModelProperty(value = "${swgr.kp.model.modify.builderType.value}", required = true)
	private String builderType;

	@ApiModelProperty(value = "${swgr.kp.model.modify.consumerType.value}", required = true)
	private String consumerType;

	@ApiModelProperty(value = "${swgr.kp.model.modify.keyType.value}", required = true)
	private SecurityKeyType keyType;

	@ApiModelProperty(value = "${swgr.kp.model.modify.configs.value}", required = true)
	private Map<String, String> configs;

}
