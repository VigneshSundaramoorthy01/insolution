package com.isg.mw.security.mgmt.constants;

public interface KeyProviderMgmtMsgKeys {


	String KP_NOT_FOUND_WITH_NAME = "kp.mgmt.keyprovider.not.found";
	
	String INTERNAL_ERROR = "kp.mgmt.internal.error";
	
	String KP_LIST_EMPTY = "kp.mgmt.keyprovider.list.empty";

	String GET_API_LOG_INFO = "kp.mgmt.get.api.log.info";

	String GETALL_API_LOG_INFO = "kp.mgmt.getall.api.log.info";

	String ADD_API_LOG_INFO = "kp.mgmt.add.api.log.info";

	String MODIFY_API_LOG_INFO = "kp.mgmt.update.api.log.info";

	String SUBMIT_API_LOG_INFO = "kp.mgmt.submit.api.log.info";

	String LOCK_API_LOG_INFO = "kp.mgmt.lock.api.log.info";

	String VERIFY_API_LOG_INFO = "kp.mgmt.verify.api.log.info";

	String UPDATE_STATUS_API_LOG_INFO = "kp.mgmt.updatestatus.api.log.info";

}
