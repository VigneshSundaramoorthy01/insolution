package com.isg.mw.security.mgmt.constants;

/**
 * Definitions of KeyProvider URIs
 * 
 * @author rahul3983
 *
 */
public interface KeyProviderUri {
	
	/**
	 * KeyProvider URI for controller as parent
	 */
	String PARENT = "/KeyProvider";
	
	/**
	 * KeyProvider URI for get by name API
	 */
	String GET_BY_NAME = "/get";
	
	/**
	 * KeyProvider URI for get all API
	 */
	String GET_ALL = "/getallactive";
	
	/**
	 * KeyProvider URI for add API
	 */
	String ADD = "/add";
	
	/**
	 * KeyProvider URI for submit API
	 */
	String SUBMIT = "/submit";
	
	/**
	 * KeyProvider URI for modify API
	 */
	String MODIFY = "/save";
	
	/**
	 * KeyProvider URI for verify API
	 */
	String VERIFY = "/verify";
	
	/**
	 * KeyProvider URI for update API
	 */
	String UPDATE_STATUS = "/update";
	
	/**
	 * KeyProvider URI for lock API
	 */
	String LOCK = "/lock";

}
