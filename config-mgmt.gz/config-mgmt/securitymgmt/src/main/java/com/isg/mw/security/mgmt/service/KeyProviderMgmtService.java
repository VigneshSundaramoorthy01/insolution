package com.isg.mw.security.mgmt.service;

import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.model.SecurityKeyType;
import com.isg.mw.security.mgmt.model.AddKeyProviderModel;
import com.isg.mw.security.mgmt.model.ModifyKeyProviderModel;

/**
 * Handles the key provider rest services
 * 
 * @author prasad_t026
 *
 */
public interface KeyProviderMgmtService {

	/**
	 * Retrieve key provider from DB base on name
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> get(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Retrieve all key provider from DB base on name
	 * 
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> getAll(String consumerType);

	/**
	 * Add key provider in DB
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> add(AddKeyProviderModel AddkPModel);

	/**
	 * modify key provider in DB
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> modify(ModifyKeyProviderModel kPModel);

	/**
	 * change the submit status of key provider which exist with Inprogess
	 * status in DB base on name
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> submit(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * change the lock status of key provider which exist in DB base on name
	 * and lock state
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> lock(String name, String consumerType, SecurityKeyType keyType, LockedState lockedState);

	/**
	 * verify submit status of key provider which exist in DB base on name
	 * and move key provider into master table with Active Status and Unlock
	 * State
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> verify(String name, String consumerType, SecurityKeyType keyType, boolean approved);

	/**
	 * change the status of key provider which exist in DB base on name and
	 * status
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> updateStatus(String status,String name, String consumerType, SecurityKeyType keyType);

}
