/**
 * 
 */
package com.isg.mw.security.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;

/**
 * Interface for operations on a validation for a Source offline validation
 * 
 * @author prasad_t026
 *
 */
public interface KeyProviderOfflineValidator {
	/**
	 * offline validation for add API
	 * 
	 * @param model - model object
	 */
	void addValidation(KeyProvider model);

	/**
	 * offline validation for modify API
	 * 
	 * @param model
	 */
	void modifyValidation(KeyProvider model);

	/**
	 * offline validation for submit API
	 * 
	 * @param editCopy - model object
	 */
	void submit(KeyProvider editCopy);

	/**
	 * offline validation for verify API base on name
	 * 
	 * @param name     - name of configuration
	 * @param approved - true or false
	 */
	void verify(String name, String consumerType, SecurityKeyType keyType, boolean approved);

	/**
	 * offline validation for lock API base on name and lock state
	 * 
	 * @param name        - name of configuration
	 * @param lockedState - lock state of configuration
	 */
	void lock(String name, String consumerType, SecurityKeyType keyType, LockedState lockedState);

	/**
	 * offline validation for status of update API base on name and status
	 * 
	 * @param name-  name of configuration
	 * @param status
	 */
	void updateValidation(String status,String name, String consumerType, SecurityKeyType keyType);

	/**
	 * offline validation for get API
	 * 
	 * @param name -name of configuration
	 */
	void get(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * offline validation for getAllActive API
	 */
	void getAllActive();

}
