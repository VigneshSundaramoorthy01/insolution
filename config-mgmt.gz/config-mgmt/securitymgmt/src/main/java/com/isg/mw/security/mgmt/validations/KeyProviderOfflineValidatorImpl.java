package com.isg.mw.security.mgmt.validations;

import org.springframework.stereotype.Component;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;

/**
 * Validates data (data which is coming from out side the system (received data
 * from Rest API)) without hitting database
 * 
 * @author rahul3983
 *
 */
@Component
public class KeyProviderOfflineValidatorImpl implements KeyProviderOfflineValidator {



	@Override
	public void addValidation(KeyProvider model) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyValidation(KeyProvider model) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void submit(KeyProvider editCopy) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void verify(String name, String consumerType, SecurityKeyType keyType, boolean approved) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lock(String name, String consumerType, SecurityKeyType keyType, LockedState lockedState) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateValidation(String status, String name, String consumerType, SecurityKeyType keyType) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void get(String name, String consumerType, SecurityKeyType keyType) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllActive() {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * Optional Data Check based on model object
	 * 
	 * @param model- SourceConfigModel object
	 */
	private void optionalDataCheck(KeyProvider model) {

	}

}