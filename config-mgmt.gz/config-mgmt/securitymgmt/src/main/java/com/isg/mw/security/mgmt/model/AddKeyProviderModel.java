package com.isg.mw.security.mgmt.model;

import java.util.Map;

import com.isg.mw.security.dao.model.SecurityKeyType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Model use in add API which contain security key provider  fields
 * 
 * @author rahul3983
 *
 */
@Getter
@Setter
@ApiModel(description = "${swgr.kp.model.add}")
public class AddKeyProviderModel {

	@ApiModelProperty(value = "${swgr.kp.model.add.name.value}", required = true)
	private String name;

	@ApiModelProperty(value = "${swgr.kp.model.add.builderType.value}", required = true)
	private String builderType;

	@ApiModelProperty(value = "${swgr.kp.model.add.consumerType.value}", required = true)
	private String consumerType;

	@ApiModelProperty(value = "${swgr.kp.model.add.keyType.value}", required = true)
	private SecurityKeyType keyType;

	@ApiModelProperty(value = "${swgr.kp.model.add.configs.value}", required = true)
	private Map<String, String> configs;

}
