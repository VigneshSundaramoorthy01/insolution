package com.isg.mw.security.mgmt.utils;

import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.mgmt.model.AddKeyProviderModel;
import com.isg.mw.security.mgmt.model.ModifyKeyProviderModel;

/**
 * Utility for security management
 * 
 * @author rahul3983
 *
 */
public class KeyProviderMgmtUtility {
	/**
	 * Constructor should not access to the outside
	 */
	private KeyProviderMgmtUtility() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * convert AddKeyProviderModel to KeyProvider
	 * 
	 * @param addModel - AddKeyProviderModel
	 * @return -KeyProvider
	 */
	public static KeyProvider getKeyProviderModel(AddKeyProviderModel addModel) {

		KeyProvider keyProvider = new KeyProvider();
		keyProvider.setName(addModel.getName());
		keyProvider.setBuilderType(addModel.getBuilderType());
		keyProvider.setConsumerType(addModel.getConsumerType());
		keyProvider.setKeyType(addModel.getKeyType());
		keyProvider.setConfigs(addModel.getConfigs());
		return keyProvider;

	}

	/**
	 * convert ModifyKeyProviderModel to KeyProvider
	 * 
	 * @param updateModel - ModifyKeyProviderModel
	 * @return - KeyProvider
	 */
	public static KeyProvider getKeyProviderModel(ModifyKeyProviderModel updateModel) {
		KeyProvider keyProvider = new KeyProvider();
		keyProvider.setName(updateModel.getName());
		keyProvider.setBuilderType(updateModel.getBuilderType());
		keyProvider.setConsumerType(updateModel.getConsumerType());
		keyProvider.setKeyType(updateModel.getKeyType());
		keyProvider.setConfigs(updateModel.getConfigs());
		return keyProvider;

	}

}
