package com.isg.mw.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.model.SecurityKeyType;
import com.isg.mw.security.mgmt.constants.KeyProviderUri;
import com.isg.mw.security.mgmt.model.AddKeyProviderModel;
import com.isg.mw.security.mgmt.model.ModifyKeyProviderModel;
import com.isg.mw.security.mgmt.service.KeyProviderMgmtService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(value = "Key Privider configuration APIs", tags = { "Key Privider Configurations" })
@RestController
@RequestMapping(value = KeyProviderUri.PARENT)
public class KeyProviderMgmtController {

	@Autowired
	private KeyProviderMgmtService keyProviderMgmtService;

	/**
	 * Key provider configuration Rest get API
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.get.value}", notes = "${swgr.kpc.op.get.notes}")
	@GetMapping(path = KeyProviderUri.GET_BY_NAME, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<?> get(
			@ApiParam(required = true, value = "${swgr.kpc.get.name.value}") @RequestParam("name") String name,
			@ApiParam(required = true, value = "${swgr.kpc.get.consumerType.value}") @RequestParam("consumerType") String consumerType,
			@ApiParam(required = true, value = "${swgr.kpc.get.keyType.value}") @RequestParam("keyType") SecurityKeyType keyType) {
		return keyProviderMgmtService.get(name, consumerType, keyType);

	}

	/**
	 * Key provider configuration Rest getAll API
	 * 
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.getall.value}")
	@GetMapping(path = KeyProviderUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<?> getAll(
			@ApiParam(required = true, value = "${swgr.kpc.getall.consumerType.value}") @RequestParam("consumerType")String consumerType) {
		return keyProviderMgmtService.getAll(consumerType);
	}

	/**
	 * Key provider configuration Rest add API
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.add.value}", notes = "${swgr.kpc.op.add.notes}")
	@PostMapping(path = KeyProviderUri.ADD, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<?> add(
			@ApiParam(required = true, value = "AddKeyProviderModel Object") @RequestBody AddKeyProviderModel addkPModel) {
		return keyProviderMgmtService.add(addkPModel);
	}

	/**
	 * Key provider configuration Rest modify API
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.modify.value}", notes = "${swgr.kpc.op.modify.notes}")
	@PostMapping(path = KeyProviderUri.MODIFY, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<?> modify(
			@ApiParam(required = true, value = "ModifyKeyProviderModel Object") @RequestBody ModifyKeyProviderModel modifyKPModel) {
		return keyProviderMgmtService.modify(modifyKPModel);
	}

	/**
	 * Key provider configuration Rest submit API
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.submit.value}", notes = "${swgr.kpc.op.submit.notes}")
	@GetMapping(path = KeyProviderUri.SUBMIT)
	ResponseEntity<?> submit(@ApiParam(required = true, value = "${swgr.kpc.submit.name.value}") @RequestParam("name") String name,
			@ApiParam(required = true, value = "${swgr.kpc.submit.consumerType.value}") @RequestParam("consumerType") String consumerType,
			@ApiParam(required = true, value = "${swgr.kpc.submit.keyType.value}") @RequestParam("keyType") SecurityKeyType keyType) {
		return keyProviderMgmtService.submit(name, consumerType, keyType);
	}

	/**
	 * Key provider configuration Rest lock API
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.lock.value}", notes = "${swgr.kpc.op.lock.notes}")
	@GetMapping(path = KeyProviderUri.LOCK)
	ResponseEntity<?> lock(@ApiParam(required = true, value = "${swgr.kpc.lock.name.value}") @RequestParam("name") String name,
			@ApiParam(required = true, value = "${swgr.kpc.lock.consumerType.value}") @RequestParam("consumerType") String consumerType,
			@ApiParam(required = true, value = "${swgr.kpc.lock.keyType.value}") @RequestParam("keyType") SecurityKeyType keyType,
			@ApiParam(required = true, value = "${swgr.kpc.lock.lockedState.value}") @RequestParam("lockedState") LockedState lockedState) {
		return keyProviderMgmtService.lock(name, consumerType, keyType, lockedState);
	}

	/**
	 * Key provider configuration Rest verify API
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.verify.value}", notes = "${swgr.kpc.op.verify.notes}")
	@GetMapping(path = KeyProviderUri.VERIFY)
	ResponseEntity<?> verify(@ApiParam(required = true, value = "${swgr.kpc.verify.name.value}") @RequestParam("name") String name,
			@ApiParam(required = true, value = "${swgr.kpc.verify.consumerType.value}") @RequestParam("consumerType") String consumerType,
			@ApiParam(required = true, value = "${swgr.kpc.verify.keyType.value}") @RequestParam("keyType") SecurityKeyType keyType,
			@ApiParam(required = true, value = "${swgr.kpc.verify.approved.value}") @RequestParam("approved")boolean approved) {
		return keyProviderMgmtService.verify(name, consumerType, keyType, approved);
	}

	/**
	 * Key provider configuration Rest update status API
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@ApiOperation(value = "${swgr.kpc.op.updatestatus.value}", notes = "${swgr.kpc.op.updatestatus.notes}")
	@GetMapping(path = KeyProviderUri.UPDATE_STATUS)
	ResponseEntity<?> updateStatus(@ApiParam(required = true, value = "${swgr.kpc.updatestatus.status.value}") @RequestParam("status") String status,
			@ApiParam(required = true, value = "${swgr.kpc.updatestatus.name.value}") @RequestParam("name") String name,
			@ApiParam(required = true, value = "${swgr.kpc.updatestatus.consumerType.value}") @RequestParam("consumerType") String consumerType,
			@ApiParam(required = true, value = "${swgr.kpc.updatestatus.keyType.value}") @RequestParam("keyType") SecurityKeyType keyType) {
		return keyProviderMgmtService.updateStatus(status, name, consumerType, keyType);
	}

}
