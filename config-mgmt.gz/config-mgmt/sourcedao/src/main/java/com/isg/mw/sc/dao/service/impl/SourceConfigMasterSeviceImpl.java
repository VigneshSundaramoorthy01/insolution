package com.isg.mw.sc.dao.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.repository.SourceConfigMasterRepository;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sc.dao.utils.SourceConfigMasterUtility;

/**
 * Class which implements {@link SourceConfigMasterService}
 * 
 * @author prasad_t026
 *
 */
@Service("sourceConfigMasterService")
@PropertySource("${spring.config.location}application-uat.properties")
public class SourceConfigMasterSeviceImpl implements SourceConfigMasterService {

	@Autowired
	private SourceConfigMasterRepository sourceConfigMasterRepository;

	@Autowired
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@Value("${eftpos.ignore.sourceId}")
	private String eftposIgnoreSourceId;

	@Override
	public SourceConfigModel get(String name) {

		List<SourceConfigMasterEntity> entities = sourceConfigMasterRepository.findByName(name);
		SourceConfigModel model = null;
		if (!entities.isEmpty()) {
			model = SourceConfigMasterUtility.getSourceModel(entities.get(0));
			model.setMessageFormats(
					messageFormatConfigMasterService.getByOwnerAndOwnerType(model.getId(), OwnerType.SOURCE));
		}
		return model;

	}

	@Override
	public SourceConfigModel add(SourceConfigModel model) {

		SourceConfigMasterEntity entity = sourceConfigMasterRepository
				.save(SourceConfigMasterUtility.getSourceEntity(model));
		return SourceConfigMasterUtility.getSourceModel(entity);

	}

	@Override
	public SourceConfigModel update(SourceConfigModel model) {

		SourceConfigMasterEntity entity = sourceConfigMasterRepository.findByName(model.getName()).get(0);
		SourceConfigMasterUtility.updateSourceEntity(model, entity);
		SourceConfigMasterEntity configMasterEntity = sourceConfigMasterRepository.save(entity);
		return SourceConfigMasterUtility.getSourceModel(configMasterEntity);

	}

	@Override
	public ConfigStatus updateStatus(String name, ConfigStatus status) {

		SourceConfigMasterEntity entity = getEntity(name);
		entity.setStatus(status);
		entity = sourceConfigMasterRepository.save(entity);
		return entity.getStatus();

	}

	@Override
	public List<SourceConfigModel> getAll() {

		List<SourceConfigMasterEntity> entities = sourceConfigMasterRepository.getAll(ConfigStatus.Active,
				LockedState.Unlocked);
		List<SourceConfigModel> models = new ArrayList<SourceConfigModel>(entities.size());
		if (entities != null && !entities.isEmpty()) {
			for (SourceConfigMasterEntity entity : entities) {

				// for ignore the sourceId
				String [] ignoreSourceIdList = eftposIgnoreSourceId.split(",");
				boolean ignoreSourceId = Arrays.stream(ignoreSourceIdList).anyMatch(x -> x.equalsIgnoreCase(String.valueOf(entity.getId())));
				if(ignoreSourceId != true) {
					SourceConfigModel model = SourceConfigMasterUtility.getSourceModel(entity);
					model.setMessageFormats(messageFormatConfigMasterService.getByOwnerAndOwnerType(entity.getId(), OwnerType.SOURCE));
					models.add(model);
				}
			}
		}
		return models;

	}

	@Override
	public LockedState lock(String name, LockedState ls) {

		SourceConfigMasterEntity entity = getEntity(name);
		entity.setLockedState(ls);
		entity = sourceConfigMasterRepository.save(entity);
		return entity.getLockedState();

	}

	@Override
	public SourceConfigMasterEntity getEntity(String name) {

		List<SourceConfigMasterEntity> entities = sourceConfigMasterRepository.findByName(name);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;

	}

	@Override
	public SourceConfigMasterEntity save(SourceConfigMasterEntity entity) {

		return sourceConfigMasterRepository.save(entity);

	}

	@Override
	public SourceConfigMasterEntity get(String name, String entityId) {
		List<SourceConfigMasterEntity> entities = sourceConfigMasterRepository.findByNameAndEntityId(name, entityId);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}

	@Override
	public List<ConfigSummary> getAll(String entityId) {
		List<SourceConfigMasterEntity> entities = sourceConfigMasterRepository.findByEntityId(entityId);
		List<ConfigSummary> models = new ArrayList<ConfigSummary>(entities.size());
		if (entities != null && !entities.isEmpty()) {
			for (SourceConfigMasterEntity entity : entities) {

				String [] ignoreSourceIdList = eftposIgnoreSourceId.split(",");
				boolean ignoreSourceId = Arrays.stream(ignoreSourceIdList).anyMatch(x -> x.equalsIgnoreCase(String.valueOf(entity.getId())));
				if(ignoreSourceId != true) {
					ConfigSummary model = getConfigSummury(entity);
					models.add(model);
				}
			}
		}
		return models;
	}

	/**
	 * Get ConfigSummary object
	 * 
	 * @param entity - SourceConfigMasterEntity object
	 * @return - ConfigSummary object
	 */
	private ConfigSummary getConfigSummury(SourceConfigMasterEntity entity) {
		ConfigSummary model = new ConfigSummary();
		model.setEntityId(entity.getEntityId());
		model.setOwnerType(OwnerType.SOURCE);
		model.setConfigName(entity.getName());
		model.setConfigStatus(entity.getStatus());
		model.setMasterExists(sourceConfigMasterRepository.isSourceConfigExists(entity.getName()));
		model.setLockedState(entity.getLockedState());
		return model;
	}

	@Override
	public SourceConfigModel getSource(Long id, LockedState ls, ConfigStatus status) {
		SourceConfigMasterEntity source = sourceConfigMasterRepository.getSource(id, ls, status);
		if (source != null) {
			return SourceConfigMasterUtility.getSourceModel(source);
		}
		return null;
	}

	@Override
	public List<SourceConfigModel> getConfigByStatus(String status) {
		List<SourceConfigMasterEntity> entities = new ArrayList<>();
		if (ConfigStatus.Active == ConfigStatus.getStatus(status)
				|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)) {
			entities = sourceConfigMasterRepository.getAll(ConfigStatus.valueOf(status));
		}
		if (LockedState.Locked == LockedState.getState(status)
				|| LockedState.Unlocked == LockedState.getState(status)) {
			entities = sourceConfigMasterRepository.getAll(LockedState.valueOf(status));
		}
		List<SourceConfigModel> list = new ArrayList<>(entities.size());
		if (!CollectionUtils.isEmpty(entities)) {
			for (SourceConfigMasterEntity entity : entities) {
				SourceConfigModel model = SourceConfigMasterUtility.getSourceModel(entity);
				model.setMessageFormats(messageFormatConfigMasterService.getByOwnerAndOwnerType(entity.getId(), OwnerType.SOURCE));
				list.add(model);
			}
		}
		return list;
	}

	@Override
	public List<SourceConfigModel> getAllByEntity(String entityId) {

		List<SourceConfigMasterEntity> entities = sourceConfigMasterRepository.getAllByEntity(ConfigStatus.Active,
				LockedState.Unlocked,entityId);
		List<SourceConfigModel> models = new ArrayList<SourceConfigModel>(entities.size());
		if (entities != null && !entities.isEmpty()) {
			for (SourceConfigMasterEntity entity : entities) {
				// for ignore the sourceId
				String [] ignoreSourceIdList = eftposIgnoreSourceId.split(",");
				boolean ignoreSourceId = Arrays.stream(ignoreSourceIdList).anyMatch(x -> x.equalsIgnoreCase(String.valueOf(entity.getId())));
				if(ignoreSourceId != true) {
					SourceConfigModel model = SourceConfigMasterUtility.getSourceModel(entity);
					model.setMessageFormats(messageFormatConfigMasterService.getByOwnerAndOwnerType(entity.getId(), OwnerType.SOURCE));
					models.add(model);
				}
			}
		}
		return models;
	}

}
