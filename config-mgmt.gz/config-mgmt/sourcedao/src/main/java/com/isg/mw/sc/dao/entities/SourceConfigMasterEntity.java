package com.isg.mw.sc.dao.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.SrcActionExtn;
import com.isg.mw.core.model.constants.TargetType;

import lombok.Getter;
import lombok.Setter;

/**
 * Source Configuration Master Entity details
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
@Entity
@Table(name = "SOURCE_CONFIG_MASTER")
public class SourceConfigMasterEntity extends AuditInfoEntity {

	/**
	 * Primary id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	/**
	 * Entity Id
	 */
	@Column(name = "ENTITY_ID", length = 32)
	private String entityId;

	/**
	 * Name of configuration
	 */
	@Column(name = "NAME", length = 64)
	private String name;

	/**
	 * Name of the default target configuration
	 */
	@Column(name = "DEFAULT_TARGET", length = 64)
	private String defaultTarget;

	
	/**
	 * List of preferred targets
	 */
	@Column(name = "TARGET_PREFERENCES", length = 324)
	private String targetPreferences;

	/**
	 * Connection type
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "CONNECTION_TYPE", length = 10)
	private ConnectionType connectionType;

	/**
	 * Socket port number
	 */
	@Column(name = "PORT_OR_URI", length = 64)
	private String portOrUri;

	/**
	 * Status of the configuration
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS", length = 10)
	private ConfigStatus status;

	/**
	 * flag turns on Merchant Validation from Merchant Data in cache is set to on
	 * otherwise Merchant validation is disabled.
	 */
	@Column(name = "MERCHANT_VAL")
	private boolean merchantValidation;

	/**
	 * flags enble card bin validation and Acquirer BIN validation if set to ON.
	 */
	@Column(name = "ISSUER_BIN_VAL")
	private boolean issuerBinValidation;

	/**
	 * flags enble card bin validation and Acquirer BIN validation if set to ON.
	 */
	@Column(name = "ACQUIRER_BIN_VAL")
	private boolean acquirerBinValidation;

	/**
	 * flag enables/disables decryption of data elements using source keys and
	 * re-encryption of data elements using target keys
	 */
	@Column(name = "DATA_SECURITY_MODULE")
	private boolean dataSecurityModule;

	/**
	 * flag enables/disables message tranformation.Require source-target Mapping
	 * table to be loaded in cache only if it is ON.If it is set to OFF,the source
	 * and target message specification must be same.
	 */
	@Column(name = "MSG_TRANSFERMATION")
	private boolean msgTransformation;

	/**
	 * maps url which is used while smart controller initialization
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "TXN_LOGGING", length = 10)
	private SrcActionExtn txnLogging;

	/**
	 * locked state
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "LOCKED_STATE", length = 10)
	private LockedState lockedState;

	/**
	 * Scheme Type (Visa, Master, Rupay, Pos)
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "SOURCE_TYPE", length = 20)
	private TargetType sourceType;

	/**
	 * Request time out
	 */
	@Column(name = "REQUEST_TIMEOUT")
	private int requestTimeout;

	@Column(name = "PRE_AUTH_PER_LIMIT")
	private String preAuthPerLimit;

	@Column(name = "PRE_AUTH_TIME_PERIOD")
	private String preAuthTimePeriod;

	/**
	 * List of sftpParams which is consist username , password, key, location 
	 */
	@Column(name = "SFTP_PARAMS", length = 4000)
	private String sftpParams;
	
	/**
	 * sourceProcessor of the configuration
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "SOURCE_PROCESSOR", length = 20)
	private SourceProcessor sourceProcessor;

	@Column(name = "REMARKS", length = 2000)
	private String remarks;
	
	@Column(name = "ADDITIONAL_DATA")
	private String additionalData;
}