package com.isg.mw.sc.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sc.dao.service.SourceMfMasterService;

/**
 * Class which implements {@link SourceMfMasterService}
 * 
 * @author prasad_t026
 *
 */
@Service("sourceMfMasterService")
public class SourceMfMasterServiceImpl implements SourceMfMasterService {

	@Autowired
	private SourceConfigMasterService sourceConfigMasterService;

	@Autowired
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@Override
	public List<MessageFormatConfigModel> getList(String entityId, String name) {
		SourceConfigMasterEntity tcm = sourceConfigMasterService.getEntity(name);
		List<MessageFormatConfigModel> list = null;
		if (tcm != null) {
			list = messageFormatConfigMasterService.getByOwnerAndOwnerType(tcm.getId(), OwnerType.SOURCE);
		}

		return list;
	}

}
