package com.isg.mw.sc.dao.constants;

/**
 * constants to refer keys from message resource bundle
 * 
 * @author rahul3983
 *
 */
public interface SourceMFDaoMsgKeys {
	
	/**
	 * Source {0} edit copy is not exists
	 */
	String SOURCE_EDIT_COPY_NOT_EXISTS = "sc.dao.edit.copy.not.exists";
	
	/**
	 * Source {0} has submitted status
	 */
	String SOURCE_STATUS_IS_SUBMITTED_STATUS = "sc.dao.has.SUBMITTED.status";
	
	/**
	 * Message format {0} is not exists
	 */
	String MESSAGE_FORMAT_NOT_EXISTS = "sc.dao.message.format.not.exists";
	
	/**
	 * System cant allow to change LOCKEDSTATE configurations message format
	 */
	String SYSTEM_WONT_ALLOW_TO_MODIFY = "sc.dao.system.wont.allow.to.modify";

}
