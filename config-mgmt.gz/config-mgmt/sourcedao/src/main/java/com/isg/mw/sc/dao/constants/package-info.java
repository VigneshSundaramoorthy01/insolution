/**
 * @author prasad_t026
 *
 */
package com.isg.mw.sc.dao.constants;