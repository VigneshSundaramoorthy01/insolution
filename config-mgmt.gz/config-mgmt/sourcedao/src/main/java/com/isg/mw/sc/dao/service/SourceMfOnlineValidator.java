package com.isg.mw.sc.dao.service;

import com.isg.mw.core.model.mf.MessageFormatConfigModel;

/**
 * Interface for operations on a validation for a Source message format
 * online validation
 * 
 * @author prasad_t026
 *
 */
public interface SourceMfOnlineValidator {

	/**
	 * validation for add API with given model, entity id and name
	 * 
	 * @param model    - model object
	 * @param entityId - entity id of the configuration
	 * @param name     - name of the configuration
	 * @return
	 */
	Long addValidation(MessageFormatConfigModel model, String entityId, String name);

	/**
	 * validation for modify API
	 * 
	 * @param model - model object
	 */
	void modifyValidation(MessageFormatConfigModel model);

	/**
	 * validation for delete API
	 * 
	 * @param id
	 */
	void deleteValidation(Long id);

}
