package com.isg.mw.sc.dao.utils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;

/**
 * Utility for converting masterEntity to editCopyEntity and editCopyEntity to
 * masterEntity object(s) etc.,
 * 
 * @author prasad_t026
 *
 */
public class SourceUtility {

	/**
	 * Default constructor It should not access from out side
	 * 
	 */
	private SourceUtility() {
	}

	/**
	 * convert editCopyEntity to masterEntity object
	 * 
	 * @param master   - source configuration master entity object
	 * @param editCopy -source configuration edit copy entity object
	 */
	public static void updateMaster(SourceConfigMasterEntity master, SourceConfigEditCopyEntity editCopy) {

		master.setDefaultTarget(editCopy.getDefaultTarget());
		master.setTargetPreferences(editCopy.getTargetPreferences());
		master.setConnectionType(editCopy.getConnectionType());
		master.setPortOrUri(editCopy.getPortOrUri());
		master.setMerchantValidation(editCopy.isMerchantValidation());
		master.setIssuerBinValidation(editCopy.isIssuerBinValidation());
		master.setAcquirerBinValidation(editCopy.isAcquirerBinValidation());
		master.setDataSecurityModule(editCopy.isDataSecurityModule());
		master.setMsgTransformation(editCopy.isMsgTransformation());
		master.setTxnLogging(editCopy.getTxnLogging());
		master.setSourceType(editCopy.getSourceType());
        master.setRequestTimeout(editCopy.getRequestTimeout());
	    master.setPreAuthPerLimit(editCopy.getPreAuthPerLimit());
	    master.setPreAuthTimePeriod(editCopy.getPreAuthTimePeriod());
	    master.setSourceProcessor(editCopy.getSourceProcessor());
	    master.setRemarks(editCopy.getRemarks());
	    master.setAdditionalData(editCopy.getAdditionalData());

	}

	/**
	 * convert masterEntity to editCopyEntity object
	 * 
	 * @param master   -source configuration master entity object
	 * @param editCopy - source configuration edit copy entity object
	 */
	public static void updateEditCopy(SourceConfigMasterEntity master, SourceConfigEditCopyEntity editCopy) {

		editCopy.setEntityId(master.getEntityId());
		editCopy.setName(master.getName());
		editCopy.setDefaultTarget(master.getDefaultTarget());
		editCopy.setTargetPreferences(master.getTargetPreferences());
		editCopy.setConnectionType(master.getConnectionType());
		editCopy.setPortOrUri(master.getPortOrUri());
		editCopy.setStatus(EditStatus.Inprogress);
		editCopy.setMerchantValidation(master.isMerchantValidation());
		editCopy.setIssuerBinValidation(master.isIssuerBinValidation());
		editCopy.setAcquirerBinValidation(master.isAcquirerBinValidation());
		editCopy.setDataSecurityModule(master.isDataSecurityModule());
		editCopy.setMsgTransformation(master.isMsgTransformation());
		editCopy.setTxnLogging(master.getTxnLogging());
		editCopy.setSourceType(master.getSourceType());
		editCopy.setRequestTimeout(master.getRequestTimeout());
        editCopy.setPreAuthPerLimit(master.getPreAuthPerLimit());
        editCopy.setPreAuthTimePeriod(master.getPreAuthTimePeriod());
        editCopy.setRemarks(master.getRemarks());
        editCopy.setAdditionalData(master.getAdditionalData());

	}

	/**
	 * create source configuration master entity
	 * 
	 * @param editCopy - source configuration edit copy entity object
	 * @return - source configuration master entity object
	 */
	public static SourceConfigMasterEntity createMaster(SourceConfigEditCopyEntity editCopy) {

		SourceConfigMasterEntity masterEntity = new SourceConfigMasterEntity();
		masterEntity.setEntityId(editCopy.getEntityId());
		masterEntity.setName(editCopy.getName());
		masterEntity.setStatus(ConfigStatus.Active);
		masterEntity.setLockedState(LockedState.Unlocked);
		masterEntity.setRequestTimeout(editCopy.getRequestTimeout());
		masterEntity.setPreAuthPerLimit(editCopy.getPreAuthPerLimit());
		masterEntity.setPreAuthTimePeriod(editCopy.getPreAuthTimePeriod());
		masterEntity.setSourceProcessor(editCopy.getSourceProcessor());
		masterEntity.setRemarks(editCopy.getRemarks());
		masterEntity.setAdditionalData(editCopy.getAdditionalData());
		return masterEntity;
    }

}
