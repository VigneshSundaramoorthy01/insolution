package com.isg.mw.sc.dao.constants;

/**
 * constants to refer keys from message resource bundle
 * 
 * @author rahul3983
 *
 */
public interface SourceDaoMsgKeys {
	
	/**
	 * Source Configuration {0} already exists
	 */
	String SC_DUPLICATE_NAME = "sc.dao.duplicate.name";

	/**
	 * Source Configuration {0} not exists
	 */
	String SC_NOT_EXISTS_WITH_NAME = "sc.dao.name.not.exists";

	/**
	 * Source Configuration {0} has same status {1}
	 */
	String SC_STATUS_IS_SAME_AS_EXPECTED = "sc.dao.status.is.same.as.expected";
	
	/**
	 * System cant allow to change TYPE
	 */
	String SC_TYPE_CANT_CHANGE = "sc.dao.type.cant.change";

	/**
	 * should use with one argument - port
	 */
	String SC_PORT_CANT_CHANGE = "sc.dao.port.cant.change";

	/**
	 * System cant allow to change PORT
	 */
	String SC_URI_CANT_CHANGE = "sc.dao.uri.cant.change";
	
	/**
	 * System cant allow to change AGGREGATORID
	 */
	String SC_ENTITYID_SHOULD_NOT_BE_CHANGE = "sc.dao.entityid.should.not.change";
	
	/**
	 * System cant allow to change STATUS.
	 */
	String SC_STATUS_SHOULD_NOT_BE_SUBMITTED = "sc.dao.status.should.not.be.submitted";
	
	/**
	 * System allow to change STATUS as expected should be SUBMITTED
	 */
	String SC_STATUS_SHOULD_BE_SUBMITTED = "sc.dao.status.should.be.submitted";
	
	/**
	 * System cant allow to change already present LOCKEDSTATE
	 */
	String SC_LOCKED_STATE_SHOULD_NOT_BE_SAME = "sc.dao.locked.state.should.not.be.same";
	
	/**
	 * System cant allow to change already present STATUS
	 */
	String SC_STATUS_SHOULD_NOT_BE_SAME = "sc.dao.status.should.not.be.same";
	
	/**
	 * Already Source configuration exists with {0}
	 */
	String SC_ALREADY_EXIST_WITH_NAME = "sc.dao.already.exist.with.name";
	
	/**
	 * {0} configuration exists in SUBMITTED state
	 */
	String SC_ALREADY_EXIST_IN_SUBMITTED_STATE = "sc.dao.already.exist.in.submitted.state";
	
	/**
	 * {0} is invalid status
	 */
	String SC_STATUS_IS_INVALID = "sc.dao.status.is.invalid";
	
	/**
	 * {0} configuration exists in SUBMITTED state it should be in IN_PROGESS
	 */
	String SC_CONFIGURATION_EXISTS_IN_SUBMITTED_STATE = "sc.dao.configuration.exists.in.submitted.state";
	
	/**
	 * System won't allow to modify locked {0} configuration
	 */
	String SC_LOCK_CANT_CHANGE = "sc.dao.lock.cant.change";

	/**
	 * System wont allow to set locked or non-existing target {0} configuration
	 */
	String SC_CANT_ALLOW_TO_SET_LOCKED_OR_NON_EXISTING_TARGET_CONFIGURATION = "sc.dao.cant.allow.to.set.lock.or.non.existing.target";
	
	/**
	 * {0} already in use
	 */
	String SC_PORT_ALREADY_IN_USE = "sc.dao.port.already.in.use";
	
	/**
	 * {0} already in use
	 */
	String SC_URI_ALREADY_IN_USE = "sc.dao.uri.already.in.use";
	/**
	 * Already Source configuration exists with {0}
	 */
	String SC_ALREADY_EXIST_IN_EDIT_COPY_ENTITY_ID = "sc.dao.already.exist.in.edit.copy.with.entity.id";
	/**
	 * Already Source configuration exists with {0}
	 */
	String SC_ALREADY_EXIST_IN_MASTER_ENTITY_ID = "sc.dao.already.exist.in.master.with.entity.id";

	String STATUS_SOURCE_IS_MANDATORY = "sc.dao.status.source.is.mandatory";

}
