package com.isg.mw.sc.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;

/**
 * Interface for generic CRUD operations on a repository for a Source
 * Configuration Master
 * 
 * @author prasad_t026
 *
 */
public interface SourceConfigMasterRepository extends CrudRepository<SourceConfigMasterEntity, Long> {

	/**
	 * finds the matching Source configuration master with the given name
	 * 
	 * @param name - name of the Source configuration master
	 * @return - List of Source configuration master objects
	 */
	List<SourceConfigMasterEntity> findByName(@Param("name") String name);

	/**
	 * finds the matching Source configuration master with the given portOrUri
	 * 
	 * @param portOrUri - portOrUri of the Source configuration master
	 * @return - List of Source configuration master objects
	 */
	@Query("SELECT scece FROM SourceConfigMasterEntity scece WHERE scece.portOrUri = :portOrUri")
	List<SourceConfigMasterEntity> findByPortOrUri(@Param("portOrUri") String portOrUri);

	/**
	 * Call to verify the matching Source configuration master exist with the given
	 * name
	 *
	 * @param name - status of the Source configuration master
	 * @return - true or false value if Source configuration master exists
	 */
	@Query("SELECT CASE WHEN COUNT(scme) > 0 THEN true ELSE false END FROM SourceConfigMasterEntity scme WHERE scme.name = :name")
	boolean isSourceConfigExists(@Param("name") String name);

	/**
	 * Call to verify the matching Source configuration master exist with the given
	 * status
	 * 
	 * @param status -status of the Source configuration master
	 * @param name   - name of the Source configuration master status and name
	 * @return - true or false value if Source configuration master status matching
	 */
	@Query("SELECT CASE WHEN COUNT(scme) > 0 THEN true ELSE false END FROM SourceConfigMasterEntity scme WHERE "
			+ "scme.status = :status and scme.name = :name")
	boolean isSourceConfiStatusMatching(@Param("status") ConfigStatus status, @Param("name") String name);

	/**
	 * finds the matching Source configuration master with the given status and
	 * locked state
	 * 
	 * @return - List of source configuration object
	 */
	@Query("SELECT scme FROM SourceConfigMasterEntity scme WHERE scme.status = :status and scme.lockedState = :lockedState")
	List<SourceConfigMasterEntity> getAll(@Param("status") ConfigStatus status,
			@Param("lockedState") LockedState lockedState);

	/**
	 * Call to verify the matching Source configuration master exist with the given
	 * name and locked state
	 * 
	 * @param name        - name of the configuration
	 * @param lockedState - locked state
	 * 
	 * @return - true or false value if target is exists
	 */
	@Query("SELECT CASE WHEN COUNT(scme) > 0 THEN true ELSE false END FROM SourceConfigMasterEntity scme WHERE "
			+ "scme.name = :name and scme.lockedState = :lockedState")
	boolean isSourceConfigExists(@Param("name") String name, @Param("lockedState") LockedState lockedState);

	/**
	 * finds the matching configurations with the given name
	 * 
	 * @param name - name of the configuration
	 * @return - List of configuration objects
	 */
	@Query("SELECT scme FROM SourceConfigMasterEntity scme WHERE scme.name = :name and scme.entityId = :aId")
	List<SourceConfigMasterEntity> findByNameAndEntityId(@Param("name") String name, @Param("aId") String entityId);

	/**
	 * finds the matching Source configuration master with the given entityId
	 * 
	 * @param entityId - Entity Id of the Source configuration master
	 * @return - List of Source configuration master objects
	 */
	@Query("SELECT scece FROM SourceConfigMasterEntity scece WHERE scece.entityId = :entityId")
	List<SourceConfigMasterEntity> findByEntityId(@Param("entityId") String entityId);

	/**
	 * Call to verify the matching Source configuration master exist with the given
	 * name
	 *
	 * @param name - status of the Source configuration master
	 * @return - true or false value if Source configuration master exists
	 */
	@Query("SELECT CASE WHEN COUNT(scme) > 0 THEN true ELSE false END FROM SourceConfigMasterEntity scme WHERE scme.entityId = :entityId")
	boolean isSourceConfigEntityIdExists(@Param("entityId") String entityId);

	@Query("SELECT scme FROM SourceConfigMasterEntity scme WHERE scme.id = :id and scme.lockedState = :lockedState and scme.status = :status")
	SourceConfigMasterEntity getSource(@Param("id") Long id, @Param("lockedState") LockedState lockedState,
			@Param("status") ConfigStatus status);
	
	@Query("SELECT scme FROM SourceConfigMasterEntity scme WHERE scme.status = :status")
	List<SourceConfigMasterEntity> getAll(@Param("status") ConfigStatus status);
	
	@Query("SELECT scme FROM SourceConfigMasterEntity scme WHERE scme.lockedState = :status")
	List<SourceConfigMasterEntity> getAll(@Param("status") LockedState status);

	@Query("SELECT scme FROM SourceConfigMasterEntity scme WHERE scme.status = :status and scme.lockedState = :lockedState and scme.entityId = :entityId")
	List<SourceConfigMasterEntity> getAllByEntity(@Param("status") ConfigStatus status,
												  @Param("lockedState") LockedState lockedState, @Param("entityId") String entityId);
}
