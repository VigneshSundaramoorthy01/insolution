package com.isg.mw.sc.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;

/**
 * Interface for generic CRUD operations on a repository for a Source
 * Configuration Edit Copy
 * 
 * @author prasad_t026
 *
 */
public interface SourceConfigEditCopyRepository extends CrudRepository<SourceConfigEditCopyEntity, Long> {

	/**
	 * finds the matching Source configuration Edit Copy with the given name
	 * 
	 * @param name - name of the Source configuration Edit Copy
	 * @return - List of Source configuration Edit Copy objects
	 */
	List<SourceConfigEditCopyEntity> findByName(@Param("name") String name);

	/**
	 * finds the matching Source configuration Edit Copy with the given portOrUri
	 * 
	 * @param portOrUri - portOrUri of the Source configuration Edit Copy
	 * @return - List of Source configuration Edit Copy objects
	 */
	@Query("SELECT scece FROM SourceConfigEditCopyEntity scece WHERE scece.portOrUri = :portOrUri")
	List<SourceConfigEditCopyEntity> findByPortOrUri(@Param("portOrUri") String portOrUri);

	/**
	 * Call to verify the matching Source configuration Edit Copy exist with the name
	 * 
	 * @param name - status of the Source configuration Edit Copy
	 * @return - true or false value if Source configuration Edit Copy exists
	 */
	@Query("SELECT CASE WHEN COUNT(scece) > 0 THEN true ELSE false END FROM SourceConfigEditCopyEntity scece WHERE scece.name = :name")
	boolean isSourceConfigExists(@Param("name") String name);

	/**
	 * Call to verify the matching Source configuration Edit Copy exist with the name and status
	 * 
	 * @param status - status of the Source configuration Edit Copy
	 * @param name   - name of the Source configuration Edit Copy
	 * @return - true or false value if Source configuration Edit Copy status
	 *         matching
	 */
	@Query("SELECT CASE WHEN COUNT(scece) > 0 THEN true ELSE false END FROM SourceConfigEditCopyEntity scece WHERE "
			+ "scece.status = :status and scece.name = :name")
	boolean isSourceConfiStatusMatching(@Param("status") EditStatus status, @Param("name") String name);

	/**
	 * finds the matching Source configuration Edit Copy with the EntityId
	 * 
	 * @param entityId - entityId of the Source configuration Edit Copy
	 * @return - List of Source configuration Edit Copy objects
	 */
	@Query("SELECT scece FROM SourceConfigEditCopyEntity scece WHERE scece.entityId = :entityId")
	List<SourceConfigEditCopyEntity> findByEntityId(@Param("entityId") String entityId);

	/**
	 * Call to verify the matching Source configuration Edit Copy exist with the entityId
	 * 
	 * @param entityId - entityId of the Source configuration Edit Copy
	 * @return - true or false value if Source configuration Edit Copy exists
	 */
	@Query("SELECT CASE WHEN COUNT(scece) > 0 THEN true ELSE false END FROM SourceConfigEditCopyEntity scece WHERE scece.entityId = :entityId")
	boolean isSourceConfigEntityIdExists(@Param("entityId") String entityId);

	@Query("SELECT se FROM SourceConfigEditCopyEntity se WHERE se.status = :status")
	List<SourceConfigEditCopyEntity> getAll(@Param("status") EditStatus status);
}
