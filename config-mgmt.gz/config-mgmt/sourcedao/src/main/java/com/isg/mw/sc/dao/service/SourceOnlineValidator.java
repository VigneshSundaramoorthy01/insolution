package com.isg.mw.sc.dao.service;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.sc.SourceConfigModel;

/**
 * Interface for operations on a validation for a Source online validation
 * 
 * @author prasad_t026
 *
 */
public interface SourceOnlineValidator {
	
	/**
	 * validation for verify source exist with name
	 * 
	 * @param name - name of the configuration
	 * @return - true or false value is source exist
	 */
	boolean isSourceExists(String name);

	/**
	 * validation for verify source unlock with name
	 * 
	 * @param name - name of the configuration
	 * @return - true or false value is source unlock
	 */
	boolean isSourceUnlocked(String name);

	/**
	 * validation for verify source edit copy exist with name
	 * 
	 * @param name - name of the configuration
	 * @return - true or false value is source edit copy exist
	 */
	boolean isSourceEditCopyExists(String name);

	/**
	 * validation for add API
	 * 
	 * @param model - model object
	 */
	void add(SourceConfigModel model);

	/**
	 * validation for modify API
	 * 
	 * @param model - model object
	 */
	void modify(SourceConfigModel model);

	/**
	 * validation for submit API
	 * 
	 * @param name - name of the configuration
	 * 
	 */
	void submit(String name);

	/**
	 * validation for verify API
	 * 
	 * @param name     - name of the configuration
	 * @param approved
	 */
	void verify(String name, boolean approved);

	/**
	 * validation for lock API
	 * 
	 * @param name        - name of the configuration
	 * @param lockedState - lock state of the configuration
	 */
	void lock(String name, LockedState lockedState);

	/**
	 * validation for update API
	 * 
	 * @param name   - name of the configuration
	 * @param status - status of the configuration
	 */
	void update(String name, String status);

	/**
	 * validation for check source exist with entity id
	 * @param entityId - entityId of the configuration
	 * @return - boolean
	 */
	boolean isSourceConfigEditCopyEntityIdExists(String entityId);
	/**
	 * validation for check source exist with entity id
	 * @param entityId - entityId of the configuration
	 * @return - boolean
	 */
	boolean isSourceConfigMasterEntityIdExists(String entityId);

}
