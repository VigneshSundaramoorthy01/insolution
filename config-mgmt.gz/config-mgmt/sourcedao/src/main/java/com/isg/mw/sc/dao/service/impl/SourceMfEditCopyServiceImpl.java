package com.isg.mw.sc.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.service.SourceMfEditCopyService;

/**
 * Class which implements {@link SourceMfEditCopyService}
 * 
 * @author prasad_t026
 *
 */
@Service("sourceMfEditCopyService")
public class SourceMfEditCopyServiceImpl implements SourceMfEditCopyService {

	@Autowired
	private SourceConfigEditCopyService sourceConfigEditCopyService;

	@Autowired
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Override
	public List<MessageFormatConfigModel> getList(String entityId, String name) {
		SourceConfigEditCopyEntity scm = sourceConfigEditCopyService.getEntity(name);
		List<MessageFormatConfigModel> list = null;
		if (scm != null) {
			list = messageFormatConfigEditCopyService.getByOwnerAndOwnerType(scm.getId(), OwnerType.SOURCE);
		}

		return list;
	}

}
