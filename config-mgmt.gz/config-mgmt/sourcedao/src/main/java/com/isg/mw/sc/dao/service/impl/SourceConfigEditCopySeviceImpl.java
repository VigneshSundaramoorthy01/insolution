package com.isg.mw.sc.dao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.repository.SourceConfigEditCopyRepository;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.utils.SourceConfigEditCopyUtility;

/**
 * Class which implements {@link SourceConfigEditCopyService}
 * 
 * @author prasad_t026
 *
 */
@Service("sourceConfigEditCopyService")
public class SourceConfigEditCopySeviceImpl implements SourceConfigEditCopyService {

	@Autowired
	private SourceConfigEditCopyRepository sourceConfigEditCopyRepository;

	@Autowired
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Override
	public SourceConfigModel get(String name) {
		List<SourceConfigEditCopyEntity> entities = sourceConfigEditCopyRepository.findByName(name);
		SourceConfigModel model = null;
		if (!entities.isEmpty()) {
			model = SourceConfigEditCopyUtility.getSourceModel(entities.get(0));
			model.setMessageFormats(
					messageFormatConfigEditCopyService.getByOwnerAndOwnerType(model.getId(), OwnerType.SOURCE));
		}
		return model;

	}

	@Override
	public SourceConfigModel add(SourceConfigModel configModel) {

		SourceConfigEditCopyEntity configEditCopyEntity = sourceConfigEditCopyRepository
				.save(SourceConfigEditCopyUtility.getSourceEntity(configModel));
		return SourceConfigEditCopyUtility.getSourceModel(configEditCopyEntity);

	}

	@Override
	public SourceConfigModel update(SourceConfigModel configModel) {

		SourceConfigEditCopyEntity entity = getEntity(configModel.getName());
		SourceConfigEditCopyUtility.updateSourceEntity(configModel, entity);
		if(entity.getStatus() == EditStatus.Rejected) {
			entity.setStatus(EditStatus.Inprogress);	
		}
		SourceConfigEditCopyEntity configEditCopyEntity = sourceConfigEditCopyRepository.save(entity);
		return SourceConfigEditCopyUtility.getSourceModel(configEditCopyEntity);

	}

	@Override
	public String updateStatus(EditStatus status, String name,String remarks) {
		SourceConfigEditCopyEntity entity = getEntity(name);
		entity.setStatus(status);
		entity.setRemarks(remarks != null ? remarks : entity.getRemarks());
		entity = sourceConfigEditCopyRepository.save(entity);
		return entity.getStatus().name();

	}

	@Override
	public SourceConfigEditCopyEntity getEntity(String name) {

		List<SourceConfigEditCopyEntity> entities = sourceConfigEditCopyRepository.findByName(name);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;

	}

	@Override
	public boolean isEditCopyExists(String name) {

		return sourceConfigEditCopyRepository.isSourceConfigExists(name);

	}

	@Override
	public SourceConfigEditCopyEntity save(SourceConfigEditCopyEntity entity) {

		return sourceConfigEditCopyRepository.save(entity);

	}

	@Override
	public void delete(SourceConfigEditCopyEntity editCopyEntity) {

		sourceConfigEditCopyRepository.delete(editCopyEntity);

	}

	@Override
	public List<ConfigSummary> getAll(String entityId) {

		List<SourceConfigEditCopyEntity> entities = sourceConfigEditCopyRepository.findByEntityId(entityId);
		List<ConfigSummary> models = new ArrayList<ConfigSummary>(entities.size());
		if (entities != null && !entities.isEmpty()) {
			for (SourceConfigEditCopyEntity entity : entities) {
				ConfigSummary model = getConfigSummury(entity);
				models.add(model);
			}
		}
		return models;

	}

	/**
	 * Get ConfigSummary object
	 * 
	 * @param entity - SourceConfigEditCopyEntity object
	 * @return - ConfigSummary object
	 */
	private ConfigSummary getConfigSummury(SourceConfigEditCopyEntity entity) {
		ConfigSummary model = new ConfigSummary();
		model.setEntityId(entity.getEntityId());
		model.setOwnerType(OwnerType.SOURCE);
		model.setConfigName(entity.getName());
		model.setEditCopyExists(sourceConfigEditCopyRepository.isSourceConfigExists(entity.getName()));
		model.setEditStatus(entity.getStatus());

		return model;
	}

	@Override
	public List<SourceConfigModel> getConfigByStatus(String status) {
		List<SourceConfigEditCopyEntity> entities = sourceConfigEditCopyRepository.getAll(EditStatus.valueOf(status));
		List<SourceConfigModel> list = new ArrayList<>(entities.size());
		if (!CollectionUtils.isEmpty(entities)) {
			for (SourceConfigEditCopyEntity entity : entities) {
				SourceConfigModel model = SourceConfigEditCopyUtility.getSourceModel(entity);
				model.setMessageFormats(messageFormatConfigEditCopyService.getByOwnerAndOwnerType(entity.getId(), OwnerType.SOURCE));
				list.add(model);
			}
		}
		return list;
	}

}
