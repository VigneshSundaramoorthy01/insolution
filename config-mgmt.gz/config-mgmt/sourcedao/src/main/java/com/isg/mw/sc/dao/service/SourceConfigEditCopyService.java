package com.isg.mw.sc.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;

/**
 * Interface for operations on a service for a Source Configuration Edit Copy
 * 
 * @author rahul3983
 *
 */
public interface SourceConfigEditCopyService {

	/**
	 * finds the matching configuration model object with the given name
	 * 
	 * @param name - name of the configuration
	 * @return - configuration model object
	 */
	SourceConfigModel get(String name);

	/**
	 * add the configuration model object
	 * 
	 * @param model - model object
	 * @return - configuration model object
	 */
	SourceConfigModel add(SourceConfigModel model);

	/**
	 * update the configuration model object
	 * 
	 * @param model - model object
	 * @return - configuration model object
	 */
	SourceConfigModel update(SourceConfigModel model);

	/**
	 * update a status of the matching configuration model object with the given
	 * status and name
	 * 
	 * @param status - status of the configuration
	 * @param name   - name of the configuration
	 * @return - status of the configuration
	 */
	String updateStatus(EditStatus status, String name,String remarks);

	/**
	 * find the matching edit copy entity object with the given name
	 * 
	 * @param name - name of the configuration
	 * @return - edit copy entity
	 */
	SourceConfigEditCopyEntity getEntity(String name);

	/**
	 * Call to verify source configuration edit copy exist with the given name
	 * 
	 * @param name - name of the configuration
	 * @return - true or false value if Source configuration Edit Copy name matching
	 */
	boolean isEditCopyExists(String name);

	/**
	 * save the matching configuration entity object
	 * 
	 * @param entity - entity object
	 * @return - entity object
	 */
	SourceConfigEditCopyEntity save(SourceConfigEditCopyEntity entity);

	/**
	 * delete the matching configuration entity object
	 * 
	 * @param editCopyEntity - entity object
	 */
	void delete(SourceConfigEditCopyEntity editCopyEntity);

	/**
	 * get all the matching configuration entity object with the given entity id
	 * 
	 * @param entityId - entity id of the configuration
	 * @return - List of source configuration objects
	 */
	List<ConfigSummary> getAll(String entityId);
	
	List<SourceConfigModel> getConfigByStatus(String status);

}
