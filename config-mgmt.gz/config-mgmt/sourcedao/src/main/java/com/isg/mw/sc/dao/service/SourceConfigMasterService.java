package com.isg.mw.sc.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;

/**
 * Interface for operations on a service for a Source Configuration Master
 * 
 * @author prasad_t026
 *
 */
public interface SourceConfigMasterService {

	/**
	 * finds the matching configuration model object with the given name
	 * 
	 * @param name - name of the configuration
	 * @return -configuration model objects
	 */
	SourceConfigModel get(String name);

	/**
	 * add the configuration model object
	 * 
	 * @param model - model object
	 * @return - configuration model object
	 */
	public SourceConfigModel add(SourceConfigModel model);

	/**
	 * update the configuration model object
	 * 
	 * @param model - model object
	 * @return - configuration model object
	 */
	public SourceConfigModel update(SourceConfigModel model);

	/**
	 * update a status of the matching configuration model object with the given
	 * status and name
	 * 
	 * @param status - status of the configuration
	 * @param name   - name of the configuration
	 * @return - status of the configuration
	 */
	public ConfigStatus updateStatus(String name, ConfigStatus status);

	/**
	 * get all active and unlocked configuration model object
	 * 
	 * @return - List of source configuration objects
	 */
	List<SourceConfigModel> getAll();

	/**
	 * lock the matching configuration model object with the given name and
	 * LockedState
	 * 
	 * @param name - name of the configuration
	 * @param ls   - lockedState of the configuration
	 * @return - lockedState of the configuration
	 */
	LockedState lock(String name, LockedState ls);

	/**
	 * finds the matching configuration entity object with the given name
	 * 
	 * @param name - name of the configuration
	 * @return - configuration model object
	 */
	SourceConfigMasterEntity getEntity(String name);

	/**
	 * save the matching configuration entity object
	 * 
	 * @param entity - entity object
	 * @return - entity object
	 */
	SourceConfigMasterEntity save(SourceConfigMasterEntity entity);

	/**
	 * finds the matching configuration entity object with the given name and
	 * entityId
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @return - entity object
	 */
	SourceConfigMasterEntity get(String name, String entityId);

	/**
	 * get all the matching configuration entity object with the given entity id
	 * 
	 * @param entityId - entity id of the configuration
	 * @return - List of source configuration objects
	 */
	List<ConfigSummary> getAll(String entityId);

	SourceConfigModel getSource(Long id, LockedState ls, ConfigStatus status);
	
	List<SourceConfigModel> getConfigByStatus(String status);

    List<SourceConfigModel> getAllByEntity(String entityId);
}
