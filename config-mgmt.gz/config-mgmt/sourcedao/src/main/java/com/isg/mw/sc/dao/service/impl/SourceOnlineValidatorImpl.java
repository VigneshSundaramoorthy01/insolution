package com.isg.mw.sc.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.sc.dao.constants.SourceDaoMsgKeys;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.repository.SourceConfigEditCopyRepository;
import com.isg.mw.sc.dao.repository.SourceConfigMasterRepository;
import com.isg.mw.sc.dao.service.SourceOnlineValidator;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;

/**
 * Class which implements {@link SourceOnlineValidator}
 * 
 * @author prasad_t026
 *
 */
@Service("sourceOnlineValidator")
public class SourceOnlineValidatorImpl implements SourceOnlineValidator {

	@Autowired
	private SourceConfigMasterRepository configMasterRepository;

	@Autowired
	private SourceConfigEditCopyRepository sourceConfigEditCopyRepository;

	@Autowired
	private TargetConfigMasterService targetConfigMasterService;

	@Override
	public boolean isSourceExists(String name) {
		return configMasterRepository.isSourceConfigExists(name);
	}

	@Override
	public boolean isSourceUnlocked(String name) {
		return configMasterRepository.isSourceConfigExists(name, LockedState.Unlocked);
	}

	@Override
	public boolean isSourceEditCopyExists(String name) {
		return sourceConfigEditCopyRepository.isSourceConfigExists(name);
	}

	@Override
	public void add(SourceConfigModel model) {

		if (getEditCopyEntity(model.getName()) != null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_ALREADY_EXIST_WITH_NAME, model.getName());
		}
		if (getMasterEntity(model.getName()) != null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_ALREADY_EXIST_WITH_NAME, model.getName());
		}
		verifyPortandUriWithEditCopy(null, model.getPortOrUri());

		verifyPortandUriWithMaster(null, model.getPortOrUri());

		List<String> targets = targetConfigMasterService.getTargets(model.getEntityId());
		if (model.getDefaultTarget() != null) {
			verifyIsValidTarget(model.getDefaultTarget(), targets);
		}

		String[] prefs = model.getTargetPreferences();
		if (prefs != null && prefs.length > 0) {
			for (String pref : prefs) {
				verifyIsValidTarget(pref, targets);
			}
		}

	}

	@Override
	public void modify(SourceConfigModel model) {

		checkIsUnLocked(model.getName());

		SourceConfigEditCopyEntity editCopy = getEditCopyEntity(model.getName());
		if (editCopy == null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_NOT_EXISTS_WITH_NAME, model.getName());
		} else {
			if (editCopy.getStatus() == EditStatus.Submitted) {
				throw new ValidationException(SourceDaoMsgKeys.SC_ALREADY_EXIST_IN_SUBMITTED_STATE, editCopy.getName());
			}
			if (!editCopy.getEntityId().equals(model.getEntityId())) {
				throw new ValidationException(SourceDaoMsgKeys.SC_ENTITYID_SHOULD_NOT_BE_CHANGE);
			}
			verifyPortandUriWithEditCopy(model.getName(), model.getPortOrUri());

			verifyPortandUriWithMaster(model.getName(), model.getPortOrUri());

			List<String> targets = targetConfigMasterService.getTargets(model.getEntityId());
			if (model.getDefaultTarget() != null) {
				verifyIsValidTarget(model.getDefaultTarget(), targets);
			}

			String[] prefs = model.getTargetPreferences();
			if (prefs != null && prefs.length > 0) {
				for (String pref : prefs) {
					verifyIsValidTarget(pref, targets);
				}
			}
		}
	}

	@Override
	public void submit(String name) {

		checkIsUnLocked(name);

		SourceConfigEditCopyEntity editCopy = getEditCopyEntity(name);
		if (editCopy == null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_NOT_EXISTS_WITH_NAME, name);
		} else if (editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(SourceDaoMsgKeys.SC_STATUS_SHOULD_NOT_BE_SUBMITTED);
		}
		if (editCopy.getStatus() == EditStatus.Rejected) {
			throw new ValidationException(SourceDaoMsgKeys.STATUS_SOURCE_IS_MANDATORY);
		}
	}

	@Override
	public void verify(String name, boolean approved) {

		checkIsUnLocked(name);
		SourceConfigEditCopyEntity editCopy = getEditCopyEntity(name);
		if (editCopy == null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_NOT_EXISTS_WITH_NAME, name);
		}
		if (EditStatus.Submitted != editCopy.getStatus()) {
			throw new ValidationException(SourceDaoMsgKeys.SC_STATUS_SHOULD_BE_SUBMITTED);
		}

	}

	@Override
	public void lock(String name, LockedState lockedState) {

		SourceConfigMasterEntity master = getMasterEntity(name);
		if (master == null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_NOT_EXISTS_WITH_NAME, name);
		} else if (lockedState.equals(master.getLockedState())) {
			throw new ValidationException(SourceDaoMsgKeys.SC_LOCKED_STATE_SHOULD_NOT_BE_SAME);
		}

	}

	@Override
	public void update(String name, String status) {

		checkIsUnLocked(name);
		SourceConfigMasterEntity master = getMasterEntity(name);
		if (master == null) {
			throw new ValidationException(SourceDaoMsgKeys.SC_NOT_EXISTS_WITH_NAME, name);
		}
		if (status.equals(master.getStatus().name())) {
			throw new ValidationException(SourceDaoMsgKeys.SC_STATUS_SHOULD_NOT_BE_SAME);
		}
		if (ConfigStatus.getStatus(status) == null && !status.equals(EditStatus.Inprogress.name())) {
			throw new ValidationException(SourceDaoMsgKeys.SC_STATUS_IS_INVALID, status);
		}
		if (status.equals(EditStatus.Inprogress.name())) {
			SourceConfigEditCopyEntity editCopy = getEditCopyEntity(name);
			if (editCopy != null && editCopy.getStatus() != EditStatus.Inprogress) {
				throw new ValidationException(SourceDaoMsgKeys.SC_CONFIGURATION_EXISTS_IN_SUBMITTED_STATE, status);
			}
		}

	}

	/**
	 * Check master object is unlock
	 * 
	 * @param name - name of the configuration object
	 */
	private void checkIsUnLocked(String name) {

		SourceConfigMasterEntity master = getMasterEntity(name);
		if (master != null && master.getLockedState() == LockedState.Locked) {
			throw new ValidationException(SourceDaoMsgKeys.SC_LOCK_CANT_CHANGE, master.getName());
		}

	}

	/**
	 * Verify valid target
	 * 
	 * @param target- target of the configuration object
	 * @param targets - list of targets present
	 */
	private void verifyIsValidTarget(String target, List<String> targets) {

		if (!targets.contains(target)) {
			throw new ValidationException(
					SourceDaoMsgKeys.SC_CANT_ALLOW_TO_SET_LOCKED_OR_NON_EXISTING_TARGET_CONFIGURATION, target);
		}

	}

	/**
	 * Verify port and URI in master
	 * 
	 * @param name - name of the configuration object
	 * @param uri  - URI of the configuration object
	 */
	private void verifyPortandUriWithMaster(String name, String uri) {

		if (uri != null) {
			List<SourceConfigMasterEntity> list = configMasterRepository.findByPortOrUri(uri);
			if (!list.isEmpty() && !list.get(0).getName().equals(name)) {
				throw new ValidationException(SourceDaoMsgKeys.SC_URI_ALREADY_IN_USE, uri);

			}
		}

	}

	/**
	 * Verify port and URI in edit copy
	 * 
	 * @param name - name of the configuration object
	 * @param uri  - URI of the configuration object
	 */
	private void verifyPortandUriWithEditCopy(String name, String uri) {

		if (uri != null) {
			List<SourceConfigEditCopyEntity> list = sourceConfigEditCopyRepository.findByPortOrUri(uri);
			if (!list.isEmpty() && !list.get(0).getName().equals(name)) {
				throw new ValidationException(SourceDaoMsgKeys.SC_URI_ALREADY_IN_USE, uri);

			}
		}

	}

	/**
	 * Get master Entity based on name
	 * 
	 * @param name - name of the configuration object
	 * @return - SourceConfigMasterEntity object
	 */
	private SourceConfigMasterEntity getMasterEntity(String name) {

		List<SourceConfigMasterEntity> list = configMasterRepository.findByName(name);
		if (!list.isEmpty()) {
			return list.get(0);
		}
		return null;

	}

	/**
	 * Get edit copy entity based on name
	 * 
	 * @param name - name of the configuration object
	 * @return - SourceConfigEditCopyEntity object
	 */
	private SourceConfigEditCopyEntity getEditCopyEntity(String name) {

		List<SourceConfigEditCopyEntity> list = sourceConfigEditCopyRepository.findByName(name);
		if (!list.isEmpty()) {
			return list.get(0);
		}
		return null;

	}

	@Override
	public boolean isSourceConfigEditCopyEntityIdExists(String entityId) {
		return sourceConfigEditCopyRepository.isSourceConfigEntityIdExists(entityId);
	}

	@Override
	public boolean isSourceConfigMasterEntityIdExists(String entityId) {
		return configMasterRepository.isSourceConfigEntityIdExists(entityId);
	}

}
