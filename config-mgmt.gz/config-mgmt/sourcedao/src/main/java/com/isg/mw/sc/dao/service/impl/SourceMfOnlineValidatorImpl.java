package com.isg.mw.sc.dao.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.mf.dao.service.MfPrivateOnlineValidator;
import com.isg.mw.sc.dao.constants.SourceMFDaoMsgKeys;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.repository.SourceConfigEditCopyRepository;
import com.isg.mw.sc.dao.repository.SourceConfigMasterRepository;
import com.isg.mw.sc.dao.service.SourceMfOnlineValidator;

/**
 * Class which implements {@link SourceMfOnlineValidator}
 * 
 * @author prasad_t026
 *
 */
@Service("sourceMfOnlineValidator")
public class SourceMfOnlineValidatorImpl implements SourceMfOnlineValidator {

	@Autowired
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Autowired
	private MfPrivateOnlineValidator mfPrivateOnlineValidator;

	@Autowired
	private SourceConfigEditCopyRepository sourceConfigEditCopyRepository;

	@Autowired
	private SourceConfigMasterRepository sourceConfigMasterRepository;

	@Override
	public Long addValidation(MessageFormatConfigModel model, String entityId, String name) {
		checkIsUnLocked(name, entityId);
		SourceConfigEditCopyEntity editCopy = getSourceEditCopyEntity(name);
		if (editCopy == null) {
			throw new ValidationException(SourceMFDaoMsgKeys.SOURCE_EDIT_COPY_NOT_EXISTS, name);
		}
		if (editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(SourceMFDaoMsgKeys.SOURCE_STATUS_IS_SUBMITTED_STATUS, editCopy.getName());
		}
		model.setOwnerId(editCopy.getId());
		mfPrivateOnlineValidator.addValidation(model);
		return editCopy.getId();
	}

	@Override
	public void modifyValidation(MessageFormatConfigModel model) {

		MessageFormatConfigEditCopyEntity mfec = messageFormatConfigEditCopyService.getById(model.getId());
		if (mfec == null) {
			throw new ValidationException(SourceMFDaoMsgKeys.MESSAGE_FORMAT_NOT_EXISTS, model.getId());
		}
		SourceConfigEditCopyEntity editCopy = sourceConfigEditCopyRepository.findById(mfec.getOwnerId()).get();
		if (editCopy == null) {
			throw new ValidationException(SourceMFDaoMsgKeys.SOURCE_EDIT_COPY_NOT_EXISTS, mfec.getOwnerId());
		}
		if (editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(SourceMFDaoMsgKeys.SOURCE_STATUS_IS_SUBMITTED_STATUS, editCopy.getName());
		}
		checkIsUnLocked(editCopy.getName(), editCopy.getEntityId());
		model.setOwnerType(OwnerType.TARGET);
		model.setOwnerId(editCopy.getId());
		mfPrivateOnlineValidator.modifyValidation(model);
	}

	@Override
	public void deleteValidation(Long id) {
		MessageFormatConfigEditCopyEntity mfec = messageFormatConfigEditCopyService.getById(id);
		if (mfec == null) {
			throw new ValidationException(SourceMFDaoMsgKeys.MESSAGE_FORMAT_NOT_EXISTS, id);
		}
		SourceConfigEditCopyEntity editCopy = sourceConfigEditCopyRepository.findById(mfec.getOwnerId()).get();
		if (editCopy == null) {
			throw new ValidationException(SourceMFDaoMsgKeys.SOURCE_EDIT_COPY_NOT_EXISTS, mfec.getOwnerId());
		}
		if (editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(SourceMFDaoMsgKeys.SOURCE_STATUS_IS_SUBMITTED_STATUS, editCopy.getName());
		}
		checkIsUnLocked(editCopy.getName(), editCopy.getEntityId());
	}

	/**
	 * Check master entity is Unlock
	 * 
	 * @param name     - name of configuration model
	 * @param entityId - entityId of configuration mode
	 */
	private void checkIsUnLocked(String name, String entityId) {

		SourceConfigMasterEntity master = getSourceMasterEntity(name);
		if (master != null && master.getLockedState() == LockedState.Locked) {
			throw new ValidationException(SourceMFDaoMsgKeys.SYSTEM_WONT_ALLOW_TO_MODIFY);
		}

	}

	/**
	 * Get SourceEditCopyEntity object
	 * 
	 * @param name - name of configuration model
	 * @return - SourceConfigEditCopyEntity object
	 */
	private SourceConfigEditCopyEntity getSourceEditCopyEntity(String name) {

		List<SourceConfigEditCopyEntity> list = sourceConfigEditCopyRepository.findByName(name);
		SourceConfigEditCopyEntity entity = null;
		if (!list.isEmpty()) {
			entity = list.get(0);
		}
		return entity;

	}

	/**
	 * Get SourceMasterEntity object
	 * 
	 * @param name - name of configuration model
	 * @return - SourceConfigMasterEntity object
	 */
	private SourceConfigMasterEntity getSourceMasterEntity(String name) {

		List<SourceConfigMasterEntity> list = sourceConfigMasterRepository.findByName(name);
		SourceConfigMasterEntity entity = null;
		if (!list.isEmpty()) {
			entity = list.get(0);
		}
		return entity;

	}

}