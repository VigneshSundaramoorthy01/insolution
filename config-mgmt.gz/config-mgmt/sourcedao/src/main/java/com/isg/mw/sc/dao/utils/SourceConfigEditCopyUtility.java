package com.isg.mw.sc.dao.utils;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;

/**
 * Utility class for source edit copy
 * 
 * @author prasad_t026
 *
 */
public class SourceConfigEditCopyUtility {

	/**
	 * Default constructor It should not access from out side
	 * 
	 */
	private SourceConfigEditCopyUtility() {

	}

	/**
	 * convert entity to model object
	 * 
	 * @param entity - entity object
	 * @return - source configuration model object
	 */
	public static SourceConfigModel getSourceModel(SourceConfigEditCopyEntity entity) {

		SourceConfigModel model = new SourceConfigModel();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDefaultTarget(entity.getDefaultTarget());
		model.setTargetPreferences(IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class));
		model.setConnectionType(entity.getConnectionType());
		model.setPortOrUri(entity.getPortOrUri());
		model.setCreatedAt(entity.getCreatedAt());
		model.setUpdatedAt(entity.getUpdatedAt());
		model.setStatus(getString(entity.getStatus()));
		model.setMerchantValidation(entity.isMerchantValidation());
		model.setIssuerBinValidation(entity.isIssuerBinValidation());
		model.setAcquirerBinValidation(entity.isAcquirerBinValidation());
		model.setDataSecurityModule(entity.isDataSecurityModule());
		model.setMsgTransfomation(entity.isMsgTransformation());
		model.setTxnLogging(entity.getTxnLogging());
		model.setCreatedBy(entity.getCreatedBy());
		model.setUpdatedBy(entity.getUpdatedBy());
		model.setEntityId(entity.getEntityId());
		model.setSourceType(entity.getSourceType());
		model.setRequestTimeout(entity.getRequestTimeout());
		model.setPreAuthPerLimit(entity.getPreAuthPerLimit());
		model.setPreAuthTimePeriod(entity.getPreAuthTimePeriod());
		model.setSourceProcessor(entity.getSourceProcessor());
		model.setSftp_params(SourceCommonUtil.convertStringToSourceConnectionList(entity.getSftpParams()));
		model.setRemarks(entity.getRemarks());
		model.setAdditionalData(SourceCommonUtil.stringToSourceAdditionalData(entity.getAdditionalData()));
		return model;
		
	}

	private static String getString(EditStatus status) {
		return status + "";
	}

	/**
	 * convert model to entity object
	 * 
	 * @param model - model object
	 * @return - source configuration edit copy entity object
	 */
	public static SourceConfigEditCopyEntity getSourceEntity(SourceConfigModel model) {

		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setName(model.getName());
		entity.setDefaultTarget(model.getDefaultTarget());
		entity.setTargetPreferences(IsgJsonUtils.getJsonString(model.getTargetPreferences()));
		entity.setConnectionType(model.getConnectionType());
		entity.setPortOrUri(model.getPortOrUri());
		entity.setStatus(EditStatus.Inprogress);
		entity.setMerchantValidation(model.isMerchantValidation());
		entity.setIssuerBinValidation(model.isIssuerBinValidation());
		entity.setAcquirerBinValidation(model.isAcquirerBinValidation());
		entity.setDataSecurityModule(model.isDataSecurityModule());
		entity.setMsgTransformation(model.isMsgTransfomation());
		entity.setTxnLogging(model.getTxnLogging());
		entity.setEntityId(model.getEntityId());
		entity.setSourceType(model.getSourceType());
		entity.setRequestTimeout(model.getRequestTimeout());
		entity.setPreAuthPerLimit(model.getPreAuthPerLimit());
		entity.setPreAuthTimePeriod(model.getPreAuthTimePeriod());
		entity.setSourceProcessor(model.getSourceProcessor());
		entity.setSftpParams(SourceCommonUtil.convertSourceConnectionListToString(model.getSftp_params()));
		entity.setRemarks(model.getRemarks());
		entity.setAdditionalData(SourceCommonUtil.sourceAdditionalDataToString(model.getAdditionalData()));
		return entity;

	}

	/**
	 * Update entity object
	 * 
	 * @param model  - source configuration model object
	 * @param entity - source configuration edit copy entity object
	 */
	public static void updateSourceEntity(SourceConfigModel model, SourceConfigEditCopyEntity entity) {

		entity.setDefaultTarget(model.getDefaultTarget());
		entity.setTargetPreferences(IsgJsonUtils.getJsonString(model.getTargetPreferences()));
		entity.setConnectionType(model.getConnectionType());
		entity.setPortOrUri(model.getPortOrUri());
		entity.setMerchantValidation(model.isMerchantValidation());
		entity.setIssuerBinValidation(model.isIssuerBinValidation());
		entity.setAcquirerBinValidation(model.isAcquirerBinValidation());
		entity.setDataSecurityModule(model.isDataSecurityModule());
		entity.setMsgTransformation(model.isMsgTransfomation());
		entity.setTxnLogging(model.getTxnLogging());
		entity.setSourceType(model.getSourceType());
		entity.setRequestTimeout(model.getRequestTimeout());
		entity.setPreAuthPerLimit(model.getPreAuthPerLimit());
		entity.setPreAuthTimePeriod(model.getPreAuthTimePeriod());
		entity.setSftpParams(SourceCommonUtil.convertSourceConnectionListToString(model.getSftp_params()));
		entity.setSourceProcessor(model.getSourceProcessor());
		entity.setAdditionalData(SourceCommonUtil.sourceAdditionalDataToString(model.getAdditionalData()));

	}

}
