package com.isg.mw.sc.dao.service;

import java.util.List;

import com.isg.mw.core.model.mf.MessageFormatConfigModel;

/**
 * Interface for operations on a service for a Source Configuration Edit
 * Copy
 * @author prasad_t026
 *
 */
public interface SourceMfEditCopyService {
	
	/**
	 * get list of the matching configuration model object with the given entity id and
	 * name
	 * 
	 * @param entityId - entity id of the configuration
	 * @param name     - name id of the configuration
	 * @return - List of configuration objects
	 */
	List<MessageFormatConfigModel> getList(String entityId, String name);

}
