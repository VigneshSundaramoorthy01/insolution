package com.isg.mw.sc.dao.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.sc.SourceAdditionalData;
import com.isg.mw.core.model.sc.SourceSftpParams;
import com.isg.mw.core.utils.IsgJsonUtils;

/**
 * Utility class for source
 * 
 * @author rahul3983
 *
 */
public class SourceCommonUtil {
	/**
	 * Default constructor It should not access from out side
	 */
	private SourceCommonUtil() {
	}

	/**
	 * Utility to convert string to array of merchant preference
	 * 
	 * @param prefsStr - string value of merchant preference
	 * @return - array of merchant preference
	 */
	public static MerchantPreference[] convertStringToTargetConnectionList(String prefsStr) {

		if (prefsStr != null) {
			MerchantPreference[] cons = IsgJsonUtils.getObjectFromJsonString(prefsStr, MerchantPreference[].class);
			if (cons != null) {
				return cons;
			}
		}
		return new MerchantPreference[0];
	}

	/**
	 * Utility to convert array of merchant preference to string
	 * 
	 * @param prefs - array of merchant preference
	 * @return - string value of merchant preference
	 */
	public static String convertTargetConnectionListToString(MerchantPreference[] prefs) {
		if (prefs == null) {
			return "[]";
		}
		return IsgJsonUtils.getJsonString(prefs);
	}
	
	/**
	 * Converts string to Source connection list
	 * 
	 * 
	 * @param connectionStr - string sftp_params
	 * @return connections - List of source sftp_params
	 */
	public static List<SourceSftpParams> convertStringToSourceConnectionList(String sftp_params) {
		SourceSftpParams[] cons = IsgJsonUtils.getObjectFromJsonString(sftp_params, SourceSftpParams[].class);
		List<SourceSftpParams> connections = new ArrayList<SourceSftpParams>();
		if (cons != null) {
			connections = Arrays.asList(cons);
		}
		return connections;
	}
	
	/**
	 * Converts source sftp_params list into string
	 * 
	 * @param connections -  List of source sftp_params
	 * @return String sftp_params
	 */
	public static String convertSourceConnectionListToString(List<SourceSftpParams> sftp_params) {
		if (sftp_params == null || sftp_params.isEmpty()) {
			return "[]";
		}
		return IsgJsonUtils.getJsonString(sftp_params);
	}
	
	public static SourceAdditionalData stringToSourceAdditionalData(String sourceAdditionalData) {
		SourceAdditionalData additionalData = null;
		if (!StringUtils.isBlank(sourceAdditionalData)) {
			additionalData = IsgJsonUtils.getObjectFromJsonString(sourceAdditionalData, SourceAdditionalData.class);
		}
		return additionalData;
	}

	public static String sourceAdditionalDataToString(SourceAdditionalData sourceAdditionalData) {
		if (sourceAdditionalData != null) {
			return IsgJsonUtils.getJsonString(sourceAdditionalData);
		}
		return null;
	}

}
