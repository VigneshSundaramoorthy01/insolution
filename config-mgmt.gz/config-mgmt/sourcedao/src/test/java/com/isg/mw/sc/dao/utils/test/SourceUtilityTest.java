package com.isg.mw.sc.dao.utils.test;



import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.utils.CoreUtils;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.sc.dao.utils.SourceUtility;

public class SourceUtilityTest {
	public static String[] demoRecord() {

		String[] merPrefArr = { "tcm1", "tcm2" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}
	@Test
	public void getupdateMasterTest() {

		SourceConfigEditCopyEntity editCopyEntity = getSCEditCopyEntity();

		SourceConfigMasterEntity masterEntity = getSCMasterEntity();
		SourceUtility.updateMaster(masterEntity, editCopyEntity);

		assertEquals(editCopyEntity.getId(), masterEntity.getId());
		assertEquals(editCopyEntity.getName(), masterEntity.getName());
		assertEquals(editCopyEntity.getTargetPreferences(), masterEntity.getTargetPreferences());
		assertEquals(editCopyEntity.getConnectionType(), masterEntity.getConnectionType());
        assertEquals(editCopyEntity.getRequestTimeout(), masterEntity.getRequestTimeout());
	}

	@Test
	public void updateEditCopyTest() {
		SourceConfigMasterEntity masterEntity = getSCMasterEntity();
		SourceConfigEditCopyEntity editCopyEntity = getSCEditCopyEntity();

		SourceUtility.updateEditCopy(masterEntity, editCopyEntity);
		assertEquals(editCopyEntity.getId(), masterEntity.getId());
		assertEquals(editCopyEntity.getName(), masterEntity.getName());
		assertEquals(editCopyEntity.getTargetPreferences(), masterEntity.getTargetPreferences());
		assertEquals(editCopyEntity.getConnectionType(), masterEntity.getConnectionType());
		assertEquals(editCopyEntity.getRequestTimeout(), masterEntity.getRequestTimeout());
		
	}

	@Test
	public void createMasterTest() {
		SourceConfigEditCopyEntity editCopyEntity = getSCEditCopyEntity();
		SourceConfigMasterEntity masterEntity = SourceUtility.createMaster(editCopyEntity);
		assertEquals(editCopyEntity.getName(), masterEntity.getName());
		assertEquals(editCopyEntity.getEntityId(), masterEntity.getEntityId());
		assertEquals(ConfigStatus.Active, masterEntity.getStatus());
		assertEquals(LockedState.Unlocked, masterEntity.getLockedState());
		assertEquals(editCopyEntity.getRequestTimeout(), masterEntity.getRequestTimeout());
	}

	private SourceConfigMasterEntity getSCMasterEntity() {
		SourceConfigMasterEntity masterEntity = new SourceConfigMasterEntity();
		masterEntity.setId(1L);
		masterEntity.setName("SCM1");
		masterEntity.setTargetPreferences(demoRecord().toString());
		masterEntity.setConnectionType(ConnectionType.ISO);
		masterEntity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		masterEntity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		masterEntity.setStatus(ConfigStatus.Active);
		masterEntity.setLockedState(LockedState.Unlocked);
		masterEntity.setRequestTimeout(8900);
		return masterEntity;
	}

	private SourceConfigEditCopyEntity getSCEditCopyEntity() {
		SourceConfigEditCopyEntity editCopyEntity = new SourceConfigEditCopyEntity();
		editCopyEntity.setId(1L);
		editCopyEntity.setName("SCM1");
		editCopyEntity.setTargetPreferences(CoreUtils.arrayToString(demoRecord()));
		editCopyEntity.setConnectionType(ConnectionType.ISO);
		editCopyEntity.setPortOrUri("9093");
		editCopyEntity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		editCopyEntity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		editCopyEntity.setStatus(EditStatus.Inprogress);
		editCopyEntity.setRequestTimeout(89000);
		return editCopyEntity;
	}

}
