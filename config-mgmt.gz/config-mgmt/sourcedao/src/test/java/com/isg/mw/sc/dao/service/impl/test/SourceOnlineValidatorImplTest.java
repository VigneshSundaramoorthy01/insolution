package com.isg.mw.sc.dao.service.impl.test;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.repository.SourceConfigEditCopyRepository;
import com.isg.mw.sc.dao.repository.SourceConfigMasterRepository;
import com.isg.mw.sc.dao.service.impl.SourceOnlineValidatorImpl;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;

public class SourceOnlineValidatorImplTest {
	@Mock
	private SourceConfigMasterRepository configMasterRepository;

	@Mock
	private SourceConfigEditCopyRepository sourceConfigEditCopyRepository;

	@Mock
	private TargetConfigMasterService targetConfigMasterService;

	@InjectMocks
	SourceOnlineValidatorImpl sourceOnlineValidator;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}



	// @Test
	public void addNT01() {
		String errorMsg = null;
		Object errorArgs[] = null;
		String name = "SCM1";
		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, name, "123"));
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));
			sourceOnlineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.dao.already.exist.with.name");
		assertEquals(errorArgs[0], name);

	}

	// @Test
	public void addNT02() {
		String errorMsg = null;
		Object errorArgs[] = null;
		String name = "SCM1";
		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));
			sourceOnlineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.dao.already.exist.with.name");
		assertEquals(errorArgs[0], name);

	}

	// @Test
	public void addNT03() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByPortOrUri(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "123"));
			sourceOnlineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.uri.already.in.use");

	}

	// @Test
	public void addNT04() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByPortOrUri(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));
			sourceOnlineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.uri.already.in.use");

	}

	// @Test
	public void addNT05() {
		String errorMsg = null;

		try {
			Mockito.when(targetConfigMasterService.getTargets(Mockito.any())).thenReturn(getTCStringNT());
			sourceOnlineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.cant.allow.to.set.lock.or.non.existing.target");

	}


	
	// @Test
	public void addPT01() {
		String errorMsg = null;
		try {
			Mockito.when(targetConfigMasterService.getTargets(Mockito.any())).thenReturn(getTCStringPT());
			sourceOnlineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);

	}
	

	// @Test
	public void modifyNT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Locked));
			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.lock.cant.change");

	}

	// @Test
	public void modifyNT02() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.name.not.exists");

	}

	// @Test
	public void modifyNT03() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Submitted, "SCM1", "123"));
			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.already.exist.in.submitted.state");

	}

	// @Test
	public void modifyNT04() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "123"));
			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.entityid.should.not.change");

	}

	// @Test
	public void modifyNT05() {
		String errorMsg = null;

		try {

			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "1234"));
			Mockito.when(sourceConfigEditCopyRepository.findByPortOrUri(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM2", "1234"));
			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.uri.already.in.use");

	}

	// @Test
	public void modifyNT06() {
		String errorMsg = null;

		try {

			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "1234"));
			Mockito.when(configMasterRepository.findByPortOrUri(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM2", LockedState.Unlocked));
			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.uri.already.in.use");

	}

	// @Test
	public void modifyNT07() {
		String errorMsg = null;

		try {

			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "1234"));
			Mockito.when(targetConfigMasterService.getTargets(Mockito.any())).thenReturn(getTCStringNT());

			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.cant.allow.to.set.lock.or.non.existing.target");

	}

	// @Test
	public void modifyPT01() {
		String errorMsg = null;

		try {

			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "1234"));
			Mockito.when(targetConfigMasterService.getTargets(Mockito.any())).thenReturn(getTCStringPT());

			sourceOnlineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);

	}

	// @Test
	public void submitNT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Locked));
			sourceOnlineValidator.submit("SCM1");

		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.lock.cant.change");

	}

	// @Test
	public void submitNT02() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
			sourceOnlineValidator.submit("SCM1");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.name.not.exists");

	}

	// @Test
	public void submitNT03() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Submitted, "SCM1", "123"));
			sourceOnlineValidator.submit("SCM1");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.status.should.not.be.submitted");

	}

	// @Test
	public void submitPT01() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "123"));
			sourceOnlineValidator.submit("SCM1");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);

	}

	// @Test
	public void verifyNT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Locked));
			sourceOnlineValidator.verify("SCM1", true);

		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.lock.cant.change");

	}

	// @Test
	public void verifyNT02() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
			sourceOnlineValidator.verify("SCM1", true);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.name.not.exists");

	}

	// @Test
	public void verifyNT03() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "123"));
			sourceOnlineValidator.verify("SCM1", true);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.status.should.be.submitted");

	}

	// @Test
	public void verifyPT01() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Submitted, "SCM1", "123"));
			sourceOnlineValidator.verify("SCM1", true);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);

	}

	// @Test
	public void lockNT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(new ArrayList<SourceConfigMasterEntity>());
			sourceOnlineValidator.lock("SCM1", LockedState.Locked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.name.not.exists");

	}

	// @Test
	public void lockNT02() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Locked));
			sourceOnlineValidator.lock("SCM1", LockedState.Locked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.locked.state.should.not.be.same");

	}

	// @Test
	public void lockPT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Locked));
			sourceOnlineValidator.lock("SCM1", LockedState.Unlocked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);

	}

	// @Test
	public void updateNT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Locked));
			sourceOnlineValidator.update("SCM1", ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.lock.cant.change");

	}

	// @Test
	public void updateNT02() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(new ArrayList<SourceConfigMasterEntity>());
			sourceOnlineValidator.update("SCM1", ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.name.not.exists");

	}

	// @Test
	public void updateNT03() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));
			sourceOnlineValidator.update("SCM1", ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.status.should.not.be.same");

	}

	// @Test
	public void updateNT04() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));

			sourceOnlineValidator.update("SCM1", "Inprogre");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.status.is.invalid");

	}

	// @Test
	public void updateNT05() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Submitted, "SCM1", "123"));

			sourceOnlineValidator.update("SCM1", EditStatus.Inprogress.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.configuration.exists.in.submitted.state");

	}

	// @Test
	public void updatePT01() {
		String errorMsg = null;

		try {
			Mockito.when(configMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, "SCM1", LockedState.Unlocked));
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
			.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress, "SCM1", "123"));
		
			sourceOnlineValidator.update("SCM1", EditStatus.Inprogress.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);
	}
	
	// @Test
	public void isSourceExistsPT01() {
		Mockito.when(configMasterRepository.isSourceConfigExists(Mockito.any())).thenReturn(true);
		boolean sourceExists = sourceOnlineValidator.isSourceExists("SCM1");
		assertEquals(sourceExists, true);
	}
	
	// @Test
	public void isSourceUnlockedPT01() {
		Mockito.when(configMasterRepository.isSourceConfigExists(Mockito.any(),Mockito.any())).thenReturn(true);
		boolean unlock = sourceOnlineValidator.isSourceUnlocked("SCM1");
		assertEquals(unlock, true);
	}
	// @Test
	public void isSourceEditCopyExistsPT01() {
		Mockito.when(sourceConfigEditCopyRepository.isSourceConfigExists(Mockito.any())).thenReturn(true);
		boolean sourceExists = sourceOnlineValidator.isSourceEditCopyExists("SCM1");
		assertEquals(sourceExists, true);
	}
	
	// @Test
	public void isSourceConfigEditCopyEntityIdExistsPT01(){
		Mockito.when(sourceConfigEditCopyRepository.isSourceConfigEntityIdExists(Mockito.any())).thenReturn(true);
		boolean sourceExists = sourceOnlineValidator.isSourceConfigEditCopyEntityIdExists("SCM1");
		assertEquals(sourceExists, true);
	}
	
	// @Test
	public void isSourceConfigMasterEntityIdExistsPT01(){
		Mockito.when(configMasterRepository.isSourceConfigEntityIdExists(Mockito.any())).thenReturn(true);
		boolean sourceExists = sourceOnlineValidator.isSourceConfigMasterEntityIdExists("SCM1");
		assertEquals(sourceExists, true);
	}
	
	
	private List<SourceConfigModel> getSCModelList() {
		List<SourceConfigModel> list = new ArrayList<SourceConfigModel>();
		SourceConfigModel model = new SourceConfigModel();
		model.setId(123L);
		model.setEntityId("1234");
		model.setName("SCM1");
		model.setPortOrUri("8080");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(new String [] {"TCM1"});
		list.add(model);
		return list;
	}

	private List<SourceConfigEditCopyEntity> getSCEditCopyEntityList(EditStatus status, String name, String entityId) {
		List<SourceConfigEditCopyEntity> list = new ArrayList<SourceConfigEditCopyEntity>();
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(123L);
		entity.setEntityId(entityId);
		entity.setName(name);
		entity.setStatus(status);
		entity.setPortOrUri("8080");
		list.add(entity);
		return list;

	}

	private List<SourceConfigMasterEntity> getSCMasterEntityList(ConfigStatus status, String name, LockedState state) {
		List<SourceConfigMasterEntity> list = new ArrayList<SourceConfigMasterEntity>();
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setId(123L);
		entity.setName(name);
		entity.setStatus(status);
		entity.setPortOrUri("8080");
		entity.setLockedState(state);
		list.add(entity);
		return list;

	}

	private List<String> getTCStringNT() {
		List<String> list = new ArrayList<String>();
		String string = "TCM2";
		list.add(string);
		return list;
	}

	private List<String> getTCStringPT() {
		List<String> list = new ArrayList<String>();
		String string = "TCM1";
		list.add(string);
		return list;
	}
	public static String[] demoRecord() {

		String[] merPrefArr = { "TCM1", "TCM2" };
		return merPrefArr;
	}

}
