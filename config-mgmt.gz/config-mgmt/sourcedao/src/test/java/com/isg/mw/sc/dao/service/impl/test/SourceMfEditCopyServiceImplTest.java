package com.isg.mw.sc.dao.service.impl.test;



import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.service.impl.SourceMfEditCopyServiceImpl;

public class SourceMfEditCopyServiceImplTest {

	@Mock
	SourceConfigEditCopyService sourceConfigEditCopyService;

	@Mock
	MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@InjectMocks
	SourceMfEditCopyServiceImpl sourceMfEditCopyService;
	
	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getListPT01() {
		Mockito.when(sourceConfigEditCopyService.getEntity(Mockito.any())).thenReturn(getSCEditCopyEntity());
		List<MessageFormatConfigModel> list = sourceMfEditCopyService.getList("123L", "SCM1");
        assertNotNull(list);
	}
	@Test
	public void getListNT01() {
		Mockito.when(sourceConfigEditCopyService.getEntity(Mockito.any())).thenReturn(null);
		List<MessageFormatConfigModel> list = sourceMfEditCopyService.getList("123L", "SCM1");
        assertNull(list);
	}
	
	
	private SourceConfigEditCopyEntity getSCEditCopyEntity() {
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(123L);
		entity.setName("SCM1");
		entity.setStatus(EditStatus.Inprogress);
		return entity;
	}


	
}
