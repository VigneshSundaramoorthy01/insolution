package com.isg.mw.sc.dao.service.impl.test;



import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sc.dao.service.impl.SourceMfMasterServiceImpl;

public class SourceMfMasterServiceImplTest {

	@Mock
	SourceConfigMasterService sourceConfigMasterService;

	@Mock
	MessageFormatConfigMasterService messageFormatConfigMasterService;

	@InjectMocks
	SourceMfMasterServiceImpl sourceMfMasterService;
	
	
	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getListPT01() {
		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any())).thenReturn(getSCMasterEntity());
		List<MessageFormatConfigModel> list = sourceMfMasterService.getList("123L", "SCM1");
        assertNotNull(list);
	}
	@Test
	public void getListNT01() {
		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any())).thenReturn(null);
		List<MessageFormatConfigModel> list = sourceMfMasterService.getList("123L", "SCM1");
        assertNull(list);
	}
	
	
	private SourceConfigMasterEntity getSCMasterEntity() {
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setId(123L);
		entity.setName("SCM1");
		entity.setStatus(ConfigStatus.Active);
		return entity;
	}


}
