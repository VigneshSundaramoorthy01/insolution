package com.isg.mw.sc.dao.service.impl.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.mf.dao.service.impl.MessageFormatConfigEditCopyServiceImpl;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.repository.SourceConfigEditCopyRepository;
import com.isg.mw.sc.dao.service.impl.SourceConfigEditCopySeviceImpl;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;

public class SourceConfigEditCopySeviceImplTest {
	@Mock
	private SourceConfigEditCopyRepository configEditCopyRepository;

	@InjectMocks
	private SourceConfigEditCopySeviceImpl configEditCopyService;

	@Mock
	private MessageFormatConfigEditCopyServiceImpl messageFormatConfigEditCopyService;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getPT01() {
		Mockito.when(configEditCopyRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "master"));
		Mockito.when(messageFormatConfigEditCopyService.getByOwnerAndOwnerType(1L, OwnerType.SOURCE))
				.thenReturn(getMFConfigModel());
		SourceConfigModel model = configEditCopyService.get("SCM1");
		assertNotNull(model);
	}

	@Test
	public void getNT01() {
		Mockito.when(configEditCopyRepository.findByName(Mockito.anyString()))
				.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
		SourceConfigModel model = configEditCopyService.get("SCM1");
		assertNull(model);
	}

	@Test
	public void addPT01() {
		Mockito.when(configEditCopyRepository.save(Mockito.any()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1").get(0));
		SourceConfigModel model = configEditCopyService.add(getSCModel());
		assertNotNull(model.getId());
		assertNotNull(model.getName());
	}

	@Test
	public void updatePT01() {

		Mockito.when(configEditCopyRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1"));
		SourceConfigModel model = getSCModel();
		List<SourceConfigEditCopyEntity> macConfigEntity = getSCEditCopyEntity(EditStatus.Inprogress, "SCM1");
		Mockito.when(configEditCopyRepository.save(Mockito.any())).thenReturn(macConfigEntity.get(0));
		SourceConfigModel configModel = configEditCopyService.update(model);
		assertEquals("SCM1", configModel.getName());
		assertEquals(123L, configModel.getId());
	}

	@Test
	public void updateStatusPT01() {
		Mockito.when(configEditCopyRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1"));
		List<SourceConfigEditCopyEntity> entities = getSCEditCopyEntity(EditStatus.Inprogress, "SCM1");
		Mockito.when(configEditCopyRepository.save(Mockito.any())).thenReturn(entities.get(0));
		String changeStatus = configEditCopyService.updateStatus(EditStatus.Inprogress, "Sample Config",null);
		assertEquals(EditStatus.Inprogress.name(), changeStatus);
	}

	@Test
	public void getEntityPT01() {
		Mockito.when(configEditCopyRepository.findByName(Mockito.any()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1"));
		SourceConfigEditCopyEntity entity = configEditCopyService.getEntity("SCM1");
		assertNotNull(entity);
	}

	@Test
	public void getEntityNT01() {
		Mockito.when(configEditCopyRepository.findByName(Mockito.any()))
				.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
		SourceConfigEditCopyEntity entity = configEditCopyService.getEntity("SCM1");
		assertNull(entity);
	}

	@Test
	public void isSourceConfigEditCopyExistsPT01() {
		Mockito.when(configEditCopyRepository.isSourceConfigExists(Mockito.any())).thenReturn(true);
		boolean editCopyExists = configEditCopyService.isEditCopyExists("SCM1");
		assertEquals(true, editCopyExists);
	}

	@Test
	public void savePT01() {
		Mockito.when(configEditCopyRepository.save(Mockito.any()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1").get(0));
		SourceConfigEditCopyEntity entity = configEditCopyService
				.save(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1").get(0));
		assertEquals(entity.getName(), "SCM1");
	}

	@Test
	public void deletePT01() {
		configEditCopyService.delete(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1").get(0));
	}

	@Test
	public void getAllPT01() {
		Mockito.when(configEditCopyRepository.findByEntityId(Mockito.any()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM1"));
		List<ConfigSummary> list = configEditCopyService.getAll("123");
		assertEquals(list.get(0).getConfigName(), "SCM1");
	}

	@Test
	public void getAllNT01() {
		Mockito.when(configEditCopyRepository.findByEntityId(Mockito.any()))
				.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
		List<ConfigSummary> list = configEditCopyService.getAll("123");
		assertNotNull(list);
	}

	public SourceConfigModel getSCModel() {
		SourceConfigModel macConfigModel = new SourceConfigModel();
		macConfigModel.setId(123L);
		macConfigModel.setName("SCM1");
		//macConfigModel.setMerchantPreferences(merPreferencesArray());
		return macConfigModel;
	}

	private List<SourceConfigEditCopyEntity> getSCEditCopyEntity(EditStatus status, String name) {
		List<SourceConfigEditCopyEntity> list = new ArrayList<SourceConfigEditCopyEntity>();
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(123L);
		entity.setName(name);
		entity.setStatus(status);
		list.add(entity);
		return list;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}

	private List<MessageFormatConfigModel> getMFConfigModel() {
		List<MessageFormatConfigModel> entities = new ArrayList<>();
		MessageFormatConfigModel entity = new MessageFormatConfigModel();
		entity.setId(123L);
		entity.setMsgType("0200");
		entity.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		entity.setOwnerType(OwnerType.SOURCE);
		entities.add(entity);
		return entities;
	}

}
