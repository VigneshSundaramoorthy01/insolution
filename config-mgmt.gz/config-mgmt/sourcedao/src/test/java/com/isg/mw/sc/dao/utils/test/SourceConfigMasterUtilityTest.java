package com.isg.mw.sc.dao.utils.test;



import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.sc.dao.utils.SourceConfigMasterUtility;

public class SourceConfigMasterUtilityTest {
	public static String[] demoRecord() {

		String[] merPrefArr = { "tcm1", "tcm2" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}

	@Test
	public void getSourceModelPT01() {

		SourceConfigMasterEntity entity = getSCMasterEntity();
		SourceConfigModel model = SourceConfigMasterUtility.getSourceModel(entity);
		assertEquals(entity.getId(), model.getId());
		assertEquals(entity.getName(), model.getName());
		assertArrayEquals((IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class)),
				model.getTargetPreferences());
		assertEquals(entity.getConnectionType(), model.getConnectionType());
		assertEquals(entity.getUpdatedAt(), model.getUpdatedAt());
		assertEquals(entity.getStatus().toString(), model.getStatus());
        assertEquals(entity.getRequestTimeout(), model.getRequestTimeout());
	}

	@Test
	public void getSourceEntityPT01() {
		SourceConfigModel model = getSCModel();
		SourceConfigMasterEntity entity = SourceConfigMasterUtility.getSourceEntity(model);
		assertEquals(entity.getName(), model.getName());
		assertEquals(entity.getConnectionType(), model.getConnectionType());
		assertArrayEquals((IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class)),
				model.getTargetPreferences());
		assertEquals(entity.getStatus().toString(), model.getStatus());
		assertEquals(entity.getRequestTimeout(), model.getRequestTimeout());
	}

	@Test
	public void updateSourceEntityPT01() {
		SourceConfigModel model = getSCModel();
		SourceConfigMasterEntity entity = getSCMasterEntity();
		SourceConfigMasterUtility.updateSourceEntity(model, entity);
		assertArrayEquals((IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class)),
				model.getTargetPreferences());
		assertNotNull(entity.getUpdatedAt());
        assertEquals(entity.getRequestTimeout(), model.getRequestTimeout());
	}

	private SourceConfigModel getSCModel() {
		SourceConfigModel configModel = new SourceConfigModel();
		configModel.setId(1L);
		configModel.setName("SCM1");
		configModel.setTargetPreferences(demoRecord());
		configModel.setConnectionType(ConnectionType.ISO);
		configModel.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		configModel.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		configModel.setStatus(ConfigStatus.Active.name());
		configModel.setRequestTimeout(89000);
		return configModel;
	}

	private SourceConfigMasterEntity getSCMasterEntity() {
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setId(1L);
		entity.setName("SCM1");
		entity.setTargetPreferences(demoRecord().toString());
		entity.setConnectionType(ConnectionType.ISO);
		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setStatus(ConfigStatus.Active);
        entity.setRequestTimeout(89000);
		return entity;
	}

}
