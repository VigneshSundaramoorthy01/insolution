package com.isg.mw.sc.dao.service.impl.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.repository.SourceConfigMasterRepository;
import com.isg.mw.sc.dao.service.impl.SourceConfigMasterSeviceImpl;

public class SourceConfigMasterSeviceImplTest {
	@Mock
	private SourceConfigMasterRepository configMasterRepository;

	@Mock
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@InjectMocks
	private SourceConfigMasterSeviceImpl configMasterSevice;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getPT01() {
		Mockito.when(configMasterRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		SourceConfigModel model = configMasterSevice.get("SCM1");
		assertEquals(model.getName(), getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0).getName());
	}

	@Test
	public void getNT01() {
		Mockito.when(configMasterRepository.findByName(Mockito.anyString()))
				.thenReturn(new ArrayList<SourceConfigMasterEntity>());
		SourceConfigModel model = configMasterSevice.get("SCM1");
		assertNull(model);
	}

	@Test
	public void addPT01() {
		Mockito.when(configMasterRepository.save(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));
		SourceConfigModel model = configMasterSevice.add(getModel());
		assertEquals(model.getId(), getModel().getId());
		assertEquals(model.getName(), getModel().getName());
	}

	@Test
	public void updatePT01() {

		Mockito.when(configMasterRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		SourceConfigModel model = getModel();
		List<SourceConfigMasterEntity> entities = getSCMasterEntity(ConfigStatus.Active, "SCM1");
		Mockito.when(configMasterRepository.save(Mockito.any())).thenReturn(entities.get(0));
		SourceConfigModel configModel = configMasterSevice.update(model);
		assertEquals("SCM1", configModel.getName());
		assertEquals(123L, configModel.getId());
	}

	@Test
	public void testchangeStatus() {
		Mockito.when(configMasterRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		Mockito.when(configMasterRepository.save(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Inactive, "SCM1").get(0));
		ConfigStatus changeStatus = configMasterSevice.updateStatus("SCM1", ConfigStatus.Inactive);
		assertEquals(ConfigStatus.Inactive, changeStatus);
	}

	@Test
	public void getAllPT01() {
		Mockito.when(configMasterRepository.getAll(Mockito.any(), Mockito.any()))
				.thenReturn(getSCMasterEntity2(ConfigStatus.Active, LockedState.Unlocked));
		List<SourceConfigModel> list = configMasterSevice.getAll();
		assertEquals(list.get(0).getLockedState(), LockedState.Unlocked);
		assertEquals(list.get(0).getStatus(), ConfigStatus.Active.name());
	}

	@Test
	public void getAllNT01() {
		Mockito.when(configMasterRepository.getAll(Mockito.any(), Mockito.any())).thenReturn(new ArrayList<>());
		List<SourceConfigModel> list = configMasterSevice.getAll();
		assertNotNull(list);
	}

	@Test
	public void lockPT01() {
		Mockito.when(configMasterRepository.findByName(Mockito.anyString()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		Mockito.when(configMasterRepository.save(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));
		LockedState lock = configMasterSevice.lock("SCM1", LockedState.Locked);
		assertEquals(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0).getLockedState(), lock);
	}

	@Test
	public void getEntityPT01() {
		Mockito.when(configMasterRepository.findByName(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		SourceConfigMasterEntity entity = configMasterSevice.getEntity("SCM1");
		assertNotNull(entity);
	}

	@Test
	public void getEntityNT01() {
		Mockito.when(configMasterRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		SourceConfigMasterEntity entity = configMasterSevice.getEntity("sample");
		assertNull(entity);
	}

	@Test
	public void savePT01() {
		Mockito.when(configMasterRepository.save(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));
		SourceConfigMasterEntity entity = configMasterSevice
				.save(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));
		assertEquals(entity.getName(), "SCM1");
	}

	@Test
	public void getPT02() {
		Mockito.when(configMasterRepository.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		SourceConfigMasterEntity entity = configMasterSevice.get("SCM1", "123L");
		assertEquals(entity.getName(), getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0).getName());
	}

	@Test
	public void getNT02() {
		Mockito.when(configMasterRepository.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(new ArrayList<SourceConfigMasterEntity>());
		SourceConfigMasterEntity entity = configMasterSevice.get("SCM1", "123L");
		assertNull(entity);
	}

	@Test
	public void getAllPT02() {
		Mockito.when(configMasterRepository.findByEntityId(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1"));
		List<ConfigSummary> list = configMasterSevice.getAll("123");
		assertEquals(list.get(0).getConfigName(), "SCM1");
	}

	@Test
	public void getAllNT02() {
		Mockito.when(configMasterRepository.findByEntityId(Mockito.any()))
				.thenReturn(new ArrayList<SourceConfigMasterEntity>());
		List<ConfigSummary> list = configMasterSevice.getAll("123");
		assertNotNull(list);
	}

	public SourceConfigModel getModel() {
		SourceConfigModel macConfigModel = new SourceConfigModel();
		macConfigModel.setId(123L);
		macConfigModel.setName("SCM1");
		return macConfigModel;
	}

	/**
	 * This Method return MacConfigEntity Object
	 * 
	 * @param status
	 * @param name
	 * 
	 */

	private List<SourceConfigMasterEntity> getSCMasterEntity(ConfigStatus status, String name) {
		List<SourceConfigMasterEntity> list = new ArrayList<SourceConfigMasterEntity>();
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setId(123L);
		entity.setName(name);
		entity.setStatus(status);
		entity.setLockedState(LockedState.Locked);
		list.add(entity);
		return list;
	}

	private List<SourceConfigMasterEntity> getSCMasterEntity2(ConfigStatus active, LockedState lockedState) {
		List<SourceConfigMasterEntity> list = new ArrayList<SourceConfigMasterEntity>();
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setId(1L);
		entity.setName("SCM1");
		entity.setStatus(active);
		entity.setLockedState(lockedState);
		list.add(entity);
		return list;

	}

}
