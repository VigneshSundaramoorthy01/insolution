package com.isg.mw.sc.dao.service.impl.test;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.dao.entities.MessageFormatConfigEditCopyEntity;
import com.isg.mw.mf.dao.repository.MessageFormatConfigEditCopyRepository;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.mf.dao.service.MfPrivateOnlineValidator;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.repository.SourceConfigEditCopyRepository;
import com.isg.mw.sc.dao.repository.SourceConfigMasterRepository;
import com.isg.mw.sc.dao.service.impl.SourceMfOnlineValidatorImpl;

public class SourceMfOnlineValidatorImplTest {

	@Mock
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Mock
	private MfPrivateOnlineValidator mfPrivateOnlineValidator;

	@Mock
	private SourceConfigEditCopyRepository sourceConfigEditCopyRepository;

	@Mock
	private SourceConfigMasterRepository sourceConfigMasterRepository;

	@InjectMocks
	SourceMfOnlineValidatorImpl sourceMfOnlineValidator;

	@Mock
	private MessageFormatConfigEditCopyRepository mssageFormatConfigEditCopyRepository;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	// @Test
	public void addValidationPT01() {
		Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
				.thenReturn(getSCEditCopyEntityList(EditStatus.Inprogress));
		Long validation = sourceMfOnlineValidator.addValidation(getMFConfigModel().get(0), "123L", "SCM1");
		assertNotNull(validation);
	}

	// @Test
	public void addValidationNT01() {
		String errorMsg = null;
		Object errorArgs[] = null;
		String name = "SCM1";
		String entityId = "123L";
		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(new ArrayList<SourceConfigEditCopyEntity>());
			sourceMfOnlineValidator.addValidation(getMFConfigModel().get(0), entityId, name);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.dao.edit.copy.not.exists");
		assertEquals(errorArgs[0], name);

	}

	// @Test
	public void addValidationNT02() {
		String errorMsg = null;
		Object errorArgs[] = null;
		String name = "SCM1";
		String entityId = "123L";
		try {
			Mockito.when(sourceConfigEditCopyRepository.findByName(Mockito.any()))
					.thenReturn(getSCEditCopyEntityList(EditStatus.Submitted));
			sourceMfOnlineValidator.addValidation(getMFConfigModel().get(0), entityId, name);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.dao.has.SUBMITTED.status");
		assertEquals(errorArgs[0], name);

	}

	// @Test
	public void modifyValidationPT01() {
		String errorMsg = null;
		Object errorArgs[] = null;
		Long id = 123L;
		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any()))
					.thenReturn(getMFEditCopyEntity().get(0));
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any()))
					.thenReturn(Optional.of(getSCEditCopyEntity(EditStatus.Inprogress, id)));
			sourceMfOnlineValidator.modifyValidation(getMFConfigModel().get(0));
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	// @Test
	public void modifyValidationNT01() {
		String errorMsg = null;
		Object errorArgs[] = null;
		Long id = 123L;

		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any())).thenReturn(null);
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any()))
					.thenReturn(Optional.of(getSCEditCopyEntity(EditStatus.Inprogress, id)));
			sourceMfOnlineValidator.modifyValidation(getMFConfigModel().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.dao.message.format.not.exists");
		assertEquals(errorArgs[0], id);

	}

	// @Test
	public void modifyValidationNT02() {
		String errorMsg = null;
		Long id = 124L;

		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any()))
					.thenReturn(getMFEditCopyEntity().get(0));
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any()))
					.thenReturn(Optional.of(getSCEditCopyEntity(EditStatus.Submitted, id)));
			sourceMfOnlineValidator.modifyValidation(getMFConfigModel().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.has.SUBMITTED.status");

	}

	// @Test
	public void modifyValidationNT03() {
		String errorMsg = null;

		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any()))
					.thenReturn(getMFEditCopyEntity().get(0));
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any())).thenReturn(Optional.ofNullable(null));
			sourceMfOnlineValidator.modifyValidation(getMFConfigModel().get(0));
		} catch (Exception ex) {
			errorMsg = ex.getMessage();

		}
		assertEquals(errorMsg, "No value present");

	}

	// @Test
	public void deleteValidationPT01() {
		String errorMsg = null;
		Object errorArgs[] = null;
		Long id = 123L;
		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any()))
					.thenReturn(getMFEditCopyEntity().get(0));
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any()))
					.thenReturn(Optional.of(getSCEditCopyEntity(EditStatus.Inprogress, id)));
			sourceMfOnlineValidator.deleteValidation(123L);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	// @Test
	public void deleteValidationNT02() {
		String errorMsg = null;
		Object errorArgs[] = null;
		Long id = 123L;

		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any())).thenReturn(null);
			sourceMfOnlineValidator.deleteValidation(123L);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.dao.message.format.not.exists");
		assertEquals(errorArgs[0], id);

	}

	// @Test
	public void deleteValidationNT03() {
		String errorMsg = null;
		Long id = 124L;

		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any()))
					.thenReturn(getMFEditCopyEntity().get(0));
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any()))
					.thenReturn(Optional.of(getSCEditCopyEntity(EditStatus.Submitted, id)));
			sourceMfOnlineValidator.deleteValidation(123L);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.has.SUBMITTED.status");

	}

	// @Test
	public void deleteValidationNT04() {
		String errorMsg = null;
		try {
			Mockito.when(messageFormatConfigEditCopyService.getById(Mockito.any()))
					.thenReturn(getMFEditCopyEntity().get(0));
			Mockito.when(sourceConfigEditCopyRepository.findById(Mockito.any())).thenReturn(Optional.ofNullable(null));
			sourceMfOnlineValidator.deleteValidation(123L);
		} catch (Exception ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "No value present");

	}

	// @Test
	public void checkIsUnLockedNT01() {
		String errorMsg = null;

		try {
			Mockito.when(sourceConfigMasterRepository.findByName(Mockito.any()))
					.thenReturn(getSCMasterEntityList(ConfigStatus.Active, LockedState.Locked));
			sourceMfOnlineValidator.addValidation(getMFConfigModel().get(0), "123L", "SCM1");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertEquals(errorMsg, "sc.dao.system.wont.allow.to.modify");

	}

	private List<SourceConfigMasterEntity> getSCMasterEntityList(ConfigStatus status, LockedState state) {
		List<SourceConfigMasterEntity> list = new ArrayList<SourceConfigMasterEntity>();
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setId(123L);
		entity.setName("SCM1");
		entity.setStatus(status);
		entity.setLockedState(state);
		list.add(entity);
		return list;
	}

	private List<MessageFormatConfigEditCopyEntity> getMFEditCopyEntity() {
		List<MessageFormatConfigEditCopyEntity> entities = new ArrayList<MessageFormatConfigEditCopyEntity>();
		MessageFormatConfigEditCopyEntity entity = new MessageFormatConfigEditCopyEntity();
		entity.setId(123L);
		entity.setOwnerId(124L);
		entity.setMsgType("0200");
		entity.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		entity.setOwnerType(OwnerType.SOURCE);
		entities.add(entity);
		return entities;
	}

	private List<MessageFormatConfigModel> getMFConfigModel() {
		List<MessageFormatConfigModel> configModels = new ArrayList<>();
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(123L);
		model.setOwnerId(124L);
		model.setMsgType("0200");
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		model.setOwnerType(OwnerType.SOURCE);
		configModels.add(model);
		return configModels;
	}

	private List<SourceConfigEditCopyEntity> getSCEditCopyEntityList(EditStatus status) {
		List<SourceConfigEditCopyEntity> list = new ArrayList<SourceConfigEditCopyEntity>();
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(123L);
		entity.setName("SCM1");
		entity.setStatus(status);
		list.add(entity);
		return list;

	}

	private SourceConfigEditCopyEntity getSCEditCopyEntity(EditStatus status, Long id) {

		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(id);
		entity.setName("SCM1");
		entity.setStatus(status);

		return entity;
	}
}
