package com.isg.mw.sc.dao.utils.test;


import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.sc.dao.utils.SourceConfigEditCopyUtility;

public class SourceConfigEditCopyUtilityTest {
	public static String[] demoRecord() {

		String[] merPrefArr = { "tcm1", "tcm2" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}


	@Test
	public void getSourceModelPT01() {

		SourceConfigEditCopyEntity entity = getSourceConfigEditCopyEntity();
		SourceConfigModel model = SourceConfigEditCopyUtility.getSourceModel(entity);
		assertEquals(entity.getId(), model.getId());
		assertEquals(entity.getName(), model.getName());
		assertArrayEquals((IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class)), model.getTargetPreferences());
		assertEquals(entity.getConnectionType(), model.getConnectionType());
		assertNotNull(entity.getCreatedAt());
		assertEquals(entity.getStatus().toString(), model.getStatus());
        assertEquals(entity.getRequestTimeout(), model.getRequestTimeout());

	}

	@Test
	public void getSourceEntityPT01() {
		SourceConfigModel model = getSourceConfigEditModel();
		SourceConfigEditCopyEntity entity =SourceConfigEditCopyUtility.getSourceEntity(model);
		assertEquals(entity.getName(), model.getName());
		assertArrayEquals((IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class)), model.getTargetPreferences());
		assertEquals(entity.getConnectionType(), model.getConnectionType());
		assertEquals(entity.getStatus().toString(), model.getStatus());
		assertEquals(entity.getRequestTimeout(), model.getRequestTimeout());
	}

	@Test
	public void updateSourceEntityPT01() {
		SourceConfigModel model = getSourceConfigEditModel();
		SourceConfigEditCopyEntity entity = getSourceConfigEditCopyEntity();
		SourceConfigEditCopyUtility.updateSourceEntity(model, entity);
		assertArrayEquals((IsgJsonUtils.getObjectFromJsonString(entity.getTargetPreferences(), String[].class)), model.getTargetPreferences());
		assertEquals(entity.getRequestTimeout(), model.getRequestTimeout());

	}

	private SourceConfigModel getSourceConfigEditModel() {
		SourceConfigModel configModel = new SourceConfigModel();
		configModel.setId(1L);
		configModel.setName("slave");
		configModel.setTargetPreferences(demoRecord());
		configModel.setConnectionType(ConnectionType.ISO);
		configModel.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		configModel.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		configModel.setStatus(EditStatus.Inprogress.toString());
        configModel.setRequestTimeout(89000);
		return configModel;
	}

	
	private SourceConfigEditCopyEntity getSourceConfigEditCopyEntity() {
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(1L);
		entity.setName("slave");
		entity.setTargetPreferences(demoRecord().toString());
		entity.setConnectionType(ConnectionType.ISO);
		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setStatus(EditStatus.Inprogress);
		entity.setRequestTimeout(89000);
		return entity;
	}

}
