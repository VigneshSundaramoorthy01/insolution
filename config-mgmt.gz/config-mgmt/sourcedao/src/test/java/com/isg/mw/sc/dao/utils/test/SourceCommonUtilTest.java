package com.isg.mw.sc.dao.utils.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;

public class SourceCommonUtilTest {

	@Test
	public void convertStringToTargetConnectionListPT01() {
		MerchantPreference[] preferences = SourceCommonUtil.convertStringToTargetConnectionList(merPreferencesString());
		int i = 0;
		for (MerchantPreference pre : preferences) {
			assertEquals(pre, merPreferencesArray()[i++]);
		}
	}

	@Test
	public void convertStringToTargetConnectionListNT01() {
		MerchantPreference[] preferences = SourceCommonUtil
				.convertStringToTargetConnectionList(MerchantPreference.ONUS.name());
		assertNotNull(preferences);
	}

	@Test
	public void convertTargetConnectionListToStringPT01() {
		String str = SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
		assertEquals(str, merPreferencesString());
	}

	@Test
	public void convertTargetConnectionListToStringNT01() {
		String str = SourceCommonUtil.convertTargetConnectionListToString(null);
		assertNotNull(str);
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}

}
