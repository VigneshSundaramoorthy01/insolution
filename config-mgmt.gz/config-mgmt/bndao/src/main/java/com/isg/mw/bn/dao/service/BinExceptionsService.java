package com.isg.mw.bn.dao.service;

import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

public interface BinExceptionsService {
    BinExceptionsModel add(BinExceptions binExceptions);

    BinExceptionsModel modify(BinExceptions binExceptions);

    BinExceptions get(String schemeName, BigInteger binNumber, BigInteger binLow, BigInteger binHigh);


  //  List<BinExceptions> getAll(ActiveFlag activeFlag, Integer pageNo, Integer pageSize);

    Map<String, List<BinExceptionsModel>> getAllasMap();

    List<BinExceptionsModel> getAll(ActiveFlag activeFlag,Integer pageNo,Integer pageSize);

    BinExceptions updateTargetId(BigInteger binNumber, String targetName);

    BinExceptions get(String schemeName,BigInteger binLow, BigInteger binHigh);

    Long getBinsCount(ActiveFlag activeFlag);

    BinExceptionsModel getBinyBinNo(BigInteger binNo);

    Long serachBinCount(String data);

    List<BinExceptionsModel> serachBinData(String data);

    void loadAll(List<BinExceptions> addOrUpdateBinInfoModel);
}
