package com.isg.mw.bn.dao.service.impl;

import com.isg.mw.bn.dao.entities.AidSchemeMap;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.bn.dao.repository.AidSchemeMapRepository;
import com.isg.mw.bn.dao.service.AidSchemeMapService;
import com.isg.mw.bn.dao.utils.AidSchemeMapUtility;
import com.isg.mw.bn.dao.utils.BinInfoUtility;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AidSchemeMapServiceImpl implements AidSchemeMapService {

    @Autowired
    AidSchemeMapRepository aidSchemeMapRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public AidSchemeModel add(AidSchemeMap aidSchemeMap) {
        AidSchemeMap aidSchemeMap1=new AidSchemeMap();
        aidSchemeMap1=aidSchemeMapRepository.save(aidSchemeMap);
        return AidSchemeMapUtility.getAidSchemeModel(aidSchemeMap1);
    }

    @Override
    public AidSchemeModel modify(AidSchemeMap aidSchemeMap) {
        AidSchemeMap aidSchemeMap1=new AidSchemeMap();
        aidSchemeMap1=aidSchemeMapRepository.save(aidSchemeMap);
        return AidSchemeMapUtility.getAidSchemeModel(aidSchemeMap1);
    }

    @Override
    public AidSchemeMap get(String aid, ActiveFlag activeFlag) {
        AidSchemeMap aidSchemeMap1=new AidSchemeMap();
        aidSchemeMap1=aidSchemeMapRepository.findByAidAndActiveFlag(aid);
        return aidSchemeMap1;
    }

    @Override
    public List<AidSchemeMap> get(BigInteger targetId, ActiveFlag activeFlag) {
        List<AidSchemeMap> aidList=new ArrayList<>();
        aidList=aidSchemeMapRepository.findByTargetId(targetId);
        return aidList;
    }

    @Override
    public Long getAidsCount(ActiveFlag activeFlag) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<AidSchemeMap> td = cq.from(AidSchemeMap.class);
        cq.select(cb.count(td));
        List<Predicate> predicates = null;
        predicates = getBinCountPredicates(cb, cq, td, activeFlag);
        cq.where(predicates.toArray(new Predicate[] {}));
        return entityManager.createQuery(cq).getSingleResult();
    }

    private List<Predicate> getBinCountPredicates(CriteriaBuilder cb, CriteriaQuery<Long> cq, Root<AidSchemeMap> td,
                                                  ActiveFlag activeFlag) {
        List<Predicate> predicates = new ArrayList<>();

        if (activeFlag != null) {
            predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
        }
        return predicates;
    }


    private List<Predicate> getAidRecordPredicates(CriteriaBuilder cb, CriteriaQuery<AidSchemeMap> cq,
                                                   Root<AidSchemeMap> td, ActiveFlag activeFlag) {
        List<Predicate> predicates = new ArrayList<>();

        if (activeFlag != null) {
            predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
        }
        return predicates;

    }

    @Override
    public List<AidSchemeModel> getAll(ActiveFlag activeFlag, Integer pageNo, Integer pageSize) {
//        List<AidSchemeMap> aidList=new ArrayList<>();
//        aidList=aidSchemeMapRepository.getAll(activeFlag);
//        return aidList;

        List<AidSchemeModel> models;
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<AidSchemeMap> cq = cb.createQuery(AidSchemeMap.class);
        Root<AidSchemeMap> td = cq.from(AidSchemeMap.class);
        List<Predicate> predicates = getAidRecordPredicates(cb, cq, td, activeFlag);
        cq.where(predicates.toArray(new Predicate[] {}));

        List<Order> orderBy = new ArrayList<>();
        orderBy.add(cb.asc(td.get("id")));
        cq.orderBy(orderBy);

        TypedQuery<AidSchemeMap> query = entityManager.createQuery(cq);
        if (pageNo != null) {
            query.setFirstResult(pageNo);
            query.setMaxResults(pageSize);
        }
        models = query.getResultList().stream().map(AidSchemeMapUtility::getAidSchemeModel).collect(Collectors.toList());
        return models;
    }
}
