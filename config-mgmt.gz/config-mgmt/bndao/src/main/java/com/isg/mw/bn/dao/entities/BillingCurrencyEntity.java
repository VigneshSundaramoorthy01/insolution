package com.isg.mw.bn.dao.entities;


import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;
import com.isg.mw.core.model.constants.TargetType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Entity
@Getter
@Setter
@Table(name = "BILLING_ISO_CURRENCY")
public class BillingCurrencyEntity extends AuditInfoEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;
	
    @Column(name = "BILLING_ISO_CURRENCY_CODE", length = 3)
    private Integer billingIsoCurrencyCode;
    
    @Column(name = "SCHEME_NAME")
    @Enumerated(EnumType.STRING)
    private TargetType schemeName;

    @Column(name = "FILE_IDENTIFIER", length = 20)
    private String fileIdentifier;

    @Column(name = "ACCOUNT_LOW_RANGE")
    private BigInteger accountLowRange;
    
    @Column(name = "ACCOUNT_HIGH_RANGE")
    private BigInteger accountHighRange;
    		
    @Column(name = "DCC_INDICATOR")
    private Integer dccIndicator;//[Numeric, DDMMYYYYHH24MMSS]
    				
}
