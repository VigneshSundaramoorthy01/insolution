package com.isg.mw.bn.dao.repository;

import org.springframework.data.repository.CrudRepository;

import com.isg.mw.bn.dao.entities.BinInfoFileEntity;

/**
 * 
 * @author sanchita3984
 *
 */
public interface BinInfoFileRepository extends CrudRepository<BinInfoFileEntity, String> {

//	@Query("SELECT file FROM BinInfoFileEntity file WHERE file.schemeName = :schemeName AND file.fileNameValidation = :status"
//			+ " ORDER BY DESC file.createdAt limit 1")
//	@Query("SELECT bie FROM BinInfoFileEntity bie WHERE bie.schemeName = :schemeName AND "
//			+ "bie.fileNameValidation = :status ORDER BY bie.createdAt DESC " )
//	List<BinInfoFileEntity> getLatestSuccess(@Param("schemeName") String schemeName, @Param("status") ValidationStatus status);

}
