package com.isg.mw.bn.dao.entities;

import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.LOFO;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;

@Getter
@Setter
@Entity
@Table(name = "BIN_ONUS_MAP")
public class BinOnusMap {
    /**
     * Database auto generated value
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;

    /**
     * Entity Id
     */
    @Column(name = "entity_id", length = 32)
    private String entityId;

    /**
     * Scheme Type (Visa, MasterCard, Rupay)
     */
    @Column(name = "SCHEME_TYPE", length = 25)
    private String schemeName;

    /**
     * Bank Identification Number
     */
    @Column(name = "BIN_NUMBER", length = 9)
    private BigInteger binNumber;

    /**
     * Bin Minimum Range
     */
    @Column(name = "BIN_LOW", length = 9)
    private BigInteger binLow;

    /**
     * Bin Maximum Range
     */
    @Column(name = "BIN_HIGH", length = 9)
    private BigInteger binHigh;

    /**
     * Country Category (Consumer, Premium )
     */
    @Column(name = "CARD_CATEGORY", length = 15)
    private String cardCategory;

    /**
     * Card Program (Debit, Credit, Prepaid, EMI)
     */
    @Column(name = "CARD_PROGRAM", length = 7)
    private String cardProgram;

    /**
     * Card brand (Classic, Platinum, Gold)
     */
    @Column(name = "CARD_BRAND", length = 50)
    private String cardBrand;

    /**
     * Country code (Numeric code)
     */
    @Column(name = "COUNTRY_CODE_N", length = 3)
    private String countryCodeN;

    /**
     * Country code (Alpha code)
     */
    @Column(name = "COUNTRY_CODE_A", length = 3)
    private String countryCodeA;

    /**
     * Active Flag
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "ACTIVE_FLAG", length = 1)
    private ActiveFlag activeFlag;

    /**
     * Lofo ‘L’ or ‘F’ L – Local Bin F – International Bin
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "LOFO", length = 1)
    private LOFO lofo;


    /**
     * targetId
     */
    @Column(name = "TARGET_ID")
    private String targetId;

    @Enumerated(EnumType.STRING)
    @Column(name = "LEAST_COST_ACTIVE_FLAG", length = 1)
    private ActiveFlag leastCostActiveFlag;

    /**
     * Product Category (Consumer, Premium )
     */
    @Column(name = "PRODUCT_CATEGORY", length = 15)
    private String productCategory;

}
