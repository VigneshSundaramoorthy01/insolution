package com.isg.mw.bn.dao.service;

import com.isg.mw.core.model.bi.BinInfoModel;

public interface BinOnlineValidation {

	String fileNameValidation(String fileName);

	void addValidation(BinInfoModel model);
	
	void updateValidation(BinInfoModel model);
	
	void checkedTargetId(String targetId);
}
