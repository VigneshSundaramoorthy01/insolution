package com.isg.mw.bn.dao.utils;

import com.isg.mw.bn.dao.entities.BillingCurrencyEntity;
import com.isg.mw.core.model.bi.BillingCurrencyModel;

public class BillingCurrnecyUtility {

    private BillingCurrnecyUtility() {

    }
    
    public static BillingCurrencyEntity getBillingCurrencyEntity(BillingCurrencyModel model) {
    	BillingCurrencyEntity entity = new BillingCurrencyEntity();
        entity.setBillingIsoCurrencyCode(model.getBillingIsoCurrencyCode());
        entity.setAccountLowRange(model.getAccountLowRange());
        entity.setAccountHighRange(model.getAccountHighRange());
        entity.setSchemeName(model.getSchemeName());
        entity.setFileIdentifier(model.getFileIdentifier());
        entity.setDccIndicator(model.getDccIndicator());
        
        return entity;
    }

    public static BillingCurrencyModel getBillingCurrencyModel(BillingCurrencyEntity entity) {
    	BillingCurrencyModel model = new BillingCurrencyModel();
    	model.setBillingIsoCurrencyCode(entity.getBillingIsoCurrencyCode());
    	model.setAccountLowRange(entity.getAccountLowRange());
    	model.setAccountHighRange(entity.getAccountHighRange());
    	model.setSchemeName(entity.getSchemeName());
    	model.setFileIdentifier(entity.getFileIdentifier());
    	model.setDccIndicator(entity.getDccIndicator());
        
        return model;
    }
}
