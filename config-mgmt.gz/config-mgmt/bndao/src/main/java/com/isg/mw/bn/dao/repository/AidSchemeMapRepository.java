package com.isg.mw.bn.dao.repository;

import com.isg.mw.bn.dao.entities.AidSchemeMap;
import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.core.model.constants.ActiveFlag;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.math.BigInteger;
import java.util.List;

public interface AidSchemeMapRepository extends CrudRepository<AidSchemeMap, String> {

    @Query("SELECT a FROM AidSchemeMap a WHERE a.targetId = :targetId")
    List<AidSchemeMap> findByTargetId(@Param("targetId") BigInteger targetId
                                          //  @Param("activeFlag") ActiveFlag activeFlag
    );

    @Query("SELECT a FROM AidSchemeMap a WHERE a.aid = :aid ")
    AidSchemeMap findByAidAndActiveFlag(@Param("aid") String aid
                                 //     @Param("activeFlag") ActiveFlag activeFlag
    );

    @Query("SELECT a FROM AidSchemeMap a WHERE a.activeFlag = :activeFlag")
    List<AidSchemeMap> getAll(@Param("activeFlag") ActiveFlag activeFlag);
}
