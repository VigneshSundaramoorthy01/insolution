package com.isg.mw.bn.dao.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.LOFO;

import com.isg.mw.core.model.constants.Tokenize;
import lombok.Getter;
import lombok.Setter;

import java.math.BigInteger;
import java.util.Objects;

/**
 * Bin info entity
 * 
 * @author sanchita3984
 *
 */
@Getter
@Setter
@Entity
@Table(name = "BIN_INFO_ENTITY")
public class BinInfoEntity extends AuditInfoEntity {

	/**
	 * Database auto generated value
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;
	/**
	 * Scheme Type (Visa, MasterCard, Rupay)
	 */
	@Column(name = "SCHEME_TYPE", length = 25)
	private String schemeName;

	/**
	 * Bank Identification Number
	 */
	@Column(name = "BIN_NUMBER", length = 9)
	private BigInteger binNumber;

	/**
	 * Bin Minimum Range
	 */
	@Column(name = "BIN_LOW", length = 9)
	private BigInteger binLow;

	/**
	 * Bin Maximum Range
	 */
	@Column(name = "BIN_HIGH", length = 9)
	private BigInteger binHigh;

	/**
	 * Country Category (Consumer, Premium )
	 */
	@Column(name = "CARD_CATEGORY", length = 15)
	private String cardCategory;

	/**
	 * Card Program (Debit, Credit, Prepaid, EMI)
	 */
	@Column(name = "CARD_PROGRAM", length = 7)
	private String cardProgram;

	/**
	 * Card brand (Classic, Platinum, Gold)
	 */
	@Column(name = "CARD_BRAND", length = 50)
	private String cardBrand;

	/**
	 * Country code (Numeric code)
	 */
	@Column(name = "COUNTRY_CODE_N", length = 3)
	private String countryCodeN;

	/**
	 * Country code (Alpha code)
	 */
	@Column(name = "COUNTRY_CODE_A", length = 3)
	private String countryCodeA;

	/**
	 * Active Flag
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "ACTIVE_FLAG", length = 1)
	private ActiveFlag activeFlag;

	/**
	 * Lofo ‘L’ or ‘F’ L – Local Bin F – International Bin
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "LOFO", length = 1)
	private LOFO lofo;


	/**
	 * targetId
	 */
	@Column(name = "TARGET_ID")
	private String targetId;

	@Enumerated(EnumType.STRING)
	@Column(name = "LEAST_COST_ACTIVE_FLAG", length = 1)
	private ActiveFlag leastCostActiveFlag;
	
	/**
	 * Tokenize
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "Tokenize", length = 1)
	private Tokenize tokenize;

	@Column(name = "BATCH_NUMBER")
	private BigInteger batchNumber;

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		BinInfoEntity entity = (BinInfoEntity) o;
		return Objects.equals(schemeName, entity.schemeName) && Objects.equals(binNumber, entity.binNumber) && Objects.equals(binLow, entity.binLow) && Objects.equals(binHigh, entity.binHigh) && Objects.equals(cardCategory, entity.cardCategory) && Objects.equals(cardProgram, entity.cardProgram) && Objects.equals(cardBrand, entity.cardBrand) && Objects.equals(countryCodeN, entity.countryCodeN) && Objects.equals(countryCodeA, entity.countryCodeA) && lofo == entity.lofo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(schemeName, binNumber, binLow, binHigh, cardCategory, cardProgram, cardBrand, countryCodeN, countryCodeA, lofo);
	}


}
