package com.isg.mw.bn.dao.service.impl;

import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.bn.dao.repository.BinInfoRepository;
import com.isg.mw.bn.dao.service.DemoBinInfoService;
import com.isg.mw.bn.dao.utils.BinInfoUtility;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service("demoBinInfoService")
public class DemoBinInfoServiceImpl implements DemoBinInfoService {

    @Autowired
    private BinInfoRepository binInfoRepository;

    @Autowired
    private TargetConfigMasterService targetMasterService;

    @Override
    public List<BinInfoModel> getAllBins() {
        List<BinInfoEntity> entities = binInfoRepository.getAll(ActiveFlag.Y);
        List<BinInfoModel> models = new ArrayList<>();
        if(!entities.isEmpty()){
            models = entities.stream().map(BinInfoUtility::getBinModel).collect(Collectors.toList());
        }
        return models;
    }

    @Override
    public List<BinInfoModel> saveTargetId(TargetConfigModel configModel) {
        List<BinInfoEntity> entities = binInfoRepository.getAll(ActiveFlag.Y,ActiveFlag.Y,configModel.getTargetType().name());
        List<BinInfoModel> models = new ArrayList<>();

        for (BinInfoEntity entity : entities) {
            if (entity != null) {
                entity.setTargetId(configModel.getId() != null ? String.valueOf(configModel.getId()) : null);
                binInfoRepository.save(entity);
                models.add(BinInfoUtility.getBinModel(entity));
            }
        }
        return models;
    }
}
