package com.isg.mw.bn.dao.service;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.LOFO;

/**
 * 
 * @author sanchita3984
 *
 */
public interface BinInfoService {

	BinInfoModel add(BinInfoEntity entity);

	BinInfoModel modify(BinInfoEntity entity);

	BinInfoEntity get(String schemeName, BigInteger binNumber, BigInteger binLow, BigInteger binHigh);

	Map<String, List<BinInfoModel>> getAllasMap();

	List<BinInfoModel> getAll(ActiveFlag activeFlag,Integer pageNo,Integer pageSize);
	
	List<BinInfoModel> getAllBinOnus(ActiveFlag activFlag,Integer pageNo,Integer pageSize);

	BinInfoEntity updateTargetId(BigInteger binNumber, String targetName);
	
	BinInfoEntity get(String schemeName, BigInteger binLow, BigInteger binHigh, BigInteger binNumber, String cardCategory, String cardProgram, String cardBrand, String countryCodeN, String countryCodeA, LOFO lofo);

	Long getBinsCount(ActiveFlag activeFlag);

	BinInfoModel getBinInfoByBinNo(BigInteger binNo);
	
    Long serachBinCount(String data);
	
    List<BinInfoModel> serachBinData(String data);

	void loadAll(List<BinInfoEntity> addOrUpdateBinInfoModel);

	boolean getBinByTokenizedFlag(String data);
}
