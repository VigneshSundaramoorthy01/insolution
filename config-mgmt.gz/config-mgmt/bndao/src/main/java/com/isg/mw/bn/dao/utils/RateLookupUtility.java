package com.isg.mw.bn.dao.utils;

import com.isg.mw.bn.dao.entities.RateLookupEntity;
import com.isg.mw.core.model.bi.RateLookupModel;

public class RateLookupUtility {

    private RateLookupUtility() {

    }

    public static RateLookupEntity getRateLookupEntity(RateLookupModel model) {
        RateLookupEntity entity = new RateLookupEntity();
        entity.setDccTxnIsoCurrencyCode(model.getDccTxnIsoCurrencyCode());
        entity.setDccTxnIsoCurrency(model.getDccTxnIsoCurrency());
        entity.setDccExchangeRate(model.getDccExchangeRate());
        entity.setDccNoOfDecimals(model.getDccNoOfDecimals());
        entity.setExchangeRateExpiredateAndTime(model.getExchangeRateExpiredateAndTime());
        entity.setExchangeRateRecordCreationTime(model.getExchangeRateRecordCreationTime());
        entity.setRemarks(model.getRemarks());
        entity.setStatus(model.getStatus());
        entity.setEntityId(model.getEntityId());
        
        return entity;
    }

    public static RateLookupModel getRateLookupModel(RateLookupEntity entity) {
        RateLookupModel model = new RateLookupModel();
        model.setDccTxnIsoCurrencyCode(entity.getDccTxnIsoCurrencyCode());
        model.setDccTxnIsoCurrency(entity.getDccTxnIsoCurrency());
        model.setDccExchangeRate(entity.getDccExchangeRate());
        model.setDccNoOfDecimals(entity.getDccNoOfDecimals());
        model.setExchangeRateExpiredateAndTime(entity.getExchangeRateExpiredateAndTime());
        model.setExchangeRateRecordCreationTime(entity.getExchangeRateRecordCreationTime());
        model.setRemarks(entity.getRemarks());
        model.setStatus(entity.getStatus());
        model.setEntityId(entity.getEntityId());
        
        return model;
    }

}
