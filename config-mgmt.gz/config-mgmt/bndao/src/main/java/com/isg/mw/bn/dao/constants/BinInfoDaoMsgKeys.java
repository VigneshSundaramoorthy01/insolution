package com.isg.mw.bn.dao.constants;

public interface BinInfoDaoMsgKeys {

	String BIN_DATE_NOT_MATCH = "bo.date.not.match";

	String BIN_SEQUENCE_NUMBER_NOT_GREATER = "bo.sequence.number.not.greater";

	String BIN_TARGET_NOT_EXITS = "bo.dao.bin.target.not.exits";
	
	String BIN_EXITS_ALREADY = "bo.dao.bin.exits.already";
	
	String BIN_NOT_EXITS = "bo.dao.bin.not.exits";
	
}
