package com.isg.mw.bn.dao.service;

import com.isg.mw.bn.dao.entities.BinInfoFileEntity;

/**
 * 
 * @author sanchita3984
 *
 */
public interface BinInfoFileService {

	BinInfoFileEntity add(BinInfoFileEntity entity);

	BinInfoFileEntity getLatestSuccess(String schemeName);

}
