package com.isg.mw.bn.dao.utils;

import com.isg.mw.bn.dao.entities.AidSchemeMap;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinInfoModel;

public class AidSchemeMapUtility {

    private AidSchemeMapUtility() {

    }


    public static AidSchemeModel getAidSchemeModel(AidSchemeMap aidSchemeMap) {

        AidSchemeModel model = new AidSchemeModel();
        model.setTargetId(aidSchemeMap.getTargetId());
        model.setEntityId(aidSchemeMap.getEntityId());
        model.setAid(aidSchemeMap.getAid());
        model.setRemark(aidSchemeMap.getRemark());
        model.setActiveFlag(aidSchemeMap.getActiveFlag());
        model.setId(aidSchemeMap.getId());

        return model;

    }

    public static AidSchemeMap getAidSchemeMap(AidSchemeModel model) {

        AidSchemeMap aidSchemeMap = new AidSchemeMap();
        aidSchemeMap.setTargetId(model.getTargetId());
        aidSchemeMap.setEntityId(model.getEntityId());
        aidSchemeMap.setAid(model.getAid());
        aidSchemeMap.setRemark(model.getRemark());
        aidSchemeMap.setActiveFlag(model.getActiveFlag());
        aidSchemeMap.setId(model.getId());
        return aidSchemeMap;

    }

    public static void updateAidEntity(AidSchemeModel model,AidSchemeMap aidSchemeMap ) {

        aidSchemeMap.setTargetId(model.getTargetId());
        aidSchemeMap.setEntityId(model.getEntityId());
        aidSchemeMap.setAid(model.getAid());
        aidSchemeMap.setRemark(model.getRemark());
        aidSchemeMap.setActiveFlag(model.getActiveFlag());
        aidSchemeMap.setId(model.getId());
        //entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());

    }

}
