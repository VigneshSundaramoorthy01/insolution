package com.isg.mw.bn.dao.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.mw.core.model.constants.ValidationStatus;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author akshay3978
 *
 */
@Getter
@Setter
@Entity
@Table(name = "BIN_INFO_FILE_ENTITY")
public class BinInfoFileEntity {
	/**
	 * Auto generated id.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long Id;

	/**
	 * File name.
	 */
	@Column(name = "FILE_NAME", length = 80)
	private String fileName;

	/**
	 * remote file
	 */
	@Column(name = "REMOTE_FILE")
	private Boolean remoteFile;

	/**
	 * Scheme name from file name.
	 */
	@Column(name = "SCHEME_NAME", length = 25)
	private String schemeName;

	/**
	 * Date from file name.
	 */
	@Column(name = "DATE_STR", length = 8)
	private String dateStr;

	/**
	 * Sequence number from file name.
	 */
	@Column(name = "SEQUENCE_NUMBER")
	private int sequenceNumber;

	/**
	 * File name validation status Success / Failed.
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "FILE_NAME_VALIDATION", length = 8)
	private ValidationStatus fileNameValidation;

	/**
	 * Total records read from file.
	 */
	@Column(name = "TOTAL_RECORDS")
	private int totalRecords;

	/**
	 * Failed count while parsing the file record.
	 */
	@Column(name = "PARSING_FAILED_COUNT")
	private int parsingFailedCount;

	/**
	 * Failed count while insert in db.
	 */
	@Column(name = "SAVE_FAILED_COUNT")
	private int saveFailedCount;

	/**
	 * Failed count while insert in db.
	 */
	@Column(name = "ADD_COUNT")
	private int addCount;

	/**
	 * Failed count while insert in db.
	 */
	@Column(name = "UPDATE_COUNT")
	private int updateCount;

	/**
	 * Time stamp of parsing file.
	 */
	@Column(name = "CREATED_AT")
	private LocalDateTime createdAt;

	/**
	 * Failure reason.
	 */
	@Column(name = "FAILURE_REASON", length = 200)
	private String failureReason;

}
