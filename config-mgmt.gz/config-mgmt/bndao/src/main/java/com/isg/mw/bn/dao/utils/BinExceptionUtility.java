package com.isg.mw.bn.dao.utils;

import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinInfoModel;

public class BinExceptionUtility {


    private BinExceptionUtility() {

    }

    public static BinExceptionsModel getBinExceptionModel(BinExceptions entity) {

        BinExceptionsModel model = new BinExceptionsModel();
        model.setSchemeName(entity.getSchemeName());
        model.setBinNumber(entity.getBinNumber());
        model.setBinLow(entity.getBinLow());
        model.setBinHigh(entity.getBinHigh());
        model.setCardCategory(entity.getCardCategory());
        model.setCardProgram(entity.getCardProgram());
        model.setCardBrand(entity.getCardBrand());
        model.setCountryCodeN(entity.getCountryCodeN());
        model.setCountryCodeA(entity.getCountryCodeA());
        model.setActiveFlag(entity.getActiveFlag());
        model.setLofo(entity.getLofo());
//        model.setCreatedAt(entity.getCreatedAt());
//        model.setUpdatedAt(entity.getUpdatedAt());
        model.setTargetId(entity.getTargetId());
        model.setId(entity.getId());
        model.setLeastCostActiveFlag(entity.getLeastCostActiveFlag());
        return model;

    }

    public static BinExceptions getBinException(BinExceptionsModel model) {

        BinExceptions entity = new BinExceptions();
        entity.setSchemeName(model.getSchemeName());
        entity.setBinNumber(model.getBinNumber());
        entity.setBinLow(model.getBinLow());
        entity.setBinHigh(model.getBinHigh());
        entity.setCardCategory(model.getCardCategory());
        entity.setCardProgram(model.getCardProgram());
        entity.setCardBrand(model.getCardBrand());
        entity.setCountryCodeN(model.getCountryCodeN());
        entity.setCountryCodeA(model.getCountryCodeA());
        entity.setActiveFlag(model.getActiveFlag());
        entity.setLofo(model.getLofo());
        entity.setTargetId(model.getTargetId());
        entity.setId(model.getId());
        entity.setLeastCostActiveFlag(model.getLeastCostActiveFlag());
        //entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
        return entity;

    }

    public static void updateBinException(BinExceptionsModel model, BinExceptions entity) {

        entity.setSchemeName(model.getSchemeName());
        entity.setBinNumber(model.getBinNumber());
        entity.setBinLow(model.getBinLow());
        entity.setBinHigh(model.getBinHigh());
        entity.setCardCategory(model.getCardCategory());
        entity.setCardProgram(model.getCardProgram());
        entity.setCardBrand(model.getCardBrand());
        entity.setCountryCodeN(model.getCountryCodeN());
        entity.setCountryCodeA(model.getCountryCodeA());
        entity.setActiveFlag(model.getActiveFlag());
        entity.setLofo(model.getLofo());
        entity.setTargetId(model.getTargetId());
        entity.setLeastCostActiveFlag(model.getLeastCostActiveFlag());
        //entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());

    }

}
