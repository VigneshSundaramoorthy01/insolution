package com.isg.mw.bn.dao.service.impl;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.bn.dao.entities.RateLookupEntity;
import com.isg.mw.bn.dao.repository.RateLookupRepository;
import com.isg.mw.bn.dao.service.RateLookupService;
import com.isg.mw.bn.dao.utils.RateLookupUtility;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.constants.ActiveFlag;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.stream.Collectors;



@Service
public class RateLookupServiceImpl implements RateLookupService {

	private final Logger logger = LogManager.getLogger(getClass());

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private RateLookupRepository rateLookupRepository;


	@Override
	public boolean save(RateLookupModel rateLookupModel) {
		boolean saved = false;
		try {
			RateLookupEntity RateEntity = RateLookupUtility.getRateLookupEntity(rateLookupModel);
			rateLookupRepository.save(RateEntity);
			saved = true;
		} catch (Exception ex) {
			logger.error("Error while inserting request/response to the database -> {}", ex);
		}
		return saved;
	}

	@Override
	public List<RateLookupModel> getdata(ActiveFlag status) {
		List<RateLookupEntity> allData = rateLookupRepository.findByDccTxnCurrencyStatus(status);
		List<RateLookupModel> models = allData.stream().map(rateLookUp -> RateLookupUtility.getRateLookupModel(rateLookUp))
												.collect(Collectors.toList());
		return models;
	}

}