package com.isg.mw.bn.dao.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.isg.mw.bn.dao.constants.BinInfoDaoMsgKeys;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.bn.dao.repository.BinInfoRepository;
import com.isg.mw.bn.dao.service.BinInfoService;
import com.isg.mw.bn.dao.utils.BinInfoUtility;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.LOFO;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.constants.Tokenize;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;

/**
 * @author sanchita3984
 */
@Service("binInfoService")
public class BinInfoServiceImpl implements BinInfoService {

	@Autowired
	private BinInfoRepository binInfoRepository;

	@Autowired
	private TargetConfigMasterService targetMasterService;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public BinInfoModel add(BinInfoEntity entity) {
		BinInfoEntity binEntity = binInfoRepository.save(entity);
		return BinInfoUtility.getBinModel(binEntity);
	}

	@Override
	public BinInfoModel modify(BinInfoEntity entity) {
		BinInfoEntity savedEntity = binInfoRepository.save(entity);
		return BinInfoUtility.getBinModel(savedEntity);
	}

	@Override
	public void loadAll(List<BinInfoEntity> entities) {
		binInfoRepository.saveAll(entities);
	}

	@Override
	public BinInfoEntity get(String schemeName, BigInteger binNumber, BigInteger binLow, BigInteger binHigh) {
		return binInfoRepository.findByBinSchemeNameAndNumber(schemeName, binNumber, binLow, binHigh);
	}

	@Override
	public BinInfoEntity get(String schemeName, BigInteger binLow, BigInteger binHigh, BigInteger binNumber, String cardCategory, String cardProgram, String cardBrand, String countryCodeN, String countryCodeA, LOFO lofo) {
		List<BinInfoEntity> entityList = binInfoRepository.findBySchemeNameAndNumber(schemeName, binLow, binHigh, binNumber, cardCategory, cardProgram, cardBrand, countryCodeN, countryCodeA, lofo);
		if(entityList.size() > 1){
			entityList = entityList.stream().filter(binInfoEntity -> binInfoEntity.equals(getBinEntity(schemeName, binLow, binHigh, binNumber, cardCategory, cardProgram, cardBrand, countryCodeN, countryCodeA, lofo))).collect(Collectors.toList());
		}
		if(CollectionUtils.isEmpty(entityList)){
			return null;
		}
		return entityList.get(0);
	}

	private BinInfoEntity getBinEntity(String schemeName, BigInteger binLow, BigInteger binHigh, BigInteger binNumber, String cardCategory, String cardProgram, String cardBrand, String countryCodeN, String countryCodeA, LOFO lofo) {
		BinInfoEntity entity = new BinInfoEntity();
		entity.setSchemeName(schemeName);
		entity.setBinLow(binLow);
		entity.setBinHigh(binHigh);
		entity.setBinNumber(binNumber);
		entity.setCardCategory(cardCategory);
		entity.setCardProgram(cardProgram);
		entity.setCardBrand(cardBrand);
		entity.setCountryCodeN(countryCodeN);
		entity.setCountryCodeA(countryCodeA);
		entity.setLofo(lofo);
		return entity;
	}


	@Override
	public Map<String, List<BinInfoModel>> getAllasMap() {

		List<String> schemeNames = binInfoRepository.getSchemeNames();
		Map<String, List<BinInfoModel>> bins = null;
		if (schemeNames != null && !schemeNames.isEmpty()) {

			bins = new HashMap<>(schemeNames.size());
			for (String schemeName : schemeNames) {
				bins.put(schemeName, new ArrayList<>());
			}

			List<BinInfoEntity> entities = binInfoRepository.getAll(ActiveFlag.Y);
			for (BinInfoEntity entity : entities) {
				bins.get(entity.getSchemeName()).add(BinInfoUtility.getBinModel(entity));
			}

		}
		return bins;
	}

	@Override
	public List<BinInfoModel> getAll(ActiveFlag activeFlag, Integer pageNo, Integer pageSize) {
		List<BinInfoModel> models;
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<BinInfoEntity> cq = cb.createQuery(BinInfoEntity.class);
		Root<BinInfoEntity> td = cq.from(BinInfoEntity.class);
		List<Predicate> predicates = getBinRecordPredicates(cb, cq, td, activeFlag);
		cq.where(predicates.toArray(new Predicate[] {}));

		List<Order> orderBy = new ArrayList<>();
		orderBy.add(cb.asc(td.get("id")));
		cq.orderBy(orderBy);

		TypedQuery<BinInfoEntity> query = entityManager.createQuery(cq);
		if (pageNo != null) {
			query.setFirstResult(pageNo);
			query.setMaxResults(pageSize);
		}
		models = query.getResultList().stream().map(BinInfoUtility::getBinModel).collect(Collectors.toList());
		return models;

	}

	private List<Predicate> getBinRecordPredicates(CriteriaBuilder cb, CriteriaQuery<BinInfoEntity> cq,
			Root<BinInfoEntity> td, ActiveFlag activeFlag) {
		List<Predicate> predicates = new ArrayList<>();

		if (activeFlag != null) {
			predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
		}
		return predicates;

	}

	@Override
	public Long getBinsCount(ActiveFlag activeFlag) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<BinInfoEntity> td = cq.from(BinInfoEntity.class);
		cq.select(cb.count(td));
		List<Predicate> predicates = null;
		predicates = getBinCountPredicates(cb, cq, td, activeFlag);
		cq.where(predicates.toArray(new Predicate[] {}));
		return entityManager.createQuery(cq).getSingleResult();
	}

	private List<Predicate> getBinCountPredicates(CriteriaBuilder cb, CriteriaQuery<Long> cq, Root<BinInfoEntity> td,
			ActiveFlag activeFlag) {
		List<Predicate> predicates = new ArrayList<>();

		if (activeFlag != null) {
			predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
		}
		return predicates;
	}

	@Override
	public List<BinInfoModel> getAllBinOnus(ActiveFlag activFlag, Integer pageNo, Integer pageSize) {
		List<BinInfoModel> models;
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<BinInfoEntity> cq = cb.createQuery(BinInfoEntity.class);
		Root<BinInfoEntity> td = cq.from(BinInfoEntity.class);
		List<Predicate> predicates = getBinRecordPredicates(cb, cq, td, activFlag);
		cq.where(predicates.toArray(new Predicate[] {}));

		List<Order> orderBy = new ArrayList<>();
		orderBy.add(cb.asc(td.get("id")));
		cq.orderBy(orderBy);

		TypedQuery<BinInfoEntity> query = entityManager.createQuery(cq);
		if (pageNo != null) {
			query.setFirstResult(pageNo);
			query.setMaxResults(pageSize);
		}
		models = query.getResultList().stream().map(bin -> getBinOnusModel(BinInfoUtility.getBinModel(bin)))
				.collect(Collectors.toList());
		return models;
	}

	private BinInfoModel getBinOnusModel(BinInfoModel binInfoModel) {
		if (binInfoModel.getTargetId() != null) {
			String targetName = targetMasterService.findNameByIdAndEntityId(Long.parseLong(binInfoModel.getTargetId()));
			binInfoModel.setTargetName(targetName);
		}
		return binInfoModel;
	}

	@Override
	public BinInfoEntity updateTargetId(BigInteger binNumber, String targetName) {
		BinInfoEntity entity = binInfoRepository.findByBinNumber(binNumber);
		if (targetName == null) {
			entity.setTargetId(null);
		} else if (entity != null) {
			TargetConfigMasterEntity configMasterEntity = targetMasterService.findByName(targetName);
			if (configMasterEntity != null && configMasterEntity.getTarget() == Target.Issuer) {
				entity.setTargetId(configMasterEntity.getId() != null ? configMasterEntity.getId().toString() : null);
			} else {
				throw new ValidationException(BinInfoDaoMsgKeys.BIN_TARGET_NOT_EXITS, targetName);
			}
		}
		return entity;
	}

	@Override
	public BinInfoModel getBinInfoByBinNo(BigInteger binNo) {
		BinInfoEntity binInfoEntity = binInfoRepository.findByBinNo(binNo);
		BinInfoModel binModel = null;
		if (binInfoEntity != null) {
			binModel = BinInfoUtility.getBinModel(binInfoEntity);
		}
		return binModel;
	}

	@Override
	public Long serachBinCount(String data) {
		Boolean isNumber = findDataIsNumber(data);
		if (isNumber) {
			BigInteger number = new BigInteger(data);
			return binInfoRepository.findBySearchCount(number, null);
		} else {
			String validScheme = getValidScheme(data);
			return binInfoRepository.findBySearchCount(BigInteger.ZERO, validScheme);
		}
	}

	private Boolean findDataIsNumber(String data) {
		try {
			Integer.parseInt(data);
		} catch (NumberFormatException e) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;

	}

	@Override
	public List<BinInfoModel> serachBinData(String data) {
		List<BinInfoModel> bininfoList = new ArrayList<>();
		List<BinInfoEntity> binInfoEntityList = new ArrayList<>();
		Boolean isNumber = findDataIsNumber(data);
		if (isNumber) {
			BigInteger number = new BigInteger(data);
			binInfoEntityList = binInfoRepository.findBySearchData(number, null);
		} else {
			String validScheme = getValidScheme(data);
			binInfoEntityList = binInfoRepository.findBySearchData(BigInteger.ZERO, validScheme);
		}
		if (binInfoEntityList != null) {
			for (BinInfoEntity binInfoEntity : binInfoEntityList) {
				BinInfoModel binModel = BinInfoUtility.getBinModel(binInfoEntity);
				bininfoList.add(binModel);
			}
		}
		return bininfoList;
	}

	private String getValidScheme(String data) {
		String firstLetStr = data.substring(0, 1);
		String remLetStr = data.substring(1);
		firstLetStr = firstLetStr.toUpperCase();
		remLetStr = remLetStr.toLowerCase();
		return firstLetStr + remLetStr;
	}

	@Override
	public boolean getBinByTokenizedFlag(String data) {
		Boolean isNumber = findDataIsNumber(data);
		if (isNumber) {
			BigInteger number = new BigInteger(data);

			BinInfoEntity binInfoEntity = binInfoRepository.findByTokenizeFlag(Tokenize.N, number);
			if (binInfoEntity != null)
				return true;
		}
		return false;
	}
}
