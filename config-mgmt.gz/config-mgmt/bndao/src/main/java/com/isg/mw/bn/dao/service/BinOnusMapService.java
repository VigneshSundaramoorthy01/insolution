package com.isg.mw.bn.dao.service;

import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

public interface BinOnusMapService {
    BinOnusModel add(BinOnusMap binOnusMap);

    BinOnusModel modify(BinOnusMap binOnusMap);

    BinOnusMap get(String schemeName, BigInteger binNumber, BigInteger binLow, BigInteger binHigh);


    Map<String, List<BinOnusModel>> getAllasMap();

    List<BinOnusModel> getAll(ActiveFlag activeFlag,Integer pageNo,Integer pageSize);

    BinOnusMap updateTargetId(BigInteger binNumber, String targetName);

    BinOnusMap get(String schemeName,BigInteger binLow, BigInteger binHigh);

    Long getBinsCount(ActiveFlag activeFlag);

    BinOnusModel getBinyBinNo(BigInteger binNo);

    Long serachBinCount(String data);

    List<BinOnusModel> serachBinData(String data);

    void loadAll(List<BinOnusMap> addOrUpdateBinInfoModel);
}
