package com.isg.mw.bn.dao.service;

import java.util.List;

import com.isg.mw.core.model.bi.BillingCurrencyModel;

public interface BillingCurrencyService {
	
	public boolean save(BillingCurrencyModel requestModel);

    public List<BillingCurrencyModel> getdata();

}
