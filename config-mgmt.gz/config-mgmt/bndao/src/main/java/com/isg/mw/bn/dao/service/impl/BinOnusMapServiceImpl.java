package com.isg.mw.bn.dao.service.impl;

import com.isg.mw.bn.dao.constants.BinInfoDaoMsgKeys;
import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.bn.dao.repository.BinInfoRepository;
import com.isg.mw.bn.dao.repository.BinOnusMapRepository;
import com.isg.mw.bn.dao.service.BinOnusMapService;
import com.isg.mw.bn.dao.utils.BinExceptionUtility;
import com.isg.mw.bn.dao.utils.BinOnusMapUtility;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BinOnusMapServiceImpl implements BinOnusMapService {


    @Autowired
    private BinOnusMapRepository binOnusMapRepository;

    @Autowired
    private TargetConfigMasterService targetMasterService;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public BinOnusModel add(BinOnusMap binOnusMap) {
        BinOnusMap binOnusMap1 = binOnusMapRepository.save(binOnusMap);
        return BinOnusMapUtility.getBinOnusModel(binOnusMap1);
    }

    @Override
    public BinOnusModel modify(BinOnusMap binOnusMap) {
        BinOnusMap binOnusMap1 = binOnusMapRepository.save(binOnusMap);
        return BinOnusMapUtility.getBinOnusModel(binOnusMap1);
    }

    @Override
    public BinOnusMap get(String schemeName, BigInteger binNumber, BigInteger binLow, BigInteger binHigh) {
        return binOnusMapRepository.findByBinSchemeNameAndNumber(schemeName, binNumber, binLow, binHigh);
    }

    @Override
    public Map<String, List<BinOnusModel>> getAllasMap() {

        List<String> schemeNames = binOnusMapRepository.getSchemeNames();
        Map<String, List<BinOnusModel>> bins = null;
        if (schemeNames != null && !schemeNames.isEmpty()) {

            bins = new HashMap<>(schemeNames.size());
            for (String schemeName : schemeNames) {
                bins.put(schemeName, new ArrayList<>());
            }

            List<BinOnusMap> entities = binOnusMapRepository.getAll(ActiveFlag.Y);
            for (BinOnusMap entity : entities) {
                bins.get(entity.getSchemeName()).add(BinOnusMapUtility.getBinOnusModel(entity));
            }

        }
        return bins;
    }

    @Override
    public List<BinOnusModel> getAll(ActiveFlag activeFlag, Integer pageNo, Integer pageSize) {

        List<BinOnusModel> models;
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<BinOnusMap> cq = cb.createQuery(BinOnusMap.class);
        Root<BinOnusMap> td = cq.from(BinOnusMap.class);
        List<Predicate> predicates = getBinRecordPredicates(cb, cq, td, activeFlag);
        cq.where(predicates.toArray(new Predicate[] {}));

        List<Order> orderBy = new ArrayList<>();
        orderBy.add(cb.asc(td.get("id")));
        cq.orderBy(orderBy);

        TypedQuery<BinOnusMap> query = entityManager.createQuery(cq);
        if (pageNo != null) {
            query.setFirstResult(pageNo);
            query.setMaxResults(pageSize);
        }
        models = query.getResultList().stream().map(BinOnusMapUtility::getBinOnusModel).collect(Collectors.toList());
        return models;

    }

    private List<Predicate> getBinRecordPredicates(CriteriaBuilder cb, CriteriaQuery<BinOnusMap> cq,
                                                   Root<BinOnusMap> td, ActiveFlag activeFlag) {
        List<Predicate> predicates = new ArrayList<>();

        if (activeFlag != null) {
            predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
        }
        return predicates;

    }
    @Override
    public BinOnusMap updateTargetId(BigInteger binNumber, String targetName) {
        BinOnusMap entity = binOnusMapRepository.findByBinNumber(binNumber);
        BinOnusModel model = null;
        if (targetName == null) {
            entity.setTargetId(null);
        } else if (entity != null) {
            TargetConfigMasterEntity configMasterEntity = targetMasterService.findByName(targetName);
            if (configMasterEntity != null && configMasterEntity.getTarget() == Target.Issuer) {
                entity.setTargetId(configMasterEntity.getId() != null ? configMasterEntity.getId().toString() : null);
            } else {
                throw new ValidationException(BinInfoDaoMsgKeys.BIN_TARGET_NOT_EXITS, targetName);
            }
        }
        return entity;
    }

    @Override
    public BinOnusMap get(String schemeName, BigInteger binLow, BigInteger binHigh) {
        return null;
    }

    @Override
    public Long getBinsCount(ActiveFlag activeFlag) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<BinOnusMap> td = cq.from(BinOnusMap.class);
        cq.select(cb.count(td));
        List<Predicate> predicates = null;
        predicates = getBinCountPredicates(cb, cq, td, activeFlag);
        cq.where(predicates.toArray(new Predicate[] {}));
        return entityManager.createQuery(cq).getSingleResult();
    }

    private List<Predicate> getBinCountPredicates(CriteriaBuilder cb, CriteriaQuery<Long> cq, Root<BinOnusMap> td,
                                                  ActiveFlag activeFlag) {
        List<Predicate> predicates = new ArrayList<>();

        if (activeFlag != null) {
            predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
        }
        return predicates;
    }

    @Override
    public BinOnusModel getBinyBinNo(BigInteger binNo) {
        BinOnusMap binOnusMap = binOnusMapRepository.findByBinNo(binNo);
        BinOnusModel binModel = null;
        if (binOnusMap != null) {
            binModel = BinOnusMapUtility.getBinOnusModel(binOnusMap);
        }
        return binModel;
    }

    @Override
    public Long serachBinCount(String data) {
        Boolean isNumber = findDataIsNumber(data);
        if (isNumber) {
            BigInteger number = new BigInteger(data);
            return binOnusMapRepository.findBySearchCount(number, null);
        } else {
            String validScheme = getValidScheme(data);
            return binOnusMapRepository.findBySearchCount(BigInteger.ZERO, validScheme);
        }
    }

    private Boolean findDataIsNumber(String data) {
        try {
            Integer.parseInt(data);
        } catch (NumberFormatException e) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;

    }


    @Override
    public List<BinOnusModel> serachBinData(String data) {
        List<BinOnusModel> bininfoList = new ArrayList<>();
        List<BinOnusMap> BinExceptionsList = new ArrayList<>();
        Boolean isNumber = findDataIsNumber(data);
        if (isNumber) {
            BigInteger number = new BigInteger(data);
            BinExceptionsList = binOnusMapRepository.findBySearchData(number, null);
        } else {
            String validScheme = getValidScheme(data);
            BinExceptionsList = binOnusMapRepository.findBySearchData(BigInteger.ZERO, validScheme);
        }
        if (BinExceptionsList != null) {
            for (BinOnusMap binOnusMap : BinExceptionsList) {
                BinOnusModel binModel = BinOnusMapUtility.getBinOnusModel(binOnusMap);
                bininfoList.add(binModel);
            }
        }
        return bininfoList;
    }

    private String getValidScheme(String data) {
        String firstLetStr = data.substring(0, 1);
        String remLetStr = data.substring(1);
        firstLetStr = firstLetStr.toUpperCase();
        remLetStr = remLetStr.toLowerCase();
        return firstLetStr + remLetStr;
    }


    @Override
    public void loadAll(List<BinOnusMap> addOrUpdateBinInfoModel) {
        binOnusMapRepository.saveAll(addOrUpdateBinInfoModel);
    }

}
