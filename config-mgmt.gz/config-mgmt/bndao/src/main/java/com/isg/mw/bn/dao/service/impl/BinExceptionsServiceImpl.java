package com.isg.mw.bn.dao.service.impl;

import com.isg.mw.bn.dao.constants.BinInfoDaoMsgKeys;
import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.bn.dao.repository.BinExceptionsRepository;
import com.isg.mw.bn.dao.repository.BinInfoRepository;
import com.isg.mw.bn.dao.service.BinExceptionsService;
import com.isg.mw.bn.dao.utils.BinExceptionUtility;
import com.isg.mw.bn.dao.utils.BinInfoUtility;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BinExceptionsServiceImpl implements BinExceptionsService {

    @Autowired
    private BinExceptionsRepository binExceptionsRepository;

    @Autowired
    private TargetConfigMasterService targetMasterService;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public BinExceptionsModel add(BinExceptions entity) {
        BinExceptions binExceptions = binExceptionsRepository.save(entity);
        return BinExceptionUtility.getBinExceptionModel(binExceptions);
    }

    @Override
    public BinExceptionsModel modify(BinExceptions entity) {
        BinExceptions savedEntity = binExceptionsRepository.save(entity);
        return BinExceptionUtility.getBinExceptionModel(savedEntity);
    }

    @Override
    public void loadAll(List<BinExceptions> entities) {
        binExceptionsRepository.saveAll(entities);
    }

    @Override
    public BinExceptions get(String schemeName, BigInteger binNumber, BigInteger binLow, BigInteger binHigh) {
        return binExceptionsRepository.findByBinSchemeNameAndNumber(schemeName, binNumber, binLow, binHigh);
    }

    @Override
    public BinExceptions get(String schemeName, BigInteger binLow, BigInteger binHigh) {
        return binExceptionsRepository.findBySchemeNameAndNumber(schemeName, binLow, binHigh);
    }

    @Override
    public Map<String, List<BinExceptionsModel>> getAllasMap() {

        List<String> schemeNames = binExceptionsRepository.getSchemeNames();
        Map<String, List<BinExceptionsModel>> bins = null;
        if (schemeNames != null && !schemeNames.isEmpty()) {

            bins = new HashMap<>(schemeNames.size());
            for (String schemeName : schemeNames) {
                bins.put(schemeName, new ArrayList<>());
            }

            List<BinExceptions> entities = binExceptionsRepository.getAll(ActiveFlag.Y);
            for (BinExceptions entity : entities) {
                bins.get(entity.getSchemeName()).add(BinExceptionUtility.getBinExceptionModel(entity));
            }

        }
        return bins;
    }

    @Override
    public List<BinExceptionsModel> getAll(ActiveFlag activeFlag, Integer pageNo, Integer pageSize) {
        List<BinExceptionsModel> models;
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<BinExceptions> cq = cb.createQuery(BinExceptions.class);
        Root<BinExceptions> td = cq.from(BinExceptions.class);
        List<Predicate> predicates = getBinRecordPredicates(cb, cq, td, activeFlag);
        cq.where(predicates.toArray(new Predicate[] {}));

        List<Order> orderBy = new ArrayList<>();
        orderBy.add(cb.asc(td.get("id")));
        cq.orderBy(orderBy);

        TypedQuery<BinExceptions> query = entityManager.createQuery(cq);
        if (pageNo != null) {
            query.setFirstResult(pageNo);
            query.setMaxResults(pageSize);
        }
        models = query.getResultList().stream().map(BinExceptionUtility::getBinExceptionModel).collect(Collectors.toList());
        return models;

    }

    private List<Predicate> getBinRecordPredicates(CriteriaBuilder cb, CriteriaQuery<BinExceptions> cq,
                                                   Root<BinExceptions> td, ActiveFlag activeFlag) {
        List<Predicate> predicates = new ArrayList<>();

        if (activeFlag != null) {
            predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
        }
        return predicates;

    }

    @Override
    public Long getBinsCount(ActiveFlag activeFlag) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<BinExceptions> td = cq.from(BinExceptions.class);
        cq.select(cb.count(td));
        List<Predicate> predicates = null;
        predicates = getBinCountPredicates(cb, cq, td, activeFlag);
        cq.where(predicates.toArray(new Predicate[] {}));
        return entityManager.createQuery(cq).getSingleResult();
    }

    private List<Predicate> getBinCountPredicates(CriteriaBuilder cb, CriteriaQuery<Long> cq, Root<BinExceptions> td,
                                                  ActiveFlag activeFlag) {
        List<Predicate> predicates = new ArrayList<>();

        if (activeFlag != null) {
            predicates.add(cb.equal(td.get("activeFlag"), activeFlag));
        }
        return predicates;
    }


    @Override
    public BinExceptions updateTargetId(BigInteger binNumber, String targetName) {
        BinExceptions entity = binExceptionsRepository.findByBinNumber(binNumber);
        BinExceptionsModel model = null;
        if (targetName == null) {
            entity.setTargetId(null);
        } else if (entity != null) {
            TargetConfigMasterEntity configMasterEntity = targetMasterService.findByName(targetName);
            if (configMasterEntity != null && configMasterEntity.getTarget() == Target.Issuer) {
                entity.setTargetId(configMasterEntity.getId() != null ? configMasterEntity.getId().toString() : null);
            } else {
                throw new ValidationException(BinInfoDaoMsgKeys.BIN_TARGET_NOT_EXITS, targetName);
            }
        }
        return entity;
    }

    @Override
    public BinExceptionsModel getBinyBinNo(BigInteger binNo) {
        BinExceptions binExceptions = binExceptionsRepository.findByBinNo(binNo);
        BinExceptionsModel binModel = null;
        if (binExceptions != null) {
            binModel = BinExceptionUtility.getBinExceptionModel(binExceptions);
        }
        return binModel;
    }

    @Override
    public Long serachBinCount(String data) {
        Boolean isNumber = findDataIsNumber(data);
        if (isNumber) {
            BigInteger number = new BigInteger(data);
            return binExceptionsRepository.findBySearchCount(number, null);
        } else {
            String validScheme = getValidScheme(data);
            return binExceptionsRepository.findBySearchCount(BigInteger.ZERO, validScheme);
        }
    }

    private Boolean findDataIsNumber(String data) {
        try {
            Integer.parseInt(data);
        } catch (NumberFormatException e) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;

    }

    @Override
    public List<BinExceptionsModel> serachBinData(String data) {
        List<BinExceptionsModel> bininfoList = new ArrayList<>();
        List<BinExceptions> BinExceptionsList = new ArrayList<>();
        Boolean isNumber = findDataIsNumber(data);
        if (isNumber) {
            BigInteger number = new BigInteger(data);
            BinExceptionsList = binExceptionsRepository.findBySearchData(number, null);
        } else {
            String validScheme = getValidScheme(data);
            BinExceptionsList = binExceptionsRepository.findBySearchData(BigInteger.ZERO, validScheme);
        }
        if (BinExceptionsList != null) {
            for (BinExceptions BinExceptions : BinExceptionsList) {
                BinExceptionsModel binModel = BinExceptionUtility.getBinExceptionModel(BinExceptions);
                bininfoList.add(binModel);
            }
        }
        return bininfoList;
    }

    private String getValidScheme(String data) {
        String firstLetStr = data.substring(0, 1);
        String remLetStr = data.substring(1);
        firstLetStr = firstLetStr.toUpperCase();
        remLetStr = remLetStr.toLowerCase();
        return firstLetStr + remLetStr;
    }

}
