package com.isg.mw.bn.dao.entities;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;
import com.isg.mw.core.model.constants.ActiveFlag;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Entity
@Getter
@Setter
@Table(name = "RATE_LOOKUP")
public class RateLookupEntity  extends AuditInfoEntity{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

    @Column(name = "DCC_TXN_ISO_CURRENCY_CODE", length = 3)
    private Integer dccTxnIsoCurrencyCode;
    
    @Column(name = "ENTITY_ID")
    private String entityId;

    @Column(name = "DCC_EXCHANGE_RATE", length = 12)
    private Double dccExchangeRate;

    @Column(name = "DCC_TXN_ISO_CURRENCY", length = 3)
    private String dccTxnIsoCurrency;

    @Column(name = "DCC_NO_OF_DECIMALS", length = 1)
    private Integer dccNoOfDecimals;
    
    @Column(name = "EXCHANGE_RATE_RECORD_CREATION_TIME")
    private OffsetDateTime exchangeRateRecordCreationTime;
    		
    @Column(name = "EXCHANGE_RATE_EXPIRE_DATE_AND_TIME")
    private OffsetDateTime exchangeRateExpiredateAndTime;//[Numeric, DDMMYYYYHH24MMSS]
    				
    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    private ActiveFlag status; // (Active, Inactive) [Alphabetic, 1]
    				
    @Column(name = "REMARKS")
    private String remarks;
    

}

