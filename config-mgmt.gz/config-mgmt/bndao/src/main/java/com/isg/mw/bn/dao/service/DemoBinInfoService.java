package com.isg.mw.bn.dao.service;

import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.tc.TargetConfigModel;

import java.util.List;

public interface DemoBinInfoService {

    public List<BinInfoModel> getAllBins();

    List<BinInfoModel> saveTargetId(TargetConfigModel configModel);

}
