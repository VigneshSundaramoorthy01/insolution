package com.isg.mw.bn.dao.service;

import java.util.List;

import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.constants.ActiveFlag;

public interface RateLookupService {

    public boolean save(RateLookupModel requestModel);

    public List<RateLookupModel> getdata(ActiveFlag status);
}
