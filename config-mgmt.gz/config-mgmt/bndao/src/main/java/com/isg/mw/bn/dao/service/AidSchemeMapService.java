package com.isg.mw.bn.dao.service;

import com.isg.mw.bn.dao.entities.AidSchemeMap;
import com.isg.mw.bn.dao.entities.BinExceptions;
import com.isg.mw.bn.dao.entities.BinOnusMap;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.constants.ActiveFlag;

import java.math.BigInteger;
import java.util.List;

public interface AidSchemeMapService {

    AidSchemeModel add(AidSchemeMap aidSchemeMap);

    AidSchemeModel modify(AidSchemeMap aidSchemeMap);
    AidSchemeMap get(String aid,ActiveFlag activeFlag);

    List<AidSchemeMap> get( BigInteger targetId,ActiveFlag activeFlag);
    Long getAidsCount(ActiveFlag activeFlag);

    List<AidSchemeModel> getAll(ActiveFlag activeFlag, Integer pageNo, Integer pageSize);
}
