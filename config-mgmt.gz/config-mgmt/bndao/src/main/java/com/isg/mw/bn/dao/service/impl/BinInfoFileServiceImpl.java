
package com.isg.mw.bn.dao.service.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.bn.dao.entities.BinInfoFileEntity;
import com.isg.mw.bn.dao.repository.BinInfoFileRepository;
import com.isg.mw.bn.dao.service.BinInfoFileService;
import com.isg.mw.core.model.constants.ValidationStatus;

/**
 * 
 * @author sanchita3984
 *
 */
@Service("binInfoFileService")
public class BinInfoFileServiceImpl implements BinInfoFileService {

	@Autowired
	private BinInfoFileRepository binInfoFileRepository;

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public BinInfoFileEntity add(BinInfoFileEntity entity) {
		return binInfoFileRepository.save(entity);
	}

	@Override
	public BinInfoFileEntity getLatestSuccess(String schemeName) {
		
		List<BinInfoFileEntity> bs = entityManager.createQuery("SELECT bie FROM BinInfoFileEntity bie "
				+ "WHERE bie.schemeName = :schemeName AND bie.fileNameValidation = :status ORDER BY bie.createdAt DESC ", 
				BinInfoFileEntity.class)
				.setParameter("schemeName", schemeName)
				.setParameter("status", ValidationStatus.Success)
				.setMaxResults(1)
				.getResultList();
		
		BinInfoFileEntity entity = null;
		if(bs != null && !bs.isEmpty()) {
			entity = bs.get(0);
		}
		return entity;
		
	}

}
