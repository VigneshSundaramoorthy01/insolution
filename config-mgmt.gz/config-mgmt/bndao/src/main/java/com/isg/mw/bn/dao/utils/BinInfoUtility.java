package com.isg.mw.bn.dao.utils;

import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.core.model.bi.BinInfoModel;

/**
 * 
 * @author sanchita3984
 *
 */
public class BinInfoUtility {

	private BinInfoUtility() {

	}

	public static BinInfoModel getBinModel(BinInfoEntity entity) {

		BinInfoModel model = new BinInfoModel();
		model.setSchemeName(entity.getSchemeName());
		model.setBinNumber(entity.getBinNumber());
		model.setBinLow(entity.getBinLow());
		model.setBinHigh(entity.getBinHigh());
		model.setCardCategory(entity.getCardCategory());
		model.setCardProgram(entity.getCardProgram());
		model.setCardBrand(entity.getCardBrand());
		model.setCountryCodeN(entity.getCountryCodeN());
		model.setCountryCodeA(entity.getCountryCodeA());
		model.setActiveFlag(entity.getActiveFlag());
		model.setLofo(entity.getLofo());
		model.setCreatedAt(entity.getCreatedAt());
		model.setUpdatedAt(entity.getUpdatedAt());
		model.setTargetId(entity.getTargetId());
		model.setId(entity.getId());
		model.setLeastCostActiveFlag(entity.getLeastCostActiveFlag());
		model.setTokenize(entity.getTokenize());
		model.setBatchNumber(entity.getBatchNumber());
		return model;

	}

	public static BinInfoEntity getBinEntity(BinInfoModel model) {

		BinInfoEntity entity = new BinInfoEntity();
		entity.setSchemeName(model.getSchemeName());
		entity.setBinNumber(model.getBinNumber());
		entity.setBinLow(model.getBinLow());
		entity.setBinHigh(model.getBinHigh());
		entity.setCardCategory(model.getCardCategory());
		entity.setCardProgram(model.getCardProgram());
		entity.setCardBrand(model.getCardBrand());
		entity.setCountryCodeN(model.getCountryCodeN());
		entity.setCountryCodeA(model.getCountryCodeA());
		entity.setActiveFlag(model.getActiveFlag());
		entity.setLofo(model.getLofo());
		entity.setTargetId(model.getTargetId());
		entity.setId(model.getId());
		entity.setLeastCostActiveFlag(model.getLeastCostActiveFlag());
		//entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setTokenize(model.getTokenize());
		entity.setBatchNumber(model.getBatchNumber());
		return entity;

	}

	public static void updateBinEntity(BinInfoModel model, BinInfoEntity entity) {

		entity.setSchemeName(model.getSchemeName());
		entity.setBinNumber(model.getBinNumber());
		entity.setBinLow(model.getBinLow());
		entity.setBinHigh(model.getBinHigh());
		entity.setCardCategory(model.getCardCategory());
		entity.setCardProgram(model.getCardProgram());
		entity.setCardBrand(model.getCardBrand());
		entity.setCountryCodeN(model.getCountryCodeN());
		entity.setCountryCodeA(model.getCountryCodeA());
		entity.setActiveFlag(model.getActiveFlag());
		entity.setLofo(model.getLofo());
		entity.setTargetId(model.getTargetId());
		entity.setLeastCostActiveFlag(model.getLeastCostActiveFlag());
		//entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setTokenize(model.getTokenize());
		entity.setBatchNumber(model.getBatchNumber());
	}
}
