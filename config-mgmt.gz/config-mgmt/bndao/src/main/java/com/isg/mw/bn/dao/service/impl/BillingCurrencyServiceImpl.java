package com.isg.mw.bn.dao.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.bn.dao.entities.BillingCurrencyEntity;
import com.isg.mw.bn.dao.repository.BillingCurrencyRepository;
import com.isg.mw.bn.dao.service.BillingCurrencyService;
import com.isg.mw.bn.dao.utils.BillingCurrnecyUtility;
import com.isg.mw.core.model.bi.BillingCurrencyModel;


@Service
public class BillingCurrencyServiceImpl implements BillingCurrencyService {

	private final Logger logger = LogManager.getLogger(getClass());

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private BillingCurrencyRepository billingCurrencyRepository;


	@Override
	public boolean save(BillingCurrencyModel billingCurrencyModel) {
		boolean saved = false;
		try {
			BillingCurrencyEntity RateEntity = BillingCurrnecyUtility.getBillingCurrencyEntity(billingCurrencyModel);
			billingCurrencyRepository.save(RateEntity);
			saved = true;
		} catch (Exception ex) {
			logger.error("Error while inserting request/response to the database -> {}", ex);
		}
		return saved;
	}

	@Override
	public List<BillingCurrencyModel> getdata() {
		List<BillingCurrencyEntity> allData =  billingCurrencyRepository.findAllBillingIsoCurrency();
		List<BillingCurrencyModel> models = allData.stream().map(billingCurrency -> BillingCurrnecyUtility.getBillingCurrencyModel(billingCurrency))
												.collect(Collectors.toList());
		return models;
	}
}
