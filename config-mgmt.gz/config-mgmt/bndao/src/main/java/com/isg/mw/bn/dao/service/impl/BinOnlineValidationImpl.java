package com.isg.mw.bn.dao.service.impl;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.bn.dao.constants.BinInfoDaoMsgKeys;
import com.isg.mw.bn.dao.entities.BinInfoEntity;
import com.isg.mw.bn.dao.entities.BinInfoFileEntity;
import com.isg.mw.bn.dao.repository.BinInfoRepository;
import com.isg.mw.bn.dao.service.BinInfoFileService;
import com.isg.mw.bn.dao.service.BinOnlineValidation;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.CommonConstants;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.validation.FileNameValidator;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;

/**
 * 
 * @author sanchita3984
 *
 */
@Service("BinOnlineValidation")
public class BinOnlineValidationImpl implements BinOnlineValidation {

	@Autowired
	private BinInfoFileService binInfoFileService;

	@Autowired
	private BinInfoRepository binInfoRepository;

	@Autowired
	private TargetConfigMasterService targetMasterService;

	@Override
	public String fileNameValidation(String fileName) {
		String name = fileName.substring(0, fileName.lastIndexOf(CommonConstants.DOT));

		String[] split = name.split(CommonConstants.UNDER_SCORE);

		String schemeName = split[1];
		String date = split[2];
		String seqNumber = split[3];

		BinInfoFileEntity entity = binInfoFileService.getLatestSuccess(schemeName);

		if (entity != null) {
			try {
				return FileNameValidator.validateFileDate(date, seqNumber, entity.getDateStr(),
						entity.getSequenceNumber());
			} catch (ParseException e) {
				return CommonConstants.UNKNOWN_ERROR;
			}
		}
		return null;
	}

	@Override
	public void addValidation(BinInfoModel model) {
		BinInfoEntity entity = binInfoRepository.findByBinSchemeNameAndNumber(model.getSchemeName(),
				model.getBinNumber(), model.getBinLow(), model.getBinHigh());
		if (entity != null) {
			throw new ValidationException(BinInfoDaoMsgKeys.BIN_EXITS_ALREADY, model.getBinNumber());
		}
		
		checkedTargetId(model.getTargetId());
			
	}

	@Override
	public void updateValidation(BinInfoModel model) {
		BinInfoEntity entity = binInfoRepository.findByBinSchemeNameAndNumber(model.getSchemeName(),
				model.getBinNumber(), model.getBinLow(), model.getBinHigh());
		if (entity == null) {
			throw new ValidationException(BinInfoDaoMsgKeys.BIN_NOT_EXITS, model.getBinNumber());
		}
		
		checkedTargetId(model.getTargetId());
		
	}

	@Override
	public void checkedTargetId(String targetId) {
		if(!StringUtils.isBlank(targetId)) {
			TargetConfigModel configModel = targetMasterService.findById(Long.parseLong(targetId));
			if (configModel == null) {
				throw new ValidationException(BinInfoDaoMsgKeys.BIN_TARGET_NOT_EXITS, targetId);
			}
			if (configModel.getTarget() != Target.Issuer) {
				throw new ValidationException(BinInfoDaoMsgKeys.BIN_TARGET_NOT_EXITS, targetId);
			}
		}
	}

}
