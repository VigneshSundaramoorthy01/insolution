package com.isg.mw.bn.dao.entities;

import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.tc.TargetConfigModel;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigInteger;



@Getter
@Setter
@Entity
@Table(name = "aid_scheme_map")
public class AidSchemeMap {
    /**
     * Database auto generated value
     */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    /**
     * Entity Id
     */
    @Column(name = "entity_id", length = 32)
    private String entityId;


    /**
     * Aid
     */
    @Column(name = "aid", length = 50)
    private String aid;

//    /**
//     * targetid
//     */
//    @Column(name = "target_id")
//    private TargetConfigModel target;

    /**
     * targetid
     */
    @Column(name = "target_id")
    private String targetId;

    /**
     * Active Flag
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "ACTIVE_FLAG", length = 1)
    private ActiveFlag activeFlag;


    /**
     * Aid
     */
    @Column(name = "remark", length = 100)
    private String remark;
}
