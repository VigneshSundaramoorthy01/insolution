package com.isg.mw.tc.mgmt.utils.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;
import com.isg.mw.tc.mgmt.utils.TargetMgmtUtility;

public class TargetMgmtUtilityTest {
	
	@Test
	public void testGetTargetConfigModelFromAddModel() {
		AddTargetConfigModel targetConfigModel = getAddTargetConfigModel();
		TargetConfigModel addModel = TargetMgmtUtility.getTargetConfigModel(targetConfigModel);
		assertEquals(targetConfigModel.getEntityId(), addModel.getEntityId());
		assertEquals(targetConfigModel.getName(), addModel.getName());
		assertEquals(targetConfigModel.getTargetType(), addModel.getTargetType());
		/*
		 * assertArrayEquals(targetConfigModel.getEncryptionKey(),
		 * addModel.getEncryptionKey());
		 * assertArrayEquals(targetConfigModel.getDecryptionKey(),
		 * addModel.getDecryptionKey());
		 */
		//assertNotNull(addModel.getCreatedBy());
		assertNotNull(addModel.getConnections());
		assertEquals(targetConfigModel.getGroupSignonId(), addModel.getGroupSignonId());
		assertEquals(targetConfigModel.getRequestTimeout(), addModel.getRequestTimeout());
		assertEquals(targetConfigModel.getConnectTimeout(), addModel.getConnectTimeout());
		assertEquals(targetConfigModel.getPinTranslationType(), addModel.getPinTranslationType());
		assertNotNull(addModel.getNettyParameters());
	}
	
	@Test
	public void testGetTargetConfigModelFromModifyModel() {
		ModifyTargetConfigModel targetConfigModel = getmodifyModel();
		TargetConfigModel modifyModel = TargetMgmtUtility.getTargetConfigModel(targetConfigModel);
		assertEquals(targetConfigModel.getEntityId(), modifyModel.getEntityId());
		assertEquals(targetConfigModel.getName(), modifyModel.getName());
		assertEquals(targetConfigModel.getTargetType(), modifyModel.getTargetType());
		/*
		 * assertArrayEquals(targetConfigModel.getEncryptionKey(),
		 * modifyModel.getEncryptionKey());
		 * assertArrayEquals(targetConfigModel.getDecryptionKey(),
		 * modifyModel.getDecryptionKey());
		 */
		//assertNotNull(modifyModel.getUpdatedBy());
		assertNotNull(modifyModel.getConnections());
		assertEquals(targetConfigModel.getGroupSignonId(), modifyModel.getGroupSignonId());
		assertEquals(targetConfigModel.getRequestTimeout(), modifyModel.getRequestTimeout());
		assertEquals(targetConfigModel.getConnectTimeout(), modifyModel.getConnectTimeout());
		assertEquals(targetConfigModel.getPinTranslationType(), modifyModel.getPinTranslationType());
		assertNotNull(modifyModel.getNettyParameters());
	}
	
	private AddTargetConfigModel getAddTargetConfigModel() {
		AddTargetConfigModel model = new AddTargetConfigModel();
		model.setEntityId("123");
		model.setName("TCM");
		model.setTargetType(TargetType.Master);
		/*
		 * model.setEncryptionKey(byteConversion());
		 * model.setDecryptionKey(byteConversion());
		 */
		//model.setCreatedBy("ISG client");
		model.setConnections(getConnections());
		model.setGroupSignonId("1234");
		model.setRequestTimeout(87000);
		model.setConnectTimeout(56000);
		model.setPinTranslationType(PinTranslationType.STATIC);
		model.setNettyParameters(getNettyParameters());
		return model;
	}

	private ModifyTargetConfigModel getmodifyModel() {
		ModifyTargetConfigModel model = new ModifyTargetConfigModel();
		model.setEntityId("123");
		model.setName("TCM");
		model.setTargetType(TargetType.Master);
		/*
		 * model.setEncryptionKey(byteConversion());
		 * model.setDecryptionKey(byteConversion());
		 */
		//model.setUpdatedBy("ISG admin");
		model.setConnections(getConnections());
		model.setGroupSignonId("1234");
		model.setRequestTimeout(87000);
		model.setConnectTimeout(56000);
		model.setPinTranslationType(PinTranslationType.STATIC);
		model.setNettyParameters(getNettyParameters());
		return model;
	}
	
	private NettyConfig getNettyParameters() {
		NettyConfig param = new NettyConfig();
		param.setPacketInitialBytesToStrip(0);
		param.setPacketLengthFieldAdjustment(4);
		param.setPacketLengthFieldLength(7);
		param.setPacketLengthOffset(4);
		param.setPacketMaxFrameLength(512);
		return param;
	}
	
	private byte[] byteConversion() {
		byte[] byteArr = "ABCD".getBytes();
		return byteArr;
	}

	private List<TargetConnection> getConnections() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(ConnectionType.ISO);
		conn.setUrlOrIp("192.168.34.32");
		conn.setPortOrHeaders("8090");
		list.add(conn);
		return list;
	}

       
}
