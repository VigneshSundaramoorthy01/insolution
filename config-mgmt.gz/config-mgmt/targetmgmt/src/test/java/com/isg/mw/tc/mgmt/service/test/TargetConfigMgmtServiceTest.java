//package com.isg.mw.tc.mgmt.service.test;
//
//import static org.junit.Assert.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.isg.mw.core.model.common.NettyCommonUtility;
//import com.isg.mw.core.model.common.NettyConfig;
//import com.isg.mw.core.model.constants.ConfigStatus;
//import com.isg.mw.core.model.constants.ConnectionType;
//import com.isg.mw.core.model.constants.EditStatus;
//import com.isg.mw.core.model.constants.LockedState;
//import com.isg.mw.core.model.constants.PinTranslationType;
//import com.isg.mw.core.model.constants.TargetType;
//import com.isg.mw.core.model.exception.ValidationException;
//import com.isg.mw.core.model.tc.TargetConfigModel;
//import com.isg.mw.core.model.tc.TargetConnection;
//import com.isg.mw.core.utils.DateFormatUtils;
//import com.isg.mw.core.utils.PropertyUtils;
//import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
//import com.isg.mw.tc.dao.entities.TargetConfigEditCopyEntity;
//import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
//import com.isg.mw.tc.dao.service.TargetConfigEditCopyService;
//import com.isg.mw.tc.dao.service.TargetConfigMasterService;
//import com.isg.mw.tc.dao.service.TargetOnlineValidator;
//import com.isg.mw.tc.dao.utils.TargetCommonUtil;
//import com.isg.mw.tc.mgmt.constants.TargetMgmtMsgKeys;
//import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
//import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;
//import com.isg.mw.tc.mgmt.service.TargetMessenger;
//import com.isg.mw.tc.mgmt.service.impl.TargetConfigMgmtServiceImpl;
//import com.isg.mw.tc.mgmt.validations.TargetOfflineValidatorImpl;
//
//public class TargetConfigMgmtServiceTest {
//
//	@Mock
//	private TargetConfigMasterService targetMasterService;
//
//	@Mock
//	private TargetConfigEditCopyService targetEditCopyService;
//
//	@Mock
//	private TargetOfflineValidatorImpl targetOfflineValidator;
//
//	@Mock
//	private TargetOnlineValidator targetOnlineValidator;
//
//	@Mock
//	private TargetMessenger messenger;
//
//	@Mock
//	private MessageFormatBulkUpdateService messageFormatBulkUpdateService;
//
//	@InjectMocks
//	private TargetConfigMgmtServiceImpl targetConfigMgmtService;
//
//	@Before
//	public void init() {
//		MockitoAnnotations.initMocks(this);
//	}
//
//	@Test
//	public void testGetP01() {
//		Mockito.when(targetMasterService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetConfigModel());
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetConfigModel());
//		ResponseEntity<?> entity = targetConfigMgmtService.get("TCM", "123");
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testGetN01Null() {
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
//		ResponseEntity<?> entity = targetConfigMgmtService.get("TCM", "123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetN02ValidationException() {
//		Mockito.when(targetMasterService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.get("TCM", "123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetN03Exception() {
//		Mockito.when(targetMasterService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.get("TCM", "123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetAllP01() {
//		Mockito.when(targetMasterService.getAll()).thenReturn(getTargetConfigModelList());
//		ResponseEntity<?> entity = targetConfigMgmtService.getAll();
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testGetAllN01Null() {
//		Mockito.when(targetMasterService.getAll()).thenReturn(new ArrayList<>());
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
//		ResponseEntity<?> entity = targetConfigMgmtService.getAll();
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetAllN02ValidationException() {
//		Mockito.when(targetMasterService.getAll()).thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.getAll();
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetAllN03Exception() {
//		Mockito.when(targetMasterService.getAll()).thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.getAll();
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetTargetsP01() {
//		Mockito.when(targetMasterService.getTargets(Mockito.anyString())).thenReturn(getTargetsList());
//		ResponseEntity<?> entity = targetConfigMgmtService.getTargets("123");
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testGetTargetsN01Null() {
//		Mockito.when(targetMasterService.getTargets(Mockito.anyString())).thenReturn(new ArrayList<>());
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
//		ResponseEntity<?> entity = targetConfigMgmtService.getTargets("123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetTargetsN02ValidationException() {
//		Mockito.when(targetMasterService.getTargets(Mockito.anyString())).thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.getTargets("123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testGetTargetsN03Exception() {
//		Mockito.when(targetMasterService.getTargets(Mockito.anyString())).thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.getTargets("123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testAddOk() {
//		Mockito.when(targetEditCopyService.add(Mockito.any())).thenReturn(getTargetConfigModel());
//		ResponseEntity<?> entity = targetConfigMgmtService.add(getAddTargetConfigModel());
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testAddValidationException() {
//		Mockito.when(targetEditCopyService.add(Mockito.any())).thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.add(getAddTargetConfigModel());
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testAddException() {
//		Mockito.when(targetEditCopyService.add(Mockito.any())).thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.add(getAddTargetConfigModel());
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testModifyOk() {
//		Mockito.when(targetEditCopyService.update(Mockito.any())).thenReturn(getTargetConfigModel());
//		ResponseEntity<?> entity = targetConfigMgmtService.modify(getmodifyModel());
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testModifyValidationException() {
//		Mockito.when(targetEditCopyService.update(Mockito.any())).thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.modify(getmodifyModel());
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testModifyException() {
//		Mockito.when(targetEditCopyService.update(Mockito.any())).thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.modify(getmodifyModel());
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testSubmitOk() {
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetConfigModel());
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetConfigModel());
//		ResponseEntity<?> entity = targetConfigMgmtService.submit("TCM", "123");
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testSubmitValidationException() {
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetConfigModel());
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.submit("TCM", "123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testSubmitException() {
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetConfigModel());
//		Mockito.when(targetEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
//				.thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.submit("TCM", "123");
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testLockOk() {
//		Mockito.when(targetMasterService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetMasterEntity());
//		Mockito.when(targetMasterService.lock(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenReturn(LockedState.Locked);
//		ResponseEntity<?> entity = targetConfigMgmtService.lock("TCM", "123", LockedState.Locked);
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testLockValidationException() {
//		Mockito.when(targetMasterService.lock(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.lock("TCM", "123", LockedState.Locked);
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testLockException() {
//		Mockito.when(targetMasterService.lock(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.lock("TCM", "123", LockedState.Locked);
//		assertEquals(response, entity);
//	}
//
//	@Test // throw exception
//	public void testVerifyOkP01() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetEditCopyEntity());
//		Mockito.when(targetMasterService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetMasterEntity());
//		ResponseEntity<?> entity = targetConfigMgmtService.verify("TCM", "123", true,null);
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testVerifyOkP02() {
//		ResponseEntity<?> entity = targetConfigMgmtService.verify("TCM", "123", false,null);
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testVerifyOkN01() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetEditCopyEntity());
//		Mockito.when(targetMasterService.get(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
//		ResponseEntity<?> entity = targetConfigMgmtService.verify("TCM", "123", true,null);
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testVerifyValidationException() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.verify("TCM", "123", true,null);
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testVerifyException() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.verify("TCM", "123", true,null);
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testUpdateStatusOkP01() {
//		Mockito.when(targetMasterService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetMasterEntity());
//		Mockito.when(targetMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenReturn(ConfigStatus.Active);
//		ResponseEntity<?> entity = targetConfigMgmtService.updateStatus("TCM", "123", ConfigStatus.Active.name());
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testUpdateStatusOkP02() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetEditCopyEntity());
//		Mockito.when(targetMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenReturn(ConfigStatus.Active);
//		ResponseEntity<?> entity = targetConfigMgmtService.updateStatus("TCM", "123", ConfigStatus.Inactive.name());
//		assertNotNull(entity);
//	}
//
//	@Test // throw error
//	public void testUpdateStatusOkP03() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetEditCopyEntity());
//		Mockito.when(targetMasterService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetMasterEntity());
//		ResponseEntity<?> entity = targetConfigMgmtService.updateStatus("TCM", "123", null);
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testUpdateStatusOkP04() {
//		Mockito.when(targetEditCopyService.get(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
//		Mockito.when(targetMasterService.get(Mockito.anyString(), Mockito.anyString()))
//				.thenReturn(getTargetMasterEntity());
//		ResponseEntity<?> entity = targetConfigMgmtService.updateStatus("TCM", "123", null);
//		assertNotNull(entity);
//	}
//
//	@Test
//	public void testUpdateStatusValidationException() {
//		Mockito.when(targetMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenThrow(ValidationException.class);
//		String errMsg = ("Unknown message");
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
//		ResponseEntity<?> entity = targetConfigMgmtService.updateStatus("TCM", "123", ConfigStatus.Active.name());
//		assertEquals(response, entity);
//	}
//
//	@Test
//	public void testUpdateStatusException() {
//		Mockito.when(targetMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
//				.thenThrow(RuntimeException.class);
//		String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
//		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<?> entity = targetConfigMgmtService.updateStatus("TCM", "123", ConfigStatus.Active.name());
//		assertEquals(response, entity);
//	}
//
//	private TargetConfigModel getTargetConfigModel() {
//		TargetConfigModel model = new TargetConfigModel();
//		model.setId(1L);
//		model.setEntityId("123");
//		model.setName("TCM");
//		model.setTargetType(TargetType.Master);
//		model.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		model.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		model.setStatus(EditStatus.Inprogress.name());
//		model.setCreatedBy("ISG client");
//		model.setUpdatedBy("ISG admin");
//		model.setConnections(getConnections());
//		model.setGroupSignonId("1234");
//		model.setRequestTimeout(87000);
//		model.setConnectTimeout(56000);
//		model.setPinTranslationType(PinTranslationType.STATIC);
//		model.setNettyParameters(getNettyParameters());
//		return model;
//	}
//
//	private List<TargetConfigModel> getTargetConfigModelList() {
//		List<TargetConfigModel> list = new ArrayList<TargetConfigModel>();
//		TargetConfigModel model = new TargetConfigModel();
//		model.setId(1L);
//		model.setEntityId("123");
//		model.setName("TCM");
//		model.setTargetType(TargetType.Master);
//		model.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		model.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		model.setStatus(EditStatus.Inprogress.name());
//		model.setCreatedBy("ISG client");
//		model.setUpdatedBy("ISG admin");
//		model.setConnections(getConnections());
//		model.setGroupSignonId("1234");
//		model.setRequestTimeout(87000);
//		model.setConnectTimeout(56000);
//		model.setPinTranslationType(PinTranslationType.STATIC);
//		model.setNettyParameters(getNettyParameters());
//		list.add(model);
//		return list;
//	}
//
//	private AddTargetConfigModel getAddTargetConfigModel() {
//		AddTargetConfigModel model = new AddTargetConfigModel();
//		model.setEntityId("123");
//		model.setName("TCM");
//		model.setTargetType(TargetType.Master);
//		/*
//		 * model.setEncryptionKey(byteConversion());
//		 * model.setDecryptionKey(byteConversion());
//		 */
//		//model.setCreatedBy("ISG client");
//		model.setConnections(getConnections());
//		model.setGroupSignonId("1234");
//		model.setRequestTimeout(87000);
//		model.setConnectTimeout(56000);
//		model.setPinTranslationType(PinTranslationType.STATIC);
//		model.setNettyParameters(getNettyParameters());
//		return model;
//	}
//
//	private ModifyTargetConfigModel getmodifyModel() {
//		ModifyTargetConfigModel model = new ModifyTargetConfigModel();
//		model.setEntityId("123");
//		model.setName("TCM");
//		model.setTargetType(TargetType.Master);
//		model.setConnections(getConnections());
//		model.setGroupSignonId("1234");
//		model.setRequestTimeout(87000);
//		model.setConnectTimeout(56000);
//		model.setPinTranslationType(PinTranslationType.STATIC);
//		model.setNettyParameters(getNettyParameters());
//		return model;
//	}
//
//	private TargetConfigEditCopyEntity getTargetEditCopyEntity() {
//		TargetConfigEditCopyEntity entity = new TargetConfigEditCopyEntity();
//		entity.setId(1L);
//		entity.setEntityId("123");
//		entity.setName("TCM");
//		entity.setTargetType(TargetType.Master);
//		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		entity.setStatus(EditStatus.Inprogress);
//		entity.setCreatedBy("ISG client");
//		entity.setUpdatedBy("ISG admin");
//		entity.setConnections(TargetCommonUtil.convertTargetConnectionListToString(getConnections()));
//		entity.setGroupSignonId("1234");
//		entity.setRequestTimeout(87000);
//		entity.setConnectTimeout(56000);
//		entity.setPinTranslationType(PinTranslationType.STATIC);
//		entity.setNettyParameters(NettyCommonUtility.nettyConfigToString(getNettyParameters()));
//		return entity;
//	}
//
//	private TargetConfigMasterEntity getTargetMasterEntity() {
//		TargetConfigMasterEntity entity = new TargetConfigMasterEntity();
//		entity.setId(1L);
//		entity.setEntityId("123");
//		entity.setName("TCM");
//		entity.setTargetType(TargetType.Master);
//		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
//		entity.setStatus(ConfigStatus.Active);
//		entity.setCreatedBy("ISG client");
//		entity.setUpdatedBy("ISG admin");
//		entity.setLockedState(LockedState.Unlocked);
//		entity.setConnections(TargetCommonUtil.convertTargetConnectionListToString(getConnections()));
//		entity.setGroupSignonId("1234");
//		entity.setRequestTimeout(87000);
//		entity.setConnectTimeout(56000);
//		entity.setPinTranslationType(PinTranslationType.STATIC);
//		entity.setNettyParameters(NettyCommonUtility.nettyConfigToString(getNettyParameters()));
//		return entity;
//	}
//
//	private List<String> getTargetsList() {
//		List<String> list = new ArrayList<String>();
//		list.add("TCM1");
//		list.add("TCM2");
//		list.add("TCM3");
//		return list;
//	}
//
//	private NettyConfig getNettyParameters() {
//		NettyConfig param = new NettyConfig();
//		param.setPacketInitialBytesToStrip(0);
//		param.setPacketLengthFieldAdjustment(4);
//		param.setPacketLengthFieldLength(7);
//		param.setPacketLengthOffset(4);
//		param.setPacketMaxFrameLength(512);
//		return param;
//	}
//
//
//	private byte[] byteConversion() {
//		byte[] byteArr = "ABCD".getBytes();
//		return byteArr;
//	}
//
//	private List<TargetConnection> getConnections() {
//		List<TargetConnection> list = new ArrayList<TargetConnection>();
//		TargetConnection conn = new TargetConnection();
//		conn.setType(ConnectionType.ISO);
//		conn.setUrlOrIp("192.168.34.32");
//		conn.setPortOrHeaders("8090");
//		list.add(conn);
//		return list;
//	}
//
//}
