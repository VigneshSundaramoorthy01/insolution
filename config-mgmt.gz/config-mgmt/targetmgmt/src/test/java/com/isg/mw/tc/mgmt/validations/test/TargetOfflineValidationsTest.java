package com.isg.mw.tc.mgmt.validations.test;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.tc.mgmt.validations.TargetOfflineValidatorImpl;

/**
 * 
 * @author sanchita3984
 *
 */
public class TargetOfflineValidationsTest {

	@InjectMocks
	private TargetOfflineValidatorImpl targetOfflineValidator;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testAddValidationP01() {
		String errorMsg = null;
		try {
			targetOfflineValidator.addValidation(getTargetConfigModel(getConnections()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);
	}

	@Test
	public void testAddValidationP02() {
		String errorMsg = null;
		try {
			targetOfflineValidator.addValidation(getTargetConfigModel(getConnectionsForWEB()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();

		}
		assertNull(errorMsg);
	}

	@Test
	public void testAddValidationN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.addValidation(getTargetConfigModel(getConnectionsList()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.data.list.has.duplicate");
		assertEquals(errorArg[0], FieldsInfo.TARGET_CONNECTIONS_FN);
	}

	@Test
	public void testAddValidationN03() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.addValidation(getTargetConfigModel(getConnectionsNullType()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.TARGET_CONNECTIONS_TYPE_FN);
	}

	@Test
	public void testModifyValidationP01() {
		String errorMsg = null;
		try {
			targetOfflineValidator.modifyValidation(getTargetConfigModel(getConnections()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);
	}

	@Test
	public void testModifyValidationP02() {
		String errorMsg = null;
		try {
			targetOfflineValidator.modifyValidation(getTargetConfigModel(getConnectionsForWEB()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();

		}
		assertNull(errorMsg);
	}

	@Test
	public void testModifyValidationN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.modifyValidation(getTargetConfigModel(getConnectionsList()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.data.list.has.duplicate");
		assertEquals(errorArg[0], FieldsInfo.TARGET_CONNECTIONS_FN);
	}

	@Test
	public void testModifyValidationN02() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.modifyValidation(getTargetConfigModel(getConnectionsNullType()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.TARGET_CONNECTIONS_TYPE_FN);
	}

	@Test
	public void testSubmitValidationP01() {
		String errorMsg = null;
		try {
			targetOfflineValidator.submitValidation(getTargetConfigModel(getConnections()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);
	}

	@Test
	public void testSubmitValidationN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.submitValidation(getTargetConfigSubmitModel(null, getConnections()));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.SCHEME_TYPE_FN);
	}

	@Test
	public void testSubmitValidationN02() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.submitValidation(getTargetConfigSubmitModel(TargetType.Master, null));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.TARGET_CONNECTIONS_FN);
	}

	@Test
	public void testVerifyValidationP01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.verifyValidation("TCM", "123", true,null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void testVerifyValidationN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.verifyValidation(null, "123", true,null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void testVerifyValidationN02() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.verifyValidation("TCM", null, true,null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.ENTITY_ID_FN);
	}

	@Test
	public void testLockValidationP01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.lockValidation("TCM", "123", LockedState.Unlocked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void testLockValidationN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.lockValidation(null, "123", LockedState.Unlocked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void testLockValidationN02() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.lockValidation("TCM", null, LockedState.Unlocked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.ENTITY_ID_FN);
	}

	@Test
	public void testUpdateValidationP01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.updateValidation("TCM", "123", ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void testUpdateValidationN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.updateValidation(null, "123", ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void testUpdateValidationN02() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.updateValidation("TCM", null, ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.ENTITY_ID_FN);
	}

	@Test
	public void testGetP01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.get("TCM", "123");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void testGetN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.get(null, "123");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void testGetN02() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.get("TCM", null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.ENTITY_ID_FN);
	}

	@Test
	public void testAllTargetsP01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.alltargets("123");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void testAllTargetsN01() {
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			targetOfflineValidator.alltargets(null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "tc.mgmt.target.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.ENTITY_ID_FN);
	}
	
	@Test
	public void testAll() {
		targetOfflineValidator.all("123", "Active", LockedState.Unlocked);
	}
	
	@Test
	public void testGetAllActive() {
		targetOfflineValidator.getAllActive();
	}

	private TargetConfigModel getTargetConfigModel(List<TargetConnection> connections) {
		TargetConfigModel model = new TargetConfigModel();
		model.setId(1L);
		model.setEntityId("123");
		model.setName("TCM");
		model.setTargetType(TargetType.Master);
		model.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		model.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		model.setStatus(EditStatus.Inprogress.name());
		model.setCreatedBy("ISGClient");
		model.setUpdatedBy("ISGAdmin");
		model.setConnections(connections);
		model.setGroupSignonId("1234");
		model.setRequestTimeout(87000);
		model.setConnectTimeout(56000);
		model.setPinTranslationType(PinTranslationType.STATIC);
		model.setNettyParameters(getNettyParameters());
		model.setAdditionalData(getData());
		return model;
	}

	private TargetConfigModel getTargetConfigSubmitModel(TargetType TargetType, List<TargetConnection> connections) {
		TargetConfigModel model = new TargetConfigModel();
		model.setId(1L);
		model.setEntityId("123");
		model.setName("TCM");
		model.setTargetType(TargetType);
		model.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		model.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		model.setStatus(EditStatus.Inprogress.name());
		model.setCreatedBy("ISGClient");
		model.setUpdatedBy("ISGAdmin");
		model.setConnections(connections);
		model.setGroupSignonId("1234");
		model.setRequestTimeout(87000);
		model.setConnectTimeout(56000);
		model.setPinTranslationType(PinTranslationType.STATIC);
		model.setNettyParameters(getNettyParameters());
		model.setAdditionalData(getData());
		return model;
	}
	
	private NettyConfig getNettyParameters() {
		NettyConfig param = new NettyConfig();
		param.setPacketInitialBytesToStrip(0);
		param.setPacketLengthFieldAdjustment(4);
		param.setPacketLengthFieldLength(7);
		param.setPacketLengthOffset(4);
		param.setPacketMaxFrameLength(512);
		return param;
	}

	private byte[] byteConversion() {
		byte[] byteArr = "ABCD".getBytes();
		return byteArr;
	}

	private List<TargetConnection> getConnections() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(ConnectionType.ISO);
		conn.setUrlOrIp("192.168.34.32");
		conn.setPortOrHeaders("8090");
		list.add(conn);
		return list;
	}

	private List<TargetConnection> getConnectionsList() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(ConnectionType.ISO);
		conn.setUrlOrIp("192.168.34.32");
		conn.setPortOrHeaders("8090");
		TargetConnection conn1 = new TargetConnection();
		conn1.setType(ConnectionType.ISO);
		conn1.setUrlOrIp("192.168.34.32");
		conn1.setPortOrHeaders("8090");
		list.add(conn);
		list.add(conn1);
		return list;
	}

	private List<TargetConnection> getConnectionsForWEB() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(ConnectionType.WEB);
		conn.setUrlOrIp("https://www.google.com");
		conn.setPortOrHeaders("8090");
		list.add(conn);
		return list;
	}

	private List<TargetConnection> getConnectionsNullType() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(null);
		conn.setUrlOrIp("192.168.34.32");
		conn.setPortOrHeaders("8090");
		list.add(conn);
		return list;
	}
	
	private TargetAdditionalData getData() {
		TargetAdditionalData additionalData = new TargetAdditionalData();
		additionalData.setAcquirerId("1234");
		TargetApiInfo urls = new TargetApiInfo();
//		urls.setTargetUrl("192.168.83.207:8085");
		additionalData.setApiInfo(urls);
		return additionalData;
	}
		

}
