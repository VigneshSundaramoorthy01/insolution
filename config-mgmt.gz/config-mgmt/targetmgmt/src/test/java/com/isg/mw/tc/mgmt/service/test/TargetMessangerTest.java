package com.isg.mw.tc.mgmt.service.test;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.tc.TargetConfigMessage;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.tc.mgmt.service.impl.TargetMessengerImpl;

public class TargetMessangerTest {

	@InjectMocks
	TargetMessengerImpl targetMessenger;

	@Mock
	private IsgKafkaConfigs isgKafkaConfigs;

	@Mock
	private KafkaTopics kafkaTopics;

	@Mock
	KafkaProducer producer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void tsetDestroy() throws Exception {
		targetMessenger.destroy();
	}

	@Test
	public void testsendPT01() {
		targetMessenger.send(getTargetConfigMsgModel());
	}

	private TargetConfigMessage getTargetConfigMsgModel() {
		TargetConfigMessage msg = new TargetConfigMessage();
		TargetConfigModel model = new TargetConfigModel();
		model.setName("TARGET");
		msg.setModel(model);
		msg.setAction(ConfigAction.ADD);
		return msg;
	}

}
