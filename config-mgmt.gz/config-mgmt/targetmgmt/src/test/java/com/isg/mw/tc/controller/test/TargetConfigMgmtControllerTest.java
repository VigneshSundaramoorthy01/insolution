package com.isg.mw.tc.controller.test;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.tc.controller.TargetConfigMgmtController;
import com.isg.mw.tc.mgmt.constants.TargetConfigUri;
import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;
import com.isg.mw.tc.mgmt.service.TargetConfigMgmtService;

/**
 * 
 * @author sanchita3984
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TargetConfigMgmtControllerTest {

	private MockMvc mockMvc;

	@Mock
	private TargetConfigMgmtService targetConfigMgmtService;

	@InjectMocks
	private TargetConfigMgmtController targetConfigMgmtController;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(targetConfigMgmtController).build();
	}

	@Test
	public void testGet() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.GET_BY_NAME)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString()))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testGetAll() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.GET_ALL))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testGetTargets() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.GET_NAMES_ONLY)
				.param("entityId", Mockito.anyString())).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testAdd() throws Exception {
		AddTargetConfigModel addTCModel = getAddTargetConfigModel();
		String requestBody = new ObjectMapper().valueToTree(addTCModel).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(TargetConfigUri.PARENT + TargetConfigUri.ADD).content(requestBody)
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testModify() throws Exception {
		ModifyTargetConfigModel modifyTCModel = getmodifyModel();
		String requestBody = new ObjectMapper().valueToTree(modifyTCModel).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(TargetConfigUri.PARENT + TargetConfigUri.MODIFY)
				.content(requestBody).contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testSubmit() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.SUBMIT)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString()))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testUpdateStatus() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.UPDATE_STATUS)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString())
				.param("status", Mockito.anyString())).andExpect(MockMvcResultMatchers.status().isOk());
	}

	//@Test
	public void testLock() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.LOCK)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString())
				.param("lockedState", Mockito.anyString())).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testVerify() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("name", "TCM");
		requestParams.add("entityId", "123");
		requestParams.add("approved", "true");

		mockMvc.perform(
				MockMvcRequestBuilders.get(TargetConfigUri.PARENT + TargetConfigUri.VERIFY).params(requestParams))
				.andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}

	private AddTargetConfigModel getAddTargetConfigModel() {
		AddTargetConfigModel model = new AddTargetConfigModel();
		model.setEntityId("123");
		model.setName("TCM");
		model.setTargetType(TargetType.Master);
		/*
		 * model.setEncryptionKey(byteConversion());
		 * model.setDecryptionKey(byteConversion());
		 */
		//model.setCreatedBy("ISG client");
		model.setConnections(getConnections());
		model.setGroupSignonId("1234");
		model.setRequestTimeout(87000);
		model.setConnectTimeout(56000);
		model.setPinTranslationType(PinTranslationType.STATIC);
		model.setNettyParameters(getNettyParameters());
		return model;
	}

	private ModifyTargetConfigModel getmodifyModel() {
		ModifyTargetConfigModel model = new ModifyTargetConfigModel();
		model.setEntityId("123");
		model.setName("TCM");
		model.setTargetType(TargetType.Master);
		/*
		 * model.setEncryptionKey(byteConversion());
		 * model.setDecryptionKey(byteConversion());
		 */
		//model.setUpdatedBy("ISG admin");
		model.setConnections(getConnections());
		model.setGroupSignonId("1234");
		model.setRequestTimeout(87000);
		model.setConnectTimeout(56000);
		model.setPinTranslationType(PinTranslationType.STATIC);
		model.setNettyParameters(getNettyParameters());
		return model;
	}
	
	private NettyConfig getNettyParameters() {
		NettyConfig param = new NettyConfig();
		param.setPacketInitialBytesToStrip(0);
		param.setPacketLengthFieldAdjustment(4);
		param.setPacketLengthFieldLength(7);
		param.setPacketLengthOffset(4);
		param.setPacketMaxFrameLength(512);
		return param;
	}

	private byte[] byteConversion() {
		byte[] byteArr = "ABCD".getBytes();
		return byteArr;
	}

	private List<TargetConnection> getConnections() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(ConnectionType.ISO);
		conn.setUrlOrIp("192.168.34.32");
		conn.setPortOrHeaders("8090");
		list.add(conn);
		return list;
	}

}