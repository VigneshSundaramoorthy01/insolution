package com.isg.mw.tc.mgmt.model;

import java.util.List;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetConnection;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * ModifyTargetConfig model class which is used to modify existing configuration
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "${swgr.tcc.model.modify}")
@Getter
@Setter
public class ModifyTargetConfigModel {

	/**
	 * Unique id of the Target configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.entityId.value}")
	private String entityId;

	/**
	 * Name of the Target configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.name.value}")
	private String name;

	/**
	 * Scheme Type (Visa, Master, Rupay)
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.targetType.value}")
	private TargetType targetType;

	/**
	 * Encryption Key
	 */
	/*
	 * @ApiModelProperty(required = false, value =
	 * "${swgr.tcc.model.modify.encryptionKey.value}") private byte[] encryptionKey;
	 */

	/**
	 * Decryption Key
	 */
	/*
	 * @ApiModelProperty(required = false, value =
	 * "${swgr.tcc.model.modify.decryptionKey.value}") private byte[] decryptionKey;
	 */

	/**
	 * Name of the person who modify Target configuration
	 */
	//@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.updatedBy.value}")
	//private String updatedBy;

	/**
	 * List of connection which is consist connection type, url or ip and port or
	 * headers
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.connections.value}")
	private List<TargetConnection> connections;

	/**
	 * sign-on required
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.signonrequired.value}")
	private boolean signonRequired;

	/**
	 * heart beat delay
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.beartbeatdelay.value}")
	private int heartBeatDelay;

	/**
	 * Group Sign On Id
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.groupSignonId.value}")
    private String groupSignonId;
	
	/**
	 * Request time out
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.requestTimeout.value}")
	private int requestTimeout;
	
	/**
	 * Connect Timeout
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.modify.connectTimeout.value}")
	private int connectTimeout;
	
	/**
	 * PinTranslationType (STATIC or DYNAMIC)
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.pinTranslationType.value}")
	private PinTranslationType pinTranslationType;
	
	/**
	 * Netty Parameters
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.nettyParameters.value}")
	private NettyConfig nettyParameters;
	
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.target.value}")
	private Target target;

	@ApiModelProperty(required = true, value = "${swgr.tcc.model.modify.additionalData.value}")
	private TargetAdditionalData additionalData;

	@ApiModelProperty(required = true, value = "processingFee")
	private Double processingFee;
}