package com.isg.mw.tc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.tc.mgmt.constants.TargetConfigUri;
import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;
import com.isg.mw.tc.mgmt.service.TargetConfigMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;


/**
 * Target configuration Rest APIS
 * 
 * @author prasad_t026
 *
 */
@Tag (name = "Target configuration", description = "Target configuration APIs" )
@RestController
@RequestMapping(value = TargetConfigUri.PARENT)
public class TargetConfigMgmtController {

	@Autowired
	private TargetConfigMgmtService targetConfigMgmtService;

	/**
	 * Target configuration Rest get API
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get Target configuration", description = "In response will get Target configuration by given name and entityId" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.GET_BY_NAME, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> get(
			@PathVariable(value = "${swgr.tcc.get.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.tcc.get.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId) {
		return targetConfigMgmtService.get(name, entityId);
	}

	/**
	 * Target configuration Rest getAll API
	 * 
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get All Active Target configuration", description = "In response will get all Active Target configuration" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAll(@PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
		return targetConfigMgmtService.getAll(entityId);
	}

	/**
	 * Target configuration Rest getTargets API
	 * 
	 * @param entityId - entity id of the configuration
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get List of Target configuration", description = "In response will get list of Target configurations by entityId" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.GET_NAMES_ONLY, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getTargets(
			@PathVariable(value = "${swgr.tcc.gettargets.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId) {
		return targetConfigMgmtService.getTargets(entityId);
	}

	/**
	 * Target configuration Rest add API
	 * 
	 * @param addModel - add Target configuration model
	 * @return - Configuration Object with 'OK' status if added successfully,
	 *         'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Add Target configuration", description = "In response will get Target configuration" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = TargetConfigUri.ADD)
	public ResponseEntity<?> add(@RequestBody AddTargetConfigModel addModel) {
		return targetConfigMgmtService.add(addModel);
	}

	/**
	 * Target configuration Rest modify API
	 * 
	 * @param modifyModel - modify Target configuration model
	 * @return - Configuration Object with 'OK' status if updated successfully,
	 *         'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Modify Target configuration", description = "In response will get Target configuration after update" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = TargetConfigUri.MODIFY)
	public ResponseEntity<?> modify(@RequestBody ModifyTargetConfigModel modifyModel) {
		return targetConfigMgmtService.modify(modifyModel);
	}

	/**
	 * Target configuration Rest submit API
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @return - Configuration updated status with 'OK' status if submitted
	 *         successfully, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Submit Target configuration", description = "In response will get Submit message" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.SUBMIT)
	public ResponseEntity<?> submit(
			@PathVariable(value = "${swgr.tcc.submit.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.tcc.submit.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId) {
		return targetConfigMgmtService.submit(name, entityId);
	}

	/**
	 * Target configuration Rest updateStatus API
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param status   - status to be update
	 * @return - Configuration updated status with 'OK' status if changed state
	 *         successfully, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Change the Status Of Target configuration", description = "In response will get status message" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.UPDATE_STATUS)
	public ResponseEntity<?> udateStatus(
			@PathVariable(value = "${swgr.tcc.updatestatus.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.tcc.updatestatus.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.tcc.updatestatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return targetConfigMgmtService.updateStatus(name, entityId, status);
	}

	/**
	 * Target configuration Rest lock API
	 * 
	 * @param name        - name of the configuration
	 * @param entityId    - entity id of the configuration
	 * @param lockedState - lock or unlocked state
	 * @return - Configuration updated state with 'OK' status if changed state
	 *         successfully, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Lock Target configuration", description = "In response will get lock state of Target configuration" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.LOCK)
	public ResponseEntity<?> lock(
			@PathVariable(value = "${swgr.tcc.lock.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.tcc.lock.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.tcc.lock.lockstate.value}") @RequestParam(value = "lockedState",required = true) LockedState lockedState) {
		return targetConfigMgmtService.lock(name, entityId, lockedState);
	}

	/**
	 * Target configuration Rest verify API
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param approved - true if verified or false if rejected
	 * @return - true with 'OK' status if verified successfully, false with 'OK'
	 *         status if rejected, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Verify Target configuration", description = "In response will get approved status of Target configuration" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.VERIFY)
	public ResponseEntity<?> verify(
			@PathVariable(value = "${swgr.tcc.verify.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.tcc.verify.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.tcc.verify.approved.value}") @RequestParam(value = "approved",required = true) boolean approved,
			@PathVariable(value = "${swgr.tcc.verify.remarks.value}") @RequestParam(value = "remarks" ,required = false) String remarks) {
		return targetConfigMgmtService.verify(name, entityId, approved,remarks);
	}
	
	/**
	 * Target configuration Rest getAll API
	 * 
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get Target configuration", description = "In response will get Target configuration by given status" ,tags= {"Target configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = TargetConfigUri.GET_CONFIG_BY_STATUS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getConfigByStatus(
			@PathVariable(value = "${swgr.tcc.getConfigByStatus.status.value}") @RequestParam(value = "status",required = true) String status,
			@PathVariable(value = "${swgr.tcc.lock.entityId.value}") @RequestParam(value = "entityId",required = false) String entityId) {
		return targetConfigMgmtService.getConfigByStatus(status,entityId);
	}

}