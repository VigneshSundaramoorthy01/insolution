package com.isg.mw.tc.mgmt.constants;

/**
 * Constants to refer keys from message resource bundle
 * 
 * @author sanchita3984
 *
 */
public interface TargetMgmtMsgKeys {

	/**
	 * should use when name is not exist in db
	 */
	String TARGET_NOT_FOUND_WITH_NAME = "tc.mgmt.target.not.found";

	/**
	 * should use when and internal error occur
	 */
	String INTERNAL_ERROR = "tc.mgmt.internal.error";

	/**
	 * should use when no any entry in db
	 */
	String TARGET_LIST_EMPTY = "tc.mgmt.target.list.empty";

	/**
	 * should use when get Target configuration by name
	 */
	String GET_API_LOG_INFO = "tc.mgmt.get.api.log.info";

	/**
	 * get all target configurations requested
	 */
	String GETALL_API_LOG_INFO = "tc.mgmt.getall.api.log.info";

	/**
	 * get all target configurations names requested
	 */
	String GETTARGETS_API_LOG_INFO = "tc.mgmt.gettargets.api.log.info";

	/**
	 * add requested with the target configuration {0}
	 */
	String ADD_API_LOG_INFO = "tc.mgmt.add.api.log.info";

	/**
	 * update requested for the target configuration {0}
	 */
	String UPDATE_API_LOG_INFO = "tc.mgmt.update.api.log.info";

	/**
	 * modify requested for target configuration {0}
	 */
	String MODIFY_API_LOG_INFO = "tc.mgmt.modify.api.log.info";

	/**
	 * submit requested for target configuration {0}
	 */
	String SUBMIT_API_LOG_INFO = "tc.mgmt.submit.api.log.info";

	/**
	 * lock requested for target configuration {0}
	 */
	String LOCK_API_LOG_INFO = "tc.mgmt.lock.api.log.info";

	/**
	 * verify requested for target configuration {0}
	 */
	String VERIFY_API_LOG_INFO = "tc.mgmt.verify.api.log.info";

	/**
	 * update status requested for target configuration {0}
	 */
	String UPDATESTATUS_API_LOG_INFO = "tc.mgmt.updatestatus.api.log.info";

	/**
	 * Should used in validations when target field is mandatory
	 */
	String TARGET_FIELD_IS_MANDATORY = "tc.mgmt.target.field.is.mandatory";

	/**
	 * should used in validation when data length is not matches with given value
	 */
	String DATA_LENGTH_ERROR = "tc.mgmt.data.length.error";

	/**
	 * should used in validation when data length is exceed with given value
	 */
	String DATA_LENGTH_EXCEEDED = "tc.mgmt.data.length.exceeded";

	/**
	 * should used in validation when list has null
	 */
	String DATA_LIST_SHOULD_NOT_HAVE_NULL = "tc.mgmt.data.list.has.null";

	/**
	 * should used when data list has duplicate
	 */
	String DATA_LIST_SHOULD_NOT_HAVE_DUPLICATE = "tc.mgmt.data.list.has.duplicate";
	
	String REMARK_TARGET_IS_MANDATORY = "tc.mgmt.remark.target.is.mandatory";
	
	String GET_CONFIG_BY_STATUS_API_LOG_INFO = "tc.mgmt.getConfigByStatus.api.log.info";

}
