package com.isg.mw.tc.mgmt.utils;

import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;

/**
 * Target management utility used for convert Add and Modify Target
 * configuration model into Target configuration model
 * 
 * @author sanchita3984
 *
 */
public class TargetMgmtUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private TargetMgmtUtility() {

	}

	/**
	 * Converts add Target configuration model into Target configuration model
	 * 
	 * @param addModel - add Target configuration model
	 * @return model - Target configuration model
	 */
	public static TargetConfigModel getTargetConfigModel(AddTargetConfigModel addModel) {
		TargetConfigModel model = new TargetConfigModel();
		model.setEntityId(addModel.getEntityId());
		model.setName(addModel.getName());
		model.setTargetType(addModel.getTargetType());
		//model.setEncryptionKey(addModel.getEncryptionKey());
		//model.setDecryptionKey(addModel.getDecryptionKey());
		//model.setCreatedBy(addModel.getCreatedBy());
		model.setConnections(addModel.getConnections());
		model.setSignonRequired(addModel.isSignonRequired());
		model.setHeartBeatDelay(addModel.getHeartBeatDelay());
		model.setGroupSignonId(addModel.getGroupSignonId());
		model.setRequestTimeout(addModel.getRequestTimeout());
		model.setConnectTimeout(addModel.getConnectTimeout());
		model.setPinTranslationType(addModel.getPinTranslationType());
		model.setNettyParameters(addModel.getNettyParameters());
		model.setTarget(addModel.getTarget());
		model.setAdditionalData(addModel.getAdditionalData());
		model.setProcessingFee(addModel.getProcessingFee());
		return model;
	}

	/**
	 * Converts Modify Target configuration model into Target configuration model
	 * 
	 * @param modifyModel - Modify Target configuration model
	 * @return model - Target configuration model
	 */
	public static TargetConfigModel getTargetConfigModel(ModifyTargetConfigModel modifyModel) {
		TargetConfigModel model = new TargetConfigModel();
		model.setEntityId(modifyModel.getEntityId());
		model.setName(modifyModel.getName());
		model.setTargetType(modifyModel.getTargetType());
		//model.setEncryptionKey(modifyModel.getEncryptionKey());
		//model.setDecryptionKey(modifyModel.getDecryptionKey());
		//model.setUpdatedBy(modifyModel.getUpdatedBy());
		model.setConnections(modifyModel.getConnections());
		model.setSignonRequired(modifyModel.isSignonRequired());
		model.setHeartBeatDelay(modifyModel.getHeartBeatDelay());
		model.setGroupSignonId(modifyModel.getGroupSignonId());
		model.setRequestTimeout(modifyModel.getRequestTimeout());
		model.setConnectTimeout(modifyModel.getConnectTimeout());
		model.setPinTranslationType(modifyModel.getPinTranslationType());
		model.setNettyParameters(modifyModel.getNettyParameters());
		model.setTarget(modifyModel.getTarget());
		model.setAdditionalData(modifyModel.getAdditionalData());
		model.setProcessingFee(modifyModel.getProcessingFee());
		return model;
	}

}