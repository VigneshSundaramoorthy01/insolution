package com.isg.mw.tc.mgmt.service.impl;

import com.isg.mw.core.filter.constants.FilterConstants;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.tc.TargetConfigMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.tc.mgmt.service.TargetMessenger;

/**
 * Method implementation for {@link TargetMessenger}
 * @author prasad_t026
 *
 */
@Service("targetMessenger")
public class TargetMessengerImpl implements TargetMessenger, InitializingBean, DisposableBean {

	@Autowired
	private IsgKafkaConfigs isgKafkaConfigs;

	@Autowired
	private KafkaTopics kafkaTopics;

	private KafkaProducer producer;

	public TargetMessengerImpl() {
	}

	@Override
	public void send(TargetConfigMessage model) {
		setTraceIdForAllModels(model);
		producer.sendMessage(getObjectData(model));
	}

	private void setTraceIdForAllModels(TargetConfigMessage model) {
		String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
		model.setAcpTraceId(acpTraceId);
	}

	@Override
	public void destroy() throws Exception {
		// TODO Stop producer
	}

	/**
	 * byte [] conversion based on object
	 * 
	 * @param - object 
	 * @return -byte[] 
	 */
	public byte[] getObjectData(Object obj) {
		byte[] data = null;
		ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule())
				.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		try {
			data = objectMapper.writeValueAsBytes(obj);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return data;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getTargetTopicName()));
		producer.init();
	}

}