package com.isg.mw.tc.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.rbac.model.ResponseObj;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.tc.TargetConfigMessage;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.tc.dao.entities.TargetConfigEditCopyEntity;
import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
import com.isg.mw.tc.dao.service.TargetConfigEditCopyService;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import com.isg.mw.tc.dao.service.TargetOnlineValidator;
import com.isg.mw.tc.dao.utils.TargetMasterUtility;
import com.isg.mw.tc.dao.utils.TargetUtility;
import com.isg.mw.tc.mgmt.constants.TargetMgmtMsgKeys;
import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;
import com.isg.mw.tc.mgmt.service.TargetConfigMgmtService;
import com.isg.mw.tc.mgmt.service.TargetMessenger;
import com.isg.mw.tc.mgmt.utils.TargetMgmtUtility;
import com.isg.mw.tc.mgmt.validations.TargetOfflineValidatorImpl;

/**
 * Method implementation for {@link TargetConfigMgmtService}
 * 
 * @author sanchita3984
 *
 */
@Service("targetConfigMgmtService")
@Transactional
public class TargetConfigMgmtServiceImpl implements TargetConfigMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private TargetConfigMasterService targetMasterService;

	@Autowired
	private TargetConfigEditCopyService targetEditService;

	@Autowired
	private TargetOnlineValidator targetOnlineValidator;

	@Autowired
	private TargetOfflineValidatorImpl targetOfflineValidator;

	@Autowired
	private TargetMessenger targetMessenger;

	@Autowired
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@Autowired
	private MessageFormatBulkUpdateService messageFormatBulkUpdateService;

	@Override
	public ResponseEntity<?> get(String name, String entityId) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.GET_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			Map<String, TargetConfigModel> map = new HashMap<String, TargetConfigModel>(2);
			TargetConfigModel master = targetMasterService.findByNameAndEntityId(name, entityId);
			if (master != null) {
				map.put("master", master);
			}
			TargetConfigModel editCopy = targetEditService.findByNameAndEntityId(name, entityId);
			if (editCopy != null) {
				map.put("editCopy", editCopy);
			}
			if (!map.isEmpty()) {
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
				res.setData(map);
				 response = new ResponseEntity<>(res, HttpStatus.OK);

			} else {
				res.setMsg(MessageConstant.NO_CONTENT);
				res.setStatusCode(MessageConstant.FAIL_CODE);
				 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response ;
	}

	@Override
	public ResponseEntity<?> getAll(String entityId) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.GETALL_API_LOG_INFO));
		ResponseEntity<?> response = null;

		try {
			if(entityId != null){
				List<TargetConfigModel> allConfig = targetMasterService.getAllByEntityId(entityId);
				if (!allConfig.isEmpty()) {
					response = new ResponseEntity<>(allConfig, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}else{
				List<TargetConfigModel> allConfig = targetMasterService.getAll();
				if (!allConfig.isEmpty()) {
					response = new ResponseEntity<>(allConfig, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getTargets(String entityId) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.GETTARGETS_API_LOG_INFO, entityId));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			List<String> targets = targetMasterService.getTargets(entityId);
			if (!targets.isEmpty()) {
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
				res.setData(targets);
				response = new ResponseEntity<>(res, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
				res.setMsg(MessageConstant.NO_CONTENT);
				res.setStatusCode(MessageConstant.FAIL_CODE);
				response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> add(AddTargetConfigModel addModel) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.ADD_API_LOG_INFO, addModel));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {

			TargetConfigModel targetModel = TargetMgmtUtility.getTargetConfigModel(addModel);
			targetOfflineValidator.addValidation(targetModel);
			targetOnlineValidator.add(targetModel);
			TargetConfigModel addTargetModel = targetEditService.add(targetModel);
			res.setMsg(MessageConstant.SUCCESS_DESC);
			res.setStatusCode(MessageConstant.SUCCESS_CODE);
			res.setData(addTargetModel);
			response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> modify(ModifyTargetConfigModel modifyModel) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.MODIFY_API_LOG_INFO, modifyModel));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			TargetConfigModel targetModel = TargetMgmtUtility.getTargetConfigModel(modifyModel);
			targetOfflineValidator.modifyValidation(targetModel);
			targetOnlineValidator.modify(targetModel);
			TargetConfigModel modifyTargetModel = targetEditService.update(targetModel);
			res.setMsg(MessageConstant.SUCCESS_DESC);
			res.setStatusCode(MessageConstant.SUCCESS_CODE);
			res.setData(modifyTargetModel);
			response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> submit(String name, String entityId) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.SUBMIT_API_LOG_INFO, entityId));
		ResponseEntity<?> response = null;
		ResponseObj res=new ResponseObj();
		try {
			TargetConfigModel editCopy = targetEditService.findByNameAndEntityId(name, entityId);
			if (editCopy != null) {
				targetOfflineValidator.submitValidation(editCopy);
			}
			targetOnlineValidator.submit(name, entityId);
			String updateStatus = targetEditService.updateStatus(EditStatus.Submitted, name, entityId,null);
			if(updateStatus=="Submitted"){
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			// response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> lock(String name, String entityId, LockedState lockedState) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.LOCK_API_LOG_INFO, entityId));
		ResponseEntity<?> response = null;
		try {
			targetOfflineValidator.lockValidation(name, entityId, lockedState);
			targetOnlineValidator.lock(name, entityId, lockedState);
			LockedState lock = targetMasterService.lock(name, entityId, lockedState);
			ConfigAction action = ConfigAction.UN_LOCKED;
			if (lock.equals(LockedState.Locked)) {
				action = ConfigAction.LOCKED;
			}
			sendMessage(name, entityId, action);
			response = new ResponseEntity<>(lock, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			 response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			 response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> verify(String name, String entityId, boolean approved,String remarks) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.VERIFY_API_LOG_INFO, entityId, approved));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			targetOfflineValidator.verifyValidation(name, entityId, approved,remarks);
			targetOnlineValidator.verify(name, entityId, approved);
			if (approved) {
				TargetConfigEditCopyEntity editCopyEntity = targetEditService.get(name, entityId);
				TargetConfigMasterEntity masterEntity = targetMasterService.get(name, entityId);
				ConfigAction action = ConfigAction.MODIFY;
				if (masterEntity == null) {
					masterEntity = TargetUtility.createMaster(editCopyEntity);
					action = ConfigAction.ADD;
				}
				TargetUtility.updateMaster(editCopyEntity, masterEntity);
				masterEntity.setRemarks(StringUtils.isBlank(remarks)?null:remarks);
				masterEntity = targetMasterService.save(masterEntity);
				targetEditService.delete(editCopyEntity);
				messageFormatBulkUpdateService.moveEditCopyToMaster(editCopyEntity.getId(), masterEntity.getId(),
						OwnerType.TARGET);
				sendMessage(name, entityId, action);
			} else {
				targetEditService.updateStatus(EditStatus.Rejected, name, entityId,remarks);
			}
			if(approved)
			{
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> updateStatus(String name, String entityId, String statusStr) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.UPDATESTATUS_API_LOG_INFO, entityId));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			targetOfflineValidator.updateValidation(name, entityId, statusStr);
			targetOnlineValidator.update(name, entityId, statusStr);
			ConfigStatus status = ConfigStatus.getStatus(statusStr);
			if (status != null) {

				targetMasterService.updateStatus(name, entityId, status);
				ConfigAction action = ConfigAction.ACTIVATE;
				if (status == ConfigStatus.Inactive) {
					action = ConfigAction.INACTIVE;
				}
				sendMessage(name, entityId, action);
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);

			} else {
				TargetConfigEditCopyEntity editCopyEntity = targetEditService.get(name, entityId);
				TargetConfigMasterEntity masterEntity = targetMasterService.get(name, entityId);
				if (editCopyEntity == null) {
					editCopyEntity = new TargetConfigEditCopyEntity();
				}

				TargetUtility.updateEditCopy(masterEntity, editCopyEntity);
				editCopyEntity = targetEditService.save(editCopyEntity);
				messageFormatBulkUpdateService.copyMasterToEditCopy(editCopyEntity.getId(), masterEntity.getId(),
						OwnerType.TARGET);
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getConfigByStatus(String status,String entityId) {
		LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.GET_CONFIG_BY_STATUS_API_LOG_INFO, status));
		ResponseEntity<?> response = null;
		try {
			if(entityId!=null){
				targetOfflineValidator.configByStatusValidation(status);
				if (ConfigStatus.Active == ConfigStatus.getStatus(status)
						|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)
						|| LockedState.Locked == LockedState.getState(status)
						|| LockedState.Unlocked == LockedState.getState(status)) {
					List<TargetConfigModel> entities = targetMasterService.getConfigByStatusAndEntityId(status,entityId);
					response = new ResponseEntity<>(entities, HttpStatus.OK);
				} else if (EditStatus.Inprogress == EditStatus.getStatus(status)
						|| EditStatus.Rejected == EditStatus.getStatus(status)
						|| EditStatus.Submitted == EditStatus.getStatus(status)) {
					List<TargetConfigModel> entities = targetEditService.getConfigByStatusAndEntityId(status,entityId);
					response = new ResponseEntity<>(entities, HttpStatus.OK);
				}
			}
			else{
				targetOfflineValidator.configByStatusValidation(status);
				if (ConfigStatus.Active == ConfigStatus.getStatus(status)
						|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)
						|| LockedState.Locked == LockedState.getState(status)
						|| LockedState.Unlocked == LockedState.getState(status)) {
					List<TargetConfigModel> entities = targetMasterService.getConfigByStatus(status);
					response = new ResponseEntity<>(entities, HttpStatus.OK);
				} else if (EditStatus.Inprogress == EditStatus.getStatus(status)
						|| EditStatus.Rejected == EditStatus.getStatus(status)
						|| EditStatus.Submitted == EditStatus.getStatus(status)) {
					List<TargetConfigModel> entities = targetEditService.getConfigByStatus(status);
					response = new ResponseEntity<>(entities, HttpStatus.OK);
				}
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	/**
	 * Send message on KAFKA
	 * 
	 * @param name         - name of the configuration object
	 * @param configAction - action of the configuration message object
	 */
	private void sendMessage(String name, String entityId, ConfigAction configAction) {
		TargetConfigMasterEntity masterEntity = targetMasterService.get(name, entityId);
		TargetConfigModel targetConfigModel = TargetMasterUtility.getTargetModel(masterEntity);
		targetConfigModel.setMessageFormats(
				messageFormatConfigMasterService.getByOwnerAndOwnerType(targetConfigModel.getId(), OwnerType.TARGET));
		TargetConfigMessage configMessage = new TargetConfigMessage();
		configMessage.setAction(configAction);
		configMessage.setModel(targetConfigModel);
		targetMessenger.send(configMessage);
	}

}