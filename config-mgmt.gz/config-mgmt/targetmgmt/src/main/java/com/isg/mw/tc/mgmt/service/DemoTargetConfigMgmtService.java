package com.isg.mw.tc.mgmt.service;

import com.isg.mw.tc.dao.model.DemoTargetConfigModel;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface DemoTargetConfigMgmtService {

    ResponseEntity<?> updateTargets(List<DemoTargetConfigModel> dTargetModels);

    ResponseEntity<?> getDemoAll();
}
