package com.isg.mw.tc.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.tc.TargetConfigModel;

/**
 * Validates data (data which is coming from out side the system (received data
 * from Rest API)) without hitting database
 * 
 * @author sanchita3984
 *
 */
public interface TargetOfflineValidator {

	/**
	 * Offline validation while adding new Target Configuration model
	 * 
	 * @param model - Target configuration model
	 */
	void addValidation(TargetConfigModel model);

	/**
	 * Offline validation while modifying Target Configuration model
	 * 
	 * @param model - Target configuration model
	 */
	void modifyValidation(TargetConfigModel model);

	/**
	 * Offline validation while submitting Target Configuration model
	 * 
	 * @param editCopy - Target configuration model
	 */
	void submitValidation(TargetConfigModel editCopy);

	/**
	 * Offline validation while verifying Target configuration
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param approved - true if verified or false if rejected
	 */
	void verifyValidation(String name, String entityId, boolean approved,String remarks);

	/**
	 * Offline validation while lock Target configuration
	 * 
	 * @param name        - name of the configuration
	 * @param entityId    - entity id of the configuration
	 * @param lockedState - locked or unlocked
	 */
	void lockValidation(String name, String entityId, LockedState lockedState);

	/**
	 * Offline validation while lock Target configuration
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param status   - new status which is going to change current status
	 */
	void updateValidation(String name, String entityId, String status);

	/**
	 * Offline validation for get Target configuration
	 * 
	 * @param name
	 * @param entityId
	 */
	void get(String name, String entityId);

	void getAllActive();

	/**
	 * Offline validation for getting all targets name
	 * 
	 * @param entityId
	 */
	void alltargets(String entityId);

	void all(String entityId, String status, LockedState lockedState);

}
