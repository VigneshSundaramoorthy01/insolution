package com.isg.mw.tc.mgmt.model;

import java.util.List;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetConnection;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * AddTargetConfig model class which is used to add new configuration
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "${swgr.tcc.model.add}")
@Getter
@Setter
public class AddTargetConfigModel {

	/**
	 * Unique id of the new Target configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.entityId.value}")
	private String entityId;

	/**
	 * Name of the new configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.name.value}")
	private String name;

	/**
	 * Scheme Type (Visa, Master, Rupay)
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.targetType.value}")
	private TargetType targetType;

	/**
	 * Encryption Key
	 */
	/*
	 * @ApiModelProperty(required = false, value =
	 * "${swgr.tcc.model.add.encryptionKey.value}") private byte[] encryptionKey;
	 */

	/**
	 * Decryption Key
	 */
	/*
	 * @ApiModelProperty(required = false, value =
	 * "${swgr.tcc.model.add.decryptionKey.value}") private byte[] decryptionKey;
	 */

	/**
	 * Name of the person who create new configuration
	 */
	//@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.createdBy.value}")
	//private String createdBy;

	/**
	 * List of connection which is consist connection type, url or ip and port or
	 * headers
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.connections.value}")
	private List<TargetConnection> connections;

	/**
	 * sign-on required
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.signonrequired.value}")
	private boolean signonRequired;

	/**
	 * heart beat delay
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.beartbeatdelay.value}")
	private int heartBeatDelay;

	/**
	 * Group Sign On Id
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.groupSignonId.value}")
    private String groupSignonId;
	
	/**
	 * Request time out
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.requestTimeout.value}")
	private int requestTimeout;
	
	/**
	 * Connect Timeout
	 */
	@ApiModelProperty(required = false, value = "${swgr.tcc.model.add.connectTimeout.value}")
	private int connectTimeout;
	
	/**
	 * PinTranslationType (STATIC or DYNAMIC)
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.pinTranslationType.value}")
	private PinTranslationType pinTranslationType;
	
	/**
	 * Netty Parameters
	 */
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.nettyParameters.value}")
	private NettyConfig nettyParameters;
	
	@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.target.value}")
	private Target target;

	@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.additionalData.value}")
	private TargetAdditionalData additionalData;

	@ApiModelProperty(required = true, value = "processingFee")
	private Double processingFee;
}
