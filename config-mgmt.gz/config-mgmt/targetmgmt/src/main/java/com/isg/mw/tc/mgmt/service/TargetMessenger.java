/**
 * 
 */
package com.isg.mw.tc.mgmt.service;

import com.isg.mw.core.model.tc.TargetConfigMessage;

/**
 * Target messenger
 * 
 * @author prasad_t026
 *
 */
public interface TargetMessenger {

	/**
	 * Send the Target configuration message model using KAFKA producer
	 * 
	 * @param model - Target message model
	 */
	void send(TargetConfigMessage model);

}