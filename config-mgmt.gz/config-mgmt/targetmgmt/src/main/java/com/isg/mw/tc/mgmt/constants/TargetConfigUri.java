package com.isg.mw.tc.mgmt.constants;

/**
 * Definitions of Target Configuration URIs
 * 
 * @author prasad_t026
 *
 */
public interface TargetConfigUri {

	/**
	 * Used for parent URI
	 */
	String PARENT = "/target";
	
	/**
	 * Used for get API URI
	 */
	String GET_BY_NAME = "/get";
	
	/**
	 * Used for getAll API URI
	 */
	String GET_ALL = "/getallactive";
	
	/**
	 * Used for get all target configuration names which are unlocked  
	 */
	String GET_NAMES_ONLY = "/alltargets";
	
	/**
	 * Used for add API URI
	 */
	String ADD = "/add";
	
	/**
	 * Used for submit API URI
	 */
	String SUBMIT = "/submit";
	
	/**
	 * Used for save API URI
	 */
	String MODIFY = "/update";
	
	/**
	 * Used for verify API URI
	 */
	String VERIFY = "/verify";
	
	/**
	 * Used for update API URI
	 */
	String UPDATE_STATUS = "/changestatus";
	
	/**
	 * Used for lock API URI
	 */
	String LOCK = "/lock";
	
	String GET_CONFIG_BY_STATUS = "/getConfigByStatus";


}