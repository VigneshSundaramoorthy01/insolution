package com.isg.mw.tc.mgmt.service;

import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.tc.mgmt.model.AddTargetConfigModel;
import com.isg.mw.tc.mgmt.model.ModifyTargetConfigModel;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Handles the Target configuration rest services
 * 
 * @author prasad_t026
 *
 */
public interface TargetConfigMgmtService {

	/**
	 * Retrieve Target Configuration from DB base on name and entity id
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> get(String name, String entityId);

	/**
	 * Retrieve all Target Configuration from DB
	 * 
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> getAll( String entityId);

	/**
	 * Retrieve Target Configuration from DB base on entity id
	 * 
	 * @param entityId - entity id of the configuration
	 * @return - Configuration Object with 'OK' status if exists, 'NOT_FOUND' status
	 *         if not exists, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> getTargets(String entityId);

	/**
	 * Add requested Target Configuration model in DB
	 * 
	 * @param addModel - add Target configuration model
	 * @return - Configuration Object with 'OK' status if added successfully,
	 *         'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> add(AddTargetConfigModel addModel);

	/**
	 * Modify requested Target Configuration model in DB
	 * 
	 * @param modifyModel - modify Target configuration model
	 * @return - Configuration Object with 'OK' status if updated successfully,
	 *         'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> modify(ModifyTargetConfigModel modifyModel);

	/**
	 * Submit requested Target Configuration model in DB with name and entity id
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @return - Configuration updated status with 'OK' status if submitted
	 *         successfully, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> submit(String name, String entityId);

	/**
	 * Lock or unlock requested Target Configuration model in DB with name and
	 * entity id
	 * 
	 * @param name        - name of the configuration
	 * @param entityId    - entity id of the configuration
	 * @param lockedState - lock or unlocked state
	 * @return - Configuration updated state with 'OK' status if changed state
	 *         successfully, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> lock(String name, String entityId, LockedState lockedState);

	/**
	 * Verify requested Target Configuration model in DB with name and entity id
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param approved - true if verified or false if rejected
	 * @return - true with 'OK' status if verified successfully, false with 'OK'
	 *         status if rejected, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> verify(String name, String entityId, boolean approved,String remarks);

	/**
	 * Update status requested Target Configuration model in DB with name and entity
	 * id
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param status   - status to be update
	 * @return - Configuration updated status with 'OK' status if changed state
	 *         successfully, 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> updateStatus(String name, String entityId, String status);
	
	ResponseEntity<?> getConfigByStatus(String status, String entityId);


}