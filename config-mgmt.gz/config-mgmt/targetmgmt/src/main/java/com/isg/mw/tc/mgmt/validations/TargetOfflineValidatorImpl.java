package com.isg.mw.tc.mgmt.validations;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.tc.dao.utils.TargetCommonUtil;
import com.isg.mw.tc.mgmt.constants.TargetMgmtMsgKeys;

/**
 * Method implementation of {@link TargetOfflineValidator}
 * 
 * @author sanchita3984
 *
 */
@Service("targetOfflineValidator")
public class TargetOfflineValidatorImpl implements TargetOfflineValidator {

	@Override
	public void addValidation(TargetConfigModel model) {
		UserDataValidations.entityIdValidations(model.getEntityId(), true);
		UserDataValidations.nameValidations(model.getName(), true);
		// UserDataValidations.userNameValidations(model.getCreatedBy(), true);
		UserDataValidations.stringPreDefiendDataValidation(model.getPinTranslationType()!=null?model.getPinTranslationType().name():null,FieldsInfo.PIN_TRANSLATION_TYPE_VALUES, FieldsInfo.PIN_TRANSLATION_TYPE_FN, true);
		validateNettyConfigData(model.getNettyParameters());
		optionalDataCheck(model);
		additionalDataCheck(model.getAdditionalData());
	}

	private void additionalDataCheck(TargetAdditionalData additionalData) {
		if (additionalData != null) {
			UserDataValidations.acquirerIdValidations(additionalData.getAcquirerId(), false);
			UserDataValidations.fwdInstIdValidations(additionalData.getFwdInstId(), false);
            TargetApiInfo apiUrls = additionalData.getApiInfo();
            if(apiUrls != null) {
//            	UserDataValidations.ipAndPortOrUrlValidations(apiUrls.getTargetUrl(), false);
            }
		}
	}

	@Override
	public void modifyValidation(TargetConfigModel model) {
		UserDataValidations.entityIdValidations(model.getEntityId(), true);
		UserDataValidations.nameValidations(model.getName(), true);
		// UserDataValidations.userNameValidations(model.getUpdatedBy(), true);
		UserDataValidations.stringPreDefiendDataValidation(model.getPinTranslationType()!=null?model.getPinTranslationType().name():null,FieldsInfo.PIN_TRANSLATION_TYPE_VALUES, FieldsInfo.PIN_TRANSLATION_TYPE_FN, true);
		validateNettyConfigData(model.getNettyParameters());
		additionalDataCheck(model.getAdditionalData());
		optionalDataCheck(model);
	}

	@Override
	public void submitValidation(TargetConfigModel editCopy) {

		if (editCopy.getTargetType() == null) {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.SCHEME_TYPE_FN);
		}
		if (editCopy.getConnections() == null || editCopy.getConnections().isEmpty()) {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY,
					FieldsInfo.TARGET_CONNECTIONS_FN);
		}

	}

	@Override
	public void verifyValidation(String name, String entityId, boolean approved,String remarks) {
		if (StringUtils.isBlank(name)){
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		if(!approved && StringUtils.isBlank(remarks)) {
			throw new ValidationException(TargetMgmtMsgKeys.REMARK_TARGET_IS_MANDATORY, FieldsInfo.REMARKS_FN);
		}
	}

	@Override
	public void lockValidation(String name, String entityId, LockedState lockedState) {
		if (StringUtils.isBlank(name)){
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)){
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		UserDataValidations.lockedStateValidations(lockedState, true);
	}

	@Override
	public void updateValidation(String name, String entityId, String status) {
		if (StringUtils.isBlank(name)){
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)){
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.UPDATE_STATUS_VALUES,
				FieldsInfo.UPDATE_STATUS_FN, true);

	}

	@Override
	public void get(String name, String entityId) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId))  {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}

	}

	@Override
	public void getAllActive() {
	}

	@Override
	public void alltargets(String entityId) {

		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}

	}

	@Override
	public void all(String entityId, String status, LockedState lockedState) {
		UserDataValidations.entityIdValidations(entityId, true);
		// TODO has to build after implementation of the method
	}

	private void optionalDataCheck(TargetConfigModel model) {
		UserDataValidations.schemeTypeValidations(model.getTargetType(),true);
		UserDataValidations.groupSignonIdValidations(model.getGroupSignonId(), false);
		if (model.getConnections() != null && !model.getConnections().isEmpty()) {

			String[] cstrs = new String[model.getConnections().size()];
			int i = 0;
			for (TargetConnection tc : model.getConnections()) {
				connectionValidations(tc);
				cstrs[i] = IsgJsonUtils.getJsonString(tc);
				i++;
			}
			if (UserDataValidations.duplicateCheck(cstrs)) {
				throw new ValidationException(TargetMgmtMsgKeys.DATA_LIST_SHOULD_NOT_HAVE_DUPLICATE,
						FieldsInfo.TARGET_CONNECTIONS_FN);
			}

			String cs = TargetCommonUtil.convertTargetConnectionListToString(model.getConnections());
			if (cs.length() > FieldsInfo.TARGET_CONNECTIONS_LN) {
				throw new ValidationException(TargetMgmtMsgKeys.DATA_LENGTH_EXCEEDED, FieldsInfo.TARGET_CONNECTIONS_FN,
						FieldsInfo.TARGET_CONNECTIONS_LN);
			}
		}
	}

	private void connectionValidations(TargetConnection connection) {
		if (connection == null) {
			throw new ValidationException(TargetMgmtMsgKeys.DATA_LIST_SHOULD_NOT_HAVE_NULL,
					FieldsInfo.TARGET_CONNECTIONS_FN);
		}
		if (connection.getType() == null) {
			throw new ValidationException(TargetMgmtMsgKeys.TARGET_FIELD_IS_MANDATORY,
					FieldsInfo.TARGET_CONNECTIONS_TYPE_FN);
		}
		if (connection.getType() == ConnectionType.WEB) {
			UserDataValidations.urlValidations(connection.getUrlOrIp(), true);
		} else if (connection.getType() == ConnectionType.ISO) {
			UserDataValidations.ipAddressValidations(connection.getUrlOrIp(), true);
			UserDataValidations.portValidations(connection.getPortOrHeaders(), true);
		}
	}

	private void validateNettyConfigData(NettyConfig nettyParam) {
		UserDataValidations.intDataValidations(nettyParam.getPacketMaxFrameLength(), Integer.MAX_VALUE,
				FieldsInfo.PACKET_MAX_FRAME_LENGTH, true);
		UserDataValidations.intDataValidations(nettyParam.getPacketLengthFieldLength(), Integer.MAX_VALUE,
				FieldsInfo.PACKET_LENGTH_FIELD_LENGTH, true);
		UserDataValidations.intTargetNettyConfigDataValidations(nettyParam.getPacketLengthOffset(), Integer.MAX_VALUE,
				FieldsInfo.PACKET_LENGTH_OFFSET, true);
		UserDataValidations.intTargetNettyConfigDataValidations(nettyParam.getPacketLengthFieldAdjustment(),
				Integer.MAX_VALUE, FieldsInfo.PACKET_LENGTH_FIELD_ADJUSTMENT, true);
		UserDataValidations.intTargetNettyConfigDataValidations(nettyParam.getPacketInitialBytesToStrip(), Integer.MAX_VALUE,
				FieldsInfo.PACKET_INITIAL_BYTES_TO_STRIP, true);
	}

	public void configByStatusValidation(String status) {
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.CONFIG_BY_STATUS_VALUES,
				FieldsInfo.CONFIG_BY_STATUS_FN, true);
	}

}