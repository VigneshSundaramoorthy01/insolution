package com.isg.mw.tc.mgmt.service.impl;

import com.isg.mw.bn.mgmt.service.DemoBinInfoMgmtService;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.tc.dao.model.DemoTargetConfigModel;
import com.isg.mw.tc.dao.service.DemoTargetConfigMasterService;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import com.isg.mw.tc.mgmt.constants.TargetMgmtMsgKeys;
import com.isg.mw.tc.mgmt.service.DemoTargetConfigMgmtService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service("demoTargetConfigMgmtService")
@Transactional
public class DemoTargetConfigMgmtServiceImpl implements DemoTargetConfigMgmtService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private DemoTargetConfigMasterService demoTargetMasterService;

    @Autowired
    private TargetConfigMasterService targetMasterService;

    @Autowired
    private DemoBinInfoMgmtService demoBinService;


    public ResponseEntity<?> updateTargets(List<DemoTargetConfigModel> dTargetModels) {
        LOG.info("Get Active Targets : ");
        ResponseEntity<?> response = null;
        try {
            if (dTargetModels.isEmpty()) {
                throw new ValidationException(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
            }
            LOG.info("Get the target from having min processing fee  : ");
            TargetConfigModel target = demoTargetMasterService.updateTargets(dTargetModels);
            boolean updateBinOnus = demoBinService.updateBin(target);
            if (updateBinOnus) {
                response = new ResponseEntity<>("Target Update Successfully", HttpStatus.OK);
            } else {
                response = new ResponseEntity<>("Target Not Update", HttpStatus.NO_CONTENT);
            }
            return response;
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getDemoAll() {
        LOG.info(PropertyUtils.getMessage(TargetMgmtMsgKeys.GETALL_API_LOG_INFO));
        ResponseEntity<?> response = null;
        try {
            List<TargetConfigModel> models = targetMasterService.getAll();
            List<TargetConfigModel> allConfig = models.stream().filter(targetConfigModel -> targetConfigModel.getTarget() == Target.Issuer).collect(Collectors.toList());
            if (!allConfig.isEmpty()) {
                response = new ResponseEntity<>(allConfig, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.TARGET_LIST_EMPTY);
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetMgmtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

}
