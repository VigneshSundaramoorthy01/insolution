package com.isg.mw.tc.controller;

import com.isg.mw.tc.dao.model.DemoTargetConfigModel;
import com.isg.mw.tc.mgmt.constants.TargetConfigUri;
import com.isg.mw.tc.mgmt.service.DemoTargetConfigMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Target configuration", description = "Target configuration APIs" )
@RestController
@RequestMapping(value = TargetConfigUri.PARENT)
public class DemoTargetConfigMgmtController {

    @Autowired
    private DemoTargetConfigMgmtService targetConfigMgmtService;

    @Operation(summary = "API To update Target configuration", description = "In response will get Target configuration", tags = {"Target configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = "/updatetargets")
    public ResponseEntity<?> getUpdateTarges(
            @RequestBody List<DemoTargetConfigModel> dTargetModel) {
        return targetConfigMgmtService.updateTargets(dTargetModel);
    }

    @GetMapping(path = "getallactivetargets", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getDemoAll() {
        return targetConfigMgmtService.getDemoAll();
    }
}
