package com.isg.mw.security.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.security.dao.constants.KeyProviderDaoMsgKeys;
import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;
import com.isg.mw.security.dao.repository.KeyProviderEditCopyRepository;
import com.isg.mw.security.dao.repository.KeyProviderMasterRepository;
import com.isg.mw.security.dao.service.KeyProviderOnlineValidator;

@Service("keyProviderOnlineValidator")
public class KeyProviderOnlineValidatorImpl implements KeyProviderOnlineValidator {

	@Autowired
	private KeyProviderEditCopyRepository keyProviderEditCopyRepository;

	@Autowired
	private KeyProviderMasterRepository keyProviderMasterRepository;

	@Override
	public boolean isKeyProviderExists(String name, String consumerType, SecurityKeyType keyType) {
		return keyProviderMasterRepository.isKeyProviderExists(name, consumerType, keyType);
	}

	@Override
	public boolean isKeyProviderUnlocked(String name, String consumerType, SecurityKeyType keyType) {
		return keyProviderMasterRepository.isKeyProviderExists(name, consumerType, keyType, LockedState.Unlocked);
	}

	@Override
	public void add(KeyProvider model) {
		if (isKeyProviderExists(model.getName(), model.getConsumerType(), model.getKeyType())) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_DUPLICATE_NAME_IN_MASTER, model.getName());
		}
		if (keyProviderEditCopyRepository.isKeyProviderExists(model.getName(), model.getConsumerType(),
				model.getKeyType())) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_DUPLICATE_NAME_IN_EDITCOPY,
					model.getName());
		}
	}

	@Override
	public void modify(KeyProvider model) {
		checkIsUnLocked(model.getName(), model.getConsumerType(), model.getKeyType());
		KeyProviderEditCopyEntity editEntity = getKeyProviderEditCopyEntity(model.getName(), model.getConsumerType(),
				model.getKeyType());
		if (editEntity == null) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_EDITCOPY,
					editEntity.getName());
		}
		if (editEntity.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_STATUS_IS_SUBMITTED_STATUS,
					editEntity.getName());
		}
	}

	@Override
	public void submit(String name, String consumerType, SecurityKeyType keyType) {
		checkIsUnLocked(name, consumerType, keyType);
		KeyProviderEditCopyEntity editCopy = getKeyProviderEditCopyEntity(name, consumerType, keyType);
		if (editCopy == null) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_EDITCOPY, name);
		}
		if (editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_STATUS_IS_SUBMITTED_STATUS, name);
		}
	}

	@Override
	public void verify(String name, String consumerType, SecurityKeyType keyType, boolean approved) {
		checkIsUnLocked(name, consumerType, keyType);
		KeyProviderEditCopyEntity editCopy = getKeyProviderEditCopyEntity(name, consumerType, keyType);
		if (editCopy == null) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_EDITCOPY, name);
		}
		if (editCopy.getStatus() != EditStatus.Submitted) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_STATUS_IS_NOT_SUBMITTED_STATUS, name);
		}

	}

	@Override
	public void lock(String name, String consumerType, SecurityKeyType keyType, LockedState lockedState) {
		KeyProviderMasterEntity master = getKeyProviderMasterEntity(name, consumerType, keyType);
		if (master == null) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_MASTER, name);
		}
		if (lockedState == master.getLockedState()) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_LOCKEDSTATE_IS_SAME_AS_EXPECTED, name,
					lockedState);
		}

	}

	@Override
	public void update(String name, String consumerType, SecurityKeyType keyType, String status) {
		checkIsUnLocked(name, consumerType, keyType);
		KeyProviderMasterEntity master = getKeyProviderMasterEntity(name, consumerType, keyType);
		if (master == null) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_MASTER, name);
		}
		if (status.equals(master.getStatus().name())) {
			throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_STATUS_IS_SAME_AS_EXPECTED, name, status);
		}
		if (status.equals(EditStatus.Inprogress.name())) {
			KeyProviderEditCopyEntity editCopy = getKeyProviderEditCopyEntity(name, consumerType, keyType);
			if (editCopy != null && editCopy.getStatus() != EditStatus.Inprogress) {
				throw new ValidationException(KeyProviderDaoMsgKeys.KEYPROVIDER_STATUS_IS_NOT_INPROGRESS_STATUS, name);
			}
		}

	}

	private void checkIsUnLocked(String name, String consumerType, SecurityKeyType keyType) {
		KeyProviderMasterEntity master = getKeyProviderMasterEntity(name, consumerType, keyType);
		if (master != null && master.getLockedState() == LockedState.Locked) {
			throw new ValidationException(KeyProviderDaoMsgKeys.SYSTEM_WONT_ALLOW_TO_MODIFY, master.getName());
		}

	}

	private KeyProviderMasterEntity getKeyProviderMasterEntity(String name, String consumerType,
			SecurityKeyType keyType) {
		List<KeyProviderMasterEntity> entities = keyProviderMasterRepository.findByNameConsumerTypeAndKeyType(name,
				consumerType, keyType);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}

	private KeyProviderEditCopyEntity getKeyProviderEditCopyEntity(String name, String consumerType,
			SecurityKeyType keyType) {
		List<KeyProviderEditCopyEntity> entities = keyProviderEditCopyRepository.findByNameConsumerTypeAndKeyType(name,
				consumerType, keyType);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}
}
