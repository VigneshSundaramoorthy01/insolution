package com.isg.mw.security.dao.utils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;

public class KeyProviderUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private KeyProviderUtility() {

	}

	public static void updateEditCopy(KeyProviderMasterEntity master, KeyProviderEditCopyEntity editCopy) {
		editCopy.setName(master.getName());
		editCopy.setBuilderType(master.getBuilderType());
		editCopy.setConsumerType(master.getConsumerType());
		editCopy.setKeyType(master.getKeyType());
		editCopy.setConfigs(master.getConfigs());
		editCopy.setStatus(EditStatus.Inprogress);
	}

	public static void updateMaster(KeyProviderEditCopyEntity editCopy, KeyProviderMasterEntity master) {
		master.setName(editCopy.getName());
		master.setBuilderType(editCopy.getBuilderType());
		master.setConsumerType(editCopy.getConsumerType());
		master.setKeyType(editCopy.getKeyType());
		master.setConfigs(editCopy.getConfigs());
	}

	public static KeyProviderMasterEntity createMaster(KeyProviderEditCopyEntity editCopy) {
		KeyProviderMasterEntity master = new KeyProviderMasterEntity();
		master.setName(editCopy.getName());
		master.setBuilderType(editCopy.getBuilderType());
		master.setConsumerType(editCopy.getConsumerType());
		master.setKeyType(editCopy.getKeyType());
		master.setConfigs(editCopy.getConfigs());
		master.setStatus(ConfigStatus.Active);
		master.setLockedState(LockedState.Unlocked);
		return master;
	}

}
