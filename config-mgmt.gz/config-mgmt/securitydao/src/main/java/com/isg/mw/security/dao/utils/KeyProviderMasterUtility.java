package com.isg.mw.security.dao.utils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;
import com.isg.mw.security.dao.model.KeyProvider;

public class KeyProviderMasterUtility {
	
	/**
	 * Default constructor It should not access from out side
	 */
	private KeyProviderMasterUtility() {

	}

	public static KeyProvider getKeyProviderModel(KeyProviderMasterEntity entity) {
		KeyProvider model = new KeyProvider();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setBuilderType(entity.getBuilderType());
		model.setConsumerType(entity.getConsumerType());
		model.setKeyType(entity.getKeyType());
		model.setConfigs(entity.getConfigs());
	//	model.setStatus(entity.getStatus().name());
//		model.setLockedState(entity.getLockedState());
		return model;
	}

	public static KeyProviderMasterEntity getKeyProviderEntity(KeyProvider model) {
		KeyProviderMasterEntity entity = new KeyProviderMasterEntity();
		entity.setId(model.getId());
		entity.setName(model.getName());
		entity.setBuilderType(model.getBuilderType());
		entity.setConsumerType(model.getConsumerType());
		entity.setKeyType(model.getKeyType());
		entity.setConfigs(model.getConfigs());
		entity.setStatus(ConfigStatus.Active);
		entity.setLockedState(LockedState.Unlocked);
		return entity;
	}

	public static void updateKeyProviderEntity(KeyProvider model, KeyProviderMasterEntity entity) {
		entity.setId(model.getId());
		entity.setName(model.getName());
		entity.setBuilderType(model.getBuilderType());
		entity.setConsumerType(model.getConsumerType());
		entity.setKeyType(model.getKeyType());
		entity.setConfigs(model.getConfigs());
	}


}
