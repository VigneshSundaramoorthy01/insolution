package com.isg.mw.security.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;
import com.isg.mw.security.dao.repository.KeyProviderEditCopyRepository;
import com.isg.mw.security.dao.service.KeyProviderEditCopyService;
import com.isg.mw.security.dao.utils.KeyProviderEditCopyUtility;

@Service("keyProviderService")
public class KeyProviderEditCopyServiceImpl implements KeyProviderEditCopyService {

	@Autowired
	private KeyProviderEditCopyRepository keyProviderEditCopyRepository;

	@Override
	public KeyProvider add(KeyProvider kpModel) {
		KeyProviderEditCopyEntity savedEntity = keyProviderEditCopyRepository
				.save(KeyProviderEditCopyUtility.getKeyProviderEntity(kpModel));
		return KeyProviderEditCopyUtility.getKeyProviderModel(savedEntity);
	}

	@Override
	public KeyProvider update(KeyProvider kpModel) {
		KeyProviderEditCopyEntity keyProviderEntity = get(kpModel.getName(), kpModel.getConsumerType(),
				kpModel.getKeyType());
		KeyProviderEditCopyUtility.updateKeyProviderEntity(kpModel, keyProviderEntity);
		KeyProviderEditCopyEntity updatedEntity = keyProviderEditCopyRepository.save(keyProviderEntity);
		return KeyProviderEditCopyUtility.getKeyProviderModel(updatedEntity);
	}

	@Override
	public KeyProvider findByNameConsumerTypeAndKeyType(String name, String consumerType, SecurityKeyType keyType) {
		KeyProviderEditCopyEntity keyProviderEntity = get(name, consumerType, keyType);
		KeyProvider keyProviderModel = null;
		if (keyProviderEntity != null) {
			keyProviderModel = KeyProviderEditCopyUtility.getKeyProviderModel(keyProviderEntity);
		}
		return keyProviderModel;
	}

	@Override
	public boolean isKeyProviderExists(String name, String consumerType, SecurityKeyType keyType) {
		boolean keyProviderExists = keyProviderEditCopyRepository.isKeyProviderExists(name, consumerType, keyType);
		if (keyProviderExists) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String updateStatus(EditStatus status, String name, String consumerType, SecurityKeyType keyType) {
		KeyProviderEditCopyEntity keyProviderEntity = get(name, consumerType, keyType);
		keyProviderEntity.setStatus(status);
		keyProviderEntity = keyProviderEditCopyRepository.save(keyProviderEntity);
		return keyProviderEntity.getStatus().name();
	}

	@Override
	public KeyProviderEditCopyEntity get(String name, String consumerType, SecurityKeyType keyType) {
		List<KeyProviderEditCopyEntity> entities = keyProviderEditCopyRepository.findByNameConsumerTypeAndKeyType(name,
				consumerType, keyType);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}

	@Override
	public KeyProviderEditCopyEntity save(KeyProviderEditCopyEntity entity) {
		return keyProviderEditCopyRepository.save(entity);
	}

	@Override
	public void delete(KeyProviderEditCopyEntity entity) {
		keyProviderEditCopyRepository.delete(entity);

	}

}
