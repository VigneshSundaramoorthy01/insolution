package com.isg.mw.security.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.model.SecurityKeyType;

public interface KeyProviderEditCopyRepository extends CrudRepository<KeyProviderEditCopyEntity, Long> {

	@Query("SELECT kp FROM KeyProviderEditCopyEntity kp WHERE kp.name = :name AND"
			+ "kp.consumertype = :consumerType AND kp.keytype = :keyType")
	List<KeyProviderEditCopyEntity> findByNameConsumerTypeAndKeyType(@Param("name") String name,
			@Param("consumerType") String consumerType, @Param("keyType") SecurityKeyType keyType);

	@Query("SELECT CASE WHEN COUNT(kp) > 0 THEN true ELSE false END FROM KeyProviderEditCopyEntity tm WHERE kp.name = :name AND"
			+ "kp.consumertype = :consumerType AND kp.keytype = :keyType")
	boolean isKeyProviderExists(@Param("name") String name, @Param("consumerType") String consumerType,
			@Param("keyType") SecurityKeyType keyType);

}
