package com.isg.mw.security.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;
import com.isg.mw.security.dao.model.SecurityKeyType;

public interface KeyProviderMasterRepository extends CrudRepository<KeyProviderMasterEntity, Long> {

	@Query("SELECT kp FROM KeyProviderMasterEntity kp WHERE kp.name = :name AND"
			+ "kp.consumertype = :consumerType AND kp.keytype = :keyType")
	List<KeyProviderMasterEntity> findByNameConsumerTypeAndKeyType(@Param("name") String name,
			@Param("consumerType") String consumerType, @Param("keyType") SecurityKeyType keyType);

	@Query("SELECT CASE WHEN COUNT(kp) > 0 THEN true ELSE false END FROM KeyProviderMasterEntity tm WHERE kp.name = :name AND"
			+ "kp.consumertype = :consumerType AND kp.keytype = :keyType")
	boolean isKeyProviderExists(@Param("name") String name, @Param("consumerType") String consumerType,
			@Param("keyType") SecurityKeyType keyType);

	@Query("SELECT CASE WHEN COUNT(kp) > 0 THEN true ELSE false END FROM KeyProviderMasterEntity tm WHERE kp.name = :name AND"
			+ "kp.consumertype = :consumerType" + "kp.keytype = :keyType AND kp.lockedstate = :lockedState")
	boolean isKeyProviderExists(@Param("name") String name, @Param("consumerType") String consumerType,
			@Param("keyType") SecurityKeyType keyType, @Param("lockedstate") LockedState ls);

	@Query("SELECT kp FROM KeyProviderMasterEntity kp WHERE kp.status = :status and kp.lockedState = :ls")
	List<KeyProviderMasterEntity> getAll(@Param("status") ConfigStatus status, @Param("ls") LockedState ls);
	
	@Query("SELECT kp FROM KeyProviderMasterEntity kp WHERE kp.consumertype = :consumerType")
	List<KeyProviderMasterEntity> findByConsumerType(@Param("consumerType") String consumerType);

}
