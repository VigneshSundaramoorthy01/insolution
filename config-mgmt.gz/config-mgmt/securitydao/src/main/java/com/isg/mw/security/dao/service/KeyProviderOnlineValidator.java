package com.isg.mw.security.dao.service;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;

public interface KeyProviderOnlineValidator {

	/**
	 * Finds matching KeyProvider configuration is exists or not with given name and
	 * entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return - true value if configuration is exists or false if not exists
	 */
	boolean isKeyProviderExists(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Finds matching KeyProvider configuration is unlocked or not with given name and
	 * entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return - true value if configuration is unlocked or false if not
	 */
	boolean isKeyProviderUnlocked(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Validates while adding new KeyProvider configuration
	 * 
	 * @param model - new KeyProvider configuration which is to be add
	 */
	void add(KeyProvider model);

	/**
	 * Validates while modifying existing KeyProvider configuration
	 * 
	 * @param model - modify KeyProvider configuration
	 */
	void modify(KeyProvider model);

	/**
	 * Validates while submitting KeyProvider configuration with given name and entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 */
	void submit(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Validates while verifying KeyProvider configuration with given name and entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @param approved     - True for verified and false for not rejected
	 */
	void verify(String name, String consumerType, SecurityKeyType keyType, boolean approved);

	/**
	 * Validates while applying lock on KeyProvider configuration with given name and
	 * entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @param lockedState  - locked or unlocked state
	 */
	void lock(String name, String consumerType, SecurityKeyType keyType, LockedState lockedState);

	/**
	 * Validates while updating status of KeyProvider configuration with given name and
	 * entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @param status       - new status of KeyProvider configuration
	 */
	void update(String name, String consumerType, SecurityKeyType keyType, String status);

}
