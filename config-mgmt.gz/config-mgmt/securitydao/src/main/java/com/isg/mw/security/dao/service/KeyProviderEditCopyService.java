package com.isg.mw.security.dao.service;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;

public interface KeyProviderEditCopyService {

	/**
	 * Add new given KeyProvider configuration model
	 * 
	 * @param kpModel - KeyProvider configuration model
	 * @return added KeyProvider configuration model object
	 */
	KeyProvider add(KeyProvider kpModel);

	/**
	 * Update existing KeyProvider configuration with given model
	 * 
	 * @param kpModel - KeyProvider configuration model
	 * @return updated KeyProvider configuration model object
	 */
	KeyProvider update(KeyProvider kpModel);

	/**
	 * Finds matching KeyProvider Configuration model with given name and entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return matching KeyProvider configuration model object
	 */
	KeyProvider findByNameConsumerTypeAndKeyType(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Finds matching KeyProvider configuration is exists or not with given name and
	 * entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return - true value if configuration is exists or false if not exists
	 */
	boolean isKeyProviderExists(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Update status of KeyProvider configuration with given status
	 * 
	 * @param status       - new status
	 * @param name         - name of KeyProvider configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return KeyProvider configuration changed status
	 */
	String updateStatus(EditStatus status, String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Get matching KeyProvider configuration with given name and entity id
	 * 
	 * @param name         - name of the KeyProvider configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return matching KeyProvider configuration entity
	 */
	KeyProviderEditCopyEntity get(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Save given KeyProvider configuration edit copy entity
	 * 
	 * @param entity - entity id of the configuration
	 * @return saved KeyProvider configuration edit copy entity
	 */
	KeyProviderEditCopyEntity save(KeyProviderEditCopyEntity entity);

	/**
	 * Delete KeyProvider Configuration edit copy with given entity id
	 * 
	 * @param entity - entity id of the configuration
	 */
	void delete(KeyProviderEditCopyEntity entity);

}
