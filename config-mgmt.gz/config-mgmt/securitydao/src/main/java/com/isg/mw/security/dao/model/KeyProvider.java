package com.isg.mw.security.dao.model;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KeyProvider {

	private Long id;
	
	private String name;

	private String builderType;
	
	private String consumerType;
	
	private SecurityKeyType keyType;
	
	private Map<String, String> configs;

}
