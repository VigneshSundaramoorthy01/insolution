package com.isg.mw.security.dao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;
import com.isg.mw.security.dao.repository.KeyProviderMasterRepository;
import com.isg.mw.security.dao.service.KeyProviderMasterService;
import com.isg.mw.security.dao.utils.KeyProviderMasterUtility;

public class KeyProviderMasterServiceImpl implements KeyProviderMasterService {

	@Autowired
	private KeyProviderMasterRepository keyProviderMasterRepository;

	@Override
	public KeyProvider add(KeyProvider kpModel) {
		KeyProviderMasterEntity savedEntity = keyProviderMasterRepository
				.save(KeyProviderMasterUtility.getKeyProviderEntity(kpModel));
		return KeyProviderMasterUtility.getKeyProviderModel(savedEntity);
	}

	@Override
	public KeyProvider update(KeyProvider kpModel) {
		KeyProviderMasterEntity masterEntity = get(kpModel.getName(), kpModel.getConsumerType(), kpModel.getKeyType());
		KeyProviderMasterUtility.updateKeyProviderEntity(kpModel, masterEntity);
		KeyProviderMasterEntity updatedEntity = keyProviderMasterRepository.save(masterEntity);
		return KeyProviderMasterUtility.getKeyProviderModel(updatedEntity);
	}

	@Override
	public KeyProvider findByNameConsumerTypeAndKeyType(String name, String consumerType, SecurityKeyType keyType) {
		KeyProviderMasterEntity masterEntity = get(name, consumerType, keyType);
		KeyProvider model = null;
		if (masterEntity != null) {
			model = KeyProviderMasterUtility.getKeyProviderModel(masterEntity);
		}
		return model;
	}

	@Override
	public String updateStatus(ConfigStatus status, String name, String consumerType, SecurityKeyType keyType) {
		KeyProviderMasterEntity masterEntity = get(name, consumerType, keyType);
		masterEntity.setStatus(status);
		KeyProviderMasterEntity entity = keyProviderMasterRepository.save(masterEntity);
		return entity.getStatus().name();
	}

	@Override
	public KeyProviderMasterEntity get(String name, String consumerType, SecurityKeyType keyType) {
		List<KeyProviderMasterEntity> entities = keyProviderMasterRepository.findByNameConsumerTypeAndKeyType(name,
				consumerType, keyType);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}

	@Override
	public KeyProviderMasterEntity save(KeyProviderMasterEntity entity) {
		return keyProviderMasterRepository.save(entity);
	}

	@Override
	public LockedState lock(String name, String consumerType, SecurityKeyType keyType, LockedState ls) {
		KeyProviderMasterEntity masterEntity = get(name, consumerType, keyType);
		masterEntity.setLockedState(ls);
		masterEntity = keyProviderMasterRepository.save(masterEntity);
		return masterEntity.getLockedState();
	}

	@Override
	public List<KeyProvider> getAllActive(String consumerType) {
		List<KeyProviderMasterEntity> entities = keyProviderMasterRepository.findByConsumerType(consumerType);
		List<KeyProvider> models = new ArrayList<KeyProvider>();
		if (entities != null && !entities.isEmpty()) {
			for (KeyProviderMasterEntity entity : entities) {
				KeyProvider model = KeyProviderMasterUtility.getKeyProviderModel(entity);
				models.add(model);
			}
		}
		return models;
	}

}
