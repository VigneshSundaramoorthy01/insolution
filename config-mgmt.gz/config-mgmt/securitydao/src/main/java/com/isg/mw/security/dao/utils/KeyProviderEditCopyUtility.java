package com.isg.mw.security.dao.utils;

import com.isg.mw.security.dao.entity.KeyProviderEditCopyEntity;
import com.isg.mw.security.dao.model.KeyProvider;

public class KeyProviderEditCopyUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private KeyProviderEditCopyUtility() {

	}

	public static KeyProvider getKeyProviderModel(KeyProviderEditCopyEntity entity) {
		KeyProvider model = new KeyProvider();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setBuilderType(entity.getBuilderType());
		model.setConsumerType(entity.getConsumerType());
		model.setKeyType(entity.getKeyType());
		model.setConfigs(entity.getConfigs());
//		model.setStatus(entity.getStatus().name());
		return model;
	}

	public static KeyProviderEditCopyEntity getKeyProviderEntity(KeyProvider model) {
		KeyProviderEditCopyEntity entity = new KeyProviderEditCopyEntity();
		entity.setId(model.getId());
		entity.setName(model.getName());
		entity.setBuilderType(model.getBuilderType());
		entity.setConsumerType(model.getConsumerType());
		entity.setKeyType(model.getKeyType());
		entity.setConfigs(model.getConfigs());
	//	model.setStatus(EditStatus.Inprogress.name());
		return entity;
	}

	public static void updateKeyProviderEntity(KeyProvider model, KeyProviderEditCopyEntity entity) {
		entity.setId(model.getId());
		entity.setName(model.getName());
		entity.setBuilderType(model.getBuilderType());
		entity.setConsumerType(model.getConsumerType());
		entity.setKeyType(model.getKeyType());
		entity.setConfigs(model.getConfigs());
	}

}
