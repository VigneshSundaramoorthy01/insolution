package com.isg.mw.security.dao.entity;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.security.dao.model.SecurityKeyType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "KEY_PROVIDER_EDIT_COPY")
public class KeyProviderEditCopyEntity {

	/**
	 * Primary id of the configuration
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "NAME", length = 60)
	private String name;

	@Column(name = "BUILDER_TYPE", length = 150)
	private String builderType;

	@Column(name = "CONSUMER_TYPE", length = 15)
	private String consumerType;

	@Column(name = "KEY_TYPE", length = 15)
	private SecurityKeyType keyType;

	@Column(name = "CONFIGS")
	private Map<String, String> configs;
	
	/**
	 * Current status of the keyProvider configuration (Inprogress, Submitted)
	 */
	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS", length = 10)
	private EditStatus status;


}
