package com.isg.mw.security.dao.constants;

public interface KeyProviderDaoMsgKeys {
	
	/**
	 * should used when Keyprovider is already present in master
	 */
	String KEYPROVIDER_DUPLICATE_NAME_IN_MASTER = "kp.dao.duplicate.name.in.master";

	/**
	 * should used when Keyprovider is already present in edit copy
	 */
	String KEYPROVIDER_DUPLICATE_NAME_IN_EDITCOPY = "kp.dao.duplicate.name.in.editCopy";

	/**
	 * should used when Keyprovider not exists in edit copy
	 */
	String KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_EDITCOPY = "kp.dao.name.not.exists.in.editcopy";

	/**
	 * should used when Keyprovider has submitted status
	 */
	String KEYPROVIDER_STATUS_IS_SUBMITTED_STATUS = "kp.dao.has.SUBMITTED.status";

	/**
	 * should used when Keyprovider has not unlocked lockedstate
	 */
	String KEYPROVIDER_LOCKEDSTATE_IS_NOT_UNLOCKED = "kp.dao.has.not.Unlocked.state";

	/**
	 * should used when Keyprovider has not submitted status
	 */
	String KEYPROVIDER_STATUS_IS_NOT_SUBMITTED_STATUS = "kp.dao.has.not.SUBMITTED.status";

	/**
	 * should used when Keyprovider has same lockedstate as requested 
	 */
	String KEYPROVIDER_LOCKEDSTATE_IS_SAME_AS_EXPECTED = "kp.dao.lockedstate.is.same.as.expected";

	/**
	 * should used when Keyprovider has same status as requested 
	 */
	String KEYPROVIDER_STATUS_IS_SAME_AS_EXPECTED = "kp.dao.status.is.same.as.expected";

	/**
	 * should used when Keyprovider has not Inprogress status
	 */
	String KEYPROVIDER_STATUS_IS_NOT_INPROGRESS_STATUS = "kp.dao.has.not.Inprogress.status";

	/**
	 * should used when Keyprovider is not exists in master
	 */
	String KEYPROVIDER_NOT_EXISTS_WITH_NAME_IN_MASTER = "kp.dao.name.not.exists.in.master";

	/**
	 * should used when system wont allow to modify configuration
	 */
    String SYSTEM_WONT_ALLOW_TO_MODIFY  = "kp.dao.system.wont.allow.to.modify";


}
