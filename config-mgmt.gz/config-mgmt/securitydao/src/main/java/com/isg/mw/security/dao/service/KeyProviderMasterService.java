package com.isg.mw.security.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.security.dao.entity.KeyProviderMasterEntity;
import com.isg.mw.security.dao.model.KeyProvider;
import com.isg.mw.security.dao.model.SecurityKeyType;

public interface KeyProviderMasterService {

	/**
	 * Add new given KeyProvider configuration model
	 * 
	 * @param kpModel - KeyProvider configuration model
	 * @return added KeyProvider configuration model object
	 */
	KeyProvider add(KeyProvider kpModel);

	/**
	 * Update existing KeyProvider configuration with given model
	 * 
	 * @param kpModel - KeyProvider configuration model
	 * @return updated KeyProvider configuration model object
	 */
	KeyProvider update(KeyProvider kpModel);

	/**
	 * Finds matching KeyProvider Configuration model with given name and entity id
	 * 
	 * @param name         - name of the configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return matching KeyProvider configuration model object
	 */
	KeyProvider findByNameConsumerTypeAndKeyType(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Update status of KeyProvider configuration with given status
	 * 
	 * @param status       - new status
	 * @param name         - name of KeyProvider configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return KeyProvider configuration changed status
	 */
	String updateStatus(ConfigStatus status, String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Get matching KeyProvider configuration with given name and entity id
	 * 
	 * @param name         - name of the KeyProvider configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @return matching KeyProvider configuration entity
	 */
	KeyProviderMasterEntity get(String name, String consumerType, SecurityKeyType keyType);

	/**
	 * Save given KeyProvider configuration edit copy entity
	 * 
	 * @param entity - entity id of the configuration
	 * @return saved KeyProvider configuration edit copy entity
	 */
	KeyProviderMasterEntity save(KeyProviderMasterEntity entity);

	/**
	 * Change locked state of KeyProvider Configuration with given locked state
	 * 
	 * @param name         - name of the KeyProvider configuration
	 * @param consumerType - consumer type of the configuration
	 * @param keyType      - key type of configuration
	 * @param ls           - locked state of the configuration
	 * @return KeyProvider configuration lockedState
	 */
	LockedState lock(String name, String consumerType, SecurityKeyType keyType, LockedState ls);

	/**
	 * Get all KeyProvider configurations in master
	 * 
	 * @return - list of all active KeyProvider configurations
	 */
	List<KeyProvider> getAllActive(String consumerType);

	
}
