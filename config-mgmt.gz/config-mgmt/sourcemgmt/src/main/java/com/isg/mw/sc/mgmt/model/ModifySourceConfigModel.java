package com.isg.mw.sc.mgmt.model;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.SrcActionExtn;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.sc.SourceAdditionalData;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Model use in save API which contain source configuration fields
 * 
 * @author rahul3983
 *
 */
@Getter
@Setter
@ApiModel(description = "${swgr.scc.model.update}")
public class ModifySourceConfigModel {
	
	/**
	 * Unique id of the Update Source config
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.entityId.value}", required = true)
	private String entityId;

	/**
	 * Name of the mac config
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.name.value}", required = true)
	private String name;

	/**
	 * Name of the switch configuration
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.defaultTarget.value}")
	private String defaultTarget;

	/**
	 * List of preferred switches
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.targetPreferences.value}")
	private String[] targetPreferences;

	/**
	 * Connection type
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.type.value}")
	private ConnectionType connectionType;

	/**
	 * Socket port number
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.portOrUri.value}")
	private String portOrUri;

	
	/**
	 * flag turns on Merchant Validation from Merchant Data in cache is set to on
	 * otherwise Merchant validation is disabled Init cache would request merchant
	 * data from RCM only if the flag is turn on
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.merchantValidation.value}")
	private boolean merchantValidation;

	/**
	 * flags enble card bin validation and Acquirer BIN validation if set to ON.
	 * Init cache would request BIN data from RCM only if either or both flags are
	 * set to "ON"
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.issuerBinValidation.value}")
	private boolean issuerBinValidation;
	
	/**
	 * flags enble card bin validation and Acquirer BIN validation if set to ON.
	 * Init cache would request BIN data from RCM only if either or both flags are
	 * set to "ON"
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.acquirerBinValidation.value}")
	private boolean acquirerBinValidation;
	
	/**
	 * flag enables/disables decryption of data elements using source keys and
	 * re-encryption of data elements using target keys
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.dataSecurityModule.value}")
	private boolean dataSecurityModule;
	/**
	 * flag enables/disables message tranformation.Require MAC-SwC Mapping table to
	 * be loaded in cache only if it is ON.If it is set to OFF,the source and target
	 * message specification must be same.This flag would also be set to OFF in MW
	 * process if it is being determined that both source and target message are
	 * same.
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.msgTransfermation.value}")
	private boolean msgTransformation;
	
	/**
	 * maps url which is used while smart controller initialization
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.txnLogging.value}")
	private SrcActionExtn txnLogging;
	
	/**
	 * source scheme type
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.sourceType.value}")
	private TargetType sourceType;
	
	/**
	 * Request time out
	 */
	@ApiModelProperty(value = "${swgr.scc.model.update.requestTimeout.value}")
	private int requestTimeout;
	
	@ApiModelProperty(value = "${swgr.scc.model.update.preAuthPerLimit.value}")
	private String preAuthPerLimit;

	@ApiModelProperty(value = "${swgr.scc.model.update.preAuthTimePeriod.value}")
	private String preAuthTimePeriod;
	
	/**
	 * sftpParams
	 */
	@ApiModelProperty(value = "${swgr.scc.model.add.sftpParams.value}")
	private String sftpParams;

	@ApiModelProperty(value = "${swgr.scc.model.update.srcProcessor.value}")
	private SourceProcessor srcProcessor;
	
	@ApiModelProperty(required = true, value = "${swgr.scc.model.update.additionalData.value}")
	private SourceAdditionalData additionalData;

}
