package com.isg.mw.sc.mgmt.service;

import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;

/**
 * Handles the source configuration rest services
 * 
 * @author prasad_t026
 *
 */
public interface SourceConfigMgmtService {

	/**
	 * Retrieve source Configuration from DB base on name
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> get(String name);

	/**
	 * Retrieve all source Configuration from DB base on name
	 * 
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> getAll(String entityId);

	/**
	 * Add source Configuration in DB
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> add(AddSourceConfigModel configModel);

	/**
	 * modify source Configuration in DB
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> modify(ModifySourceConfigModel configModel);

	/**
	 * change the submit status of source Configuration which exist with Inprogess
	 * status in DB base on name
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> submit(String name);

	/**
	 * change the lock status of source Configuration which exist in DB base on name
	 * and lock state
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> lock(String name, LockedState lockedState);

	/**
	 * verify submit status of source Configuration which exist in DB base on name
	 * and move source configuration into master table with Active Status and Unlock
	 * State
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> verify(String name, boolean approved,String remarks);

	/**
	 * change the status of source Configuration which exist in DB base on name and
	 * status
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> updateStatus(String name, String status);
	
	ResponseEntity<?> getConfigByStatus(String status);

}
