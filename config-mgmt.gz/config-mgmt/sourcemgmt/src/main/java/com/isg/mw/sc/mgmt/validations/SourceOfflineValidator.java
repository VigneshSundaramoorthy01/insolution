/**
 * 
 */
package com.isg.mw.sc.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.sc.SourceConfigModel;

/**
 * Interface for operations on a validation for a Source offline validation
 * 
 * @author prasad_t026
 *
 */
public interface SourceOfflineValidator {
	/**
	 * offline validation for add API
	 * 
	 * @param model - model object
	 */
	void add(SourceConfigModel model);

	/**
	 * offline validation for modify API
	 * 
	 * @param model
	 */
	void modify(SourceConfigModel model);

	/**
	 * offline validation for submit API
	 * 
	 * @param editCopy - model object
	 */
	void submit(SourceConfigModel editCopy);

	/**
	 * offline validation for verify API base on name
	 * 
	 * @param name     - name of configuration
	 * @param approved - true or false
	 */
	void verify(String name, boolean approved,String remarks);

	/**
	 * offline validation for lock API base on name and lock state
	 * 
	 * @param name        - name of configuration
	 * @param lockedState - lock state of configuration
	 */
	void lock(String name, LockedState lockedState);

	/**
	 * offline validation for status of update API base on name and status
	 * 
	 * @param name-  name of configuration
	 * @param status
	 */
	void update(String name, String status);

	/**
	 * offline validation for get API
	 * 
	 * @param name -name of configuration
	 */
	void get(String name);

	/**
	 * offline validation for getAllActive API
	 */
	void getAllActive();

	/**
	 * offline validation for all API
	 * 
	 * @param entityId         - entity id of configuration
	 * @param status           - status of configuration
	 * @param lockedState-lock State of configuration
	 */
	void all(String entityId, String status, LockedState lockedState);
	
	void configByStatusValidation(String status);

}
