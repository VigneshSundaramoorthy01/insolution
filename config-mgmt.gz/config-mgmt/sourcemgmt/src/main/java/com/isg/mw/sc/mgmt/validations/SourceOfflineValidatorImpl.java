package com.isg.mw.sc.mgmt.validations;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sc.SourceAdditionalData;
import com.isg.mw.core.model.sc.SourceApiUrls;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sc.Urls;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.sc.mgmt.constants.SourceMgmtMsgKeys;

/**
 * Validates data (data which is coming from out side the system (received data
 * from Rest API)) without hitting database
 * 
 * @author rahul3983
 *
 */
@Component
public class SourceOfflineValidatorImpl implements SourceOfflineValidator {

	@Override
	public void add(SourceConfigModel model) {

		UserDataValidations.entityIdValidations(model.getEntityId(), true);
		UserDataValidations.nameValidations(model.getName(), true);
		optionalDataCheck(model);
		additionalDataCheck(model.getAdditionalData());
	}

	private void additionalDataCheck(SourceAdditionalData additionalData) {
		SourceApiUrls apiUrls = additionalData.getApiUrls();
		if (apiUrls != null && !(apiUrls.getUrls().isEmpty())) {
			List<Urls> urls = apiUrls.getUrls();
			for (Urls url : urls) {
				UserDataValidations.stringDataValidation(url.getUrl(), FieldsInfo.URLS_EX, FieldsInfo.URLS_FN, false,
						FieldsInfo.URLS_FL);
				UserDataValidations.stringDataValidation(url.getObject(), FieldsInfo.OBJECT_EX, FieldsInfo.OBJECT_FN,
						false, FieldsInfo.OBJECT_FL);
			}
		}

	}

	@Override
	public void modify(SourceConfigModel model) {

		UserDataValidations.entityIdValidations(model.getEntityId(), true);
		UserDataValidations.nameValidations(model.getName(), true);
		additionalDataCheck(model.getAdditionalData());
		optionalDataCheck(model);

	}

	@Override
	public void submit(SourceConfigModel model) {

		if (model.getSourceType() == null) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.SCHEME_TYPE_FN);
		}
		if (model.getDefaultTarget() == null) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.DEFAULT_TARGET_FN);
		}
		if (model.getConnectionType() == null) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY,
					FieldsInfo.SOURCE_CONECTION_TYPE_FN);
		}
		if (model.getTxnLogging() == null) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.TXN_LOGGING_FN);
		}

	}

	@Override
	public void verify(String name, boolean approved, String remarks) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (!approved && StringUtils.isBlank(remarks)) {
			throw new ValidationException(SourceMgmtMsgKeys.REMARK_SOURCE_IS_MANDATORY, FieldsInfo.REMARKS_FN);
		}

	}

	@Override
	public void get(String name) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}

	}

	@Override
	public void lock(String name, LockedState lockedState) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		UserDataValidations.lockedStateValidations(lockedState, true);

	}

	@Override
	public void update(String name, String status) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(SourceMgmtMsgKeys.SOURCE_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.UPDATE_STATUS_VALUES,
				FieldsInfo.UPDATE_STATUS_FN, true);

	}

	@Override
	public void getAllActive() {
	}

	@Override
	public void all(String entityId, String status, LockedState lockedState) {

		UserDataValidations.entityIdValidations(entityId, true);

	}

	/**
	 * Optional Data Check based on model object
	 * 
	 * @param model- SourceConfigModel object
	 */
	private void optionalDataCheck(SourceConfigModel model) {

		if (model.getTargetPreferences() != null) {
			for (String tp : model.getTargetPreferences()) {
				if (tp == null) {
					throw new ValidationException(SourceMgmtMsgKeys.LIST_SHOULDNOT_HAVE_NULL,
							FieldsInfo.TARGET_PREFERENCES_FN);
				}
			}
			if (UserDataValidations.duplicateCheck(model.getTargetPreferences())) {
				throw new ValidationException(SourceMgmtMsgKeys.LIST_SHOULDNOT_HAVE_DUPLICATE,
						FieldsInfo.TARGET_PREFERENCES_FN);
			}
		}

		if (model.getConnectionType() != null) {
			if (model.getConnectionType() == ConnectionType.WEB) {
				UserDataValidations.uriValidations(model.getPortOrUri(), true);
			} else if (model.getConnectionType() == ConnectionType.ISO) {
				UserDataValidations.portValidations(model.getPortOrUri(), true);
			}
		}

	}

	@Override
	public void configByStatusValidation(String status) {
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.CONFIG_BY_STATUS_VALUES,
				FieldsInfo.CONFIG_BY_STATUS_FN, true);
	}

}
