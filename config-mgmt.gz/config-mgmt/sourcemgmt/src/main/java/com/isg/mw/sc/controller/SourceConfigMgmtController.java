package com.isg.mw.sc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sc.mgmt.constants.SourceConfigUri;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;
import com.isg.mw.sc.mgmt.service.SourceConfigMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Source configuration Rest APIS
 * 
 * @author prasad_t026
 *
 */
@Tag (name = "Source configuration", description = "Source configuration APIs")
@RestController
@RequestMapping(value = SourceConfigUri.PARENT)
public class SourceConfigMgmtController {

	@Autowired
	private SourceConfigMgmtService sourceConfigMgmtService;

	/**
	 * Source configuration Rest get API
	 * 
	 * @param name - name of configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get Source configuration", description = "In response will get Source configuration by given name" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.GET_BY_NAME, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> get(
			@PathVariable(value = "${swgr.scc.get.name.value}") @RequestParam(value = "name",required = true) String name) {
		return sourceConfigMgmtService.get(name);
	}

	/**
	 * Source configuration Rest getAll API
	 * 
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get All Active Source configuration", description = "In response will get all Active Source configurations" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAll(@PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
		return sourceConfigMgmtService.getAll(entityId);
	}

	/**
	 * Source configuration Rest add API
	 * 
	 * @param addModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Add Source configuration", description = "In response will get Source configuration" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = SourceConfigUri.ADD)
	public ResponseEntity<?> add(@RequestBody AddSourceConfigModel addModel) {
		return sourceConfigMgmtService.add(addModel);
	}

	/**
	 * Source configuration Rest modify API
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Modify Source configuration", description = "In response will get Source configuration after update" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = SourceConfigUri.MODIFY)
	public ResponseEntity<?> modify(@RequestBody ModifySourceConfigModel configModel) {
		return sourceConfigMgmtService.modify(configModel);
	}

	/**
	 * Source configuration Rest submit API
	 * 
	 * @param name - name of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Submit Source configuration", description = "In response will get submit message" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.SUBMIT)
	public ResponseEntity<?> submit(
			@PathVariable(value = "${swgr.scc.submit.name.value}") @RequestParam(value = "name",required = true) String name) {
		return sourceConfigMgmtService.submit(name);
	}

	/**
	 * Source configuration Rest update API
	 * 
	 * @param name   - name of the configuration
	 * @param status - status of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Change the Status Of Source configuration", description = "In response will get status message" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.UPDATE_STATUS)
	public ResponseEntity<?> updateStatus(
			@PathVariable(value = "${swgr.scc.updateStatus.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.scc.updateStatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return sourceConfigMgmtService.updateStatus(name, status);
	}

	/**
	 * Source configuration Rest lock API
	 * 
	 * @param name        - name of the configuration
	 * @param lockedState - lock state of the configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Lock Source configuration", description = "In response will get lock state of Source configuration" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.LOCK)
	public ResponseEntity<?> lock(
			@PathVariable(value = "${swgr.scc.lock.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.scc.lock.lockstate.value}") @RequestParam(value = "lockedState",required = true) LockedState lockedState) {
		return sourceConfigMgmtService.lock(name, lockedState);
	}

	/**
	 * Source configuration Rest verify API
	 * 
	 * @param name     - name of the configuration
	 * @param approved - true or false value
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Verify Source configuration", description = "In response will get approved status of Source configuration" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.VERIFY)
	public ResponseEntity<?> verify(
			@PathVariable(value = "${swgr.scc.verify.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.scc.verify.approved.value}") @RequestParam(value = "approved",required = true) boolean approved,
			@PathVariable(value = "${swgr.scc.verify.remarks.value}") @RequestParam(value = "remarks" ,required = false) String remarks) {
		return sourceConfigMgmtService.verify(name, approved,remarks);
	}

	@Operation(summary = "API To Get Source configuration", description = "In response will get Source configuration by given status" ,tags= {"Source configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SourceConfigUri.GET_CONFIG_BY_STATUS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getConfigByStatus(
			@PathVariable(value = "${swgr.scc.getConfigByStatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return sourceConfigMgmtService.getConfigByStatus(status);
	}
}