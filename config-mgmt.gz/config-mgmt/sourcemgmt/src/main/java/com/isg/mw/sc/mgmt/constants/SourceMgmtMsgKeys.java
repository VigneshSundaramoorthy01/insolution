package com.isg.mw.sc.mgmt.constants;

/**
 * Message keys of source configuration management
 * 
 * @author rahul3983
 *
 */
public interface SourceMgmtMsgKeys {
	/**
	 * get Source Configuration by name {0}
	 */
	String GETSC_API_LOG_INFO = "sc.mgmt.get.source.api.log.info";

	/**
	 * get all Source Configurations requested
	 */
	String GETALLSC_API_LOG_INFO = "sc.mgmt.getall.source.api.log.info";

	/**
	 * add requested with the Source Configuration {0}
	 */
	String ADD_API_LOG_INFO = "sc.mgmt.add.api.log.info";

	/**
	 * modify requested for the Source Configuration {0}
	 */
	String MODIFY_API_LOG_INFO = "sc.mgmt.modify.api.log.info";

	/**
	 * submit requested for the Source Configuration {0}
	 */
	String SUBMIT_API_LOG_INFO = "sc.mgmt.submit.api.log.info";

	/**
	 * lock requested for the Source Configuration {0}
	 */
	String LOCK_API_LOG_INFO = "sc.mgmt.lock.api.log.info";

	/**
	 * verify requested for the Source Configuration {0}
	 */
	String VERIFY_API_LOG_INFO = "sc.mgmt.verify.api.log.info";

	/**
	 * update status requested for the Source Configuration {0}
	 */
	String UPDATE_STATUS_API_LOG_INFO = "sc.mgmt.update.status.api.log.info";

	/**
	 * should use when name is not exist in db
	 */
	String SC_NOT_FOUND_WITH_NAME = "sc.mgmt.source.not.found";

	/**
	 * should use when and internal error occure
	 */
	String INTERNAL_ERROR = "sc.mgmt.internal.error";

	/**
	 * should use when no any entry in db
	 */
	String SC_LIST_EMPTY = "sc.mgmt.source.list.empty";
	/**
	 * Source field {0} is mandatory
	 */
	String SOURCE_FIELD_IS_MANDATORY = "sc.mgmt.field.is.mandatory";
	/**
	 * source field {0} should not contain null value in the list
	 */
	String LIST_SHOULDNOT_HAVE_NULL = "sc.mgmt.list.with.null";
	/**
	 * {0} should not contain duplicate
	 */
	String LIST_SHOULDNOT_HAVE_DUPLICATE = "sc.mgmt.list.with.duplicate";
	
	String REMARK_SOURCE_IS_MANDATORY = "sc.mgmt.remark.source.is.mandatory";
	
	String GET_CONFIG_BY_STATUS_API_LOG_INFO="sc.mgmt.getConfigByStatus.api.log.info";

}
