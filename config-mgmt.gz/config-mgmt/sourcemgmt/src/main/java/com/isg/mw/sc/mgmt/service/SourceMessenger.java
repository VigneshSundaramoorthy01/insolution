package com.isg.mw.sc.mgmt.service;

import com.isg.mw.core.model.sc.SourceConfigMessage;

/**
 * Source Messenger
 * 
 * @author rahul3983
 *
 */
public interface SourceMessenger {
	/**
	 * Send the source configuration message model using KAFKA producer
	 * 
	 * @param model - model object
	 */
	void send(SourceConfigMessage model);

}
