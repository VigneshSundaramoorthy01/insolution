package com.isg.mw.sc.mgmt.constants;

/**
 * Definitions of source configuration URIs
 * 
 * @author rahul3983
 *
 */
public interface SourceConfigUri {
	
	/**
	 * source configuration URI for controller as parent
	 */
	String PARENT = "/source";
	
	/**
	 * source configuration URI for get by name API
	 */
	String GET_BY_NAME = "/get";
	
	/**
	 * source configuration URI for get all API
	 */
	String GET_ALL = "/getallactive";
	
	/**
	 * source configuration URI for add API
	 */
	String ADD = "/add";
	
	/**
	 * source configuration URI for submit API
	 */
	String SUBMIT = "/submit";
	
	/**
	 * source configuration URI for modify API
	 */
	String MODIFY = "/update";
	
	/**
	 * source configuration URI for verify API
	 */
	String VERIFY = "/verify";
	
	/**
	 * source configuration URI for update API
	 */
	String UPDATE_STATUS = "/changestatus";
	
	/**
	 * source configuration URI for lock API
	 */
	String LOCK = "/lock";
	
	String GET_CONFIG_BY_STATUS="/getConfigByStatus";

}
