package com.isg.mw.sc.mgmt.utils;

import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;

/**
 * Utility for source management
 * 
 * @author rahul3983
 *
 */
public class SourceMgmtUtility {
	/**
	 * Constructor should not access to the outside
	 */
	private SourceMgmtUtility() {

	}

	/**
	 * convert AddSourceConfigModel to SourceConfigModel
	 * 
	 * @param addModel - model object
	 * @return -SourceConfigModel
	 */
	public static SourceConfigModel getSourceConfigModel(AddSourceConfigModel addModel) {

		SourceConfigModel model = new SourceConfigModel();
		model.setEntityId(addModel.getEntityId());
		model.setName(addModel.getName());
		model.setDefaultTarget(addModel.getDefaultTarget());
		model.setTargetPreferences(addModel.getTargetPreferences());
		model.setConnectionType(addModel.getConnectionType());
		model.setPortOrUri(addModel.getPortOrUri());
		model.setMerchantValidation(addModel.isMerchantValidation());
		model.setIssuerBinValidation(addModel.isIssuerBinValidation());
		model.setAcquirerBinValidation(addModel.isAcquirerBinValidation());
		model.setDataSecurityModule(addModel.isDataSecurityModule());
		model.setMsgTransfomation(addModel.isMsgTransformation());
		model.setTxnLogging(addModel.getTxnLogging());
		model.setSourceType(addModel.getSourceType());
		model.setRequestTimeout(addModel.getRequestTimeout());
		model.setPreAuthPerLimit(addModel.getPreAuthPerLimit());
		model.setPreAuthTimePeriod(addModel.getPreAuthTimePeriod());
		model.setSourceProcessor(addModel.getSrcProcessor());
		model.setSftp_params(SourceCommonUtil.convertStringToSourceConnectionList(addModel.getSftpParams()));
		model.setAdditionalData(addModel.getAdditionalData());
		return model;
	}

	/**
	 * convert UpdateSourceConfigModel to SourceConfigModel
	 * 
	 * @param updateModel - UpdateSourceConfigModel
	 * @return - SourceConfigModel
	 */
	public static SourceConfigModel getSourceConfigModel(ModifySourceConfigModel updateModel) {

		SourceConfigModel model = new SourceConfigModel();
		model.setEntityId(updateModel.getEntityId());
		model.setName(updateModel.getName());
		model.setDefaultTarget(updateModel.getDefaultTarget());
		model.setTargetPreferences(updateModel.getTargetPreferences());
		model.setConnectionType(updateModel.getConnectionType());
		model.setPortOrUri(updateModel.getPortOrUri());
		model.setMerchantValidation(updateModel.isMerchantValidation());
		model.setIssuerBinValidation(updateModel.isIssuerBinValidation());
		model.setAcquirerBinValidation(updateModel.isAcquirerBinValidation());
		model.setDataSecurityModule(updateModel.isDataSecurityModule());
		model.setMsgTransfomation(updateModel.isMsgTransformation());
		model.setTxnLogging(updateModel.getTxnLogging());
		model.setSourceType(updateModel.getSourceType());
		model.setRequestTimeout(updateModel.getRequestTimeout());
		model.setPreAuthPerLimit(updateModel.getPreAuthPerLimit());
		model.setPreAuthTimePeriod(updateModel.getPreAuthTimePeriod());
		model.setSourceProcessor(updateModel.getSrcProcessor());
		model.setSftp_params(SourceCommonUtil.convertStringToSourceConnectionList(updateModel.getSftpParams()));
		model.setAdditionalData(updateModel.getAdditionalData());
		return model;
	}

}
