package com.isg.mw.sc.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.rbac.model.ResponseObj;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sc.SourceConfigMessage;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sc.dao.service.SourceOnlineValidator;
import com.isg.mw.sc.dao.utils.SourceConfigMasterUtility;
import com.isg.mw.sc.dao.utils.SourceUtility;
import com.isg.mw.sc.mgmt.constants.SourceMgmtMsgKeys;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;
import com.isg.mw.sc.mgmt.service.SourceConfigMgmtService;
import com.isg.mw.sc.mgmt.service.SourceMessenger;
import com.isg.mw.sc.mgmt.utils.SourceMgmtUtility;
import com.isg.mw.sc.mgmt.validations.SourceOfflineValidator;

/**
 * Class Implements {@link SourceConfigMgmtService} services
 * 
 * @author prasad_t026
 *
 */
@Service("sourceConfigMgmtService")
@Transactional
public class SourceConfigMgmtServiceImpl implements SourceConfigMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private SourceConfigEditCopyService sourceConfigEditCopyService;

	@Autowired
	private SourceConfigMasterService sourceConfigMasterService;

	@Autowired
	private SourceOnlineValidator sourceOnlineValidator;

	@Autowired
	private SourceMessenger sourceMessenger;

	@Autowired
	private SourceOfflineValidator offlineSourceConfigValidator;

	@Autowired
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@Autowired
	private MessageFormatBulkUpdateService messageFormatBulkUpdateService;

	@Override
	public ResponseEntity<?> get(String name) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.GETSC_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			offlineSourceConfigValidator.get(name);
			Map<String, SourceConfigModel> map = new HashMap<String, SourceConfigModel>(2);
			SourceConfigModel master = sourceConfigMasterService.get(name);
			if (master != null) {
				map.put("master", master);
			}
			SourceConfigModel editCopy = sourceConfigEditCopyService.get(name);
			if (editCopy != null) {
				map.put("editCopy", editCopy);
			}
			if (!map.isEmpty()) {
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
				res.setData(map);
				 response = new ResponseEntity<>(res, HttpStatus.OK);
			} else {
				res.setMsg(MessageConstant.NO_CONTENT);
				res.setStatusCode(MessageConstant.FAIL_CODE);
				 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getAll(String entityId) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.GETALLSC_API_LOG_INFO));
		ResponseEntity<?> response = null;
		try {
			if (entityId != null) {
				List<SourceConfigModel> all = sourceConfigMasterService.getAllByEntity(entityId);
				if (!all.isEmpty()) {
					response = new ResponseEntity<>(all, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.SC_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}
			else {
				List<SourceConfigModel> all = sourceConfigMasterService.getAll();
				if (!all.isEmpty()) {
					response = new ResponseEntity<>(all, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.SC_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> add(AddSourceConfigModel configModel) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.ADD_API_LOG_INFO, configModel));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			SourceConfigModel model = SourceMgmtUtility.getSourceConfigModel(configModel);
			offlineSourceConfigValidator.add(model);
			sourceOnlineValidator.add(model);
			SourceConfigModel add = sourceConfigEditCopyService.add(model);
			res.setMsg(MessageConstant.SUCCESS_DESC);
			res.setStatusCode(MessageConstant.SUCCESS_CODE);
			res.setData(add);
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
		response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
	} catch (Exception e) {
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
		res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
		response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
	}
		return response;
	}

	@Override
	public ResponseEntity<?> modify(ModifySourceConfigModel configModel) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.MODIFY_API_LOG_INFO, configModel));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			SourceConfigModel model = SourceMgmtUtility.getSourceConfigModel(configModel);
			offlineSourceConfigValidator.modify(model);
			sourceOnlineValidator.modify(model);
			SourceConfigModel update = sourceConfigEditCopyService.update(model);
			res.setMsg(MessageConstant.SUCCESS_DESC);
			res.setStatusCode(MessageConstant.SUCCESS_CODE);
			res.setData(update);
			response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> submit(String name) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.SUBMIT_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		ResponseObj res=new ResponseObj();
		try {
			SourceConfigModel model = sourceConfigEditCopyService.get(name);
			if (model != null) {
				offlineSourceConfigValidator.submit(model);
			}
			sourceOnlineValidator.submit(name);
			String updateStatus = sourceConfigEditCopyService.updateStatus(EditStatus.Submitted, name,null);
			if(updateStatus=="Submitted"){
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			// response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> lock(String name, LockedState lockedState) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.LOCK_API_LOG_INFO, name));

		ResponseEntity<?> response = null;
		try {
			offlineSourceConfigValidator.lock(name, lockedState);
			sourceOnlineValidator.lock(name, lockedState);
			LockedState lock = sourceConfigMasterService.lock(name, lockedState);
			ConfigAction action = ConfigAction.UN_LOCKED;
			if (lock.equals(LockedState.Locked)) {
				action = ConfigAction.LOCKED;
			}
			sendMessage(name, action);
			response = new ResponseEntity<>(lock, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> verify(String name, boolean approved,String remarks) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.VERIFY_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			offlineSourceConfigValidator.verify(name, approved,remarks);
			sourceOnlineValidator.verify(name, approved);
			if (approved) {
				SourceConfigEditCopyEntity editCopyEntity = sourceConfigEditCopyService.getEntity(name);
				SourceConfigMasterEntity configMasterEntity = sourceConfigMasterService.getEntity(name);
				ConfigAction action = ConfigAction.MODIFY;
				if (configMasterEntity == null) {
					configMasterEntity = SourceUtility.createMaster(editCopyEntity);
					action = ConfigAction.ADD;
				}
				SourceUtility.updateMaster(configMasterEntity, editCopyEntity);
				configMasterEntity.setRemarks(StringUtils.isBlank(remarks)?null:remarks);
				configMasterEntity = sourceConfigMasterService.save(configMasterEntity);
				sourceConfigEditCopyService.delete(editCopyEntity);
				messageFormatBulkUpdateService.moveEditCopyToMaster(editCopyEntity.getId(), configMasterEntity.getId(),
						OwnerType.SOURCE);
				sendMessage(name, action);
			} else {
				sourceConfigEditCopyService.updateStatus(EditStatus.Rejected, name ,remarks);
			}
			if(approved)
			{
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res,HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> updateStatus(String name, String statusStr) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.UPDATE_STATUS_API_LOG_INFO, name));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			offlineSourceConfigValidator.update(name, statusStr);
			sourceOnlineValidator.update(name, statusStr);
			ConfigStatus status = ConfigStatus.getStatus(statusStr);
			if (status != null) {
				sourceConfigMasterService.updateStatus(name, status);
				ConfigAction action = ConfigAction.ACTIVATE;
				if (status == ConfigStatus.Inactive) {
					action = ConfigAction.INACTIVE;
				}
				sendMessage(name, action);

			} else {
				SourceConfigEditCopyEntity editCopyEntity = sourceConfigEditCopyService.getEntity(name);
				SourceConfigMasterEntity configMasterEntity = sourceConfigMasterService.getEntity(name);
				if (editCopyEntity == null) {
					editCopyEntity = new SourceConfigEditCopyEntity();
				}
				SourceUtility.updateEditCopy(configMasterEntity, editCopyEntity);
				editCopyEntity = sourceConfigEditCopyService.save(editCopyEntity);
				messageFormatBulkUpdateService.copyMasterToEditCopy(editCopyEntity.getId(), configMasterEntity.getId(),
						OwnerType.SOURCE);
			}
			if(status!=null){
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	/**
	 * Send message on KAFKA
	 * 
	 * @param name         - name of the configuration object
	 * @param configAction - action of the configuration message object
	 */
	private void sendMessage(String name, ConfigAction configAction) {
		SourceConfigMasterEntity entity = sourceConfigMasterService.getEntity(name);
		SourceConfigModel configModel = SourceConfigMasterUtility.getSourceModel(entity);
		configModel.setMessageFormats(
				messageFormatConfigMasterService.getByOwnerAndOwnerType(configModel.getId(), OwnerType.SOURCE));
		SourceConfigMessage configMessage = new SourceConfigMessage();
		configMessage.setAction(configAction);
		configMessage.setModel(configModel);
		sourceMessenger.send(configMessage);
	}
	
	
	@Override
	public ResponseEntity<?> getConfigByStatus(String status) {
		LOG.info(PropertyUtils.getMessage(SourceMgmtMsgKeys.GET_CONFIG_BY_STATUS_API_LOG_INFO, status));
		ResponseEntity<?> response = null;
		try {
			offlineSourceConfigValidator.configByStatusValidation(status);
			if (ConfigStatus.Active == ConfigStatus.getStatus(status)
					|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)
					|| LockedState.Locked == LockedState.getState(status)
					|| LockedState.Unlocked == LockedState.getState(status)) {
				List<SourceConfigModel> entities = sourceConfigMasterService.getConfigByStatus(status);
				response = new ResponseEntity<>(entities, HttpStatus.OK);
			} else if (EditStatus.Inprogress == EditStatus.getStatus(status)
					|| EditStatus.Rejected == EditStatus.getStatus(status)
					|| EditStatus.Submitted == EditStatus.getStatus(status)) {
				List<SourceConfigModel> entities = sourceConfigEditCopyService.getConfigByStatus(status);
				response = new ResponseEntity<>(entities, HttpStatus.OK);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}
