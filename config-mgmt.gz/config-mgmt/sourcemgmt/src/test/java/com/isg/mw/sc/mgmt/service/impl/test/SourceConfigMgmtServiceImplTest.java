package com.isg.mw.sc.mgmt.service.impl.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.constants.SrcActionExtn;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.utils.CoreUtils;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sc.dao.service.SourceOnlineValidator;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.sc.mgmt.constants.SourceMgmtMsgKeys;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;
import com.isg.mw.sc.mgmt.service.SourceMessenger;
import com.isg.mw.sc.mgmt.service.impl.SourceConfigMgmtServiceImpl;
import com.isg.mw.sc.mgmt.validations.SourceOfflineValidator;

@RunWith(SpringJUnit4ClassRunner.class)
public class SourceConfigMgmtServiceImplTest {

	@Mock
	private MessageFormatBulkUpdateService messageFormatBulkUpdateService;

	@Mock
	private SourceConfigEditCopyService sourceConfigEditCopyService;

	@Mock
	private SourceConfigMasterService sourceConfigMasterService;

	@Mock
	private SourceOnlineValidator sourceOnlineValidator;

	@Mock
	private SourceMessenger sourceMessenger;

	@Mock
	private SourceOfflineValidator offlineSourceConfigValidator;

	@InjectMocks
	private SourceConfigMgmtServiceImpl SourceConfigMgmtService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getPT01() {
		Mockito.when(sourceConfigMasterService.get(Mockito.any())).thenReturn(getSCModelList().get(0));
		Mockito.when(sourceConfigEditCopyService.get(Mockito.any())).thenReturn(getSCModelList().get(0));

		ResponseEntity<?> entity = SourceConfigMgmtService.get("SCM1");
		assertNotNull(entity);
	}

	@Test
	public void getNT01() {
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.SC_NOT_FOUND_WITH_NAME);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NOT_FOUND);
		ResponseEntity<?> entity = SourceConfigMgmtService.get("SCM1");
		assertEquals(response, entity);
	}

	@Test
	public void getNT02Validation() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigMasterService.get(Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = SourceConfigMgmtService.get("SCM1");
		assertEquals(response, entity);
	}

	@Test
	public void getNT03Exception() {
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(sourceConfigMasterService.get(Mockito.any())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = SourceConfigMgmtService.get("SCM1");
		assertEquals(response, entity);
	}

	@Test
	public void getAllPT01() {
		Mockito.when(sourceConfigMasterService.getAll()).thenReturn(getSCModelList());
		ResponseEntity<?> allSwc = SourceConfigMgmtService.getAll("9568");
		assertNotNull(allSwc);
	}

	@Test
	public void getAllNT01Null() {
		Mockito.when(sourceConfigMasterService.getAll()).thenReturn(new ArrayList<>());
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.SC_LIST_EMPTY);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
		ResponseEntity<?> entity = SourceConfigMgmtService.getAll("9568");
		assertEquals(response, entity);
	}

	@Test
	public void getAllNT02ValidationException() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigMasterService.getAll()).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> allName = SourceConfigMgmtService.getAll("9568");
		assertEquals(response, allName);
	}

	@Test
	public void getAllNT03Exception() {
		Mockito.when(sourceConfigMasterService.getAll()).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = SourceConfigMgmtService.getAll("9568");
		assertEquals(response, entity);
	}

	@Test
	public void testAddOk() {
		Mockito.when(sourceConfigEditCopyService.add(Mockito.any())).thenReturn(getSCModelList().get(0));
		ResponseEntity<?> add = SourceConfigMgmtService.add(getAddSCConfigModel());
		assertNotNull(add);
	}

	@Test
	public void testAddValidationException() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigEditCopyService.add(Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> add = SourceConfigMgmtService.add(getAddSCConfigModel());
		assertEquals(response, add);
	}

	@Test
	public void testAddExceptipn() {
		Mockito.when(sourceConfigEditCopyService.add(Mockito.any())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> add = SourceConfigMgmtService.add(getAddSCConfigModel());

		assertEquals(response, add);
	}

	@Test
	public void testUpdateOk() {
		Mockito.when(sourceConfigEditCopyService.update(Mockito.any())).thenReturn(getSCModelList().get(0));
		ResponseEntity<?> update = SourceConfigMgmtService.modify(getUpdateSCModel());
		assertNotNull(update);
	}

	@Test
	public void testUpdateValidationException() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigEditCopyService.update(Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> update = SourceConfigMgmtService.modify(getUpdateSCModel());
		assertEquals(response, update);
	}

	@Test
	public void testUpdateExceptipn() {
		Mockito.when(sourceConfigEditCopyService.update(Mockito.any())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> update = SourceConfigMgmtService.modify(getUpdateSCModel());
		assertEquals(response, update);
	}

	@Test
	public void testSubmitOk() {
		Mockito.when(sourceConfigEditCopyService.get(Mockito.any())).thenReturn(getSCModelList().get(0));
		Mockito.when(sourceConfigEditCopyService.updateStatus(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenReturn(EditStatus.Submitted.name());
		ResponseEntity<?> update = SourceConfigMgmtService.submit("SCM1");
		assertNotNull(update);
	}

	@Test
	public void testSubmitValidationException() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigEditCopyService.get(Mockito.any())).thenReturn(getSCModelList().get(0));
		Mockito.when(sourceConfigEditCopyService.updateStatus(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> update = SourceConfigMgmtService.submit("SCM1");
		assertEquals(response, update);
	}

	@Test
	public void testSubmitException() {
		Mockito.when(sourceConfigEditCopyService.get(Mockito.any())).thenReturn(getSCModelList().get(0));
		Mockito.when(sourceConfigEditCopyService.updateStatus(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> update = SourceConfigMgmtService.submit("SCM1");
		assertEquals(response, update);
	}

	@Test
	public void testlockOk() {

		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));
		Mockito.when(sourceConfigMasterService.lock(Mockito.any(), Mockito.any())).thenReturn(LockedState.Locked);
		ResponseEntity<?> update = SourceConfigMgmtService.lock("SCM1", LockedState.Locked);
		assertNotNull(update);
	}

	@Test
	public void testLockValidationException() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigMasterService.lock(Mockito.any(), Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> update = SourceConfigMgmtService.lock("SCM1", LockedState.Locked);
		assertEquals(response, update);
	}

	@Test
	public void testLockException() {
		Mockito.when(sourceConfigMasterService.lock(Mockito.any(), Mockito.any())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> update = SourceConfigMgmtService.lock("SCM1", LockedState.Locked);
		assertEquals(response, update);
	}

	@Test // error
	public void testVerifyPT01Ok() {
		Mockito.when(sourceConfigEditCopyService.getEntity(Mockito.any()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM2").get(0));
		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any())).thenReturn(getSCMasterEntity(ConfigStatus.Active, "TCM1").get(0));
		Mockito.when(sourceConfigMasterService.save(Mockito.any())).thenReturn(getSCMasterEntity(ConfigStatus.Active, "TCM1").get(0));

		ResponseEntity<?> update = SourceConfigMgmtService.verify("SCM2", true,null);
		assertNotNull(update);
	}

	@Test
	public void testVerifyPT02Ok() {
		ResponseEntity<?> update = SourceConfigMgmtService.verify("SCM1", false,null);
		assertNotNull(update);
	}

	@Test
	public void testVerifyValidationException() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigEditCopyService.updateStatus(Mockito.any(), Mockito.any(),Mockito.any()))
				.thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> update = SourceConfigMgmtService.verify("SCM1", false,null);
		assertEquals(response, update);
	}

	@Test
	public void testVerifyException() {
		Mockito.when(sourceConfigEditCopyService.getEntity(Mockito.any()))
				.thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "SCM2").get(0));
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> update = SourceConfigMgmtService.verify("SCM1", true,null);
		assertEquals(response, update);
	}

	@Test
	public void testUpdateStatusOk() {
		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));

		Mockito.when(sourceConfigMasterService.updateStatus(Mockito.any(), Mockito.any()))
				.thenReturn(ConfigStatus.Active);
		ResponseEntity<?> update = SourceConfigMgmtService.updateStatus("SCM1", ConfigStatus.Active.name());
		assertNotNull(update);
	}

	@Test
	public void testUpdateStatusOk2() {
		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));

		Mockito.when(sourceConfigMasterService.updateStatus(Mockito.any(), Mockito.any()))
				.thenReturn(ConfigStatus.Active);
		ResponseEntity<?> update = SourceConfigMgmtService.updateStatus("SCM1", ConfigStatus.Inactive.name());
		assertNotNull(update);
	}

	@Test // error
	public void testUpdateStatusOk3() {

		Mockito.when(sourceConfigMasterService.getEntity(Mockito.any()))
				.thenReturn(getSCMasterEntity(ConfigStatus.Active, "SCM1").get(0));
		Mockito.when(sourceConfigEditCopyService.save(Mockito.any())).thenReturn(getSCEditCopyEntity(EditStatus.Inprogress, "TCM1").get(0));

		ResponseEntity<?> update = SourceConfigMgmtService.updateStatus("SCM1", EditStatus.Inprogress.name());
		assertNotNull(update);
	}

	@Test
	public void testUpdateStatusValidation() {
		String errMsg = "Unknown message";
		Mockito.when(sourceConfigMasterService.updateStatus(Mockito.any(), Mockito.any()))
				.thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> update = SourceConfigMgmtService.updateStatus("SCM1", ConfigStatus.Active.name());
		assertEquals(response, update);
	}

	@Test
	public void testUpdateStatusException() {
		Mockito.when(sourceConfigMasterService.updateStatus(Mockito.any(), Mockito.any()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(SourceMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> update = SourceConfigMgmtService.updateStatus("SCM1", ConfigStatus.Active.name());
		assertEquals(response, update);
	}

	private AddSourceConfigModel getAddSCConfigModel() {
		AddSourceConfigModel model = new AddSourceConfigModel();
		model.setName("SCM1");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(ConnectionType.ISO);
		model.setPortOrUri("9093");
		model.setEntityId("123L");
		model.setMerchantValidation(true);
		model.setIssuerBinValidation(true);
		model.setAcquirerBinValidation(true);
		model.setDataSecurityModule(true);
		model.setMsgTransformation(true);
		model.setTxnLogging(SrcActionExtn.ON);

		return model;
	}

	private ModifySourceConfigModel getUpdateSCModel() {
		ModifySourceConfigModel model = new ModifySourceConfigModel();
		model.setName("SCM1");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(ConnectionType.ISO);
		model.setPortOrUri("9093");
		model.setEntityId("123L");
		model.setMerchantValidation(true);
		model.setIssuerBinValidation(true);
		model.setAcquirerBinValidation(true);
		model.setDataSecurityModule(true);
		model.setMsgTransformation(true);
		model.setTxnLogging(SrcActionExtn.ON);
		return model;

	}

	private List<SourceConfigModel> getSCModelList() {
		List<SourceConfigModel> list = new ArrayList<SourceConfigModel>();
		SourceConfigModel model = new SourceConfigModel();
		model.setName("SCM1");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(ConnectionType.ISO);
		model.setPortOrUri("9093");
		list.add(model);
		return list;
	}

	public static String[] demoRecord() {

		String[] merPrefArr = { "asdf", "asdf" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}

	private List<SourceConfigMasterEntity> getSCMasterEntity(ConfigStatus status, String name) {
		List<SourceConfigMasterEntity> list = new ArrayList<SourceConfigMasterEntity>();
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setName(name);
		entity.setDefaultTarget("TCM1");
		entity.setTargetPreferences(CoreUtils.arrayToString(demoRecord()));
		entity.setConnectionType(ConnectionType.ISO);
		entity.setPortOrUri("9093");
		entity.setLockedState(LockedState.Locked);
		entity.setId(123L);
		entity.setStatus(status);
		list.add(entity);
		return list;
	}

	private List<SourceConfigEditCopyEntity> getSCEditCopyEntity(EditStatus status, String name) {
		List<SourceConfigEditCopyEntity> list = new ArrayList<SourceConfigEditCopyEntity>();
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setName(name);
		entity.setDefaultTarget("TCM1");
		entity.setTargetPreferences(CoreUtils.arrayToString(demoRecord()));
		entity.setConnectionType(ConnectionType.ISO);
		entity.setPortOrUri("9093");
		entity.setId(123L);
		entity.setStatus(status);
		list.add(entity);
		return list;
	}


}
