package com.isg.mw.sc.mgmt.validations.test;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.constants.SrcActionExtn;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sc.SourceAdditionalData;
import com.isg.mw.core.model.sc.SourceApiUrls;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sc.Urls;
import com.isg.mw.core.utils.CoreUtils;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.sc.mgmt.validations.SourceOfflineValidatorImpl;

public class SourceOfflineValidatorImplTest {

	@InjectMocks
	SourceOfflineValidatorImpl sourceOfflineValidator;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void add() {
		String errorMsg = null;
		try {
			sourceOfflineValidator.add(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();

		}
		assertNull(errorMsg);
	}


	@Test
	public void addNT01() {
		MerchantPreference[] merchantPreferences = new MerchantPreference[] { MerchantPreference.ONUS };
		String[] targetPreferences = new String[] { "TCM", null };
		ConnectionType type = ConnectionType.ISO;
		String headersInfo = "head";
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.add(getSCModel(merchantPreferences, targetPreferences, type, headersInfo));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.list.with.null");
		assertEquals(errorArg[0], FieldsInfo.TARGET_PREFERENCES_FN);
	}

	@Test
	public void addNT02() {
		MerchantPreference[] merchantPreferences = new MerchantPreference[] { MerchantPreference.ONUS };
		String[] targetPreferences = new String[] { "TCM", "TCM" };
		ConnectionType type = ConnectionType.ISO;
		String headersInfo = "head";
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.add(getSCModel(merchantPreferences, targetPreferences, type, headersInfo));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.list.with.duplicate");
		assertEquals(errorArg[0], FieldsInfo.TARGET_PREFERENCES_FN);
	}

	@Test
	public void addPT03() {
		MerchantPreference[] merchantPreferences = new MerchantPreference[] { MerchantPreference.ONUS };
		String[] targetPreferences = new String[] { "TCM1"};
		ConnectionType type = ConnectionType.WEB;
		String headersInfo = "head";
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.add(getSCModel(merchantPreferences, targetPreferences, type, headersInfo));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
		}

	
	@Test
	public void addPT04() {
		MerchantPreference[] merchantPreferences = new MerchantPreference[] { MerchantPreference.ONUS };
		String[] targetPreferences = new String[] { "TCM1"};
		ConnectionType type = ConnectionType.ISO;
		String headersInfo = "head";
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.add(getSCModel(merchantPreferences, targetPreferences, type, headersInfo));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
		}


	private SourceConfigModel getSCModel(MerchantPreference[] merchantPreferences, String[] targetPreferences,
			ConnectionType type, String headersInfo) {
		SourceConfigModel model = new SourceConfigModel();
		model.setEntityId("123l");
		model.setName("SCM1");
		model.setCreatedBy("john");
		model.setTargetPreferences(targetPreferences);
		model.setPortOrUri("8080");
		model.setConnectionType(type);
		model.setAdditionalData(getSourceAdditionalData());
		return model;
	}

	@Test
	public void modify() {
		String errorMsg = null;
		try {
			sourceOfflineValidator.modify(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();

		}
		assertNull(errorMsg);
	}

	@Test
	public void submitPT01() {
		String errorMsg = null;
		try {
			sourceOfflineValidator.submit(getSCModelList().get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();

		}
		assertNull(errorMsg);
	}

	@Test
	public void submitNT01() {

		String target = null;
		ConnectionType type = ConnectionType.ISO;
		SrcActionExtn actionExtn = SrcActionExtn.ON;
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.submit(getSCModelList(target, type, actionExtn).get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.DEFAULT_TARGET_FN);
	}

	@Test
	public void submitNT02() {

		String target = "TCM1";
		ConnectionType type = null;
		SrcActionExtn actionExtn = SrcActionExtn.ON;
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.submit(getSCModelList(target, type, actionExtn).get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.SOURCE_CONECTION_TYPE_FN);
	}

	@Test
	public void submitNT03() {

		String target = "TCM1";
		ConnectionType type = ConnectionType.ISO;
		SrcActionExtn actionExtn = null;
		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.submit(getSCModelList(target, type, actionExtn).get(0));
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.TXN_LOGGING_FN);
	}

	@Test
	public void verifyNT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.verify(null, true,null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void verifyPT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.verify("SCM1", true,null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void getPT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.get("SCM1");
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void getNT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.get(null);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void lockPT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.lock("SCM1", LockedState.Unlocked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void lockNT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.lock(null, LockedState.Unlocked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void updatePT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.update("SCM1", ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void updateNT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.update(null, ConfigStatus.Active.name());
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertEquals(errorMsg, "sc.mgmt.field.is.mandatory");
		assertEquals(errorArg[0], FieldsInfo.NAME_FN);
	}

	@Test
	public void getAllPT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.getAllActive();
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	@Test
	public void allPT01() {

		String errorMsg = null;
		Object[] errorArg = null;
		try {
			sourceOfflineValidator.all("123L", ConfigStatus.Active.name(), LockedState.Locked);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArg = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArg);
	}

	private List<SourceConfigModel> getSCModelList() {
		List<SourceConfigModel> list = new ArrayList<SourceConfigModel>();
		SourceConfigModel model = new SourceConfigModel();
		model.setEntityId("123");
		model.setName("SCM1");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(ConnectionType.ISO);
		model.setPortOrUri("9093");
		model.setCreatedBy("john");
		model.setUpdatedBy("john");
		model.setTxnLogging(SrcActionExtn.ON);
		model.setSourceType(TargetType.Pos);
		model.setAdditionalData(getSourceAdditionalData());
		list.add(model);
		return list;
	}

	private SourceAdditionalData getSourceAdditionalData() {
		SourceAdditionalData data = new SourceAdditionalData();
		SourceApiUrls apiUrls = new SourceApiUrls();
		Urls url = new Urls();
		url.setUrl("receiveTxn");
		url.setObject("com.isg.mw.core.model.PgTxnModel");
		apiUrls.setUrls(Arrays.asList(url));
		data.setApiUrls(apiUrls);
		return data;
	}

	private List<SourceConfigModel> getSCModelList(String targetPreference, ConnectionType type,
			SrcActionExtn actionExtn) {
		List<SourceConfigModel> list = new ArrayList<SourceConfigModel>();
		SourceConfigModel model = new SourceConfigModel();
		model.setEntityId("123");
		model.setName("SCM1");
		model.setDefaultTarget(targetPreference);
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(type);
		model.setPortOrUri("9093");
		model.setCreatedBy("john");
		model.setUpdatedBy("john");
		model.setTxnLogging(actionExtn);
		model.setSourceType(TargetType.Pos);
		list.add(model);
		return list;
	}

	public static String[] demoRecord() {

		String[] merPrefArr = { "asdf", "asdf" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}

}
