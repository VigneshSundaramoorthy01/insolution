package com.isg.mw.sc.controller.test;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.utils.CoreUtils;
import com.isg.mw.sc.controller.SourceConfigMgmtController;
import com.isg.mw.sc.mgmt.constants.SourceConfigUri;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;
import com.isg.mw.sc.mgmt.service.SourceConfigMgmtService;

@RunWith(SpringJUnit4ClassRunner.class)
public class SourceConfigMgmtControllerTest {

	private MockMvc mockMvc;

	@InjectMocks
	private SourceConfigMgmtController sourceConfigMgmtController;

	@Mock
	private SourceConfigMgmtService sourceConfigMgmtService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(sourceConfigMgmtController).build();
	}

	@Test
	public void getAllPT01() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(SourceConfigUri.PARENT + SourceConfigUri.GET_ALL))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void getPT01() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get(SourceConfigUri.PARENT + SourceConfigUri.GET_BY_NAME).param("name",
				Mockito.anyString())).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void getAddTest() throws Exception {
		AddSourceConfigModel configModel = getAddSCConfigModel();
		String requestBody = new ObjectMapper().valueToTree(configModel).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(SourceConfigUri.PARENT + SourceConfigUri.ADD).content(requestBody)
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());

	}

	@Test
	public void getModifyTest() throws Exception {
		ModifySourceConfigModel configModel = getUpdateSCModel();
		String requestBody = new ObjectMapper().valueToTree(configModel).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(SourceConfigUri.PARENT + SourceConfigUri.MODIFY)
				.content(requestBody).contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());

	}

	@Test
	public void submitPT01() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get(SourceConfigUri.PARENT + SourceConfigUri.SUBMIT).param("name",
				Mockito.anyString())).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void updateStatusPT01() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get(SourceConfigUri.PARENT + SourceConfigUri.UPDATE_STATUS)
				.param("name", Mockito.anyString()).param("status", Mockito.anyString()))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	//@Test
	public void lockPT01() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get(SourceConfigUri.PARENT + SourceConfigUri.LOCK)
				.param("name", Mockito.anyString()).param("lockedState", Mockito.anyString())).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void updateVerifyPT01() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("name", "rahul");
		requestParams.add("approved", "true");

		mockMvc.perform(
				MockMvcRequestBuilders.get(SourceConfigUri.PARENT + SourceConfigUri.VERIFY).params(requestParams))
				.andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}

	private AddSourceConfigModel getAddSCConfigModel() {
		AddSourceConfigModel model = new AddSourceConfigModel();
		model.setName("SCM1");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(ConnectionType.ISO);
		model.setPortOrUri("9093");
		return model;
	}

	private ModifySourceConfigModel getUpdateSCModel() {
		ModifySourceConfigModel model = new ModifySourceConfigModel();
		model.setName("SCM1");
		model.setDefaultTarget("TCM1");
		model.setTargetPreferences(CoreUtils.stringToArray(demoRecord().toString()));
		model.setConnectionType(ConnectionType.ISO);
		model.setPortOrUri("9093");
		return model;

	}

	public static String[] demoRecord() {

		String[] merPrefArr = { "asdf", "asdf" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}


}
