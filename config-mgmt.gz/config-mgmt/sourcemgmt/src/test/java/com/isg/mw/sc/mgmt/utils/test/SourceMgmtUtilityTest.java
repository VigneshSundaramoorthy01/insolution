package com.isg.mw.sc.mgmt.utils.test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.sc.mgmt.model.AddSourceConfigModel;
import com.isg.mw.sc.mgmt.model.ModifySourceConfigModel;
import com.isg.mw.sc.mgmt.utils.SourceMgmtUtility;

public class SourceMgmtUtilityTest {

	@Test
	public void getSourceConfigTest() {
		AddSourceConfigModel macModel = getAddSourceConfigModel();
		SourceConfigModel configModel = SourceMgmtUtility.getSourceConfigModel(macModel);
		assertEquals(configModel.getName(), macModel.getName());
		assertEquals(configModel.getDefaultTarget(), macModel.getDefaultTarget());
		assertArrayEquals(configModel.getTargetPreferences(), macModel.getTargetPreferences());
		assertEquals(configModel.getConnectionType(), macModel.getConnectionType());
		assertEquals(configModel.getRequestTimeout(), macModel.getRequestTimeout());
	}

	@Test
	public void getSourceConfigTest2() {
		ModifySourceConfigModel macModel = getUpdateSourceConfigModel();
		SourceConfigModel configModel = SourceMgmtUtility.getSourceConfigModel(macModel);
		assertEquals(configModel.getName(), macModel.getName());
		assertEquals(configModel.getDefaultTarget(), macModel.getDefaultTarget());
		assertArrayEquals(configModel.getTargetPreferences(), macModel.getTargetPreferences());
		assertEquals(configModel.getConnectionType(), macModel.getConnectionType());
		assertEquals(configModel.getRequestTimeout(), macModel.getRequestTimeout());
	}

	private MerchantPreference[] getMerchant() {

		MerchantPreference[] mer = new MerchantPreference[] { MerchantPreference.MERCHANT_CHOICE,
				MerchantPreference.PRICING, MerchantPreference.ONUS };
		return mer;
	}

	private ModifySourceConfigModel getUpdateSourceConfigModel() {
		ModifySourceConfigModel configModel = new ModifySourceConfigModel();
		configModel.setName("slave");
		configModel.setDefaultTarget("switch");
		configModel.setTargetPreferences(demoRecord1());
		configModel.setConnectionType(ConnectionType.ISO);
		configModel.setRequestTimeout(89000);
		return configModel;
	}

	private AddSourceConfigModel getAddSourceConfigModel() {
		AddSourceConfigModel configModel = new AddSourceConfigModel();
		configModel.setName("slave");
		configModel.setDefaultTarget("switch");
		configModel.setTargetPreferences(demoRecord1());
		configModel.setConnectionType(ConnectionType.ISO);
		configModel.setRequestTimeout(89000);
		return configModel;
	}

	private String[] demoRecord1() {
		String[] str = { "demo", "demo1" };
		return str;
	}

	public static MerchantPreference[] demoRecord() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.MERCHANT_CHOICE,
				MerchantPreference.PRICING, MerchantPreference.ONUS };
		return merPrefArr;
	}

}
