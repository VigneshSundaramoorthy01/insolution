package com.isg.mw.sc.mgmt.service.impl.test;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.sc.SourceConfigMessage;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sc.mgmt.service.impl.SourceMessengerImpl;

public class SourceMessangerTest {

	@InjectMocks
	SourceMessengerImpl sourceMessenger;

	@Mock
	private IsgKafkaConfigs isgKafkaConfigs;

	@Mock
	private KafkaTopics kafkaTopics;

	@Mock
	KafkaProducer producer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void tsetDestroy() throws Exception {
		sourceMessenger.destroy();
	}

	@Test
	public void testsendPT01() {
		sourceMessenger.send(getSourceConfigMsgModel());
	}

	private SourceConfigMessage getSourceConfigMsgModel() {
		SourceConfigMessage msg = new SourceConfigMessage();
		SourceConfigModel model = new SourceConfigModel();
		model.setName("SOURCE");
		msg.setModel(model);
		msg.setAction(ConfigAction.ADD);
		return msg;
	}

}
