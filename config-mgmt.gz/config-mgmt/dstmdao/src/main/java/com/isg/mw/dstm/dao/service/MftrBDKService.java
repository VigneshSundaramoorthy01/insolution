package com.isg.mw.dstm.dao.service;

import java.util.List;

import com.isg.mw.core.model.dstm.MftrBDKModel;

public interface MftrBDKService {


    MftrBDKModel findByMftrNameAndEntityId(String mftrname, String entityId);
	
	List<MftrBDKModel> getAll();

}
