package com.isg.mw.dstm.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;

/**
 * Hsm Configuration EditCopy Repository
 * 
 * @author sudharshan
 */
public interface HsmConfigEditCopyRepository extends CrudRepository<HsmConfigEditCopyEntity, Long> {

	/**
	 * finds the matching Hsm configuration Edit Copy with the given name
	 * 
	 * @param name - name of the Hsm configuration Edit Copy
	 * @return - List of Hsm configuration Edit Copy objects
	 */
	@Query("SELECT hsmece FROM HsmConfigEditCopyEntity hsmece WHERE hsmece.name = :name")
	List<HsmConfigEditCopyEntity> findByName(@Param("name") String name);

	/**
	 * 
	 * @param name - status of the Hsm configuration Edit Copy
	 * @return - true or false value if Hsm configuration Edit Copy exists
	 */
	@Query("SELECT CASE WHEN COUNT(hsmece) > 0 THEN true ELSE false END FROM HsmConfigEditCopyEntity hsmece WHERE hsmece.name = :name")
	boolean isHsmConfigExists(@Param("name") String name);

	/**
	 * 
	 * @param status -status of the Hsm configuration Edit Copy
	 * @param name   - name of the Hsm configuration Edit Copy status
	 * @return - true or false value if Hsm configuration Edit Copy status matching
	 */
	@Query("SELECT CASE WHEN COUNT(hsmece) > 0 THEN true ELSE false END FROM HsmConfigEditCopyEntity hsmece WHERE hsmece.status = :status and hsmece.name = :name")
	boolean isHsmConfiStatusMatching(@Param("status") EditStatus status, @Param("name") String name);

	/**
	 * 
	 * @return - List of Hsm configuration Edit Copy objects
	 */
	@Query("SELECT hsmece FROM HsmConfigEditCopyEntity hsmece")
	List<HsmConfigEditCopyEntity> getAll();

	/**
	 * 
	 * @param name
	 */
	@Query("DELETE from HsmConfigEditCopyEntity hsmece WHERE hsmece.name = :name")
	void delete(@Param("name") String name);

	@Query("SELECT hsmece FROM HsmConfigEditCopyEntity hsmece WHERE hsmece.status = :status")
	List<HsmConfigEditCopyEntity> getAll(@Param("status") EditStatus status);

}
