package com.isg.mw.dstm.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;

/**
 * Hsm Configuration Edit Copy Service
 * 
 * @author sudharshan
 */
public interface HsmConfigEditCopyService {

	HsmConfigModel getModel(String name);

	HsmConfigModel add(HsmConfigModel model);

	HsmConfigModel update(HsmConfigModel model);

	String updateStatus(EditStatus status, String name, String reason);

	List<HsmConfigModel> getAll();

	HsmConfigEditCopyEntity getEntity(String name);

	boolean isEditCopyExists(String name);

	void save(HsmConfigEditCopyEntity entity);

	void delete(HsmConfigEditCopyEntity entity);

	List<HsmConfigModel> getConfigByStatus(String status);

}
