package com.isg.mw.dstm.dao.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TERMINAL_MFTR_MAPPING")
public class MftrBDKEntity extends AuditInfoEntity {

	/**
	 * Primary id of the mftr
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	/**
	 * entity id of the manufacturer configuration
	 */
	@Column(name = "ENTITY_ID", length = 32)
	private String entityId;

	/**
	 * Name of the manufacturer configuration
	 */
	@Column(name = "MFTR_NAME", length = 50)
	private String mftrName;

	/**
	 * BDK 1
	 */
	@Column(name = "BDK1", length = 30)
	private String bdk1;

	/**
	 * BDK 2
	 */
	@Column(name = "BDK2", length = 30)
	private String bdk2;

	
}
