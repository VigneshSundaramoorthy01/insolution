package com.isg.mw.dstm.dao.utils;

import com.isg.mw.core.model.common.NettyCommonUtility;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;

/**
 * Hsm Configuration Master Utility
 * 
 * @author sudharshan
 */
public class HsmConfigMasterUtility {

	/**
	 * Default constructor It should not access from out side
	 * 
	 */
	private HsmConfigMasterUtility() {
	}

	public static HsmConfigModel getHsmConfigModel(HsmConfigMasterEntity hsmConfigMasterEntity) {
		HsmConfigModel model = new HsmConfigModel();
		model.setId(hsmConfigMasterEntity.getId());
		model.setEntityId(hsmConfigMasterEntity.getEntityId());
		model.setName(hsmConfigMasterEntity.getName());
		model.setManufacture(hsmConfigMasterEntity.getManufacture());
		model.setModel(hsmConfigMasterEntity.getModel());
		model.setProtocol(hsmConfigMasterEntity.getProtocol());
		model.setIp(hsmConfigMasterEntity.getIp());
		model.setPort(hsmConfigMasterEntity.getPort());
		model.setType(hsmConfigMasterEntity.getType());
		model.setOffsetType(hsmConfigMasterEntity.getOffsetType());
		model.setHeader(hsmConfigMasterEntity.getHeader());
		model.setStatus(hsmConfigMasterEntity.getStatus().name());
		model.setLockedState(hsmConfigMasterEntity.getLockedState());
		model.setRemarks(hsmConfigMasterEntity.getRemarks());
		model.setKeys(HsmConfigUtility.convertStringToKeyModel(hsmConfigMasterEntity.getKeys()));
		model.setHsmServices(HsmConfigUtility.convertStringToServicesModel(hsmConfigMasterEntity.getHsmServices()));
		//Netty Config Added.
		model.setNettyConfig(NettyCommonUtility.convertStringToNettyConfig(hsmConfigMasterEntity.getNettyParameters()));
		model.setCreatedAt(hsmConfigMasterEntity.getCreatedAt());
		model.setUpdatedAt(hsmConfigMasterEntity.getUpdatedAt());
		model.setCreatedBy(hsmConfigMasterEntity.getCreatedBy());
		model.setUpdatedBy(hsmConfigMasterEntity.getUpdatedBy());
		return model;
	}

	public static Object getHsmConfigMasterEntity(HsmConfigModel configModel) {
		HsmConfigMasterEntity entity = new HsmConfigMasterEntity();
		entity.setId(configModel.getId());
		entity.setEntityId(configModel.getEntityId());
		entity.setName(configModel.getName());
		entity.setManufacture(configModel.getManufacture());
		entity.setModel(configModel.getModel());
		entity.setProtocol(configModel.getProtocol());
		entity.setIp(configModel.getIp());
		entity.setPort(configModel.getPort());
		entity.setType(configModel.getType());
		entity.setOffsetType(configModel.getOffsetType());
		entity.setHeader(configModel.getHeader());
		entity.setStatus(ConfigStatus.Active);
		entity.setLockedState(LockedState.Unlocked);
		entity.setRemarks(configModel.getRemarks());
		entity.setKeys(HsmConfigUtility.keyModelToString(configModel.getKeys()));
		entity.setHsmServices(HsmConfigUtility.serviceModelToString(configModel.getHsmServices()));
		
		//Netty Config Added.
		entity.setNettyParameters(NettyCommonUtility.nettyConfigToString(configModel.getNettyConfig()));
		//entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		//entity.setUpdatedAt(configModel.getUpdatedAt());
		//entity.setCreatedBy(configModel.getCreatedBy());
		//entity.setUpdatedBy(configModel.getUpdatedBy());
		return entity;
	}

	public static void updateHsmConfigMasterEntity(HsmConfigModel configModel, HsmConfigMasterEntity entity) {
		entity.setId(configModel.getId());
		entity.setEntityId(configModel.getEntityId());
		entity.setName(configModel.getName());
		entity.setManufacture(configModel.getManufacture());
		entity.setModel(configModel.getModel());
		entity.setProtocol(configModel.getProtocol());
		entity.setIp(configModel.getIp());
		entity.setPort(configModel.getPort());
		entity.setType(configModel.getType());
		entity.setOffsetType(configModel.getOffsetType());
		entity.setHeader(configModel.getHeader());
		entity.setStatus(ConfigStatus.valueOf(configModel.getStatus()));
		entity.setLockedState(configModel.getLockedState());
		entity.setRemarks(configModel.getRemarks());
		entity.setKeys(HsmConfigUtility.keyModelToString(configModel.getKeys()));
		entity.setHsmServices(HsmConfigUtility.serviceModelToString(configModel.getHsmServices()));
		
		//Netty Config Added.
		entity.setNettyParameters(NettyCommonUtility.nettyConfigToString(configModel.getNettyConfig()));
		//entity.setCreatedAt(configModel.getCreatedAt());
		//entity.setUpdatedAt(configModel.getUpdatedAt());
		//entity.setCreatedBy(configModel.getCreatedBy());
		//entity.setUpdatedBy(configModel.getUpdatedBy());
	}

}