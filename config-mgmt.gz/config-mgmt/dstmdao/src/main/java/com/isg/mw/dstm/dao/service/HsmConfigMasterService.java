package com.isg.mw.dstm.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;

/**
 * Hsm Configuration Master Service
 * 
 * @author sudharshan
 */
public interface HsmConfigMasterService {

	HsmConfigModel getModel(String name);

	HsmConfigModel add(HsmConfigModel macModel);

	HsmConfigModel update(HsmConfigModel macModel);

	ConfigStatus updateStatus(String name, ConfigStatus status);

	List<HsmConfigModel> getAll();

	LockedState lock(String name, LockedState ls);

	HsmConfigMasterEntity getEntity(String name);

	void save(HsmConfigMasterEntity entity);

	List<HsmConfigModel> getAllActiveHsmConfigs();

	List<HsmConfigModel> getAllByParam(String entityId, ConfigStatus status, LockedState lockedState);
	
	List<HsmConfigModel> getConfigByStatus(String status);

}
