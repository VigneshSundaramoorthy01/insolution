package com.isg.mw.dstm.dao.service;

import java.util.List;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;

/**
 * This interface fused for hsm configuration validation
 * 
 * @author sudharshan
 */
public interface HsmConfigOnlineValidator {

	boolean isHsmExists(String name);

	boolean isHsmEditCopyExists(String name);

	boolean isHsmUnlocked(String name);

	void add(HsmConfigModel model);

	void modify(HsmConfigModel model);

	void submit(String name);

	void verify(String name, boolean approved);

	void lock(String name, LockedState lockedState);

	void update(String name, String status);

	List<HsmConfigMasterEntity> getMasterEntity(String name);

	List<HsmConfigEditCopyEntity> getEditCopyEntity(String name);

}
