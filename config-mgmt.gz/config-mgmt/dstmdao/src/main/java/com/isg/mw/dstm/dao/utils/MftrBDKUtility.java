package com.isg.mw.dstm.dao.utils;

import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.dstm.dao.entities.MftrBDKEntity;

public class MftrBDKUtility {


	/**
	 * Default constructor It should not access from out side
	 */
	private MftrBDKUtility() {

	}

	public static MftrBDKModel getMftrBDKModel(MftrBDKEntity entity) {
		MftrBDKModel model = new MftrBDKModel();
		model.setId(entity.getId());
		model.setEntityId(entity.getEntityId());
		model.setMftrName(entity.getMftrName());
		model.setBdk1(entity.getBdk1());
		model.setBdk2(entity.getBdk2());
		return model;
	}

}

