package com.isg.mw.dstm.dao.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.isg.common.auditinfo.AuditInfoEntity;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.HsmType;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.Offset;
import com.isg.mw.core.model.constants.ProtocolType;

import lombok.Getter;
import lombok.Setter;

/**
 * Master HSM configuration details
 * 
 * @author sudharshan
 */
@Getter
@Setter
@Entity
@Table(name = "HSM_CONFIG_MASTER")
public class HsmConfigMasterEntity extends AuditInfoEntity {

	// Auto Generated Id - Primary id
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "ENTITY_ID", length = 32)
	private String entityId;

	// Full Name with format of src_id|target id_hsm_config_<datetime>
	@Column(name = "NAME", length = 64)
	private String name;

	// HSM Provider Name,
	@Column(name = "MANUFACTURE", length = 64)
	private String manufacture;

	// Model Name
	@Column(name = "MODEL", length = 64)
	private String model;

	// Protocol type {TCP/HTTPS}
	@Enumerated(EnumType.STRING)
	@Column(name = "PROTOCOL", length = 10)
	private ProtocolType protocol;

	// Listen IP adress of HSM
	@Column(name = "IP", length = 32)
	private String ip;

	// Listen Port HSM
	@Column(name = "PORT", length = 5)
	private Integer port;

	// HSM Type{SW,HW,NA}
	@Enumerated(EnumType.STRING)
	@Column(name = "TYPE", length = 10)
	private HsmType type;

	// offset type {IBM,PVV}
	@Enumerated(EnumType.STRING)
	@Column(name = "OFFSET_TYPE", length = 10)
	private Offset offsetType;

	// HSM header
	@Column(name = "HEADER", length = 32)
	private String header;

	// status of hsm config
	@Enumerated(EnumType.STRING)
	@Column(name = "STATUS", length = 32)
	private ConfigStatus status;

	// lock status
	@Enumerated(EnumType.STRING)
	@Column(name = "LOCKED_STATE", length = 10)
	private LockedState lockedState;

	// rejected reason of hsm configuration
	@Column(name = "REMARKS", length = 2000)
	private String remarks;

	// Array of keys for the owners. Owners are source(MA) and target(Switch).
	@Column(name = "KEYS", length = 10000)
	private String keys;

	// Services - list of services like decrypt, pin transaction and pin generator
	@Column(name = "HSM_SERVICES", length = 10000)
	private String hsmServices;
	
	@Column(name = "NETTY_PARAMETERS", length = 10000)
	private String nettyParameters;

}
