package com.isg.mw.dstm.dao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;
import com.isg.mw.dstm.dao.repository.HsmConfigMasterRepository;
import com.isg.mw.dstm.dao.service.HsmConfigMasterService;
import com.isg.mw.dstm.dao.utils.HsmConfigMasterUtility;

/**
 * HSM Configuration master entity services
 * 
 * @author sudharshan
 */
@Service("hsmConfigMasterService")
public class HsmConfigMasterSeviceImpl implements HsmConfigMasterService {

	@Autowired
	private HsmConfigMasterRepository hsmConfigMasterRepository;

	@Override
	public HsmConfigModel getModel(String name) {
		List<HsmConfigMasterEntity> configMasterEntities = hsmConfigMasterRepository.findByName(name);
		HsmConfigModel model = null;
		if (!configMasterEntities.isEmpty()) {
			model = HsmConfigMasterUtility.getHsmConfigModel(configMasterEntities.get(0));
		}
		return model;
	}

	@Override
	public HsmConfigModel add(HsmConfigModel configModel) {
		return null;
	}

	@Override
	public HsmConfigModel update(HsmConfigModel configModel) {
		HsmConfigModel outputModel = null;
		List<HsmConfigMasterEntity> macEntities = hsmConfigMasterRepository.findByName(configModel.getName());
		if (!macEntities.isEmpty()) {
			HsmConfigMasterEntity entity = macEntities.get(0);
			HsmConfigMasterUtility.updateHsmConfigMasterEntity(configModel, entity);
			HsmConfigMasterEntity configMasterEntity = hsmConfigMasterRepository.save(entity);
			outputModel = HsmConfigMasterUtility.getHsmConfigModel(configMasterEntity);
		}
		return outputModel;
	}

	@Override
	public ConfigStatus updateStatus(String name, ConfigStatus status) {
		List<HsmConfigMasterEntity> configMasterEntities = hsmConfigMasterRepository.findByName(name);
		ConfigStatus newStatus = null;
		if (!configMasterEntities.isEmpty()) {
			HsmConfigMasterEntity entity = configMasterEntities.get(0);
			entity.setStatus(status);
			entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
			entity = hsmConfigMasterRepository.save(entity);
			newStatus = entity.getStatus();
		}
		return newStatus;
	}

	@Override
	public List<HsmConfigModel> getAll() {
		List<HsmConfigModel> models = null;
		List<HsmConfigMasterEntity> configMasterEntities = hsmConfigMasterRepository.getAll();
		if (configMasterEntities != null && !configMasterEntities.isEmpty()) {
			models = new ArrayList<HsmConfigModel>(configMasterEntities.size());
			for (HsmConfigMasterEntity mce : configMasterEntities) {
				models.add(HsmConfigMasterUtility.getHsmConfigModel(mce));
			}
		}
		return models;
	}

	@Override
	public LockedState lock(String name, LockedState ls) {
		HsmConfigMasterEntity entity = getEntity(name);
		entity.setLockedState(ls);
		entity = hsmConfigMasterRepository.save(entity);
		return entity.getLockedState();
	}

	@Override
	public HsmConfigMasterEntity getEntity(String name) {
		List<HsmConfigMasterEntity> entities = hsmConfigMasterRepository.findByName(name);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}

	@Override
	public void save(HsmConfigMasterEntity entity) {
		hsmConfigMasterRepository.save(entity);
	}

	@Override
	public List<HsmConfigModel> getAllActiveHsmConfigs() {
		List<HsmConfigModel> models = null;
		List<HsmConfigMasterEntity> configMasterEntities = hsmConfigMasterRepository
				.getAllActiveHsmConfigs(LockedState.Unlocked, ConfigStatus.Active);
		if (configMasterEntities != null && !configMasterEntities.isEmpty()) {
			models = new ArrayList<HsmConfigModel>(configMasterEntities.size());
			for (HsmConfigMasterEntity mce : configMasterEntities) {
				models.add(HsmConfigMasterUtility.getHsmConfigModel(mce));
			}
		}
		return models;
	}

	@Override
	public List<HsmConfigModel> getAllByParam(String entityId, ConfigStatus status, LockedState lockedState) {
		List<HsmConfigMasterEntity> configMasterEntities = null;
		List<HsmConfigModel> models = null;
		if (status == null && lockedState == null) {
			configMasterEntities = hsmConfigMasterRepository.getAllByParam(entityId);
		} else if (status != null && lockedState == null) {
			configMasterEntities = hsmConfigMasterRepository.getAllByParam(entityId, status);
		} else if (status == null && lockedState != null) {
			configMasterEntities = hsmConfigMasterRepository.getAllByParam(entityId, lockedState);
		} else if (status != null && lockedState != null) {
			configMasterEntities = hsmConfigMasterRepository.getAllByParam(entityId, status, lockedState);
		}
		if (configMasterEntities != null && !configMasterEntities.isEmpty()) {
			models = new ArrayList<HsmConfigModel>(configMasterEntities.size());
			for (HsmConfigMasterEntity mce : configMasterEntities) {
				models.add(HsmConfigMasterUtility.getHsmConfigModel(mce));
			}
		}
		return models;
	}

	@Override
	public List<HsmConfigModel> getConfigByStatus(String status) {
		List<HsmConfigMasterEntity> entities =new ArrayList<>();
		if (ConfigStatus.Active == ConfigStatus.getStatus(status)
				|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)) {
			entities = hsmConfigMasterRepository.getAll(ConfigStatus.valueOf(status));
		}
		if (LockedState.Locked == LockedState.getState(status)
				|| LockedState.Unlocked == LockedState.getState(status)) {
			entities = hsmConfigMasterRepository.getAll(LockedState.valueOf(status));
		}
		List<HsmConfigModel> list = new ArrayList<>(entities.size());
		if (!CollectionUtils.isEmpty(entities)) {
			for (HsmConfigMasterEntity entity : entities) {
				HsmConfigModel model = HsmConfigMasterUtility.getHsmConfigModel(entity);
				list.add(model);
			}
		}
		return list;
	}

}
