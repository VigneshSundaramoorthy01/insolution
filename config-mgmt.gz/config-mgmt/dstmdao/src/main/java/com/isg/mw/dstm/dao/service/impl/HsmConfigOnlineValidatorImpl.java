package com.isg.mw.dstm.dao.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.dstm.dao.constants.HsmConfigDaoMsgKeys;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;
import com.isg.mw.dstm.dao.repository.HsmConfigEditCopyRepository;
import com.isg.mw.dstm.dao.repository.HsmConfigMasterRepository;
import com.isg.mw.dstm.dao.service.HsmConfigOnlineValidator;

@Service("hsmConfigOnlineValidator")
public class HsmConfigOnlineValidatorImpl implements HsmConfigOnlineValidator {

	@Autowired
	HsmConfigMasterRepository hsmConfigMasterRepository;

	@Autowired
	HsmConfigEditCopyRepository hsmConfigEditCopyRepository;

	@Override
	public boolean isHsmExists(String name) {
		return hsmConfigMasterRepository.isHsmConfigExists(name);
	}

	@Override
	public boolean isHsmEditCopyExists(String name) {
		return hsmConfigEditCopyRepository.isHsmConfigExists(name);
	}

	@Override
	public boolean isHsmUnlocked(String name) {
		return hsmConfigMasterRepository.isHsmConfigExists(name, LockedState.Unlocked);
	}

	@Override
	public void add(HsmConfigModel model) {
		checkIsUnLocked(model.getName());
		if (isHsmExists(model.getName())) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_DUPLICATE_NAME_IN_MASTER, model.getName());
		} else if (isHsmEditCopyExists(model.getName())) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_DUPLICATE_NAME_IN_EDITCOPY, model.getName());
		} else if (model.getLockedState() == LockedState.Locked) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_LOCKEDSTATE_IS_NOT_UNLOCKED, model.getLockedState());
		}
	}

	@Override
	public void modify(HsmConfigModel model) {
		checkIsUnLocked(model.getName());
		HsmConfigEditCopyEntity editCopy = getHsmConfigEditCopyEntity(model.getName());
		if (editCopy == null) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_NOT_EXISTS_WITH_NAME_IN_EDITCOPY, model.getName());
		}
		if (editCopy != null && editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_STATUS_IS_SUBMITTED_STATUS, model.getName());
		}
	}

	@Override
	public void submit(String name) {
		checkIsUnLocked(name);
		HsmConfigEditCopyEntity editCopy = getHsmConfigEditCopyEntity(name);
		if (editCopy == null) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_NOT_EXISTS_WITH_NAME_IN_EDITCOPY, name);
		} else if (editCopy.getStatus() == EditStatus.Submitted) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_STATUS_IS_SUBMITTED_STATUS, name);
		}
		if (editCopy.getStatus() == EditStatus.Rejected) {
			throw new ValidationException(HsmConfigDaoMsgKeys.STATUS_HSM_IS_MANDATORY);
		}
	}

	@Override
	public void verify(String name, boolean approved) {
		checkIsUnLocked(name);
		HsmConfigEditCopyEntity editCopy = getHsmConfigEditCopyEntity(name);
		if (editCopy == null) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_NOT_EXISTS_WITH_NAME_IN_EDITCOPY, name);
		}
		if (editCopy.getStatus() != EditStatus.Submitted) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_STATUS_IS_NOT_SUBMITTED_STATUS, name);
		}
	}

	@Override
	public void lock(String name, LockedState lockedState) {
		HsmConfigMasterEntity master = getHsmConfigMasterEntity(name);
		if (master == null) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_NOT_EXISTS_WITH_NAME_IN_MASTER, name);
		}
		if (lockedState == master.getLockedState()) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_LOCKEDSTATE_IS_SAME_AS_EXPECTED, name);
		}
	}

	@Override
	public void update(String name, String status) {
		checkIsUnLocked(name);
		HsmConfigMasterEntity master = getHsmConfigMasterEntity(name);

		if (master == null) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_NOT_EXISTS_WITH_NAME_IN_MASTER, name);
		}
		if (status.equals(master.getStatus().name())) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_STATUS_IS_SAME_AS_EXPECTED, name, status);
		}

		if (status.equals(EditStatus.Inprogress.name())) {
			HsmConfigEditCopyEntity editCopy = getHsmConfigEditCopyEntity(name);
			if (editCopy != null && editCopy.getStatus() != EditStatus.Inprogress) {
				throw new ValidationException(HsmConfigDaoMsgKeys.HSM_STATUS_IS_SUBMITTED_STATUS, name);
			}
			if (editCopy != null && editCopy.getStatus() == EditStatus.Inprogress) {
				throw new ValidationException(HsmConfigDaoMsgKeys.HSM_STATUS_IS_SAME_AS_EXPECTED, name, status);
			}
		}

	}

	@Override
	public List<HsmConfigMasterEntity> getMasterEntity(String name) {
		return hsmConfigMasterRepository.findByName(name);
	}

	@Override
	public List<HsmConfigEditCopyEntity> getEditCopyEntity(String name) {
		return hsmConfigEditCopyRepository.findByName(name);
	}

	private HsmConfigEditCopyEntity getHsmConfigEditCopyEntity(String name) {
		List<HsmConfigEditCopyEntity> list = getEditCopyEntity(name);
		HsmConfigEditCopyEntity entity = null;
		if (!list.isEmpty()) {
			entity = list.get(0);
		}
		return entity;
	}

	private void checkIsUnLocked(String name) {
		HsmConfigMasterEntity master = getHsmConfigMasterEntity(name);
		if (master != null && master.getLockedState() == LockedState.Locked) {
			throw new ValidationException(HsmConfigDaoMsgKeys.HSM_LOCKEDSTATE_IS_NOT_UNLOCKED, master.getLockedState());
		}
	}

	private HsmConfigMasterEntity getHsmConfigMasterEntity(String name) {
		List<HsmConfigMasterEntity> list = getMasterEntity(name);
		HsmConfigMasterEntity entity = null;
		if (!list.isEmpty()) {
			entity = list.get(0);
		}
		return entity;
	}

}
