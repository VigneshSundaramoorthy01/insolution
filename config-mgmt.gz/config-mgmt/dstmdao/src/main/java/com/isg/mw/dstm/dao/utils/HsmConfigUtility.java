package com.isg.mw.dstm.dao.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmServices;
import com.isg.mw.core.model.dstm.Keys;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;

public class HsmConfigUtility {

	private static final Logger LOG = LogManager.getLogger(HsmConfigUtility.class);

	/**
	 * Default constructor It should not access from out side
	 */
	private HsmConfigUtility() {
	}

	public static void updateMaster(HsmConfigMasterEntity configMasterEntity, HsmConfigEditCopyEntity editCopyEntity) {
		configMasterEntity.setEntityId(editCopyEntity.getEntityId());
		configMasterEntity.setName(editCopyEntity.getName());
		configMasterEntity.setManufacture(editCopyEntity.getManufacture());
		configMasterEntity.setModel(editCopyEntity.getModel());
		configMasterEntity.setProtocol(editCopyEntity.getProtocol());
		configMasterEntity.setIp(editCopyEntity.getIp());
		configMasterEntity.setPort(editCopyEntity.getPort());
		configMasterEntity.setType(editCopyEntity.getType());
		configMasterEntity.setOffsetType(editCopyEntity.getOffsetType());
		configMasterEntity.setHeader(editCopyEntity.getHeader());
		configMasterEntity.setRemarks(editCopyEntity.getRemarks());
		configMasterEntity.setKeys(editCopyEntity.getKeys());
		configMasterEntity.setHsmServices(editCopyEntity.getHsmServices());
		configMasterEntity.setNettyParameters(editCopyEntity.getNettyParameters());
		// configMasterEntity.setUpdatedAt(editCopyEntity.getUpdatedAt());
		// configMasterEntity.setUpdatedBy(editCopyEntity.getUpdatedBy());
	}

	public static HsmConfigMasterEntity createMaster(HsmConfigEditCopyEntity editCopyEntity) {
		HsmConfigMasterEntity configMasterEntity = new HsmConfigMasterEntity();
		configMasterEntity.setId(editCopyEntity.getId());
		configMasterEntity.setEntityId(editCopyEntity.getEntityId());
		configMasterEntity.setName(editCopyEntity.getName());
		configMasterEntity.setManufacture(editCopyEntity.getManufacture());
		configMasterEntity.setModel(editCopyEntity.getModel());
		configMasterEntity.setProtocol(editCopyEntity.getProtocol());
		configMasterEntity.setIp(editCopyEntity.getIp());
		configMasterEntity.setPort(editCopyEntity.getPort());
		configMasterEntity.setType(editCopyEntity.getType());
		configMasterEntity.setOffsetType(editCopyEntity.getOffsetType());
		configMasterEntity.setHeader(editCopyEntity.getHeader());
		configMasterEntity.setStatus(ConfigStatus.Active);
		configMasterEntity.setLockedState(LockedState.Unlocked);
		configMasterEntity.setRemarks(editCopyEntity.getRemarks());
		configMasterEntity.setKeys(editCopyEntity.getKeys());
		configMasterEntity.setHsmServices(editCopyEntity.getHsmServices());
		configMasterEntity.setNettyParameters(editCopyEntity.getNettyParameters());
		// configMasterEntity.setCreatedAt(editCopyEntity.getCreatedAt());
		// configMasterEntity.setCreatedBy(editCopyEntity.getCreatedBy());
		return configMasterEntity;
	}

	public static void updateEditCopy(HsmConfigMasterEntity configMasterEntity,
			HsmConfigEditCopyEntity editCopyEntity) {
		editCopyEntity.setEntityId(configMasterEntity.getEntityId());
		editCopyEntity.setName(configMasterEntity.getName());
		editCopyEntity.setManufacture(configMasterEntity.getManufacture());
		editCopyEntity.setModel(configMasterEntity.getModel());
		editCopyEntity.setProtocol(configMasterEntity.getProtocol());
		editCopyEntity.setIp(configMasterEntity.getIp());
		editCopyEntity.setPort(configMasterEntity.getPort());
		editCopyEntity.setType(configMasterEntity.getType());
		editCopyEntity.setOffsetType(configMasterEntity.getOffsetType());
		editCopyEntity.setHeader(configMasterEntity.getHeader());
		editCopyEntity.setRemarks(configMasterEntity.getRemarks());
		editCopyEntity.setKeys(configMasterEntity.getKeys());
		editCopyEntity.setHsmServices(configMasterEntity.getHsmServices());
		editCopyEntity.setNettyParameters(configMasterEntity.getNettyParameters());
		// editCopyEntity.setCreatedAt(configMasterEntity.getCreatedAt());
		// editCopyEntity.setUpdatedAt(configMasterEntity.getUpdatedAt());
		// editCopyEntity.setCreatedBy(configMasterEntity.getCreatedBy());
		// editCopyEntity.setUpdatedBy(configMasterEntity.getUpdatedBy());
		editCopyEntity.setStatus(EditStatus.Inprogress);
	}

	public static HsmServices[] convertStringToServicesModel(String service) {
		ObjectMapper mapper = new ObjectMapper();
		HsmServices arr[] = null;
		try {
			arr = mapper.readValue(service, HsmServices[].class);
		} catch (JsonMappingException e) {
			LOG.error("An error occurred! {}", e);
		} catch (JsonProcessingException e) {
			LOG.error("An error occurred! {}", e);
		}
		return arr;
	}

	public static Keys[] convertStringToKeyModel(String keys) {
		ObjectMapper mapper = new ObjectMapper();
		Keys[] arr = null;
		try {
			arr = mapper.readValue(keys, Keys[].class);
		} catch (JsonMappingException e) {
			LOG.error("An error occurred! {}", e);
		} catch (JsonProcessingException e) {
			LOG.error("An error occurred! {}", e);
		}
		return arr;
	}

	public static String serviceModelToString(HsmServices[] service) {
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(service);
		} catch (Exception e) {
			LOG.error("An error occurred! {}", e);
		}
		return json;
	}

	public static String keyModelToString(Keys[] keys) {
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(keys);
		} catch (Exception e) {
			LOG.error("An error occurred! {}", e);
		}
		return json;
	}

}
