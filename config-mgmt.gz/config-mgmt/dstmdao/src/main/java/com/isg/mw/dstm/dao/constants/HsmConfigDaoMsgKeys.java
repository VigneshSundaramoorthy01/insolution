package com.isg.mw.dstm.dao.constants;

/**
 * constants to refer keys from message resource bundle
 * 
 * @author sudharshan
 */
public interface HsmConfigDaoMsgKeys {

	// should use with one argument - name
	static final String HSM_DUPLICATE_NAME_IN_MASTER = "hsm.dao.duplicate.name.in.master";

	// should use with one argument - name
	static final String HSM_DUPLICATE_NAME_IN_EDITCOPY = "hsm.dao.duplicate.name.in.editCopy";

	// should use with one argument - name
	static final String HSM_NOT_EXISTS_WITH_NAME_IN_EDITCOPY = "hsm.dao.name.not.exists.in.editcopy";

	// should use with one argument - name
	static final String HSM_STATUS_IS_SUBMITTED_STATUS = "hsm.dao.has.SUBMITTED.status";

	// should use with one argument - name
	static final String HSM_LOCKEDSTATE_IS_NOT_UNLOCKED = "hsm.dao.has.not.UN_LOCKED.state";

	// should use with one argument - name
	static final String HSM_STATUS_IS_NOT_SUBMITTED_STATUS = "hsm.dao.has.not.SUBMITTED.status";

	// should use with two argument - name, lockedstate
	static final String HSM_LOCKEDSTATE_IS_SAME_AS_EXPECTED = "hsm.dao.lockedstate.is.same.as.expected";

	// should use with two argument - name, status
	static final String HSM_STATUS_IS_SAME_AS_EXPECTED = "hsm.dao.status.is.same.as.expected";

	// should use with one argument - name
	static final String HSM_STATUS_IS_NOT_INPROGRESS_STATUS = "hsm.dao.has.not.INPROGRESS.status";

	// should use with one argument - name
	static final String HSM_NOT_EXISTS_WITH_NAME_IN_MASTER = "hsm.dao.name.not.exists.in.master";

	// should use with one argument - name
	static final String CANT_MODIFY_HSM_CONFIG = "hsm.dao.locked.state.should.not.be.same";
	
	static final String HSM_STATUS_IS_INVALID="hsm.dao.status.is.invalid";
	
	static final String STATUS_HSM_IS_MANDATORY="hsm.dao.status.is.mandatory";

}
