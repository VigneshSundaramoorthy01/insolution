package com.isg.mw.dstm.dao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;
import com.isg.mw.dstm.dao.repository.HsmConfigEditCopyRepository;
import com.isg.mw.dstm.dao.service.HsmConfigEditCopyService;
import com.isg.mw.dstm.dao.utils.HsmConfigEditCopyUtility;

/**
 * Hsm Configuration Edit Copy Sevice Implementation
 * 
 * @author sudharshan
 */
@Service("hsmConfigEditCopyService")
public class HsmConfigEditCopySeviceImpl implements HsmConfigEditCopyService {

	@Autowired
	private HsmConfigEditCopyRepository hsmConfigEditCopyRepository;

	@Override
	public HsmConfigModel getModel(String name) {
		List<HsmConfigEditCopyEntity> entities = hsmConfigEditCopyRepository.findByName(name);
		HsmConfigModel model = null;
		if (!entities.isEmpty()) {
			model = HsmConfigEditCopyUtility.getHsmConfigModel(entities.get(0));
		}
		return model;
	}

	@Override
	public HsmConfigModel add(HsmConfigModel configModel) {
		HsmConfigEditCopyEntity configEditCopyEntity = hsmConfigEditCopyRepository
				.save(HsmConfigEditCopyUtility.getHsmConfigEditCopyEntity(configModel));
		return HsmConfigEditCopyUtility.getHsmConfigModel(configEditCopyEntity);
	}

	@Override
	public HsmConfigModel update(HsmConfigModel configModel) {
		HsmConfigModel outputModel = null;
		List<HsmConfigEditCopyEntity> configEditCopyEntities = hsmConfigEditCopyRepository
				.findByName(configModel.getName());
		if (!configEditCopyEntities.isEmpty()) {
			HsmConfigEditCopyEntity entity = configEditCopyEntities.get(0);
			HsmConfigEditCopyUtility.updateHsmConfigEditCopyEntity(configModel, entity);
			if(entity.getStatus() == EditStatus.Rejected) {
				entity.setStatus(EditStatus.Inprogress);
			}
			HsmConfigEditCopyEntity configEditCopyEntity = hsmConfigEditCopyRepository.save(entity);
			outputModel = HsmConfigEditCopyUtility.getHsmConfigModel(configEditCopyEntity);
		}
		return outputModel;
	}

	@Override
	public String updateStatus(EditStatus status, String name, String remarks) {
		HsmConfigEditCopyEntity entity = getEntity(name);
		entity.setStatus(status);
		entity.setRemarks(remarks != null ? remarks : entity.getRemarks());
		entity = hsmConfigEditCopyRepository.save(entity);
		return entity.getStatus().name();
	}

	@Override
	public List<HsmConfigModel> getAll() {
		List<HsmConfigModel> models = null;
		List<HsmConfigEditCopyEntity> configEditCopyEntities = hsmConfigEditCopyRepository.getAll();
		if (configEditCopyEntities != null && !configEditCopyEntities.isEmpty()) {
			models = new ArrayList<HsmConfigModel>(configEditCopyEntities.size());
			for (HsmConfigEditCopyEntity mce : configEditCopyEntities) {
				models.add(HsmConfigEditCopyUtility.getHsmConfigModel(mce));
			}
		}
		return models;
	}

	@Override
	public HsmConfigEditCopyEntity getEntity(String name) {
		List<HsmConfigEditCopyEntity> entities = hsmConfigEditCopyRepository.findByName(name);
		if (!entities.isEmpty()) {
			return entities.get(0);
		}
		return null;
	}

	@Override
	public boolean isEditCopyExists(String name) {
		return hsmConfigEditCopyRepository.isHsmConfigExists(name);
	}

	@Override
	public void save(HsmConfigEditCopyEntity entity) {
		hsmConfigEditCopyRepository.save(entity);
	}

	@Override
	public void delete(HsmConfigEditCopyEntity entity) {
		hsmConfigEditCopyRepository.delete(entity);
	}

	@Override
	public List<HsmConfigModel> getConfigByStatus(String status) {
		List<HsmConfigEditCopyEntity> entities = hsmConfigEditCopyRepository.getAll(EditStatus.valueOf(status));
		List<HsmConfigModel> list = new ArrayList<>(entities.size());
		if (!CollectionUtils.isEmpty(entities)) {
			for (HsmConfigEditCopyEntity entity : entities) {
				HsmConfigModel model = HsmConfigEditCopyUtility.getHsmConfigModel(entity);
				list.add(model);
			}
		}
		return list;
	}

}