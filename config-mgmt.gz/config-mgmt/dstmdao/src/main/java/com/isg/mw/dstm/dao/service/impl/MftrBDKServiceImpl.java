package com.isg.mw.dstm.dao.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.dstm.dao.entities.MftrBDKEntity;
import com.isg.mw.dstm.dao.repository.MftrBDKRepository;
import com.isg.mw.dstm.dao.service.MftrBDKService;
import com.isg.mw.dstm.dao.utils.MftrBDKUtility;

@Service("mftrBDKService")
public class MftrBDKServiceImpl implements MftrBDKService {

	@Autowired
	private MftrBDKRepository mftrBDKRepository;

	@Override
	public MftrBDKModel findByMftrNameAndEntityId(String mftrName, String entityId) {
		MftrBDKEntity entity = mftrBDKRepository.findByMftrNameAndEntityId(mftrName, entityId);
		MftrBDKModel model = new MftrBDKModel();
		if (entity != null ) {
			 model = MftrBDKUtility.getMftrBDKModel(entity);
		}
		return model;
	}
	
	@Override
	public List<MftrBDKModel> getAll() {
		List<MftrBDKEntity> entities = mftrBDKRepository.getAll();
		List<MftrBDKModel> list = new ArrayList<MftrBDKModel>(entities.size());
		if (entities != null && !entities.isEmpty()) {
			for (MftrBDKEntity mb : entities) {
				MftrBDKModel model = MftrBDKUtility.getMftrBDKModel(mb);
				list.add(model);
			}
		}
		return list;
	}

}
