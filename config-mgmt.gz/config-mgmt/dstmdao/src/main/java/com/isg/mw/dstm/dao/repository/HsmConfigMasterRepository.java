package com.isg.mw.dstm.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;

/**
 * Hsm Configuration Master Repository
 * 
 * @author sudharshan
 */
public interface HsmConfigMasterRepository extends CrudRepository<HsmConfigMasterEntity, Long> {

	/**
	 * finds the matching Hsm configuration master with the given name
	 * 
	 * @param name - name of the Hsm configuration master
	 * @return - List of Hsm configuration master objects
	 */
	List<HsmConfigMasterEntity> findByName(@Param("name") String name);

	/**
	 * 
	 * @param name - status of the Hsm configuration master
	 * @return - true or false value if Hsm configuration master exists
	 */
	@Query("SELECT CASE WHEN COUNT(hsmc) > 0 THEN true ELSE false END FROM HsmConfigMasterEntity hsmc WHERE hsmc.name = :name")
	boolean isHsmConfigExists(@Param("name") String name);

	/**
	 * 
	 * @param status -status of the Hsm configuration master
	 * @param name   - name of the Hsm configuration master status
	 * @return - true or false value if Hsm configuration master status matching
	 */
	@Query("SELECT CASE WHEN COUNT(hsmc) > 0 THEN true ELSE false END FROM HsmConfigMasterEntity hsmc WHERE hsmc.status = :status and hsmc.name = :name")
	boolean isHsmConfiStatusMatching(@Param("status") ConfigStatus status, @Param("name") String name);

	/**
	 * 
	 * @return - List of Hsm configuration master objects
	 */
	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc")
	List<HsmConfigMasterEntity> getAll();

	/**
	 * @param name        - name of the configuration
	 * @param lockedState - locked state
	 * 
	 * @return - true or false value if hsm is exists
	 */
	@Query("SELECT CASE WHEN COUNT(hsmc) > 0 THEN true ELSE false END FROM HsmConfigMasterEntity hsmc WHERE "
			+ "hsmc.name = :name and hsmc.lockedState = :lockedState")
	boolean isHsmConfigExists(@Param("name") String name, @Param("lockedState") LockedState lockedState);

	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc where hsmc.lockedState = :lockedState and hsmc.status = :status ")
	List<HsmConfigMasterEntity> getAllActiveHsmConfigs(@Param("lockedState") LockedState lockedState,
			@Param("status") ConfigStatus status);

	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc where hsmc.entityId = :entityId")
	List<HsmConfigMasterEntity> getAllByParam(String entityId);

	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc where hsmc.entityId = :entityId and hsmc.status = :status")
	List<HsmConfigMasterEntity> getAllByParam(String entityId, ConfigStatus status);

	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc where hsmc.entityId = :entityId and hsmc.lockedState = :lockedState")
	List<HsmConfigMasterEntity> getAllByParam(String entityId, LockedState lockedState);

	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc where hsmc.entityId = :entityId and hsmc.status = :status and hsmc.lockedState = :lockedState")
	List<HsmConfigMasterEntity> getAllByParam(@Param("entityId") String entityId, @Param("status") ConfigStatus status,
			@Param("lockedState") LockedState lockedState);

	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc WHERE hsmc.status = :status")
	List<HsmConfigMasterEntity> getAll(@Param("status") ConfigStatus status);
	
	@Query("SELECT hsmc FROM HsmConfigMasterEntity hsmc WHERE hsmc.lockedState = :status")
	List<HsmConfigMasterEntity> getAll(@Param("status") LockedState status);

}
