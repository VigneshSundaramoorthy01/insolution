package com.isg.mw.dstm.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.isg.mw.dstm.dao.entities.MftrBDKEntity;


public interface MftrBDKRepository extends CrudRepository<MftrBDKEntity, Long> {

	@Query("SELECT mb FROM MftrBDKEntity mb WHERE mb.mftrName = :mftrName and mb.entityId = :entityId")
	MftrBDKEntity findByMftrNameAndEntityId(@Param("mftrName") String mftrName, @Param("entityId") String entityId);
	
	@Query("SELECT mb FROM MftrBDKEntity mb")
	List<MftrBDKEntity> getAll();


}