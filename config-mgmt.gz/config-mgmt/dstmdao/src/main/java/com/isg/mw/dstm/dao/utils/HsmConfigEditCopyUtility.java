package com.isg.mw.dstm.dao.utils;

import com.isg.mw.core.model.common.NettyCommonUtility;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;

/**
 * Hsm Configuration Edit Copy Utility
 * 
 * @author sudharshan
 */
public class HsmConfigEditCopyUtility {

	/**
	 * Default constructor It should not access from out side
	 * 
	 */
	private HsmConfigEditCopyUtility() {
	}

	public static HsmConfigModel getHsmConfigModel(HsmConfigEditCopyEntity hsmConfigEditCopyEntity) {
		HsmConfigModel model = new HsmConfigModel();
		model.setId(hsmConfigEditCopyEntity.getId());
		model.setEntityId(hsmConfigEditCopyEntity.getEntityId());
		model.setName(hsmConfigEditCopyEntity.getName());
		model.setManufacture(hsmConfigEditCopyEntity.getManufacture());
		model.setModel(hsmConfigEditCopyEntity.getModel());
		model.setProtocol(hsmConfigEditCopyEntity.getProtocol());
		model.setIp(hsmConfigEditCopyEntity.getIp());
		model.setPort(hsmConfigEditCopyEntity.getPort());
		model.setType(hsmConfigEditCopyEntity.getType());
		model.setOffsetType(hsmConfigEditCopyEntity.getOffsetType());
		model.setHeader(hsmConfigEditCopyEntity.getHeader());
		model.setStatus(hsmConfigEditCopyEntity.getStatus().name());
		model.setRemarks(hsmConfigEditCopyEntity.getRemarks());
		model.setKeys(HsmConfigUtility.convertStringToKeyModel(hsmConfigEditCopyEntity.getKeys()));
		model.setHsmServices(HsmConfigUtility.convertStringToServicesModel(hsmConfigEditCopyEntity.getHsmServices()));
		//Netty Config
		model.setNettyConfig(NettyCommonUtility.convertStringToNettyConfig(hsmConfigEditCopyEntity.getNettyParameters()));
		model.setCreatedAt(hsmConfigEditCopyEntity.getCreatedAt());
		model.setUpdatedAt(hsmConfigEditCopyEntity.getUpdatedAt());
		model.setCreatedBy(hsmConfigEditCopyEntity.getCreatedBy());
		model.setUpdatedBy(hsmConfigEditCopyEntity.getUpdatedBy());
		return model;
	}

	public static HsmConfigEditCopyEntity getHsmConfigEditCopyEntity(HsmConfigModel configModel) {
		HsmConfigEditCopyEntity entity = new HsmConfigEditCopyEntity();
		entity.setId(configModel.getId());
		entity.setEntityId(configModel.getEntityId());
		entity.setName(configModel.getName());
		entity.setManufacture(configModel.getManufacture());
		entity.setModel(configModel.getModel());
		entity.setProtocol(configModel.getProtocol());
		entity.setIp(configModel.getIp());
		entity.setPort(configModel.getPort());
		entity.setType(configModel.getType());
		entity.setOffsetType(configModel.getOffsetType());
		entity.setHeader(configModel.getHeader());
		entity.setStatus(EditStatus.Inprogress);
		entity.setRemarks(configModel.getRemarks());
		entity.setKeys(HsmConfigUtility.keyModelToString(configModel.getKeys()));
		entity.setHsmServices(HsmConfigUtility.serviceModelToString(configModel.getHsmServices()));
		// Netty Config Properties Added.
		entity.setNettyParameters(NettyCommonUtility.nettyConfigToString(configModel.getNettyConfig()));
		// entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		// entity.setUpdatedAt(configModel.getUpdatedAt());
		// entity.setCreatedBy(configModel.getCreatedBy());
		// entity.setUpdatedBy(configModel.getUpdatedBy());
		return entity;
	}

	public static void updateHsmConfigEditCopyEntity(HsmConfigModel configModel, HsmConfigEditCopyEntity entity) {
		entity.setEntityId(configModel.getEntityId());
		entity.setName(configModel.getName());
		entity.setManufacture(configModel.getManufacture());
		entity.setModel(configModel.getModel());
		entity.setProtocol(configModel.getProtocol());
		entity.setIp(configModel.getIp());
		entity.setPort(configModel.getPort());
		entity.setType(configModel.getType());
		entity.setOffsetType(configModel.getOffsetType());
		entity.setHeader(configModel.getHeader());
		entity.setKeys(HsmConfigUtility.keyModelToString(configModel.getKeys()));
		entity.setHsmServices(HsmConfigUtility.serviceModelToString(configModel.getHsmServices()));
		// Netty Config Properties Added.
		entity.setNettyParameters(NettyCommonUtility.nettyConfigToString(configModel.getNettyConfig()));
		// entity.setCreatedAt(configModel.getCreatedAt());
		// entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		// entity.setCreatedBy(configModel.getCreatedBy());
		// entity.setUpdatedBy(configModel.getUpdatedBy());
	}

}