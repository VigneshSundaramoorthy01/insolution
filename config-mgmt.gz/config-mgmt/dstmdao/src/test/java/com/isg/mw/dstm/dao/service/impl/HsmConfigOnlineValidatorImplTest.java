package com.isg.mw.dstm.dao.service.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;
import com.isg.mw.dstm.dao.repository.HsmConfigEditCopyRepository;
import com.isg.mw.dstm.dao.repository.HsmConfigMasterRepository;
/**
 * 
 * @author shital3986
 */
public class HsmConfigOnlineValidatorImplTest {

	@Mock
	private HsmConfigMasterRepository hsmConfigMasterRepository;

	@Mock
	private HsmConfigEditCopyRepository hsmConfigEditCopyRepository;

	@InjectMocks
	private HsmConfigOnlineValidatorImpl hsmConfigOnlineValidator;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void isHsmExistsTest() {
		when(hsmConfigMasterRepository.isHsmConfigExists(Mockito.any())).thenReturn(true);
		hsmConfigOnlineValidator.isHsmExists("HSM");
	}

	@Test
	public void isHsmEditCopyExistsTest() {
		when(hsmConfigEditCopyRepository.isHsmConfigExists(Mockito.any())).thenReturn(true);
		hsmConfigOnlineValidator.isHsmEditCopyExists("HSM");
	}

	@Test
	public void isHsmUnlockedTest() {
		when(hsmConfigMasterRepository.isHsmConfigExists("HSM", LockedState.Unlocked)).thenReturn(true);
		hsmConfigOnlineValidator.isHsmUnlocked("HSM");
	}

	@Test
	public void addTest_1() {
		List<HsmConfigMasterEntity> list = new ArrayList<HsmConfigMasterEntity>();
		list.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigOnlineValidator.isHsmExists(Mockito.any())).thenReturn(true);
		try {
			hsmConfigOnlineValidator.add(getHsmConfigModel());
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void addTest_2() {
		List<HsmConfigMasterEntity> list = new ArrayList<HsmConfigMasterEntity>();
		list.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigOnlineValidator.isHsmEditCopyExists(Mockito.any())).thenReturn(true);
		try {
			hsmConfigOnlineValidator.add(getHsmConfigModel());
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void addTest_3() {
		List<HsmConfigMasterEntity> list = new ArrayList<HsmConfigMasterEntity>();
		list.add(getHsmConfigMasterEntity_Locked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigOnlineValidator.isHsmEditCopyExists(Mockito.any())).thenReturn(true);
		try {
			hsmConfigOnlineValidator.add(getHsmConfigModel());
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void modifyTest_1() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity_Submitted());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigOnlineValidator.isHsmEditCopyExists(Mockito.any())).thenReturn(true);
		try {
			hsmConfigOnlineValidator.modify(getHsmConfigModel());
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void modifyTest_2() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		when(hsmConfigOnlineValidator.isHsmEditCopyExists(Mockito.any())).thenReturn(true);
		try {
			hsmConfigOnlineValidator.modify(getHsmConfigModel());
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void submitTest_1() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity_Submitted());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.submit("HSM");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void submitTest_3() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity_NOTINPROGRESS());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.submit("HSM");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void submitTest_2() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		try {
			hsmConfigOnlineValidator.submit("HSM");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void verifyTest_1() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		when(hsmConfigOnlineValidator.isHsmEditCopyExists(Mockito.any())).thenReturn(true);
		try {
			hsmConfigOnlineValidator.verify("HSM", true);
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void verifyTest_2() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.verify("HSM", true);
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void verifyTest_3() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity_NOTINPROGRESS());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.verify("HSM", true);
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void lockTest_1() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		try {
			hsmConfigOnlineValidator.lock("HSM", LockedState.Unlocked);
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void lockTest_2() {
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		try {
			hsmConfigOnlineValidator.lock("HSM", LockedState.Unlocked);
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void lockTest_3() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		try {
			hsmConfigOnlineValidator.lock("HSM", LockedState.Locked);
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void updateTest_1() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		try {
			hsmConfigOnlineValidator.update("HSM", "Inactive");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void updateTest_2() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		try {
			hsmConfigOnlineValidator.update("HSM", "Inactive");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void updateTest_3() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.update("HSM", "Inprogress");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void updateTest_4() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.update("HSM", "Active");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}
	

	@Test
	public void updateTest_5() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity_NOTINPROGRESS());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		try {
			hsmConfigOnlineValidator.update("HSM", "Inprogress");
		} catch (ValidationException e) {
			e.getMessage();
		}
	}

	@Test
	public void getMasterEntityTest() {
		List<HsmConfigMasterEntity> listMaster = new ArrayList<HsmConfigMasterEntity>();
		listMaster.add(getHsmConfigMasterEntity_UnLocked());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(listMaster);
		List<HsmConfigMasterEntity> masterEntity = hsmConfigOnlineValidator.getMasterEntity("HSM");
		assertNotNull(masterEntity);
		assertEquals("HSM", masterEntity.get(0).getName());

	}

	@Test
	public void getEditCopyEntityTest() {
		List<HsmConfigEditCopyEntity> list = new ArrayList<HsmConfigEditCopyEntity>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		List<HsmConfigEditCopyEntity> editCopyEntity = hsmConfigOnlineValidator.getEditCopyEntity("ABC");
		assertNotNull(editCopyEntity);
		assertEquals("ABC", editCopyEntity.get(0).getName());
	}

	public HsmConfigModel getHsmConfigModel() {
		HsmConfigModel hsmConfigModel = new HsmConfigModel();
		hsmConfigModel.setIp("192.168.37.30");
		hsmConfigModel.setName("ABC");
		return hsmConfigModel;
	}

	public HsmConfigMasterEntity getHsmConfigMasterEntity_UnLocked() {
		HsmConfigMasterEntity hsmConfigMasterEntity = new HsmConfigMasterEntity();
		hsmConfigMasterEntity.setIp("192.168.37.30");
		hsmConfigMasterEntity.setName("HSM");
		hsmConfigMasterEntity.setStatus(ConfigStatus.Inactive);
		hsmConfigMasterEntity.setKeys("1");
		hsmConfigMasterEntity.setHsmServices("Service");
		hsmConfigMasterEntity.setLockedState(LockedState.Unlocked);
		return hsmConfigMasterEntity;
	}

	public HsmConfigMasterEntity getHsmConfigMasterEntity_Locked() {
		HsmConfigMasterEntity hsmConfigMasterEntity = new HsmConfigMasterEntity();
		hsmConfigMasterEntity.setIp("192.168.37.30");
		hsmConfigMasterEntity.setName("HSM");
		hsmConfigMasterEntity.setStatus(ConfigStatus.Inactive);
		hsmConfigMasterEntity.setKeys("1");
		hsmConfigMasterEntity.setHsmServices("Service");
		hsmConfigMasterEntity.setLockedState(LockedState.Locked);
		return hsmConfigMasterEntity;
	}

	public HsmConfigEditCopyEntity getHsmConfigEditCopyEntity_Submitted() {
		HsmConfigEditCopyEntity hsmConfigEditCopyEntity = new HsmConfigEditCopyEntity();
		hsmConfigEditCopyEntity.setIp("192.168.37.25");
		hsmConfigEditCopyEntity.setName("ABC");
		hsmConfigEditCopyEntity.setStatus(EditStatus.Submitted);
		hsmConfigEditCopyEntity.setKeys("1");
		hsmConfigEditCopyEntity.setHsmServices("Service");
		return hsmConfigEditCopyEntity;
	}

	public HsmConfigEditCopyEntity getHsmConfigEditCopyEntity() {
		HsmConfigEditCopyEntity hsmConfigEditCopyEntity = new HsmConfigEditCopyEntity();
		hsmConfigEditCopyEntity.setIp("192.168.37.25");
		hsmConfigEditCopyEntity.setName("ABC");
		hsmConfigEditCopyEntity.setStatus(EditStatus.Inprogress);
		hsmConfigEditCopyEntity.setKeys("1");
		hsmConfigEditCopyEntity.setHsmServices("Service");
		return hsmConfigEditCopyEntity;
	}

	public HsmConfigEditCopyEntity getHsmConfigEditCopyEntity_NOTINPROGRESS() {
		HsmConfigEditCopyEntity hsmConfigEditCopyEntity = new HsmConfigEditCopyEntity();
		hsmConfigEditCopyEntity.setIp("192.168.37.25");
		hsmConfigEditCopyEntity.setName("ABC");
		hsmConfigEditCopyEntity.setStatus(EditStatus.Submitted);
		hsmConfigEditCopyEntity.setKeys("1");
		hsmConfigEditCopyEntity.setHsmServices("Service");
		return hsmConfigEditCopyEntity;
	}
}
