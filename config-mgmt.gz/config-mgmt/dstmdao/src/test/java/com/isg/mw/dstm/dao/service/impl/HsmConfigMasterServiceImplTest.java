package com.isg.mw.dstm.dao.service.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.HsmType;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigMasterEntity;
import com.isg.mw.dstm.dao.repository.HsmConfigMasterRepository;
import com.isg.mw.dstm.dao.service.impl.HsmConfigMasterSeviceImpl;
/**
 * 
 * @author shital3986
 */
public class HsmConfigMasterServiceImplTest {

	@Mock
	private HsmConfigMasterRepository hsmConfigMasterRepository;

	@InjectMocks
	private HsmConfigMasterSeviceImpl hsmConfigMasterService;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getModeltest() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		HsmConfigModel model = hsmConfigMasterService.getModel("HSM");
		assertNotNull(model);
	}

	@Test
	public void addTest() {
		HsmConfigModel add = hsmConfigMasterService.add(getHsmConfigModel());
		assertNull(add);
	}

	@Test
	public void updateTest() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigMasterRepository.save(Mockito.any())).thenReturn(getHsmConfigMasterEntity());
		HsmConfigModel update = hsmConfigMasterService.update(getHsmConfigModel());
		assertNotNull(update);
	}

	@Test
	public void updateTestEmpty() {
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		when(hsmConfigMasterRepository.save(Mockito.any())).thenReturn(getHsmConfigMasterEntity());
		HsmConfigModel update = hsmConfigMasterService.update(getHsmConfigModel());
		assertNull(update);
	}

	@Test
	public void updateStatusTest() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigMasterRepository.save(Mockito.any())).thenReturn(getHsmConfigMasterEntity());
		ConfigStatus updateStatus = hsmConfigMasterService.updateStatus("HSM", ConfigStatus.Inactive);
		assertNotNull(updateStatus);
		assertEquals(ConfigStatus.Inactive, updateStatus);
	}

	@Test
	public void getAllTest() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.getAll()).thenReturn(list);
		List<HsmConfigModel> all = hsmConfigMasterService.getAll();
		assertEquals("ABC", all.get(0).getName());
		

	}

	@Test
	public void getAllTest_Empty() {
		when(hsmConfigMasterRepository.getAll()).thenReturn(new ArrayList<>());
		List<HsmConfigModel> model = hsmConfigMasterService.getAll();
		assertNull(model);
	}

	@Test
	public void lockTest() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigMasterRepository.save(Mockito.any())).thenReturn(getHsmConfigMasterEntity());
		LockedState lock = hsmConfigMasterService.lock("HSM", LockedState.Locked);
		assertEquals(LockedState.Locked, lock);
	}

	@Test
	public void saveTest() {
		when(hsmConfigMasterRepository.save(Mockito.any())).thenReturn(getHsmConfigMasterEntity());
		hsmConfigMasterService.save(getHsmConfigMasterEntity());
	}

	@Test
	public void getAllActiveHsmConfigsTest() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.getAllActiveHsmConfigs(LockedState.Unlocked, ConfigStatus.Active))
				.thenReturn(list);
		List<HsmConfigModel> allActiveHsmConfigs = hsmConfigMasterService.getAllActiveHsmConfigs();
		assertNotNull(allActiveHsmConfigs);
		assertEquals(LockedState.Locked, allActiveHsmConfigs.get(0).getLockedState());
		assertEquals(HsmType.HW, allActiveHsmConfigs.get(0).getType());
	}

	@Test
	public void getAllActiveHsmConfigsTest_Empty() {
		when(hsmConfigMasterRepository.getAllActiveHsmConfigs(LockedState.Unlocked, ConfigStatus.Active))
				.thenReturn(new ArrayList<>());
		List<HsmConfigModel> allActiveHsmConfigs = hsmConfigMasterService.getAllActiveHsmConfigs();
		assertNull(allActiveHsmConfigs);
	}

	@Test
	public void getAllByParamTest_1() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.getAllByParam(Mockito.any())).thenReturn(list);
		List<HsmConfigModel> allByParam = hsmConfigMasterService.getAllByParam("HSM", null, null);
		assertNotNull(allByParam);
		assertEquals("ABC", allByParam.get(0).getName());
		assertEquals(HsmType.HW, allByParam.get(0).getType());
	}

	@Test
	public void getAllByParamTest_2() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.getAllByParam("HSM", ConfigStatus.Active)).thenReturn(list);
		List<HsmConfigModel> allByParam = hsmConfigMasterService.getAllByParam("HSM", ConfigStatus.Active, null);
		assertNotNull(allByParam);
		assertEquals("ABC", allByParam.get(0).getName());
		assertEquals(HsmType.HW, allByParam.get(0).getType());
	}

	@Test
	public void getAllByParamTest_3() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.getAllByParam("HSM", LockedState.Unlocked)).thenReturn(list);
		List<HsmConfigModel> allByParam = hsmConfigMasterService.getAllByParam("HSM", null, LockedState.Unlocked);
		assertNotNull(allByParam);
		assertEquals("ABC", allByParam.get(0).getName());
		assertEquals(HsmType.HW, allByParam.get(0).getType());
	}

	@Test
	public void getAllByParamTest_4() {
		List<HsmConfigMasterEntity> list = new ArrayList<>();
		list.add(getHsmConfigMasterEntity());
		when(hsmConfigMasterRepository.getAllByParam("HSM", ConfigStatus.Active, LockedState.Unlocked))
				.thenReturn(list);
		List<HsmConfigModel> allByParam = hsmConfigMasterService.getAllByParam("HSM", ConfigStatus.Active,
				LockedState.Unlocked);
		assertNotNull(allByParam);
		assertEquals("ABC", allByParam.get(0).getName());
		assertEquals(HsmType.HW, allByParam.get(0).getType());
	}

	public HsmConfigModel getHsmConfigModel() {
		HsmConfigModel hsmConfigModel = new HsmConfigModel();
		hsmConfigModel.setIp("192.168.37.30");
		hsmConfigModel.setName("ABC");
		hsmConfigModel.setStatus("Active");
		NettyConfig netty = new NettyConfig();
		netty.setConnectTimeout(1500);
		netty.setRequestTimeout(1000L);
		netty.setWorkerCount(5);
		hsmConfigModel.setNettyConfig(netty);
		hsmConfigModel.setEntityId("isg");
		hsmConfigModel.setType(HsmType.HW);
		return hsmConfigModel;
	}

	public HsmConfigMasterEntity getHsmConfigMasterEntity() {
		HsmConfigMasterEntity hsmConfigMasterEntity = new HsmConfigMasterEntity();
		hsmConfigMasterEntity.setIp("192.168.37.30");
		hsmConfigMasterEntity.setName("ABC");
		hsmConfigMasterEntity.setStatus(ConfigStatus.Inactive);
		hsmConfigMasterEntity.setKeys("1");
		hsmConfigMasterEntity.setHsmServices("Service");
		hsmConfigMasterEntity.setLockedState(LockedState.Locked);
		hsmConfigMasterEntity.setType(HsmType.HW);
		hsmConfigMasterEntity.setNettyParameters("{\"workerCount\":5,\"requestTimeout\":30000,\"connectTimeout\":1000,\"poolMaxActive\":-1,\"poolMaxIdle\":100,\"poolMinEvictableIdle\":300000,\"poolMinIdle\":0}");
		return hsmConfigMasterEntity;
	}

}
