package com.isg.mw.dstm.dao.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.HsmType;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.dao.entities.HsmConfigEditCopyEntity;
import com.isg.mw.dstm.dao.repository.HsmConfigEditCopyRepository;
import com.isg.mw.dstm.dao.service.impl.HsmConfigEditCopySeviceImpl;
/**
 * 
 * @author shital3986
 */
public class HsmConfigEditCopyServiceImplTest {

	@Mock
	private HsmConfigEditCopyRepository hsmConfigEditCopyRepository;

	@InjectMocks
	private HsmConfigEditCopySeviceImpl hsmConfigEditCopySevice;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getModelTest() {
		List<HsmConfigEditCopyEntity> list = new ArrayList<>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		HsmConfigModel model = hsmConfigEditCopySevice.getModel("HSM");
		assertNotNull(model);
		assertEquals(HsmType.HW, model.getType());
	}

	@Test
	public void getModelTest_Empty() {
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		HsmConfigModel model = hsmConfigEditCopySevice.getModel("HSM");
		assertNull(model);
	}

	@Test
	public void addTest() {
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		HsmConfigModel model = hsmConfigEditCopySevice.add(getHsmConfigModel());
		assertNotNull(model);
		assertEquals(HsmType.HW, model.getType());
	}

	@Test
	public void updateTest() {
		List<HsmConfigEditCopyEntity> list = new ArrayList<>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		HsmConfigModel model = hsmConfigEditCopySevice.update(getHsmConfigModel());
		assertNotNull(model);
		assertEquals(HsmType.HW, model.getType());
	}

	@Test
	public void updateTest_Empty() {
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		HsmConfigModel model = hsmConfigEditCopySevice.update(getHsmConfigModel());
		assertNull(model);
	}

	@Test
	public void updateStatusTest() {
		List<HsmConfigEditCopyEntity> list = new ArrayList<>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		String updateStatus = hsmConfigEditCopySevice.updateStatus(EditStatus.Submitted, "HSM", "VerifyHsm");
		assertNotNull(updateStatus);
		assertEquals("Submitted", updateStatus);
	}

	@Test
	public void getAllTest() {
		List<HsmConfigEditCopyEntity> list = new ArrayList<>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.getAll()).thenReturn(list);
		List<HsmConfigModel> model = hsmConfigEditCopySevice.getAll();
		assertEquals("Submitted", model.get(0).getStatus());
		assertEquals(HsmType.HW, model.get(0).getType());
	}

	@Test
	public void getAllTest_Empty() {
		when(hsmConfigEditCopyRepository.getAll()).thenReturn(new ArrayList<>());
		List<HsmConfigModel> model = hsmConfigEditCopySevice.getAll();
		assertNull(model);
	}

	@Test
	public void getEntityTest() {
		List<HsmConfigEditCopyEntity> list = new ArrayList<>();
		list.add(getHsmConfigEditCopyEntity());
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(list);
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		HsmConfigEditCopyEntity entity = hsmConfigEditCopySevice.getEntity("HSM");
		assertNotNull(entity);
	}

	@Test
	public void getEntityTest_Empty() {
		when(hsmConfigEditCopyRepository.findByName(Mockito.any())).thenReturn(new ArrayList<>());
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		HsmConfigEditCopyEntity entity = hsmConfigEditCopySevice.getEntity("HSM");
		assertNull(entity);
	}

	@Test
	public void isEditCopyExistsTest() {
		when(hsmConfigEditCopyRepository.isHsmConfigExists(Mockito.any())).thenReturn(true);
		hsmConfigEditCopySevice.isEditCopyExists("HSM");
		assertEquals(true, true);
	}

	@Test
	public void saveTest() {
		when(hsmConfigEditCopyRepository.save(Mockito.any())).thenReturn(getHsmConfigEditCopyEntity());
		hsmConfigEditCopySevice.save(getHsmConfigEditCopyEntity());
	}

	@Test
	public void deleteTest() {
		hsmConfigEditCopySevice.delete(getHsmConfigEditCopyEntity());
	}

	public HsmConfigModel getHsmConfigModel() {
		HsmConfigModel hsmConfigModel = new HsmConfigModel();
		hsmConfigModel.setIp("192.168.37.30");
		hsmConfigModel.setName("ABC");
		hsmConfigModel.setStatus("Active");
		NettyConfig netty = new NettyConfig();
		netty.setConnectTimeout(1500);
		netty.setRequestTimeout(1000L);
		netty.setWorkerCount(5);
		hsmConfigModel.setNettyConfig(netty);
		hsmConfigModel.setEntityId("isg");
		hsmConfigModel.setType(HsmType.HW);
		return hsmConfigModel;
	}

	public HsmConfigEditCopyEntity getHsmConfigEditCopyEntity() {
		HsmConfigEditCopyEntity hsmConfigEditCopyEntity = new HsmConfigEditCopyEntity();
		hsmConfigEditCopyEntity.setIp("192.168.37.25");
		hsmConfigEditCopyEntity.setName("ABC");
		hsmConfigEditCopyEntity.setStatus(EditStatus.Submitted);
		hsmConfigEditCopyEntity.setKeys("1");
		hsmConfigEditCopyEntity.setHsmServices("Service");
		hsmConfigEditCopyEntity.setType(HsmType.HW);
		hsmConfigEditCopyEntity.setNettyParameters("{\"workerCount\":5,\"requestTimeout\":30000,\"connectTimeout\":1000,\"poolMaxActive\":-1,\"poolMaxIdle\":100,\"poolMinEvictableIdle\":300000,\"poolMinIdle\":0}");
		
		return hsmConfigEditCopyEntity;
	}

}
