package com.isg.mw.file.constants;

public interface FileInfoUri {
	
	String PARENT = "/file";
	
	String UPLOAD = "/upload";

}
