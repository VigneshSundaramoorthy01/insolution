package com.isg.mw.file.service;

import org.springframework.web.multipart.MultipartFile;

import com.isg.mw.core.model.constants.DataFileType;

public interface FileUploadService {
	
	 public void save(MultipartFile file, DataFileType fileType);


}