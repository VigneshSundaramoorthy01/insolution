
package com.isg.mw.file.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.isg.mw.core.model.constants.DataFileType;
import com.isg.mw.file.constants.FileInfoUri;
import com.isg.mw.file.service.FileUploadService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "File Upload", description = "Bin and Map File Upload API")
@RestController
@RequestMapping(value = FileInfoUri.PARENT)
public class FileUploadController {
	@Autowired
	private FileUploadService storageService;

	@Operation(summary = "API To Upload Bin and Map File", description = "In response will get message after upload file successfully" ,tags= {"Map Info Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = FileInfoUri.UPLOAD, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<String> uploadFile(@RequestPart("file") MultipartFile file,
			@RequestParam(value = "fileUploadEnum",required = false) DataFileType fileType) {
		String message = "";
		try {
			storageService.save(file, fileType);
			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			return ResponseEntity.status(HttpStatus.OK).body(message);
		} catch (Exception e) {
			message = "Could not upload the file: " + file.getOriginalFilename() + "!";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
		}
	}
}
