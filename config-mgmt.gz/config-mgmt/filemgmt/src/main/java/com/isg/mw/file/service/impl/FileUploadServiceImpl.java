package com.isg.mw.file.service.impl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.isg.mw.core.model.constants.DataFileType;
import com.isg.mw.file.service.FileUploadService;

@Service
public class FileUploadServiceImpl implements FileUploadService {

	private Logger logger = LogManager.getLogger();

	@Value("${resource.bundle.path}")
	private String configLocation;

	@Value("${camel.file.source.bin.location}")
	private String fileDestinationPathForBin;

	@Value("${camel.file.source.location}")
	private String fileDestinationPathForMaps;

	@Override
	public void save(MultipartFile file, DataFileType fileType) {
		logger.info("Config: {}", configLocation);
		String fileDestinationPath = null;
		switch (fileType) {
		case Bin:
			fileDestinationPath = fileDestinationPathForBin;
			break;
		case Maps:
			fileDestinationPath = fileDestinationPathForMaps;
			break;
		}
		logger.info("filePath: {}", fileDestinationPath);
		try {
			Path root = Paths.get(configLocation + fileDestinationPath.replaceFirst("/", ""));
			long bytes = Files.copy(file.getInputStream(), root.resolve(file.getOriginalFilename()));
			logger.info("No of bytes written: {}, {}", bytes, root.toAbsolutePath());
		} catch (Exception e) {
			throw new RuntimeException("Could not store the file. Error: " + e.getMessage());
		}
	}

}