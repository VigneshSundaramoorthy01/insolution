package com.isg.mw.sr.mgmt.constants;

public enum DemoSrTxnType {
    SUCCESS_RATIO_STATIC,

    SUCCESS_RATIO_DYNAMIC,

    LEAST_COST;


    public static DemoSrTxnType getSrTxnType(String name) {
        for (DemoSrTxnType type : DemoSrTxnType.values()) {
            if(type.name().equals(name)){
                return type;
            }
        }
        return null;
    }
}
