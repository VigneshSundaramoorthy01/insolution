package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.sr.TargetPaymentModeOptionsAdditionalData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import java.time.OffsetDateTime;

@ApiModel(description = "${swgr.sr.model.add}}")
@Getter
@Setter
public class AddTargetPaymentModeOptionsModel {

    @ApiModelProperty(required = true, value = "${swgr.sr.model.add.targetPaymentModeId.value}")
    private Long targetPaymentModeId;

    @ApiModelProperty(required = true, value = "${swgr.sr.model.add.paymentModeOptionId.value}")
    private Long paymentModeOptionId;

    @ApiModelProperty(required = true, value = "${swgr.sr.model.add.startDate.value}")
    private String startDate;

    @ApiModelProperty(required = true, value = "${swgr.sr.model.add.endDate.value}")
    private String endDate;

    @ApiModelProperty(required = true, value = "additionalData")
    private TargetPaymentModeOptionsAdditionalData additionalData;

}
