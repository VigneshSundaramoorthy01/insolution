package com.isg.mw.sr.mgmt.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.sr.TargetLCRConfigMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.TargetLCRConfigSerializer;
import com.isg.mw.sr.mgmt.service.TargetLCRConfigMessenger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 
 * @author shital3986
 *
 */
@Service("targetLCRConfigMessenger")
public class TargetLCRConfigMessengerImpl implements TargetLCRConfigMessenger, InitializingBean, DisposableBean {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private IsgKafkaConfigs isgKafkaConfigs;

	@Autowired
	private KafkaTopics kafkaTopics;

	private KafkaProducer producer;

	public TargetLCRConfigMessengerImpl() {
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getTargetLCRConfigTopicName(), TargetLCRConfigSerializer.class));
		producer.init();
	}

	@Override
	public void send(TargetLCRConfigMessage model) {
		setTraceIdForAllModels(model);
		LOG.info("Sending TargetLCRConfigModel on kafka with input targetId : " + model.getModel().getTargetId() + " , paymentModeId : " + model.getModel().getPaymentModeId() + " , paymentModeOptionId : " + model.getModel().getPaymentModeOptionId() +" and action : "+model.getAction() );
		producer.sendMessage(model);
	}

	private void setTraceIdForAllModels(TargetLCRConfigMessage model) {
		String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
		model.setAcpTraceId(acpTraceId);
	}
}
