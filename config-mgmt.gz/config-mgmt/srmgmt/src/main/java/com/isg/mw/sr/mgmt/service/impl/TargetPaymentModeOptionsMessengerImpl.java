package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.TargetPaymentModeOptionsSerializer;
import com.isg.mw.sr.mgmt.service.TargetPaymentModeOptionsMessenger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("tpmoMessenger")
public class TargetPaymentModeOptionsMessengerImpl implements TargetPaymentModeOptionsMessenger, InitializingBean, DisposableBean {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public TargetPaymentModeOptionsMessengerImpl(){

    }
    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getTargetPaymentModeOptionsTopicName(), TargetPaymentModeOptionsSerializer.class));
        producer.init();
    }

    @Override
    public void send(TargetPaymentModeOptionsMessage model) {
        setTraceIdForAllModels(model);
        LOG.info("Sending TargetPaymentModeOptionsModel on kafka with input targetPaymentModeId : " + model.getModel().getTargetPaymentModeId() + " , paymentModeId : " + model.getModel().getPaymentModeOptionId() +" and action : "+model.getAction());
        producer.sendMessage(model);
    }

    private void setTraceIdForAllModels(TargetPaymentModeOptionsMessage model) {
        String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
        model.setAcpTraceId(acpTraceId);
    }

}
