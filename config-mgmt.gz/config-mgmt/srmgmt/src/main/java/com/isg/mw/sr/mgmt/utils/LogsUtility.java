package com.isg.mw.sr.mgmt.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class LogsUtility {


    private static final Logger LOG = LogManager.getLogger(com.isg.mw.sr.mgmt.utils.LogsUtility.class);

    public static final boolean POST_FIX = false;

    public static final boolean PRE_FIX = true;

    private LogsUtility() {
    }

    public static OffsetDateTime trimDate(String input) {
        OffsetDateTime output = null;
        if(input != null && !input.equals("")) {
            try {
                return OffsetDateTime.parse(input.trim(), DateTimeFormatter.ISO_DATE_TIME);
            }
            catch(Exception ex) {
                LOG.trace(ex.getMessage(), ex);
            }
        }
        return output;
    }

}
