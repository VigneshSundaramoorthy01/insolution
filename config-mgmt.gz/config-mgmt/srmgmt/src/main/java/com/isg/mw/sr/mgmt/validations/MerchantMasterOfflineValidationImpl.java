package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.MerchantMasterFieldInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.springframework.stereotype.Service;

@Service("MerchantMasterOfflineValidation")
public class MerchantMasterOfflineValidationImpl implements MerchantMasterOfflineValidation{

    @Override
    public void addValidation(MerchantMasterModel model) {
        UserDataValidations.stringDataValidation(model.getMid(), MerchantMasterFieldInfo.MID_EX, MerchantMasterFieldInfo.MID_FN, true,MerchantMasterFieldInfo.MID_FL);
        UserDataValidations.stringDataValidation(model.getMerchantName(),MerchantMasterFieldInfo.MERCHANT_NAME_EX,MerchantMasterFieldInfo.MERCHANT_NAME_FN,false,MerchantMasterFieldInfo.MERCHANT_NAME_FL);
        UserDataValidations.stringDataValidation(model.getMerchantEmail(),MerchantMasterFieldInfo.MERCHANT_EMAIL_EX,MerchantMasterFieldInfo.MERCHANT_EMAIL_EX,false,MerchantMasterFieldInfo.MERCHANT_EMAIL_FL);
        UserDataValidations.stringDataValidation(model.getMerchantMobNo(),MerchantMasterFieldInfo.MERCHANT_MOB_NO_EX,MerchantMasterFieldInfo.MERCHANT_MOB_NO_FN,false,MerchantMasterFieldInfo.MERCHANT_MOB_NO_FL);
        UserDataValidations.stringDataValidation(model.getMerchantAddress(),MerchantMasterFieldInfo.MERCHANT_ADDRESS_EX,MerchantMasterFieldInfo.MERCHANT_ADDRESS_FN,false,MerchantMasterFieldInfo.MERCHANT_ADDRESS_FL);
        UserDataValidations.longDataValidations(model.getMerchantPincode(),MerchantMasterFieldInfo.MERCHANT_PINCODE_FN,MerchantMasterFieldInfo.MERCHANT_PINCODE_FL,false);
        UserDataValidations.stringDataValidation(model.getEntityId(),MerchantMasterFieldInfo.ENTITY_ID_EX,MerchantMasterFieldInfo.ENTITY_ID_FN,true,MerchantMasterFieldInfo.ENTITY_ID_FL);
        UserDataValidations.stringDataValidation(model.getMcrEnabled(),MerchantMasterFieldInfo.MCR_ENABLED_EX,MerchantMasterFieldInfo.MCR_ENABLED_FN,false,MerchantMasterFieldInfo.MCR_ENABLED_FL);
        UserDataValidations.longDataValidations(model.getMcrDefaultTargetId(), MerchantMasterFieldInfo.MCR_DEFAULT_TARGET_ID_FN,MerchantMasterFieldInfo.MCR_DEFAULT_TARGET_FL, false);
        UserDataValidations.stringDataValidation(model.getSecretKey(),MerchantMasterFieldInfo.SECRET_KEY_EX,MerchantMasterFieldInfo.SECRET_KEY_FN,false,MerchantMasterFieldInfo.SECRET_KEY_FL);
        UserDataValidations.stringDataValidation(model.getEncryptionKey(),MerchantMasterFieldInfo.ENCRYPTION_KEY_EX,MerchantMasterFieldInfo.ENCRYPTION_KEY_FN,false,MerchantMasterFieldInfo.ENCRYPTION_KEY_FL);
        UserDataValidations.stringPreDefiendDataValidation(model.getConvFeeFlag().name(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.CONV_FEE_FLAG_FN,false);
        UserDataValidations.stringPreDefiendDataValidation(model.getStatus().name(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.STATUS_FN,false);
        UserDataValidations.stringDataValidation(model.getMerchantVpa(),MerchantMasterFieldInfo.MERCHANT_VPA_EX,MerchantMasterFieldInfo.MERCHANT_VPA_FN,false,MerchantMasterFieldInfo.MERCHANT_VPA_FL);
        UserDataValidations.stringDataValidation(model.getMerchantStoreId(),MerchantMasterFieldInfo.MERCHANT_STORE_ID_EX,MerchantMasterFieldInfo.MERCHANT_STORE_ID_FN,false,MerchantMasterFieldInfo.MERCHANT_STORE_ID_FL);
        UserDataValidations.stringDataValidation(model.getAccountNo(),MerchantMasterFieldInfo.ACCOUNT_NO_EX,MerchantMasterFieldInfo.ACCOUNT_NO_FN,false,MerchantMasterFieldInfo.ACCOUNT_NO_FL);
        UserDataValidations.stringDataValidation(model.getOwnershipType(),MerchantMasterFieldInfo.OWNERSHIP_TYPE_EX,MerchantMasterFieldInfo.OWNERSHIP_TYPE_FN,false,MerchantMasterFieldInfo.OWNERSHIP_TYPE_FL);
        UserDataValidations.stringDataValidation(model.getMerchantClass(),MerchantMasterFieldInfo.MERCHANT_CLASS_EX,MerchantMasterFieldInfo.MERCHANT_CLASS_FN,false,MerchantMasterFieldInfo.MERCHANT_CLASS_FL);
        UserDataValidations.stringDataValidation(model.getAccessCode(),MerchantMasterFieldInfo.ACCESS_CODE_EX,MerchantMasterFieldInfo.ACCESS_CODE_FN,false,MerchantMasterFieldInfo.ACCESS_CODE_FL);

        // Added validations for missing fields in merchant master model
        UserDataValidations.stringDataValidation(model.getGstNumber() , MerchantMasterFieldInfo.GST_EX, MerchantMasterFieldInfo.GST_NO_FN, MerchantMasterFieldInfo.GST_NO_MA, MerchantMasterFieldInfo.GST_NO_FL);
        UserDataValidations.stringDataValidation(model.getWebsiteURL() , MerchantMasterFieldInfo.WEBSITE_URL_EX, MerchantMasterFieldInfo.WEBSITE_URL_NO_FN, MerchantMasterFieldInfo.WEBSITE_URL_NO_MA, MerchantMasterFieldInfo.WEBSITE_URL_NO_FL);
        UserDataValidations.stringDataValidation(model.getContactPerson() , MerchantMasterFieldInfo.CONTACT_PERSON_EX, MerchantMasterFieldInfo.CONTACT_PERSON_FN, MerchantMasterFieldInfo.CONTACT_PERSON_MA, MerchantMasterFieldInfo.CONTACT_PERSON_FL);
        UserDataValidations.stringDataValidation(model.getPanNumber() , MerchantMasterFieldInfo.PAN_NUMBER_EX, MerchantMasterFieldInfo.PAN_NUMBER_FN, MerchantMasterFieldInfo.PAN_NUMBER_MA, MerchantMasterFieldInfo.PAN_NUMBER_FL);
        UserDataValidations.stringDataValidation(model.getBusinessType() , MerchantMasterFieldInfo.BUSINESS_TYPE_EX, MerchantMasterFieldInfo.BUSINESS_TYPE_FN, MerchantMasterFieldInfo.BUSINESS_TYPE_MA, MerchantMasterFieldInfo.BUSINESS_TYPE_FL);
        UserDataValidations.stringDataValidation(model.getMerchantURL() , MerchantMasterFieldInfo.MERCHANT_URL_EX, MerchantMasterFieldInfo.MERCHANT_URL_FN, MerchantMasterFieldInfo.MERCHANT_URL_MA, MerchantMasterFieldInfo.MERCHANT_URL_FL);
        UserDataValidations.stringDataValidation(model.getTerminalType() , MerchantMasterFieldInfo.TERMINAL_TYPE_EX, MerchantMasterFieldInfo.TERMINAL_TYPE_FN, MerchantMasterFieldInfo.TERMINAL_TYPE_MA, MerchantMasterFieldInfo.TERMINAL_TYPE_FL);
    }

    @Override
    public void modifyValidation(MerchantMasterModel model) {
        UserDataValidations.stringDataValidation(model.getMid(), MerchantMasterFieldInfo.MID_EX, MerchantMasterFieldInfo.MID_FN, true,MerchantMasterFieldInfo.MID_FL);
        UserDataValidations.stringDataValidation(model.getMerchantName(),MerchantMasterFieldInfo.MERCHANT_NAME_EX,MerchantMasterFieldInfo.MERCHANT_NAME_FN,false,MerchantMasterFieldInfo.MERCHANT_NAME_FL);
        UserDataValidations.stringDataValidation(model.getMerchantEmail(),MerchantMasterFieldInfo.MERCHANT_EMAIL_EX,MerchantMasterFieldInfo.MERCHANT_EMAIL_EX,false,MerchantMasterFieldInfo.MERCHANT_EMAIL_FL);
        UserDataValidations.stringDataValidation(model.getMerchantMobNo(),MerchantMasterFieldInfo.MERCHANT_MOB_NO_EX,MerchantMasterFieldInfo.MERCHANT_MOB_NO_FN,false,MerchantMasterFieldInfo.MERCHANT_MOB_NO_FL);
        UserDataValidations.stringDataValidation(model.getMerchantAddress(),MerchantMasterFieldInfo.MERCHANT_ADDRESS_EX,MerchantMasterFieldInfo.MERCHANT_ADDRESS_FN,false,MerchantMasterFieldInfo.MERCHANT_ADDRESS_FL);
        UserDataValidations.longDataValidations(model.getMerchantPincode(),MerchantMasterFieldInfo.MERCHANT_PINCODE_FN,MerchantMasterFieldInfo.MERCHANT_PINCODE_FL,false);
        UserDataValidations.stringDataValidation(model.getEntityId(),MerchantMasterFieldInfo.ENTITY_ID_EX,MerchantMasterFieldInfo.ENTITY_ID_FN,true,MerchantMasterFieldInfo.ENTITY_ID_FL);
        UserDataValidations.stringDataValidation(model.getMcrEnabled(),MerchantMasterFieldInfo.MCR_ENABLED_EX,MerchantMasterFieldInfo.MCR_ENABLED_FN,false,MerchantMasterFieldInfo.MCR_ENABLED_FL);
        UserDataValidations.longDataValidations(model.getMcrDefaultTargetId(), MerchantMasterFieldInfo.MCR_DEFAULT_TARGET_ID_FN,MerchantMasterFieldInfo.MCR_DEFAULT_TARGET_FL, false);
        UserDataValidations.stringDataValidation(model.getSecretKey(),MerchantMasterFieldInfo.SECRET_KEY_EX,MerchantMasterFieldInfo.SECRET_KEY_FN,false,MerchantMasterFieldInfo.SECRET_KEY_FL);
        UserDataValidations.stringDataValidation(model.getEncryptionKey(),MerchantMasterFieldInfo.ENCRYPTION_KEY_EX,MerchantMasterFieldInfo.ENCRYPTION_KEY_FN,false,MerchantMasterFieldInfo.ENCRYPTION_KEY_FL);
        UserDataValidations.stringPreDefiendDataValidation(model.getConvFeeFlag().name(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.CONV_FEE_FLAG_FN,false);
        UserDataValidations.stringPreDefiendDataValidation(model.getStatus().name(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.STATUS_FN,false);
        UserDataValidations.stringDataValidation(model.getMerchantVpa(),MerchantMasterFieldInfo.MERCHANT_VPA_EX,MerchantMasterFieldInfo.MERCHANT_VPA_FN,false,MerchantMasterFieldInfo.MERCHANT_VPA_FL);
        UserDataValidations.stringDataValidation(model.getMerchantStoreId(),MerchantMasterFieldInfo.MERCHANT_STORE_ID_EX,MerchantMasterFieldInfo.MERCHANT_STORE_ID_FN,false,MerchantMasterFieldInfo.MERCHANT_STORE_ID_FL);
        UserDataValidations.stringDataValidation(model.getAccountNo(),MerchantMasterFieldInfo.ACCOUNT_NO_EX,MerchantMasterFieldInfo.ACCOUNT_NO_FN,false,MerchantMasterFieldInfo.ACCOUNT_NO_FL);
        UserDataValidations.stringDataValidation(model.getOwnershipType(),MerchantMasterFieldInfo.OWNERSHIP_TYPE_EX,MerchantMasterFieldInfo.OWNERSHIP_TYPE_FN,false,MerchantMasterFieldInfo.OWNERSHIP_TYPE_FL);
        UserDataValidations.stringDataValidation(model.getMerchantClass(),MerchantMasterFieldInfo.MERCHANT_CLASS_EX,MerchantMasterFieldInfo.MERCHANT_CLASS_FN,false,MerchantMasterFieldInfo.MERCHANT_CLASS_FL);
        UserDataValidations.stringDataValidation(model.getAccessCode(),MerchantMasterFieldInfo.ACCESS_CODE_EX,MerchantMasterFieldInfo.ACCESS_CODE_FN,false,MerchantMasterFieldInfo.ACCESS_CODE_FL);

        // Added validations for missing fields in merchant master model
        UserDataValidations.stringDataValidation(model.getGstNumber() , MerchantMasterFieldInfo.GST_EX, MerchantMasterFieldInfo.GST_NO_FN, MerchantMasterFieldInfo.GST_NO_MA, MerchantMasterFieldInfo.GST_NO_FL);
        UserDataValidations.stringDataValidation(model.getWebsiteURL() , MerchantMasterFieldInfo.WEBSITE_URL_EX, MerchantMasterFieldInfo.WEBSITE_URL_NO_FN, MerchantMasterFieldInfo.WEBSITE_URL_NO_MA, MerchantMasterFieldInfo.WEBSITE_URL_NO_FL);
        UserDataValidations.stringDataValidation(model.getContactPerson() , MerchantMasterFieldInfo.CONTACT_PERSON_EX, MerchantMasterFieldInfo.CONTACT_PERSON_FN, MerchantMasterFieldInfo.CONTACT_PERSON_MA, MerchantMasterFieldInfo.CONTACT_PERSON_FL);
        UserDataValidations.stringDataValidation(model.getPanNumber() , MerchantMasterFieldInfo.PAN_NUMBER_EX, MerchantMasterFieldInfo.PAN_NUMBER_FN, MerchantMasterFieldInfo.PAN_NUMBER_MA, MerchantMasterFieldInfo.PAN_NUMBER_FL);
        UserDataValidations.stringDataValidation(model.getBusinessType() , MerchantMasterFieldInfo.BUSINESS_TYPE_EX, MerchantMasterFieldInfo.BUSINESS_TYPE_FN, MerchantMasterFieldInfo.BUSINESS_TYPE_MA, MerchantMasterFieldInfo.BUSINESS_TYPE_FL);
        UserDataValidations.stringDataValidation(model.getMerchantURL() , MerchantMasterFieldInfo.MERCHANT_URL_EX, MerchantMasterFieldInfo.MERCHANT_URL_FN, MerchantMasterFieldInfo.MERCHANT_URL_MA, MerchantMasterFieldInfo.MERCHANT_URL_FL);
        UserDataValidations.stringDataValidation(model.getTerminalType() , MerchantMasterFieldInfo.TERMINAL_TYPE_EX, MerchantMasterFieldInfo.TERMINAL_TYPE_FN, MerchantMasterFieldInfo.TERMINAL_TYPE_MA, MerchantMasterFieldInfo.TERMINAL_TYPE_FL);
    }

    @Override
    public void getValidations(String mid) {
        if (mid == null) {
            throw new ValidationException("Merchant Master field mid is mandatory", MerchantMasterFieldInfo.MID_FN);
        }
    }
}
