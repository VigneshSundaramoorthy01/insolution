package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.MerchantPaymentModesMessage;

public interface MerchantPaymentModesMessenger {

    void send(MerchantPaymentModesMessage model);

}
