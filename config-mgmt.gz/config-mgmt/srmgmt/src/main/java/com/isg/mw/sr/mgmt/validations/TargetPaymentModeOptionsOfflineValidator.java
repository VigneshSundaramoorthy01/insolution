package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;

public interface TargetPaymentModeOptionsOfflineValidator {

    void getValidations(Long targetPaymentModeId,Long paymentModeOptionId);

    void addValidation(TargetPaymentModeOptionsModel model);

    void modifyValidation(TargetPaymentModeOptionsModel model);

    void submitValidation(Long targetPaymentModeId,Long paymentModeOptionId);

    void updateStatusValidation(Long targetPaymentModeId,Long paymentModeOptionId, String status);

    void verifyValidation(Long targetPaymentModeId,Long paymentModeOptionId,boolean approved,String remarks);

    void getByTargetIdValidation(Long targetPayModeOptionId);

    void targetPayModeByStatusValidation(String status);
}
