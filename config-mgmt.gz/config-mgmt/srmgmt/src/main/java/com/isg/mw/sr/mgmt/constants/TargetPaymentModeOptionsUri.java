package com.isg.mw.sr.mgmt.constants;

public interface TargetPaymentModeOptionsUri {

    /**
     * Used for parent URI
     */
    String PARENT = "/tpmo";

    /**
     * Used for get API URI
     */
    String GET_BY_ID = "/getTPMO";

    /**
     * Used for getAll API URI
     */
    String GET_ALL_ACTIVE = "/getallactiveTPMO";

    /**
     * Used for getAll API URI
     */
    String GET_ALL = "/getall";

    /**
     * Used for add API URI
     */
    String ADD = "/addTPMO";

    /**
     * Used for submit API URI
     */
    String SUBMIT = "/submitTPMO";

    /**
     * Used for save API URI
     */
    String MODIFY = "/saveTPMO";

    /**
     * Used for verify API URI
     */
    String VERIFY = "/verifyTPMO";

    /**
     * Used for update API URI
     */
    String UPDATE_STATUS = "/updateTPMO";

    /**
     * Used for lock API URI
     */
    String LOCK = "/lock";

    /**
     * Used for lock API URI
     */
    String GET_BY_TARGET_OPTIONS_ID = "/getByTargetOptionsId";

    String GET_TARGET_PAYMENT_MODES_OPTIONS_BY_ID="/getTargetPaymentModeOptionsById";
}
