package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.MerchantTargetPreferencesModel;
import com.isg.mw.sr.mgmt.model.AddMerchantTargetPreferencesModel;
import com.isg.mw.sr.mgmt.model.ModifyMerchantTargetPreferencesModel;

public class MerchantTargetPreferencesMgmtUtility {
    public static MerchantTargetPreferencesModel getMerchantTargetPreferencesModel(AddMerchantTargetPreferencesModel addModel) {
        MerchantTargetPreferencesModel model = new MerchantTargetPreferencesModel();
        model.setMerchantMasterId(addModel.getMerchantMasterId());
        model.setTargetId(addModel.getTargetId());
        model.setPaymentModeId(addModel.getPaymentModeId());
        model.setMid(addModel.getMid());
        model.setStatus(ActiveInactiveFlag.valueOf(addModel.getStatus().name()));
        model.setStartDate(addModel.getStartDate());
        model.setEndDate(addModel.getEndDate());
        return model;
    }

    public static MerchantTargetPreferencesModel getMerchantTargetPreferencesModifyModel(ModifyMerchantTargetPreferencesModel modifyModel) {
        MerchantTargetPreferencesModel model = new MerchantTargetPreferencesModel();
        model.setMerchantMasterId(modifyModel.getMerchantMasterId());
        model.setMerchantMasterId(modifyModel.getMerchantMasterId());
        model.setTargetId(modifyModel.getTargetId());
        model.setPaymentModeId(modifyModel.getPaymentModeId());
        model.setMid(modifyModel.getMid());
        model.setStatus(ActiveInactiveFlag.valueOf(modifyModel.getStatus().name()));
        model.setStartDate(modifyModel.getStartDate());
        model.setEndDate(modifyModel.getEndDate());
        return model;
    }
}
