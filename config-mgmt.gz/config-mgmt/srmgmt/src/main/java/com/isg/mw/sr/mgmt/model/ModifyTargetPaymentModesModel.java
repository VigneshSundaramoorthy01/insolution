package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.sr.TargetPaymentModesAdditionalData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@ApiModel(description = "${swgr.sr.modify.add}}")
@Getter
@Setter
public class ModifyTargetPaymentModesModel {

    @ApiModelProperty(required = true, value = "targetId")
    private Long targetId;

    @ApiModelProperty(required = true, value = "paymentModeId")
    private Long paymentModeId;

    @ApiModelProperty(required = true, value = "startDate",example = "2022-10-12T10:15:30+05:30")
    private String startDate;

    @ApiModelProperty(required = true, value = "endDate",example = "2022-10-12T10:15:30+05:30")
    private String endDate;

    @ApiModelProperty(required = true, value = "integrationType")
    private String integrationType;

    @ApiModelProperty(required = true, value = "entityId")
    private String entityId;

    @ApiModelProperty(required = true, value = "additionalData")
    private TargetPaymentModesAdditionalData additionalData;
}
