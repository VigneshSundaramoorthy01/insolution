package com.isg.mw.sr.mgmt.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetPaymentModesMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.TargetLCRConfigSerializer;
import com.isg.mw.sr.mgmt.serializer.TargetPaymentModeSerializer;
import com.isg.mw.sr.mgmt.service.TargetPaymentModesMessenger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("tpmMessenger")
public class TargetPaymentModesMessengerImpl implements TargetPaymentModesMessenger, InitializingBean, DisposableBean {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public TargetPaymentModesMessengerImpl(){

    }
    @Override
    public void destroy() throws Exception {
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getTargetPaymentModesTopicName(), TargetPaymentModeSerializer.class));
        producer.init();
    }

    @Override
    public void send(TargetPaymentModesMessage model) {
        setTraceIdForAllModels(model);
        LOG.trace("Sending TargetPaymentModesModel on kafka having targetId : " + model.getModel().getTargetId() + " , paymentModeId : " +  model.getModel().getPaymentModeId() + " , integrationType : "+ model.getModel().getIntegrationType()+"and action: "+model.getAction());
        producer.sendMessage(model);
    }

    private void setTraceIdForAllModels(TargetPaymentModesMessage model) {
        String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
        model.setAcpTraceId(acpTraceId);
    }

    private byte[] getObjectData(Object obj) {

        byte[] data = null;
        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        try {
            data = objectMapper.writeValueAsBytes(obj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return data;

    }

}
