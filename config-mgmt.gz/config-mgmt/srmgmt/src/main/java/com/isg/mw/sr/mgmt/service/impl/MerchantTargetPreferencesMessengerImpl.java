package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.sr.MerchantTargetPreferencesMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.MerchantTargetPreferencesSerializer;
import com.isg.mw.sr.mgmt.service.MerchantTargetPreferencesMessenger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("merchantTargetPreferencesMessenger")
public class MerchantTargetPreferencesMessengerImpl  implements MerchantTargetPreferencesMessenger, InitializingBean, DisposableBean {

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public MerchantTargetPreferencesMessengerImpl() {
    }

    @Override
    public void send(MerchantTargetPreferencesMessage model) {
        producer.sendMessage(model);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getMerchantTargetPreferenceTopicName(), MerchantTargetPreferencesSerializer.class));
        producer.init();
    }
}
