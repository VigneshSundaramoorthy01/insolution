package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.SmartRouteConfigMessage;

/**
 * 
 * @author shital3986
 *
 */
public interface SrMessenger {

	void send(SmartRouteConfigMessage model);
}
