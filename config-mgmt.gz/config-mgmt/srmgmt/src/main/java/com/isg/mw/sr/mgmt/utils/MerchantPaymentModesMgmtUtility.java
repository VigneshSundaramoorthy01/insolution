package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.sr.MerchantPaymentModesModel;
import com.isg.mw.sr.mgmt.model.AddMerchantPaymentModesModel;
import com.isg.mw.sr.mgmt.model.ModifyMerchantPaymentModesModel;

public class MerchantPaymentModesMgmtUtility {

    private MerchantPaymentModesMgmtUtility() {

    }
    public static MerchantPaymentModesModel getMerchantPaymentModesMgmtUtility(AddMerchantPaymentModesModel addModel) {

        MerchantPaymentModesModel model = new MerchantPaymentModesModel();
        model.setMerchantMasterId(addModel.getMerchantMasterId());
        model.setPaymentModeId(addModel.getPaymentModeId());
        model.setStartDate(addModel.getStartDate());
        model.setEndDate(addModel.getEndDate());
        model.setEntityId(addModel.getEntityId());
        return model;
    }

    public static MerchantPaymentModesModel getMerchantPaymentModesModifyModel(ModifyMerchantPaymentModesModel modifyModel) {

        MerchantPaymentModesModel model = new MerchantPaymentModesModel();
        model.setMerchantMasterId(modifyModel.getMerchantMasterId());
        model.setPaymentModeId(modifyModel.getPaymentModeId());
        model.setStartDate(modifyModel.getStartDate());
        model.setEndDate(modifyModel.getEndDate());
        model.setEntityId(modifyModel.getEntityId());
        return model;
    }
}
