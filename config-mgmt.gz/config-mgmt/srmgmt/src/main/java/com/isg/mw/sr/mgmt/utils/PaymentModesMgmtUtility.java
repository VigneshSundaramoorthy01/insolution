package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.sr.mgmt.model.AddPaymentModesModel;
import com.isg.mw.sr.mgmt.model.ModifyPaymentModesModel;

public class PaymentModesMgmtUtility {

    private PaymentModesMgmtUtility() {

    }
    public static PaymentModesModel getPaymentModesModel(AddPaymentModesModel addModel) {
        PaymentModesModel model = new PaymentModesModel();
        model.setPaymentModeName(addModel.getPaymentModeName());
        model.setPaymentModeDesc(addModel.getPaymentModeDesc());
        return model;
    }

    public static PaymentModesModel getPaymentModesModifyModel(ModifyPaymentModesModel modifyModel) {
        PaymentModesModel model = new PaymentModesModel();
        model.setPaymentModeId(modifyModel.getPaymentModeId());
        model.setPaymentModeName(modifyModel.getPaymentModeName());
        model.setPaymentModeDesc(modifyModel.getPaymentModeDesc());
        return model;
    }

}
