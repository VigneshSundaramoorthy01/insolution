package com.isg.mw.sr.mgmt.scheduler;

import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.maps.dao.service.MapsInfoService;
import com.isg.mw.maps.dao.utils.MapsInfoUtility;
import com.isg.mw.sr.dao.entities.MerchantMasterEntity;
import com.isg.mw.sr.dao.service.MerchantMasterService;
import com.isg.mw.sr.dao.service.TargetMerchantMasterService;
import com.isg.mw.sr.dao.utils.MerchantMasterUtility;
import com.isg.mw.sr.mgmt.service.MerchantMasterMessenger;
import com.isg.mw.sr.mgmt.service.MerchantMasterOnboardMessenger;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class FailedTargetMerchantMasterSchedulerJob implements Runnable {
    private Logger logger = LogManager.getLogger();

    @Setter
    private TargetMerchantMasterService targetMerchantMasterService;

    @Setter
    private MerchantMasterService merchantMasterService;

    @Setter
    private MapsInfoService mapsInfoService;

    @Setter
    private TargetConfigMasterService targetConfigMasterService;

    @Autowired
    private TargetMerchantMasterScheduler schedular;

    @Autowired
    private MerchantMasterOnboardMessenger merchantMasterOnboardMessenger;

    public FailedTargetMerchantMasterSchedulerJob() {
    }

    @Override
    public void run() {
        logger.info("Start Scheduler to fetch records for failed status : ");
        List<TargetMerchantMasterModel> tgtMerchantMasterModels = targetMerchantMasterService.findByStatus(ActiveInactiveFlag.Failed);
        if (tgtMerchantMasterModels != null && !tgtMerchantMasterModels.isEmpty()) {
            tgtMerchantMasterModels = tgtMerchantMasterModels.stream().filter(tmm -> !tmm.getRetryCount().equals(3)).collect(Collectors.toList());
            logger.info("Fetching Target Merchant Master For Failed Status: {} ", tgtMerchantMasterModels.size());
            List<MerchantMasterModel> merchantMasterModels = new ArrayList<>();
            if (!tgtMerchantMasterModels.isEmpty() && tgtMerchantMasterModels != null) {
                for (TargetMerchantMasterModel model : tgtMerchantMasterModels) {
                    MerchantMasterEntity merchantMaster = merchantMasterService.getByMid(model.getMid());
                    MapsInfoModel mapsInfoModel = MapsInfoUtility.getMapsInfoModel(mapsInfoService.get(merchantMaster.getEntityId(), model.getMid(), model.getTid()));
                    TargetConfigModel targetConfigModel = targetConfigMasterService.findById(model.getTargetId());
                    Integer retryCount = model.getRetryCount();
                    if (retryCount != null && retryCount < 3) {
                        merchantMasterModels = updateRetryFlagAndRetryOnboarding(merchantMasterModels, model, merchantMaster, mapsInfoModel, targetConfigModel, retryCount);
                    }
                }
                sendMerchantMasterModelToKafka(merchantMasterModels);
            }
        }
    }

    private List<MerchantMasterModel> updateRetryFlagAndRetryOnboarding(List<MerchantMasterModel> merchantMasterModels, TargetMerchantMasterModel model, MerchantMasterEntity merchantMaster,
                                                   MapsInfoModel mapsInfoModel, TargetConfigModel targetConfigModel, Integer retryCount) {
        List<TargetType> targetType =new ArrayList<>();
        targetType.add(targetConfigModel.getTargetType());
        merchantMaster.setTid(mapsInfoModel.getTid());
        MerchantMasterModel merchantMasterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMaster);
        merchantMasterModel.setTargetTypes(targetType);
        merchantMasterModel.setIsOnboardEnable(true);
        model.setRetryCount(retryCount +1);
        TargetMerchantMasterModel updateRetryCount = targetMerchantMasterService.updateRetryCount(model);
        if(updateRetryCount != null){
            merchantMasterModels.add(merchantMasterModel);
        }
        return merchantMasterModels;
    }

    private void sendMerchantMasterModelToKafka(List<MerchantMasterModel> merchantMasterModels) {
        for (MerchantMasterModel merchantMasterModel : merchantMasterModels) {
            logger.info("Sending Merchant Master For Pending Status On Kafka : {}", merchantMasterModel);
            merchantMasterOnboardMessenger.sendMerchantMasterForOnboardReq(merchantMasterModel);
            logger.info("Send Merchant Master For Pending Status On Kafka successfully : {}", merchantMasterModel);
        }
    }
}
