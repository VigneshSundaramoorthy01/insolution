package com.isg.mw.sr.mgmt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@ApiModel(description = "${swgr.targetlcr.modify.add}}")
@Getter
@Setter
public class ModifyTargetLCRConfigModel {

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.targetId.value}")
    private Long targetId;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.paymentModeId.value}")
    private Long paymentModeId;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.cardType.value}")
    private String cardType;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.mccCategory.value}")
    private String mccCategory;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.pricePct.value}")
    private Double pricePct;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.priceFixed.value}")
    private Double priceFixed;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.below2000PricePct.value}")
    private Double below2000PricePct;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.below2000PriceFixed.value}")
    private Double below2000PriceFixed;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.paymentModeOptionId.value}")
    private Long paymentModeOptionId;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.status.value}")
    private String startDate;

    @ApiModelProperty(required = true, value = "${swgr.targetlcr.model.add.status.value}")
    private String endDate;

    @ApiModelProperty(required = true, value = "entityId")
    private String entityId;
}

