package com.isg.mw.sr.mgmt.service.impl;


import com.isg.mw.core.model.constants.MessageConstant;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.CmLookupCodeValuesModel;
import com.isg.mw.core.model.sr.CmLookupCodesModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.dao.service.CmLookupCodeValuesOnlineValidator;
import com.isg.mw.sr.dao.service.CmLookupCodeValuesService;
import com.isg.mw.sr.dao.service.CmLookupCodesOnlineValidator;
import com.isg.mw.sr.dao.service.CmLookupCodesService;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodesConfigModel;
import com.isg.mw.sr.mgmt.service.CmLookupCodesMgmtService;
import com.isg.mw.sr.mgmt.utils.CmLookupCodeValuesMgmtUtility;
import com.isg.mw.sr.mgmt.utils.CmLookupCodesMgmtUtility;
import com.isg.mw.sr.mgmt.validations.CmLookupCodeValuesOfflineValidation;
import com.isg.mw.sr.mgmt.validations.CmLookupCodesOfflineValidation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("CmLookupCodesMgmtService")
public class CmLookupCodesMgmtServiceImpl implements CmLookupCodesMgmtService {
    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private CmLookupCodesOfflineValidation cmLookupCodesOfflineValidation;

    @Autowired
    private CmLookupCodeValuesOfflineValidation cmLookupCodeValuesOfflineValidation;


    @Autowired
    private CmLookupCodesOnlineValidator cmLookupCodesOnlineValidator;

    @Autowired
    private CmLookupCodesService cmLookupCodesService;

    @Autowired
    private CmLookupCodeValuesOnlineValidator cmLookupCodeValuesOnlineValidator;

    @Autowired
    private CmLookupCodeValuesService cmLookupCodeValuesService;

    @Override
    public ResponseEntity<?> add(AddCmLookupCodesConfigModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            CmLookupCodesModel lookupmodel = CmLookupCodesMgmtUtility.getCmLookupCodeModel(addModel);
            cmLookupCodesOfflineValidation.addValidation(lookupmodel);
            cmLookupCodesOnlineValidator.addValidation(lookupmodel);
            CmLookupCodesModel resultModel = cmLookupCodesService.add(lookupmodel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modify(ModifyCmLookupCodesConfigModel modifyModel) {
        ResponseEntity<?> response = null;
        ResponseObj res=new ResponseObj();
        try {
            CmLookupCodesModel lookupModel = CmLookupCodesMgmtUtility.getLookupCodesModifyModel(modifyModel);
            cmLookupCodesOfflineValidation.modifyValidation(lookupModel);
            cmLookupCodesOnlineValidator.modifyValidation(lookupModel);
            CmLookupCodesModel resultModel = cmLookupCodesService.update(lookupModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAll() {
        ResponseEntity<?> response = null;
        try {
            List<CmLookupCodesModel> allLookupCode= cmLookupCodesService.getAll();
            if (!allLookupCode.isEmpty()) {
                response = new ResponseEntity<>(allLookupCode, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> get(Long id) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            cmLookupCodesOfflineValidation.getValidations(id);
            cmLookupCodesOnlineValidator.getValidations(id);
            Map<String, CmLookupCodesModel> map = new HashMap<>(2);
            CmLookupCodesModel master = cmLookupCodesService.findById(id);
            if (master != null) {
                map.put("CmLookupCodesModel", master);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                 response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> addLookupCodeValues(AddCmLookupCodeValuesConfigModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            CmLookupCodeValuesModel lookupmodelV = CmLookupCodeValuesMgmtUtility.getCmLookupCodeValueModel(addModel);
            cmLookupCodeValuesOfflineValidation.addValidation(lookupmodelV);
            cmLookupCodeValuesOnlineValidator.addValidation(lookupmodelV);
            CmLookupCodeValuesModel resultModel = cmLookupCodeValuesService.add(lookupmodelV);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }



    @Override
    public ResponseEntity<?> getAllLookupCodeValue() {
        ResponseEntity<?> response = null;
        try {
            List<CmLookupCodeValuesModel> alllookupCodeValue =  cmLookupCodeValuesService.getAll();
            if (!alllookupCodeValue.isEmpty()) {
                response = new ResponseEntity<>(alllookupCodeValue, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;


    }

    @Override
    public ResponseEntity<?> modifyLookupCodeValues(ModifyCmLookupCodeValuesConfigModel modifyModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            CmLookupCodeValuesModel lcValueModel = CmLookupCodeValuesMgmtUtility.getLookupCodeValueModifyModel(modifyModel);
            cmLookupCodeValuesOfflineValidation.modifyValidation(lcValueModel);
            cmLookupCodeValuesOnlineValidator.modifyValidation(lcValueModel);
            CmLookupCodeValuesModel resultModel = cmLookupCodeValuesService.update(lcValueModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getByLookupCodeValueId(Long id) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();

        try {
            cmLookupCodeValuesOfflineValidation.getValidations(id);
            cmLookupCodeValuesOnlineValidator.getValidations(id);
            Map<String, CmLookupCodeValuesModel> map = new HashMap<>(2);
            CmLookupCodeValuesModel master = cmLookupCodeValuesService.findById(id);
            if (master != null) {
                map.put("CmLookupCodeValuesModel", master);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                 response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
