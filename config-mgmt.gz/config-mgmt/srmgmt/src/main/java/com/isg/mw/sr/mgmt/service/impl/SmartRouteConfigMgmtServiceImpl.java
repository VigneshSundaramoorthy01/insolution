package com.isg.mw.sr.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.sr.mgmt.constants.TargetLCRMgMtMsgKeys;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.SmartRouteConfigMessage;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.dao.entities.SmartRouteConfigEditCopyEntity;
import com.isg.mw.sr.dao.entities.SmartRouteConfigMasterEntity;
import com.isg.mw.sr.dao.service.SmartRouteConfigEditCopyService;
import com.isg.mw.sr.dao.service.SmartRouteConfigMasterService;
import com.isg.mw.sr.dao.service.SmartRouteOnlineValidator;
import com.isg.mw.sr.dao.utils.SmartRouteConfigMasterUtility;
import com.isg.mw.sr.dao.utils.SrUtility;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import com.isg.mw.sr.mgmt.model.AddSrConfigModel;
import com.isg.mw.sr.mgmt.model.ModifySrConfigModel;
import com.isg.mw.sr.mgmt.service.SmartRouteConfigMgmtService;
import com.isg.mw.sr.mgmt.service.SrMessenger;
import com.isg.mw.sr.mgmt.utils.SmartRouteConfigMgmtUtility;
import com.isg.mw.sr.mgmt.validations.SmartRouteOfflineValidator;

@Service("smartRouteConfigMgmtService")
public class SmartRouteConfigMgmtServiceImpl implements SmartRouteConfigMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private SmartRouteConfigEditCopyService srConfigEditCopyService;

	@Autowired
	private SmartRouteConfigMasterService srConfigMasterService;

	@Autowired
	private SmartRouteOnlineValidator smartRouteOnlineValidator;

	@Autowired
	private SrMessenger srMessenger;

	@Autowired
	private SmartRouteOfflineValidator smartRouteOfflineValidator;

	@Override
	public ResponseEntity<?> get(Long id) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.GET_API_LOG_INFO, id));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			smartRouteOfflineValidator.getValidations(id);
			smartRouteOnlineValidator.getValidations(id);
			Map<String, SmartRouteConfigModel> map = new HashMap<>(2);
			SmartRouteConfigModel master = srConfigMasterService.findById(id);
			if (master != null) {
				map.put("master", master);
			}
			SmartRouteConfigModel editCopy = srConfigEditCopyService.findById(id);
			if (editCopy != null) {
				map.put("editCopy", editCopy);
			}
			if (!map.isEmpty()) {
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
				res.setData(map);
				 response = new ResponseEntity<>(res, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
				res.setMsg(MessageConstant.NO_CONTENT);
				res.setStatusCode(MessageConstant.FAIL_CODE);
				 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getAllActive(String entityId) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.GETALL_API_LOG_INFO));
		ResponseEntity<?> response = null;
		try {
			if(entityId!=null){
				List<SmartRouteConfigModel> allConfig = srConfigMasterService.getAllActiveByEntityId(entityId);
				if (!allConfig.isEmpty()) {
					response = new ResponseEntity<>(allConfig, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}else {
				List<SmartRouteConfigModel> allConfig = srConfigMasterService.getAllActive();
				if (!allConfig.isEmpty()) {
					response = new ResponseEntity<>(allConfig, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getAll(String entityId) {
		ResponseEntity<?> response = null;
		try {
			Map<String, List<SmartRouteConfigModel>> map = new HashMap<String, List<SmartRouteConfigModel>>(2);

			if(entityId!=null) {

				List<SmartRouteConfigModel> master = srConfigMasterService.getAllByEntityId(entityId);
				if (master != null) {
					map.put("master", master);
				}
				List<SmartRouteConfigModel> editCopy = srConfigEditCopyService.getAllByEntityId(entityId);
				if (editCopy != null) {
					map.put("editCopy", editCopy);
				}
				if (!map.isEmpty()) {
					response = new ResponseEntity<>(map, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}
			}else
			{
				List<SmartRouteConfigModel> master = srConfigMasterService.getAll();
				if (master != null) {
					map.put("master", master);
				}
				List<SmartRouteConfigModel> editCopy = srConfigEditCopyService.getAll();
				if (editCopy != null) {
					map.put("editCopy", editCopy);
				}
				if (!map.isEmpty()) {
					response = new ResponseEntity<>(map, HttpStatus.OK);
				} else {
					String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
					response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
				}

			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	@Override
	public ResponseEntity<?> getBySourceId(Long srcId) {
		ResponseEntity<?> response = null;
		try {
			smartRouteOfflineValidator.getBySourceIdValidation(srcId);
			smartRouteOnlineValidator.getBySrcIdValidation(srcId);
			SmartRouteConfigModel master = srConfigMasterService.getBySourceId(srcId);
			if (master != null) {
				response = new ResponseEntity<>(master, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> submit(Long srcId) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.SUBMIT_API_LOG_INFO, srcId));
		ResponseEntity<?> response = null;
		ResponseObj res=new ResponseObj();
		try {
			smartRouteOfflineValidator.submitValidation(srcId);
			smartRouteOnlineValidator.submitValidation(srcId);
			String updateStatus = srConfigEditCopyService.updateStatus(EditStatus.Submitted, srcId,null);
			if(updateStatus=="Submitted"){
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			// response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> lock(Long srcId, LockedState lockedState) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.LOCK_API_LOG_INFO, srcId, lockedState));
		ResponseEntity<?> response = null;
		try {
			smartRouteOfflineValidator.lockValidation(srcId, lockedState);
			smartRouteOnlineValidator.lockValidation(srcId, lockedState);
			LockedState lock = srConfigMasterService.lock(srcId, lockedState);
			ConfigAction action = ConfigAction.UN_LOCKED;
			if (lock.equals(LockedState.Locked)) {
				action = ConfigAction.LOCKED;
			}
			sendMessage(srcId, action);

			response = new ResponseEntity<>(lock, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> verify(Long srcId, boolean approved,String remarks) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.VERIFY_API_LOG_INFO, srcId, approved));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();

		try {
			smartRouteOfflineValidator.verifyValidation(srcId, approved,remarks);
			smartRouteOnlineValidator.verifyValidation(srcId, approved);
			if (approved) {
				SmartRouteConfigEditCopyEntity editCopyEntity = srConfigEditCopyService.verifyBySrcId(srcId);
				SmartRouteConfigMasterEntity masterEntity = srConfigMasterService.verifyBySrcId(srcId);
				ConfigAction action = ConfigAction.MODIFY;
				if (masterEntity == null) {
					masterEntity = SrUtility.createMaster(editCopyEntity);
					action = ConfigAction.ADD;
				} else {

					SrUtility.updateMaster(editCopyEntity, masterEntity);
				}
				masterEntity.setRemarks(StringUtils.isBlank(remarks)?null:remarks);
				masterEntity = srConfigMasterService.save(masterEntity);
				srConfigEditCopyService.delete(editCopyEntity);
				sendMessage(srcId, action);
			} else {
				srConfigEditCopyService.updateStatus(EditStatus.Rejected, srcId,remarks);
			}
			if(approved)
			{
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> updateStatus(Long srcId, String srStatus) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.UPDATESTATUS_API_LOG_INFO, srcId, srStatus));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			smartRouteOfflineValidator.updateStatusValidation(srcId, srStatus);
			smartRouteOnlineValidator.updateStatusValidation(srcId, srStatus);
			ConfigStatus status = ConfigStatus.getStatus(srStatus);
			if (status != null) {

				srConfigMasterService.updateStatus(srcId, status);
				ConfigAction action = ConfigAction.ACTIVATE;
				if (status == ConfigStatus.Inactive) {
					action = ConfigAction.INACTIVE;
				}
				sendMessage(srcId, action);

			} else {
				SmartRouteConfigEditCopyEntity editCopyEntity = srConfigEditCopyService.verifyBySrcId(srcId);
				SmartRouteConfigMasterEntity masterEntity = srConfigMasterService.verifyBySrcId(srcId);
				if (editCopyEntity == null) {
					editCopyEntity = new SmartRouteConfigEditCopyEntity();
				}

				SrUtility.updateEditCopy(masterEntity, editCopyEntity);
				editCopyEntity = srConfigEditCopyService.save(editCopyEntity);
			}
			if(status!=null){
				res.setMsg(MessageConstant.SUCCESS_DESC);
				res.setStatusCode(MessageConstant.SUCCESS_CODE);
			}
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> add(AddSrConfigModel addModel) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.ADD_API_LOG_INFO, addModel.getSourceId()));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			SmartRouteConfigModel srModel = SmartRouteConfigMgmtUtility.getSmartRouteConfigModel(addModel);
			smartRouteOfflineValidator.addValidation(srModel);
			smartRouteOnlineValidator.addValidation(srModel);
			SmartRouteConfigModel resultModel = srConfigEditCopyService.add(srModel);
			res.setMsg(MessageConstant.SUCCESS_DESC);
			res.setStatusCode(MessageConstant.SUCCESS_CODE);
			res.setData(resultModel);
			 response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			 response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> modify(ModifySrConfigModel modifyModel) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.MODIFY_API_LOG_INFO, modifyModel.getSourceId()));
		ResponseEntity<?> response = null;
		ResponseObj res =new ResponseObj();
		try {
			SmartRouteConfigModel rdModel = SmartRouteConfigMgmtUtility.getSmartRouteConfigModifyModel(modifyModel);
			smartRouteOfflineValidator.modifyValidation(rdModel);
			smartRouteOnlineValidator.modifyValidation(rdModel);
			SmartRouteConfigModel resultModel = srConfigEditCopyService.update(rdModel);
			res.setMsg(MessageConstant.SUCCESS_DESC);
			res.setStatusCode(MessageConstant.SUCCESS_CODE);
			res.setData(resultModel);
			response = new ResponseEntity<>(res, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
			res.setStatusCode(MessageConstant.FAIL_CODE);
			response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
			res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
			response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	private void sendMessage(Long id, ConfigAction action) {
		SmartRouteConfigMasterEntity masterEntity = srConfigMasterService.verifyBySrcId(id);
		SmartRouteConfigModel srModel = SmartRouteConfigMasterUtility.getSrModel(masterEntity);
		SmartRouteConfigMessage srconfigMessage = new SmartRouteConfigMessage();
		srconfigMessage.setAction(action);
		srconfigMessage.setModel(srModel);
		srMessenger.send(srconfigMessage);
	}

	@Override
	public ResponseEntity<?> getConfigByStatus(String status) {
		LOG.info(PropertyUtils.getMessage(SrMgMtMsgKeys.GET_CONFIG_BY_STATUS_API_LOG_INFO, status));
		ResponseEntity<?> response = null;
		try {
			smartRouteOfflineValidator.configByStatusValidation(status);
			if (ConfigStatus.Active == ConfigStatus.getStatus(status)
					|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)
					|| LockedState.Locked == LockedState.getState(status)
					|| LockedState.Unlocked == LockedState.getState(status)) {
				List<SmartRouteConfigModel> entities = srConfigMasterService.getConfigByStatus(status);
				response = new ResponseEntity<>(entities, HttpStatus.OK);
			} else if (EditStatus.Inprogress == EditStatus.getStatus(status)
					|| EditStatus.Rejected == EditStatus.getStatus(status)
					|| EditStatus.Submitted == EditStatus.getStatus(status)) {
				List<SmartRouteConfigModel> entities = srConfigEditCopyService.getConfigByStatus(status);
				response = new ResponseEntity<>(entities, HttpStatus.OK);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}
