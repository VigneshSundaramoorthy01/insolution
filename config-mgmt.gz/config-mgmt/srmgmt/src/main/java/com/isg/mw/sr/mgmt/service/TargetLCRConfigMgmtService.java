package com.isg.mw.sr.mgmt.service;

import com.isg.mw.sr.mgmt.model.AddTargetLCRConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetLCRConfigModel;
import org.springframework.http.ResponseEntity;

public interface TargetLCRConfigMgmtService {
    ResponseEntity<?> add(AddTargetLCRConfigModel model);

    ResponseEntity<?> get(Long id,Long paymentModeId ,Long paymentModeOptionId);

    ResponseEntity<?> getAllActive(String[] status,String entityId);

    ResponseEntity<?> submit(Long targetId,Long paymentModeId ,Long paymentModeOptionId);

    ResponseEntity<?> modify(ModifyTargetLCRConfigModel model);

    ResponseEntity<?> changeStatus(Long targetId,Long paymentModeId ,Long paymentModeOptionId, String status,String remarks);

    ResponseEntity<?> verify(Long targetId,Long paymentModeId ,Long paymentModeOptionId, boolean approved,String remarks);
}
