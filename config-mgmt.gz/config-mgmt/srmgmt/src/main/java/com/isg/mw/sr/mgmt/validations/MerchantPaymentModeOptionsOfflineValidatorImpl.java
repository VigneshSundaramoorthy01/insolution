package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.MerchantMasterFieldInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsAdditionalData;
import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesAdditionalData;
import com.isg.mw.core.model.validation.DateValidation;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service("merchantPaymentModeOptionsOfflineValidator")
public class MerchantPaymentModeOptionsOfflineValidatorImpl implements MerchantPaymentModeOptionsOfflineValidator{
    @Override
    public void addValidation(MerchantPaymentModeOptionsModel model) {
        UserDataValidations.longDataValidations(model.getMerchantPaymentModeId(), MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.ID_FL,true);
        UserDataValidations.longDataValidations(model.getPaymentModeOptionId(),MerchantMasterFieldInfo.PAY_MODE_OPTIONS_ID_FN,MerchantMasterFieldInfo.PAY_MODE_OPTIONS_ID_FL, true);
        DateValidation.startDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        additionalDataValidation(model.getAdditionalData());

    }


    @Override
    public void modifyValidation(MerchantPaymentModeOptionsModel model) {
        UserDataValidations.longDataValidations(model.getMerchantPaymentModeId(), MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.ID_FL,true);
        UserDataValidations.longDataValidations(model.getPaymentModeOptionId(),MerchantMasterFieldInfo.PAY_MODE_ID_FN,MerchantMasterFieldInfo.PAY_MODE_ID_FL, true);
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        additionalDataValidation(model.getAdditionalData());
    }
    private void additionalDataValidation(MerchantPaymentModeOptionsAdditionalData additionalData) {
        if(additionalData != null){
            UserDataValidations.stringDataValidation(additionalData.getStatusUrl(),null,"statusUrl",false,1000);
        }
    }
    @Override
    public void getValidations(Long merchantPayModeId,Long paymentModeOptionId) {
        if (merchantPayModeId <= 0 && paymentModeOptionId<= 0) {
            throw new ValidationException("Merchant Payment Mode options field merchant Payment Mode option Id is mandatory", MerchantMasterFieldInfo.MERCHANT_PAYMENT_MODE_OPTIONS_ID_FN);
        }
    }

    @Override
    public void updateStatusValidation(Long merchantPayModeId,Long paymentModeOptionId, String status) {
        if (merchantPayModeId == 0 && paymentModeOptionId==0) {
            throw new ValidationException("Merchant Payment Mode and Payment mode id is mandatory");
        }
        UserDataValidations.stringPreDefiendDataValidation(status, MerchantMasterFieldInfo.UPDATE_STATUS_VALUES,
                MerchantMasterFieldInfo.UPDATE_STATUS_FN, true);
    }

    @Override
    public void submitValidation(Long merchantPayModeId,Long paymentModeOptionId) {
        if (merchantPayModeId == 0 && paymentModeOptionId==0) {
            throw new ValidationException("Merchant Payment Mode and Payment mode id is mandatory");
        }
    }

    @Override
    public void verifyValidation(Long merchantPayModeId,Long paymentModeOptionId, boolean approved,String remarks) {
        UserDataValidations.longDataValidations(merchantPayModeId,  MerchantMasterFieldInfo.MERCHANT_PAYMENT_MODE_ID_FN, MerchantMasterFieldInfo.MERCHANT_PAYMENT_MODE_ID_FL,true);
        UserDataValidations.longDataValidations(paymentModeOptionId,  MerchantMasterFieldInfo.PAY_MODE_OPTIONS_ID_FN, MerchantMasterFieldInfo.PAY_MODE_OPTIONS_ID_FL,true);
        if (!approved && StringUtils.isBlank(remarks)) {
            throw new ValidationException("Remark is mandatory", FieldsInfo.REMARKS_FN);
        }
    }

    @Override
    public void removeValidation(Long merchantPayModeId,Long paymentModeOptionId) {
        if (merchantPayModeId == 0 && paymentModeOptionId==0) {
            throw new ValidationException("PMerchant Payment Mode and Payment mode id is mandatory");
        }
    }

}
