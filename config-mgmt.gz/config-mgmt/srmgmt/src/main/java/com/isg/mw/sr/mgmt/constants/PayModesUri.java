package com.isg.mw.sr.mgmt.constants;

public interface PayModesUri {

    /**
     * Used for parent URI
     */
    String PARENT = "/sr";

    /**
     * Used for get API URI
     */
    String GET_BY_ID = "/paymentModes/get";

    /**
     * Used for getAll API URI
     */
    String GET_ALL = "/paymentModes/getall";

    /**
     * Used for add API URI
     */
    String ADD = "/paymentModes/add";


    /**
     * Used for save API URI
     */
    String MODIFY = "/paymentModes/update";

    /**
     * Used for add API URI
     */
    String ADD_PAY_MODE_OPTIONS = "/paymentModeOptions/add";

    /**
     * Used for save API URI
     */
    String MODIFY_PAY_MODE_OPTIONS = "/paymentModeOptions/update";

    /**
     * Used for getAll API URI
     */
    String GET_ALL_PAY_MODE_OPTIONS = "/paymentModeOptions/getall";


    /**
     * Used for get API URI
     */
    String GET_PAY_MODE_OPTIONS_BY_ID = "/paymentModeOptions/get";




}
