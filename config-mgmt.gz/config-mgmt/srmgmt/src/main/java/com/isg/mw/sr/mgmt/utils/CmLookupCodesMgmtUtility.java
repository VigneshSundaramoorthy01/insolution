package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.CmLookupCodesModel;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodesConfigModel;

public class CmLookupCodesMgmtUtility {


    private CmLookupCodesMgmtUtility() {

    }
    public static CmLookupCodesModel getCmLookupCodeModel(AddCmLookupCodesConfigModel addModel) {

        CmLookupCodesModel model = new CmLookupCodesModel();
        model.setLookupCode(addModel.getLookupCode());
        return model;


    }

    public static CmLookupCodesModel getLookupCodesModifyModel(ModifyCmLookupCodesConfigModel modifyModel) {
        CmLookupCodesModel model = new CmLookupCodesModel();
        model.setLookupCodeId(modifyModel.getLookupCodeId());
        model.setLookupCode(modifyModel.getLookupCode());
        return model;
    }
}
