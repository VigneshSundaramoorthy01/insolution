package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.sr.MerchantPaymentModesMessage;
import com.isg.mw.core.model.sr.MerchantPaymentModesModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.MerchantPaymentModesSerializer;
import com.isg.mw.sr.mgmt.service.MerchantPaymentModesMessenger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("merchantPaymentModesMessenger")
public class MerchantPaymentModesMessengerImpl  implements MerchantPaymentModesMessenger, InitializingBean, DisposableBean {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public MerchantPaymentModesMessengerImpl() {
    }


    @Override
    public void send(MerchantPaymentModesMessage model) {
        LOG.trace("Sending data on kafka : {} and Action Status : {}", model.getModel(),
               model.getAction());
            producer.sendMessage(model);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getMerchantPaymentModesTopicName(), MerchantPaymentModesSerializer.class));
        producer.init();
    }
}
