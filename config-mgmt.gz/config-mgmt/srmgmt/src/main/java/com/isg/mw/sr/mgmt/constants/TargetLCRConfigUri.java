package com.isg.mw.sr.mgmt.constants;

public interface TargetLCRConfigUri {

    /**
     * Used for parent URI
     */
    String PARENT = "/sr/targetLCR";

    /**
     * Used for get API URI
     */
    String GET_BY_ID = "/get";

    /**
     * Used for getAll API URI
     */
    String GET_ALL_ACTIVE = "/getallactive";

    /**
     * Used for getAll API URI
     */
    String GET_ALL = "/getall";

    /**
     * Used for add API URI
     */
    String ADD = "/add";

    /**
     * Used for submit API URI
     */
    String SUBMIT = "/submit";

    /**
     * Used for save API URI
     */
    String UPDATE = "/update";

    /**
     * Used for verify API URI
     */
    String VERIFY = "/verify";

    /**
     * Used for update API URI
     */
    String CHANGE_STATUS = "/changestatus";

    /**
     * Used for lock API URI
     */
    String LOCK = "/lock";
}
