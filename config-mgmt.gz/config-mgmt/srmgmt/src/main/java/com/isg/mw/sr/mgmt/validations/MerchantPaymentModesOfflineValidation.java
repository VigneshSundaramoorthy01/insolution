package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.MerchantPaymentModesModel;

public interface MerchantPaymentModesOfflineValidation {

    void addValidation(MerchantPaymentModesModel model);

    void modifyValidation(MerchantPaymentModesModel model);
    void getValidations(Long merchantMasterId, Long paymentModeId);

    void updateStatusValidation(Long merchantMasterId, Long paymentModeId, String status);

    void submitValidation(Long merchantMasterId, Long paymentModeId);

    void verifyValidation(Long merchantMasterId, Long paymentModeId, boolean approved,String remarks);

    void removeValidation(Long merchantMasterId, Long paymentModeId);
}
