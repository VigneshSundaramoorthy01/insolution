package com.isg.mw.sr.mgmt.service.impl;

import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.MessageConstant;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetLCRConfigMessage;
import com.isg.mw.core.model.sr.TargetLCRConfigModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.sr.dao.entities.TargetLCRConfigEditCopyEntity;
import com.isg.mw.sr.dao.entities.TargetLCRConfigMasterEntity;
import com.isg.mw.sr.dao.service.TargetLCRConfigEditCopyService;
import com.isg.mw.sr.dao.service.TargetLCRConfigMasterService;
import com.isg.mw.sr.dao.service.TargetLCRConfigOnlineValidator;
import com.isg.mw.sr.dao.utils.TargetLCRConfigMasterUtility;
import com.isg.mw.sr.dao.utils.TargetLCRUtility;
import com.isg.mw.sr.mgmt.constants.TargetLCRMgMtMsgKeys;
import com.isg.mw.sr.mgmt.model.AddTargetLCRConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetLCRConfigModel;
import com.isg.mw.sr.mgmt.service.TargetLCRConfigMessenger;
import com.isg.mw.sr.mgmt.service.TargetLCRConfigMgmtService;
import com.isg.mw.sr.mgmt.utils.TargetLCRConfigMgmtUtility;
import com.isg.mw.sr.mgmt.validations.TargetLCRConfigOfflineValidation;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service("targetLCRConfigMgmtService")
public class TargetLCRConfigMgmtServiceImpl implements TargetLCRConfigMgmtService {

    @Autowired
    private TargetLCRConfigOfflineValidation targetLCRConfigOfflineValidation;

    @Autowired
    private TargetLCRConfigOnlineValidator targetLCRConfigOnlineValidator;

    @Autowired
    private TargetLCRConfigMessenger targetMessenger;

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private TargetLCRConfigEditCopyService targetLCRConfigEditCopyService;

    @Autowired
    private TargetLCRConfigMasterService targetLCRConfigMasterService;


    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private MessageFormatBulkUpdateService messageFormatBulkUpdateService;

    @Override
    public ResponseEntity<?> add(AddTargetLCRConfigModel addModel) {
        LOG.info("Add api calling");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            TargetLCRConfigModel targetModel = TargetLCRConfigMgmtUtility.getTargetLCRConfigMgmtUtility(addModel);
            targetLCRConfigOfflineValidation.addValidation(targetModel);
            targetLCRConfigOnlineValidator.addValidation(targetModel);
            TargetLCRConfigModel resultModel = targetLCRConfigEditCopyService.add(targetModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> get(Long targetId,Long paymentModeId ,Long paymentModeOptionId) {
        LOG.info("Get api calling having targetId: "+targetId+" ,paymentModeId: "+paymentModeId +" and paymentModeOptionId: "+paymentModeOptionId);
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetLCRConfigOfflineValidation.getValidations(targetId,paymentModeId,paymentModeOptionId);
            Map<String, TargetLCRConfigModel> map = new HashMap<>(2);
            TargetLCRConfigModel master = targetLCRConfigMasterService.findById(targetId,paymentModeId,paymentModeOptionId);
            if (master != null) {
                map.put("master", master);
            }
            TargetLCRConfigModel editCopy = targetLCRConfigEditCopyService.findById(targetId,paymentModeId,paymentModeOptionId);
            if (editCopy != null) {
                map.put("editCopy", editCopy);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                 response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.FAILED_DEPENDENCY);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.OK);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllActive(String[] status,String entityId) {
        ResponseEntity<?> response = null;
        List<TargetLCRConfigModel> models = new ArrayList<>();
        try {
            if (entityId != null) {
                if (status != null) {
                    if (status[0].equalsIgnoreCase("All")) {
                        status = new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(), EditStatus.Rejected.name()};
                    }

                    for (String strStatus : status) {
                        if (ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                            List<TargetLCRConfigModel> entities = targetLCRConfigMasterService.getConfigByStatusAndEntityId(ConfigStatus.getStatus(strStatus),entityId);
                            models.addAll(entities);
                        }else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                            models = targetLCRConfigMasterService.getAllActiveByEntityId(entityId);
                        } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus)) || (EditStatus.Rejected == EditStatus.getStatus(strStatus))) {
                            List<TargetLCRConfigModel> entities = targetLCRConfigEditCopyService.getConfigByStatusAndEntityId(EditStatus.getStatus(strStatus),entityId);
                            models.addAll(entities);
                        }
                    }
                    if(!models.isEmpty()){
                        response = new ResponseEntity<>(models, HttpStatus.OK);
                    }else{
                        String errMsg = PropertyUtils.getMessage("Merchant Payment Mode list is empty");
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                } else {
                    List<TargetLCRConfigModel> allConfig = targetLCRConfigMasterService.getAllActiveByEntityId(entityId);
                    if (!allConfig.isEmpty()) {
                        response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.TRGT_LIST_EMPTY);
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                }
            }else {
                if (status != null) {
                    if (status[0].equalsIgnoreCase("All")) {
                        status = new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(), EditStatus.Rejected.name()};
                    }

                    for (String strStatus : status) {
                        if (ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                            List<TargetLCRConfigModel> entities = targetLCRConfigMasterService.getConfigByStatus(ConfigStatus.getStatus(strStatus));
                            models.addAll(entities);
                        } else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                            models = targetLCRConfigMasterService.getAllActive();
                        } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus)) || (EditStatus.Rejected == EditStatus.getStatus(strStatus))) {
                            List<TargetLCRConfigModel> entities = targetLCRConfigEditCopyService.getConfigByStatus(EditStatus.getStatus(strStatus));
                            models.addAll(entities);
                        }
                    }
                    response = new ResponseEntity<>(models, HttpStatus.OK);
                } else {
                    List<TargetLCRConfigModel> allConfig = targetLCRConfigMasterService.getAllActive();
                    if (!allConfig.isEmpty()) {
                        response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.TRGT_LIST_EMPTY);
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                }
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;

    }

    @Override
    public ResponseEntity<?> submit(Long targetId,Long paymentModeId ,Long paymentModeOptionId) {
        LOG.info("Submit api calling having targetId: "+targetId+" ,paymentModeId: "+paymentModeId +" and paymentModeOptionId: "+paymentModeOptionId);
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetLCRConfigOfflineValidation.submitValidation(targetId,paymentModeId,paymentModeOptionId);
            targetLCRConfigOnlineValidator.submitValidation(targetId,paymentModeId,paymentModeOptionId);
            String updateStatus = targetLCRConfigEditCopyService.updateStatus(EditStatus.Submitted,targetId,paymentModeId,paymentModeOptionId,null);
            if(updateStatus=="Submitted"){
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);

            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modify(ModifyTargetLCRConfigModel modifyModel) {
        LOG.info(PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.MODIFY_API_LOG_INFO, modifyModel.getTargetId()));
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            TargetLCRConfigModel rdModel = TargetLCRConfigMgmtUtility.getTargetLCRConfigModifyModel(modifyModel);
            targetLCRConfigOfflineValidation.modifyValidation(rdModel);
            targetLCRConfigOnlineValidator.modifyValidation(rdModel);
            TargetLCRConfigModel resultModel = targetLCRConfigEditCopyService.update(rdModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> changeStatus(Long targetId,Long paymentModeId,Long paymentModeOptionId,String status,String remarks) {
        LOG.info("Change status api calling ");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetLCRConfigOfflineValidation.updateStatusValidation(targetId,paymentModeId,paymentModeOptionId,status);
            targetLCRConfigOnlineValidator.updateStatusValidation(targetId,paymentModeId,paymentModeOptionId,status);
            ConfigStatus configStatus = ConfigStatus.getStatus(status);
            if (configStatus != null) {
                targetLCRConfigMasterService.updateStatus(targetId,paymentModeId,paymentModeOptionId,configStatus,remarks);
                ConfigAction action = ConfigAction.ACTIVATE;
                if (configStatus == ConfigStatus.Inactive) {
                    action = ConfigAction.INACTIVE;
                }
                sendMessage(targetId,paymentModeId,paymentModeOptionId,action);
            } else {
                TargetLCRConfigEditCopyEntity editCopyEntity = targetLCRConfigEditCopyService.verifyByTargetId(targetId,paymentModeId,paymentModeOptionId);
                TargetLCRConfigMasterEntity masterEntity = targetLCRConfigMasterService.verifyByTargetId(targetId,paymentModeId,paymentModeOptionId);
                if (editCopyEntity == null) {
                    editCopyEntity = new TargetLCRConfigEditCopyEntity();
                }
                masterEntity.setRemarks(remarks);
                editCopyEntity.setRemarks(remarks);
                TargetLCRUtility.updateEditCopy(masterEntity, editCopyEntity);
                targetLCRConfigEditCopyService.save(editCopyEntity);
            }
            if(status!=null){
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private void sendMessage(Long targetId,Long paymentModeId,Long paymentModeOptionId,ConfigAction action) {
        TargetLCRConfigMasterEntity masterEntity = targetLCRConfigMasterService.verifyByTargetId(targetId,paymentModeId,paymentModeOptionId);
        TargetLCRConfigModel trgtModel = TargetLCRConfigMasterUtility.getTargetLCRModel(masterEntity);
        TargetLCRConfigMessage trgtconfigMessage = new TargetLCRConfigMessage();
        trgtconfigMessage.setAction(action);
        trgtconfigMessage.setModel(trgtModel);
        targetMessenger.send(trgtconfigMessage);
    }

    @Override
    public ResponseEntity<?> verify(Long targetId,Long paymentModeId,Long paymentModeOptionId,boolean approved,String remarks) {
        LOG.info("Verify api calling");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetLCRConfigOfflineValidation.verifyValidation(targetId,paymentModeId,paymentModeOptionId,approved,remarks);
            targetLCRConfigOnlineValidator.verifyValidation(targetId,paymentModeId,paymentModeOptionId);
            if (approved) {
                TargetLCRConfigEditCopyEntity editCopyEntity = targetLCRConfigEditCopyService.verifyByTargetId(targetId,paymentModeId,paymentModeOptionId);
                TargetLCRConfigMasterEntity masterEntity = targetLCRConfigMasterService.verifyByTargetId(targetId,paymentModeId,paymentModeOptionId);
                ConfigAction action = ConfigAction.MODIFY;
                if (masterEntity == null) {
                    masterEntity = TargetLCRUtility.createMaster(editCopyEntity);
                    action = ConfigAction.ADD;
                } else {
                    TargetLCRUtility.updateMaster(editCopyEntity, masterEntity);
                }
                masterEntity.setRemarks(StringUtils.isBlank(remarks) ? null : remarks);
                targetLCRConfigMasterService.save(masterEntity);
                targetLCRConfigEditCopyService.delete(editCopyEntity);
                 sendMessage(targetId,paymentModeId,paymentModeOptionId,action);
            } else {
                targetLCRConfigEditCopyService.updateStatus(EditStatus.Rejected,targetId,paymentModeId,paymentModeOptionId,remarks);
            }
            if(approved)
            {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}