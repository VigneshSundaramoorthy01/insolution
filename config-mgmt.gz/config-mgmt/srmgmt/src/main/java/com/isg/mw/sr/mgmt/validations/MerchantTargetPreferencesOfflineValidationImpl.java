package com.isg.mw.sr.mgmt.validations;


import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.MerchantMasterFieldInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.MerchantTargetPreferencesModel;
import com.isg.mw.core.model.validation.DateValidation;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service("MerchantTargetPreferencesOfflineValidation")
public class MerchantTargetPreferencesOfflineValidationImpl implements MerchantTargetPreferencesOfflineValidation{

    @Override
    public void addValidation(MerchantTargetPreferencesModel model) {
        UserDataValidations.longDataValidations(model.getMerchantMasterId(), MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.ID_FL, true);
        UserDataValidations.longDataValidations(model.getTargetId(), MerchantMasterFieldInfo.TARGET_ID_FN,MerchantMasterFieldInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeId(), MerchantMasterFieldInfo.PAY_MODE_ID_FN,MerchantMasterFieldInfo.PAY_MODE_ID_FL, true);
        UserDataValidations.stringDataValidation(model.getMid(), MerchantMasterFieldInfo.MID_EX, MerchantMasterFieldInfo.MID_FN, true,MerchantMasterFieldInfo.MID_FL);
        DateValidation.startDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        UserDataValidations.stringPreDefiendDataValidation(model.getStatus().name(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.STATUS_FN,false);
    }

    @Override
    public void modifyValidation(MerchantTargetPreferencesModel model) {
        UserDataValidations.longDataValidations(model.getMerchantMasterId(), MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.ID_FL, true);
        UserDataValidations.longDataValidations(model.getTargetId(), MerchantMasterFieldInfo.TARGET_ID_FN,MerchantMasterFieldInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeId(), MerchantMasterFieldInfo.PAY_MODE_ID_FN,MerchantMasterFieldInfo.PAY_MODE_ID_FL, true);
        UserDataValidations.stringDataValidation(model.getMid(), MerchantMasterFieldInfo.MID_EX, MerchantMasterFieldInfo.MID_FN, true,MerchantMasterFieldInfo.MID_FL);
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        UserDataValidations.stringPreDefiendDataValidation(model.getStatus().name(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.STATUS_FN,false);

    }

    @Override
    public void getValidations(Long merchantMasterId,Long targetId,Long paymentModeId) {
        if (merchantMasterId <= 0 && targetId<=0 && paymentModeId<=0) {
            throw new ValidationException("Merchant Target Preferences field McPreferenceId is mandatory", MerchantMasterFieldInfo.ID_FN);
        }
    }
}
