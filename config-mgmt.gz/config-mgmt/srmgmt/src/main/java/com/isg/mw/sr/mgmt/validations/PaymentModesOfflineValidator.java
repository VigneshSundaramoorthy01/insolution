package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;

public interface PaymentModesOfflineValidator {

    void addValidation(PaymentModesModel model);

    void modifyValidation(PaymentModesModel model);

    void getValidations(Long id);



}
