package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsAdditionalData;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesMsgKeys;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service("targetPaymentModeOptionsOfflineValidator")
public class TargetPaymentModeOptionsOfflineValidatorImpl implements TargetPaymentModeOptionsOfflineValidator{
    @Override
    public void getValidations(Long targetPaymentModeId,Long paymentModeOptionId) {
        UserDataValidations.longDataValidations(targetPaymentModeId, "TargetPaymentModeId", 18, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, "PaymentModeOptionId", 18, true);
    }

    @Override
    public void addValidation(TargetPaymentModeOptionsModel model) {
        UserDataValidations.longDataValidations(model.getTargetPaymentModeId(), "TargetPaymentModeId", 18, true);
        UserDataValidations.longDataValidations(model.getPaymentModeOptionId(), "PaymentModeOptionId", 18, true);
        UserDataValidations.stringDataValidation(model.getStatus(), "^[A-Za-z_ ]*", "status", false, 12);
        additionalDataValidation(model.getAdditionalData());
    }

    @Override
    public void modifyValidation(TargetPaymentModeOptionsModel model) {
        UserDataValidations.longDataValidations(model.getTargetPaymentModeId(), "TargetPaymentModeId",18, true);
        UserDataValidations.longDataValidations(model.getPaymentModeOptionId(), "PaymentModeOptionId",18, true);
        UserDataValidations.stringDataValidation(model.getStatus(), "^[A-Za-z_ ]*", "status", false, 12);
        additionalDataValidation(model.getAdditionalData());
    }

    @Override
    public void submitValidation(Long targetPaymentModeId,Long paymentModeOptionId) {
        UserDataValidations.longDataValidations(targetPaymentModeId, "TargetPaymentModeId",18, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, "PaymentModeOptionId",18, true);
    }

    @Override
    public void updateStatusValidation(Long targetPaymentModeId,Long paymentModeOptionId, String status) {
        UserDataValidations.longDataValidations(targetPaymentModeId, "TargetPaymentModeId",18, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, "PaymentModeOptionId",18, true);
        UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.UPDATE_STATUS_VALUES,
                FieldsInfo.UPDATE_STATUS_FN, true);
    }


    @Override
    public void verifyValidation(Long targetPaymentModeId,Long paymentModeOptionId,boolean approved,String remarks) {
        UserDataValidations.longDataValidations(targetPaymentModeId, "TargetPaymentModeId",18, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, "PaymentModeOptionId",18, true);
        if (!approved && StringUtils.isBlank(remarks)) {
            throw new ValidationException("Remark is mandatory", FieldsInfo.REMARKS_FN);
        }
    }

    @Override
    public void getByTargetIdValidation(Long targetPayModeOptionId) {
        if (targetPayModeOptionId == 0) {
            throw new ValidationException(TargetPaymentModesMsgKeys.TPM_FIELD_IS_MANDATORY, FieldsInfo.SRC_ID_FN);
        }
    }

    @Override
    public void targetPayModeByStatusValidation(String status) {
        UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.CONFIG_BY_STATUS_VALUES,
                FieldsInfo.CONFIG_BY_STATUS_FN, true);
    }

    private void additionalDataValidation(TargetPaymentModeOptionsAdditionalData additionalData) {
        if(additionalData != null){
        UserDataValidations.stringDataValidation(additionalData.getExternalIdentifier(),null,"externalIdentifier",false,50);
        }
    }
}
