package com.isg.mw.sr.controller;

import com.isg.mw.sr.mgmt.constants.TargetLCRConfigUri;
import com.isg.mw.sr.mgmt.model.AddTargetLCRConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetLCRConfigModel;
import com.isg.mw.sr.mgmt.service.TargetLCRConfigMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Target LCR Configuration", description = "Target LCR Configuration API's")
@RestController
@RequestMapping(value = TargetLCRConfigUri.PARENT)
public class TargetLCRConfigController {

    @Autowired
    private TargetLCRConfigMgmtService targetLCRConfigMgmtService;


    @Operation(summary = "API To Add Target LCR configuration", description = "In response will get Target LCR configuration" ,tags= {"Target LCR Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = TargetLCRConfigUri.ADD)
    public ResponseEntity<?> add(@RequestBody AddTargetLCRConfigModel model) {
        return targetLCRConfigMgmtService.add(model);
    }

    @Operation(summary = "API To Get Target LCR configuration", description = "In response will get Target LCR configuration by given id" ,tags= {"Target LCR Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = TargetLCRConfigUri.GET_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestParam(value = "targetId",required = true) Long targetId,
                                 @RequestParam(value = "paymentModeId",required = true) Long paymentModeId,
                                 @RequestParam(value = "paymentModeOptionId",required = true) Long paymentModeOptionId) {
        return targetLCRConfigMgmtService.get(targetId,paymentModeId ,paymentModeOptionId);
    }

    @Operation(summary = "API To Get All Active Target LCR", description = "In response will get all Active TargetLCR" ,tags= {"Target LCR Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = TargetLCRConfigUri.GET_ALL_ACTIVE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllActive(@PathVariable(value = "status") @RequestParam(value = "status", required = false) String[] status,@PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
        return targetLCRConfigMgmtService.getAllActive(status,entityId);

    }


    @Operation(summary = "API To Submit Target LCR configuration", description = "In response will get submit message" ,tags= {"Target LCR Configuration"})
    @GetMapping(value = TargetLCRConfigUri.SUBMIT)
    public ResponseEntity<?> submit(@RequestParam(value = "targetId",required = true) Long targetId,
                                    @RequestParam(value = "paymentModeId",required = true) Long paymentModeId,
                                    @RequestParam(value = "paymentModeOptionId",required = true) Long paymentModeOptionId) {
        return targetLCRConfigMgmtService.submit(targetId,paymentModeId ,paymentModeOptionId);
    }

    @Operation(summary = "API To Modify Target LCR configuration", description = "In response will get Target LCR configuration after update" ,tags= {"Target LCR Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = TargetLCRConfigUri.UPDATE)
    public ResponseEntity<?> modify(@RequestBody ModifyTargetLCRConfigModel model) {
        return targetLCRConfigMgmtService.modify(model);
    }

    @Operation(summary = "API To Change the Status Of Target LCR configuration", description = "In response will get status message" ,tags= {"Target LCR Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = TargetLCRConfigUri.CHANGE_STATUS)
    public ResponseEntity<?> updateStatus(@RequestParam(value = "targetId", required = true) Long targetId,
                                          @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                          @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId,
                                          @RequestParam(value = "status", required = true) String status,
                                          @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return targetLCRConfigMgmtService.changeStatus(targetId,paymentModeId,paymentModeOptionId, status,remarks);
    }

    @Operation(summary = "API To Verify Target LCR configuration", description = "In response will get approved status of Target LCR configuration" ,tags= {"Target LCR Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = TargetLCRConfigUri.VERIFY)
    public ResponseEntity<?> verify(@RequestParam(value = "targetId",required = true) Long targetId,
                                    @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                    @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId,
                                    @RequestParam(value = "approved",required = true) boolean approved,
                                    @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return targetLCRConfigMgmtService.verify(targetId,paymentModeId,paymentModeOptionId,approved,remarks);
    }

}
