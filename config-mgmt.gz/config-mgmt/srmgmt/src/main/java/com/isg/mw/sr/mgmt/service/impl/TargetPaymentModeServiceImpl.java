package com.isg.mw.sr.mgmt.service.impl;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.sr.dao.entities.TargetPaymentModesEditCopyEntity;
import com.isg.mw.sr.dao.entities.TargetPaymentModesMasterEntity;
import com.isg.mw.sr.dao.service.TargetPaymentModesEditCopyService;
import com.isg.mw.sr.dao.service.TargetPaymentModesMasterService;
import com.isg.mw.sr.dao.service.TargetPaymentModesOnlineValidator;
import com.isg.mw.sr.dao.utils.TargetPaymentModesMasterUtility;
import com.isg.mw.sr.dao.utils.TargetUtility;
import com.isg.mw.sr.mgmt.constants.TargetLCRMgMtMsgKeys;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesMsgKeys;
import com.isg.mw.sr.mgmt.model.AddTargetPaymentModesModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModesModel;
import com.isg.mw.sr.mgmt.service.TargetPaymentModeService;
import com.isg.mw.sr.mgmt.service.TargetPaymentModesMessenger;
import com.isg.mw.sr.mgmt.utils.TargetPaymentModesMgmtUtility;
import com.isg.mw.sr.mgmt.validations.TargetPaymentModeOfflineValidator;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("targetPaymentModeService")
public class TargetPaymentModeServiceImpl implements TargetPaymentModeService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private TargetPaymentModesEditCopyService targetPaymentModesEditCopyService;

    @Autowired
    private TargetPaymentModesMasterService targetPaymentModesMasterService;

    @Autowired
    private TargetPaymentModesOnlineValidator targetPaymentModesOnlineValidator;

    @Autowired
    private TargetPaymentModesMessenger tpmMessenger;

    @Autowired
    private TargetPaymentModeOfflineValidator targetPaymentModesOfflineValidator;


    @Autowired
    private MessageFormatBulkUpdateService messageFormatBulkUpdateService;


    @Override
    public ResponseEntity<?> get(Long targetId,Long paymentModeId,String integrationType) {
        LOG.info("Get api calling with targetId : {} , paymentModeId : {} and integrationType: {} ",targetId,paymentModeId,integrationType);
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetPaymentModesOfflineValidator.getValidations(targetId,paymentModeId,integrationType);
            Map<String, TargetPaymentModesModel> map = new HashMap<>(2);
            TargetPaymentModesModel master = targetPaymentModesMasterService.findById(targetId,paymentModeId,integrationType);
            if (master != null) {
                map.put("master", master);
            }
            TargetPaymentModesModel editCopy = targetPaymentModesEditCopyService.findById(targetId,paymentModeId,integrationType);
            if (editCopy != null) {
                map.put("editCopy", editCopy);
            }
            if (!map.isEmpty()) {

                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);

            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllActive(String[] status,String entityId) {
        ResponseEntity<?> response = null;
        List<TargetPaymentModesModel> models = new ArrayList<>();
        try {
            if(entityId!=null){
                if (status != null) {
                    if (status[0].equalsIgnoreCase("All")) {
                        status = new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(), EditStatus.Rejected.name()};
                    }
                    for (String strStatus : status) {
                        if (ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                            List<TargetPaymentModesModel> entities = targetPaymentModesMasterService.getConfigByStatusAndEntityId(ConfigStatus.getStatus(strStatus),entityId);
                            models.addAll(entities);
                        } else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                            models = targetPaymentModesMasterService.getAllActiveByEntity(entityId);
                        } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus)) || (EditStatus.Rejected == EditStatus.getStatus(strStatus))) {
                            List<TargetPaymentModesModel> entities = targetPaymentModesEditCopyService.getConfigByStatusAndEntityId(EditStatus.getStatus(strStatus),entityId);
                            models.addAll(entities);
                        }
                    }
                    if(!models.isEmpty()){
                        response = new ResponseEntity<>(models, HttpStatus.OK);
                    }else{
                        String errMsg = PropertyUtils.getMessage("Merchant Payment Mode list is empty");
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                } else {
                    List<TargetPaymentModesModel> allConfig = targetPaymentModesMasterService.getAllActiveByEntity(entityId);
                    if (!allConfig.isEmpty()) {
                        response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.TRGT_LIST_EMPTY);
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                }
            }else{
                if (status != null) {
                    if(status[0].equalsIgnoreCase("All")){
                        status= new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(),EditStatus.Rejected.name()};
                    }
                    for (String strStatus : status) {
                        if(ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                            List<TargetPaymentModesModel> entities = targetPaymentModesMasterService.getConfigByStatus(ConfigStatus.getStatus(strStatus));
                            models.addAll(entities);
                        }else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                            models = targetPaymentModesMasterService.getAllActive();
                        } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus))||(EditStatus.Rejected==EditStatus.getStatus(strStatus))) {
                            List<TargetPaymentModesModel> entities = targetPaymentModesEditCopyService.getConfigByStatus(EditStatus.getStatus(strStatus));
                            models.addAll(entities);
                        }
                    }
                    response = new ResponseEntity<>(models, HttpStatus.OK);
                } else {
                    List<TargetPaymentModesModel> allConfig = targetPaymentModesMasterService.getAllActive();
                    if (!allConfig.isEmpty()) {
                        response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.TPM_LIST_EMPTY);
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                }
            }

        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> add(AddTargetPaymentModesModel addModel) {
        LOG.info("Add api calling ");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            TargetPaymentModesModel targetPaymentModesModel = TargetPaymentModesMgmtUtility.getTargetPaymentModesModel(addModel);
            targetPaymentModesOfflineValidator.addValidation(targetPaymentModesModel);
            targetPaymentModesOnlineValidator.addValidation(targetPaymentModesModel);
            TargetPaymentModesModel resultModel = targetPaymentModesEditCopyService.add(targetPaymentModesModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modify(ModifyTargetPaymentModesModel modifyModel) {
        LOG.info("Modify api call");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            TargetPaymentModesModel targetPaymentModesModel = TargetPaymentModesMgmtUtility.getTargetPaymentModesModifyModel(modifyModel);
            targetPaymentModesOfflineValidator.modifyValidation(targetPaymentModesModel);
            targetPaymentModesOnlineValidator.modifyValidation(targetPaymentModesModel);
            TargetPaymentModesModel resultModel = targetPaymentModesEditCopyService.update(targetPaymentModesModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> submit(Long targetId,Long paymentModeId,String integrationType) {
        LOG.info("submit api calling with targetId : {} , paymentModeId : {} and integrationType: {} ",targetId,paymentModeId,integrationType);
        ResponseEntity<?> response = null;
        ResponseObj res=new ResponseObj();
        try {
            targetPaymentModesOfflineValidator.submitValidation(targetId,paymentModeId,integrationType);
            targetPaymentModesOnlineValidator.submitValidation(targetId,paymentModeId,integrationType);
            String updateStatus = targetPaymentModesEditCopyService.updateStatus(EditStatus.Submitted, targetId,paymentModeId,integrationType,null);
            if(updateStatus=="Submitted"){
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            // response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> verify(Long targetId,Long paymentModeId,String integrationType,boolean approved,String remarks) {
        LOG.info("verify api calling with targetId : {} , paymentModeId : {} and integrationType: {} ",targetId,paymentModeId,integrationType);
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetPaymentModesOfflineValidator.verifyValidation(targetId,paymentModeId,integrationType,approved,remarks);
            targetPaymentModesOnlineValidator.verifyValidation(targetId,paymentModeId,integrationType);
            if (approved) {
                TargetPaymentModesEditCopyEntity editCopyEntity = targetPaymentModesEditCopyService.verifyByTargetIdAndPaymentModeId(targetId,paymentModeId,integrationType);
                TargetPaymentModesMasterEntity masterEntity = targetPaymentModesMasterService.verifyByTargetIdAndPaymentModeId(targetId,paymentModeId,integrationType);
                ConfigAction action = ConfigAction.MODIFY;
                if (masterEntity == null) {
                    masterEntity = TargetUtility.createMaster(editCopyEntity);
                    action = ConfigAction.ADD;
                } else {
                    TargetUtility.updateMaster(editCopyEntity, masterEntity);
                }
                masterEntity.setRemarks(StringUtils.isBlank(remarks)?null:remarks);
                targetPaymentModesMasterService.save(masterEntity);
                targetPaymentModesEditCopyService.delete(editCopyEntity);
                sendMessage(targetId,paymentModeId,integrationType, action);
            } else {
                targetPaymentModesEditCopyService.updateStatus(EditStatus.Rejected,targetId,paymentModeId,integrationType,remarks);
            }

            if(approved)
            {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res,HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res,HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> updateStatus(Long targetId,Long paymentModeId,String integrationType,String status,String remarks) {
        LOG.info("Change status api calling");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetPaymentModesOfflineValidator.updateStatusValidation(targetId,paymentModeId,integrationType,status);
            targetPaymentModesOnlineValidator.updateStatusValidation(targetId,paymentModeId,integrationType,status);
            ConfigStatus configStatus = ConfigStatus.getStatus(status);
            if (configStatus != null) {
                targetPaymentModesMasterService.updateStatus(configStatus,targetId,paymentModeId,integrationType,remarks);
                ConfigAction action = ConfigAction.ACTIVATE;
                if (configStatus == ConfigStatus.Inactive) {
                    action = ConfigAction.INACTIVE;
                }
                sendMessage(targetId,paymentModeId,integrationType,action);

            } else {
                TargetPaymentModesEditCopyEntity editCopyEntity = targetPaymentModesEditCopyService.verifyByTargetIdAndPaymentModeId(targetId,paymentModeId,integrationType);
                TargetPaymentModesMasterEntity masterEntity = targetPaymentModesMasterService.verifyByTargetIdAndPaymentModeId(targetId,paymentModeId,integrationType);
                if (editCopyEntity == null) {
                    editCopyEntity = new TargetPaymentModesEditCopyEntity();
                }
                editCopyEntity.setRemarks(remarks);
                masterEntity.setRemarks(remarks);
                TargetUtility.updateEditCopy(masterEntity, editCopyEntity);

                targetPaymentModesEditCopyService.save(editCopyEntity);
            }
            if(status!=null){
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }


    @Override
    public ResponseEntity<?> getTargetPaymentModesModelByStatus(String status) {
        LOG.info(PropertyUtils.getMessage(TargetPaymentModesMsgKeys.GET_CONFIG_BY_STATUS_API_LOG_INFO, status));
        ResponseEntity<?> response = null;
        try {
            targetPaymentModesOfflineValidator.targetPayModeByStatusValidation(status);
            if (ConfigStatus.Active == ConfigStatus.getStatus(status)
                    || ConfigStatus.Inactive == ConfigStatus.getStatus(status)) {
                List<TargetPaymentModesModel> entities = targetPaymentModesMasterService.getTargetPaymentModesByStatus(status);
                response = new ResponseEntity<>(entities, HttpStatus.OK);
            } else if (EditStatus.Inprogress == EditStatus.getStatus(status)
                    || EditStatus.Rejected == EditStatus.getStatus(status)
                    || EditStatus.Submitted == EditStatus.getStatus(status)) {
                List<TargetPaymentModesModel> entities = targetPaymentModesEditCopyService.getTargetPaymentModesByStatus(status);
                response = new ResponseEntity<>(entities, HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private void sendMessage(Long targetId,Long paymentModeId,String integrationType, ConfigAction action) {
        TargetPaymentModesMasterEntity masterEntity = targetPaymentModesMasterService.verifyByTargetIdAndPaymentModeId(targetId,paymentModeId,integrationType);
        TargetPaymentModesModel tpmModel = TargetPaymentModesMasterUtility.getTargetModel(masterEntity);
        TargetPaymentModesMessage tpmConfigMessage = new TargetPaymentModesMessage();
        tpmConfigMessage.setAction(action);
        tpmConfigMessage.setModel(tpmModel);
        tpmMessenger.send(tpmConfigMessage);
    }

}
