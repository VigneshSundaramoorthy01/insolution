package com.isg.mw.sr.controller;

import com.isg.mw.sr.mgmt.constants.PayModesUri;
import com.isg.mw.sr.mgmt.model.*;
import com.isg.mw.sr.mgmt.service.PaymentModesMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Payment Modes Configuration", description = "Payment Modes Configuration API's")
@RestController
@RequestMapping(value = PayModesUri.PARENT)
public class PaymentModesMgmtController {

    @Autowired
    private PaymentModesMgmtService payModesMgmtService;

    @Operation(summary = "API To Add Payment Modes", description = "In response will get Payment Modes" ,tags= {"Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = PayModesUri.ADD)
    public ResponseEntity<?> add(@RequestBody AddPaymentModesModel model) {
        return payModesMgmtService.add(model);
    }

    @Operation(summary = "API To Modify Payment Modes", description = "In response will get Payment Modes after update" ,tags= {"Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = PayModesUri.MODIFY)
    public ResponseEntity<?> modify(@RequestBody ModifyPaymentModesModel model) {
        return payModesMgmtService.modify(model);
    }

    @Operation(summary = "API To Get All Payment Modes", description = "In response will get all Payment Modes" ,tags= {"Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = PayModesUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAll() {
        return payModesMgmtService.getAll();
    }


    @Operation(summary = "API To Get Payment Modes", description = "In response will get Payment Modes by given payment mode id" ,tags= {"Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = PayModesUri.GET_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestParam(value = "id",required = true) Long id) {
        return payModesMgmtService.get(id);
    }



    /* Payment mode options */

    @Operation(summary = "API To Add Payment Mode Options", description = "In response will get Payment Mode Options" ,tags= {"Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = PayModesUri.ADD_PAY_MODE_OPTIONS)
    public ResponseEntity<?> addPmo(@RequestBody AddPaymentModeOptionsModel model) {
        return payModesMgmtService.addPayModeOptions(model);
    }

    @Operation(summary = "API To Modify Payment Mode Options", description = "In response will get Payment Mode Options after update" ,tags= {"Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = PayModesUri.MODIFY_PAY_MODE_OPTIONS)
    public ResponseEntity<?> modifyPmo(@RequestBody ModifyPaymentModeOptionsModel model) {
        return payModesMgmtService.modifyPmo(model);
    }

    @Operation(summary = "API To Get All Payment Mode Options", description = "In response will get all Payment Mode Options" ,tags= {"Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = PayModesUri.GET_ALL_PAY_MODE_OPTIONS, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllPmo() {
        return payModesMgmtService.getAllPmo();
    }






}
