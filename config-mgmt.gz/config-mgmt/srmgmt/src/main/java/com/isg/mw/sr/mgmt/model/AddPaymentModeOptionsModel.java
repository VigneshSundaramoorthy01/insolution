package com.isg.mw.sr.mgmt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel(description = "AddPaymentModeOptionsModel")
public class AddPaymentModeOptionsModel {

    @ApiModelProperty(value = "paymentModeId", required = true)
    private Long paymentModeId;

    @ApiModelProperty(value = "modeOptionName", required = true)
    private String modeOptionName;

    @ApiModelProperty(value = "modeOptionDesc", required = true)
    private String modeOptionDesc;

    @ApiModelProperty(value = "defaultEnabledFlag", required = true)
    private Boolean defaultEnabledFlag;

}
