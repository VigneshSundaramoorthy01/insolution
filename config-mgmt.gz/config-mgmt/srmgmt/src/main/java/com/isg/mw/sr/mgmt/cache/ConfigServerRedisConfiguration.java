package com.isg.mw.sr.mgmt.cache;

import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;
import java.util.Arrays;
import java.util.Map;

@Configuration
public class ConfigServerRedisConfiguration {

    private final Logger logger = LogManager.getLogger(getClass());

    @Value("${spring.redis.sentinel.nodes:}")
    private String[] redisSentinelNodes;

    @Value("${spring.redis.sentinel.master:}")
    private String redisSentinelMaster;

    @Value("${spring.redis.host:}")
    private String redisHostName;

    @Value("${spring.redis.port:0}")
    private int redisPort;

    @Value("${spring.redis.password:}")
    private String redisPassword;

    @Value("${redis.ssl.enabled:false}")
    private boolean isSslEnabled;

    @Bean
    protected RedisConnectionFactory jedisConnectionFactory() {
        JedisConnectionFactory factory;
        if (!(Arrays.asList(redisSentinelNodes).isEmpty())) {
            factory = jedisSentinelConnectionFactory();
        } else {
            RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration(redisHostName, redisPort);
            configuration.setPassword(redisPassword);
            JedisClientConfiguration.JedisClientConfigurationBuilder jedisClientConfiguration = JedisClientConfiguration.builder();
            jedisClientConfiguration.connectTimeout(Duration.ofSeconds(60));
            jedisClientConfiguration.usePooling();
            if (isSslEnabled) {
                logger.info("Redis SSL CONNECTION: {}", redisPort);
                jedisClientConfiguration.useSsl();
            } else {
                logger.info("Redis NON-SSL CONNECTION: {}", redisPort);
            }
            factory = new JedisConnectionFactory(configuration, jedisClientConfiguration.build());
            factory.afterPropertiesSet();
        }
        return factory;
    }

    public JedisConnectionFactory jedisSentinelConnectionFactory() {
        RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration().master(redisSentinelMaster);
        logger.info("Redis sentinel nodes: {}", redisSentinelNodes);
        for (String sentinalNode : redisSentinelNodes) {
            String str = sentinalNode.trim();
            int beginIndex = str.indexOf(":");
            int endIndex = str.length();
            sentinelConfig.sentinel(str.substring(0, beginIndex),
                    Integer.parseInt(str.substring(beginIndex + 1, endIndex)));
        }
        return new JedisConnectionFactory(sentinelConfig);
    }

    @Bean
    public RedisTemplate<String, CacheTargetMerchantMaster> targetMerchantMasterRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, CacheTargetMerchantMaster> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

}
