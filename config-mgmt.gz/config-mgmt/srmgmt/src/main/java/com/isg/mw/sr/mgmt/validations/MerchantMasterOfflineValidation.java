package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.MerchantMasterModel;

public interface MerchantMasterOfflineValidation {
    void addValidation(MerchantMasterModel merchantmodel);
    void modifyValidation(MerchantMasterModel merchantmodel);
    void getValidations(String mid);
}