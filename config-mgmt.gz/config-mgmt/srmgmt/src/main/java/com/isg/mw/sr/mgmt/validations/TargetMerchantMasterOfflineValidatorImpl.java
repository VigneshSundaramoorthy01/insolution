package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.MerchantMasterFieldInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.springframework.stereotype.Service;

@Service("targetMerchantMasterOfflineValidator")
public class TargetMerchantMasterOfflineValidatorImpl implements TargetMerchantMasterOfflineValidator{
    @Override
    public void addValidation(TargetMerchantMasterModel model) {
        UserDataValidations.stringDataValidation(model.getMid(), MerchantMasterFieldInfo.MID_EX, MerchantMasterFieldInfo.MID_FN, true,MerchantMasterFieldInfo.MID_FL);
        UserDataValidations.stringDataValidation(model.getTargetMid(),MerchantMasterFieldInfo.TARGET_MID_EX,MerchantMasterFieldInfo.TARGET_MID_FN,true,MerchantMasterFieldInfo.TARGET_MID_FL);
        UserDataValidations.longDataValidations(model.getTargetId(), MerchantMasterFieldInfo.TARGET_ID_FN,MerchantMasterFieldInfo.TARGET_ID_FL, false);
        UserDataValidations.stringPreDefiendDataValidation(model.getStatus(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.STATUS_FN,false);
        UserDataValidations.stringDataValidation(model.getMerchantVpa(),MerchantMasterFieldInfo.MERCHNAT_VPA_EX,MerchantMasterFieldInfo.MERCHNAT_VPA_FN,false,MerchantMasterFieldInfo.MERCHNAT_VPA_FL);
        UserDataValidations.stringDataValidation(model.getKey(),MerchantMasterFieldInfo.KEY_EX,MerchantMasterFieldInfo.KEY_FN,false,MerchantMasterFieldInfo.KEY_FL);
        UserDataValidations.stringDataValidation(model.getSalt(),MerchantMasterFieldInfo.SALT_EX,MerchantMasterFieldInfo.SALT_FN,false,MerchantMasterFieldInfo.SALT_FL);
    }

    @Override
    public void modifyValidation(TargetMerchantMasterModel model) {
        UserDataValidations.stringDataValidation(model.getMid(), MerchantMasterFieldInfo.MID_EX, MerchantMasterFieldInfo.MID_FN, true,MerchantMasterFieldInfo.MID_FL);
        UserDataValidations.stringDataValidation(model.getTargetMid(),MerchantMasterFieldInfo.TARGET_MID_EX,MerchantMasterFieldInfo.TARGET_MID_FN,true,MerchantMasterFieldInfo.TARGET_MID_FL);
        UserDataValidations.longDataValidations(model.getTargetId(), MerchantMasterFieldInfo.TARGET_ID_FN,MerchantMasterFieldInfo.TARGET_ID_FL, false);
        UserDataValidations.stringPreDefiendDataValidation(model.getStatus(),new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inactive.name()},MerchantMasterFieldInfo.STATUS_FN,false);
        UserDataValidations.stringDataValidation(model.getMerchantVpa(),MerchantMasterFieldInfo.MERCHNAT_VPA_EX,MerchantMasterFieldInfo.MERCHNAT_VPA_FN,false,MerchantMasterFieldInfo.MERCHNAT_VPA_FL);
        UserDataValidations.stringDataValidation(model.getKey(),MerchantMasterFieldInfo.KEY_EX,MerchantMasterFieldInfo.KEY_FN,false,MerchantMasterFieldInfo.KEY_FL);
        UserDataValidations.stringDataValidation(model.getSalt(),MerchantMasterFieldInfo.SALT_EX,MerchantMasterFieldInfo.SALT_FN,false,MerchantMasterFieldInfo.SALT_FL);


    }

    @Override
    public void getValidations(Long targetId,String mid,String tid) {
        if (targetId <= 0 && mid==null) {
            throw new ValidationException("Target Merchant Master field targetMerchantMasterId is mandatory", MerchantMasterFieldInfo.TARGET_MERCHANT_MASTERID_FN);
        }

    }

    @Override
    public void checkStatus(String status) {
        UserDataValidations.stringPreDefiendDataValidation(status,new String[]{ActiveInactiveFlag.Active.name(),ActiveInactiveFlag.Inprogress.name(),ActiveInactiveFlag.Failed.name()},MerchantMasterFieldInfo.STATUS_FN,false);
    }
}
