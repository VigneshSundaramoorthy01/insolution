package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.TargetMerchantMasterSerializer;
import com.isg.mw.sr.mgmt.service.TargetMerchantMasterMessenger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("targetMerchantMasterMessenger")
public class TargetMerchantMasterMessengerImpl implements TargetMerchantMasterMessenger, InitializingBean, DisposableBean {

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public TargetMerchantMasterMessengerImpl() {
    }


    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getTargetMerchantMasterTopicName(), TargetMerchantMasterSerializer.class));
        producer.init();
    }

    @Override
    public void send(TargetMerchantMasterModel model) {
            producer.sendMessage(model);
    }
}
