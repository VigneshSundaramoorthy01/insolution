package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.sr.dao.entities.TargetPaymentModesEditCopyEntity;
import com.isg.mw.sr.mgmt.model.AddTargetPaymentModesModel;
import com.isg.mw.sr.mgmt.model.ModifySrConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModesModel;

import java.time.OffsetDateTime;

public class TargetPaymentModesMgmtUtility {

    private TargetPaymentModesMgmtUtility(){

    }

    public static TargetPaymentModesModel getTargetPaymentModesModel(AddTargetPaymentModesModel addModel) {
        TargetPaymentModesModel model = new TargetPaymentModesModel();
        model.setTargetId(addModel.getTargetId());
        model.setPaymentModeId(addModel.getPaymentModeId());
        model.setStartDate(DateFormatUtils.trimDate(addModel.getStartDate()));
        model.setEndDate(DateFormatUtils.trimDate(addModel.getEndDate()));
        model.setIntegrationType(addModel.getIntegrationType());
        model.setEntityId(addModel.getEntityId());
        model.setAdditionalData(addModel.getAdditionalData());
        return model;
    }

    public static TargetPaymentModesModel getTargetPaymentModesModifyModel(ModifyTargetPaymentModesModel modifyModel) {
        TargetPaymentModesModel model = new TargetPaymentModesModel();
        model.setTargetId(modifyModel.getTargetId());
        model.setPaymentModeId(modifyModel.getPaymentModeId());
        model.setIntegrationType(modifyModel.getIntegrationType());
        model.setStartDate(DateFormatUtils.trimDate(modifyModel.getStartDate()));
        model.setEndDate(DateFormatUtils.trimDate(modifyModel.getEndDate()));
        model.setEntityId(modifyModel.getEntityId());
        model.setAdditionalData(modifyModel.getAdditionalData());
        return model;
    }

}
