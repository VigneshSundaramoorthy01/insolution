package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.sr.TargetLCRConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.sr.mgmt.model.AddTargetLCRConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetLCRConfigModel;

public class TargetLCRConfigMgmtUtility {

    private TargetLCRConfigMgmtUtility(){

    }

    public static TargetLCRConfigModel getTargetLCRConfigMgmtUtility(AddTargetLCRConfigModel addModel) {

        TargetLCRConfigModel targetLCRConfigModel = new TargetLCRConfigModel();
        targetLCRConfigModel.setTargetId(addModel.getTargetId());
        targetLCRConfigModel.setPaymentModeId(addModel.getPaymentModeId());
        targetLCRConfigModel.setCardType(addModel.getCardType());
        targetLCRConfigModel.setMccCategory(addModel.getMccCategory());
        targetLCRConfigModel.setPricePct(addModel.getPricePct());
        targetLCRConfigModel.setPriceFixed(addModel.getPriceFixed());
        targetLCRConfigModel.setBelow2000PricePct(addModel.getBelow2000PricePct());
        targetLCRConfigModel.setBelow2000PriceFixed(addModel.getBelow2000PriceFixed());
        targetLCRConfigModel.setPaymentModeOptionId(addModel.getPaymentModeOptionId());
        targetLCRConfigModel.setStatus(EditStatus.Inprogress.name());
        targetLCRConfigModel.setStartDate(DateFormatUtils.trimDate(addModel.getStartDate()));
        targetLCRConfigModel.setEndDate(DateFormatUtils.trimDate(addModel.getEndDate()));
        targetLCRConfigModel.setEntityId(addModel.getEntityId());
        return targetLCRConfigModel;
    }

    public static TargetLCRConfigModel getTargetLCRConfigModifyModel(ModifyTargetLCRConfigModel modifyModel) {

        TargetLCRConfigModel targetLCRConfigModel = new TargetLCRConfigModel();
        targetLCRConfigModel.setTargetId(modifyModel.getTargetId());
        targetLCRConfigModel.setPaymentModeId(modifyModel.getPaymentModeId());
        targetLCRConfigModel.setCardType(modifyModel.getCardType());
        targetLCRConfigModel.setMccCategory(modifyModel.getMccCategory());
        targetLCRConfigModel.setPricePct(modifyModel.getPricePct());
        targetLCRConfigModel.setPriceFixed(modifyModel.getPriceFixed());
        targetLCRConfigModel.setBelow2000PricePct(modifyModel.getBelow2000PricePct());
        targetLCRConfigModel.setBelow2000PriceFixed(modifyModel.getBelow2000PriceFixed());
        targetLCRConfigModel.setPaymentModeOptionId(modifyModel.getPaymentModeOptionId());
        targetLCRConfigModel.setStartDate(DateFormatUtils.trimDate(modifyModel.getStartDate()));
        targetLCRConfigModel.setEndDate(DateFormatUtils.trimDate(modifyModel.getEndDate()));
        targetLCRConfigModel.setEntityId(modifyModel.getEntityId());
        return targetLCRConfigModel;
    }
}
