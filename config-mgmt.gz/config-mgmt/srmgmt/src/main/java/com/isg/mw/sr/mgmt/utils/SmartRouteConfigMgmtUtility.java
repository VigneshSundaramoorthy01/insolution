package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.sr.mgmt.model.AddSrConfigModel;
import com.isg.mw.sr.mgmt.model.ModifySrConfigModel;

public class SmartRouteConfigMgmtUtility {
	
	private SmartRouteConfigMgmtUtility() {

	}

	public static SmartRouteConfigModel getSmartRouteConfigModel(AddSrConfigModel addModel) {
		SmartRouteConfigModel model = new SmartRouteConfigModel();
		model.setRouteType(addModel.getRouteType());
		model.setRouteSwitchingPercent(addModel.getRouteSwitchingPercent());
		model.setSourceId(addModel.getSourceId());
		model.setSuccessRatioInterval(addModel.getSuccessRatioInterval());
		model.setSuccessRatioMaxTxns(addModel.getSuccessRatioMaxTxns());
		model.setTargetRouteConfig(addModel.getTargetRouteConfig());
		model.setSuccessThreshold(addModel.getSuccessThreshold());
		model.setEntityId(addModel.getEntityId());
		return model;
	}

	public static SmartRouteConfigModel getSmartRouteConfigModifyModel(ModifySrConfigModel modifyModel) {
		SmartRouteConfigModel model = new SmartRouteConfigModel();
		model.setRouteType(modifyModel.getRouteType());
		model.setRouteSwitchingPercent(modifyModel.getRouteSwitchingPercent());
		model.setSourceId(modifyModel.getSourceId());
		model.setSuccessRatioInterval(modifyModel.getSuccessRatioInterval());
		model.setSuccessRatioMaxTxns(modifyModel.getSuccessRatioMaxTxns());
		model.setTargetRouteConfig(modifyModel.getTargetRouteConfig());
		model.setSuccessThreshold(modifyModel.getSuccessThreshold());
		model.setEntityId(modifyModel.getEntityId());
		return model;
	}

}
