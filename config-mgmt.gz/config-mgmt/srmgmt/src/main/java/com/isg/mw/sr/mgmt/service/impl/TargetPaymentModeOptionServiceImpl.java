package com.isg.mw.sr.mgmt.service.impl;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsMessage;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.sr.dao.entities.TargetPaymentModeOptionsEditCopyEntity;
import com.isg.mw.sr.dao.entities.TargetPaymentModeOptionsMasterEntity;
import com.isg.mw.sr.dao.entities.TargetPaymentModesMasterEntity;
import com.isg.mw.sr.dao.service.TargetPaymentModeOptionsEditCopyService;
import com.isg.mw.sr.dao.service.TargetPaymentModeOptionsMasterService;
import com.isg.mw.sr.dao.service.TargetPaymentModeOptionsOnlineValidator;
import com.isg.mw.sr.dao.service.TargetPaymentModesMasterService;
import com.isg.mw.sr.dao.utils.TargetOptionUtility;
import com.isg.mw.sr.dao.utils.TargetPaymentModeOptionsMasterUtility;
import com.isg.mw.sr.dao.utils.TargetPaymentModesMasterUtility;
import com.isg.mw.sr.mgmt.constants.TargetLCRMgMtMsgKeys;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModeOptionsMsgKeys;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesMsgKeys;
import com.isg.mw.sr.mgmt.model.AddTargetPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.service.TargetPaymentModeOptionService;
import com.isg.mw.sr.mgmt.service.TargetPaymentModeOptionsMessenger;
import com.isg.mw.sr.mgmt.utils.TargetPaymentModeOptionMgmtUtility;
import com.isg.mw.sr.mgmt.validations.TargetPaymentModeOptionsOfflineValidator;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("targetPaymentModeOptionService")
public class TargetPaymentModeOptionServiceImpl implements TargetPaymentModeOptionService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private TargetPaymentModeOptionsEditCopyService targetPaymentModeOptionsEditCopyService;

    @Autowired
    private TargetPaymentModeOptionsMasterService targetPaymentModeOptionsMasterService;

    @Autowired
    private TargetPaymentModesMasterService targetPaymentModesMasterService;

    @Autowired
    private TargetPaymentModeOptionsOnlineValidator targetPaymentModeOptionsOnlineValidator;

    @Autowired
    private TargetPaymentModeOptionsMessenger tpmoMessenger;

    @Autowired
    private TargetPaymentModeOptionsOfflineValidator targetPaymentModeOptionsOfflineValidator;

    @Autowired
    private MessageFormatBulkUpdateService messageFormatBulkUpdateService;

    @Override
    public ResponseEntity<?> get(Long targetPaymentModeId,Long paymentModeOptionId) {
        LOG.info("Get api calling ");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetPaymentModeOptionsOfflineValidator.getValidations(targetPaymentModeId,paymentModeOptionId);
            Map<String, TargetPaymentModeOptionsModel> map = new HashMap<>(2);
            TargetPaymentModeOptionsModel master = targetPaymentModeOptionsMasterService.findById(targetPaymentModeId,paymentModeOptionId);
            if (master != null) {
                map.put("master", master);
            }
            TargetPaymentModeOptionsModel editCopy = targetPaymentModeOptionsEditCopyService.findById(targetPaymentModeId,paymentModeOptionId);
            if (editCopy != null) {
                map.put("editCopy", editCopy);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                 response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModeOptionsMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllActive(String[] status) {
        LOG.info("Get all active api calling");
         ResponseEntity<?> response = null;
            List<TargetPaymentModeOptionsModel> models = new ArrayList<>();
            try {
                    if (status != null) {
                        if(status[0].equalsIgnoreCase("All")){
                            status= new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(),EditStatus.Rejected.name()};
                        }

                        for (String strStatus : status) {
                            if (ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                                List<TargetPaymentModeOptionsModel> entities = targetPaymentModeOptionsMasterService.getConfigByStatus(ConfigStatus.getStatus(strStatus));
                                models.addAll(entities);
                            }else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                                models = targetPaymentModeOptionsMasterService.getAllActive();
                            }else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus))||(EditStatus.Rejected==EditStatus.getStatus(strStatus))) {
                                List<TargetPaymentModeOptionsModel> entities = targetPaymentModeOptionsEditCopyService .getConfigByStatus(EditStatus.getStatus(strStatus));
                                models.addAll(entities);
                            }
                        }
                        response = new ResponseEntity<>(models, HttpStatus.OK);
                    } else {
                        List<TargetPaymentModeOptionsModel> allConfig = targetPaymentModeOptionsMasterService.getAllActive();
                        if (!allConfig.isEmpty()) {
                            response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                        } else {
                            String errMsg = PropertyUtils.getMessage(TargetPaymentModeOptionsMsgKeys.TPMO_LIST_EMPTY);
                            response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                        }
                    }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModeOptionsMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> add(AddTargetPaymentModeOptionsModel addModel) {
        LOG.info("Add api calling");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            TargetPaymentModeOptionsModel paymentModeOptionsModel = TargetPaymentModeOptionMgmtUtility.getTargetPaymentModesOptionsModel(addModel);
            targetPaymentModeOptionsOfflineValidator.addValidation(paymentModeOptionsModel);
            targetPaymentModeOptionsOnlineValidator.addValidation(paymentModeOptionsModel);
            TargetPaymentModeOptionsModel resultModel = targetPaymentModeOptionsEditCopyService.add(paymentModeOptionsModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModeOptionsMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modify(ModifyTargetPaymentModeOptionsModel modifyModel) {
        LOG.info("Modify api calling");
        ResponseEntity<?> response = null;
        ResponseObj res=new ResponseObj();
        try {
            TargetPaymentModeOptionsModel rdModel = TargetPaymentModeOptionMgmtUtility.getTargetPaymentModeOptionsModifyModel(modifyModel);
            targetPaymentModeOptionsOfflineValidator.modifyValidation(rdModel);
            targetPaymentModeOptionsOnlineValidator.modifyValidation(rdModel);
            TargetPaymentModeOptionsModel resultModel = targetPaymentModeOptionsEditCopyService.update(rdModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModeOptionsMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }


    @Override
    public ResponseEntity<?> submit(Long targetPaymentModeId,Long paymentModeOptionId) {
        LOG.info("Submit api calling ");
        ResponseEntity<?> response = null;
        ResponseObj res=new ResponseObj();
        try {
            targetPaymentModeOptionsOfflineValidator.submitValidation(targetPaymentModeId,paymentModeOptionId);
            targetPaymentModeOptionsOnlineValidator.submitValidation(targetPaymentModeId,paymentModeOptionId);
            String updateStatus = targetPaymentModeOptionsEditCopyService.updateStatus(EditStatus.Submitted, targetPaymentModeId,paymentModeOptionId,null);
            if(updateStatus=="Submitted"){
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            // response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }


    @Override
    public ResponseEntity<?> verify(Long targetPaymentModeId,Long paymentModeOptionId,boolean approved,String remarks) {
        LOG.info("Verify api calling");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetPaymentModeOptionsOfflineValidator.verifyValidation(targetPaymentModeId,paymentModeOptionId,approved,remarks);
            targetPaymentModeOptionsOnlineValidator.verifyValidation(targetPaymentModeId,paymentModeOptionId);
            if (approved) {
            TargetPaymentModeOptionsEditCopyEntity editCopyEntity = targetPaymentModeOptionsEditCopyService.get(targetPaymentModeId,paymentModeOptionId);
            TargetPaymentModeOptionsMasterEntity masterEntity = targetPaymentModeOptionsMasterService.get(targetPaymentModeId,paymentModeOptionId);
            ConfigAction action = ConfigAction.MODIFY;
            if (masterEntity == null) {
                masterEntity = TargetOptionUtility.createMaster(editCopyEntity);
                action = ConfigAction.ADD;
            }else {
                TargetOptionUtility.updateMaster(editCopyEntity, masterEntity);
            }
            masterEntity.setRemarks(StringUtils.isBlank(remarks) ? null : remarks);
            targetPaymentModeOptionsMasterService.save(masterEntity);
            targetPaymentModeOptionsEditCopyService.delete(editCopyEntity);
                        sendMessage(targetPaymentModeId,paymentModeOptionId, action);
            } else {
                targetPaymentModeOptionsEditCopyService.updateStatus(EditStatus.Rejected, targetPaymentModeId,paymentModeOptionId,remarks);
            }
            if(approved)
            {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> updateStatus(Long targetPaymentModeId,Long paymentModeOptionId,String status,String remarks) {
        LOG.info("Change status api calling");
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            targetPaymentModeOptionsOfflineValidator.updateStatusValidation(targetPaymentModeId,paymentModeOptionId,status);
            targetPaymentModeOptionsOnlineValidator.updateStatusValidation(targetPaymentModeId,paymentModeOptionId, status);
            ConfigStatus configStatus = ConfigStatus.getStatus(status);
            if (configStatus != null) {
                targetPaymentModeOptionsMasterService.updateStatus(configStatus,targetPaymentModeId,paymentModeOptionId,remarks);
                ConfigAction action = ConfigAction.ACTIVATE;
                if (configStatus == ConfigStatus.Inactive) {
                    action = ConfigAction.INACTIVE;
                }
                sendMessage(targetPaymentModeId,paymentModeOptionId, action);
            } else {
                TargetPaymentModeOptionsEditCopyEntity editCopyEntity = targetPaymentModeOptionsEditCopyService.get(targetPaymentModeId,paymentModeOptionId);
                TargetPaymentModeOptionsMasterEntity masterEntity = targetPaymentModeOptionsMasterService.get(targetPaymentModeId,paymentModeOptionId);
                if (editCopyEntity == null) {
                    editCopyEntity = new TargetPaymentModeOptionsEditCopyEntity();
                }
                editCopyEntity.setRemarks(remarks);
                masterEntity.setRemarks(remarks);
                TargetOptionUtility.updateEditCopy(masterEntity, editCopyEntity);
                targetPaymentModeOptionsEditCopyService.save(editCopyEntity);
            }
            if(status!=null){
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private void sendMessage(Long targetPaymentModeId,Long paymentModeOptionId, ConfigAction action) {
        TargetPaymentModeOptionsMasterEntity masterEntity = targetPaymentModeOptionsMasterService.get(targetPaymentModeId,paymentModeOptionId);
        TargetPaymentModeOptionsModel tpmOptionModel = TargetPaymentModeOptionsMasterUtility.getTargetModel(masterEntity);

        TargetPaymentModesMasterEntity targetPaymentModesMasterEntity = targetPaymentModesMasterService.get(masterEntity.getTargetPaymentModeId(), ConfigStatus.Active);
        TargetPaymentModesModel targetPaymentModesModel = TargetPaymentModesMasterUtility.getTargetModel(targetPaymentModesMasterEntity);

        TargetPaymentModeOptionsMessage tpmConfigMessage = new TargetPaymentModeOptionsMessage();
        tpmConfigMessage.setAction(action);
        tpmConfigMessage.setModel(tpmOptionModel);
        tpmConfigMessage.setTargetPaymentModesModel(targetPaymentModesModel);
        tpmoMessenger.send(tpmConfigMessage);
    }


    @Override
    public ResponseEntity<?> getTargetModeOptionByStatus(String status) {
        LOG.info(PropertyUtils.getMessage(TargetPaymentModesMsgKeys.GET_CONFIG_BY_STATUS_API_LOG_INFO, status));
        ResponseEntity<?> response = null;
        try {
            targetPaymentModeOptionsOfflineValidator.targetPayModeByStatusValidation(status);
            if (ConfigStatus.Active == ConfigStatus.getStatus(status)
                    || ConfigStatus.Inactive == ConfigStatus.getStatus(status)
                    || LockedState.Locked == LockedState.getState(status)
                    || LockedState.Unlocked == LockedState.getState(status)) {
                List<TargetPaymentModeOptionsModel> entities = targetPaymentModeOptionsMasterService.getTargetPaymentModeOptionsByStatus(status);
                response = new ResponseEntity<>(entities, HttpStatus.OK);
            } else if (EditStatus.Inprogress == EditStatus.getStatus(status)
                    || EditStatus.Rejected == EditStatus.getStatus(status)
                    || EditStatus.Submitted == EditStatus.getStatus(status)) {
                List<TargetPaymentModeOptionsModel> entities = targetPaymentModeOptionsEditCopyService.getTargetPaymentModeOptionsByStatus(status);
                response = new ResponseEntity<>(entities, HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> changeStatus(Long targetPayModeOptionId, String status) {
        return null;
    }
}
