package com.isg.mw.sr.mgmt.service.impl;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.maps.dao.entities.MapsInfoEntity;
import com.isg.mw.maps.dao.service.MapsInfoService;
import com.isg.mw.mf.dao.service.MessageFormatBulkUpdateService;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sr.dao.entities.*;
import com.isg.mw.sr.dao.model.TargetMerchantMasterModels;
import com.isg.mw.sr.dao.model.TargetMerchantMasterResponseModel;
import com.isg.mw.sr.dao.service.*;
import com.isg.mw.sr.dao.utils.*;
import com.isg.mw.sr.mgmt.cache.ConfigRedisCacheUtil;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import com.isg.mw.sr.mgmt.constants.TargetLCRMgMtMsgKeys;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesMsgKeys;
import com.isg.mw.sr.mgmt.model.*;
import com.isg.mw.sr.mgmt.service.*;
import com.isg.mw.sr.mgmt.utils.*;
import com.isg.mw.sr.mgmt.validations.*;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.net.URLDecoder;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service("MerchantMasterMgmtService")
public class MerchantMasterMgmtServiceImpl implements MerchantMasterMgmtService {


    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private MerchantMasterOfflineValidation merchantMasterOfflineValidation;

    @Autowired
    private MerchantMasterOnlineValidator merchantMasterOnlineValidator;

    @Autowired
    private MerchantMasterService merchantMasterService;

    @Autowired
    private MapsInfoService mapsInfoService;

    @Autowired
    private MerchantTargetPreferencesOfflineValidation merchantTargetPrefOfflineValidation;

    @Autowired
    private MerchantTargetPreferencesOnlineValidator merchantTargetPrefOnlineValidator;

    @Autowired
    private MerchantTargetPreferencesService merchantTargetPrefService;

    @Autowired
    private MerchantMasterMessenger merchantMasterMessenger;

    @Autowired
    private MerchantMasterOnboardMessenger merchantMasterOnboardMessenger;

    @Autowired
    private MerchantTargetPreferencesMessenger merchantTargetPreferencesMessenger;

    @Autowired
    private MerchantPaymentModesOfflineValidation merchantPaymentModesOfflineValidator;

    @Autowired
    private MerchantPaymentModesOnlineValidator merchantPaymentModesOnlineValidator;

    @Autowired
    private MerchantPaymentModesEditCopyService merchantPaymentModesEditCopyService;

    @Autowired
    private MerchantPaymentModesMessenger merchantPaymentModesMessenger;

    @Autowired
    private MerchantPaymentModeOptionsMessenger merchantPaymentModeOptionsMessenger;

    @Autowired
    private MerchantPaymentModesMasterService merchantPaymentModesMasterService;

    @Autowired
    private MerchantPaymentModeOptionsOfflineValidator merchantPayModeOptionsOfflineValidator;

    @Autowired
    private MerchantPaymentModeOptionsOnlineValidator merchantPayModeOptionsOnlineValidator;
    @Autowired
    private MerchantPaymentModeOptionEditCopyService merchantPayModeOptionEditCopyService;

    @Autowired
    private MerchantPaymentModeOptionMasterService merchantPayModeOptionMasterService;

    @Autowired
    private TargetMerchantMasterOfflineValidator targetMerchantMasterOfflineValidator;

    @Autowired
    private TargetMerchantMasterOnlineValidator targetMerchantMasterOnlineValidator;

    @Autowired
    private TargetMerchantMasterService targetMerchantMasterService;

    @Autowired
    private TargetMerchantMasterMessenger targetMerchantMasterMessenger;

    @Autowired
    private MessageFormatBulkUpdateService messageFormatBulkUpdateService;

    @Autowired
    private PaymentModesService paymentModesService;

    @Autowired
    private PaymentModeOptionsService paymentModeOptionsService;

    @Autowired
    private TargetConfigMasterService targetConfigMasterService;

    @Autowired
    private SourceConfigMasterService sourceConfigMasterService;

    @Autowired
    private BusinessTypeService businessTypeService;

    @Autowired
    private TargetPaymentModesMasterService targetPaymentModeMasterService;

    @Value("${sm.merchant.payment.mode.end.date.expiry.in.days}")
    private Integer paymentModeEndDate;

    @Value("${sm.target.types:Lyra}")
    private List<String> targetTypes;

    @Autowired
    private ConfigRedisCacheUtil configRedisCacheUtil;

    private Logger logger = LogManager.getLogger();

    @Override
    public ResponseEntity<?> add(AddMerchantMasterModel addModel, Boolean isOnBoardingRequest, Boolean isModifyRequest) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {

            LOG.info("Add Api Condition Call : {}", addModel);
            MerchantMasterModel merchantmodel = MerchantMasterMgmtUtility.getMerchantMasterModel(addModel);
            merchantMasterOfflineValidation.addValidation(merchantmodel);
            merchantMasterOnlineValidator.addValidation(merchantmodel, isOnBoardingRequest, isModifyRequest);
            MerchantMasterEntity existEntity = merchantMasterService.getByMid(merchantmodel.getMid());
            MerchantMasterModel resultModel = null;
            boolean isPaymentModeRequired = false;
            if (existEntity == null) {
                logger.info("Creating new entry for merchant in db having mid : {} and tid : {} ", merchantmodel.getMid(), merchantmodel.getTid());
                resultModel = merchantMasterService.add(merchantmodel);
                isPaymentModeRequired = true;
            } else {
                logger.info("Altering existing merchant having mid : {} and tid : {} ", merchantmodel.getMid(), merchantmodel.getTid());
                resultModel = merchantMasterService.update(merchantmodel);
//                Thread.sleep(6000);
                resultModel.setTid(merchantmodel.getTid());
            }
            //this value set for to avoid update of target merchant master
            resultModel.setIsOnboardEnable(merchantmodel.getIsOnboardEnable());
            merchantMasterMessenger.send(resultModel);
            if (isOnBoardingRequest) {
                /* save targets in targetMerMaster with status = INPROGRESS*/
                resultModel = fetchAndSaveTargetEnabledForOnboard(resultModel);
//                resultModel = fetchAndSaveSourceEnabledForOnboard(resultModel);
//                logger.info("Start Time : {}",OffsetDateTime.now());
//                Thread.sleep(2000);
//                logger.info("End Time : {}",OffsetDateTime.now());
                /*Insert TargetMerchantMaster In Redis cache*/
                resultModel.setBusinessType(businessTypeService.getByIsgBusinessType(merchantmodel.getBusinessType()));
                merchantMasterOnboardMessenger.sendMerchantMasterForOnboardReq(resultModel);
            }
            if ((isOnBoardingRequest && isPaymentModeRequired) && (!isModifyRequest)) {
                List<PaymentModesModel> paymentModes = paymentModesService.getAll();
                MerchantPaymentModesModel merchantPaymentModesModel = new MerchantPaymentModesModel();
                List<PaymentModeOptionsModel> optionsModels = paymentModeOptionsService.getAllByDefaultFlag();
                MerchantPaymentModeOptionsModel merchantPaymentModeOptionsModel = new MerchantPaymentModeOptionsModel();
                if (paymentModes != null && !paymentModes.isEmpty()) {
                    for (PaymentModesModel pm : paymentModes) {
                        optionsModels.stream().filter(list -> list.getPaymentModeId().equals(pm.getPaymentModeId())).collect(Collectors.toList());
                        if ((optionsModels != null && !optionsModels.isEmpty())) {
                            merchantPaymentModesModel.setMerchantMasterId(resultModel.getMerchantMasterId());
                            merchantPaymentModesModel.setPaymentModeId(pm.getPaymentModeId());
                            merchantPaymentModesModel.setStartDate(OffsetDateTime.now().minusMinutes(5));
                            merchantPaymentModesModel.setEndDate(OffsetDateTime.now().plusMonths(Long.valueOf(paymentModeEndDate)));
                            merchantPaymentModesModel.setEntityId(resultModel.getEntityId());
                            merchantPaymentModesModel.setStatus(ConfigStatus.Active.name());
                            MerchantPaymentModesMasterEntity entity = merchantPaymentModesMasterService.save(MerchantPaymentModesMasterUtility.getMerchantPaymentModesMasterEntity(merchantPaymentModesModel));
                            MerchantPaymentModesModel merchPaymentModesModel = MerchantPaymentModesMasterUtility.getMerchantPaymentModesModel(entity);

                            MerchantPaymentModeOptionsMessage merchantPayModeOptionsMessage = new MerchantPaymentModeOptionsMessage();
                            merchantPayModeOptionsMessage.setAction(ConfigAction.ADD);
                            merchantPayModeOptionsMessage.setMerchantPaymentModesModel(merchPaymentModesModel);
                            merchantPayModeOptionsMessage.setMerchantMasterModel(resultModel);

                            for (PaymentModeOptionsModel pom : optionsModels) {
                                if (pom.getPaymentModeId() == pm.getPaymentModeId()) {
                                    merchantPaymentModeOptionsModel.setMerchantPaymentModeId(entity.getMerchantPaymentModeId());
                                    merchantPaymentModeOptionsModel.setPaymentModeOptionId(pom.getPaymentModeOptionId());
                                    merchantPaymentModeOptionsModel.setStartDate(OffsetDateTime.now().minusMinutes(5));
                                    merchantPaymentModeOptionsModel.setEndDate(OffsetDateTime.now().plusMonths(Long.valueOf(paymentModeEndDate)));
                                    merchantPaymentModeOptionsModel.setStatus(ConfigStatus.Active.name());
                                    MerchantPaymentModeOptionsMasterEntity optionsMasterEntity = merchantPayModeOptionMasterService.save(MerchantPaymentModeOptionsMasterUtility.getMerchantPayModeOptionsMasterEntity(merchantPaymentModeOptionsModel));
                                    merchantPayModeOptionsMessage.setModel(MerchantPaymentModeOptionsMasterUtility.getMerchantPaymentModeOptionsModel(optionsMasterEntity));
                                    merchantPaymentModeOptionsMessenger.sendPaymentModesAndOptions(merchantPayModeOptionsMessage);
                                }
                            }
                        }
                    }
                }
            }
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

   /* private MerchantMasterModel fetchAndSaveSourceEnabledForOnboard(MerchantMasterModel merchantMasterModel) {
        logger.info("Calling method to save default target merchant master for source Config in DB for MID : {} ", merchantMasterModel.getMid());
        try {
            List<SourceConfigModel> sourceConfigMasters = sourceConfigMasterService.getAllByEntity(merchantMasterModel.getEntityId());
            List<TargetType> targetTypeList = new ArrayList<>();
            if ((sourceConfigMasters != null && !sourceConfigMasters.isEmpty())) {
                List<TargetMerchantMasterModel> tmmByMid = targetMerchantMasterService.getByMid(merchantMasterModel.getMid());
                List<SourceConfigModel> sourceConfigMastersList = sourceConfigMasters.stream()
                        .filter(tmodel -> tmodel.getAdditionalData().getMerchantOnboardFlag().equals(ActiveFlag.Y.name())).collect(Collectors.toList());
                if (sourceConfigMastersList != null && !sourceConfigMastersList.isEmpty()) {
                    for (SourceConfigModel sourceConfigModel : sourceConfigMastersList) {
                        List<String> integrationTypes = sourceConfigModel.getAdditionalData().getIntegrationTypes();
                        boolean containsIT = integrationTypes.contains(merchantMasterModel.getIntegrationType());
                        TargetMerchantMasterModel tgtMerMasters = null;
                        if (containsIT) {
                            if (tmmByMid != null && !tmmByMid.isEmpty()) {
                                tgtMerMasters = tmmByMid.stream().filter(tmodel -> tmodel.getTargetId().equals(sourceConfigModel.getId())).findFirst().orElse(null);
                                if (tgtMerMasters == null) {
                                    tgtMerMasters = new TargetMerchantMasterModel();
                                    tgtMerMasters.setTargetId(sourceConfigModel.getId());
                                    tgtMerMasters.setMid(merchantMasterModel.getMid());
                                    tgtMerMasters.setTid(merchantMasterModel.getTid());
                                    tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
                                    tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
                                    tgtMerMasters.setRetryCount(0);
                                    tgtMerMasters = targetMerchantMasterService.add(tgtMerMasters);
//                                    putTargetMerchantMasterToRedis(tgtMerMasters);
                                    targetTypeList.add(sourceConfigModel.getSourceType());
                                    merchantMasterModel.setIsMosambeeAddEnable(true);
                                } else {
                                    List<TargetMerchantMasterModel> tmmByMidTid = targetMerchantMasterService.getByMidTid(merchantMasterModel.getMid(), merchantMasterModel.getTid());
                                    if (tmmByMidTid != null && !tmmByMidTid.isEmpty()) {
                                        tgtMerMasters = tmmByMid.stream().filter(tmodel -> tmodel.getTargetId().equals(sourceConfigModel.getId())).findFirst().orElse(null);
                                        if (tgtMerMasters != null) {
                                            targetTypeList.add(sourceConfigModel.getSourceType());
                                            merchantMasterModel.setIsOnboardEnable(true);
                                            merchantMasterModel.setIsMosambeeUpdateEnable(true);
//                                            if (merchantMasterModel.getStatus().equals(ActiveInactiveFlag.Inactive)) {
//                                                merchantMasterModel.setIsMosambeeStatusUpdateEnable(true);
//                                                merchantMasterModel.setRefId(tmmByMid.get(0).getTargetMid());
//                                            } else {
//                                            merchantMasterModel.setIsMosambeeUpdateEnable(true);
//                                            }
                                        } else {
                                            tgtMerMasters = new TargetMerchantMasterModel();
                                            tgtMerMasters.setTargetId(sourceConfigModel.getId());
                                            tgtMerMasters.setMid(merchantMasterModel.getMid());
                                            tgtMerMasters.setTid(merchantMasterModel.getTid());
                                            tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
                                            tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
                                            tgtMerMasters.setRetryCount(0);
                                            tgtMerMasters = targetMerchantMasterService.add(tgtMerMasters);
//                                            putTargetMerchantMasterToRedis(tgtMerMasters);
                                            targetTypeList.add(sourceConfigModel.getSourceType());
                                            merchantMasterModel.setIsMosambeeTidRegEnable(true);
                                        }
                                    } else {
                                        tgtMerMasters = new TargetMerchantMasterModel();
                                        tgtMerMasters.setTargetId(sourceConfigModel.getId());
                                        tgtMerMasters.setMid(merchantMasterModel.getMid());
                                        tgtMerMasters.setTid(merchantMasterModel.getTid());
                                        tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
                                        tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
                                        tgtMerMasters.setRetryCount(0);
                                        tgtMerMasters = targetMerchantMasterService.add(tgtMerMasters);
//                                        putTargetMerchantMasterToRedis(tgtMerMasters);
                                        targetTypeList.add(sourceConfigModel.getSourceType());
                                        merchantMasterModel.setIsMosambeeTidRegEnable(true);
                                    }
                                }
                            } else {
                                tgtMerMasters = new TargetMerchantMasterModel();
                                tgtMerMasters.setTargetId(sourceConfigModel.getId());
                                tgtMerMasters.setMid(merchantMasterModel.getMid());
                                tgtMerMasters.setTid(merchantMasterModel.getTid());
                                tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
                                tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
                                tgtMerMasters.setRetryCount(0);
                                tgtMerMasters = targetMerchantMasterService.add(tgtMerMasters);
//                                putTargetMerchantMasterToRedis(tgtMerMasters);
                                targetTypeList.add(sourceConfigModel.getSourceType());
                                merchantMasterModel.setIsMosambeeAddEnable(true);
                            }
                        }
                    }
                    merchantMasterModel.setTargetTypes(targetTypeList);
                    return merchantMasterModel;
                }
            }
        } catch (Exception e) {
            logger.info("Exception while add Target Merchant Master to  DB / REDIS : {} ", e.getMessage());
        }
        return null;
    }

    */

    private MerchantMasterModel fetchAndSaveTargetEnabledForOnboard(MerchantMasterModel merchantMasterModel) {
        logger.info("Calling method to save default target merchant master in DB for MID : {} ", merchantMasterModel.getMid());
        try {
            List<TargetConfigModel> targetConfigMasters = targetConfigMasterService.getAllByEntityId(merchantMasterModel.getEntityId());
            List<TargetType> targetTypeList = new ArrayList<>();
            if ((targetConfigMasters != null && !targetConfigMasters.isEmpty())) {
                List<TargetMerchantMasterModel> tmmByMidTid = targetMerchantMasterService.getByMidTid(merchantMasterModel.getMid(), merchantMasterModel.getTid());
                List<TargetConfigModel> targetConfigMastersList = targetConfigMasters.stream()
                        .filter(tmodel -> tmodel.getAdditionalData().getMerchantOnboardFlag()!=null && tmodel.getAdditionalData().getMerchantOnboardFlag().equals(ActiveFlag.Y.name())).collect(Collectors.toList());
                if (targetConfigMastersList != null && !targetConfigMastersList.isEmpty()) {
                    for (TargetConfigModel targetConfigModel : targetConfigMastersList) {
                        List<String> integrationTypes = targetConfigModel.getAdditionalData().getIntegrationTypes();
                        boolean containsIT = integrationTypes!=null && integrationTypes.contains(merchantMasterModel.getIntegrationType());
                        TargetMerchantMasterModel tgtMerMasters = null;
                        if (containsIT) {
                            if (!StringUtils.isBlank(merchantMasterModel.getTerminalType())) {
                                if (("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND")) && targetConfigModel.getTargetType() == TargetType.VizPay) {
                                    logger.info("Condition execute successfully for terminal type sound box : "+merchantMasterModel.getMid());
                                    fetchAndSaveTargetEnabledForOnboard(merchantMasterModel, targetConfigModel, tmmByMidTid, targetTypeList);
                                } else if (!("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND")) && targetConfigModel.getTargetType() != TargetType.VizPay) {
                                    logger.info("Condition execute successfully terminal type other than sound box : "+merchantMasterModel.getMid());
                                    fetchAndSaveTargetEnabledForOnboard(merchantMasterModel, targetConfigModel, tmmByMidTid, targetTypeList);
                                }
                            } else if (StringUtils.isBlank(merchantMasterModel.getTerminalType()) && targetConfigModel.getTargetType() != TargetType.VizPay) {
                                logger.info("Condition execute successfully terminal type blank  : "+merchantMasterModel.getMid());
                                fetchAndSaveTargetEnabledForOnboard(merchantMasterModel, targetConfigModel, tmmByMidTid, targetTypeList);
                            }
                        }
                    }
                    merchantMasterModel.setTerminalType(!StringUtils.isBlank(merchantMasterModel.getTerminalType())?merchantMasterModel.getTerminalType():"");
                    merchantMasterModel.setTargetTypes(targetTypeList);
                    return merchantMasterModel;
                }
            }
        } catch (Exception e) {
            logger.info("Exception while add Target Merchant Master to  DB / REDIS : {} ", e.getMessage());
        }
        return null;
    }

    private void fetchAndSaveTargetEnabledForOnboard(MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel, List<TargetMerchantMasterModel> tmmByMidTid, List<TargetType> targetTypeList) {
        TargetMerchantMasterModel tgtMerMasters;

        List<TargetMerchantMasterModel> tmmByMid = targetMerchantMasterService.getByMid(merchantMasterModel.getMid());

        tgtMerMasters = tmmByMid==null?null:tmmByMid.stream().filter(tmodel -> tmodel.getTargetId().equals(targetConfigModel.getId())).findFirst().orElse(null);

        if ((targetConfigModel.getTargetType() == TargetType.Mosambee) && tmmByMid==null && tgtMerMasters == null) {
            tgtMerMasters = new TargetMerchantMasterModel();
            tgtMerMasters.setTargetId(targetConfigModel.getId());
            tgtMerMasters.setMid(merchantMasterModel.getMid());
            tgtMerMasters.setTid(merchantMasterModel.getTid());
            tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
            tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
            tgtMerMasters.setRetryCount(0);
            tgtMerMasters.setIntegrationType(merchantMasterModel.getIntegrationType());
            targetMerchantMasterService.add(tgtMerMasters);
            targetTypeList.add(targetConfigModel.getTargetType());
            merchantMasterModel.setIsMosambeeAddEnable(true);
        } else if (tmmByMidTid != null && !tmmByMidTid.isEmpty()) {
            tgtMerMasters = tmmByMidTid.stream().filter(tmodel -> tmodel.getTargetId().equals(targetConfigModel.getId())).findFirst().orElse(null);
            if (tgtMerMasters == null) {
                tgtMerMasters = new TargetMerchantMasterModel();
                tgtMerMasters.setTargetId(targetConfigModel.getId());
                tgtMerMasters.setMid(merchantMasterModel.getMid());
                tgtMerMasters.setTid(merchantMasterModel.getTid());
                tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
                tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
                tgtMerMasters.setRetryCount(0);
                tgtMerMasters.setIntegrationType(merchantMasterModel.getIntegrationType());
                targetMerchantMasterService.add(tgtMerMasters);
                targetTypeList.add(targetConfigModel.getTargetType());
                if (targetConfigModel.getTargetType() == TargetType.Mosambee) {
                    merchantMasterModel.setIsMosambeeAddEnable(true);
                }
            } else {
                if (!tgtMerMasters.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                    targetTypeList.add(targetConfigModel.getTargetType());
                    merchantMasterModel.setIsOnboardEnable(true);
                }
                if (targetConfigModel.getTargetType() == TargetType.Mosambee) {
                    merchantMasterModel.setIsMosambeeUpdateEnable(true);
                    targetTypeList.add(targetConfigModel.getTargetType());
                    merchantMasterModel.setIsOnboardEnable(true);
                }
            }
        } else {
            tgtMerMasters = new TargetMerchantMasterModel();
            tgtMerMasters.setTargetId(targetConfigModel.getId());
            tgtMerMasters.setMid(merchantMasterModel.getMid());
            tgtMerMasters.setTid(merchantMasterModel.getTid());
            tgtMerMasters.setStatus(ActiveInactiveFlag.Inprogress.name());
            tgtMerMasters.setTargetMid(merchantMasterModel.getMid());
            tgtMerMasters.setRetryCount(0);
            tgtMerMasters.setIntegrationType(merchantMasterModel.getIntegrationType());
            targetMerchantMasterService.add(tgtMerMasters);
            targetTypeList.add(targetConfigModel.getTargetType());
            if (targetConfigModel.getTargetType() == TargetType.Mosambee) {
                merchantMasterModel.setIsMosambeeTidRegEnable(true);
            }
        }
    }

    @Override
    public ResponseEntity<?> modify(ModifyMerchantMasterModel model) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            MerchantMasterModel merchantmodel = MerchantMasterMgmtUtility.getMerchantMasterModifyModel(model);
            merchantMasterOfflineValidation.modifyValidation(merchantmodel);
            merchantMasterOnlineValidator.modifyValidation(merchantmodel);
            MerchantMasterModel resultModel = merchantMasterService.update(merchantmodel);
            resultModel.setMerchantCity(merchantmodel.getMerchantCity());
            resultModel.setMerchantStateCode(merchantmodel.getMerchantStateCode());
            resultModel.setMerchantShortCountryCode(merchantmodel.getMerchantShortCountryCode());
            merchantMasterMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAll(ActiveInactiveFlag status, Integer pageNo, Integer pageSize,String entityId,String[] integrationType) {
        ResponseEntity<?> response = null;
        List<MerchantMasterModel> allMerchant = null;
        try {
            allMerchant = merchantMasterService.getAll(status, pageNo, pageSize, entityId, integrationType);
            if (allMerchant != null && !allMerchant.isEmpty()) {
                response = new ResponseEntity<>(allMerchant, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Merchant masters list is empty");
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> get(String mid) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantMasterOfflineValidation.getValidations(mid);
            merchantMasterOnlineValidator.getValidations(mid);
            MerchantMasterModel model = merchantMasterService.findById(mid);
            if (model != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(model);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> addMerchantTargetPreferences(AddMerchantTargetPreferencesModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            MerchantTargetPreferencesModel model = MerchantTargetPreferencesMgmtUtility.getMerchantTargetPreferencesModel(addModel);
            merchantTargetPrefOfflineValidation.addValidation(model);
            merchantTargetPrefOnlineValidator.addValidation(model);
            MerchantTargetPreferencesModel resultModel = merchantTargetPrefService.add(model);
            MerchantMasterEntity merchantMasterEntity = merchantMasterService.get(resultModel.getMerchantMasterId());
            MerchantTargetPreferencesMessage message = new MerchantTargetPreferencesMessage();
            message.setModel(resultModel);
            message.setMerchantMasterModel(MerchantMasterUtility.getMerchantMasterModel(merchantMasterEntity));
            merchantTargetPreferencesMessenger.send(message);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modifyMerchantTargetPreferences(ModifyMerchantTargetPreferencesModel model) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            MerchantTargetPreferencesModel merchantmodel = MerchantTargetPreferencesMgmtUtility.getMerchantTargetPreferencesModifyModel(model);
            merchantTargetPrefOfflineValidation.modifyValidation(merchantmodel);
            merchantTargetPrefOnlineValidator.modifyValidation(merchantmodel);
            MerchantTargetPreferencesModel resultModel = merchantTargetPrefService.update(merchantmodel);
            MerchantMasterEntity merchantMasterEntity = merchantMasterService.get(resultModel.getMerchantMasterId());
            MerchantTargetPreferencesMessage message = new MerchantTargetPreferencesMessage();
            message.setModel(resultModel);
            message.setMerchantMasterModel(MerchantMasterUtility.getMerchantMasterModel(merchantMasterEntity));
            merchantTargetPreferencesMessenger.send(message);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllActiveMerchantTrgPref() {
        ResponseEntity<?> response = null;
        try {
            List<MerchantTargetPreferencesModel> allMerchantPreferance = merchantTargetPrefService.getAllActive();
            if (!allMerchantPreferance.isEmpty()) {
                response = new ResponseEntity<>(allMerchantPreferance, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.TPM_LIST_EMPTY);
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantTrgPref(Long merchantMasterId, Long targetId, Long paymentModeId, String mid) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantTargetPrefOfflineValidation.getValidations(merchantMasterId, targetId, paymentModeId);
            merchantTargetPrefOnlineValidator.getValidations(merchantMasterId, targetId, paymentModeId, mid);
            MerchantTargetPreferencesModel model = merchantTargetPrefService.findById(merchantMasterId, targetId, paymentModeId, mid);
            if (model != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(model);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> addMerchantPayModes(AddMerchantPaymentModesModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            MerchantPaymentModesModel model = MerchantPaymentModesMgmtUtility.getMerchantPaymentModesMgmtUtility(addModel);
            merchantPaymentModesOfflineValidator.addValidation(model);
            merchantPaymentModesOnlineValidator.addValidation(model);
            MerchantPaymentModesModel resultModel = merchantPaymentModesEditCopyService.add(model);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modifyMerchantPayModes(ModifyMerchantPaymentModesModel modifyModel) {
        ResponseObj res = new ResponseObj();
        ResponseEntity<?> response = null;
        try {
            MerchantPaymentModesModel model = MerchantPaymentModesMgmtUtility.getMerchantPaymentModesModifyModel(modifyModel);
            merchantPaymentModesOfflineValidator.modifyValidation(model);
            merchantPaymentModesOnlineValidator.modifyValidation(model);
            MerchantPaymentModesModel resultModel = merchantPaymentModesEditCopyService.update(model);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;

    }

    @Override
    public ResponseEntity<?> getAllActive(String[] status, String entityId) {
        ResponseEntity<?> response = null;
        List<MerchantPaymentModesModel> models = new ArrayList<>();
        try {
            if (entityId != null) {

                if (status != null) {
                    if (status[0].equalsIgnoreCase("All")) {
                        status = new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(), EditStatus.Rejected.name()};
                    }

                    for (String strStatus : status) {
                        if (ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                            List<MerchantPaymentModesModel> entities = merchantPaymentModesMasterService.getConfigByStatusAndEntityId(ConfigStatus.getStatus(strStatus), entityId);
                            models.addAll(entities);
                        } else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                            models = merchantPaymentModesMasterService.getAllActiveByEntityId(entityId);
                        } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus)) || (EditStatus.Rejected == EditStatus.getStatus(strStatus))) {
                            List<MerchantPaymentModesModel> entities = merchantPaymentModesEditCopyService.getConfigByStatusAndEntityId(EditStatus.getStatus(strStatus), entityId);
                            models.addAll(entities);
                        }
                    }
                    if (!models.isEmpty()) {
                        response = new ResponseEntity<>(models, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage("Merchant Payment Mode list is empty");
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }

                } else {
                    List<MerchantPaymentModesModel> allConfig = merchantPaymentModesMasterService.getAllActiveByEntityId(entityId);
                    if (!allConfig.isEmpty()) {
                        response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage("Merchant Payment Mode list is empty");
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                }
            } else {
                if (status != null) {
                    if (status[0].equalsIgnoreCase("All")) {
                        status = new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(), EditStatus.Rejected.name()};
                    }

                    for (String strStatus : status) {
                        if (ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus)) {
                            List<MerchantPaymentModesModel> entities = merchantPaymentModesMasterService.getConfigByStatus(ConfigStatus.getStatus(strStatus));
                            models.addAll(entities);
                        } else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                            models = merchantPaymentModesMasterService.getAllActive();
                        } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus)) || (EditStatus.Rejected == EditStatus.getStatus(strStatus))) {
                            List<MerchantPaymentModesModel> entities = merchantPaymentModesEditCopyService.getConfigByStatus(EditStatus.getStatus(strStatus));
                            models.addAll(entities);
                        }
                    }
                    response = new ResponseEntity<>(models, HttpStatus.OK);
                } else {
                    List<MerchantPaymentModesModel> allConfig = merchantPaymentModesMasterService.getAllActive();
                    if (!allConfig.isEmpty()) {
                        response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                    } else {
                        String errMsg = PropertyUtils.getMessage("Merchant Payment Mode list is empty");
                        response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                    }
                }
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantPaymentModesById(Long merchantMasterId, Long paymentModeId) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPaymentModesOfflineValidator.getValidations(merchantMasterId, paymentModeId);
            merchantPaymentModesOnlineValidator.getValidations(merchantMasterId, paymentModeId);
            Map<String, MerchantPaymentModesModel> map = new HashMap<>(2);
            MerchantPaymentModesModel master = merchantPaymentModesMasterService.findById(merchantMasterId, paymentModeId);
            if (master != null) {
                map.put("master", master);
            }
            MerchantPaymentModesModel editCopy = merchantPaymentModesEditCopyService.findById(merchantMasterId, paymentModeId);
            if (editCopy != null) {
                map.put("editCopy", editCopy);
            }
            if (!map.isEmpty()) {

                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                response = new ResponseEntity<>(res, HttpStatus.OK);

            } else {
                String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.TPM_LIST_EMPTY);
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantPaymentModesByMidTid(String mid, String tid, String entityId) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
//            merchantPaymentModesOfflineValidator.getValidations(merchantMasterId,paymentModeId);
//            merchantPaymentModesOnlineValidator.getValidations(merchantMasterId,paymentModeId);
            List<Map<String, Object>> listOfMap = new ArrayList<>();
            MerchantMasterModel model = merchantMasterService.getByMidTid(mid, tid, entityId);
            List<TargetPaymentModesModel> allActiveTPMByEntity = targetPaymentModeMasterService.getAllActiveByEntity(entityId);
            if (model != null) {
                List<MerchantPaymentModesModel> paymentModesModels = merchantPaymentModesMasterService.getPaymentModeIdByMerchantMasterId(model.getMerchantMasterId());
                if (allActiveTPMByEntity != null && !allActiveTPMByEntity.isEmpty()) {
                    for (TargetPaymentModesModel tpm : allActiveTPMByEntity) {
                        Map<Long, String> paymentModeMap = paymentModesService.getAll().stream().collect(Collectors.toMap(PaymentModesModel::getPaymentModeId, PaymentModesModel::getPaymentModeName));
                        Map<String, Object> map = getPaymentModeDetailsByMerMaster(model, tpm, paymentModeMap);
                        Optional<Map<String, Object>> existMap = listOfMap.stream().filter(lst -> lst.get("paymentModeId").equals(tpm.getPaymentModeId())).findFirst();
                        if (existMap != null && !existMap.isPresent()) {
                            listOfMap.add(map);
                        }
                    }
                }

                if (paymentModesModels != null && !paymentModesModels.isEmpty()) {
                    for (MerchantPaymentModesModel mpm : paymentModesModels) {
                        Map<String, Object> existMap = listOfMap.stream().filter(lst -> lst.get("paymentModeId").equals(mpm.getPaymentModeId())).findFirst().orElse(null);
                        if (existMap != null && (mpm.getPaymentModeId().equals(existMap.get("paymentModeId")) && mpm.getStatus().equalsIgnoreCase(ConfigStatus.Active.name()))) {
                            existMap.put("status", ConfigStatus.Inactive.name());
                        }
                    }
                }
            }

            if (listOfMap != null && !listOfMap.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(listOfMap);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private Map<String, Object> getPaymentModeDetailsByMerMaster(MerchantMasterModel model,
                                                                 TargetPaymentModesModel tgtPaymentModesModel,
                                                                 Map<Long, String> paymentModes) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", model.getMerchantMasterId());
        map.put("merchantName", model.getMerchantName());
        map.put("mid", model.getMid());
        map.put("tid", model.getTid());
        map.put("paymentModeId", tgtPaymentModesModel.getPaymentModeId());
        map.put("paymentModeName", paymentModes.get(tgtPaymentModesModel.getPaymentModeId()));
        map.put("status", tgtPaymentModesModel.getStatus());
        return map;
    }

    @Override
    public ResponseEntity<?> updateStatusMerchantPaymentModes(Long merchantMasterId, Long paymentModeId, String mstatus, String remarks) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPaymentModesOfflineValidator.updateStatusValidation(merchantMasterId, paymentModeId, mstatus);
            merchantPaymentModesOnlineValidator.updateStatusValidation(merchantMasterId, paymentModeId, mstatus);
            ConfigStatus status = ConfigStatus.getStatus(mstatus);
            if (status != null) {
                merchantPaymentModesMasterService.updateStatus(merchantMasterId, paymentModeId, status, remarks);
                ConfigAction action = ConfigAction.ACTIVATE;
                if (status == ConfigStatus.Inactive) {
                    action = ConfigAction.INACTIVE;
                }
                sendMessage(merchantMasterId, paymentModeId, action);

            } else {
                MerchantPaymentModesEditCopyEntity editCopyEntity = merchantPaymentModesEditCopyService.verifyById(merchantMasterId, paymentModeId);
                MerchantPaymentModesMasterEntity masterEntity = merchantPaymentModesMasterService.verifyById(merchantMasterId, paymentModeId);
                if (editCopyEntity == null) {
                    editCopyEntity = new MerchantPaymentModesEditCopyEntity();
                }
                editCopyEntity.setRemarks(remarks);
                masterEntity.setRemarks(remarks);
                MerchantPaymentModesUtility.updateEditCopy(masterEntity, editCopyEntity);
                editCopyEntity = merchantPaymentModesEditCopyService.save(editCopyEntity);
            }
            if (status != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> verifyMerchantPaymentModes(Long merchantMasterId, Long paymentModeId, boolean approved, String remarks) {

        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();

        try {
            merchantPaymentModesOfflineValidator.verifyValidation(merchantMasterId, paymentModeId, approved, remarks);
            merchantPaymentModesOnlineValidator.verifyValidation(merchantMasterId, paymentModeId, approved);
            if (approved) {
                MerchantPaymentModesEditCopyEntity editCopyEntity = merchantPaymentModesEditCopyService.verifyById(merchantMasterId, paymentModeId);
                MerchantPaymentModesMasterEntity masterEntity = merchantPaymentModesMasterService.verifyById(merchantMasterId, paymentModeId);
                ConfigAction action = ConfigAction.MODIFY;
                if (masterEntity == null) {
                    masterEntity = MerchantPayModeUtility.createMaster(editCopyEntity);
                    action = ConfigAction.ADD;
                } else {

                    MerchantPayModeUtility.updateMaster(editCopyEntity, masterEntity);
                }
                masterEntity.setRemarks(StringUtils.isBlank(remarks) ? null : remarks);
                merchantPaymentModesMasterService.save(masterEntity);
                merchantPaymentModesEditCopyService.delete(editCopyEntity);
                sendMessage(merchantMasterId, paymentModeId, action);
            } else {
                merchantPaymentModesEditCopyService.updateStatus(EditStatus.Rejected, merchantMasterId, paymentModeId, remarks);
            }
            if (approved) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }


    @Override
    public ResponseEntity<?> submitMerchantPaymentModes(Long merchantMasterId, Long paymentModeId) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPaymentModesOfflineValidator.submitValidation(merchantMasterId, paymentModeId);
            merchantPaymentModesOnlineValidator.submitValidation(merchantMasterId, paymentModeId);
            String updateStatus = merchantPaymentModesEditCopyService.updateStatus(EditStatus.Submitted, merchantMasterId, paymentModeId, null);
            if (updateStatus == "Submitted") {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            // response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private void sendMessage(Long merchantMasterId, Long paymentModeId, ConfigAction action) {
        MerchantPaymentModesMasterEntity masterEntity = merchantPaymentModesMasterService.verifyById(merchantMasterId, paymentModeId);
        MerchantPaymentModesModel model = MerchantPaymentModesMasterUtility.getMerchantPaymentModesModel(masterEntity);
        MerchantMasterEntity merchantMasterEntity = merchantMasterService.get(masterEntity.getMerchantMasterId());
        MerchantMasterModel merchantMasterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMasterEntity);
        MerchantPaymentModesMessage merchantPayModeMessage = new MerchantPaymentModesMessage();
        merchantPayModeMessage.setAction(action);
        merchantPayModeMessage.setModel(model);
        merchantPayModeMessage.setMerchantMasterModel(merchantMasterModel);
        merchantPaymentModesMessenger.send(merchantPayModeMessage);
    }

    @Override
    public ResponseEntity<?> addMerchantPayModeOptions(AddMerchantPaymentModeOptionsModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {

            MerchantPaymentModeOptionsModel model = MerchantPaymentModeOptionsMgmtUtility.getMerchantPayModeOptionsMgmtUtility(addModel);
            merchantPayModeOptionsOfflineValidator.addValidation(model);
            merchantPayModeOptionsOnlineValidator.addValidation(model);
            MerchantPaymentModeOptionsModel resultModel = merchantPayModeOptionEditCopyService.add(model);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modifyMerchantPayModeOptions(ModifyMerchantPaymentModeOptionsModel modifyModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            MerchantPaymentModeOptionsModel model = MerchantPaymentModeOptionsMgmtUtility.getMerchantPaymentModeOptionsModifyModel(modifyModel);
            merchantPayModeOptionsOfflineValidator.modifyValidation(model);
            merchantPayModeOptionsOnlineValidator.modifyValidation(model);
            MerchantPaymentModeOptionsModel resultModel = merchantPayModeOptionEditCopyService.update(model);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> submitMerchantPaymentModeOptions(Long merchantPayModeId, Long paymentModeOptionId) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPayModeOptionsOfflineValidator.submitValidation(merchantPayModeId, paymentModeOptionId);
            merchantPayModeOptionsOnlineValidator.submitValidation(merchantPayModeId, paymentModeOptionId);
            String updateStatus = merchantPayModeOptionEditCopyService.updateStatus(EditStatus.Submitted, merchantPayModeId, paymentModeOptionId, null);
            if (updateStatus == "Submitted") {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            // response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetLCRMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> verifyMerchantPaymentModeOptions(Long merchantPaymentModeId, Long paymentModeOptionId, boolean approved, String remarks) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPayModeOptionsOfflineValidator.verifyValidation(merchantPaymentModeId, paymentModeOptionId, approved, remarks);
            merchantPayModeOptionsOnlineValidator.verifyValidation(merchantPaymentModeId, paymentModeOptionId, approved);
            if (approved) {
                MerchantPaymentModeOptionsEditCopyEntity editCopyEntity = merchantPayModeOptionEditCopyService.verifyById(merchantPaymentModeId, paymentModeOptionId);
                MerchantPaymentModeOptionsMasterEntity masterEntity = merchantPayModeOptionMasterService.verifyById(merchantPaymentModeId, paymentModeOptionId);
                ConfigAction action = ConfigAction.MODIFY;
                if (masterEntity == null) {
                    masterEntity = MerchantPayModeOptionsUtility.createMaster(editCopyEntity);
                    action = ConfigAction.ADD;
                } else {
                    MerchantPayModeOptionsUtility.updateMaster(editCopyEntity, masterEntity);
                }
                masterEntity.setRemarks(StringUtils.isBlank(remarks) ? null : remarks);
                merchantPayModeOptionMasterService.save(masterEntity);
                merchantPayModeOptionEditCopyService.delete(editCopyEntity);
                ;
                sendMessageMerchantPayModeOption(merchantPaymentModeId, paymentModeOptionId, action);
            } else {
                merchantPayModeOptionEditCopyService.updateStatus(EditStatus.Rejected, merchantPaymentModeId, paymentModeOptionId, remarks);
            }
            if (approved) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private void sendMessageMerchantPayModeOption(Long merchantPaymentModeId, Long paymentModeOptionId, ConfigAction action) {
        MerchantPaymentModeOptionsMasterEntity masterEntity = merchantPayModeOptionMasterService.verifyById(merchantPaymentModeId, paymentModeOptionId);
        MerchantPaymentModeOptionsModel model = MerchantPaymentModeOptionsMasterUtility.getMerchantPaymentModeOptionsModel(masterEntity);
        MerchantPaymentModesMasterEntity merchantPayModeEntity = merchantPaymentModesMasterService.getEntityByMerchantPayModeId(masterEntity.getMerchantPaymentModeId());
        MerchantPaymentModesModel merchantpaymentModesModel = MerchantPaymentModesMasterUtility.getMerchantPaymentModesModel(merchantPayModeEntity);
        MerchantPaymentModeOptionsMessage merchantPayModeOptionsMessage = new MerchantPaymentModeOptionsMessage();
        MerchantMasterEntity merchantMasterEntity = merchantMasterService.get(merchantPayModeEntity.getMerchantMasterId());
        MerchantMasterModel merchantMasterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMasterEntity);
        merchantPayModeOptionsMessage.setAction(action);
        merchantPayModeOptionsMessage.setModel(model);
        merchantPayModeOptionsMessage.setMerchantPaymentModesModel(merchantpaymentModesModel);
        merchantPayModeOptionsMessage.setMerchantMasterModel(merchantMasterModel);
        merchantPaymentModeOptionsMessenger.send(merchantPayModeOptionsMessage);
    }

    @Override
    public ResponseEntity<?> updateStatusMerchantPaymentModeOptions(Long merchantPaymentModeId, Long paymentModeOptionId, String mstatus, String remarks) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPayModeOptionsOfflineValidator.updateStatusValidation(merchantPaymentModeId, paymentModeOptionId, mstatus);
            merchantPayModeOptionsOnlineValidator.updateStatusValidation(merchantPaymentModeId, paymentModeOptionId, mstatus);
            ConfigStatus status = ConfigStatus.getStatus(mstatus);
            if (status != null) {

                merchantPayModeOptionMasterService.updateStatus(merchantPaymentModeId, paymentModeOptionId, status, remarks);
                ConfigAction action = ConfigAction.ACTIVATE;
                if (status == ConfigStatus.Inactive) {
                    action = ConfigAction.INACTIVE;
                }
                sendMessageMerchantPayModeOption(merchantPaymentModeId, paymentModeOptionId, action);

            } else {
                MerchantPaymentModeOptionsEditCopyEntity editCopyEntity = merchantPayModeOptionEditCopyService.verifyById(merchantPaymentModeId, paymentModeOptionId);
                MerchantPaymentModeOptionsMasterEntity masterEntity = merchantPayModeOptionMasterService.verifyById(merchantPaymentModeId, paymentModeOptionId);
                if (editCopyEntity == null) {
                    editCopyEntity = new MerchantPaymentModeOptionsEditCopyEntity();
                }
                editCopyEntity.setRemarks(remarks);
                masterEntity.setRemarks(remarks);
                MerchantPayModeOptionsUtility.updateEditCopy(masterEntity, editCopyEntity);
                editCopyEntity = merchantPayModeOptionEditCopyService.save(editCopyEntity);
            }
            if (status != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllActiveMerchantPaymentModeOptions(String[] status) {
        ResponseEntity<?> response = null;
        List<MerchantPaymentModeOptionsModel> models = new ArrayList<>();
        try {
            if (status != null) {
                if (status[0].equalsIgnoreCase("All")) {
                    status = new String[]{ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), EditStatus.Inprogress.name(), EditStatus.Submitted.name(), EditStatus.Rejected.name()};
                }

                for (String strStatus : status) {
                    if ((ConfigStatus.Inactive == ConfigStatus.getStatus(strStatus))) {
                        List<MerchantPaymentModeOptionsModel> entities = merchantPayModeOptionMasterService.getConfigByStatus(ConfigStatus.getStatus(strStatus));
                        models.addAll(entities);
                    } else if (ConfigStatus.Active == ConfigStatus.getStatus(strStatus)) {
                        models = merchantPayModeOptionMasterService.getAllActive();
                    } else if ((EditStatus.Inprogress == EditStatus.getStatus(strStatus)) || (EditStatus.Submitted == EditStatus.getStatus(strStatus)) || (EditStatus.Rejected == EditStatus.getStatus(strStatus))) {
                        List<MerchantPaymentModeOptionsModel> entities = merchantPayModeOptionEditCopyService.getConfigByStatus(EditStatus.getStatus(strStatus));
                        models.addAll(entities);
                    }
                }
                response = new ResponseEntity<>(models, HttpStatus.OK);
            } else {
                List<MerchantPaymentModeOptionsModel> allConfig = merchantPayModeOptionMasterService.getAllActive();
                if (!allConfig.isEmpty()) {
                    response = new ResponseEntity<>(allConfig, HttpStatus.OK);
                } else {
                    String errMsg = PropertyUtils.getMessage("Merchant Payment Mode Options list is empty");
                    response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
                }
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantPaymentModeOptionsById(Long merchantPaymentModeId, Long paymentModeOptionId) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            merchantPayModeOptionsOfflineValidator.getValidations(merchantPaymentModeId, paymentModeOptionId);
            merchantPayModeOptionsOnlineValidator.getValidations(merchantPaymentModeId, paymentModeOptionId);
            Map<String, MerchantPaymentModeOptionsModel> map = new HashMap<>(2);
            MerchantPaymentModeOptionsModel master = merchantPayModeOptionMasterService.findById(merchantPaymentModeId, paymentModeOptionId);
            if (master != null) {
                map.put("master", master);
            }
            MerchantPaymentModeOptionsModel editCopy = merchantPayModeOptionEditCopyService.findById(merchantPaymentModeId, paymentModeOptionId);
            if (editCopy != null) {
                map.put("editCopy", editCopy);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Merchant Payment Mode Options list is empty");
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(TargetPaymentModesMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> addTargetMerchantMaster(AddTargetMerchantMasterModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            TargetMerchantMasterModel model = TargetMerchantMasterMgmtUtility.getTargetMerchantMasterModel(addModel);
            targetMerchantMasterOfflineValidator.addValidation(model);
            targetMerchantMasterOnlineValidator.addValidation(model);
            TargetMerchantMasterModel resultModel = targetMerchantMasterService.add(model);
            targetMerchantMasterMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modifyTargetMerchantMaster(ModifyTargetMerchantMasterModel modifyModel) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            TargetMerchantMasterModel model = TargetMerchantMasterMgmtUtility.getTargetMerchantMasterModifyModel(modifyModel);
            targetMerchantMasterOfflineValidator.modifyValidation(model);
            targetMerchantMasterOnlineValidator.modifyValidation(model);
            TargetMerchantMasterModel resultModel = targetMerchantMasterService.update(model);
            targetMerchantMasterMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllTargetMerchantMaster(ActiveInactiveFlag status, String integrationType, Integer pageNo, Integer pageSize) {
        ResponseEntity<?> response = null;
        List<TargetMerchantMasterModel> allTergetMerchantMaster = null;
        try {
            if (status != null) {
                allTergetMerchantMaster = targetMerchantMasterService.getAll(status, integrationType, pageNo, pageSize);

            } else {
                allTergetMerchantMaster = targetMerchantMasterService.getAll(ActiveInactiveFlag.Active, integrationType, pageNo, pageSize);
            }
            if (allTergetMerchantMaster != null && !allTergetMerchantMaster.isEmpty()) {
                response = new ResponseEntity<>(allTergetMerchantMaster, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Data Not Found With GIven Parameters");
                response = new ResponseEntity<>(errMsg, HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getAllTargetMerchantMasterCount(ActiveInactiveFlag status, String integrationType) {
        ResponseEntity<?> response;
        ResponseObj res = new ResponseObj();
        try {
            Long count = targetMerchantMasterService.getAllCount(status, integrationType);
            if (count != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(count);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg("Data Not Found With Given Parameters");
                res.setStatusCode(MessageConstant.FAIL_CODE);
                res.setData(count);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getTargetMerchantMaster(Long targetId, String mid, String tid, String status) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            if (!StringUtils.isBlank(status)) {
                targetMerchantMasterOfflineValidator.checkStatus(status);
            }
            targetMerchantMasterOfflineValidator.getValidations(targetId, mid, tid);
//            targetMerchantMasterOnlineValidator.getValidations(targetId,mid,tid,status);
            List<TargetMerchantMasterModel> models = targetMerchantMasterService.getTargetMerchantMasterDetails(targetId, mid, tid, status);
            if (models != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(models);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> delete(Long id) {
        ResponseObj res = new ResponseObj();
        ResponseEntity<?> response = null;
        try {

            merchantTargetPrefOnlineValidator.deleteValidation(id);
            merchantTargetPrefService.deleteById(id);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            response = new ResponseEntity<>(res, HttpStatus.OK);

        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantsCount(ActiveInactiveFlag status,String entityId,String[] integrationType) {
        LOG.info("Calling getMerchantsCount API");
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
            Long merchantsCount = merchantMasterService.getMerchantsCount(status,entityId,integrationType);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(merchantsCount);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantDetails(String mid, String tid, String entityId) {
        LOG.info("Calling getMerchants Details API  API");
        ResponseEntity<?> response;
        ResponseObj res = new ResponseObj();
        List<MerchantDetailModel> list;
        try {
            list = merchantMasterService.getDetailsByMid(mid, tid, entityId);
            if (list != null && !list.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(list);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                MapsInfoModel mm = merchantMasterService.getMapsInfoByMidTid(mid, tid, entityId);
                if (mm != null) {
                    MerchantDetailModel md = new MerchantDetailModel();
                    md.setMid(mm.getMid());
                    md.setTid(mm.getTid());
                    md.setMerchantName(mm.getMerchantName());
                    list.add(md);
                    res.setMsg(MessageConstant.SUCCESS_DESC);
                    res.setStatusCode(MessageConstant.SUCCESS_CODE);
                    res.setData(list);
                    response = new ResponseEntity<>(res, HttpStatus.OK);
                } else {
                    res.setMsg("Merchant Not Present");
                    res.setStatusCode(MessageConstant.FAIL_CODE);
                    response = new ResponseEntity<>(res, HttpStatus.OK);
                }
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> runTargetMerchantMasterModel(Long targetMerchantMasterId, String tid, String mid,
                                                          Long targetId) {
        logger.info("Calling API To Retry On Boarding API's For Target : {} , Mid : {} and Tid : {} ", targetId, mid, tid);
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        if (targetMerchantMasterId == null && targetId == null) {
            logger.info("Force Retry For mid : {} and tid : {} ", mid, tid);
            try {
                MerchantMasterModel masterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMasterService.getByMid(mid));
                MapsInfoEntity mapsInfoEntity = mapsInfoService.get(masterModel.getEntityId(), mid, tid);
                if (mapsInfoEntity != null && masterModel != null) {
                    MerchantMasterModel merchantMasterModel = fetchAndSaveTargetEnabledForOnboard(masterModel);
                    masterModel.setIsOnboardEnable(true);
                    masterModel.setTid(tid);
                    merchantMasterOnboardMessenger.sendMerchantMasterForOnboardReq(merchantMasterModel);
                    List<MerchantDetailModel> detailsByMid = merchantMasterService.getDetailsByMid(mid, tid, masterModel.getEntityId());
                    if (detailsByMid != null) {
                        res.setMsg(MessageConstant.SUCCESS_DESC);
                        res.setStatusCode(MessageConstant.SUCCESS_CODE);
                        res.setData(detailsByMid);
                        response = new ResponseEntity<>(res, HttpStatus.OK);
                    } else {
                        res.setMsg("Data Not Found");
                        res.setStatusCode(MessageConstant.FAIL_CODE);
                        res.setData(null);
                        response = new ResponseEntity<>(res, HttpStatus.OK);
                    }
                } else {
                    res.setMsg("Merchant Not Present");
                    res.setStatusCode(MessageConstant.FAIL_CODE);
                    res.setData(null);
                    response = new ResponseEntity<>(res, HttpStatus.OK);
                }
            } catch (Exception e) {
                String errMsg = e.getMessage();
                logger.error(errMsg, e);
                res.setMsg(errMsg);
                res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
                response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else {
            logger.info("Retry For Single Target  mid : {} , tid : {} and targetId : {}  ", mid, tid, targetId);
            TargetConfigModel targetConfigModel = targetConfigMasterService.findById(targetId);
            if (targetConfigModel != null) {
                try {
                    MerchantMasterModel masterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMasterService.getByMid(mid));
                    MapsInfoEntity mapsInfoEntity = mapsInfoService.get(masterModel.getEntityId(), mid, tid);
                    TargetMerchantMasterModel model = null;
                    if (mapsInfoEntity != null && masterModel != null) {
                        TargetMerchantMasterEntity targetMerchantMasterEntity = targetMerchantMasterService.get(targetId, mid, tid);
                        if (targetMerchantMasterEntity != null) {
                            if (targetMerchantMasterEntity.getStatus() != ActiveInactiveFlag.Active) {
                                masterModel.setTid(tid);
                                masterModel.setIsOnboardEnable(true);
                                masterModel.setTargetTypes(Arrays.asList(targetConfigModel.getTargetType()));
                                sendMerchantMasterModelToKafka(Arrays.asList(masterModel));
                                logger.info("Send Target Merchant Master For Failed / Inprogress Status On Kafka successfully : {} , {} ,{} ,{} ", targetMerchantMasterId, mid, tid, targetId);
                            } else if (targetMerchantMasterEntity.getStatus() == ActiveInactiveFlag.Active) {
                                if (targetTypes.contains(targetConfigModel.getTargetType().name())) {
                                    masterModel.setTid(tid);
                                    masterModel.setIsOnboardEnable(true);
                                    masterModel.setTargetTypes(Arrays.asList(targetConfigModel.getTargetType()));
                                    sendMerchantMasterModelToKafka(Arrays.asList(masterModel));
                                    logger.info("Send Target Merchant Master For Success Status On Kafka successfully : {} , {} ,{} ,{} ", targetMerchantMasterId, mid, tid, targetId);
                                } else {
                                    res.setMsg("Update Is Not Valid To Given Target Type : " + targetConfigModel.getTargetType());
                                    res.setStatusCode(MessageConstant.FAIL_CODE);
                                    res.setData(null);
                                    return new ResponseEntity<>(res, HttpStatus.OK);
                                }
                            }
                            model = TargetMerchantMasteUtility.getTargetMerchantMasterModel(targetMerchantMasterEntity);
                        } else {
                            model = new TargetMerchantMasterModel();
                            model.setTargetId(targetConfigModel.getId());
                            model.setMid(mid);
                            model.setTid(tid);
                            model.setStatus(ActiveInactiveFlag.Inprogress.name());
                            model.setTargetMid(mid);
                            model.setRetryCount(0);
                            model = targetMerchantMasterService.add(model);
                            masterModel.setIsOnboardEnable(true);
                            masterModel.setTargetTypes(Arrays.asList(targetConfigModel.getTargetType()));
                            sendMerchantMasterModelToKafka(Arrays.asList(masterModel));
                            logger.info("Send Target Merchant Master which not present in DB On Kafka successfully : {}", targetMerchantMasterId, mid, tid, targetId);
                        }
                        if (model != null) {
                            res.setMsg(MessageConstant.SUCCESS_DESC);
                            res.setStatusCode(MessageConstant.SUCCESS_CODE);
                            res.setData(model);
                            response = new ResponseEntity<>(res, HttpStatus.OK);
                        } else {
                            res.setMsg("Data Not Found");
                            res.setStatusCode(MessageConstant.FAIL_CODE);
                            res.setData(model);
                            response = new ResponseEntity<>(res, HttpStatus.OK);
                        }
                    } else {
                        res.setMsg("Merchant Not Present");
                        res.setStatusCode(MessageConstant.FAIL_CODE);
                        res.setData(null);
                        response = new ResponseEntity<>(res, HttpStatus.OK);
                    }
                } catch (Exception e) {
                    String errMsg = e.getMessage();
                    logger.error(errMsg, e);
                    res.setMsg(errMsg);
                    res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
                    response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } else {
                res.setMsg("Target Is Not Present In Master");
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            }
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getallpaymentMode(String mid, String tid, String dateFrom, String dateTo, Integer pageNo, Integer pageSize) {
        LOG.info("Calling getallpaymentMode API");
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {

            List<MerchantPaymentModeDetails> list = merchantMasterService.getMerchantDetailsByFilter(LogsUtility.trimDate(dateFrom), LogsUtility.trimDate(dateTo), mid, tid, pageNo, pageSize);

            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(list);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;

    }


    @Override
    public ResponseEntity<?> sendTargetMerchantMaster(TargetMerchantMasterModel model) {
        logger.info("Target Merchant Master Received in CM : {}", IsgJsonUtils.getJsonString(model));

        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        try {
//            Thread.sleep(5000);
            TargetMerchantMasterModel resultModel = null;
            if (model != null) {
                TargetMerchantMasterModel dbEntity = targetMerchantMasterService.findById(model.getTargetId(), model.getMid(), model.getTid());
                logger.info("Fetched Entity For Target : {} Is {} ", model.getTargetId(), dbEntity);
                if (dbEntity != null) {
                    if (!dbEntity.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                        model.setRetryCount(dbEntity.getRetryCount());
                        resultModel = targetMerchantMasterService.update(model);
                        logger.trace("Target Merchant Master Object Updated successfully in DB : ");
                    }
                } else {
                    model.setRetryCount(0);
                    resultModel = targetMerchantMasterService.add(model);
                    logger.trace("Target Merchant Master Object Added successfully in DB : ");
                }
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(resultModel);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg("No Data Received");
                res.setStatusCode(MessageConstant.FAIL_CODE);
                res.setData(null);
                response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getTargetMerchantMasterByDates(String fromDate, String toDate, Integer pageNo, Integer pageSize) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        List<TargetMerchantMasterResponseModel> models = new ArrayList<>();
        try {
            logger.info("Fetching Target Merchant Master by Dates : {}");
            String fDate = URLDecoder.decode(fromDate);
            String tDate = URLDecoder.decode(toDate);
            List<ActiveInactiveFlag> status= Arrays.asList(new ActiveInactiveFlag[] {ActiveInactiveFlag.Failed,ActiveInactiveFlag.Inprogress});
            List<TargetMerchantMasterEntity> entities = targetMerchantMasterService.getByFromDateToDate(trimIsoDate(fDate), trimIsoDate(tDate), pageNo, pageSize,status);
            int count = targetMerchantMasterService.getCountByFromDateToDate(trimIsoDate(fDate), trimIsoDate(tDate),status);
            if (entities != null && !entities.isEmpty()) {
                for (TargetMerchantMasterEntity entity : entities) {
                    models.add(TargetMerchantMasteUtility.getTargetMerchantMasterResponseModel(entity, count));
                }
            }
            if (models != null && !models.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(models);
            } else {
                res.setMsg("Data Not Found With Given Dates");
                res.setStatusCode(MessageConstant.FAIL_CODE);
                res.setData(null);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            logger.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> updateTargetMerchantMasterStatus(Long targetMerchantMasterId, String tid, String mid, Long targetId, String status) {
        logger.info("Calling API To Retry On Boarding API's For Target : {} , Mid : {} and Tid : {} ", targetId, mid, tid);
        ResponseEntity<?> response;
        ResponseObj res = new ResponseObj();
        try {
            TargetMerchantMasterModel model = null;
            targetMerchantMasterOnlineValidator.getByParamValidations(targetMerchantMasterId, mid, tid, targetId, ActiveInactiveFlag.getActiveInactiveFlag(status));
            targetMerchantMasterOfflineValidator.checkStatus(status);
            TargetMerchantMasterEntity targetMerchantMasterEntity = targetMerchantMasterService.getTargetMerchantMasterByParams(targetMerchantMasterId, mid, tid, targetId);
            if (targetMerchantMasterEntity != null) {
                targetMerchantMasterEntity.setStatus(ActiveInactiveFlag.getActiveInactiveFlag(status));
                targetMerchantMasterEntity = targetMerchantMasterService.save(targetMerchantMasterEntity);
                model = TargetMerchantMasteUtility.getTargetMerchantMasterModel(targetMerchantMasterEntity);
            }
            if (model != null) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            } else {
                res.setMsg("Data Not Found");
                res.setStatusCode(MessageConstant.FAIL_CODE);
            }
            res.setData(model);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = e.getMessage();
            logger.error(errMsg, e);
            res.setMsg(errMsg);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    public OffsetDateTime trimIsoDate(String input) {
        OffsetDateTime output = null;
        if (input != null && !input.equals("")) {
            try {
                ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(5, 30);
                OffsetDateTime parse = OffsetDateTime.parse(input.trim(), DateTimeFormatter.ISO_DATE_TIME);
                return parse.withOffsetSameInstant(gmtOffset);
            } catch (Exception ex) {
                LOG.trace(ex.getMessage(), ex);
            }
        }
        return output;
    }

    private void sendMerchantMasterModelToKafka(List<MerchantMasterModel> merchantMasterModels) {
        for (MerchantMasterModel merchantMasterModel : merchantMasterModels) {
            logger.info("Sending Merchant Master On Kafka : {}", merchantMasterModel);
            merchantMasterOnboardMessenger.sendMerchantMasterForOnboardReq(merchantMasterModel);
            logger.info("Send Merchant Master For Kafka successfully : {}", merchantMasterModel);
        }
    }


    @Override
    public ResponseEntity<?> removeMerchantPaymentModeOptions(Long merchantPaymentModeId, Long paymentModeOptionId) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        Boolean merchantPaymentModesFlag = false;
        try {
            merchantPayModeOptionsOfflineValidator.removeValidation(merchantPaymentModeId, paymentModeOptionId);
            merchantPayModeOptionsOnlineValidator.removeValidation(merchantPaymentModeId, paymentModeOptionId);
            ConfigAction action = ConfigAction.INACTIVE;
            sendMessageMerchantPayModeOption(merchantPaymentModeId, paymentModeOptionId, action);
            Boolean flag = merchantPayModeOptionMasterService.removeMerchantPaymentModeByGivenParams(merchantPaymentModeId, paymentModeOptionId);
            merchantPaymentModesFlag = removeMerchantPaymentMode(merchantPaymentModeId);
            if (merchantPaymentModesFlag) {
                res.setData("Merchant Payment Mode Removed For Given Merchant Payment Mode Id Because Options Are Not Present");
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            } else if (flag) {
                res.setData("Merchant Payment Mode  Option Removed For Given Merchant Payment Mode Id");
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            } else {
                res.setData("Enable TO Remove Merchant Payment Mode  Option Removed For Given Merchant Payment Mode Id");
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> removeMerchantPaymentMode(Long merchantMasterId, Long paymentModeId, String status) {
        ResponseEntity<?> response = null;
        ConfigAction action;
        ResponseObj res = new ResponseObj();
        try {
            ConfigStatus configStatus = ConfigStatus.getStatus(status);
            if (configStatus != null) {
                if (configStatus == ConfigStatus.Active) {
                    merchantPaymentModesOfflineValidator.removeValidation(merchantMasterId, paymentModeId);
                    merchantPaymentModesOnlineValidator.removeValidation(merchantMasterId, paymentModeId);
                    action = ConfigAction.INACTIVE;
                    MerchantPaymentModesModel merchantPaymentModesModel = merchantPaymentModesMasterService.findById(merchantMasterId, paymentModeId);
                    if (merchantPaymentModesModel != null) {
                        List<MerchantPaymentModeOptionsMasterEntity> merchantPaymentModeOptionsMasterEntities = merchantPayModeOptionMasterService.verifyByMerchantPaymentModeId(merchantPaymentModesModel.getMerchantPaymentModeId());
                        if (merchantPaymentModeOptionsMasterEntities != null && !merchantPaymentModeOptionsMasterEntities.isEmpty()) {
                            for (MerchantPaymentModeOptionsMasterEntity entity : merchantPaymentModeOptionsMasterEntities) {
                                logger.info("Removing Merchant Payment Mode Option For Given MerchantPaymentModeId:: {} and PaymentModeOptionId :: {}",entity.getMerchantPaymentModeId(),entity.getPaymentModeOptionId());
                                sendMessageMerchantPayModeOption(entity.getMerchantPaymentModeId(), entity.getPaymentModeOptionId(), ConfigAction.INACTIVE,ConfigStatus.Inactive);
                                merchantPayModeOptionMasterService.removeMerchantPaymentModeByGivenParams(entity.getMerchantPaymentModeId(), entity.getPaymentModeOptionId());
                            }
                        }
                    }
                    sendMessage(merchantMasterId, paymentModeId, action,ConfigStatus.Inactive);
                    Boolean flag = merchantPaymentModesMasterService.removeByMerchantMastIdAndPayModeId(merchantMasterId, paymentModeId);
                    if (flag) {
                        logger.info("Removed Merchant Payment Mode For Given MerchantMasterId:: " + merchantMasterId);
                        res.setData("Merchant Payment Mode Removed For Given Parameters");
                    } else {
                        res.setData("Enable TO Remove Merchant Payment Mode Removed For Given Parameters");
                    }
                } else if (configStatus == ConfigStatus.Inactive) {
                    MerchantMasterEntity merchantMaster = merchantMasterService.get(merchantMasterId);
                    action = ConfigAction.ACTIVATE;
                    MerchantPaymentModesModel model = null;
                    MerchantPaymentModesMasterEntity entity = merchantPaymentModesMasterService.verifyById(merchantMasterId, paymentModeId);
                    if(entity != null){
                        logger.info("Updating the Merchant Payment Modes model due to already present,for MerchantPaymentModeId :: {} ,PaymentModeId :: {} ",entity.getMerchantPaymentModeId(),entity.getPaymentModeId());
                        entity.setStatus(ConfigStatus.Active);
                    }else{
                        model = new MerchantPaymentModesModel();
                        model.setMerchantMasterId(merchantMasterId);
                        model.setPaymentModeId(paymentModeId);
                        model.setStartDate(OffsetDateTime.now().minusMinutes(5));
                        model.setEndDate(OffsetDateTime.now().plusMonths(Long.valueOf(paymentModeEndDate)));
                        model.setStatus(ConfigStatus.Active.name());
                        model.setEntityId(merchantMaster.getEntityId());
                        entity = MerchantPaymentModesMasterUtility.getMerchantPaymentModesMasterEntity(model);
                        logger.info("Inserting the Merchant Payment Mode model for PaymentModeId :: {} ",entity.getPaymentModeId());
                    }
                    MerchantPaymentModesMasterEntity masterEntity = merchantPaymentModesMasterService.save(entity);
                    if (masterEntity != null) {
                        sendMessage(merchantMasterId, paymentModeId, action,ConfigStatus.Active);
                        res.setData("Merchant Payment Mode Add For Given Parameters");
                    } else {
                        res.setData("Enable TO Add Merchant Payment Mode For Given Parameters");
                    }
                }
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
            } else {
                res.setData("Invalid Input");
                res.setMsg(MessageConstant.FAIL_DESC);
                res.setStatusCode(MessageConstant.FAIL_CODE);
            }
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> getMerchantMasterInfoByKey(ActiveInactiveFlag status, String key) {
        LOG.info("Calling GetMerchantMasterInfoByKey with status :{} and key :{} ",status,key);
        ResponseEntity<?> response = null;
        MerchantMasterModel masterModel = null;
        try {
            String[] keyElements = key.split("::");
            String entityId = keyElements[0];
            String mid = keyElements[1];
            LOG.info("Calling GetMerchantMasterInfoByKey with mid :{} and entityId :{} ",mid,entityId);
            if (status != null) {
                MerchantMasterModel merchantMasterModel = merchantMasterService.findById(mid);
                if(merchantMasterModel != null && merchantMasterModel.getEntityId().equals(entityId) && merchantMasterModel.getStatus() == status){
                    masterModel = merchantMasterModel;
                }
            } else {
                MerchantMasterModel merchantMasterModel = merchantMasterService.findById(mid);
                if(merchantMasterModel != null && merchantMasterModel.getEntityId().equals(entityId) && merchantMasterModel.getStatus() == ActiveInactiveFlag.Active){
                    masterModel = merchantMasterModel;
                }
            }
            if (masterModel != null) {
                response = new ResponseEntity<>(masterModel, HttpStatus.OK);
            } else {
                response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            LOG.info("GetMerchantMasterInfoByKey Api Response :{} ",response);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private Boolean removeMerchantPaymentMode(Long merchantPaymentModeId) {
        Boolean flag = false;
        List<MerchantPaymentModeOptionsMasterEntity> masterEntities = merchantPayModeOptionMasterService.verifyByMerchantPaymentModeId(merchantPaymentModeId);
        if (masterEntities != null && masterEntities.isEmpty()) {
            MerchantPaymentModesMasterEntity entity = merchantPaymentModesMasterService.getEntityByMerchantPayModeId(merchantPaymentModeId);
            sendMessage(entity.getMerchantMasterId(), entity.getPaymentModeId(), ConfigAction.INACTIVE);
            flag = merchantPaymentModesMasterService.removeByMerchantPayModeId(merchantPaymentModeId);
            return flag;
        }
        return flag;
    }

    private void sendMessage(Long merchantMasterId, Long paymentModeId, ConfigAction action,ConfigStatus updatedStatus) {
        MerchantPaymentModesMasterEntity masterEntity = merchantPaymentModesMasterService.verifyById(merchantMasterId, paymentModeId);
        MerchantPaymentModesModel model = MerchantPaymentModesMasterUtility.getMerchantPaymentModesModel(masterEntity);
        model.setStatus(updatedStatus.toString());
        MerchantMasterEntity merchantMasterEntity = merchantMasterService.get(masterEntity.getMerchantMasterId());
        MerchantMasterModel merchantMasterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMasterEntity);
        MerchantPaymentModesMessage merchantPayModeMessage = new MerchantPaymentModesMessage();
        merchantPayModeMessage.setAction(action);
        merchantPayModeMessage.setModel(model);
        merchantPayModeMessage.setMerchantMasterModel(merchantMasterModel);
        merchantPaymentModesMessenger.send(merchantPayModeMessage);
    }

    private void sendMessageMerchantPayModeOption(Long merchantPaymentModeId, Long paymentModeOptionId, ConfigAction action,ConfigStatus updatedStatus) {
        MerchantPaymentModeOptionsMasterEntity masterEntity = merchantPayModeOptionMasterService.verifyById(merchantPaymentModeId, paymentModeOptionId);
        MerchantPaymentModeOptionsModel model = MerchantPaymentModeOptionsMasterUtility.getMerchantPaymentModeOptionsModel(masterEntity);
        model.setStatus(updatedStatus.name());
        MerchantPaymentModesMasterEntity merchantPayModeEntity = merchantPaymentModesMasterService.getEntityByMerchantPayModeId(masterEntity.getMerchantPaymentModeId());
        MerchantPaymentModesModel merchantpaymentModesModel = MerchantPaymentModesMasterUtility.getMerchantPaymentModesModel(merchantPayModeEntity);
        MerchantPaymentModeOptionsMessage merchantPayModeOptionsMessage = new MerchantPaymentModeOptionsMessage();
        MerchantMasterEntity merchantMasterEntity = merchantMasterService.get(merchantPayModeEntity.getMerchantMasterId());
        MerchantMasterModel merchantMasterModel = MerchantMasterUtility.getMerchantMasterModel(merchantMasterEntity);
        merchantPayModeOptionsMessage.setAction(action);
        merchantPayModeOptionsMessage.setModel(model);
        merchantPayModeOptionsMessage.setMerchantPaymentModesModel(merchantpaymentModesModel);
        merchantPayModeOptionsMessage.setMerchantMasterModel(merchantMasterModel);
        merchantPaymentModeOptionsMessenger.send(merchantPayModeOptionsMessage);
    }

    @Override
    public ResponseEntity<?> getAllMerchantDetails(String mid, String tid, String transactionType, String fromDate, String toDate, Integer pageNo, Integer pageSize) {
        ResponseEntity<?> response = null;
        ResponseObj res = new ResponseObj();
        TargetMerchantMasterModels targetMerchantMasterModel = new TargetMerchantMasterModels();
        if(transactionType.equals("ALL"))
        {
            transactionType=null;
        }
        try {
            int merchantMasterCountDetails = 0;
            offlineValidation(mid, tid);

            merchantMasterCountDetails = merchantMasterService.getMerchantDataCount(mid, tid, transactionType,LogsUtility.trimDate(fromDate), LogsUtility.trimDate(toDate));
            List<MerchantMasterModel> modals = merchantMasterService.getMerchantData(mid, tid, transactionType,LogsUtility.trimDate(fromDate), LogsUtility.trimDate(toDate),pageNo, pageSize);
            LOG.info(merchantMasterCountDetails);
            if (!CollectionUtils.isEmpty(modals)) {
                for (MerchantMasterModel merchantMasterModel :modals) {

                    merchantMasterModel.setEndOfset(merchantMasterCountDetails);
                }
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(modals);
/*                targetMerchantMasterModel.setMerchantDetails(modals);
                res.setData(targetMerchantMasterModel);*/

                response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_DATA_FOUND);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                response = new ResponseEntity<>(res, HttpStatus.OK);
            }

        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message") ? e.getMessage() : errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);

        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return response;
    }

    private static void offlineValidation(String mid, String tid) {
        UserDataValidations.stringDataValidation(mid, "^[A-Za-z0-9]*$", "MID", false, 15);
        UserDataValidations.stringDataValidation(tid, "^[A-Za-z0-9]*$", "TID", false, 8);
    }


}
