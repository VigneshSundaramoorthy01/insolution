package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetPaymentModesAdditionalData;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import com.isg.mw.core.model.validation.DateValidation;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesMsgKeys;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service("targetPaymentModeOfflineValidator")
public class TargetPaymentModeOfflineValidatorImpl implements TargetPaymentModeOfflineValidator {
    @Override
    public void getValidations(Long targetId,Long paymentModeId,String integrationType) {
        UserDataValidations.longDataValidations(targetId, "TargetId", 18, true);
        UserDataValidations.longDataValidations(paymentModeId, "PaymentModeId", 18, true);
        UserDataValidations.stringDataValidation(integrationType, "^[A-Za-z_ ]*", "IntegrationType", false, 64);
    }

    @Override
    public void addValidation(TargetPaymentModesModel model) {
        UserDataValidations.longDataValidations(model.getTargetId(), "TargetId", 18, true);
        UserDataValidations.longDataValidations(model.getPaymentModeId(), "PaymentModeId", 18, true);
        UserDataValidations.stringDataValidation(model.getIntegrationType(), "^[A-Za-z_ ]*", "IntegrationType", false, 64);
        UserDataValidations.entityIdValidations(model.getEntityId(), true);
        DateValidation.startDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        additionalDataValidation(model.getAdditionalData());
    }

    @Override
    public void modifyValidation(TargetPaymentModesModel model) {
        UserDataValidations.longDataValidations(model.getTargetId(), FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeId(), FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.stringDataValidation(model.getIntegrationType(), "^[A-Za-z_ ]*", "IntegrationType", false, 64);
        UserDataValidations.stringDataValidation(model.getStatus(), "^[A-Za-z_ ]*", "status", false, 12);
        UserDataValidations.entityIdValidations(model.getEntityId(), true);
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        additionalDataValidation(model.getAdditionalData());
//        optionalDataCheck(model);
    }

    @Override
    public void submitValidation(Long targetId,Long paymentModeId,String integrationType) {
        UserDataValidations.longDataValidations(targetId, FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.stringDataValidation(integrationType, "^[A-Za-z_ ]*", "IntegrationType", false, 64);
    }

    @Override
    public void updateStatusValidation(Long targetId,Long paymentModeId,String integrationType, String status) {
        UserDataValidations.longDataValidations(targetId, FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.stringDataValidation(integrationType, "^[A-Za-z_ ]*", "IntegrationType", false, 64);
        UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.UPDATE_STATUS_VALUES,
                FieldsInfo.UPDATE_STATUS_FN, true);
    }

    @Override
    public void lockValidation(Long targetPaymentModeId, LockedState lockedState) {

    }


    @Override
    public void verifyValidation(Long targetId,Long paymentModeId,String integrationType,boolean approved,String remarks) {
        UserDataValidations.longDataValidations(targetId, FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
        UserDataValidations.stringDataValidation(integrationType, "^[A-Za-z_ ]*", "IntegrationType", false, 64);
        if (!approved && StringUtils.isBlank(remarks)) {
            throw new ValidationException("Remark is mandatory", FieldsInfo.REMARKS_FN);
        }
    }

    @Override
    public void getByTargetIdValidation(Long targetPaymentModeId) {
        if (targetPaymentModeId == 0) {
            throw new ValidationException(TargetPaymentModesMsgKeys.TPM_FIELD_IS_MANDATORY, FieldsInfo.SRC_ID_FN);
        }
    }

    @Override
    public void targetPayModeByStatusValidation(String status) {
        UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.CONFIG_BY_STATUS_VALUES,
                FieldsInfo.CONFIG_BY_STATUS_FN, true);
    }

    private void additionalDataValidation(TargetPaymentModesAdditionalData additionalData) {
        if(additionalData != null){
            UserDataValidations.stringDataValidation(additionalData.getStatusUrl(),null,"statusUrl",false,50);
        }
    }
}
