package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.PaymentModesSerializer;
import com.isg.mw.sr.mgmt.serializer.TargetLCRConfigSerializer;
import com.isg.mw.sr.mgmt.service.PaymentModesMessenger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("paymentModesMessenger")
public class PaymentModesMessengerImpl implements PaymentModesMessenger, InitializingBean, DisposableBean {
    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public PaymentModesMessengerImpl() {
    }

    @Override
    public void send(PaymentModesModel model) {
        setTraceIdForAllModels(model);
        producer.sendMessage(model);
    }

    private void setTraceIdForAllModels(PaymentModesModel model) {
        String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
        model.setAcpTraceId(acpTraceId);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getPaymentModesTopicName(), PaymentModesSerializer.class));
        producer.init();
    }
}
