package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.TargetPaymentModeOptionsMessage;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;

public interface TargetPaymentModeOptionsMessenger {

    void send (TargetPaymentModeOptionsMessage model);

}
