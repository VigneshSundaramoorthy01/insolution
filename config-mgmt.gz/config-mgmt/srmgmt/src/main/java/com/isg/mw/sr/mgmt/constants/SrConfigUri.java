package com.isg.mw.sr.mgmt.constants;

public interface SrConfigUri {

	/**
	 * Used for parent URI
	 */
	String PARENT = "/sr";
	
	/**
	 * Used for get API URI
	 */
	String GET_BY_ID = "/get";
	
	/**
	 * Used for getAll API URI
	 */
	String GET_ALL_ACTIVE = "/getallactive";
	
	/**
	 * Used for getAll API URI
	 */
	String GET_ALL = "/getall";
	
	/**
	 * Used for add API URI
	 */
	String ADD = "/add";
	
	/**
	 * Used for submit API URI
	 */
	String SUBMIT = "/submit";
	
	/**
	 * Used for save API URI
	 */
	String MODIFY = "/update";
	
	/**
	 * Used for verify API URI
	 */
	String VERIFY = "/verify";
	
	/**
	 * Used for update API URI
	 */
	String UPDATE_STATUS = "/changestatus";
	
	/**
	 * Used for lock API URI
	 */
	String LOCK = "/lock";
	
	/**
	 * Used for lock API URI
	 */
	String GET_BY_SOURCE_ID = "/getbysourceid";
	
	String GET_CONFIG_BY_STATUS="/getConfigByStatus";

}
