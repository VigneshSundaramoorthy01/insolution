package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.PaymentModesModel;

public interface PaymentModesMessenger {
    void send(PaymentModesModel model);
}
