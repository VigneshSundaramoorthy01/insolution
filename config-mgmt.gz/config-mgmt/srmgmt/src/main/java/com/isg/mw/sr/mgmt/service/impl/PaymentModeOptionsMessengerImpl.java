package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.PaymentModeOptionsSerializer;
import com.isg.mw.sr.mgmt.serializer.TargetLCRConfigSerializer;
import com.isg.mw.sr.mgmt.service.PaymentModeOptionsMessenger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("paymentModeOptionsMessenger")
public class PaymentModeOptionsMessengerImpl implements PaymentModeOptionsMessenger, InitializingBean, DisposableBean {

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public PaymentModeOptionsMessengerImpl() {
    }

    @Override
    public void send( PaymentModeOptionsModel model) {
        setTraceIdForAllModels(model);
        producer.sendMessage(model);
    }

    private void setTraceIdForAllModels(PaymentModeOptionsModel model) {
        String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
        model.setAcpTraceId(acpTraceId);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getPaymentModeOptionsTopicName(), PaymentModeOptionsSerializer.class));
        producer.init();
    }
}
