package com.isg.mw.sr.mgmt.constants;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

public interface MerchantMasterUri {

    /**
     * Used for parent URI
     */
    String PARENT = "/sr";

    /**
     * Used for get API URI
     */
    String GET_BY_ID = "/merchantMaster/get";

    /**
     * Used for getAll API URI
     */
    String GET_ALL = "/merchantMaster/getall";

    /**
     * Used for add API URI
     */
    String ADD = "/merchantMaster/add";


    /**
     * Used for save API URI
     */
    String MODIFY = "/merchantMaster/update";

    /**
     * Used for get merchant count
     */
    String GET_MERCHANT_COUNT = "/merchantMaster/allMerchantsCount";


    String ADD_MER_TRGT_PREF="/merchantTargetPreferences/add";

    String MODIFY_MER_TRGT_PREF = "/merchantTargetPreferences/update";

    String  GET_ALL_ACTIVE_MER_TRGT_PREF = "/merchantTargetPreferences/getAllActive";

    String GET_MER_TRGT_PREF_BY_ID = "/merchantTargetPreferences/get";
    String ADD_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/add";
    String MODIFY_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/update";

    String GET_ALL_ACTIVE_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/getAllActive";

    String GET_MERCHANT_PAYMENT_MODES_BY_ID = "/merchantPaymentModes/get";
    String GET_MERCHANT_PAYMENT_MODES_BY_MID_TID = "/merchantPaymentModes/getByMidTid";
    String SUBMIT_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/submit";
    String CHANGE_STATUS_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/changeStatus";
    String VERIFY_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/verify";
    String ADD_MERCHANT_PAYMENT_MODE_OPTIONS = "/merchantPaymentModeOptions/add";

    String MODIFY_MERCHANT_PAYMENT_MODE_OPTIONS = "/merchantPaymentModeOptions/update";

    String GET_ALL_ACTIVE_MERCHANT_PAYMENT_MODE_OPTIONS = "/merchantPaymentModeOptions/getAllActive";

    String GET_MERCHANT_PAYMENT_MODE_OPTIONS_BY_ID = "/merchantPaymentModeOptions/get";
    String SUBMIT_MERCHANT_PAYMENT_MODE_OPTIONS= "/merchantPaymentModeOptions/submit";
    String CHANGE_STATUS_MERCHANT_PAYMENT_MODE_OPTIONS = "/merchantPaymentModeOptions/changeStatus";
    String VERIFY_MERCHANT_PAYMENT_MODE_OPTIONS= "/merchantPaymentModeOptions/verify";

    String ADD_TARGET_MERCHANT_MASTER  = "/targetMerchantMaster/add";

    String SEND_TARGET_MERCHANT_MASTER  = "/targetMerchantMaster/sendTargetMerchantMaster";

    String GET_TARGET_MERCHANT_MASTER_BY_DATES  = "/targetMerchantMaster/getTargetMerchantMasterByDates";

    String MODIFY_TARGET_MERCHANT_MASTER  = "/targetMerchantMaster/update";

    String GET_TARGET_MERCHANT_MASTER_BY_ID  = "/targetMerchantMaster/get";

    String GET_ALL_TARGET_MERCHANT_MASTER  = "/targetMerchantMaster/getall";

    String GET_ALL_TARGET_MERCHANT_MASTER_COUNT  = "/targetMerchantMaster/getAllCount";

    String DELETE_MER_TRGT_PREF = "/merchantTargetPreferences/delete";
    String GET_MERCHANT_DETAILS = "/MerchantDetails" ;


    String GET_ALL_PAYMENTMODE = "/paymentModes/getallpaymentMode";
    String RUN = "/run";

    String UPDATE_TARGET_MERCHANT_MASTER_STATUS = "/targetMerchantMaster/updateTargetMerchantMasterStatus";

    String REMOVE_MERCHANT_PAYMENT_MODES_OPTION = "/merchantPaymentModeOptions/removeMerchantPaymentModeOptions";

    String REMOVE_MERCHANT_PAYMENT_MODES = "/merchantPaymentModes/removeMerchantPaymentMode";

    String GET_MERCHANT_INFO_BY_KEY= "/getMerchantMasterInfoByKey";

    String GET_ALL_MERCHANT_DETAILS = "/merchantMaster/getAllMerchantDetails";


}
