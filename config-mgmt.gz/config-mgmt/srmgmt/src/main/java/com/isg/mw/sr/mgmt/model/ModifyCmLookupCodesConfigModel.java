package com.isg.mw.sr.mgmt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;

@Getter
@Setter
@ApiModel(description = "ModifyCmLookupCodesConfigModel")
public class ModifyCmLookupCodesConfigModel {

    @ApiModelProperty(value = "lookupCodeId", required = true)
    private Long lookupCodeId;

    @ApiModelProperty(value = "lookupCode", required = true)
    private String lookupCode;



}
