package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.ConfigAction;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
@ApiModel(description = "AddMerchantTargetPreferencesModel")
public class AddMerchantTargetPreferencesModel {

    @ApiModelProperty(value = "merchantMasterId", required = true)
    private Long merchantMasterId;

    @ApiModelProperty(value = "targetId", required = true)
    private Long targetId;

    @ApiModelProperty(value = "paymentModeId", required = true)
    private Long paymentModeId;

    @ApiModelProperty(value = "mid", required = true)
    private String mid;

    @ApiModelProperty( value = "startDate",required = true)
    private OffsetDateTime startDate;

    @ApiModelProperty(value = "endDate",required = true)
    private OffsetDateTime endDate;

    @ApiModelProperty(value = "status", required = true)
    private ActiveInactiveFlag status;

}
