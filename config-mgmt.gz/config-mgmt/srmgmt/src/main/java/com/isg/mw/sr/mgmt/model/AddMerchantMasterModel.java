package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;

@Getter
@Setter
@ToString
@Data
@ApiModel(description = "AddMerchantMasterModel")
public class AddMerchantMasterModel {

    @ApiModelProperty(value = "mid", required = true)
    private String mid;

    @ApiModelProperty(value = "tid", required = true)
    private String tid;

    @ApiModelProperty(value = "merchantName")
    private String merchantName;

    @ApiModelProperty(value = "merchantEmail")
    private String merchantEmail;

    @ApiModelProperty(value = "merchantMobNo")
    private String merchantMobNo;

    @ApiModelProperty(value = "merchantAddress")
    private String merchantAddress;

    @ApiModelProperty(value = "merchantPincode")
    private Long merchantPincode;

    @ApiModelProperty(value = "entityId", required = true)
    private String entityId;

    @ApiModelProperty(value = "mcrEnabled")
    private String mcrEnabled;

    @ApiModelProperty(value = "mcrDefaultTargetId")
    private Long mcrDefaultTargetId;

    @ApiModelProperty(value = "secretKey")
    private String secretKey;

    @ApiModelProperty(value = "encryptionKey")
    private String encryptionKey;

    @ApiModelProperty(value = "convFeeFlag")
    private ActiveInactiveFlag convFeeFlag;

    @ApiModelProperty(value = "status")
    private ActiveInactiveFlag status;

    @ApiModelProperty(value = "merchantVpa")
    private String merchantVpa;

    @ApiModelProperty(value = "merchantStoreId")
    private String merchantStoreId;

    @ApiModelProperty(value = "accountNo")
    private String accountNo;

    @ApiModelProperty(value = "ownershipType")
    private String ownershipType;

    @ApiModelProperty(value = "merchantClass")
    private String merchantClass;

    @ApiModelProperty(value = "accessCode")
    private String accessCode;

    @ApiModelProperty(value = "bankName")
    private String bankName;

    @ApiModelProperty(value = "ifsc")
    private String ifsc;

    @ApiModelProperty(value = "accountType")
    private String accountType;

    @ApiModelProperty(value = "terminalType")
    private String terminalType;

    @ApiModelProperty(value = "terminalModel")
    private String terminalModel;

    @ApiModelProperty(value = "deviceSerialNo")
    private String deviceSerialNo;

    @ApiModelProperty(value = "valueAddedService")
    private String valueAddedService;

    @ApiModelProperty(value = "MCC_CODE")
    private String mccCode;

    //new

    @ApiModelProperty(value = "merchantSector")
    private String merchantSector;

    @ApiModelProperty(value = "gstNumber")
    private String gstNumber;

    @ApiModelProperty(value = "websiteURL")
    private String websiteURL;

    @ApiModelProperty(value = "panNumber")
    private String panNumber;

    @ApiModelProperty(value = "purposeOfPG")
    private String purposeOfPG;

    @ApiModelProperty(value = "contactPerson")
    private String contactPerson;

    @ApiModelProperty(value = "expectedNoOfTransactions")
    private String expectedNoOfTransactions;

    @ApiModelProperty(value = "averageTicketSize")
    private String averageTicketSize;

    @ApiModelProperty(value = "midCategory")
    private String midCategory;

    @ApiModelProperty(value = "entityType")
    private String entityType;

    @ApiModelProperty(value = "businessType")
    private String businessType;

    @ApiModelProperty(value = "productServices")
    private String productServices;

    @ApiModelProperty(value = "websiteStatus")
    private String websiteStatus;

    @ApiModelProperty(value = "termsAndConditions")
    private String termsAndConditions;

    @ApiModelProperty(value = "privacyPolicy")
    private String privacyPolicy;

    @ApiModelProperty(value = "refundsAndCancellationPolicy")
    private String refundsAndCancellationPolicy;

    @ApiModelProperty(value = "contactDetailsAvailable")
    private String contactDetailsAvailable;

    @ApiModelProperty(value = "productDetailAndPricingStructure")
    private String productDetailAndPricingStructure;

    @ApiModelProperty(value = "midType")
    private String midType;

    @ApiModelProperty(value = "merchantURL")
    private String merchantURL;

    @ApiModelProperty(value = "countryName")
    private String countryName;

    @ApiModelProperty(value = "integrationType")
    private String integrationType;

    @ApiModelProperty(value = "isOnboardEnable")
    private Boolean isOnboardEnable = false;

    @ApiModelProperty(value = "merchantCity")
    private String merchantCity;

    @ApiModelProperty(value = "merchantStateCode")
    private String merchantStateCode;

    @ApiModelProperty(value = "merchantShortCountryCode")
    private String merchantShortCountryCode;

    @ApiModelProperty(value = "turnover")
    private String turnover;

    @ApiModelProperty(value = "signatoryPan")
    private String signatoryPan;

    @ApiModelProperty(value = "riskApproved")
    private String riskApproved;

    @ApiModelProperty(value = "sbLanguage")
    private String sbLanguage;

    @ApiModelProperty(value = "emiAllowedFlag")
    private String emiAllowedFlag;

    @ApiModelProperty(value = "merchantState")
    private String merchantState;

    @ApiModelProperty(value = "tradingName")
    private String tradingName;

    @ApiModelProperty(value = "seNumber")
    private String seNumber;

    @ApiModelProperty(value = "authorizedSignerDateOfBirth")
    private String authorizedSignerDateOfBirth;
}
