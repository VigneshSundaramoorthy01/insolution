package com.isg.mw.sr.controller;


import com.isg.mw.sr.mgmt.constants.CmLookupCodeUri;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodesConfigModel;
import com.isg.mw.sr.mgmt.service.CmLookupCodesMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Smart Route Configuration", description = "Smart Route Configuration API's")
@RestController
@RequestMapping(value = CmLookupCodeUri.PARENT)
public class CmLookupCodeController {

    @Autowired
    private CmLookupCodesMgmtService cmLookupCodesMgmtService;

    @Operation(summary = "API To Add CM Lookup Code ", description = "In response will get CM Lookup Code" ,tags= {"CM Lookup Code"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = CmLookupCodeUri.ADD)
    public ResponseEntity<?> add(@RequestBody AddCmLookupCodesConfigModel model) {
        return cmLookupCodesMgmtService.add(model);
    }

    @Operation(summary = "API To Modify CM Lookup Code", description = "In response will get CM Lookup Code after update" ,tags= {"CM Lookup Code"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = CmLookupCodeUri.MODIFY)
    public ResponseEntity<?> modify(@RequestBody ModifyCmLookupCodesConfigModel model) {
        return cmLookupCodesMgmtService.modify(model);
    }

    @Operation(summary = "API To Get All CM Lookup Code", description = "In response will get all CM Lookup Code" ,tags= {"CM Lookup Code"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = CmLookupCodeUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAll() {
        return cmLookupCodesMgmtService.getAll();
    }

    @Operation(summary = "API To Get CM Lookup Code", description = "In response will get Payment Modes by given CM Lookup Code id" ,tags= {"CM Lookup Code"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = CmLookupCodeUri.GET_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestParam(value = "id",required = true) Long id) {
        return cmLookupCodesMgmtService.get(id);
    }

    @Operation(summary = "API To Add CM Lookup Code Values ", description = "In response will get CM Lookup Code Values" ,tags= {"CM Lookup Code Values"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = CmLookupCodeUri.ADD_LOOKUP_CODE_VALUES)
    public ResponseEntity<?> addLookupCodeValues(@RequestBody AddCmLookupCodeValuesConfigModel model) {
        return cmLookupCodesMgmtService.addLookupCodeValues(model);
    }

    @Operation(summary = "API To Modify CM Lookup Code VALUES", description = "In response will get CM Lookup Code VALUES after update" ,tags= {"CM Lookup Code VALUES"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = CmLookupCodeUri.UPDATE_LOOKUP_CODE_VALUES)
    public ResponseEntity<?> modifyLookupCodeValues(@RequestBody ModifyCmLookupCodeValuesConfigModel model) {
        return cmLookupCodesMgmtService.modifyLookupCodeValues(model);
    }

    @Operation(summary = "API To Get All CM Lookup Code Values", description = "In response will get all CM Lookup Code Values" ,tags= {"CM Lookup Code Values"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = CmLookupCodeUri.GET_ALL_LOOKUP_CODE_VALUES, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllLookupCodeValue() {
        return cmLookupCodesMgmtService.getAllLookupCodeValue();
    }

    @Operation(summary = "API To Get CM Lookup Code Values", description = "In response will get Payment Modes by given CM Lookup Code Values id" ,tags= {"CM Lookup Code Values"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = CmLookupCodeUri.GET_LOOKUP_CODE_VALUES_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getByLookupCodeValueId(@RequestParam(value = "id",required = true) Long id) {
        return cmLookupCodesMgmtService.getByLookupCodeValueId(id);
    }
}
