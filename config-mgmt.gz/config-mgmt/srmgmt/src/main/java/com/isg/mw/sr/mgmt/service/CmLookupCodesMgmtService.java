package com.isg.mw.sr.mgmt.service;

import com.isg.mw.sr.mgmt.model.AddCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodesConfigModel;
import org.springframework.http.ResponseEntity;

public interface CmLookupCodesMgmtService {
    ResponseEntity<?> add(AddCmLookupCodesConfigModel model);

    ResponseEntity<?> modify(ModifyCmLookupCodesConfigModel model);

    ResponseEntity<?> getAll();

    ResponseEntity<?> get(Long id);

    ResponseEntity<?> addLookupCodeValues(AddCmLookupCodeValuesConfigModel model);

    ResponseEntity<?> getAllLookupCodeValue();

    ResponseEntity<?> modifyLookupCodeValues(ModifyCmLookupCodeValuesConfigModel model);

    ResponseEntity<?> getByLookupCodeValueId(Long id);
}
