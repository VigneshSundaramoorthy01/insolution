package com.isg.mw.sr.mgmt.cache;

import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.Map;

@Configuration
public class ConfigRedisCacheUtil {
    private static final String KEY_SEPERATE = "::";

    private final ValueOperations<String, CacheTargetMerchantMaster> targetMerchantMasterList;

    private final RedisTemplate<String, CacheTargetMerchantMaster> targetMerchMasterRedisTemp;

    @Autowired
    public ConfigRedisCacheUtil(RedisTemplate<String, CacheTargetMerchantMaster> targetMerchMasterRedisTemp) {
        this.targetMerchMasterRedisTemp = targetMerchMasterRedisTemp;
        this.targetMerchantMasterList = targetMerchMasterRedisTemp.opsForValue();
    }

    public void putTargetMerchantMasterByMidTid(String targetId, String mid,String tid, CacheTargetMerchantMaster targetMerchantMasterKey) {
        this.targetMerchantMasterList.set(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + tid, targetMerchantMasterKey);
    }

    public void putTargetMerchantMasterData(String targetId, String mid,String status, CacheTargetMerchantMaster targetMerchantMasterKey) {
        this.targetMerchantMasterList.set(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + status , targetMerchantMasterKey);
    }

    public CacheTargetMerchantMaster getTargetMerchantMasterData(String targetId, String mid ,String status) {
        return this.targetMerchantMasterList.get(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + status);
    }


    public void removeTargetMerchantMasterData(String targetId, String mid, String status) {
        this.targetMerchMasterRedisTemp.delete(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + status);
    }

    public Boolean removeTargetMerchantMaster(String targetId, String mid,String tid) {
        return this.targetMerchMasterRedisTemp.delete(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + tid);
    }

    public CacheTargetMerchantMaster getTargetMerchantMaster(String targetId, String mid,String tid) {
        return this.targetMerchantMasterList.get(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + tid);
    }

    public String getTargetMid(String targetId, String mid,String tid) {
        CacheTargetMerchantMaster targetMerchantMasterKey = this.targetMerchantMasterList.get(targetId + KEY_SEPERATE + mid + KEY_SEPERATE + tid);
        return targetMerchantMasterKey != null ? targetMerchantMasterKey.getTargetMid() : null;
    }
}
