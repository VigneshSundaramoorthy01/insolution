package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.CmLookupCodeValuesModel;
import com.isg.mw.core.model.sr.CmLookupCodesModel;
import com.isg.mw.sr.mgmt.model.AddCmLookupCodeValuesConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyCmLookupCodeValuesConfigModel;

public class CmLookupCodeValuesMgmtUtility {

    private CmLookupCodeValuesMgmtUtility() {

    }

    public static CmLookupCodeValuesModel getCmLookupCodeValueModel(AddCmLookupCodeValuesConfigModel addModel) {
        CmLookupCodeValuesModel model = new CmLookupCodeValuesModel();
        model.setLookupCodeId(addModel.getLookupCodeId());
        model.setLookupCodeValue(addModel.getLookupCodeValue());
        return model;
    }

    public static CmLookupCodeValuesModel getLookupCodeValueModifyModel(ModifyCmLookupCodeValuesConfigModel modifyModel) {
        CmLookupCodeValuesModel model = new CmLookupCodeValuesModel();
        model.setLookupCodeValueId(modifyModel.getLookupCodeValueId());
        model.setLookupCodeId(modifyModel.getLookupCodeId());
        model.setLookupCodeValue(modifyModel.getLookupCodeValue());
        return model;
    }
}
