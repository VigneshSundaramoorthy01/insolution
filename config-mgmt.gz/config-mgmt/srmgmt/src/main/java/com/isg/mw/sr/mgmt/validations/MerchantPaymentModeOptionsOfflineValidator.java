package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsModel;

public interface MerchantPaymentModeOptionsOfflineValidator {
    void addValidation(MerchantPaymentModeOptionsModel model);

    void modifyValidation(MerchantPaymentModeOptionsModel model);

    void getValidations(Long merchantPayModeId,Long paymentModeOptionId);

    void updateStatusValidation(Long merchantPayModeId,Long paymentModeOptionId, String status);

    void submitValidation(Long merchantPayModeId,Long paymentModeOptionId);

    void verifyValidation(Long merchantPayModeId,Long paymentModeOptionId, boolean approved,String remarks);

    void removeValidation(Long merchantPayModeId,Long paymentModeOptionId);
}
