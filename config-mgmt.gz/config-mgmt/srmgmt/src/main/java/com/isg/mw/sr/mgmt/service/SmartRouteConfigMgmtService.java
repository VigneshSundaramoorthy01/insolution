package com.isg.mw.sr.mgmt.service;

import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sr.mgmt.model.AddSrConfigModel;
import com.isg.mw.sr.mgmt.model.ModifySrConfigModel;

public interface SmartRouteConfigMgmtService {

	ResponseEntity<?> get(Long id);

	ResponseEntity<?> getAllActive(String entityId);

	ResponseEntity<?> getAll(String entityId);
	
	ResponseEntity<?> getBySourceId(Long id);

	ResponseEntity<?> submit(Long id);

	ResponseEntity<?> lock(Long id, LockedState lockedState);

	ResponseEntity<?> verify(Long id, boolean approved,String remarks);

	ResponseEntity<?> updateStatus(Long id, String status);

	ResponseEntity<?> add(AddSrConfigModel addModel);

	ResponseEntity<?> modify(ModifySrConfigModel modifyModel);
	
	ResponseEntity<?> getConfigByStatus(String status);

}
