package com.isg.mw.sr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sr.mgmt.constants.SrConfigUri;
import com.isg.mw.sr.mgmt.model.AddSrConfigModel;
import com.isg.mw.sr.mgmt.model.ModifySrConfigModel;
import com.isg.mw.sr.mgmt.service.SmartRouteConfigMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Smart Route Configuration", description = "Smart Route Configuration API's")
@RestController
@RequestMapping(value = SrConfigUri.PARENT)
public class SmartRouteConfigMgmtController {

	@Autowired
	private SmartRouteConfigMgmtService srConfigMgmtService;

	@Operation(summary = "API To Get Smart Route configuration", description = "In response will get Smart Route configuration by given id" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SrConfigUri.GET_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> get(@PathVariable(value = "${swgr.sr.get.id.value}") @RequestParam(value = "id",required = true) Long id) {
		return srConfigMgmtService.get(id);
	}

	@Operation(summary = "API To Get All Active Smart Route configuration", description = "In response will get all Active Smart Route configuration" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SrConfigUri.GET_ALL_ACTIVE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllActive( @PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
		return srConfigMgmtService.getAllActive(entityId);
	}

	@Operation(summary = "API To Get All Smart Route configuration", description = "In response will get all Smart Route configuration" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SrConfigUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAll(@PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
		return srConfigMgmtService.getAll(entityId);
	}

	@Operation(summary = "API To Add Smart Route configuration", description = "In response will get Smart Route configuration" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = SrConfigUri.ADD)
	public ResponseEntity<?> add(@RequestBody AddSrConfigModel model) {
		return srConfigMgmtService.add(model);
	}

	@Operation(summary = "API To Modify Smart Route configuration", description = "In response will get Smart Route configuration after update" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = SrConfigUri.MODIFY)
	public ResponseEntity<?> modify(@RequestBody ModifySrConfigModel model) {
		return srConfigMgmtService.modify(model);
	}

	@Operation(summary = "API To Submit Smart Route configuration", description = "In response will get submit message" ,tags= {"Smart Route Configuration"})
	@GetMapping(value = SrConfigUri.SUBMIT)
	public ResponseEntity<?> submit(@PathVariable(value = "${swgr.sr.submit.sc.id.value}") @RequestParam(value = "srcId",required = true) Long srcId) {
		return srConfigMgmtService.submit(srcId);
	}

	@Operation(summary = "API To Change the Status Of Smart Route configuration", description = "In response will get status message" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = SrConfigUri.UPDATE_STATUS)
	public ResponseEntity<?> updateStatus(@PathVariable(value = "${swgr.sr.updatestatus.sc.id.value}") @RequestParam(value = "srcId",required = true) Long srcId
			,@PathVariable(value = "${swgr.sr.updatestatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return srConfigMgmtService.updateStatus(srcId, status);
	}

	@Operation(summary = "API To Lock Smart Route configuration", description = "In response will lock state of Smart Route configuration" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = SrConfigUri.LOCK)
	public ResponseEntity<?> lock(@PathVariable(value = "${swgr.sr.lock.sc.id.value}") @RequestParam(value = "srcId",required = true) Long srcId
			,@PathVariable(value = "${swgr.sr.lock.lockstate.value}") @RequestParam(value = "lockedState",required = true) LockedState ls) {
		return srConfigMgmtService.lock(srcId, ls);
	}

	@Operation(summary = "API To Verify Smart Route configuration", description = "In response will get approved status of Smart Route configuration" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = SrConfigUri.VERIFY)
	public ResponseEntity<?> verify(@PathVariable(required = true, value = "${swgr.sr.verify.sc.id.value}") @RequestParam(value = "srcId") Long srcId
			,@PathVariable(value = "${swgr.sr.verify.approved.value}") @RequestParam(value = "approved",required = true) boolean approved,
			@PathVariable(value = "${swgr.sr.verify.remarks.value}") @RequestParam(value = "remarks" ,required = false) String remarks) {
		return srConfigMgmtService.verify(srcId, approved,remarks);
	}

	@Operation(summary = "API To Get Smart Route configuration", description = "In response will get Smart Route configuration by given source id" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = SrConfigUri.GET_BY_SOURCE_ID)
	public ResponseEntity<?> getBySourceId(@PathVariable(value = "${swgr.sr.get.sc.id.value}") @RequestParam(value = "srcId",required = true) Long srcId) {
		return srConfigMgmtService.getBySourceId(srcId);
	}
	
	
	@Operation(summary = "API To Get Smart Route configuration", description = "In response will get Smart Route configuration by given status" ,tags= {"Smart Route Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = SrConfigUri.GET_CONFIG_BY_STATUS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getConfigByStatus(
			@PathVariable(value = "${swgr.sr.getConfigByStatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return srConfigMgmtService.getConfigByStatus(status);
	}


}
