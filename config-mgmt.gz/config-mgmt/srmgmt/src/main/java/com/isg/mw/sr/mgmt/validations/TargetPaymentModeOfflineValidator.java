package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;

public interface TargetPaymentModeOfflineValidator {

    void getValidations(Long targetId,Long paymentModeId,String integrationType);

    void addValidation(TargetPaymentModesModel model);

    void modifyValidation(TargetPaymentModesModel model);

    void submitValidation(Long targetId,Long paymentModeId,String integrationType);

    void updateStatusValidation(Long targetId,Long paymentModeId,String integrationType,String status);

    void lockValidation(Long targetPaymentModeId, LockedState lockedState);

    void verifyValidation(Long targetId,Long paymentModeId,String integrationType,boolean approved,String remarks);

    void getByTargetIdValidation(Long targetPaymentModeId);

    void targetPayModeByStatusValidation(String status);
}
