package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.AddMerchantPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyMerchantPaymentModeOptionsModel;

public class MerchantPaymentModeOptionsMgmtUtility {

    private MerchantPaymentModeOptionsMgmtUtility() {

    }
    public static MerchantPaymentModeOptionsModel getMerchantPayModeOptionsMgmtUtility(AddMerchantPaymentModeOptionsModel addModel) {

        MerchantPaymentModeOptionsModel model = new MerchantPaymentModeOptionsModel();
        model.setMerchantPaymentModeId(addModel.getMerchantPaymentModeId());
        model.setPaymentModeOptionId(addModel.getPaymentModeOptionId());
        model.setStartDate(addModel.getStartDate());
        model.setEndDate(addModel.getEndDate());
        model.setStatus(EditStatus.Inprogress.name());
        model.setAdditionalData(addModel.getAdditionalData());
        return model;
    }

    public static MerchantPaymentModeOptionsModel getMerchantPaymentModeOptionsModifyModel(ModifyMerchantPaymentModeOptionsModel modifyModel) {
        MerchantPaymentModeOptionsModel model = new MerchantPaymentModeOptionsModel();
        model.setMerchantPaymentModeId(modifyModel.getMerchantPaymentModeId());
        model.setPaymentModeOptionId(modifyModel.getPaymentModeOptionId());
        model.setStartDate(modifyModel.getStartDate());
        model.setEndDate(modifyModel.getEndDate());
        model.setAdditionalData(modifyModel.getAdditionalData());

        return model;
    }
}
