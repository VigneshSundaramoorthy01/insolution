package com.isg.mw.sr.mgmt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import java.time.OffsetDateTime;

@Getter
@Setter
@ApiModel(description = "ModifyPaymentModesModel")
public class ModifyPaymentModesModel {

    @ApiModelProperty(value = "paymentModeId", required = true)
    private Long paymentModeId;

    @ApiModelProperty(value = "paymentModeName", required = true)
    private String paymentModeName;

    @ApiModelProperty(value = "paymentModeDesc", required = true)
    private String paymentModeDesc;

}
