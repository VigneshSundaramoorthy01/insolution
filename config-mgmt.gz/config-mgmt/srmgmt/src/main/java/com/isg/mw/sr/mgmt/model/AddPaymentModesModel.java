package com.isg.mw.sr.mgmt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import java.time.OffsetDateTime;

@Getter
@Setter
@ApiModel(description = "${swgr.scc.model.add}")
public class AddPaymentModesModel {

    @ApiModelProperty(value = "${swgr.scc.model.add.paymentModeName.value}", required = true)
    private String paymentModeName;

    @ApiModelProperty(value = "${swgr.scc.model.add.paymentModeDesc.value}", required = true)
    private String paymentModeDesc;

   }
