package com.isg.mw.sr.mgmt.service.impl;

import com.isg.mw.core.model.constants.MessageConstant;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.dao.service.PaymentModeOnlineValidator;
import com.isg.mw.sr.dao.service.PaymentModeOptionsOnlineValidator;
import com.isg.mw.sr.dao.service.PaymentModeOptionsService;
import com.isg.mw.sr.dao.service.PaymentModesService;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import com.isg.mw.sr.mgmt.model.AddPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.AddPaymentModesModel;
import com.isg.mw.sr.mgmt.model.ModifyPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyPaymentModesModel;
import com.isg.mw.sr.mgmt.service.PaymentModeOptionsMessenger;
import com.isg.mw.sr.mgmt.service.PaymentModesMessenger;
import com.isg.mw.sr.mgmt.service.PaymentModesMgmtService;
import com.isg.mw.sr.mgmt.utils.PaymentModeOptionsMgmtUtility;
import com.isg.mw.sr.mgmt.utils.PaymentModesMgmtUtility;
import com.isg.mw.sr.mgmt.validations.PaymentModeOptionsOfflineValidator;
import com.isg.mw.sr.mgmt.validations.PaymentModesOfflineValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("PaymentModesMgmtService")
public class PaymentModesMgmtServiceImpl implements PaymentModesMgmtService {
    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private PaymentModesOfflineValidator payModesOfflineValidator;

    @Autowired
    private PaymentModeOnlineValidator paymentModeOnlineValidator;

    @Autowired
    private PaymentModeOptionsOfflineValidator payModeOptionsOfflineValidator;

    @Autowired
    private PaymentModeOptionsOnlineValidator payModeOptionsOnlineValidator;

    @Autowired
    private PaymentModeOptionsService payModeOptionsService;

    @Autowired
    private PaymentModesService paymentModesService;

    @Autowired
    private PaymentModesMessenger paymentModesMessenger;

    @Autowired
    private PaymentModeOptionsMessenger paymentModeOptionsMessenger;


    @Override
    public ResponseEntity<?> add(AddPaymentModesModel addModel) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            PaymentModesModel pmModel = PaymentModesMgmtUtility.getPaymentModesModel(addModel);
            payModesOfflineValidator.addValidation(pmModel);
            paymentModeOnlineValidator.addValidation(pmModel);
            PaymentModesModel resultModel = paymentModesService.add(pmModel);
            paymentModesMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modify(ModifyPaymentModesModel modifyModel) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            PaymentModesModel pmModel = PaymentModesMgmtUtility.getPaymentModesModifyModel(modifyModel);
            payModesOfflineValidator.modifyValidation(pmModel);
            paymentModeOnlineValidator.modifyValidation(pmModel);
            PaymentModesModel resultModel = paymentModesService.update(pmModel);
            paymentModesMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }



    @Override
    public ResponseEntity<?> getAll() {
        ResponseEntity<?> response = null;
        try {
            List<PaymentModesModel> allpayMode = paymentModesService.getAll();
            if (!allpayMode.isEmpty()) {
                response = new ResponseEntity<>(allpayMode, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;

    }

    @Override
    public ResponseEntity<?> get(Long id) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            payModesOfflineValidator.getValidations(id);
            paymentModeOnlineValidator.getValidations(id);
            Map<String, PaymentModesModel> map = new HashMap<>(2);
            PaymentModesModel master = paymentModesService.findById(id);
            if (master != null) {
                map.put("PaymentModesModel", master);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                 response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> addPayModeOptions(AddPaymentModeOptionsModel addmodel) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            PaymentModeOptionsModel pmoModel = PaymentModeOptionsMgmtUtility.getPaymentModesOptionModel(addmodel);
            payModeOptionsOfflineValidator.addValidation(pmoModel);
            payModeOptionsOnlineValidator.addValidation(pmoModel);
            PaymentModeOptionsModel resultModel =  payModeOptionsService.add(pmoModel);
            paymentModeOptionsMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
             response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Override
    public ResponseEntity<?> modifyPmo(ModifyPaymentModeOptionsModel modifyModel) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            PaymentModeOptionsModel pmoModel = PaymentModeOptionsMgmtUtility.getPayModeOptionModifyModel(modifyModel);
            payModeOptionsOfflineValidator.modifyValidation(pmoModel);
            payModeOptionsOnlineValidator.modifyValidation(pmoModel);
            PaymentModeOptionsModel resultModel = payModeOptionsService.update(pmoModel);
            paymentModeOptionsMessenger.send(resultModel);
            res.setMsg(MessageConstant.SUCCESS_DESC);
            res.setStatusCode(MessageConstant.SUCCESS_CODE);
            res.setData(resultModel);
            response = new ResponseEntity<>(res, HttpStatus.OK);
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
            response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
            response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    public ResponseEntity<?> getAllPmo() {

        ResponseEntity<?> response = null;
        try {
            List<PaymentModeOptionsModel> allpayModeOptions = payModeOptionsService.getAll();
            if (!allpayModeOptions.isEmpty()) {
                response = new ResponseEntity<>(allpayModeOptions, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.SR_LIST_EMPTY);
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;

    }


    public ResponseEntity<?> getPmo(Long id) {
        ResponseEntity<?> response = null;
        ResponseObj res =new ResponseObj();
        try {
            payModeOptionsOfflineValidator.getValidations(id);
            payModeOptionsOnlineValidator.getValidations(id);
            Map<String, PaymentModeOptionsModel> map = new HashMap<>(2);
            PaymentModeOptionsModel master = payModeOptionsService.findById(id);
            if (master != null) {
                map.put("PaymentModeOptionsModel", master);
            }
            if (!map.isEmpty()) {
                res.setMsg(MessageConstant.SUCCESS_DESC);
                res.setStatusCode(MessageConstant.SUCCESS_CODE);
                res.setData(map);
                 response = new ResponseEntity<>(res, HttpStatus.OK);
            } else {
                res.setMsg(MessageConstant.NO_CONTENT);
                res.setStatusCode(MessageConstant.FAIL_CODE);
                 response = new ResponseEntity<>(res, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            res.setMsg(errMsg.equals("Unknown message")?e.getMessage():errMsg);
            res.setStatusCode(MessageConstant.FAIL_CODE);
             response = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            res.setMsg(MessageConstant.INTERNAL_SERVER_ERROR);
            res.setStatusCode(MessageConstant.INTERNAL_SERVER_CODE);
             response = new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
