package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.sr.mgmt.model.AddTargetMerchantMasterModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetMerchantMasterModel;

public class TargetMerchantMasterMgmtUtility {
    public static TargetMerchantMasterModel getTargetMerchantMasterModel(AddTargetMerchantMasterModel addModel) {

        TargetMerchantMasterModel model = new TargetMerchantMasterModel();
        model.setMid(addModel.getMid());
        model.setTid(addModel.getTid());
        model.setTargetId(addModel.getTargetId());
        model.setTargetMid(addModel.getTargetMid());
        model.setMerchantVpa(addModel.getMerchantVpa());
        model.setStatus(addModel.getStatus());
        model.setKey(addModel.getKey());
        model.setSalt(addModel.getSalt());
        model.setExceptionMessage(addModel.getExceptionMessage());
        return model;
    }

    public static TargetMerchantMasterModel getTargetMerchantMasterModifyModel(ModifyTargetMerchantMasterModel modifyModel) {
        TargetMerchantMasterModel model = new TargetMerchantMasterModel();
        model.setMid(modifyModel.getMid());
        model.setTargetId(modifyModel.getTargetId());
        model.setTargetMid(modifyModel.getTargetMid());
        model.setMerchantVpa(modifyModel.getMerchantVpa());
        model.setStatus(modifyModel.getStatus());
        model.setKey(modifyModel.getKey());
        model.setSalt(modifyModel.getSalt());
        return model;

    }
}
