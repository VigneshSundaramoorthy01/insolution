package com.isg.mw.sr.controller;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.MerchantTypeModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.dao.service.BusinessTypeService;
import com.isg.mw.sr.dao.service.MerchantTypeService;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import com.isg.mw.sr.mgmt.constants.TargetLCRConfigUri;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "Merchant Type Configuration", description = "Merchant Type Configuration API's")
@RestController
@RequestMapping(value = "/MerchantTypeMapping")
public class MerchantTypeController {
    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private MerchantTypeService merchantTypeService;

    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = "/getall", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAll() {
        ResponseEntity<?> response = null;
        try {
            List<MerchantTypeModel> list = merchantTypeService.getAll();
            if (list != null && !list.isEmpty()) {
                response = new ResponseEntity<>(list, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Merchant Types Are empty");
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    @Operation(summary = "API To Get Merchant configuration", description = "In response will get Merchant configuration by given id", tags = {"Merchant Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = "getByMcc", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@PathVariable(value = "merchantType") @RequestParam(value = "merchantType", required = true) String merchantType) {
        ResponseEntity<?> response = null;
        try {
            MerchantTypeModel model = merchantTypeService.get(merchantType);
            if (model != null) {
                response = new ResponseEntity<>(model, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Merchant Types Not Found");
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message") ? e.getMessage() : errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
