package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.sr.TargetPaymentModeOptionsAdditionalData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@ApiModel(description = "${swgr.sr.modify.add}}")
@Getter
@Setter
public class ModifyTargetPaymentModeOptionsModel {

    @ApiModelProperty(required = true, value = "${swgr.sr.modify.add.paymentModeOptionId.value}")
    private Long paymentModeOptionId;

    @ApiModelProperty(required = true, value = "${swgr.sr.modify.add.targetPaymentModeId.value}")
    private Long targetPaymentModeId;

    @ApiModelProperty(required = true, value = "${swgr.sr.modify.add.startDate.value}")
    private String startDate;

    @ApiModelProperty(required = true, value = "${swgr.sr.modify.add.endDate.value}")
    private String endDate;

    @ApiModelProperty(required = true, value = "additionalData")
    private TargetPaymentModeOptionsAdditionalData additionalData;
}
