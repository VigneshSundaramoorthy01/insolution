package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.core.model.sr.PaymentModesModel;

public interface PaymentModeOptionsMessenger {
    void send(PaymentModeOptionsModel model);
}
