package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.sr.mgmt.model.*;
import org.springframework.http.ResponseEntity;

public interface MerchantMasterMgmtService {
    ResponseEntity<?> add(AddMerchantMasterModel model,Boolean isOnBoardingRequest,Boolean isModifyRequest);
    ResponseEntity<?> modify(ModifyMerchantMasterModel model);
    ResponseEntity<?> getAll(ActiveInactiveFlag status, Integer pageNo, Integer pageSize,String entityId,String[] integrationType );
    ResponseEntity<?> get(String mid);
    ResponseEntity<?> addMerchantTargetPreferences(AddMerchantTargetPreferencesModel model);
    ResponseEntity<?> modifyMerchantTargetPreferences(ModifyMerchantTargetPreferencesModel model);
    ResponseEntity<?> getAllActiveMerchantTrgPref();
    ResponseEntity<?> getMerchantTrgPref(Long merchantMasterId,Long targetId,Long paymentModeId,String mid);
    ResponseEntity<?> addMerchantPayModes(AddMerchantPaymentModesModel model);
    ResponseEntity<?> modifyMerchantPayModes(ModifyMerchantPaymentModesModel model);
    ResponseEntity<?> getAllActive(String[] status,String entityId);
    ResponseEntity<?> getMerchantPaymentModesById(Long merchantMasterId, Long paymentModeId);
    ResponseEntity<?> getMerchantPaymentModesByMidTid(String mid,String tid, String entityId);
    ResponseEntity<?> updateStatusMerchantPaymentModes(Long merchantMasterId, Long paymentModeId, String status,String remarks);
    ResponseEntity<?> submitMerchantPaymentModes(Long merchantMasterId, Long paymentModeId);
    ResponseEntity<?> verifyMerchantPaymentModes(Long merchantMasterId, Long paymentModeId, boolean approved,String remarks);
    ResponseEntity<?> addMerchantPayModeOptions(AddMerchantPaymentModeOptionsModel model);
    ResponseEntity<?> modifyMerchantPayModeOptions(ModifyMerchantPaymentModeOptionsModel model);
    ResponseEntity<?> submitMerchantPaymentModeOptions(Long merchantPaymentModeId,Long paymentModeOptionId);
    ResponseEntity<?> verifyMerchantPaymentModeOptions(Long merchantPaymentModeId,Long paymentModeOptionId, boolean approved,String remarks);
    ResponseEntity<?> updateStatusMerchantPaymentModeOptions(Long merchantPaymentModeId,Long paymentModeOptionId, String status,String remarks);

    ResponseEntity<?> getAllActiveMerchantPaymentModeOptions(String[] status);

    ResponseEntity<?> getMerchantPaymentModeOptionsById(Long merchantPaymentModeId,Long paymentModeOptionId);

    ResponseEntity<?> addTargetMerchantMaster(AddTargetMerchantMasterModel model);

    ResponseEntity<?> modifyTargetMerchantMaster(ModifyTargetMerchantMasterModel model);

    ResponseEntity<?> getAllTargetMerchantMaster(ActiveInactiveFlag status,String integrationType,Integer pageNo, Integer pageSize);

    ResponseEntity<?> getTargetMerchantMaster(Long targetId, String mid, String tid, String status);

    ResponseEntity<?> delete(Long id);

    ResponseEntity<?> getMerchantsCount(ActiveInactiveFlag merchantStatus,String entityId,String[] integrationType);

   // ResponseEntity<?> getMerchantDetails(String mid);
  
    ResponseEntity<?> getallpaymentMode(String mid,String tid, String dateFrom, String dateTo, Integer pageNo, Integer pageSize);

    ResponseEntity<?> getMerchantDetails(String mid, String tid,String entityId);

    ResponseEntity<?> runTargetMerchantMasterModel(Long targetMerchantMasterId, String tid, String mid, Long targetId);

    ResponseEntity<?> sendTargetMerchantMaster(TargetMerchantMasterModel addModel);

    ResponseEntity<?> getTargetMerchantMasterByDates(String fromDate,String toDate,Integer pageNo,Integer pageSize);

    ResponseEntity<?> updateTargetMerchantMasterStatus(Long targetMerchantMasterId, String tid, String mid, Long targetId, String status);

    ResponseEntity<?> getAllTargetMerchantMasterCount(ActiveInactiveFlag status, String integrationType);

    ResponseEntity<?> removeMerchantPaymentModeOptions(Long merchantPaymentModeId,Long paymentModeOptionId);

    ResponseEntity<?> removeMerchantPaymentMode(Long merchantMasterId, Long paymentModeId, String status);

    ResponseEntity<?> getMerchantMasterInfoByKey(ActiveInactiveFlag status,String mid);

    ResponseEntity<?> getAllMerchantDetails(String mid,String tid, String transactionType,String fromDate, String toDate, Integer pageNo, Integer pageSize);

}