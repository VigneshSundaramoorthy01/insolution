package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.PaymentFieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.springframework.stereotype.Service;


@Service("PaymentModeOptionsOfflineValidator")
public class PaymentModeOptionsOfflineValidatiorImpl implements PaymentModeOptionsOfflineValidator{



    public void addValidation(PaymentModeOptionsModel pmoModel) {
        UserDataValidations.stringDataValidation(pmoModel.getModeOptionName(), PaymentFieldsInfo.MODE_OPTION_NAME_EX, PaymentFieldsInfo.MODE_OPTION_NAME_FN, true,PaymentFieldsInfo.MODE_OPTION_NAME_FL);
        UserDataValidations.longDataValidations(pmoModel.getPaymentModeId(), PaymentFieldsInfo.PAY_MODE_ID,PaymentFieldsInfo.MODE_OPTION_ID_FL, true);
        UserDataValidations.stringDataValidation(pmoModel.getModeOptionDesc(),PaymentFieldsInfo.MODE_OPTION_DESC_EX,PaymentFieldsInfo.MODE_OPTION_DESC_FN,false,PaymentFieldsInfo.MODE_OPTION_DESC_FL);
    }


    public void modifyValidation(PaymentModeOptionsModel pmoModel) {
        UserDataValidations.stringDataValidation(pmoModel.getModeOptionName(), PaymentFieldsInfo.MODE_OPTION_NAME_EX, PaymentFieldsInfo.MODE_OPTION_NAME_FN, true,PaymentFieldsInfo.MODE_OPTION_NAME_FL);
        UserDataValidations.longDataValidations(pmoModel.getPaymentModeId(), PaymentFieldsInfo.PAY_MODE_ID,PaymentFieldsInfo.MODE_OPTION_ID_FL, true);
        UserDataValidations.stringDataValidation(pmoModel.getModeOptionDesc(),PaymentFieldsInfo.MODE_OPTION_DESC_EX,PaymentFieldsInfo.MODE_OPTION_DESC_FN,false,PaymentFieldsInfo.MODE_OPTION_DESC_FL);
    }


    public void getValidations(Long id) {
        if (id <= 0) {
            throw new ValidationException("Payment Modes Options field paymentModeOptionId is mandatory", PaymentFieldsInfo.MODE_OPTION_FN);
        }
    }


}
