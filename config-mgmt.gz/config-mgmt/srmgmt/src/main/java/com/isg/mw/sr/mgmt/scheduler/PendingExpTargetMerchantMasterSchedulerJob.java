package com.isg.mw.sr.mgmt.scheduler;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.sr.dao.service.MerchantMasterService;
import com.isg.mw.sr.dao.service.TargetMerchantMasterService;
import com.isg.mw.sr.dao.utils.MerchantMasterUtility;
import com.isg.mw.sr.mgmt.utils.GenerateCsvUtility;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
@Component
public class PendingExpTargetMerchantMasterSchedulerJob implements Runnable {
    private Logger logger = LogManager.getLogger();

    @Setter
    private TargetMerchantMasterService targetMerchantMasterService;

    @Setter
    private MerchantMasterService merchantMasterService;

    public PendingExpTargetMerchantMasterSchedulerJob() {
    }

    @Override
    public void run() {
        logger.info("Start Scheduler to fetch records for pending Exp status : ");
        List<TargetMerchantMasterModel> tgtMerchantMasterModels = targetMerchantMasterService.findByStatus(ActiveInactiveFlag.Pending_Exp);
        logger.info("Fetching Target Merchant Master For Pending Exp Status: {} ", tgtMerchantMasterModels.size());
        List<MerchantMasterModel> merchantMasterModels = new ArrayList<>();
        tgtMerchantMasterModels = tgtMerchantMasterModels.stream().
                filter(tmodel -> StringUtils.isBlank(tmodel.getTargetMid())).collect(Collectors.toList());
        if (!tgtMerchantMasterModels.isEmpty() && tgtMerchantMasterModels != null) {
            for (TargetMerchantMasterModel model : tgtMerchantMasterModels) {
                merchantMasterModels.add(MerchantMasterUtility.getMerchantMasterModel(merchantMasterService.getByUniqeMid(model.getMid(),model.getTid())));
            }
        }
        if(!tgtMerchantMasterModels.isEmpty() && tgtMerchantMasterModels != null
                && !merchantMasterModels.isEmpty() && merchantMasterModels != null) {
            try {
                generateCSVFile(merchantMasterModels,tgtMerchantMasterModels);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void generateCSVFile(List<MerchantMasterModel> merchantMasterModels, List<TargetMerchantMasterModel> tgtMerchantMasterModels)  {
        boolean flag = GenerateCsvUtility.buildCSVFile(merchantMasterModels);
        TargetMerchantMasterModel model;
        if(flag){
            for (TargetMerchantMasterModel tgtMerchantMasterModel : tgtMerchantMasterModels) {
                tgtMerchantMasterModel.setStatus(ActiveInactiveFlag.Exported.name());
                model = targetMerchantMasterService.update(tgtMerchantMasterModel);
                logger.info("Target Merchant Master status successfully  updated to Exported : {} {}", model.getTargetId(),model.getMid());
            }
        }
    }
}
