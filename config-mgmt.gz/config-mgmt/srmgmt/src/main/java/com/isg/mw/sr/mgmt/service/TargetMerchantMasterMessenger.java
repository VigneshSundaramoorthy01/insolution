package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.TargetMerchantMasterModel;

public interface TargetMerchantMasterMessenger {

    void send(TargetMerchantMasterModel resultModel);
}
