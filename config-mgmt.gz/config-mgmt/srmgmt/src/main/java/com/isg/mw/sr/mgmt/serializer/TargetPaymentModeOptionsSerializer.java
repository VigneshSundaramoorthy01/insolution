package com.isg.mw.sr.mgmt.serializer;

import com.isg.mw.core.model.sr.TargetPaymentModeOptionsMessage;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TargetPaymentModeOptionsSerializer  implements Serializer<TargetPaymentModeOptionsMessage> {

    private final Logger LOG = LoggerFactory.getLogger(TargetPaymentModeOptionsSerializer.class);

    @Override
    public byte[] serialize(String topic, TargetPaymentModeOptionsMessage data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(data);
            oos.flush();
        } catch (IOException e) {
            LOG.error("Error while serializing object: {}", e);
        }

        return bos.toByteArray();

    }

}
