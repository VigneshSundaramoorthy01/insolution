package com.isg.mw.sr.controller;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.mgmt.constants.SrConfigUri;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import com.isg.mw.sr.mgmt.constants.DemoSrTxnType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.net.Socket;
import java.util.Random;

@Tag(name = "Smart Route Configuration", description = "Smart Route Configuration API's")
@RestController
@RequestMapping(value = SrConfigUri.PARENT)
public class DemoSmartRouteConfigMgmtController {
    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private Environment env;

    @Operation(summary = "API To Get Smart Route configuration", description = "In response will get Smart Route configuration by given id", tags = {"Smart Route Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = "/smart-route-txn", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getSmartRouteTxn(@RequestParam(value = "type", required = false) DemoSrTxnType type) {
        return getSRTxn(type);
    }

    private ResponseEntity<?> getSRTxn(DemoSrTxnType type) {
        LOG.info("Calling sr/smart-route-txn api having type : {} and demoTargetModels : {} ", type);
        ResponseEntity<?> response = null;
        String resp = null;
        try {
            if(type == null){
                return new ResponseEntity<>("Input smart route txn type is invalid", HttpStatus.EXPECTATION_FAILED);
            }
            switch (type) {
                case SUCCESS_RATIO_STATIC:
                    String demoSrStaticIp = env.getProperty("demo.sr.static.ip.port");
                    resp = getConnection(getIp(demoSrStaticIp), getPort(demoSrStaticIp), getSalePacket());
                    break;
                case SUCCESS_RATIO_DYNAMIC:
                    String demoSrDynamicIp = env.getProperty("demo.sr.dynamic.ip.port");
                    resp = getConnection(getIp(demoSrDynamicIp), getPort(demoSrDynamicIp), getSalePacket());
                    break;
                case LEAST_COST:
                    String demoLeastCostIp = env.getProperty("demo.least.cost.ip.port");
                    resp = getConnection(getIp(demoLeastCostIp), getPort(demoLeastCostIp), getSalePacket());
                    break;
                default:
                    break;
            }
            if(resp != null){
                return new ResponseEntity<>("Transaction done successfully,RRN : "+getRRN(resp), HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    private String getRRN(String resp) throws UnsupportedEncodingException, DecoderException {
        String[] splitString = resp.split("0056", 3);
        String substring = splitString[2].substring(0, 24);
        byte[] bytes = Hex.decodeHex(substring.toCharArray());
        return new String(bytes, "UTF-8");
    }

    private int getPort(String ipWithPort) {
        return Integer.parseInt(ipWithPort.substring(ipWithPort.indexOf(':') + 1));
    }

    private String getIp(String ipWithPort) {
        return ipWithPort.substring(0, ipWithPort.indexOf(':'));
    }

    private String getSalePacket() {
        String stan = getRandomNumberString();
        LOG.info("Stan Value: "+stan);
        return "0146600056000002003020058020c01a06000000000000010000"+stan+"0051005600805eccdf7d2e8eb408af62208e82591d19869ab7c9fab435c7255467842fb73418d67bafcbc6a9ec02485059424c30303748505942494a414c495030303030373e07adbbc260f605098765432100000101459f02060000000100009f03060000000000008407a0000000031010820218009f36020ef39f0702ff809f2608a5f9a37f82ec36619f2701809f34034203009f1e0831333032393737349f100706010a03a0a8019f0902008c9f3303e0f0c89f1a0203569f350122950580800480005f2a0203565f3401019a032104219c01009f370493e618ff9f4104000007899f53015200123030303430363030303238350051303030363234313933333037333333323231303835373133303239373734303030353036303030303435303030313033333536";
    }


    public static String getRandomNumberString() {
        int number = new Random().nextInt(999999);
        if(number==1){
            number=+1;
        }
        return String.format("%06d", number);
    }

    public String getConnection(String host, int port, String strMessage) throws IOException {
        Socket clientSocket = null;
        String response = null;
        LOG.info("Attempting to connect : " + host + " ...");
        clientSocket = new Socket(host, port);
        LOG.info("Connected to the target : " + clientSocket.getRemoteSocketAddress());
        sendRequest(strMessage, clientSocket);
        response = getResponse(clientSocket);
        clientSocket.close();
        return response;
    }

    public void sendRequest(String str, Socket s) throws IOException {
        DataOutputStream out = new DataOutputStream(s.getOutputStream());
        out.write(hex2byte(str));
        out.flush();
        LOG.info("Request : " + str);
    }

    public String getResponse(Socket s) throws IOException {
        String response = null;
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        byte[] respBytes = br.readLine().getBytes();
        LOG.info("Response in bytes : " + respBytes);
        response = byte2hex(respBytes);
        LOG.info("Response : " + response);
        return response;
    }

    public static byte[] hex2byte (String s) {
        if (s.length() % 2 == 0) {
            return hex2byte (s.getBytes(), 0, s.length() >> 1);
        } else {
            // Padding left zero to make it even size #Bug raised by tommy
            return hex2byte("0"+s);
        }
    }

    public static byte[] hex2byte (byte[] b, int offset, int len) {
        byte[] d = new byte[len];
        for (int i=0; i<len*2; i++) {
            int shift = i%2 == 1 ? 0 : 4;
            d[i>>1] |= Character.digit((char) b[offset+i], 16) << shift;
        }
        return d;
    }

    public static String byte2hex(byte[] bs) {
        return byte2hex(bs, 0, bs.length);
    }

    public static String byte2hex(byte[] bs, int off, int length) {
        if (bs.length <= off || bs.length < off + length)
            throw new IllegalArgumentException();
        StringBuilder sb = new StringBuilder(length * 2);
        byte2hexAppend(bs, off, length, sb);
        return sb.toString();
    }

    private static void byte2hexAppend(byte[] bs, int off, int length, StringBuilder sb) {
        if (bs.length <= off || bs.length < off + length)
            throw new IllegalArgumentException();
        sb.ensureCapacity(sb.length() + length * 2);
        for (int i = off; i < off + length; i++) {
            sb.append(Character.forDigit(bs[i] >>> 4 & 0xf, 16));
            sb.append(Character.forDigit(bs[i] & 0xf, 16));
        }
    }
}
