package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.MerchantTargetPreferencesModel;

public interface MerchantTargetPreferencesOfflineValidation {

    void addValidation(MerchantTargetPreferencesModel model);

    void modifyValidation(MerchantTargetPreferencesModel model);
    void getValidations(Long merchantMasterId,Long targetId,Long paymentModeId);

}
