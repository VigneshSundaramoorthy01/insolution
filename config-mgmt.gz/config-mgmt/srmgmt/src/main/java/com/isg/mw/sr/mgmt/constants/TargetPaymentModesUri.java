package com.isg.mw.sr.mgmt.constants;

public interface TargetPaymentModesUri {

    /*     Used for parent URI
     */
    String PARENT = "/sr";

    /**
     * Used for get API URI
     */
    String GET_BY_ID = "/targetPaymentModes/get";

    /**
     * Used for getAll API URI
     */
    String GET_ALL_ACTIVE = "/targetPaymentModes/getallactive";

    /**
     * Used for getAll API URI
     */
    String GET_ALL = "/targetPaymentModes/getall";

    /**
     * Used for add API URI
     */
    String ADD = "/targetPaymentModes/add";

    /**
     * Used for submit API URI
     */
    String SUBMIT = "/targetPaymentModes/submit";

    /**
     * Used for save API URI
     */
    String MODIFY = "/targetPaymentModes/update";

    /**
     * Used for verify API URI
     */
    String VERIFY = "/targetPaymentModes/verify";

    /**
     * Used for update API URI
     */
    String CHANGE_STATUS = "/targetPaymentModes/changeStatus";




    /*
    Target Payment Mode Options
    */
    String GET_BY_ID_TPMO = "/targetPaymentModeOptions/get";

    /**
     * Used for getAll API URI
     */
    String GET_ALL_ACTIVE_TPMO = "/targetPaymentModeOptions/getallactive";

    /**
     * Used for add API URI
     */
    String ADD_TPMO = "/targetPaymentModeOptions/add";

    /**
     * Used for submit API URI
     */
    String SUBMIT_TPMO = "/targetPaymentModeOptions/submit";

    /**
     * Used for save API URI
     */
    String MODIFY_TPMO = "/targetPaymentModeOptions/update";

    /**
     * Used for verify API URI
     */
    String VERIFY_TPMO = "/targetPaymentModeOptions/verify";

    /**
     * Used for update API URI
     */
    String CHANGE_STATUS_TPMO = "/targetPaymentModeOptions/changeStatus";


}
