package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.sr.dao.entities.TargetPaymentModeOptionsEditCopyEntity;
import com.isg.mw.sr.dao.entities.TargetPaymentModesEditCopyEntity;
import com.isg.mw.sr.mgmt.model.AddTargetPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModesModel;

public class TargetPaymentModeOptionMgmtUtility {

    private TargetPaymentModeOptionMgmtUtility(){

    }


    public static TargetPaymentModeOptionsModel getTargetPaymentModesOptionsModel(AddTargetPaymentModeOptionsModel addModel) {

        TargetPaymentModeOptionsModel model = new TargetPaymentModeOptionsModel();
        model.setPaymentModeOptionId(addModel.getPaymentModeOptionId());
        model.setTargetPaymentModeId(addModel.getTargetPaymentModeId());
        model.setStartDate(DateFormatUtils.trimDate(addModel.getStartDate()));
        model.setEndDate(DateFormatUtils.trimDate(addModel.getEndDate()));
        model.setAdditionalData(addModel.getAdditionalData());
        return model;
    }

    /**
     * convert UpdateTargetPaymentModesModel to TargetPaymentModesModel
     *
     //     * @param updateModel - UpdateTargetPaymentModesModel
     * @return - TargetPaymentModesModel
     */
    public static TargetPaymentModeOptionsEditCopyEntity getTargetOptionsEditCopyEntity(TargetPaymentModeOptionsModel tpmModel) {
        TargetPaymentModeOptionsEditCopyEntity entity = new TargetPaymentModeOptionsEditCopyEntity();
        tpmModel.setPaymentModeOptionId(entity.getPaymentModeOptionId());
        tpmModel.setTargetPaymentModeId(entity.getTargetPaymentModeId());
        tpmModel.setTargetPayModeOptionId(entity.getTargetPayModeOptionId());
        tpmModel.setStartDate(entity.getStartDate());
        tpmModel.setEndDate(entity.getEndDate());
        return entity;
    }

    public static TargetPaymentModeOptionsModel getTargetPaymentModeOptionsModifyModel(ModifyTargetPaymentModeOptionsModel modifyModel) {
        TargetPaymentModeOptionsModel model = new TargetPaymentModeOptionsModel();
        model.setTargetPaymentModeId(modifyModel.getTargetPaymentModeId());
        model.setPaymentModeOptionId(modifyModel.getPaymentModeOptionId());
        model.setStartDate(DateFormatUtils.trimDate(modifyModel.getStartDate()));
        model.setEndDate(DateFormatUtils.trimDate(modifyModel.getEndDate()));
        model.setAdditionalData(modifyModel.getAdditionalData());
        return model;
    }

}
