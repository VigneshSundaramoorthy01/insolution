package com.isg.mw.sr.mgmt.service.impl;


import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.MerchantMasterSerializer;
import com.isg.mw.sr.mgmt.service.MerchantMasterMessenger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("merchantMasterMessenger")
public class MerchantMasterMessengerImpl implements MerchantMasterMessenger, InitializingBean, DisposableBean {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    public MerchantMasterMessengerImpl() {
    }

    @Override
    public void send(MerchantMasterModel model) {
        LOG.trace("Sending merchant master data on kafka having mid : {} and merchant status : {}  ", model.getMid(),
                model.getStatus());
        producer.sendMessage(model);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getMerchantMasterTopicName(), MerchantMasterSerializer.class));
        producer.init();
    }
}
