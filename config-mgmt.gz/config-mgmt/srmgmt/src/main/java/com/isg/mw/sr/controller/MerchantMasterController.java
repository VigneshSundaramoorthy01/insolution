package com.isg.mw.sr.controller;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.service.UserActivity;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.sr.mgmt.cache.ConfigRedisCacheUtil;
import com.isg.mw.sr.mgmt.constants.CmLookupCodeUri;
import com.isg.mw.sr.mgmt.constants.MerchantMasterUri;
import com.isg.mw.sr.mgmt.constants.PayModesUri;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesUri;
import com.isg.mw.sr.mgmt.model.*;
import com.isg.mw.sr.mgmt.service.MerchantMasterMgmtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Merchant Master Configuration", description = "Merchant Master Configuration API's")
@RestController
@RequestMapping(value = MerchantMasterUri.PARENT)
public class MerchantMasterController {

    @Autowired
    private MerchantMasterMgmtService merchantMasterMgmtService;

    @Autowired
    private ConfigRedisCacheUtil configRedisCacheUtil;


    @Operation(summary = "API To Add Merchant Master", description = "In response will get Merchant Master", tags = {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.ADD)
    public ResponseEntity<?> add(@RequestBody AddMerchantMasterModel model) {
        return merchantMasterMgmtService.add(model,false,false);
    }

    @Operation(summary = "API To Modify Merchant Master", description = "In response will get Merchant Master after update", tags = {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.MODIFY)
    public ResponseEntity<?> modify(@RequestBody ModifyMerchantMasterModel model) {
        return merchantMasterMgmtService.modify(model);

    }
    @Operation(summary = "API To Get All Merchant Master", description = "In response will get all Merchant Master" ,tags= {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAll(
            @PathVariable(value = "${swgr.get.all.merchant.status.value}") @RequestParam(value = "status", required = false,defaultValue = "Active") ActiveInactiveFlag status,
            @PathVariable(required = false) @RequestParam(defaultValue = "0",required = false) Integer pageNo,
            @PathVariable(required = false) @RequestParam(defaultValue = "1",required = false) Integer pageSize,
            @PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId,
            @RequestParam(value = "integrationType", required = false) String[] integrationType) {
        return merchantMasterMgmtService.getAll(status,pageNo,pageSize,entityId,integrationType);
    }

    @Operation(summary = "API To Get Merchant Master", description = "In response will get Merchant Master by given Merchant Master id" ,tags= {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestParam(value = "mid",required = true) String mid) {
        return merchantMasterMgmtService.get(mid);
    }

    @Operation(summary = "API To Get Merchants Count" ,description = "In response will get Merchants Count" ,tags= {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.GET_MERCHANT_COUNT)
    public ResponseEntity<?> getMerchantsCount(@RequestParam(value = "status", required = false) ActiveInactiveFlag status,
                                               @RequestParam(value = "entityId", required = false) String entityId,
                                               @RequestParam(value = "integrationType", required = false) String[] integrationType) {
        return merchantMasterMgmtService.getMerchantsCount(status,entityId,integrationType);
    }


    @Operation(summary = "API To Add Merchant Target Preferances", description = "In response will get Merchant Target Preferances", tags = {"Merchant Target Preferances"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.ADD_MER_TRGT_PREF)
    public ResponseEntity<?> add(@RequestBody AddMerchantTargetPreferencesModel model) {
        return merchantMasterMgmtService.addMerchantTargetPreferences(model);
    }

    @Operation(summary = "API To Modify Merchant Target Preferances", description = "In response will get Merchant Target Preferances after update", tags = {"Merchant Target Preferances"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.MODIFY_MER_TRGT_PREF)
    public ResponseEntity<?> modify(@RequestBody ModifyMerchantTargetPreferencesModel model) {
        return merchantMasterMgmtService.modifyMerchantTargetPreferences(model);

    }

    @Operation(summary = "API To Get All Merchant Target Preferances", description = "In response will get all Merchant Target Preferances" ,tags= {"Merchant Target Preferances"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_ACTIVE_MER_TRGT_PREF, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllActiveMerchantTrgPref() {
        return merchantMasterMgmtService.getAllActiveMerchantTrgPref();
    }

    @Operation(summary = "API To Get Merchant Target Preferances", description = "In response will get Merchant Target Preferances by given Merchant Target Preferances id" ,tags= {"Merchant Target Preferances"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_MER_TRGT_PREF_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getMerchantTrgPref(@RequestParam(value = "merchantMasterId",required = true) Long merchantMasterId,@RequestParam(value = "targetId",required = true) Long targetId,@RequestParam(value = "paymentModeId",required = true) Long paymentModeId,@RequestParam(value = "mid",required = true) String mid) {
        return merchantMasterMgmtService.getMerchantTrgPref(merchantMasterId,targetId,paymentModeId,mid);
    }


    @Operation(summary = "API To Delete Merchant Target Preferances", description = "In response will get success message after delete Message Format configuration" ,tags= {"Merchant Target Preferances"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.DELETE_MER_TRGT_PREF)
    public ResponseEntity<?> delete(
            @PathVariable(value = "mcPreferenceId") @RequestParam(value = "mcPreferenceId",required = true) Long mcPreferenceId) {
        return merchantMasterMgmtService.delete(mcPreferenceId
        );
    }

    @Operation(summary = "API To Add Merchant Payment Modes", description = "In response will get Merchant Payment Modes", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.ADD_MERCHANT_PAYMENT_MODES)
    public ResponseEntity<?> add(@RequestBody AddMerchantPaymentModesModel model) {
        return merchantMasterMgmtService.addMerchantPayModes(model);
    }


    @Operation(summary = "API To Modify Merchant Payment Modes", description = "In response will get Merchant Payment Modes after update", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.MODIFY_MERCHANT_PAYMENT_MODES)
    public ResponseEntity<?> modify(@RequestBody ModifyMerchantPaymentModesModel model) {
        return merchantMasterMgmtService.modifyMerchantPayModes(model);
}

    @Operation(summary = "API To Get All Merchant Payment Modes", description = "In response will get all Merchant Payment Modes", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_ACTIVE_MERCHANT_PAYMENT_MODES, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllActive(@PathVariable(value = "status") @RequestParam(value = "status", required = false) String[] status,@PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
        return merchantMasterMgmtService.getAllActive(status, entityId);
    }

    @Operation(summary = "API To Get Merchant Payment Modes", description = "In response will get Merchant Payment Modes by given id", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_MERCHANT_PAYMENT_MODES_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getMerchantPaymentModesById(@PathVariable(value = "merchantMasterId")
                                                             @RequestParam(value = "merchantMasterId", required = true) Long merchantMasterId
            ,@PathVariable(value = "paymentModeId")
                                                             @RequestParam(value = "paymentModeId", required = true) Long paymentModeId) {
        return merchantMasterMgmtService.getMerchantPaymentModesById(merchantMasterId,paymentModeId);
    }

    @Operation(summary = "API To Get Merchant Payment Modes", description = "In response will get Merchant Payment Modes by given mid and tid", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_MERCHANT_PAYMENT_MODES_BY_MID_TID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getMerchantPaymentModesByMidTid(@RequestParam(value = "mid", required = true) String mid,
                                                         @RequestParam(value = "tid", required = true) String tid,
                                                         @RequestParam(value = "entityId", required = true) String entityId) {
        return merchantMasterMgmtService.getMerchantPaymentModesByMidTid(mid,tid,entityId);
    }

    @Operation(summary = "API To Submit Merchant Payment Modes", description = "In response will get submit message", tags = {"Merchant Payment Modes"})
    @GetMapping(value = MerchantMasterUri.SUBMIT_MERCHANT_PAYMENT_MODES)
    public ResponseEntity<?> submit(@PathVariable(value = "merchantMasterId")
                                         @RequestParam(value = "merchantMasterId", required = true) Long merchantMasterId
            ,@PathVariable(value = "paymentModeId")
                                         @RequestParam(value = "paymentModeId", required = true) Long paymentModeId) {
        return merchantMasterMgmtService.submitMerchantPaymentModes(merchantMasterId,paymentModeId);
    }

    @Operation(summary = "API To Change the Status Of Merchant Payment Modes", description = "In response will get status message", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = MerchantMasterUri.CHANGE_STATUS_MERCHANT_PAYMENT_MODES)
    public ResponseEntity<?> updateStatus(@PathVariable(value = "merchantMasterId")
                                              @RequestParam(value = "merchantMasterId", required = true) Long merchantMasterId
            ,@PathVariable(value = "paymentModeId")
                                              @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
    @RequestParam(value = "status", required = true) String status,
                                          @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return merchantMasterMgmtService.updateStatusMerchantPaymentModes(merchantMasterId,paymentModeId, status,remarks);
    }

    @Operation(summary = "API To Verify Merchant Payment Modes", description = "In response will get status of Merchant Payment Modes", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = MerchantMasterUri.VERIFY_MERCHANT_PAYMENT_MODES)
    public ResponseEntity<?> verify(@PathVariable(value = "merchantMasterId")
                                        @RequestParam(value = "merchantMasterId", required = true) Long merchantMasterId
            ,@PathVariable(value = "paymentModeId")
                                        @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,@PathVariable(value = "approved")
                                        @RequestParam(value = "approved",required = true) boolean approved,
                                    @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return merchantMasterMgmtService.verifyMerchantPaymentModes(merchantMasterId,paymentModeId,approved,remarks);
    }

    @Operation(summary = "API To Add Merchant Payment Mode Options", description = "In response will get Merchant Payment Mode Options", tags = {"Merchant Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.ADD_MERCHANT_PAYMENT_MODE_OPTIONS)
    public ResponseEntity<?> add(@RequestBody AddMerchantPaymentModeOptionsModel model) {
        return merchantMasterMgmtService.addMerchantPayModeOptions(model);
    }

    @Operation(summary = "API To Modify Merchant Payment Mode Options", description = "In response will get Merchant Payment Mode Options after update", tags = {"Merchant Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.MODIFY_MERCHANT_PAYMENT_MODE_OPTIONS)
    public ResponseEntity<?> modify(@RequestBody ModifyMerchantPaymentModeOptionsModel model) {
        return merchantMasterMgmtService.modifyMerchantPayModeOptions(model);
    }

    @Operation(summary = "API To Submit Merchant Payment Mode Options", description = "In response will get submit message", tags = {"Merchant Payment Mode Options"})
    @GetMapping(value = MerchantMasterUri.SUBMIT_MERCHANT_PAYMENT_MODE_OPTIONS)
    public ResponseEntity<?> submitMerchantPaymentModeOptions(@PathVariable(value = "merchantPaymentModeId") @RequestParam(value = "merchantPaymentModeId", required = true) Long merchantPaymentModeId,
                                                              @PathVariable(value = "paymentModeOptionId") @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId) {
        return merchantMasterMgmtService.submitMerchantPaymentModeOptions(merchantPaymentModeId,paymentModeOptionId);
    }

    @Operation(summary = "API To Verify Merchant Payment Modes", description = "In response will get status of Merchant Payment Modes", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = MerchantMasterUri.VERIFY_MERCHANT_PAYMENT_MODE_OPTIONS)
    public ResponseEntity<?> verifyMerchantPaymentModeOptions(@PathVariable(value = "merchantPaymentModeId") @RequestParam(value = "merchantPaymentModeId", required = true) Long merchantPaymentModeId,
                                                              @PathVariable(value = "paymentModeOptionId") @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId,@PathVariable(value = "approved") @RequestParam(value = "approved",required = true) boolean approved
                                                              ,@PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks){
        return merchantMasterMgmtService.verifyMerchantPaymentModeOptions(merchantPaymentModeId,paymentModeOptionId,approved,remarks);
    }

    @Operation(summary = "API To Change the Status Of Merchant Payment Mode Options", description = "In response will get status message", tags = {"Merchant Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = MerchantMasterUri.CHANGE_STATUS_MERCHANT_PAYMENT_MODE_OPTIONS)
    public ResponseEntity<?> updateMerchantPaymentModeOptionsStatus(
            @PathVariable(value = "merchantPaymentModeId") @RequestParam(value = "merchantPaymentModeId", required = true) Long merchantPaymentModeId,
            @PathVariable(value = "paymentModeOptionId") @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId,@PathVariable(value = "status")
            @RequestParam(value = "status", required = true) String status,
            @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return merchantMasterMgmtService.updateStatusMerchantPaymentModeOptions(merchantPaymentModeId,paymentModeOptionId, status,remarks);
    }

    @Operation(summary = "API To Get All Target Payment Mode Options", description = "In response will get all Target Payment Mode Options", tags = {"Target Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_ACTIVE_MERCHANT_PAYMENT_MODE_OPTIONS, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllActiveMerchantPaymentModeOptions(@PathVariable(value = "status") @RequestParam(value = "status", required = false) String[] status) {
        return merchantMasterMgmtService.getAllActiveMerchantPaymentModeOptions(status);
    }

    @Operation(summary = "API To Get Merchant Payment Mode Options", description = "In response will get Merchant Payment Mode Options by given id", tags = {"Merchant Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_MERCHANT_PAYMENT_MODE_OPTIONS_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getMerchantPaymentModeOptionsById(@RequestParam(value = "merchantPaymentModeId",required = true) Long merchantPaymentModeId,@RequestParam(value = "paymentModeOptionId",required = true) Long paymentModeOptionId) {
        return merchantMasterMgmtService.getMerchantPaymentModeOptionsById(merchantPaymentModeId,paymentModeOptionId);
    }


    @Operation(summary = "API To Add Target Merchant Master", description = "In response will getTarget Merchant Master", tags = {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.ADD_TARGET_MERCHANT_MASTER)
    public ResponseEntity<?> add(@RequestBody AddTargetMerchantMasterModel model) {
        return merchantMasterMgmtService.addTargetMerchantMaster(model);
    }

    @Operation(summary = "API To Modify Target Merchant Master", description = "In response will get Target Merchant Master after update", tags = {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.MODIFY_TARGET_MERCHANT_MASTER)
    public ResponseEntity<?> modify(@RequestBody ModifyTargetMerchantMasterModel model) {
        return merchantMasterMgmtService.modifyTargetMerchantMaster(model);

    }

    @Operation(summary = "API To Get All Target Merchant Master", description = "In response will get all Target Merchant Master" ,tags= {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_TARGET_MERCHANT_MASTER, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllTargetMerchantMaster(@RequestParam(value = "status", required = false) ActiveInactiveFlag status,
                                                        @RequestParam(defaultValue = "PG",value = "integrationType", required = false) String integrationType,
                                                        @RequestParam(defaultValue = "0",required = false) Integer pageNo,
                                                        @RequestParam(defaultValue = "1",required = false) Integer pageSize) {
        return merchantMasterMgmtService.getAllTargetMerchantMaster(status,integrationType,pageNo,pageSize);
    }

    @Operation(summary = "API To Get count of  All Target Merchant Master", description = "In response will get count of all Target Merchant Master" ,tags= {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_TARGET_MERCHANT_MASTER_COUNT, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllTargetMerchantMasterCount(@RequestParam(value = "status", required = true) ActiveInactiveFlag status,
                                                        @RequestParam(defaultValue = "PG",value = "integrationType", required = false) String integrationType){
        return merchantMasterMgmtService.getAllTargetMerchantMasterCount(status,integrationType);
    }

    @Operation(summary = "API To Get Target Merchant Master", description = "In response will get Merchant Master by given Target Merchant Master id" ,tags= {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_TARGET_MERCHANT_MASTER_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getTargetMerchantMaster(@RequestParam(value = "targetId",required = true) Long targetId,@RequestParam(value = "mid",required = true) String mid,
    @RequestParam(value = "tid",required = false) String tid,@RequestParam(value = "status",required = false) String status) {
        return merchantMasterMgmtService.getTargetMerchantMaster(targetId,mid,tid,status);
    }


//    @Operation(summary = "API To Get Target Merchant Master", description = "In response will get Merchant Master by given Target Merchant Master id" ,tags= {"Target Merchant Master"})
//    @ApiResponses(value = {
//            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
//            @ApiResponse(responseCode = "404", description = "Not Found !!"),
//            @ApiResponse(responseCode = "500", description = "Internal Error"),
//            @ApiResponse(responseCode = "403", description = "Forbidden Error")
//    })
//    @CrossOrigin(methods = RequestMethod.DELETE)
//    @DeleteMapping(path = "/targetMerchantMaster/delete", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<?> deleteTargetMerchantMaster(@RequestParam(value = "targetId",required = true) Long targetId,@RequestParam(value = "mid",required = true) String mid,
//                                                     @RequestParam(value = "tid",required = false) String tid,@RequestParam(value = "status",required = false) String status) {
//        Boolean merchantMaster= false;
//        if (!StringUtils.isBlank(tid)) {
//            merchantMaster = configRedisCacheUtil.removeTargetMerchantMaster(targetId.toString(), mid, tid);
//        } else if (!StringUtils.isBlank(status)) {
//            merchantMaster = configRedisCacheUtil.removeTargetMerchantMasterData(targetId.toString(), mid, status);
//        }
//        return new ResponseEntity<>(merchantMaster, HttpStatus.OK);
//
//    }

    @UserActivity
    @Operation(summary = "API To Get Merchant details", description = "In response will get merchant details", tags = {"Merchant details"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_MERCHANT_DETAILS)
    public ResponseEntity<?> getMerchantDetails(
            @RequestParam(value = "mid", required = false) String mid,
            @RequestParam(value = "tid", required = false) String tid,
            @RequestParam(value = "entityId", required = false) String entityId) {
        return merchantMasterMgmtService.getMerchantDetails(mid,tid,entityId);
    }

    @Operation(summary = "API To Get All Available Payment Modes", description = "In response will get all available Payment Modes" ,tags= {"Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_PAYMENTMODE , produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllPaymentMode(
            @RequestParam(value = "fromDate",required = true) String dateFrom,
            @RequestParam(value = "toDate",required = true) String dateTo,
            @RequestParam(value = "MID",required = true) String mid,
            @RequestParam(value = "TID" ,required = true) String tid,
            @RequestParam(defaultValue = "0", required = false) Integer pageNo,
            @RequestParam(defaultValue = "1", required = false) Integer pageSize) {
        return merchantMasterMgmtService.getallpaymentMode(mid,tid,dateFrom,dateTo,pageNo,pageSize);
    }



    @Operation(summary = "API To update Active status from pending in Merchant Master", description = "In response will get Target Merchant Master", tags = {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.RUN)
    public ResponseEntity<?> run(
            @RequestParam(value = "targetMerchantMasterId",required = false) Long targetMerchantMasterId,
            @RequestParam(value = "tid" ,required = true) String tid,
            @RequestParam(value = "mid",required = true) String mid,
            @RequestParam(value = "targetId" ,required = false) Long targetId) {
        return merchantMasterMgmtService.runTargetMerchantMasterModel(targetMerchantMasterId, tid, mid, targetId);
    }

    @Operation(summary = "API To Consume Target Merchant Master from MW", description = "In response will getTarget Merchant Master", tags = {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.SEND_TARGET_MERCHANT_MASTER)
    public ResponseEntity<?> sendTargetMerchantMaster(@RequestBody TargetMerchantMasterModel model) {
        return merchantMasterMgmtService.sendTargetMerchantMaster(model);
    }

    @Operation(summary = "API To Get Target Merchant Master from DB By Dates", description = "In response will getTarget Merchant Master list", tags = {"Target Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.GET_TARGET_MERCHANT_MASTER_BY_DATES)
    public ResponseEntity<?> getTargetMerchantMasterByDates(
            @RequestParam(value = "fromDate", required = true) String fromDate,
            @RequestParam(value = "toDate", required = true) String toDate,
            @RequestParam(defaultValue = "0",required = false) Integer pageNo,
            @RequestParam(defaultValue = "1",required = false) Integer pageSize
    ) {
        return merchantMasterMgmtService.getTargetMerchantMasterByDates(fromDate, toDate,pageNo,pageSize);
    }

    @Operation(summary = "API To update Target Merchant Master Merchant Master", description = "In response will get Update Target Merchant Master", tags = {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.UPDATE_TARGET_MERCHANT_MASTER_STATUS)
    public ResponseEntity<?> updateTargetMerchantMasterStatus(
            @RequestParam(value = "targetMerchantMasterId", required = true) Long targetMerchantMasterId,
            @RequestParam(value = "mid", required = true) String mid,
            @RequestParam(value = "tid", required = true) String tid,
            @RequestParam(value = "targetId", required = true) Long targetId,
            @RequestParam(value = "status", required = true) String status
    ) {
        return merchantMasterMgmtService.updateTargetMerchantMasterStatus(targetMerchantMasterId, tid, mid, targetId, status);
    }


    @Operation(summary = "API To Remove Merchant Payment Modes Option", description = "In response will get status message", tags = {"Merchant Payment Modes Option"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @GetMapping(value = MerchantMasterUri.REMOVE_MERCHANT_PAYMENT_MODES_OPTION)
    public ResponseEntity<?> removeMerchantPaymentModeOptions(@PathVariable(value = "merchantPaymentModeId") @RequestParam(value = "merchantPaymentModeId", required = true) Long merchantPaymentModeId,
                                                              @PathVariable(value = "paymentModeOptionId") @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId) {
        return merchantMasterMgmtService.removeMerchantPaymentModeOptions(merchantPaymentModeId,paymentModeOptionId);
    }

    @Operation(summary = "API To Remove Merchant Payment Modes", description = "In response will get status message", tags = {"Merchant Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @GetMapping(value = MerchantMasterUri.REMOVE_MERCHANT_PAYMENT_MODES)
    public ResponseEntity<?> removeMerchantPaymentMode(@RequestParam(value = "merchantMasterId", required = true) Long merchantMasterId,
                                                       @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                                       @RequestParam(value = "status", required = true) String status) {
        return merchantMasterMgmtService.removeMerchantPaymentMode(merchantMasterId, paymentModeId,status);
    }

    @Operation(summary = "API To Get Map Info Configuration", description = "In response will get Map Info Configuration by given merchantStatus and key" ,tags= {"Map Info Configuration"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = MerchantMasterUri.GET_MERCHANT_INFO_BY_KEY)
    public ResponseEntity<?> getMap(
            @RequestParam(value = "status", required = false) ActiveInactiveFlag status,
            @RequestParam(defaultValue= "entityId::mid",  required = true) String key) {
        return merchantMasterMgmtService.getMerchantMasterInfoByKey(status, key);
    }

    @Operation(summary = "API To Get All Merchant Details", description = "In response will get All Merchant Details" ,tags= {"Merchant Master"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = MerchantMasterUri.GET_ALL_MERCHANT_DETAILS, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllMerchantDetails(@RequestParam(value = "mid",required = false) String mid,
                                                   @RequestParam(value = "tid",required = false) String tid,
                                                   @RequestParam(value = "transactionType",required = false) String transactionType,
                                                   @RequestParam(value = "fromDate",required = false) String fromDate,
                                                   @RequestParam(value = "toDate",required = false) String toDate,
                                                   @RequestParam(defaultValue = "0", required = false) Integer pageNo,
                                                   @RequestParam(defaultValue = "1", required = false) Integer pageSize) {

        return merchantMasterMgmtService.getAllMerchantDetails(mid,tid,transactionType,fromDate,toDate,pageNo,pageSize);
    }

}