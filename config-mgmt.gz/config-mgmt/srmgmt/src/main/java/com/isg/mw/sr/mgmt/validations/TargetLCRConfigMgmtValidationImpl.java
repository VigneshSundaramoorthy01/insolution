package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.TargetLCRFieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.TargetLCRConfigModel;
import com.isg.mw.core.model.validation.DateValidation;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.core.utils.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.TimeZone;

@Service("targetLCRConfigMgmtValidationImpl")
public class TargetLCRConfigMgmtValidationImpl implements TargetLCRConfigOfflineValidation {
    @Override
    public void addValidation(TargetLCRConfigModel model) {
        UserDataValidations.longDataValidations(model.getTargetId(), TargetLCRFieldsInfo.TARGET_ID_FN, TargetLCRFieldsInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeId(), TargetLCRFieldsInfo.PAYMENT_MODE_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeOptionId(), TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FL, true);
        UserDataValidations.stringDataValidation(model.getCardType(), TargetLCRFieldsInfo.ANS_EX, TargetLCRFieldsInfo.CARD_TYPE_FN, false, TargetLCRFieldsInfo.CARD_TYPE_FL);
        UserDataValidations.stringDataValidation(model.getMccCategory(), TargetLCRFieldsInfo.ANS_EX, TargetLCRFieldsInfo.MCC_CATGORY_FN, false, TargetLCRFieldsInfo.MCC_CATGORY_FL);
        UserDataValidations.doubleDataValidations(model.getPricePct(),TargetLCRFieldsInfo.PRICE_PCT_FL, TargetLCRFieldsInfo.PRICE_PCT_FN, false);
        UserDataValidations.doubleDataValidations(model.getPriceFixed(),TargetLCRFieldsInfo.PRICE_FIXED_FL, TargetLCRFieldsInfo.PRICE_FIXED_FN, false);
        UserDataValidations.doubleDataValidations(model.getBelow2000PricePct(),TargetLCRFieldsInfo.BELOW_2000_PRICE_PCT_FL, TargetLCRFieldsInfo.BELOW_2000_PRICE_PCT_FN, false);
        UserDataValidations.doubleDataValidations(model.getBelow2000PriceFixed(),TargetLCRFieldsInfo.BELOW_2000_PRICE_FIXED_FL, TargetLCRFieldsInfo.BELOW_2000_PRICE_FIXED_FN, false);
        UserDataValidations.entityIdValidations(model.getEntityId(), true);
        DateValidation.startDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
    }

    @Override
    public void getValidations(Long targetId,Long paymentModeId ,Long paymentModeOptionId) {
        UserDataValidations.longDataValidations(targetId, TargetLCRFieldsInfo.TARGET_ID_FN, TargetLCRFieldsInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FL, true);
    }

    @Override
    public void submitValidation(Long targetId,Long paymentModeId ,Long paymentModeOptionId) {
        UserDataValidations.longDataValidations(targetId, TargetLCRFieldsInfo.TARGET_ID_FN, TargetLCRFieldsInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FL, true);
    }

    @Override
    public void modifyValidation(TargetLCRConfigModel model) {
        UserDataValidations.longDataValidations(model.getTargetId(), TargetLCRFieldsInfo.TARGET_ID_FN, TargetLCRFieldsInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeId(), TargetLCRFieldsInfo.PAYMENT_MODE_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FL, true);
        UserDataValidations.longDataValidations(model.getPaymentModeOptionId(), TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FL, true);
        UserDataValidations.stringDataValidation(model.getCardType(), TargetLCRFieldsInfo.ANS_EX, TargetLCRFieldsInfo.CARD_TYPE_FN, false, TargetLCRFieldsInfo.CARD_TYPE_FL);
        UserDataValidations.stringDataValidation(model.getMccCategory(), TargetLCRFieldsInfo.ANS_EX, TargetLCRFieldsInfo.MCC_CATGORY_FN, false, TargetLCRFieldsInfo.MCC_CATGORY_FL);
        UserDataValidations.doubleDataValidations(model.getPricePct(),TargetLCRFieldsInfo.PRICE_PCT_FL, TargetLCRFieldsInfo.PRICE_PCT_FN, false);
        UserDataValidations.doubleDataValidations(model.getPriceFixed(),TargetLCRFieldsInfo.PRICE_FIXED_FL, TargetLCRFieldsInfo.PRICE_FIXED_FN, false);
        UserDataValidations.doubleDataValidations(model.getBelow2000PricePct(),TargetLCRFieldsInfo.BELOW_2000_PRICE_PCT_FL, TargetLCRFieldsInfo.BELOW_2000_PRICE_PCT_FN, false);
        UserDataValidations.doubleDataValidations(model.getBelow2000PriceFixed(),TargetLCRFieldsInfo.BELOW_2000_PRICE_FIXED_FL, TargetLCRFieldsInfo.BELOW_2000_PRICE_FIXED_FN, false);
        UserDataValidations.entityIdValidations(model.getEntityId(), true);
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));    }

    @Override
    public void updateStatusValidation(Long targetId,Long paymentModeId ,Long paymentModeOptionId, String status) {
        UserDataValidations.longDataValidations(targetId, TargetLCRFieldsInfo.TARGET_ID_FN, TargetLCRFieldsInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FL, true);
        UserDataValidations.stringPreDefiendDataValidation(status, TargetLCRFieldsInfo.UPDATE_STATUS_VALUES,
                TargetLCRFieldsInfo.UPDATE_STATUS_FN, true);
    }

    @Override
    public void verifyValidation(Long targetId,Long paymentModeId,Long paymentModeOptionId,boolean approved,String remarks) {
        UserDataValidations.longDataValidations(targetId, TargetLCRFieldsInfo.TARGET_ID_FN, TargetLCRFieldsInfo.TARGET_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeId, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_ID_FL, true);
        UserDataValidations.longDataValidations(paymentModeOptionId, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FN, TargetLCRFieldsInfo.PAYMENT_MODE_OPTION_ID_FL, true);
        if (!approved && StringUtils.isBlank(remarks)) {
            throw new ValidationException("Remark is mandatory", FieldsInfo.REMARKS_FN);
        }
    }

}
