package com.isg.mw.sr.mgmt.scheduler;

import com.isg.mw.maps.dao.service.MapsInfoService;
import com.isg.mw.sr.dao.service.MerchantMasterService;
import com.isg.mw.sr.dao.service.TargetMerchantMasterService;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
@PropertySource("${spring.config.location}application-uat.properties")
public class TargetMerchantMasterScheduler implements ApplicationRunner {

    private Logger logger = LogManager.getLogger();

    private ScheduledExecutorService executor;

    @Autowired
    private FailedTargetMerchantMasterSchedulerJob failedTargetMerchantMasterSchedulerJob;

    @Autowired
    private PendingExpTargetMerchantMasterSchedulerJob pendingExpTargetMerchantMasterSchedulerJob;

    @Autowired
    private TargetMerchantMasterService targetMerchantMasterService;

    @Autowired
    private MerchantMasterService merchantMasterService;

    @Autowired
    private TargetConfigMasterService targetConfigMasterService;


    @Autowired
    private MapsInfoService mapsInfoService;

    @Value("${target.merchant.master.thread.pool.size:1}")
    private Integer targetMerchantMasterThreadPoolSize;

    @Value("${target.merchant.master.delay:60000}")
    private Integer delay;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        scheduleTaskForFailedStatus();
//        scheduleTaskForPendingExpStatus();
    }

    public void scheduleTaskForFailedStatus() {
        executor = Executors.newScheduledThreadPool(targetMerchantMasterThreadPoolSize);
        failedTargetMerchantMasterSchedulerJob.setTargetMerchantMasterService(targetMerchantMasterService);
        failedTargetMerchantMasterSchedulerJob.setMerchantMasterService(merchantMasterService);
        failedTargetMerchantMasterSchedulerJob.setMapsInfoService(mapsInfoService);
        failedTargetMerchantMasterSchedulerJob.setTargetConfigMasterService(targetConfigMasterService);
        executor.scheduleWithFixedDelay(failedTargetMerchantMasterSchedulerJob, Long.valueOf(delay), Long.valueOf(delay), TimeUnit.MILLISECONDS);
    }

//    public void scheduleTaskForPendingExpStatus() {
//        executor = Executors.newScheduledThreadPool(targetMerchantMasterThreadPoolSize);
//        pendingExpTargetMerchantMasterSchedulerJob.setTargetMerchantMasterService(targetMerchantMasterService);
//        pendingExpTargetMerchantMasterSchedulerJob.setMerchantMasterService(merchantMasterService);
//        executor.scheduleAtFixedRate(pendingExpTargetMerchantMasterSchedulerJob, Long.valueOf(delay), Long.valueOf(delay), TimeUnit.MILLISECONDS);
//    }

    public void stopScheduledTask() {
        executor.shutdownNow();
    }
}
