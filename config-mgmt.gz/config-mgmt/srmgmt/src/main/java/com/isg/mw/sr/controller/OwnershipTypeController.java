package com.isg.mw.sr.controller;

import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.dao.entities.OwnershipTypeEntity;
import com.isg.mw.sr.dao.service.BusinessTypeService;
import com.isg.mw.sr.dao.service.OwnershipTypeService;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Tag(name = "Ownership Type Configuration", description = "Ownership Type Configuration API's")
@RestController
@RequestMapping(value = "/ownershipType")
public class OwnershipTypeController {
    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private OwnershipTypeService ownershipTypeService;

    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = "/getall", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAll(@RequestParam(value = "paymentSource", required = true) String paymentSource) {
        ResponseEntity<?> response = null;
        Map<String, String> map = null;
        try {
            if("lyra".equalsIgnoreCase(paymentSource)) {
                map = ownershipTypeService.getLyraOwnershipTypes();
            }else if("upi".equalsIgnoreCase(paymentSource)){
                map = ownershipTypeService.getUpiOwnershipTypes();
            }else if("tpsl".equalsIgnoreCase(paymentSource)){
                map = ownershipTypeService.getTpslEntityTypes();
            }

            if (map != null && !map.isEmpty()) {
                response = new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Ownership Types Are empty");
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }


    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = "/getOwnershipType", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getOwnershipType(@RequestParam(value = "consCode", required = true) String consCode,
                                              @RequestParam(value = "paymentSource", required = true) String paymentSource) {
        ResponseEntity<?> response;
        String ownerType = null;
        try {
            OwnershipTypeEntity ownershipType = ownershipTypeService.getOwnershipType(consCode);
            if (ownershipType != null) {
                if ("lyra".equalsIgnoreCase(paymentSource)) {
                    ownerType = ownershipType.getLyraOwnershipType();
                } else if ("upi".equalsIgnoreCase(paymentSource)) {
                    ownerType = ownershipType.getUpiOwnershipType();
                } else if ("tpsl".equalsIgnoreCase(paymentSource)) {
                    ownerType = ownershipType.getTpslEntityType();
                }
            } else {
                if ("lyra".equalsIgnoreCase(paymentSource) || "tpsl".equalsIgnoreCase(paymentSource)) {
                    ownerType = "Others";
                } else if ("upi".equalsIgnoreCase(paymentSource)) {
                    ownerType = "OTHERS";
                }
            }
            if (ownerType != null) {
                response = new ResponseEntity<>(ownerType, HttpStatus.OK);
            } else {
                response = new ResponseEntity<>(null, HttpStatus.OK);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
