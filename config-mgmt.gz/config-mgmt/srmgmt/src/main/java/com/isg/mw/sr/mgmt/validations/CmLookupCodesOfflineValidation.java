package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.CmLookupCodeValuesModel;
import com.isg.mw.core.model.sr.CmLookupCodesModel;

public interface CmLookupCodesOfflineValidation {
    void addValidation(CmLookupCodesModel lookupmodel);

    void modifyValidation(CmLookupCodesModel lookupModel);

    void getValidations(Long id);


}
