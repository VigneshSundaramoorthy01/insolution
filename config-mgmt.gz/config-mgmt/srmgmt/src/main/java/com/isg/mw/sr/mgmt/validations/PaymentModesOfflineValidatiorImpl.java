package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.PaymentFieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.springframework.stereotype.Service;

@Service("PaymentModesOfflineValidator")
public class PaymentModesOfflineValidatiorImpl implements PaymentModesOfflineValidator{

    @Override
    public void addValidation(PaymentModesModel model) {
        UserDataValidations.stringDataValidation(model.getPaymentModeName(), PaymentFieldsInfo.PAYMENT_MODE_NAME_EX, PaymentFieldsInfo.PAYMENT_MODE_NAME_FN, true,PaymentFieldsInfo.PAYMENT_MODE_NAME_FL);
        UserDataValidations.stringDataValidation(model.getPaymentModeDesc(),PaymentFieldsInfo.PAYMENT_MODE_DESC_EX,PaymentFieldsInfo.PAYMENT_MODE_DESC_FN,false,PaymentFieldsInfo.PAYMENT_MODE_DESC_FL);
    }

    @Override
    public void modifyValidation(PaymentModesModel model) {
        UserDataValidations.stringDataValidation(model.getPaymentModeName(), PaymentFieldsInfo.PAYMENT_MODE_NAME_EX, PaymentFieldsInfo.PAYMENT_MODE_NAME_FN, true,PaymentFieldsInfo.PAYMENT_MODE_NAME_FL);
        UserDataValidations.stringDataValidation(model.getPaymentModeDesc(),PaymentFieldsInfo.PAYMENT_MODE_DESC_EX,PaymentFieldsInfo.PAYMENT_MODE_DESC_FN,false,PaymentFieldsInfo.PAYMENT_MODE_DESC_FL);
    }

    @Override
    public void getValidations(Long id) {
        if (id <= 0) {
            throw new ValidationException("Payment Modes field paymentModeId is mandatory", PaymentFieldsInfo.PAY_MODE_ID);
        }
    }



}
