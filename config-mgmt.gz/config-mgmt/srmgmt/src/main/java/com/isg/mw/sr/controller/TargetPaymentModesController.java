package com.isg.mw.sr.controller;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sr.dao.service.TargetPaymentModesEditCopyService;
import com.isg.mw.sr.mgmt.constants.SrConfigUri;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModeOptionsUri;
import com.isg.mw.sr.mgmt.constants.TargetPaymentModesUri;
import com.isg.mw.sr.mgmt.model.*;
import com.isg.mw.sr.mgmt.service.SmartRouteConfigMgmtService;
import com.isg.mw.sr.mgmt.service.TargetPaymentModeOptionService;
import com.isg.mw.sr.mgmt.service.TargetPaymentModeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Target Payment Modes", description = "Target Payment Modes API's")
@RestController

@RequestMapping(value = TargetPaymentModesUri.PARENT)
public class TargetPaymentModesController {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private Environment env;

    @Autowired
    private TargetPaymentModeService trgtPaymentModeService;

    @Autowired
    private TargetPaymentModeOptionService targetPaymentModeOptionService;

    @Operation(summary = "API To Get Target Payment Modes", description = "In response will get Target Payment Modes by given id", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = TargetPaymentModesUri.GET_BY_ID, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestParam(value = "targetId", required = true) Long targetId,
                                 @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                 @RequestParam(value = "integrationType", required = true) String integrationType) {
        return trgtPaymentModeService.get(targetId,paymentModeId,integrationType);
    }

    @Operation(summary = "API To Get All Target Payment Modes", description = "In response will get all Target Payment Modes", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = TargetPaymentModesUri.GET_ALL_ACTIVE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllActive(@PathVariable(value = "status") @RequestParam(value = "status", required = false) String[] status,@PathVariable(value = "entityId") @RequestParam(value = "entityId", required = false) String entityId) {
        return trgtPaymentModeService.getAllActive(status,entityId);
    }

    @Operation(summary = "API To Add Target Payment Modes", description = "In response will get Target Payment Modes", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = TargetPaymentModesUri.ADD)
    public ResponseEntity<?> add(@RequestBody AddTargetPaymentModesModel model) {
        return trgtPaymentModeService.add(model);
    }

    @Operation(summary = "API To Modify Target Payment Modes", description = "In response will get Target Payment Modes after update", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = TargetPaymentModesUri.MODIFY)
    public ResponseEntity<?> modify(@RequestBody ModifyTargetPaymentModesModel model) {
        return trgtPaymentModeService.modify(model);
    }

    @Operation(summary = "API To Submit Target Payment Modes", description = "In response will get submit message", tags = {"Target Payment Modes"})
    @GetMapping(value = TargetPaymentModesUri.SUBMIT)
    public ResponseEntity<?> submit(@RequestParam(value = "targetId", required = true) Long targetId,
                                    @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                    @RequestParam(value = "integrationType", required = true) String integrationType) {
        return trgtPaymentModeService.submit(targetId,paymentModeId,integrationType);
    }

    @Operation(summary = "API To Change the Status Of Target Payment Modes", description = "In response will get status message", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = TargetPaymentModesUri.CHANGE_STATUS)
    public ResponseEntity<?> updateStatus(@RequestParam(value = "targetId", required = true) Long targetId,
                                          @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                          @RequestParam(value = "integrationType", required = true) String integrationType,
                                          @RequestParam(value = "status", required = true) String status,
                                          @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return trgtPaymentModeService.updateStatus(targetId,paymentModeId,integrationType,status,remarks);
    }

    @Operation(summary = "API To Verify Target Payment Modes", description = "In response will get status of Target Payment Modes", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = TargetPaymentModesUri.VERIFY)
    public ResponseEntity<?> verify(@RequestParam(value = "targetId", required = true) Long targetId,
                                    @RequestParam(value = "paymentModeId", required = true) Long paymentModeId,
                                    @RequestParam(value = "integrationType", required = true) String integrationType,
                                    @RequestParam(value = "approved", required = true) boolean approved,
                                    @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return trgtPaymentModeService.verify(targetId,paymentModeId,integrationType,approved,remarks);
    }


   /*
   Target Payment Mode Options API
    */

    @Operation(summary = "API To Add Target Payment Mode Options", description = "In response will get Target Payment Mode Options", tags = {"Target Payment Modes Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = TargetPaymentModesUri.ADD_TPMO)
    public ResponseEntity<?> add(@RequestBody AddTargetPaymentModeOptionsModel model) {
        return targetPaymentModeOptionService.add(model);
    }


    @Operation(summary = "API To Modify Target Payment Mode Options", description = "In response will get Target Payment Mode Options after update", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
    @PostMapping(path = TargetPaymentModesUri.MODIFY_TPMO)
    public ResponseEntity<?> modify(@RequestBody ModifyTargetPaymentModeOptionsModel model) {
        return targetPaymentModeOptionService.modify(model);
    }

    @Operation(summary = "API To Submit Target Payment Mode Options", description = "In response will get submit message", tags = {"Target Payment Mode Options"})
    @GetMapping(value = TargetPaymentModesUri.SUBMIT_TPMO)
    public ResponseEntity<?> submit(@RequestParam(value = "targetPaymentModeId", required = true) Long targetPaymentModeId,
                                    @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId) {
        return targetPaymentModeOptionService.submit(targetPaymentModeId,paymentModeOptionId);
    }


    @Operation(summary = "API To Verify Target Payment Mode Options", description = "In response will get status of Target Payment Mode Options", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = TargetPaymentModesUri.VERIFY_TPMO)
    public ResponseEntity<?> verify(@RequestParam(value = "targetPaymentModeId", required = true) Long targetPaymentModeId,
                                    @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId,
                                    @RequestParam(value = "approved", required = true) boolean approved,
                                    @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return targetPaymentModeOptionService.verify(targetPaymentModeId,paymentModeOptionId,approved,remarks);
    }



    @Operation(summary = "API To Change the Status Of Target Payment Mode Options", description = "In response will get status message", tags = {"Target Payment Modes"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(value = TargetPaymentModesUri.CHANGE_STATUS_TPMO)
    public ResponseEntity<?> updateStatus(@RequestParam(value = "targetPaymentModeId", required = true) Long targetPaymentModeId,
                                          @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId,
                                          @RequestParam(value = "status", required = true) String status,
                                          @PathVariable(value = "remarks") @RequestParam(value = "remarks" ,required = false) String remarks) {
        return targetPaymentModeOptionService.updateStatus(targetPaymentModeId,paymentModeOptionId,status,remarks);
    }



    @Operation(summary = "API To Get Target Payment Modes", description = "In response will get Target Payment Mode Options by given id", tags = {"Target Payment Mode Option"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = TargetPaymentModesUri.GET_BY_ID_TPMO, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestParam(value = "targetPaymentModeId", required = true) Long targetPaymentModeId,
                                 @RequestParam(value = "paymentModeOptionId", required = true) Long paymentModeOptionId) {
        return targetPaymentModeOptionService.get(targetPaymentModeId,paymentModeOptionId);
    }

    @Operation(summary = "API To Get All Target Payment Modes", description = "In response will get all Target Payment Mode Options", tags = {"Target Payment Mode Options"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = TargetPaymentModesUri.GET_ALL_ACTIVE_TPMO, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllActiveTargetPaymentModesOptions(@PathVariable(value = "status") @RequestParam(value = "status", required = false) String[] status) {
        return targetPaymentModeOptionService.getAllActive(status);
    }
}
