package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.LookupCodeFieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.CmLookupCodeValuesModel;
import com.isg.mw.core.model.sr.CmLookupCodesModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import org.springframework.stereotype.Service;

@Service("CmLookupCodesOfflineValidation")
public class CmLookupCodesOfflineValidationImpl implements CmLookupCodesOfflineValidation {
    @Override
    public void addValidation(CmLookupCodesModel lookupmodel) {
        UserDataValidations.stringDataValidation(lookupmodel.getLookupCode(), LookupCodeFieldsInfo.LOOKUP_CODE_EX, LookupCodeFieldsInfo.LOOKUP_CODE_NAME_FN, true, LookupCodeFieldsInfo.LOOKUP_CODE_NAME_FL);
}

    @Override
    public void modifyValidation(CmLookupCodesModel lookupCodeModel) {
        UserDataValidations.stringDataValidation(lookupCodeModel.getLookupCode(), LookupCodeFieldsInfo.LOOKUP_CODE_EX, LookupCodeFieldsInfo.LOOKUP_CODE_NAME_FN, true, LookupCodeFieldsInfo.LOOKUP_CODE_NAME_FL);
    }

    @Override
    public void getValidations(Long id) {
        if (id <= 0) {
            throw new ValidationException("Cm Lookup Codes field lookupCodeId is mandatory", LookupCodeFieldsInfo.ID_FN);
        }
    }



}
