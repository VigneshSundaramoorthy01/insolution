package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.TargetPaymentModesMessage;

public interface TargetPaymentModesMessenger {
    void send(TargetPaymentModesMessage model);
}
