package com.isg.mw.sr.mgmt.model;

import java.util.List;

import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.RouteType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(description = "${swgr.sr.model.add}}")
@Getter
@Setter
public class AddSrConfigModel {

//	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.id.value}")
//	private Long id;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.sourceId.value}")
	private Long sourceId;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.routeType.value}")
	private RouteType routeType;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.successRatioInterval.value}")
	private Long successRatioInterval;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.successRatioMaxTxns.value}")
	private Double successRatioMaxTxns;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.routeSwitchingPercent.value}")
	private Double routeSwitchingPercent;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.successThreshold.value}")
	private Double successThreshold;
	
	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.targetRouteConfig.value}")
	private List<SmartRouteTargetDefinition> targetRouteConfig;

	@ApiModelProperty(required = true, value = "${swgr.sr.model.add.entityId.value}")
	private String entityId;
	
}
