package com.isg.mw.sr.mgmt.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;

@Getter
@Setter
@ApiModel(description = "AddTargetMerchantMasterModel")
public class AddTargetMerchantMasterModel {

    @ApiModelProperty(value = "targetId", required = true)
    private Long targetId;

    @ApiModelProperty(value = "mid", required = true)
    private String mid;

    @ApiModelProperty(value = "tid", required = true)
    private String tid;

    @ApiModelProperty(value = "targetMid", required = true)
    private String targetMid;

    @ApiModelProperty(value = "merchantVpa", required = true)
    private String merchantVpa;

    @ApiModelProperty(value = "status", required = true)
    private String status;

    @ApiModelProperty(value = "key", required = true)
    private String key;

    @ApiModelProperty(value = "salt", required = true)
    private String salt;

    @ApiModelProperty(value = "exceptionMessage", required = true)
    private String exceptionMessage;

    @ApiModelProperty(value = "integrationType")
    private String integrationType;


}
