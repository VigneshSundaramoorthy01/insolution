package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.MerchantPaymentModesModel;
import com.isg.mw.core.model.validation.DateValidation;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service("merchantPaymentModesOfflineValidationImpl")
public class MerchantPaymentModesOfflineValidationImpl implements MerchantPaymentModesOfflineValidation{

    @Override
    public void addValidation(MerchantPaymentModesModel model) {
        UserDataValidations.longDataValidations(model.getMerchantMasterId(),MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.ID_FL,true);
        UserDataValidations.stringDataValidation(model.getEntityId(),MerchantMasterFieldInfo.ENTITY_ID_EX,MerchantMasterFieldInfo.ENTITY_ID_FN,true,MerchantMasterFieldInfo.ENTITY_ID_FL);
        UserDataValidations.longDataValidations(model.getPaymentModeId(),MerchantMasterFieldInfo.PAY_MODE_ID_FN,MerchantMasterFieldInfo.PAY_MODE_ID_FL, true);
        DateValidation.startDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
//Status
    }

    @Override
    public void modifyValidation(MerchantPaymentModesModel model) {
        UserDataValidations.longDataValidations(model.getMerchantMasterId(),MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.ID_FL,true);
        UserDataValidations.stringDataValidation(model.getEntityId(),MerchantMasterFieldInfo.ENTITY_ID_EX,MerchantMasterFieldInfo.ENTITY_ID_FN,true,MerchantMasterFieldInfo.ENTITY_ID_FL);
        UserDataValidations.longDataValidations(model.getPaymentModeId(),MerchantMasterFieldInfo.PAY_MODE_ID_FN,MerchantMasterFieldInfo.PAY_MODE_ID_FL, true);
        DateValidation.endDateValidations(model.getStartDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),model.getEndDate().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        //Status
    }

    public void getValidations(Long merchantMasterId, Long paymentModeId) {
        if (merchantMasterId <= 0 && paymentModeId <= 0) {
            throw new ValidationException("Merchant master and payment mode id is mandatory",MerchantMasterFieldInfo.ID_FN,MerchantMasterFieldInfo.PAY_MODE_ID_FN);
        }
    }

    @Override
    public void updateStatusValidation(Long merchantMasterId, Long paymentModeId, String status) {
        if (merchantMasterId == 0 && paymentModeId==0) {
            throw new ValidationException("Merchant Master Id and Payment Mode Id is mandatory");
        }
        UserDataValidations.stringPreDefiendDataValidation(status, MerchantMasterFieldInfo.UPDATE_STATUS_VALUES,
                MerchantMasterFieldInfo.UPDATE_STATUS_FN, true);

    }

    @Override
    public void submitValidation(Long merchantMasterId, Long paymentModeId) {
        if (merchantMasterId == 0) {
            throw new ValidationException("Merchant master field merchant master Id is mandatory", MerchantMasterFieldInfo.ID_FN);
        }

        if (paymentModeId == 0) {
            throw new ValidationException("Payment Mode field Payment Mode Id is mandatory", MerchantMasterFieldInfo.PAY_MODE_ID_FN);
        }
    }

    @Override
    public void verifyValidation(Long merchantMasterId, Long paymentModeId, boolean approved,String remarks) {
        UserDataValidations.longDataValidations(merchantMasterId,  MerchantMasterFieldInfo.ID_FN, MerchantMasterFieldInfo.ID_FL,true);
        UserDataValidations.longDataValidations(paymentModeId,  MerchantMasterFieldInfo.PAY_MODE_ID_FN, MerchantMasterFieldInfo.PAY_MODE_ID_FL,true);
        if (!approved && StringUtils.isBlank(remarks)) {
            throw new ValidationException("Remark is mandatory", FieldsInfo.REMARKS_FN);
        }
    }


    @Override
    public void removeValidation(Long merchantMasterId, Long paymentModeId) {
        if (merchantMasterId == 0 && paymentModeId==0) {
            throw new ValidationException("Merchant Master Id and Payment Mode Id is mandatory");
        }
    }


}
