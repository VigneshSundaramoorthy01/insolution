package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.MerchantMasterModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author shital3986
 */
public class GenerateCsvUtility {

    private static final Logger LOG = LogManager.getLogger(GenerateCsvUtility.class);

    public static final String SPREAD_SHEET_NAME = "Merchant_Master_Info";

    private static final List<String> columnHeaders = prepareHeaderList();
    private static final String DELIMITER = ",";
    private static final String LINE_SEPARATOR = "\n";

    public GenerateCsvUtility() {
    }

    public static boolean buildCSVFile(List<MerchantMasterModel> records) {
        String home = System.getProperty("user.home");
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new java.util.Date());
        File file = new File(home+"/"+"Merchant_Master_Info-"+ timeStamp + ".csv");
        try {
            PrintWriter writer = new PrintWriter(file);
            //write header
            writer.write(writeHeader(columnHeaders));
            //write body
            writer.write(writeBody(records));
            writer.close();
            //get path of file
            LOG.info("CSV File Absolute Path : {}", file.getAbsolutePath());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Exception while generating CSV file : {}", e.getMessage());
        }
        return false;
    }

    private static String writeHeader(List<String> columnHeaders) {
        StringBuilder sb = new StringBuilder();
        columnHeaders.stream().forEach(item -> sb.append(item).append(DELIMITER));
        sb.replace(sb.length() - 1, sb.length(), "");
        sb.append(LINE_SEPARATOR);
        return sb.toString();
    }

    private static String writeBody(List<MerchantMasterModel> merchantMasterModels) {
        StringBuilder sb = new StringBuilder();
        merchantMasterModels.stream().forEach(item ->
                sb.append(item.getMid()).append(DELIMITER)
                        .append(item.getMerchantName()).append(DELIMITER)
                        .append(item.getMerchantMobNo()).append(DELIMITER)
                        .append(item.getMerchantEmail()).append(LINE_SEPARATOR));
        return sb.toString();
    }

    private static List<String> prepareHeaderList() {
        List<String> headers = new ArrayList<String>();
        headers.add("MID"); // index 0
        headers.add("MERCHANT_NAME");
        headers.add("MERCHANT_MOB_NO");
        headers.add("MERCHANT_EMAIL_ID");
        LOG.info("Prepared file headers...");
        return headers;
    }

}
