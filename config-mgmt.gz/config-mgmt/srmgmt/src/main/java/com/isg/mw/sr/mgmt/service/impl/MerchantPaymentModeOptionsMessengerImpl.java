package com.isg.mw.sr.mgmt.service.impl;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.sr.mgmt.serializer.MerchantPaymentModeOptionsSerializer;
import com.isg.mw.sr.mgmt.service.MerchantPaymentModeOptionsMessenger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("merchantPaymentModeOptionsMessenger")
public class MerchantPaymentModeOptionsMessengerImpl implements MerchantPaymentModeOptionsMessenger, InitializingBean, DisposableBean {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private IsgKafkaConfigs isgKafkaConfigs;

    @Autowired
    private KafkaTopics kafkaTopics;

    private KafkaProducer producer;

    private KafkaProducer payModesAndOptionsProducer;



    public MerchantPaymentModeOptionsMessengerImpl() {
    }

    @Override
    public void send(MerchantPaymentModeOptionsMessage model) {
        LOG.trace("Sending data on kafka : {} and Action Status : {}", model.getModel(),
                model.getAction());
        producer.sendMessage(model);
    }

    @Override
    public void sendPaymentModesAndOptions(MerchantPaymentModeOptionsMessage model) {
        LOG.trace("Sending data on kafka : {} and Action Status : {}", model.getModel(),
                model.getAction());
        payModesAndOptionsProducer.sendMessage(model);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getMerchantPaymentModeOptionsTopicName(), MerchantPaymentModeOptionsSerializer.class));
        producer.init();

        payModesAndOptionsProducer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getMerchantPaymentModesAndOptionsTopicName(), MerchantPaymentModeOptionsSerializer.class));
        payModesAndOptionsProducer.init();
    }

}
