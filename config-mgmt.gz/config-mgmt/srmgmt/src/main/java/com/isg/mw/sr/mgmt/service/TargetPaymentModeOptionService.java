package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sr.mgmt.model.AddTargetPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModeOptionsModel;
import org.springframework.http.ResponseEntity;

public interface TargetPaymentModeOptionService {

    ResponseEntity<?> get(Long targetPaymentModeId,Long paymentModeOptionId);

    ResponseEntity<?> getAllActive(String[] status);

    ResponseEntity<?> submit(Long targetPaymentModeId,Long paymentModeOptionId);

    ResponseEntity<?> verify(Long targetPaymentModeId,Long paymentModeOptionId,boolean approved,String remarks);

    ResponseEntity<?> updateStatus(Long targetPaymentModeId,Long paymentModeOptionId,String status,String remarks);

    ResponseEntity<?> add(AddTargetPaymentModeOptionsModel addModel);

    ResponseEntity<?> modify(ModifyTargetPaymentModeOptionsModel modifyModel);

    ResponseEntity<?> getTargetModeOptionByStatus(String status);

    ResponseEntity<?> changeStatus(Long targetPayModeOptionId, String status);
}
