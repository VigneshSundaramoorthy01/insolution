package com.isg.mw.sr.mgmt.service;

import com.isg.mw.sr.mgmt.model.*;
import org.springframework.http.ResponseEntity;

public interface PaymentModesMgmtService {

    ResponseEntity<?> add(AddPaymentModesModel addModel);

    ResponseEntity<?> modify(ModifyPaymentModesModel modifyModel);

    ResponseEntity<?> getAll();

    ResponseEntity<?> get(Long id);

    ResponseEntity<?> addPayModeOptions(AddPaymentModeOptionsModel addPmoModel);

    ResponseEntity<?> modifyPmo(ModifyPaymentModeOptionsModel modifyModel);

    ResponseEntity<?> getAllPmo();

    ResponseEntity<?> getPmo(Long id);


}
