package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsMessage;

public interface MerchantPaymentModeOptionsMessenger {

    void send(MerchantPaymentModeOptionsMessage model);

    void sendPaymentModesAndOptions(MerchantPaymentModeOptionsMessage model);
}
