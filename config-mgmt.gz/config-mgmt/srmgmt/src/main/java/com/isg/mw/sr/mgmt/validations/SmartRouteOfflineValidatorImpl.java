package com.isg.mw.sr.mgmt.validations;

import java.util.List;

import com.isg.mw.core.model.constants.MerchantMasterFieldInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;

@Service("smartRouteOfflineValidator")
public class SmartRouteOfflineValidatorImpl implements SmartRouteOfflineValidator {

	@Override
	public void addValidation(SmartRouteConfigModel model) {
		UserDataValidations.longDataValidations(model.getSourceId(), FieldsInfo.SRC_ID_FN, FieldsInfo.SRC_ID_FL, true);
		UserDataValidations.stringPreDefiendDataValidation(model.getRouteType()!=null?model.getRouteType().name():null, FieldsInfo.ROUTE_TYPE_VALUES, FieldsInfo.ROUTE_TYPE_FN, true);
		UserDataValidations.stringDataValidation(model.getEntityId(),FieldsInfo.ENTITY_ID_EX,FieldsInfo.ENTITY_ID_FN,true,FieldsInfo.ENTITY_ID_FL);
		optionalDataCheck(model);
	}

	@Override
	public void modifyValidation(SmartRouteConfigModel model) {
		UserDataValidations.longDataValidations(model.getSourceId(), FieldsInfo.SRC_ID_FN,FieldsInfo.SRC_ID_FL, true);
		UserDataValidations.stringPreDefiendDataValidation(model.getRouteType()!=null?model.getRouteType().name():null, FieldsInfo.ROUTE_TYPE_VALUES, FieldsInfo.ROUTE_TYPE_FN, true);
		UserDataValidations.stringDataValidation(model.getEntityId(),FieldsInfo.ENTITY_ID_EX,FieldsInfo.ENTITY_ID_FN,true,FieldsInfo.ENTITY_ID_FL);
		optionalDataCheck(model);
	}

	@Override
	public void submitValidation(Long srcId) {
		if (srcId == 0) {
			throw new ValidationException(SrMgMtMsgKeys.SR_FIELD_IS_MANDATORY, FieldsInfo.SRC_ID_FN);
		}
	}

	@Override
	public void verifyValidation(Long srcId, boolean approved,String remarks) {
		UserDataValidations.longDataValidations(srcId, FieldsInfo.SRC_ID_FN, FieldsInfo.SRC_ID_FL,true);
		if(!approved && StringUtils.isBlank(remarks)) {
			throw new ValidationException(SrMgMtMsgKeys.REMARK_SR_IS_MANDATORY, FieldsInfo.REMARKS_FN);
		}
	}

	@Override
	public void updateStatusValidation(Long srcId, String status) {
		if (srcId == 0) {
			throw new ValidationException(SrMgMtMsgKeys.SR_FIELD_IS_MANDATORY, FieldsInfo.SRC_ID_FN);
		}
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.UPDATE_STATUS_VALUES,
				FieldsInfo.UPDATE_STATUS_FN, true);
	}

	@Override
	public void lockValidation(Long srcId, LockedState lockedState) {
		if (srcId == 0) {
			throw new ValidationException(SrMgMtMsgKeys.SR_FIELD_IS_MANDATORY, FieldsInfo.SRC_ID_FN);
		}
		UserDataValidations.lockedStateValidations(lockedState, true);
	}

	@Override
	public void getBySourceIdValidation(Long srcId) {
		if (srcId == 0) {
			throw new ValidationException(SrMgMtMsgKeys.SR_FIELD_IS_MANDATORY, FieldsInfo.SRC_ID_FN);
		}
	}

	@Override
	public void getValidations(Long id) {
		if (id == 0) {
			throw new ValidationException(SrMgMtMsgKeys.SR_FIELD_IS_MANDATORY, FieldsInfo.ID_FN);
		}
	}

	private void optionalDataCheck(SmartRouteConfigModel model) {
		UserDataValidations.longDataValidations(model.getSuccessRatioInterval(),
				FieldsInfo.SUCCESS_RATIONAL_INTERVAL_FN, FieldsInfo.SUCCESS_RATIONAL_INTERVAL_FL, false);
		UserDataValidations.doubleDataValidations(model.getSuccessRatioMaxTxns(),
				FieldsInfo.SUCCESS_RATIONAL_MAXTXNS_FL, FieldsInfo.SUCCESS_RATIONAL_MAXTXNS_FN, false);
		UserDataValidations.doubleDataValidations(model.getRouteSwitchingPercent(),
				FieldsInfo.ROURE_SWITCHING_PERCENT_FL, FieldsInfo.ROURE_SWITCHING_PERCENT_FN, false);
		UserDataValidations.doubleDataValidations(model.getSuccessThreshold(), FieldsInfo.SUCCESS_THRESHOLD_FL,
				FieldsInfo.SUCCESS_THRESHOLD_FN, false);
		if (model.getTargetRouteConfig()!= null) {
		List<SmartRouteTargetDefinition> targetRouteConfigs = model.getTargetRouteConfig();
		for (SmartRouteTargetDefinition targetRouteConfig : targetRouteConfigs) {
			UserDataValidations.longDataValidations(targetRouteConfig.getTargetId(), FieldsInfo.TARGET_ID_FN, FieldsInfo.TARGET_ID_FL,  true);
			UserDataValidations.stringPreDefiendDataValidation(targetRouteConfig.getTargetPriority()!=null?targetRouteConfig.getTargetPriority().name():null,FieldsInfo.TARGET_PRIORITY_VALUES, FieldsInfo.TARGET_PRIORITY_FN, false);
		}
		}
	}
	
	@Override
	public void configByStatusValidation(String status) {
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.CONFIG_BY_STATUS_VALUES,
				FieldsInfo.CONFIG_BY_STATUS_FN, true);
	}


}
