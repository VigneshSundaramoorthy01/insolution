package com.isg.mw.sr.mgmt.serializer;

import com.isg.mw.core.model.sr.MerchantMasterModel;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class MerchantMasterSerializer implements Serializer<MerchantMasterModel> {
    private final Logger LOG = LoggerFactory.getLogger(MerchantMasterSerializer.class);

    @Override
    public byte[] serialize(String topic, MerchantMasterModel data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(data);
            oos.flush();
        } catch (IOException e) {
            LOG.error("Error while serializing object: {}", e);
        }
        return bos.toByteArray();

    }

}
