package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.sr.mgmt.model.AddSrConfigModel;
import com.isg.mw.sr.mgmt.model.AddTargetPaymentModesModel;
import com.isg.mw.sr.mgmt.model.ModifySrConfigModel;
import com.isg.mw.sr.mgmt.model.ModifyTargetPaymentModesModel;
import org.springframework.http.ResponseEntity;

public interface TargetPaymentModeService {

    ResponseEntity<?> get(Long targetId,Long paymentModeId,String integrationType);

    ResponseEntity<?> getAllActive(String[] status,String entityId);

    ResponseEntity<?> submit(Long targetId,Long paymentModeId,String integrationType);

    ResponseEntity<?> verify(Long targetId,Long paymentModeId,String integrationType,boolean approved,String remarks);

    ResponseEntity<?> updateStatus(Long targetId,Long paymentModeId,String integrationType,String status,String remarks);

    ResponseEntity<?> add(AddTargetPaymentModesModel addModel);

    ResponseEntity<?> modify(ModifyTargetPaymentModesModel modifyModel);

    ResponseEntity<?> getTargetPaymentModesModelByStatus(String status);
}
