package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;

public interface SmartRouteOfflineValidator {

	void getValidations(Long id);

	void addValidation(SmartRouteConfigModel model);

	void modifyValidation(SmartRouteConfigModel model);

	void submitValidation(Long srcId);

	void updateStatusValidation(Long srcId, String status);

	void lockValidation(Long srcId, LockedState lockedState);

	void verifyValidation(Long srcId, boolean approved,String remarks);

	void getBySourceIdValidation(Long srcId);
	
	void configByStatusValidation(String status);


}
