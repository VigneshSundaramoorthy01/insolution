package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.CmLookupCodeValuesModel;

public interface CmLookupCodeValuesOfflineValidation {
    void addValidation(CmLookupCodeValuesModel lookupmodelV);

    void modifyValidation(CmLookupCodeValuesModel lcValueModel);

    void getValidations(Long id);

}
