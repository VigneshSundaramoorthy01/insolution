package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.SmartRouteConfigMessage;
import com.isg.mw.core.model.sr.TargetLCRConfigMessage;

/**
 * 
 * @author shital3986
 *
 */
public interface TargetLCRConfigMessenger {

	void send(TargetLCRConfigMessage trgtconfigMessage);
}
