//package com.isg.mw.sr.mgmt.consumer;
//
//import com.isg.kafka.consumer.KafkaConsumer;
//import com.isg.mw.core.model.constants.ActiveInactiveFlag;
//import com.isg.mw.core.model.sr.MerchantMasterModel;
//import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
//import com.isg.mw.kafka.IsgKafkaConfigs;
//import com.isg.mw.kafka.KafkaTopics;
//import com.isg.mw.sr.dao.service.TargetMerchantMasterService;
//import com.isg.mw.sr.mgmt.deserializer.TargetMerchantMasterDeserializer;
//import com.isg.mw.sr.mgmt.utils.TargetMerchantMasterMgmtUtility;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.ApplicationArguments;
//import org.springframework.boot.ApplicationRunner;
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//
//@Component
//public class TargetMerchantMasterConsumer implements ApplicationRunner {
//
//    private static final Logger logger = LogManager.getLogger(TargetMerchantMasterConsumer.class);
//
//    @Autowired
//    private IsgKafkaConfigs isgKafkaConfigs;
//
//    @Autowired
//    private KafkaTopics kafkaTopics;
//
//    @Autowired
//    private TargetMerchantMasterService targetMerchantMasterService;
//
//
//
//    /**
//     * This method consume Target Merchant Master  from kafka topic using reusable kafka
//     * component.
//     */
//
//    @Override
//    public void run(ApplicationArguments args) throws Exception {
//
//        logger.info("Target Merchant Master Kafka Consumer Method Call");
//        try {
//            KafkaConsumer consumer1 = new KafkaConsumer(isgKafkaConfigs
//                    .getKafkaDeserializerConfig(kafkaTopics.getTargetMerchantMasterConsumerTopicName(), TargetMerchantMasterDeserializer.class),
//                    this, "targetMerchantMasterConsumer");
//            consumer1.init();
//            logger.info("Target Merchant Master Kafka Consumer Initialization Done...");
//        } catch (Exception e) {
//            logger.error("Exception While Consuming MapsInfo & Merchant Master: ", e);
//        }
//    }
//
//    /**
//     * This method store data into TargetMerchantMaster
//     *
//     * @param targetMerchantMasterModel
//     */
//    public void targetMerchantMasterConsumer(TargetMerchantMasterModel targetMerchantMasterModel) {
//        try {
//            logger.trace("Target Merchant Master Object Consumed in CM: {}", targetMerchantMasterModel);
//            if (targetMerchantMasterModel != null) {
//                TargetMerchantMasterModel dbEntity = targetMerchantMasterService.findById(targetMerchantMasterModel.getTargetId(), targetMerchantMasterModel.getMid(), targetMerchantMasterModel.getTid());
//                if (dbEntity == null) {
//                    targetMerchantMasterService.add(targetMerchantMasterModel);
//                    logger.trace("Target Merchant Master Object Added successfully in DB : ");
//                } else {
//                    if (!dbEntity.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
//                        targetMerchantMasterService.update(targetMerchantMasterModel);
//                        logger.trace("Target Merchant Master entity Updated successfully in DB : ");
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error("Exception While Add/Updating Target Merchant Master Entity: ", e);
//        }
//    }
//}