package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.TargetLCRConfigModel;

public interface TargetLCRConfigOfflineValidation {

    void addValidation(TargetLCRConfigModel model);

    void getValidations(Long id,Long paymentModeId ,Long paymentModeOptionId);

    void submitValidation(Long targetId,Long paymentModeId ,Long paymentModeOptionId);

    void modifyValidation(TargetLCRConfigModel rdModel);

    void updateStatusValidation(Long targetId,Long paymentModeId,Long paymentModeOptionId,String trgtStatus);

    void verifyValidation(Long targetId,Long paymentModeId,Long paymentModeOptionId,boolean approved,String remarks);
}
