package com.isg.mw.sr.mgmt.constants;

public interface CmLookupCodeUri {

    /**
     * Used for parent URI
     */
    String PARENT = "/sr";

    /**
     * Used for get API URI
     */
    String GET_BY_ID = "/cmLookupCodes/get";

    /**
     * Used for getAll API URI
     */
    String GET_ALL = "/cmLookupCodes/getall";

    /**
     * Used for add API URI
     */
    String ADD = "/cmLookupCodes/add";

    /**
     * Used for save API URI
     */
    String MODIFY = "/cmLookupCodes/update";

    /**
     * Used for add API URI
     */
    String ADD_LOOKUP_CODE_VALUES = "/cmLookupCodeValues/add";

    /**
     * Used for save API URI
     */
    String UPDATE_LOOKUP_CODE_VALUES = "/cmLookupCodeValues/update";

    /**
     * Used for getAll API URI
     */
    String GET_ALL_LOOKUP_CODE_VALUES = "/cmLookupCodeValues/getall";


    /**
     * Used for get API URI
     */
    String GET_LOOKUP_CODE_VALUES_BY_ID = "/cmLookupCodeValues/get";

}
