package com.isg.mw.sr.mgmt.service;

import com.isg.mw.core.model.sr.MerchantMasterModel;

public interface MerchantMasterOnboardMessenger {
    void sendMerchantMasterForOnboardReq(MerchantMasterModel resultModel);
}
