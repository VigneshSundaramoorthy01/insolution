package com.isg.mw.sr.mgmt.constants;

public interface TargetPaymentModeOptionsMsgKeys {

    /**
     * should use when no entry in db
     */
    String TPMO_LIST_EMPTY = "sr.mgmt.sr.list.empty";

    /**
     * should use when and internal error occur
     */
    String INTERNAL_ERROR = "sr.mgmt.internal.error";

    /**
     * get Route Definition configuration for name {0} and entity Id {1}
     */
    String GET_API_LOG_INFO = "sr.mgmt.get.api.log.info";

    /**
     * get all (Active and Unlocked) Route Definition configurations requested for
     * initialization
     */
    String GETALL_ACTIVE_API_LOG_INFO = "sr.mgmt.getall.active.api.log.info";

    /**
     * get all (Active and Unlocked) Route Definition configurations requested for
     * initialization
     */
    String GETALL_API_LOG_INFO = "sr.mgmt.getall.api.log.info";


    /**
     * add requested with the Route Definition configuration {0} for entity Id {1}
     */
    String ADD_API_LOG_INFO = "sr.mgmt.add.api.log.info";

    /**
     * modify requested for Route Definition configuration {0} for entity Id {1}
     */
    String MODIFY_API_LOG_INFO = "sr.mgmt.modify.api.log.info";

    /**
     * submit requested for Route Definition configuration {0} for entity Id {1}
     */
    String SUBMIT_API_LOG_INFO = "sr.mgmt.submit.api.log.info";

    /**
     * lock requested for Route Definition configuration {0} for entity Id {1} with
     * lockState as {2}
     */
    String LOCK_API_LOG_INFO = "sr.mgmt.lock.api.log.info";

    /**
     * verify requested for Route Definition configuration {0} for entity Id {1}
     */
    String VERIFY_API_LOG_INFO = "sr.mgmt.verify.api.log.info";

    /**
     * update status requested for Route Definition configuration {0} for entity Id
     * {1} with Status as {2}
     */
    String UPDATESTATUS_API_LOG_INFO = "sr.mgmt.updatestatus.api.log.info";

    /**
     * Should used in validations when Route Definition field is mandatory
     */
    String TPMO_FIELD_IS_MANDATORY = "sr.mgmt.route.field.is.mandatory";

    /**
     * Should used in validations when rule defination is empty
     */
    String RULE_DEFINATION_SHOULD_NOT_EMPTY = "sr.mgmt.rule.defination.should.not.be.empty";

    /**
     * Should used in validations when rule defination is invalid
     */
    String INVALID_RULE_DEFINATION = "sr.mgmt.invalid.rule.defination";

    /**
     * should used in validation when data length is exceed with given value
     */
    String DATA_LENGTH_EXCEEDED = "sr.mgmt.data.length.exceeded";

    String REMARK_SR_IS_MANDATORY="sr.mgmt.remark.sr.is.mandatory";

    String GET_CONFIG_BY_STATUS_API_LOG_INFO="sr.mgmt.getConfigByStatus.api.log.info";
}
