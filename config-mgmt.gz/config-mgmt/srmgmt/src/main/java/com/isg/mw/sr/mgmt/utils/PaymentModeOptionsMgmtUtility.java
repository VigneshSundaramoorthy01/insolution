package com.isg.mw.sr.mgmt.utils;

import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.AddPaymentModeOptionsModel;
import com.isg.mw.sr.mgmt.model.ModifyPaymentModeOptionsModel;

public class PaymentModeOptionsMgmtUtility {
    public static PaymentModeOptionsModel getPaymentModesOptionModel(AddPaymentModeOptionsModel addmodel) {
        PaymentModeOptionsModel model = new PaymentModeOptionsModel();
        model.setPaymentModeId(addmodel.getPaymentModeId());
        model.setModeOptionName(addmodel.getModeOptionName());
        model.setModeOptionDesc(addmodel.getModeOptionDesc());
        model.setDefaultEnabledFlag(addmodel.getDefaultEnabledFlag());
        return model;

    }

    public static PaymentModeOptionsModel getPayModeOptionModifyModel(ModifyPaymentModeOptionsModel modifyModel) {
        PaymentModeOptionsModel model = new PaymentModeOptionsModel();
        model.setPaymentModeOptionId(modifyModel.getPaymentModeOptionId());
        model.setPaymentModeId(modifyModel.getPaymentModeId());
        model.setModeOptionName(modifyModel.getModeOptionName());
        model.setModeOptionDesc(modifyModel.getModeOptionDesc());
        model.setDefaultEnabledFlag(modifyModel.getDefaultEnabledFlag());
        return model;

    }
}
