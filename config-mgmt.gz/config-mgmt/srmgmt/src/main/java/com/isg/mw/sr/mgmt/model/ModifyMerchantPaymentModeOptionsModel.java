package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsAdditionalData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@ApiModel(description = "ModifyMerchantPaymentModeOptionsModel")
@Getter
@Setter
public class ModifyMerchantPaymentModeOptionsModel {

    @ApiModelProperty(value = "merchantPaymentModeId", required = true)
    private Long merchantPaymentModeId;

    @ApiModelProperty(value = "paymentModeOptionId", required = true)
    private Long paymentModeOptionId;

    @ApiModelProperty( value = "startDate",required = true)
    private OffsetDateTime startDate;

    @ApiModelProperty(value = "endDate",required = true)
    private OffsetDateTime endDate;

    @ApiModelProperty(value = "additionalData", required = true)
    private MerchantPaymentModeOptionsAdditionalData additionalData;


}
