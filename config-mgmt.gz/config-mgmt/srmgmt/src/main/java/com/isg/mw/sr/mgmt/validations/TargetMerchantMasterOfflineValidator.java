package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.TargetMerchantMasterModel;

public interface TargetMerchantMasterOfflineValidator {

    void addValidation(TargetMerchantMasterModel model);

    void modifyValidation(TargetMerchantMasterModel model);

    void getValidations(Long targetId,String mid,String tid);

    void checkStatus(String status);
}
