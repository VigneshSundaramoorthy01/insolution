package com.isg.mw.sr.controller;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.sr.dao.service.BusinessTypeService;
import com.isg.mw.sr.mgmt.constants.SrMgMtMsgKeys;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "Business Type Configuration", description = "Business Type Configuration API's")
@RestController
@RequestMapping(value = "/businessType")
public class BusinessTypeController {
    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private BusinessTypeService businessTypeService;

    @CrossOrigin(methods = RequestMethod.GET)
    @GetMapping(path = "/getall", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAll() {
        ResponseEntity<?> response = null;
        Map<String, String> map;
        try {
            map = businessTypeService.getAll();
            if (map != null && !map.isEmpty()) {
                response = new ResponseEntity<>(map, HttpStatus.OK);
            } else {
                String errMsg = PropertyUtils.getMessage("Business Types Are empty");
                response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
            }
        } catch (ValidationException e) {
            String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg.equals("Unknown message")?e.getMessage():errMsg, HttpStatus.EXPECTATION_FAILED);
        } catch (Exception e) {
            String errMsg = PropertyUtils.getMessage(SrMgMtMsgKeys.INTERNAL_ERROR);
            LOG.error(errMsg, e);
            response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }
}
