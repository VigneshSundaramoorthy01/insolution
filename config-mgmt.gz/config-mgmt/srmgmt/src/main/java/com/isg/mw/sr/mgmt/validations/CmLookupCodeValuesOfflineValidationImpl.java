package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.constants.LookupCodeFieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.sr.CmLookupCodeValuesModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import org.springframework.stereotype.Service;

@Service("CmLookupCodeValuesOfflineValidation")
public class CmLookupCodeValuesOfflineValidationImpl implements CmLookupCodeValuesOfflineValidation{


    @Override
    public void addValidation(CmLookupCodeValuesModel lcValueModel) {
        UserDataValidations.stringDataValidation(lcValueModel.getLookupCodeValue(), LookupCodeFieldsInfo.LOOKUP_CODE_VALUE_EX,  LookupCodeFieldsInfo.LOOKUP_CODE_VALUE_NAME_FN,true,LookupCodeFieldsInfo.LOOKUP_CODE_VALUE_NAME_FL);
        UserDataValidations.longDataValidations(lcValueModel.getLookupCodeId(), LookupCodeFieldsInfo.LOOKUP_CODE_ID,LookupCodeFieldsInfo.LOOKUP_CODE_ID_FL, true);

    }

    @Override
    public void modifyValidation(CmLookupCodeValuesModel lcValueModel) {
        UserDataValidations.stringDataValidation(lcValueModel.getLookupCodeValue(),LookupCodeFieldsInfo.LOOKUP_CODE_VALUE_EX,  LookupCodeFieldsInfo.LOOKUP_CODE_VALUE_NAME_FN,true,LookupCodeFieldsInfo.LOOKUP_CODE_VALUE_NAME_FL);
        UserDataValidations.longDataValidations(lcValueModel.getLookupCodeId(), LookupCodeFieldsInfo.LOOKUP_CODE_ID,LookupCodeFieldsInfo.LOOKUP_CODE_ID_FL, true);

    }

    @Override
    public void getValidations(Long id) {
        if (id <= 0) {
            throw new ValidationException("Cm Lookup Code Values field lookupCodeValueId is mandatory", LookupCodeFieldsInfo.ID_FN);
        }
    }
}
