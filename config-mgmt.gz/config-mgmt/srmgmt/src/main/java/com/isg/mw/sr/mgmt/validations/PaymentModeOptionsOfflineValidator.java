package com.isg.mw.sr.mgmt.validations;

import com.isg.mw.core.model.sr.PaymentModeOptionsModel;

public interface PaymentModeOptionsOfflineValidator {

    void addValidation(PaymentModeOptionsModel pmoModel);

    void modifyValidation(PaymentModeOptionsModel pmoModel);

    void getValidations(Long id);

}
