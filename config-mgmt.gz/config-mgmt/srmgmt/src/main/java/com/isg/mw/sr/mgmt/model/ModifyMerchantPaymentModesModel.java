package com.isg.mw.sr.mgmt.model;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@ApiModel(description = "ModifyMerchantPaymentModesModel")
@Getter
@Setter
public class ModifyMerchantPaymentModesModel {

    @ApiModelProperty(value = "merchantMasterId", required = true)
    private Long merchantMasterId;

    @ApiModelProperty(value = "paymentModeId", required = true)
    private Long paymentModeId;

    @ApiModelProperty( value = "startDate",required = true)
    private OffsetDateTime startDate;

    @ApiModelProperty(value = "endDate",required = true)
    private OffsetDateTime endDate;

    @ApiModelProperty(value = "entityId", required = true)
    private String entityId;

}
