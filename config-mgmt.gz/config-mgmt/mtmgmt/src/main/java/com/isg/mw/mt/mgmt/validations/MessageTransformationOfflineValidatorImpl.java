package com.isg.mw.mt.mgmt.validations;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mt.MessageMappingDefinition;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.mt.dao.utils.MtCommonUtil;
import com.isg.mw.mt.mgmt.constants.MtMgMtMsgKeys;

/**
 * Implementation of {@link RouteDefinitionOfflineValidator}
 * 
 * @author prasad_t026
 *
 */
@Service("routeDefinitionOfflineValidator")
public class MessageTransformationOfflineValidatorImpl implements MessageTransformationOfflineValidator {

	@Override
	public void addValidation(MessageTransformationConfigModel model) {

		UserDataValidations.entityIdValidations(model.getEntityId(), true);
		UserDataValidations.nameValidations(model.getName(), true);
//		UserDataValidations.userNameValidations(model.getCreatedBy(), true);
		UserDataValidations.stringDataValidation(model.getDescription(), DESCRIPTION_EXPR, DESCRIPTION_NAME, false,
				DESCRIPTION_LENGTH);
		routeDefValidation(model.getRules());
		UserDataValidations.longDataValidations(model.getSourceId(), FieldsInfo.SRC_ID_FN, FieldsInfo.SRC_ID_FL, true);
	}

	@Override
	public void modifyValidation(MessageTransformationConfigModel model) {

		UserDataValidations.entityIdValidations(model.getEntityId(), true);
		UserDataValidations.nameValidations(model.getName(), true);
	//	UserDataValidations.userNameValidations(model.getUpdatedBy(), true);
		UserDataValidations.stringDataValidation(model.getDescription(), DESCRIPTION_EXPR, DESCRIPTION_NAME, false,
				DESCRIPTION_LENGTH);
		routeDefValidation(model.getRules());
		UserDataValidations.longDataValidations(model.getSourceId(), FieldsInfo.SRC_ID_FN, FieldsInfo.SRC_ID_FL, true);
	}

	@Override
	public void submitValidation(String name, String entityId) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}

	}

	@Override
	public void verifyValidation(String name, String entityId, boolean approved,String remarks) {

		if (StringUtils.isBlank(name))  {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId))  {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		if(!approved && StringUtils.isBlank(remarks)) {
			throw new ValidationException(MtMgMtMsgKeys.REMARK_MT_IS_MANDATORY, FieldsInfo.REMARKS_FN);
		}

	}

	@Override
	public void lockValidation(String name, String entityId, LockedState lockedState) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)){
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		UserDataValidations.lockedStateValidations(lockedState, true);

	}

	@Override
	public void updateValidation(String name, String entityId, String status) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.UPDATE_STATUS_VALUES,
				FieldsInfo.UPDATE_STATUS_FN, true);

	}

	@Override
	public void get(String name, String entityId) {

		if (StringUtils.isBlank(name)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}

	}

	@Override
	public void getAllActive() {
	}

	@Override
	public void allRouteDefinitions(String entityId) {

		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(MtMgMtMsgKeys.MT_FIELD_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}

	}

	private void routeDefValidation(List<MessageMappingDefinition> rules) {

		if (rules == null || rules.isEmpty()) {
			throw new ValidationException(MtMgMtMsgKeys.RULE_DEFINATION_SHOULD_NOT_EMPTY);
		}
		for (MessageMappingDefinition rule : rules) {
			if (rule == null) {
				throw new ValidationException(MtMgMtMsgKeys.INVALID_RULE_DEFINATION);
			}
			
			if (rule.getName() == null || rule.getName().isEmpty() ) { //|| rule.getSrc() == null || rule.getDest() == null
				throw new ValidationException(MtMgMtMsgKeys.INVALID_RULE_DEFINATION);
			}
			/*
			if (rule.getSrc().getSchemeType() == null || rule.getSrc().getMsgType() == null
					|| rule.getSrc().getMsgType().isEmpty() || rule.getSrc().getMsgTypeId() == null
					|| rule.getSrc().getMsgTypeId().isEmpty()) {
				throw new ValidationException(MtMgMtMsgKeys.INVALID_RULE_DEFINATION);
			}
			if (rule.getDest().getSchemeType() == null || rule.getDest().getMsgType() == null
					|| rule.getDest().getMsgType().isEmpty() || rule.getDest().getMsgTypeId() == null
					|| rule.getDest().getMsgTypeId().isEmpty()) {
				throw new ValidationException(MtMgMtMsgKeys.INVALID_RULE_DEFINATION);
			}
			*/
			if (rule.getDest() != null) {
				UserDataValidations.stringDataValidation(rule.getDest().getApiPath(), FieldsInfo.TARGET_METHOD_EX,
						FieldsInfo.TARGET_METHOD_FN, false, FieldsInfo.TARGET_METHOD_FL);
			}
		}
		String cs = MtCommonUtil.convertRulesToString(rules);
		if(cs.length() > ROUTE_DEF_LENGTH) {
			throw new ValidationException(MtMgMtMsgKeys.DATA_LENGTH_EXCEEDED, ROUTE_DEF_NAME,ROUTE_DEF_LENGTH);
		}

	}
	
	@Override
	public void configByStatusValidation(String status) {
		UserDataValidations.stringPreDefiendDataValidation(status, FieldsInfo.CONFIG_BY_STATUS_VALUES,
				FieldsInfo.CONFIG_BY_STATUS_FN, true);
	}


}
