package com.isg.mw.mt.mgmt.service;

import com.isg.mw.core.model.mt.MessageTransformationConfigMessage;


/**
 * Route Definition Messenger
 * 
 * @author prasad_t026
 *
 */
public interface MtMessenger {

	/**
	 * Send the Route Definition configuration message model using KAFKA producer
	 * 
	 * @param model - Route Definition message model
	 */
	void send(MessageTransformationConfigMessage model);

}
