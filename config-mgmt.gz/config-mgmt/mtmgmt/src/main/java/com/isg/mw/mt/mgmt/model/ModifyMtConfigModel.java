package com.isg.mw.mt.mgmt.model;

import java.util.List;

import com.isg.mw.core.model.mt.MessageMappingDefinition;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Route Definition edit model
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "${swgr.mt.model.modify}}")
@Getter
@Setter
public class ModifyMtConfigModel {

	/**
	 * entity id
	 */
	@ApiModelProperty(required = true, value = "${swgr.mt.model.modify.entityId.value}")
	private String entityId;

	/**
	 * name of the route definition
	 */
	@ApiModelProperty(required = true, value = "${swgr.mt.model.modify.name.value}")
	private String name;

	/**
	 * route definition content of the file
	 */
	@ApiModelProperty(required = true, value = "${swgr.mt.model.modify.messagetrans.value}")
	private List<MessageMappingDefinition> rules;

	/**
	 * description about message format
	 */
	@ApiModelProperty(required = false, value = "${swgr.mt.model.modify.description.value}")
	private String description;

	/**
	 * Updated by
	 */
	//@ApiModelProperty(required = true, value = "${swgr.mt.model.modify.updatedBy.value}")
	//private String updatedBy;
	
	@ApiModelProperty(required = false, value = "${swgr.mt.model.modify.sourceId.value}")
	private Long sourceId;
}
