package com.isg.mw.mt.mgmt.validations;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;

/**
 * Validates data (received data from Rest API) without hitting database
 * 
 * @author prasad_t026
 *
 */
public interface MessageTransformationOfflineValidator {

	
	public static final String ROUTE_DEF_EXPR = null;
	public static final int ROUTE_DEF_LENGTH = 20000;
	public static final String ROUTE_DEF_NAME = "routeDef";

	public static final String DESCRIPTION_EXPR = null;
	public static final int DESCRIPTION_LENGTH = 100;
	public static final String DESCRIPTION_NAME = "description";

	/**
	 * Offline validation while adding new Route Definition Configuration model
	 * 
	 * @param model - Route Definition configuration model
	 */
	void addValidation(MessageTransformationConfigModel model);

	/**
	 * Offline validation while modifying Route Definition Configuration model
	 * 
	 * @param model - Route Definition configuration model
	 */
	void modifyValidation(MessageTransformationConfigModel model);

	/**
	 * Offline validation while submitting Route Definition Configuration model
	 * 
	 * @param editCopy - Route Definition configuration model
	 */
	void submitValidation(String name, String entityId);

	/**
	 * Offline validation while verifying Route Definition configuration
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param approved - true if verified or false if rejected
	 */
	void verifyValidation(String name, String entityId, boolean approved,String remarks);

	/**
	 * Offline validation while lock Route Definition configuration
	 * 
	 * @param name        - name of the configuration
	 * @param entityId    - entity id of the configuration
	 * @param lockedState - locked or unlocked
	 */
	void lockValidation(String name, String entityId, LockedState lockedState);

	/**
	 * Offline validation while lock Route Definition configuration
	 * 
	 * @param name     - name of the configuration
	 * @param entityId - entity id of the configuration
	 * @param status   - new status which is going to change current status
	 */
	void updateValidation(String name, String entityId, String status);

	/**
	 * Offline validation for get Route Definition configuration
	 * 
	 * @param name
	 * @param entityId
	 */
	void get(String name, String entityId);

	void getAllActive();

	/**
	 * Offline validation for getting all Route Definitions name
	 * 
	 * @param entityId
	 */
	void allRouteDefinitions(String entityId);
	
	void configByStatusValidation(String status);

}
