package com.isg.mw.mt.mgmt.model;

import java.util.List;

import com.isg.mw.core.model.mt.MessageMappingDefinition;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Route Definition Add model
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "${swgr.mt.model.add}}")
@Getter
@Setter
public class AddMtConfigModel {

	/**
	 * entity id
	 */
	@ApiModelProperty(required = true, value = "${swgr.mt.model.add.entityId.value}")
	private String entityId;

	/**
	 * name of the route definition
	 */
	@ApiModelProperty(required = true, value = "${swgr.mt.model.add.name.value}")
	private String name;

	/**
	 * route definition content of the file
	 */
	@ApiModelProperty(required = true, value = "${swgr.mt.model.add.messagetrans.value}")
	private List<MessageMappingDefinition> rules;

	/**
	 * description about message format
	 */
	@ApiModelProperty(required = false, value = "${swgr.mt.model.add.description.value}")
	private String description;

	/**
	 * Created by
	 */
	//@ApiModelProperty(required = true, value = "${swgr.mt.model.add.createdBy.value}")
	//private String createdBy;

	@ApiModelProperty(required = false, value = "${swgr.mt.model.add.sourceId.value}")
	private Long sourceId;
}
