package com.isg.mw.mt.mgmt.utils;

import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.mt.mgmt.model.AddMtConfigModel;
import com.isg.mw.mt.mgmt.model.ModifyMtConfigModel;

/**
 * Route Definition management utility used for convert Add and Modify Route Definition
 * model into Route Definition configuration model
 * 
 * @author prasad_t026
 *
 */
public class MtMgmtUtility {

	/**
	 * Default constructor It should not access from out side
	 */
	private MtMgmtUtility() {
	}

	/**
	 * Converts add Route Definition configuration model into Route Definition configuration model
	 * 
	 * @param addModel - add Route Definition configuration model
	 * @return model - Route Definition configuration model
	 */
	public static MessageTransformationConfigModel getMessageTransformationConfigModel(AddMtConfigModel addModel) {
		MessageTransformationConfigModel model = new MessageTransformationConfigModel();
		model.setEntityId(addModel.getEntityId());
		model.setName(addModel.getName());
		model.setRules(addModel.getRules() );
		model.setDescription(addModel.getDescription());
		//model.setCreatedBy(addModel.getCreatedBy());
		model.setSourceId(addModel.getSourceId());
		return model;
	}

	/**
	 * Converts Modify Route Definition configuration model into Route Definition configuration model
	 * 
	 * @param modifyModel - Modify Route Definition configuration model
	 * @return model - Route Definition configuration model
	 */
	public static MessageTransformationConfigModel getMessageTransformationConfigModel(ModifyMtConfigModel modifyModel) {
		MessageTransformationConfigModel model = new MessageTransformationConfigModel();
		model.setEntityId(modifyModel.getEntityId());
		model.setName(modifyModel.getName());
		model.setRules(modifyModel.getRules());
		//model.setUpdatedBy(modifyModel.getUpdatedBy());
		model.setDescription(modifyModel.getDescription());
		model.setSourceId(modifyModel.getSourceId());
		return model;
	}

}
