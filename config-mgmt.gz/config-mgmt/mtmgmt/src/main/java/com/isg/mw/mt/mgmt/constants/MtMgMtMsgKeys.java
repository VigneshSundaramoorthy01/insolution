package com.isg.mw.mt.mgmt.constants;

/**
 * 
 * @author prasad_t026
 *
 */
public interface MtMgMtMsgKeys {

	/**
	 * should use when no entry in db
	 */
	String MT_LIST_EMPTY = "mt.mgmt.mt.list.empty";

	/**
	 * should use when and internal error occur
	 */
	String INTERNAL_ERROR = "mt.mgmt.internal.error";

	/**
	 * get Route Definition configuration for name {0} and entity Id {1}
	 */
	String GET_API_LOG_INFO = "mt.mgmt.get.api.log.info";

	/**
	 * get all (Active and Unlocked) Route Definition configurations requested for
	 * initialization
	 */
	String GETALL_API_LOG_INFO = "mt.mgmt.getall.api.log.info";

	/**
	 * get all Route Definition configuration names requested for entity Id {1}
	 */
	String GETNAMES_API_LOG_INFO = "mt.mgmt.get.names.api.log.info";

	/**
	 * add requested with the Route Definition configuration {0} for entity Id {1}
	 */
	String ADD_API_LOG_INFO = "mt.mgmt.add.api.log.info";

	/**
	 * modify requested for Route Definition configuration {0} for entity Id {1}
	 */
	String MODIFY_API_LOG_INFO = "mt.mgmt.modify.api.log.info";

	/**
	 * submit requested for Route Definition configuration {0} for entity Id {1}
	 */
	String SUBMIT_API_LOG_INFO = "mt.mgmt.submit.api.log.info";

	/**
	 * lock requested for Route Definition configuration {0} for entity Id {1} with
	 * lockState as {2}
	 */
	String LOCK_API_LOG_INFO = "mt.mgmt.lock.api.log.info";

	/**
	 * verify requested for Route Definition configuration {0} for entity Id {1}
	 */
	String VERIFY_API_LOG_INFO = "mt.mgmt.verify.api.log.info";

	/**
	 * update status requested for Route Definition configuration {0} for entity Id
	 * {1} with Status as {2}
	 */
	String UPDATESTATUS_API_LOG_INFO = "mt.mgmt.updatestatus.api.log.info";

	/**
	 * Should used in validations when Route Definition field is mandatory
	 */
	String MT_FIELD_IS_MANDATORY = "mt.mgmt.route.field.is.mandatory";

	/**
	 * Should used in validations when rule defination is empty
	 */
	String RULE_DEFINATION_SHOULD_NOT_EMPTY = "mt.mgmt.rule.defination.should.not.be.empty";

	/**
	 * Should used in validations when rule defination is invalid
	 */
	String INVALID_RULE_DEFINATION = "mt.mgmt.invalid.rule.defination";
	
	/**
	 * should used in validation when data length is exceed with given value
	 */
	String DATA_LENGTH_EXCEEDED = "mt.mgmt.data.length.exceeded";
	
	String REMARK_MT_IS_MANDATORY = "mt.mgmt.remark.mt.is.mandatory";
	
	String GET_CONFIG_BY_STATUS_API_LOG_INFO ="mt.mgmt.getConfigByStatus.api.log.info";

}
