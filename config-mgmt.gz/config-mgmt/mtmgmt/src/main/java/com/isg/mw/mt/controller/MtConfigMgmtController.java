package com.isg.mw.mt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.mt.mgmt.constants.MtConfigUri;
import com.isg.mw.mt.mgmt.model.AddMtConfigModel;
import com.isg.mw.mt.mgmt.model.ModifyMtConfigModel;
import com.isg.mw.mt.mgmt.service.MtConfigMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * 
 * @author sanchita3984
 *
 */
@Tag (name = "Message Transformation Config", description = "Message Transformation Config API's")
@RestController
@RequestMapping(value = MtConfigUri.PARENT)
public class MtConfigMgmtController {

	@Autowired
	private MtConfigMgmtService MtConfigMgmtService;

	@Operation(summary = "API To Get Message Transformation configuration", description = "In response will get Message Transformation configuration by given name and entityId" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MtConfigUri.GET_BY_NAME, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> get(
			@PathVariable(value = "${swgr.mt.get.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.mt.get.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId) {
		return MtConfigMgmtService.get(name, entityId);
	}

	@Operation(summary = "API To Get All Active Message Transformation configuration", description = "In response will get all Active Message Transformation configuration" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MtConfigUri.GET_ALL , produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAllActive() {
		return MtConfigMgmtService.getAllActive();
	}

	@Operation(summary = "API To Get List of Message Transformation configuration", description = "In response will get list of Message Transformation configuration by given entityId" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MtConfigUri.GET_NAMES_ONLY, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getMessageTransformationsNames(
			@PathVariable(value = "${swgr.mt.getmtnames.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId) {
		return MtConfigMgmtService.getMessageTransformationsNames(entityId);
	}

	@Operation(summary = "API To Add Message Transformation configuration", description = "In response will get Message Transformation configuration" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = MtConfigUri.ADD)
	public ResponseEntity<?> add(@RequestBody AddMtConfigModel addModel) {
		return MtConfigMgmtService.add(addModel);
	}

	@Operation(summary = "API To Modify Message Transformation configuration", description = "In response will get Message Transformation configuration after update" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = MtConfigUri.MODIFY)
	public ResponseEntity<?> modify(@RequestBody ModifyMtConfigModel modifyModel) {
		return MtConfigMgmtService.modify(modifyModel);
	}

	@Operation(summary = "API To Submit Message Transformation configuration", description = "In response will get submit message" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = MtConfigUri.SUBMIT)
	public ResponseEntity<?> submit(
			@PathVariable(value = "${swgr.mt.submit.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.mt.submit.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId) {
		return MtConfigMgmtService.submit(name, entityId);
	}

	@Operation(summary = "API To Lock Message Transformation configuration", description = "In response will get lock state of Message Transformation configuration" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = MtConfigUri.LOCK)
	public ResponseEntity<?> lock(
			@PathVariable(value = "${swgr.mt.lock.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.mt.lock.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.mt.lock.lockstate.value}") @RequestParam(value = "lockedState",required = true) LockedState lockedState) {
		return MtConfigMgmtService.lock(name, entityId, lockedState);
	}

	@Operation(summary = "API To Verify Message Transformation configuration", description = "In response will get approved status of Message Transformation configuration" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = MtConfigUri.VERIFY)
	public ResponseEntity<?> verify(
			@PathVariable(value = "${swgr.mt.verify.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.mt.verify.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.mt.verify.approved.value}") @RequestParam(value = "approved",required = true) boolean approved,
			@PathVariable(value = "${swgr.mt.verify.remarks.value}") @RequestParam(value = "remarks" ,required = false) String remarks) {
		return MtConfigMgmtService.verify(name, entityId, approved,remarks);
	}

	@Operation(summary = "API To Change the Status Message Transformation configuration", description = "In response will get status message" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(value = MtConfigUri.UPDATE_STATUS)
	public ResponseEntity<?> updateStatus(
			@PathVariable(value = "${swgr.mt.updatestatus.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.mt.updatestatus.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.mt.updatestatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return MtConfigMgmtService.updateStatus(name, entityId, status);
	}
	
	@Operation(summary = "API To Get Message Transformation configuration", description = "In response will get Message Transformation configuration by given status" ,tags= {"Message Transformation Config"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MtConfigUri.GET_CONFIG_BY_STATUS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getConfigByStatus(
			@PathVariable(value = "${swgr.mt.getConfigByStatus.status.value}") @RequestParam(value = "status",required = true) String status) {
		return MtConfigMgmtService.getConfigByStatus(status);
	}

}
