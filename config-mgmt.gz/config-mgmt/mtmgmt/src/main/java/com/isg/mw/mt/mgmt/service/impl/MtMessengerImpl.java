package com.isg.mw.mt.mgmt.service.impl;

import com.isg.mw.core.filter.constants.FilterConstants;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.mt.MessageTransformationConfigMessage;
import com.isg.mw.kafka.IsgKafkaConfigs;
import com.isg.mw.kafka.KafkaTopics;
import com.isg.mw.mt.mgmt.service.MtMessenger;

@Service("MtMessenger")
public class MtMessengerImpl implements MtMessenger, InitializingBean, DisposableBean {

	@Autowired
	private IsgKafkaConfigs isgKafkaConfigs;

	@Autowired
	private KafkaTopics kafkaTopics;

	private KafkaProducer producer;

	public MtMessengerImpl() {
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public void afterPropertiesSet() throws Exception {

		producer = new KafkaProducer(isgKafkaConfigs.getKafkaConfig(kafkaTopics.getRouteDefTopicName()));
		producer.init();
		
	}

	@Override
	public void send(MessageTransformationConfigMessage model) {
		setTraceIdForAllModels(model);

		producer.sendMessage(getObjectData(model));
		
	}
	private void setTraceIdForAllModels(MessageTransformationConfigMessage model) {
		String acpTraceId = ThreadContext.get(FilterConstants.threadContextAcpTraceId);
		model.setAcpTraceId(acpTraceId);
	}

	private byte[] getObjectData(Object obj) {
		
		byte[] data = null;
		ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule())
				.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		try {
			data = objectMapper.writeValueAsBytes(obj);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return data;
		
	}

}
