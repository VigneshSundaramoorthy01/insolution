package com.isg.mw.mt.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mt.MessageTransformationConfigMessage;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mt.dao.entity.MessageTransformationEditCopyEntity;
import com.isg.mw.mt.dao.entity.MessageTransformationMasterEntity;
import com.isg.mw.mt.dao.service.MessageTransformationEditCopyService;
import com.isg.mw.mt.dao.service.MessageTransformationMasterService;
import com.isg.mw.mt.dao.service.MessageTransformationOnlineValidator;
import com.isg.mw.mt.dao.utils.MtMasterUtility;
import com.isg.mw.mt.dao.utils.MtUtility;
import com.isg.mw.mt.mgmt.constants.MtMgMtMsgKeys;
import com.isg.mw.mt.mgmt.model.AddMtConfigModel;
import com.isg.mw.mt.mgmt.model.ModifyMtConfigModel;
import com.isg.mw.mt.mgmt.service.MtConfigMgmtService;
import com.isg.mw.mt.mgmt.service.MtMessenger;
import com.isg.mw.mt.mgmt.utils.MtMgmtUtility;
import com.isg.mw.mt.mgmt.validations.MessageTransformationOfflineValidator;

/**
 * Implementation of {@link TargetConfigMgmtService}
 * 
 * @author prasad_t026
 *
 */
@Service("MtConfigMgmtService")
@Transactional
public class MtConfigMgmtServiceImpl implements MtConfigMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private MessageTransformationMasterService MessageTransformationMasterService;

	@Autowired
	private MessageTransformationEditCopyService MessageTransformationEditCopyService;

	@Autowired
	private MessageTransformationOnlineValidator MessageTransformationOnlineValidator;

	@Autowired
	private MessageTransformationOfflineValidator MessageTransformationOfflineValidator;

	@Autowired
	private MtMessenger MtMessenger;

	@Override
	public ResponseEntity<?> get(String name, String entityId) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.GET_API_LOG_INFO, name, entityId));
		ResponseEntity<?> response = null;
		try {
			Map<String, MessageTransformationConfigModel> map = new HashMap<String, MessageTransformationConfigModel>(
					2);
			MessageTransformationConfigModel master = MessageTransformationMasterService.findByNameAndEntityId(name,
					entityId);
			if (master != null) {
				map.put("master", master);
			}
			MessageTransformationConfigModel editCopy = MessageTransformationEditCopyService.findByNameAndEntityId(name,
					entityId);
			if (editCopy != null) {
				map.put("editCopy", editCopy);
			}
			if (!map.isEmpty()) {
				response = new ResponseEntity<>(map, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> getAllActive() {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.GETALL_API_LOG_INFO));
		ResponseEntity<?> response = null;
		try {
			List<MessageTransformationConfigModel> allConfig = MessageTransformationMasterService.getAllActive();
			if (!allConfig.isEmpty()) {
				response = new ResponseEntity<>(allConfig, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> getMessageTransformationsNames(String entityId) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.GETNAMES_API_LOG_INFO, entityId));
		ResponseEntity<?> response = null;
		try {
			List<String> names = MessageTransformationMasterService.getMsgTransformationNames(entityId);
			if (!names.isEmpty()) {
				response = new ResponseEntity<>(names, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> add(AddMtConfigModel addModel) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.ADD_API_LOG_INFO, addModel.getName()));
		ResponseEntity<?> response = null;
		try {

			MessageTransformationConfigModel rdModel = MtMgmtUtility.getMessageTransformationConfigModel(addModel);
			MessageTransformationOfflineValidator.addValidation(rdModel);
			MessageTransformationOnlineValidator.add(rdModel);
			MessageTransformationConfigModel resultModel = MessageTransformationEditCopyService.add(rdModel);
			response = new ResponseEntity<>(resultModel, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> modify(ModifyMtConfigModel modifyModel) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.MODIFY_API_LOG_INFO, modifyModel.getName()));
		ResponseEntity<?> response = null;
		try {
			MessageTransformationConfigModel rdModel = MtMgmtUtility.getMessageTransformationConfigModel(modifyModel);
			MessageTransformationOfflineValidator.modifyValidation(rdModel);
			MessageTransformationOnlineValidator.modify(rdModel);
			MessageTransformationConfigModel resultModel = MessageTransformationEditCopyService.update(rdModel);
			response = new ResponseEntity<>(resultModel, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> submit(String name, String entityId) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.SUBMIT_API_LOG_INFO, name, entityId));
		ResponseEntity<?> response = null;
		try {
			MessageTransformationOfflineValidator.submitValidation(name, entityId);
			MessageTransformationOnlineValidator.submit(name, entityId);
			String updateStatus = MessageTransformationEditCopyService.updateStatus(EditStatus.Submitted, name,
					entityId,null);
			response = new ResponseEntity<>(updateStatus, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> lock(String name, String entityId, LockedState lockedState) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.LOCK_API_LOG_INFO, name, entityId, lockedState));
		ResponseEntity<?> response = null;
		try {
			MessageTransformationOfflineValidator.lockValidation(name, entityId, lockedState);
			MessageTransformationOnlineValidator.lock(name, entityId, lockedState);
			LockedState lock = MessageTransformationMasterService.lock(name, entityId, lockedState);
			ConfigAction action = ConfigAction.UN_LOCKED;
			if (lock.equals(LockedState.Locked)) {
				action = ConfigAction.LOCKED;
			}
			sendMessage(name, entityId, action);

			response = new ResponseEntity<>(lock, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> verify(String name, String entityId, boolean approved,String remarks) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.VERIFY_API_LOG_INFO, entityId, approved));
		ResponseEntity<?> response = null;
		try {
			MessageTransformationOfflineValidator.verifyValidation(name, entityId, approved,remarks);
			MessageTransformationOnlineValidator.verify(name, entityId, approved);
			if (approved) {
				MessageTransformationEditCopyEntity editCopyEntity = MessageTransformationEditCopyService.get(name,
						entityId);
				MessageTransformationMasterEntity masterEntity = MessageTransformationMasterService.get(name, entityId);
				ConfigAction action = ConfigAction.MODIFY;
				if (masterEntity == null) {
					masterEntity = MtUtility.createMaster(editCopyEntity);
					action = ConfigAction.ADD;
				}
				MtUtility.updateMaster(editCopyEntity, masterEntity);
				masterEntity.setRemarks(StringUtils.isBlank(remarks)?null:remarks);
				masterEntity = MessageTransformationMasterService.save(masterEntity);
				MessageTransformationEditCopyService.delete(editCopyEntity);
				sendMessage(name, entityId, action);
			} else {
				MessageTransformationEditCopyService.updateStatus(EditStatus.Rejected, name, entityId,remarks);
			}
			response = new ResponseEntity<>(approved, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	@Override
	public ResponseEntity<?> updateStatus(String name, String entityId, String statusStr) {

		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.UPDATESTATUS_API_LOG_INFO, name, entityId, statusStr));
		ResponseEntity<?> response = null;
		try {
			MessageTransformationOfflineValidator.updateValidation(name, entityId, statusStr);
			MessageTransformationOnlineValidator.update(name, entityId, statusStr);
			ConfigStatus status = ConfigStatus.getStatus(statusStr);
			if (status != null) {

				MessageTransformationMasterService.updateStatus(name, entityId, status);
				ConfigAction action = ConfigAction.ACTIVATE;
				if (status == ConfigStatus.Inactive) {
					action = ConfigAction.INACTIVE;
				}
				sendMessage(name, entityId, action);

			} else {
				MessageTransformationEditCopyEntity editCopyEntity = MessageTransformationEditCopyService.get(name,
						entityId);
				MessageTransformationMasterEntity masterEntity = MessageTransformationMasterService.get(name, entityId);
				if (editCopyEntity == null) {
					editCopyEntity = new MessageTransformationEditCopyEntity();
				}

				MtUtility.updateEditCopy(masterEntity, editCopyEntity);
				editCopyEntity = MessageTransformationEditCopyService.save(editCopyEntity);
			}
			response = new ResponseEntity<>(statusStr, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

	private void sendMessage(String name, String entityId, ConfigAction configAction) {

		MessageTransformationMasterEntity masterEntity = MessageTransformationMasterService.get(name, entityId);
		MessageTransformationConfigModel rdModel = MtMasterUtility.getRdModel(masterEntity);
		MessageTransformationConfigMessage configMessage = new MessageTransformationConfigMessage();
		configMessage.setAction(configAction);
		configMessage.setModel(rdModel);
		MtMessenger.send(configMessage);

	}
	
	
	@Override
	public ResponseEntity<?> getConfigByStatus(String status) {
		LOG.info(PropertyUtils.getMessage(MtMgMtMsgKeys.GET_CONFIG_BY_STATUS_API_LOG_INFO, status));
		ResponseEntity<?> response = null;
		try {
			MessageTransformationOfflineValidator.configByStatusValidation(status);
			if (ConfigStatus.Active == ConfigStatus.getStatus(status)
					|| ConfigStatus.Inactive == ConfigStatus.getStatus(status)
					|| LockedState.Locked == LockedState.getState(status)
					|| LockedState.Unlocked == LockedState.getState(status)) {
				List<MessageTransformationConfigModel> entities = MessageTransformationMasterService
						.getConfigByStatus(status);
				response = new ResponseEntity<>(entities, HttpStatus.OK);
			} else if (EditStatus.Inprogress == EditStatus.getStatus(status)
					|| EditStatus.Rejected == EditStatus.getStatus(status)
					|| EditStatus.Submitted == EditStatus.getStatus(status)) {
				List<MessageTransformationConfigModel> entities = MessageTransformationEditCopyService
						.getConfigByStatus(status);
				response = new ResponseEntity<>(entities, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}
