package com.isg.mw.mt.mgmt.service.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mt.MessageDefinition;
import com.isg.mw.core.model.mt.MessageMappingDefinition;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mt.dao.entity.MessageTransformationEditCopyEntity;
import com.isg.mw.mt.dao.entity.MessageTransformationMasterEntity;
import com.isg.mw.mt.dao.service.MessageTransformationEditCopyService;
import com.isg.mw.mt.dao.service.MessageTransformationMasterService;
import com.isg.mw.mt.dao.service.MessageTransformationOnlineValidator;
import com.isg.mw.mt.dao.utils.MtCommonUtil;
import com.isg.mw.mt.mgmt.constants.MtMgMtMsgKeys;
import com.isg.mw.mt.mgmt.model.AddMtConfigModel;
import com.isg.mw.mt.mgmt.model.ModifyMtConfigModel;
import com.isg.mw.mt.mgmt.service.MtMessenger;
import com.isg.mw.mt.mgmt.service.impl.MtConfigMgmtServiceImpl;
import com.isg.mw.mt.mgmt.validations.MessageTransformationOfflineValidator;

public class MtConfigMgmtServiceTest {

	@Mock
	private MessageTransformationMasterService MessageTransformationMasterService;

	@Mock
	private MessageTransformationEditCopyService MessageTransformationEditCopyService;

	@Mock
	private MessageTransformationOnlineValidator MessageTransformationOnlineValidator;

	@Mock
	private MessageTransformationOfflineValidator MessageTransformationOfflineValidator;

	@Mock
	private MtMessenger MtMessenger;

	@InjectMocks
	private MtConfigMgmtServiceImpl MtConfigMgmtService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetP01() {
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEntityList().get(0));
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEditEntityList().get(0));
		ResponseEntity<?> responseEntity = MtConfigMgmtService.get("RD", "111");
		assertNotNull(responseEntity);
	}

	@Test
	public void testGetN01Null() {
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
		ResponseEntity<?> entity = MtConfigMgmtService.get("RD", "111");
		assertEquals(response, entity);
	}

	@Test
	public void testGetN02ValidationException() {
		Mockito.when(MessageTransformationMasterService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.get("RD", "111");
		assertEquals(response, entity);
	}

	@Test
	public void testGetN03Exception() {
		Mockito.when(MessageTransformationMasterService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.get("RD", "111");
		assertEquals(response, entity);
	}

	@Test
	public void testGetAllActiveP01() {
		Mockito.when(MessageTransformationMasterService.getAllActive()).thenReturn(getRouteDefinitionModelList());
		ResponseEntity<?> responseEntity = MtConfigMgmtService.getAllActive();
		assertNotNull(responseEntity);
	}

	@Test
	public void testGetAllActiveN01Null() {
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
		ResponseEntity<?> entity = MtConfigMgmtService.getAllActive();
		assertEquals(response, entity);
	}

	@Test
	public void testGetAllActiveN02ValidationException() {
		Mockito.when(MessageTransformationMasterService.getAllActive())
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.getAllActive();
		assertEquals(response, entity);
	}

	@Test
	public void testGetAllActiveN03Exception() {
		Mockito.when(MessageTransformationMasterService.getAllActive())
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.getAllActive();
		assertEquals(response, entity);
	}

	@Test
	public void testGetRouteDefinitionNamesP01() {
		Mockito.when(MessageTransformationMasterService.getMsgTransformationNames(Mockito.anyString())).thenReturn(getRoutesNamesList());
		ResponseEntity<?> entity = MtConfigMgmtService.getMessageTransformationsNames("111");
		assertNotNull(entity);
	}

	@Test
	public void testGetRouteDefinitionNamesN01Null() {
		Mockito.when(MessageTransformationMasterService.getMsgTransformationNames(Mockito.anyString())).thenReturn(new ArrayList<>());
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.MT_LIST_EMPTY);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
		ResponseEntity<?> entity = MtConfigMgmtService.getMessageTransformationsNames("111");
		assertEquals(response, entity);
	}

	@Test
	public void testGetRouteDefinitionNamesN02ValidationException() {
		Mockito.when(MessageTransformationMasterService.getMsgTransformationNames(Mockito.anyString()))
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.getMessageTransformationsNames("111");
		assertEquals(response, entity);
	}

	@Test
	public void testGetRouteDefinitionNamesN03Exception() {
		Mockito.when(MessageTransformationMasterService.getMsgTransformationNames(Mockito.anyString())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.getMessageTransformationsNames("111");
		assertEquals(response, entity);
	}

	@Test
	public void testAddOk() {
		Mockito.when(MessageTransformationEditCopyService.add(Mockito.any()))
				.thenReturn(getRouteDefinitionModelList().get(0));
		ResponseEntity<?> entity = MtConfigMgmtService.add(getAddRouteModel());
		assertNotNull(entity);
	}

	@Test
	public void testAddValidationException() {
		Mockito.when(MessageTransformationEditCopyService.add(Mockito.any())).thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.add(getAddRouteModel());
		assertEquals(response, entity);
	}

	@Test
	public void testAddException() {
		Mockito.when(MessageTransformationEditCopyService.add(Mockito.any())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.add(getAddRouteModel());
		assertEquals(response, entity);
	}

	@Test
	public void testModifyOk() {
		Mockito.when(MessageTransformationEditCopyService.update(Mockito.any()))
				.thenReturn(getRouteDefinitionModelList().get(0));
		ResponseEntity<?> entity = MtConfigMgmtService.modify(getModifyRouteModel());
		assertNotNull(entity);
	}

	@Test
	public void testModifyValidationException() {
		Mockito.when(MessageTransformationEditCopyService.update(Mockito.any())).thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.modify(getModifyRouteModel());
		assertEquals(response, entity);
	}

	@Test
	public void testModifyException() {
		Mockito.when(MessageTransformationEditCopyService.update(Mockito.any())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.modify(getModifyRouteModel());
		assertEquals(response, entity);
	}

	@Test
	public void testSubmitOk() {
		Mockito.when(MessageTransformationEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionModelList().get(0));
		Mockito.when(MessageTransformationEditCopyService.updateStatus(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(EditStatus.Submitted.name());
		ResponseEntity<?> entity = MtConfigMgmtService.submit("RD", "111");
		assertNotNull(entity);
	}

	@Test
	public void testSubmitValidationException() {
		Mockito.when(MessageTransformationEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionModelList().get(0));
		Mockito.when(MessageTransformationEditCopyService.updateStatus(Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.submit("RD", "111");
		assertEquals(response, entity);
	}

	@Test
	public void testSubmitException() {
		Mockito.when(MessageTransformationEditCopyService.findByNameAndEntityId(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionModelList().get(0));
		Mockito.when(MessageTransformationEditCopyService.updateStatus(Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.submit("RD", "111");
		assertEquals(response, entity);
	}

	@Test
	public void testLockOk() {
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEntityList().get(0));
		Mockito.when(MessageTransformationMasterService.lock(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenReturn(LockedState.Locked);
		ResponseEntity<?> entity = MtConfigMgmtService.lock("RD", "111", LockedState.Locked);
		assertNotNull(entity);
	}

	@Test
	public void testLockValidationException() {
		Mockito.when(MessageTransformationMasterService.lock(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.lock("RD", "111", LockedState.Locked);
		assertEquals(response, entity);
	}

	@Test
	public void testLockException() {
		Mockito.when(MessageTransformationMasterService.lock(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.lock("RD", "111", LockedState.Locked);
		assertEquals(response, entity);
	}

	@Test // throw exception
	public void testVerifyOkP01() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEditEntityList().get(0));
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEntityList().get(0));
		ResponseEntity<?> entity = MtConfigMgmtService.verify("RD", "111", true,null);
		assertNotNull(entity);
	}

	@Test
	public void testVerifyOkP02() {
		ResponseEntity<?> entity = MtConfigMgmtService.verify("RD", "111", false,null);
		assertNotNull(entity);
	}

	@Test
	public void testVerifyOkN01() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEditEntityList().get(0));
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		ResponseEntity<?> entity = MtConfigMgmtService.verify("RD", "111", true,null);
		assertNotNull(entity);
	}

	@Test
	public void testVerifyValidationException() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.verify("RD", "111", true,null);
		assertEquals(response, entity);
	}

	@Test
	public void testVerifyException() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.verify("RD", "111", true,null);
		assertEquals(response, entity);
	}

	@Test
	public void testUpdateStatusOkP01() {
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEntityList().get(0));
		Mockito.when(MessageTransformationMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenReturn(ConfigStatus.Active);
		ResponseEntity<?> entity = MtConfigMgmtService.updateStatus("RD", "111", ConfigStatus.Active.name());
		assertNotNull(entity);
	}

	@Test
	public void testUpdateStatusOkP02() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEditEntityList().get(0));
		Mockito.when(MessageTransformationMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenReturn(ConfigStatus.Active);
		ResponseEntity<?> entity = MtConfigMgmtService.updateStatus("RD", "111", ConfigStatus.Inactive.name());
		assertNotNull(entity);
	}

	@Test // throw error
	public void testUpdateStatusOkP03() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEditEntityList().get(0));
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEntityList().get(0));
		ResponseEntity<?> entity = MtConfigMgmtService.updateStatus("RD", "111", null);
		assertNotNull(entity);
	}

	@Test
	public void testUpdateStatusOkP04() {
		Mockito.when(MessageTransformationEditCopyService.get(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		Mockito.when(MessageTransformationMasterService.get(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getRouteDefinitionEntityList().get(0));
		ResponseEntity<?> entity = MtConfigMgmtService.updateStatus("RD", "111", null);
		assertNotNull(entity);
	}

	@Test
	public void testUpdateStatusValidationException() {
		Mockito.when(MessageTransformationMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenThrow(ValidationException.class);
		String errMsg = ("Unknown message");
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = MtConfigMgmtService.updateStatus("RD", "111", ConfigStatus.Active.name());
		assertEquals(response, entity);
	}

	@Test
	public void testUpdateStatusException() {
		Mockito.when(MessageTransformationMasterService.updateStatus(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MtMgMtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = MtConfigMgmtService.updateStatus("RD", "111", ConfigStatus.Active.name());
		assertEquals(response, entity);
	}

	private AddMtConfigModel getAddRouteModel() {
		AddMtConfigModel model = new AddMtConfigModel();
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		//model.setCreatedBy("ISG Client");
		return model;
	}

	private ModifyMtConfigModel getModifyRouteModel() {
		ModifyMtConfigModel model = new ModifyMtConfigModel();
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		//model.setUpdatedBy("ISG Admin");
		return model;
	}

	private List<MessageTransformationEditCopyEntity> getRouteDefinitionEditEntityList() {
		List<MessageTransformationEditCopyEntity> list = new ArrayList<MessageTransformationEditCopyEntity>();
		MessageTransformationEditCopyEntity entity = new MessageTransformationEditCopyEntity();
		entity.setId(1L);
		entity.setEntityId("111");
		entity.setName("RD");
		entity.setRouteDef(MtCommonUtil.convertRulesToString(getRules()));
		entity.setDescription("Messsage format description");
		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setCreatedBy("ISG Client");
		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setUpdatedBy("ISG Admin");
		entity.setStatus(EditStatus.Inprogress);
		list.add(entity);
		return list;
	}

	private List<MessageTransformationMasterEntity> getRouteDefinitionEntityList() {
		List<MessageTransformationMasterEntity> list = new ArrayList<MessageTransformationMasterEntity>();
		MessageTransformationMasterEntity entity = new MessageTransformationMasterEntity();
		entity.setId(1L);
		entity.setEntityId("111");
		entity.setName("RD");
		entity.setRouteDef(MtCommonUtil.convertRulesToString(getRules()));
		entity.setDescription("Messsage format description");
		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setCreatedBy("ISG Client");
		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setUpdatedBy("ISG Admin");
		entity.setStatus(ConfigStatus.Active);
		entity.setLockedState(LockedState.Unlocked);
		list.add(entity);
		return list;
	}

	private List<MessageTransformationConfigModel> getRouteDefinitionModelList() {
		List<MessageTransformationConfigModel> list = new ArrayList<MessageTransformationConfigModel>();
		MessageTransformationConfigModel model = new MessageTransformationConfigModel();
		model.setId(1L);
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		model.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		model.setCreatedBy("ISG Client");
		model.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		model.setUpdatedBy("ISG Admin");
		model.setStatus(ConfigStatus.Active.name());
		model.setLockedState(LockedState.Unlocked);
		list.add(model);
		return list;
	}

	private List<MessageMappingDefinition> getRules() {
		List<MessageMappingDefinition> list = new ArrayList<MessageMappingDefinition>();
		MessageMappingDefinition rules = new MessageMappingDefinition();
		rules.setName("purchase");
		rules.setSrc(getSrc());
		rules.setDest(getDest());
		list.add(rules);
		return list;
	}

	private MessageDefinition getSrc() {
		MessageDefinition src = new MessageDefinition();
		src.setTargetType(TargetType.Pos);
		src.setMsgType("0200");
		src.setMsgTypeId("000000");
		return src;
	}

	private MessageDefinition getDest() {
		MessageDefinition dest = new MessageDefinition();
		dest.setTargetType(TargetType.Pos);
		dest.setMsgType("0200");
		dest.setMsgTypeId("000000");
		return dest;
	}

	private List<String> getRoutesNamesList() {
		List<String> list = new ArrayList<String>();
		list.add("Rupay");
		list.add("Visa");
		list.add("Master");
		return list;
	}

}
