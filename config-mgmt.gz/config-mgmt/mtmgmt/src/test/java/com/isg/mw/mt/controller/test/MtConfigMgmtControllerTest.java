package com.isg.mw.mt.controller.test;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.mt.MessageDefinition;
import com.isg.mw.core.model.mt.MessageMappingDefinition;
import com.isg.mw.mt.controller.MtConfigMgmtController;
import com.isg.mw.mt.mgmt.constants.MtConfigUri;
import com.isg.mw.mt.mgmt.model.AddMtConfigModel;
import com.isg.mw.mt.mgmt.model.ModifyMtConfigModel;
import com.isg.mw.mt.mgmt.service.impl.MtConfigMgmtServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
public class MtConfigMgmtControllerTest {

	private MockMvc mockMvc;

	@Mock
	private MtConfigMgmtServiceImpl MtConfigMgmtService;

	@InjectMocks
	private MtConfigMgmtController MtConfigMgmtController;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.standaloneSetup(MtConfigMgmtController).build();
	}

	@Test
	public void testGet() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.GET_BY_NAME)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString()))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testGetAllActive() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.GET_ALL))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testGetRouteDefinitionNames() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.GET_NAMES_ONLY)
		.param("entityId", Mockito.anyString())).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testAdd() throws Exception {
		AddMtConfigModel addRdModel = getAddRouteModel();
		String requestBody = new ObjectMapper().valueToTree(addRdModel).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(MtConfigUri.PARENT + MtConfigUri.ADD).content(requestBody)
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testModify() throws Exception {
		ModifyMtConfigModel modifyRdModel = getModifyRouteModel();
		String requestBody = new ObjectMapper().valueToTree(modifyRdModel).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(MtConfigUri.PARENT + MtConfigUri.MODIFY).content(requestBody)
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testSubmit() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.SUBMIT)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString()))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testUpdateStatus() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.UPDATE_STATUS)
				.param("name", Mockito.anyString()).param("entityId", Mockito.anyString())
				.param("status", Mockito.anyString())).andExpect(MockMvcResultMatchers.status().isOk());
	}

//	@Test
	public void testLock() throws Exception {
		mockMvc.perform(
				MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.LOCK).param("name", Mockito.anyString())
						.param("entityId", Mockito.anyString()).param("lockedState", Mockito.anyString()))
				.andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testVerify() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("name", "RD");
		requestParams.add("entityId", "111");
		requestParams.add("approved", "true");

		mockMvc.perform(MockMvcRequestBuilders.get(MtConfigUri.PARENT + MtConfigUri.VERIFY).params(requestParams))
				.andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}

	private AddMtConfigModel getAddRouteModel() {
		AddMtConfigModel model = new AddMtConfigModel();
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		//model.setCreatedBy("ISG Client");
		return model;
	}

	private ModifyMtConfigModel getModifyRouteModel() {
		ModifyMtConfigModel model = new ModifyMtConfigModel();
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		//model.setUpdatedBy("ISG Admin");
		return model;
	}

	private List<MessageMappingDefinition> getRules() {
		List<MessageMappingDefinition> list = new ArrayList<MessageMappingDefinition>();
		MessageMappingDefinition rules = new MessageMappingDefinition();
		rules.setName("purchase");
		rules.setSrc(getSrc());
		rules.setDest(getDest());
		list.add(rules);
		return list;
	}

	private MessageDefinition getSrc() {
		MessageDefinition src = new MessageDefinition();
		src.setTargetType(TargetType.Pos);
		src.setMsgType("0200");
		src.setMsgTypeId("000000");
		return src;
	}

	private MessageDefinition getDest() {
		MessageDefinition dest = new MessageDefinition();
		dest.setTargetType(TargetType.Pos);
		dest.setMsgType("0200");
		dest.setMsgTypeId("000000");
		return dest;
	}

}
