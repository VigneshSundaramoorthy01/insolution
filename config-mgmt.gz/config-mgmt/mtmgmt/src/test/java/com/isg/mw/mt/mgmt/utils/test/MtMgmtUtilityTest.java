package com.isg.mw.mt.mgmt.utils.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.mt.MessageDefinition;
import com.isg.mw.core.model.mt.MessageMappingDefinition;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.mt.mgmt.model.AddMtConfigModel;
import com.isg.mw.mt.mgmt.model.ModifyMtConfigModel;
import com.isg.mw.mt.mgmt.utils.MtMgmtUtility;

public class MtMgmtUtilityTest {

	@Test
	public void testGetMessageTransformationConfigModelForAdd() {
		AddMtConfigModel addModel = getAddRouteModel();
		MessageTransformationConfigModel routeModel = MtMgmtUtility.getMessageTransformationConfigModel(getAddRouteModel());
		assertEquals(addModel.getEntityId(), routeModel.getEntityId());
		assertEquals(addModel.getName(), routeModel.getName());
		assertNotNull(routeModel.getRules());
		assertEquals(addModel.getDescription(), routeModel.getDescription());
		//assertEquals(addModel.getCreatedBy(), routeModel.getCreatedBy());
	}

	@Test
	public void testGetMessageTransformationConfigModelForModify() {
		ModifyMtConfigModel addModel = getModifyRouteModel();
		MessageTransformationConfigModel routeModel = MtMgmtUtility.getMessageTransformationConfigModel(getModifyRouteModel());
		assertEquals(addModel.getEntityId(), routeModel.getEntityId());
		assertEquals(addModel.getName(), routeModel.getName());
		assertNotNull(routeModel.getRules());
		assertEquals(addModel.getDescription(), routeModel.getDescription());
		//assertEquals(addModel.getUpdatedBy(), routeModel.getUpdatedBy());
	}

	private AddMtConfigModel getAddRouteModel() {
		AddMtConfigModel model = new AddMtConfigModel();
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		//model.setCreatedBy("ISG Client");
		return model;
	}

	private ModifyMtConfigModel getModifyRouteModel() {
		ModifyMtConfigModel model = new ModifyMtConfigModel();
		model.setEntityId("111");
		model.setName("RD");
		model.setRules(getRules());
		model.setDescription("Messsage format description");
		//model.setUpdatedBy("ISG Admin");
		return model;
	}

	private List<MessageMappingDefinition> getRules() {
		List<MessageMappingDefinition> list = new ArrayList<MessageMappingDefinition>();
		MessageMappingDefinition rules = new MessageMappingDefinition();
		rules.setName("purchase");
		rules.setSrc(getSrc());
		rules.setDest(getDest());
		list.add(rules);
		return list;
	}

	private MessageDefinition getSrc() {
		MessageDefinition src = new MessageDefinition();
		src.setTargetType(TargetType.Pos);
		src.setMsgType("0200");
		src.setMsgTypeId("000000");
		return src;
	}

	private MessageDefinition getDest() {
		MessageDefinition dest = new MessageDefinition();
		dest.setTargetType(TargetType.Pos);
		dest.setMsgType("0200");
		dest.setMsgTypeId("000000");
		return dest;
	}

}
