package com.isg.mw.mf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.mf.mgmt.constants.MessageFormatUri;
import com.isg.mw.mf.mgmt.model.AddIsgVanillaMfConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.MessageFormatIsgVanillaMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Message Format ISG Vanilla Configuration Rest APIs
 * 
 * @author prasad_t026
 *
 */
@Tag (name = "Isg Vanilla Message Format", description = "Isg Vanilla Message Format APIs")
@RestController
@RequestMapping(value = MessageFormatUri.PARENT_ISG)
public class MessageFormatIsgVanillaConfigController {

	@Autowired
	private MessageFormatIsgVanillaMgmtService messageFormatIsgVanillaMgmtService;

	/**
	 * Message Format ISG Vanilla Configuration Rest add API
	 * 
	 * @param addModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Add Isg Vanilla Message Format configuration", description = "In response will get Isg Vanilla Message Format configuration" ,tags= {"Isg Vanilla Message Format"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = MessageFormatUri.ADD_ISG)
	public ResponseEntity<?> add(@RequestBody AddIsgVanillaMfConfigModel addModel) {
		return messageFormatIsgVanillaMgmtService.add(addModel);
	}

	/**
	 * Message Format ISG Vanilla Configuration Rest modify API
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Modify Isg Vanilla Message Format configuration", description = "In response will get Isg Vanilla Message Format configuration after update" ,tags= {"Isg Vanilla Message Format"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = MessageFormatUri.MODIFY_ISG)
	public ResponseEntity<?> modify(@RequestBody ModifyMessageFormatConfigModel configModel) {
		return messageFormatIsgVanillaMgmtService.modify(configModel);
	}

	/**
	 * Message Format ISG Vanilla Configuration Rest delete API
	 * 
	 * @param id - id of model object present in DB
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Delete Isg Vanilla Message Format configuration", description = "In response will get success message after delete Message Format configuration" ,tags= {"Isg Vanilla Message Format"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MessageFormatUri.DELETE_ISG)
	public ResponseEntity<?> delete(
			@PathVariable(value = "${swgr.mfic.delete.id.value}") @RequestParam(value = "id",required = true) Long id) {
		return messageFormatIsgVanillaMgmtService.delete(id);
	}

	/**
	 * Message Format ISG Vanilla Configuration Rest getList API
	 * 
	 * @param msgType - message type of model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get List Of Isg Vanilla Message Format configuration", description = "In response will get list of Isg Vanilla Message Format configuration" ,tags= {"Isg Vanilla Message Format"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MessageFormatUri.GET_LIST_ISG, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getList(
			@PathVariable(value = "${swgr.mfic.getlist.msgType.value}") @RequestParam(value = "msgType",required = true) String msgType) {
		return messageFormatIsgVanillaMgmtService.getList(msgType);
	}

}
