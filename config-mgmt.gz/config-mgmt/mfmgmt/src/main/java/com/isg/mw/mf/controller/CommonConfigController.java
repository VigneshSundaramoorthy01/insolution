package com.isg.mw.mf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.mgmt.constants.MessageFormatUri;
import com.isg.mw.mf.mgmt.service.ConfigMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Configuration Rest APIS
 * 
 * @author sanchita3984
 *
 */
@Tag (name = "Common Configurations (source/target)", description = "Common apis for configurations (source/target)")
@RestController
@RequestMapping(value = MessageFormatUri.PARENT_VD)
public class CommonConfigController {

	@Autowired
	private ConfigMgmtService configMgmtService;

	/**
	 * Configuration Rest validate API
	 * 
	 * @param entityId  - entity id of configuration object
	 * @param ownerName - owner name id of message format model
	 * @param ownerType -SOURCE or TARGET or ISG_VANILLA configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 * 
	 */
	@Operation(summary = "API To Get Valid Common Configurations(Source/Target)", description = "In response will get Common Configurations by given entityId,ownerName and ownerType" ,tags= {"Common Configurations (source/target)"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MessageFormatUri.VALIDATE_VD, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> validate(
			@PathVariable(value = "${swgr.cc.validate.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.cc.validate.name.value}") @RequestParam(value = "ownerName",required = true) String ownerName,
			@PathVariable(value = "${swgr.cc.validate.ownerType.value}") @RequestParam(value = "ownerType",required = true) OwnerType ownerType) {
		return configMgmtService.validate(entityId, ownerName, ownerType);
	}

	/**
	 * Configuration Rest getAll API
	 * 
	 * @param entityId  -entity id of configuration object
	 * @param ownerType -SOURCE or TARGET or ISG_VANILLA configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get All Common Configurations", description = "In response will get all Common Configurations by given entityId and ownerType" ,tags= {"Common Configurations (source/target)"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MessageFormatUri.GET_ALL, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getAll(
			@PathVariable(value = "${swgr.cc.getall.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.cc.getall.ownerType.value}") @RequestParam(value = "ownerType",required = true) OwnerType ownerType) {
		return configMgmtService.getAll(entityId, ownerType);
	}

}
