package com.isg.mw.mf.mgmt.model;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.BusinessRule;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Model use in add API of Message format Controller which contain Message
 * format configuration fields
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "Add message format configuration model")
@Getter
@Setter
public class AddMessageFormatConfigModel {
	/**
	 * Entity id of the specific configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.entityId.value}")
	private String entityId;
	/**
	 * name of the of specific configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.name.value}")
	private String ownerName;
	/**
	 * SOURCE or TARGET or ISG_VANILLA configuration
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.ownerType.value}")
	private OwnerType ownerType;
	/**
	 * message transaction type
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.msgType.value}")
	private String msgType;
	/**
	 * message format
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.msgFormat.value}")
	private String msgFormat;
	/**
	 * description of the message type
	 */
	@ApiModelProperty(value = "${swgr.mfc.model.add.description.value}")
	private String description;
	/**
	 * created user name
	 */
	//@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.createdBy.value}")
	//private String createdBy;
	/**
	 * Business Rule
	 */
	@ApiModelProperty(value = "${swgr.mfc.model.add.businessRule.value}")
	private BusinessRule businessRule;

}
