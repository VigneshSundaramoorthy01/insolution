package com.isg.mw.mf.mgmt.validations;

import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;

/**
 * Interface for operations on a Validations for a Message format Private
 * Offline Validation
 * 
 * @author prasad_t026
 *
 */
public interface MfPrivateOfflineValidator {
	/**
	 * Offline Validation for add API in Message format Private Offline Validation
	 * 
	 * @param addModel - model object
	 */
	void addValidation(AddMessageFormatConfigModel addModel);

	/**
	 * Offline Validation for modify API in Message format Private Offline
	 * Validation
	 * 
	 * @param updateModel - model object
	 */
	void modifyValidation(ModifyMessageFormatConfigModel updateModel);

}
