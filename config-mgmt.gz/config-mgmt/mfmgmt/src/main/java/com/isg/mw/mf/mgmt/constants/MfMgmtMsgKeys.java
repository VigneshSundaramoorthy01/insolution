package com.isg.mw.mf.mgmt.constants;

/**
 * Message keys of Message format management
 * 
 * @author prasad_t026
 *
 */
public interface MfMgmtMsgKeys {
	/**
	 * Internal error
	 */
	String INTERNAL_ERROR = "mf.mgmt.internal.error";
	/**
	 * add Message Format requested
	 */
	String MFP_ADD_API_LOG_INFO = "mfp.mgmt.add.api.log.info";
	/**
	 * Update Message Format requested for {0}
	 */
	String MFP_MODIFY_API_LOG_INFO = "mfp.mgmt.modify.api.log.info";
	/**
	 * Delete Message Format requested for id {0} and OwnerType {1}
	 */
	String MFP_DELETE_API_LOG_INFO = "mfp.mgmt.delete.api.log.info";
	/**
	 * get list api requested for message format entityId {0}, config name {1} and
	 * OwnerType {2}
	 */
	String MFP_GET_LIST_API_LOG_INFO = "mfp.mgmt.getlist.api.log.info";
	/**
	 * message format list is empty
	 */
	String MFP_LIST_EMPTY = "mfp.mgmt.list.empty";
	/**
	 * add Message Format requested
	 */
	String MFI_ADD_API_LOG_INFO = "mfi.mgmt.add.api.log.info";
	/**
	 * Update Message Format requested for {0}
	 */
	String MFI_MODIFY_API_LOG_INFO = "mfi.mgmt.modify.api.log.info";
	/**
	 * Delete Message Format requested for id {0}
	 */
	String MFI_DELETE_API_LOG_INFO = "mfi.mgmt.delete.api.log.info";
	/**
	 * get list api requested for message format type {0}
	 */
	String MFI_GET_LIST_API_LOG_INFO = "mfi.mgmt.getlist.api.log.info";
	/**
	 * message format list is empty
	 */
	String MFI_LIST_EMPTY = "mfi.mgmt.list.empty";
	/**
	 * Invalid Owner Type {0}
	 */
	String OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG = "mfi.mgmt.owner.type.not.belong.to.any.config";
	/**
	 * Invalid message format id {0}
	 */
	String INVALID_MF_ID_ERROR = "mfi.mgmt.invalide.id";
	/**
	 * Validate api requested for config entityId {0}, config name {1} and OwnerType
	 * {2}
	 */
	String CC_VALIDATOR_API_LOG_INFO = "cc.mgmt.validator.api.log.info";
	/**
	 * get all api requested for config entityId {0} and owner type {1} .
	 */
	String CC_API_LOG_INFO = "cc.mgmt.getall.api.log.info";
	/**
	 * {0} field is mandatory
	 */
	String Field_IS_MANDATORY = "cc.mgmt.field.is.mandatory";

}
