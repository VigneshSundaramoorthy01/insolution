package com.isg.mw.mf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.mgmt.constants.MessageFormatUri;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.MessageFormatConfigMgmtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Message Format Configuration Rest APIs
 * 
 * @author prasad_t026
 *
 */
@Tag (name = "Message Format Configuration", description = "Message Format Configuration APIs for Source or Target Configurations")
@RestController
@RequestMapping(value = MessageFormatUri.PARENT_PR)
public class MessageFormatPrivateConfigController {

	@Autowired
	private MessageFormatConfigMgmtService messageFormatConfigMgmtService;

	/**
	 * Message Format Configuration Rest add API
	 * 
	 * @param addModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Add Message Format Configuration", description = "In response will get Message Format Configuration" ,tags= {"Message Format Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = MessageFormatUri.ADD_PR)
	public ResponseEntity<?> add(@RequestBody AddMessageFormatConfigModel addModel) {
		return messageFormatConfigMgmtService.add(addModel);
	}

	/**
	 * Message Format Configuration Rest modify API
	 * 
	 * @param configModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Modify Message Format Configuration", description = "In response will get Message Format Configuration after update" ,tags= {"Message Format Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = MessageFormatUri.MODIFY_PR)
	public ResponseEntity<?> modify(@RequestBody ModifyMessageFormatConfigModel configModel) {
		return messageFormatConfigMgmtService.modify(configModel);
	}

	/**
	 * Message Format Configuration Rest delete API
	 * 
	 * @param id        - id of model object present in DB
	 * @param ownerType - owner type id of model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Delete Message Format Configuration", description = "In response will get success message after delete Message Format Configuration" ,tags= {"Message Format Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MessageFormatUri.DELETE_PR)
	public ResponseEntity<?> delete(
			@PathVariable(value = "${swgr.mfpc.delete.id.value}") @RequestParam(value = "id",required = true) Long id,
			@PathVariable(value = "${swgr.mfpc.delete.ownerType.value}") @RequestParam(value = "ownerType",required = true) OwnerType ownerType) {
		return messageFormatConfigMgmtService.delete(id, ownerType);
	}

	/**
	 * Message Format Configuration Rest getList API
	 * 
	 * @param entityId  - entity id of model object
	 * @param name      - name of model object
	 * @param ownerType - owner type id of model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	@Operation(summary = "API To Get List Of Message Format Configuration", description = "In response will get list of Message Format Configuration" ,tags= {"Message Format Configuration"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.GET)
	@GetMapping(path = MessageFormatUri.GET_LIST_PR, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getList(
			@PathVariable(value = "${swgr.mfpc.getlist.entityId.value}") @RequestParam(value = "entityId",required = true) String entityId,
			@PathVariable(value = "${swgr.mfpc.getlist.name.value}") @RequestParam(value = "name",required = true) String name,
			@PathVariable(value = "${swgr.mfpc.getlist.ownerType.value}") @RequestParam(value = "ownerType",required = true) OwnerType ownerType) {
		return messageFormatConfigMgmtService.getList(entityId, name, ownerType);
	}

}
