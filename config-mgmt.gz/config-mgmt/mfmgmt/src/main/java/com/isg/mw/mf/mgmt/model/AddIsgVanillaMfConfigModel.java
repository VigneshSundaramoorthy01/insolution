package com.isg.mw.mf.mgmt.model;

import com.isg.mw.core.model.mf.BusinessRule;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Model use in add API of ISG Vanilla Message format Controller which contain
 * ISG Vanilla Message format configuration fields
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "${swgr.mfc.model.add.vanilla}")
@Getter
@Setter
public class AddIsgVanillaMfConfigModel {
	/**
	 * message transaction type
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.vanilla.msgType.value}")
	private String msgType;
	/**
	 * message format
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.add.vanilla.msgFormat.value}")
	private String msgFormat;
	/**
	 * description of the message type
	 */
	@ApiModelProperty(value = "${swgr.tmf.model.add.vanilla.description.value}")
	private String description;
	/**
	 * created user name
	 */
	//@ApiModelProperty(required = true, value = "${swgr.tcc.model.add.vanilla.createdBy.value}")
	//private String createdBy;
	/**
	 * Business Rule
	 */
	@ApiModelProperty(value = "${swgr.mfc.model.add.vanilla.businessRule.value}")
	private BusinessRule businessRule;

}
