package com.isg.mw.mf.mgmt.service;

import org.springframework.http.ResponseEntity;

import com.isg.mw.mf.mgmt.model.AddIsgVanillaMfConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;

/**
 * Interface for operations on a services for a ISG Vanilla Message format
 * configuration management service
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatIsgVanillaMgmtService {
	/**
	 * Add ISG Vanilla Message format configuration model in DB
	 * 
	 * @param addModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */

	ResponseEntity<?> add(AddIsgVanillaMfConfigModel addModel);

	/**
	 * Modify ISG Vanilla Message format configuration model in DB
	 * 
	 * @param updateModel - model object
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */

	ResponseEntity<?> modify(ModifyMessageFormatConfigModel updateModel);

	/**
	 * delete ISG Vanilla Message format configuration model in DB base on id
	 * 
	 * @param id - DB ID
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> delete(Long id);

	/**
	 * get list of ISG Vanilla Message format configuration model from DB base on
	 * message type
	 * 
	 * @param msgType -message transaction type
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> getList(String msgType);

}
