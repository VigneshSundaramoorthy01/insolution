package com.isg.mw.mf.mgmt.validations;

import com.isg.mw.core.model.constants.OwnerType;

/**
 * Interface for operations on a Validations for a Configuration Offline
 * Validation
 * 
 * @author sanchita3984
 *
 */
public interface ConfigOfflineValidator {
	/**
	 * Offline Validation for validation API
	 * 
	 * @param entityId  - entity id of configuration model
	 * @param ownerName - name of the of specific configuration
	 * @param ownerType -SOURCE or TARGET or ISG_VANILLA configuration
	 */
	void validateValidation(String entityId, String ownerName, OwnerType ownerType);

	/**
	 * Offline Validation for getAll API
	 * 
	 * @param entityId - entity id of configuration model
	 * @param type     - SOURCE or TARGET or ISG_VANILLA configuration
	 */
	void getAllValidation(String entityId, OwnerType type);

}
