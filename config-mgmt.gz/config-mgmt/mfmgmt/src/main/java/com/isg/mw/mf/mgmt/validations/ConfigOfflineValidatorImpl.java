package com.isg.mw.mf.mgmt.validations;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;

/**
 * Class Implements {@link ConfigOfflineValidator}
 * 
 * @author rahul3983
 *
 */
@Service
public class ConfigOfflineValidatorImpl implements ConfigOfflineValidator {

	@Override
	public void validateValidation(String entityId, String ownerName, OwnerType ownerType) {
		
		if (StringUtils.isBlank(ownerName)) {
			throw new ValidationException(MfMgmtMsgKeys.Field_IS_MANDATORY, FieldsInfo.NAME_FN);
		}
		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(MfMgmtMsgKeys.Field_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}
		if (ownerType == null) {
			throw new ValidationException(MfMgmtMsgKeys.Field_IS_MANDATORY, FieldsInfo.OWNER_TYPE_FN);
		}

	}

	@Override
	public void getAllValidation(String entityId, OwnerType type) {
		
		if (StringUtils.isBlank(entityId)) {
			throw new ValidationException(MfMgmtMsgKeys.Field_IS_MANDATORY, FieldsInfo.ENTITY_ID_FN);
		}

	}

}
