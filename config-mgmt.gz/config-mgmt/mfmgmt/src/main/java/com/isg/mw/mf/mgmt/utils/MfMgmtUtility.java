package com.isg.mw.mf.mgmt.utils;

import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.AddIsgVanillaMfConfigModel;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;

/**
 * Utility for Message format Configuration
 * 
 * @author prasad_t026
 *
 */
public class MfMgmtUtility {

	/**
	 * constructor should not access outside
	 */
	private MfMgmtUtility() {
	}

	/**
	 * convert AddMessageFormatConfigModel to MessageFormatConfigModel
	 * 
	 * @param addModel - model object
	 * @return - MessageFormatConfigModel
	 */
	public static MessageFormatConfigModel getMessageFormatModel(AddMessageFormatConfigModel addModel) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setOwnerType(addModel.getOwnerType());
		model.setMsgType(addModel.getMsgType());
		model.setMsgFormat(addModel.getMsgFormat());
		model.setDescription(addModel.getDescription());
		//model.setCreatedBy(addModel.getCreatedBy());
		model.setBusinessRule(addModel.getBusinessRule());
		return model;
	}

	/**
	 * convert AddIsgVanillaMfConfigModel to MessageFormatConfigModel
	 * 
	 * @param addModel - model object
	 * @return - MessageFormatConfigModel
	 */
	public static MessageFormatConfigModel getMessageFormatModel(AddIsgVanillaMfConfigModel addModel) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setMsgType(addModel.getMsgType());
		model.setMsgFormat(addModel.getMsgFormat());
		model.setDescription(addModel.getDescription());
		//model.setCreatedBy(addModel.getCreatedBy());
		model.setBusinessRule(addModel.getBusinessRule());
		return model;
	}

	/**
	 * convert ModifyMessageFormatConfigModel to MessageFormatConfigModel
	 * 
	 * @param modifyModel - message model
	 * @return - MessageFormatConfigModel
	 */
	public static MessageFormatConfigModel getMessageFormatModel(ModifyMessageFormatConfigModel modifyModel) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(modifyModel.getId());
		model.setMsgType(modifyModel.getMsgType());
		model.setMsgFormat(modifyModel.getMsgFormat());
		model.setDescription(modifyModel.getDescription());
		//model.setUpdatedBy(modifyModel.getUpdatedBy());
		model.setBusinessRule(modifyModel.getBusinessRule());
		return model;
	}

}
