package com.isg.mw.mf.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.ConfigStateResponse;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.mf.ValidationSummary;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.service.ConfigMgmtService;
import com.isg.mw.mf.mgmt.utils.ConfigSummaryUtil;
import com.isg.mw.mf.mgmt.validations.ConfigOfflineValidator;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
import com.isg.mw.tc.dao.service.TargetConfigEditCopyService;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;

/**
 * class implements {@link ConfigMgmtService}
 * 
 * @author sanchita3984
 *
 */
@Service("configValidatotMgmtService")
public class ConfigMgmtServiceImpl implements ConfigMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private TargetConfigMasterService targetConfigMasterService;

	@Autowired
	private SourceConfigMasterService sourceConfigMasterService;

	@Autowired
	private SourceConfigEditCopyService sourceEditCopyService;

	@Autowired
	private TargetConfigEditCopyService targetEditCopyService;

	@Autowired
	private ConfigOfflineValidator configOfflineValidator;

	@Override
	public ResponseEntity<?> validate(String entityId, String ownerName, OwnerType type) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.CC_VALIDATOR_API_LOG_INFO, entityId, ownerName, type!=null?type.name():null));
		ResponseEntity<?> response = null;
		ConfigStateResponse stateResponse = null;
		TargetConfigMasterEntity targetEntity = null;
		SourceConfigMasterEntity sourceEntity = null;
		ValidationSummary validationSummary = new ValidationSummary();
		try {
			configOfflineValidator.validateValidation(entityId, ownerName, type);
			if (type == OwnerType.TARGET) {
				targetEntity = targetConfigMasterService.get(ownerName, entityId);
				if (targetEntity != null) {
					if (targetEntity.getLockedState() == LockedState.Locked) {
						stateResponse = ConfigStateResponse.Locked;
						validationSummary = getValidationSummary(entityId, ownerName, type, stateResponse);
						response = new ResponseEntity<>(validationSummary, HttpStatus.OK);
					} else {
						stateResponse = ConfigStateResponse.Success;
						validationSummary = getValidationSummary(entityId, ownerName, type, stateResponse);
						response = new ResponseEntity<>(validationSummary, HttpStatus.OK);
					}
				} else {
					stateResponse = ConfigStateResponse.NotExists;
					validationSummary = getValidationSummary(entityId, ownerName, type, stateResponse);
					response = new ResponseEntity<>(validationSummary, HttpStatus.OK);
				}
			} else if (type == OwnerType.SOURCE) {
				sourceEntity = sourceConfigMasterService.get(ownerName, entityId);
				if (sourceEntity != null) {
					if (sourceEntity.getLockedState() == LockedState.Locked) {
						stateResponse = ConfigStateResponse.Locked;
						validationSummary = getValidationSummary(entityId, ownerName, type, stateResponse);
						response = new ResponseEntity<>(validationSummary, HttpStatus.OK);
					} else {
						stateResponse = ConfigStateResponse.Success;
						validationSummary = getValidationSummary(entityId, ownerName, type, stateResponse);
						response = new ResponseEntity<>(validationSummary, HttpStatus.OK);
					}
				} else {
					stateResponse = ConfigStateResponse.NotExists;
					validationSummary = getValidationSummary(entityId, ownerName, type, stateResponse);
					response = new ResponseEntity<>(validationSummary, HttpStatus.OK);
				}
			} else {
				throw new ValidationException(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG, type);
			}

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	/**
	 * Get validation summary base on entityId,ownerName,type and stateResponse
	 * 
	 * @param entityId      - entityId of the configuration object
	 * @param ownerName     - name of the configuration
	 * @param type          - SOURCE or TARGET or ISG_VANILLA configuration
	 * @param stateResponse - stateResponse of the ConfigStateResponse object
	 * @return
	 */
	private ValidationSummary getValidationSummary(String entityId, String ownerName, OwnerType type,
			ConfigStateResponse stateResponse) {
		ValidationSummary validationSummary = new ValidationSummary();
		validationSummary.setEntityId(entityId);
		validationSummary.setOwnerName(ownerName);
		validationSummary.setOwnerType(type);
		validationSummary.setResponse(stateResponse);
		return validationSummary;
	}

	@Override
	public ResponseEntity<?> getAll(String entityId, OwnerType type) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.CC_API_LOG_INFO, entityId, type!=null?type.name():null));
		ResponseEntity<?> response = null;

		try {
			configOfflineValidator.getAllValidation(entityId, type);
			Map<String, List<ConfigSummary>> map = new HashMap<String, List<ConfigSummary>>(2);

			if (type == OwnerType.ISG_VANILLA) {
				throw new ValidationException(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG, type);
			}

			if (type == OwnerType.TARGET || type == null) {
				List<ConfigSummary> list = ConfigSummaryUtil.updateConfigSummaryList(
						targetConfigMasterService.getAll(entityId), targetEditCopyService.getAll(entityId));
				map.put(OwnerType.TARGET.name(), list);
			}

			if (type == OwnerType.SOURCE || type == null) {
				List<ConfigSummary> list = ConfigSummaryUtil.updateConfigSummaryList(
						sourceConfigMasterService.getAll(entityId), sourceEditCopyService.getAll(entityId));
				map.put(OwnerType.SOURCE.name(), list);
			}
			response = new ResponseEntity<>(map, HttpStatus.OK);

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;

	}

}
