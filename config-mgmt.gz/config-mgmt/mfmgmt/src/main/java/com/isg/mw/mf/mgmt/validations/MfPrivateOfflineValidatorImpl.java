package com.isg.mw.mf.mgmt.validations;

import org.springframework.stereotype.Service;

import com.isg.mw.core.model.validation.UserDataValidations;
import com.isg.mw.mf.mgmt.constants.MfOfflineValidator;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;

/**
 * Class Implements {@link MfPrivateOfflineValidator}
 * 
 * @author prasad_t026
 *
 */
@Service("mfPrivateOfflineValidator")
public class MfPrivateOfflineValidatorImpl implements MfPrivateOfflineValidator {

	@Override
	public void addValidation(AddMessageFormatConfigModel addModel) {

		UserDataValidations.entityIdValidations(addModel.getEntityId(), true);

		UserDataValidations.nameValidations(addModel.getOwnerName(), true);

		UserDataValidations.ownerTypeValidations(addModel.getOwnerType(), true);

		MfOfflineValidator.messageTypeValidation(addModel.getMsgType());

		MfOfflineValidator.messageFormatValidation(addModel.getMsgFormat());

		MfOfflineValidator.messageDescriptionValidation(addModel.getDescription());

		//UserDataValidations.userNameValidations(addModel.getCreatedBy(), true);

		if (addModel.getBusinessRule() != null) {

			MfOfflineValidator.brClssNameValidation(addModel.getBusinessRule().getClassName());

			MfOfflineValidator.brMethodNameValidation(addModel.getBusinessRule().getMethodName());

		}

	}

	@Override
	public void modifyValidation(ModifyMessageFormatConfigModel updateModel) {

		UserDataValidations.idValidations(updateModel.getId(), true);

		MfOfflineValidator.messageTypeValidation(updateModel.getMsgType());

		MfOfflineValidator.messageFormatValidation(updateModel.getMsgFormat());

		MfOfflineValidator.messageDescriptionValidation(updateModel.getDescription());

		//UserDataValidations.userNameValidations(updateModel.getUpdatedBy(), true);

		if (updateModel.getBusinessRule() != null) {

			MfOfflineValidator.brClssNameValidation(updateModel.getBusinessRule().getClassName());

			MfOfflineValidator.brMethodNameValidation(updateModel.getBusinessRule().getMethodName());

		}

	}

}
