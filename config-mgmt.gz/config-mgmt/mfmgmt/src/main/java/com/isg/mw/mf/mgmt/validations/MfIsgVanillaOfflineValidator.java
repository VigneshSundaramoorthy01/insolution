package com.isg.mw.mf.mgmt.validations;

import com.isg.mw.mf.mgmt.model.AddIsgVanillaMfConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;

/**
 * Interface for operations on a Validations for a Message format ISG Vanilla
 * Offline Validation
 * 
 * @author prasad_t026
 *
 */
public interface MfIsgVanillaOfflineValidator {
	/**
	 * Offline Validation for add API
	 * 
	 * @param addModel - model object
	 */
	void addValidation(AddIsgVanillaMfConfigModel addModel);

	/**
	 * Offline Validation for modify API
	 * 
	 * @param updateModel - model object
	 */
	void modifyValidation(ModifyMessageFormatConfigModel updateModel);

}
