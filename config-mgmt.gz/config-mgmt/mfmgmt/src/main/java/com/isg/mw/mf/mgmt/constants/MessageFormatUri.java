package com.isg.mw.mf.mgmt.constants;

/**
 * Definitions of Message Format URIs
 * 
 * @author prasad_t026
 *
 */
public interface MessageFormatUri {
	
	/**
	 * Message Format URIs for Controller
	 */
	String PARENT_PR = "/mfs/config";
	
	/**
	 * Private Message Format URIs for add API
	 */
	String ADD_PR = "/add";
	
	/**
	 * Private Message Format URIs for modify API
	 */
	String MODIFY_PR = "/update";
	
	/**
	 * Private Message Format URIs for delete API
	 */
	String DELETE_PR = "/delete";
	
	/**
	 * Private Message Format URIs for getList API
	 */
	String GET_LIST_PR = "/getlist";
	
	/**
	 * ISG vanilla Message Format URIs for Controller
	 */
	String PARENT_ISG = "/mfs/vanilla";
	
	/**
	 * ISG vanilla Message Format URIs for add API
	 */
	String ADD_ISG = "/add";
	
	/**
	 * ISG vanilla Message Format URIs for modify API
	 */
	String MODIFY_ISG = "/update";
	
	/**
	 * ISG vanilla Message Format URIs for delete API
	 */
	String DELETE_ISG = "/delete";
	
	/**
	 * ISG vanilla Message Format URIs for getList API
	 */
	String GET_LIST_ISG = "/getlist";
	
	/**
	 * Configuration URIs for controller
	 */
	String PARENT_VD = "/config";
	
	/**
	 * Configuration URIs for validate API
	 */
	String VALIDATE_VD = "/validate";
	
	/**
	 * Configuration URIs for getAll API
	 */
	String GET_ALL = "/getall";

}
