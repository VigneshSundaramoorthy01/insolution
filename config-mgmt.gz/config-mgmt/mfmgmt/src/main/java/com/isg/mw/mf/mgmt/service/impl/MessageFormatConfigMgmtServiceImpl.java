package com.isg.mw.mf.mgmt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.mf.dao.service.MfPrivateOnlineValidator;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.MessageFormatConfigMgmtService;
import com.isg.mw.mf.mgmt.utils.MfMgmtUtility;
import com.isg.mw.mf.mgmt.validations.MfPrivateOfflineValidator;
import com.isg.mw.sc.dao.service.SourceMfEditCopyService;
import com.isg.mw.sc.dao.service.SourceMfMasterService;
import com.isg.mw.sc.dao.service.SourceMfOnlineValidator;
import com.isg.mw.tc.dao.service.TargetMfEditCopyService;
import com.isg.mw.tc.dao.service.TargetMfMasterService;
import com.isg.mw.tc.dao.service.TargetMfOnlineValidator;

/**
 * class implements {@link MessageFormatConfigMgmtService}
 * 
 * @author prasad_t026
 *
 */
@Service("messageFormatConfigMgmtService")
@Transactional
public class MessageFormatConfigMgmtServiceImpl implements MessageFormatConfigMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Autowired
	private TargetMfOnlineValidator targetMfOnlineValidator;

	@Autowired
	private SourceMfOnlineValidator sourceMfOnlineValidator;

	@Autowired
	private MfPrivateOfflineValidator mfPrivateOfflineValidator;

	@Autowired
	private MfPrivateOnlineValidator mfPrivateOnlineValidator;

	@Autowired
	private TargetMfEditCopyService targetMfEditCopyService;

	@Autowired
	private SourceMfEditCopyService sourceMfEditCopyService;

	@Autowired
	private TargetMfMasterService targetMfMasterService;

	@Autowired
	private SourceMfMasterService sourceMfMasterService;

	@Override
	public ResponseEntity<?> add(AddMessageFormatConfigModel addModel) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFP_ADD_API_LOG_INFO));
		ResponseEntity<?> response = null;
		try {

			mfPrivateOfflineValidator.addValidation(addModel);
			MessageFormatConfigModel model = MfMgmtUtility.getMessageFormatModel(addModel);
			Long ownerId = null;
			if (model.getOwnerType() == OwnerType.TARGET) {
				ownerId = targetMfOnlineValidator.addValidation(model, addModel.getEntityId(), addModel.getOwnerName());
			} else if (model.getOwnerType() == OwnerType.SOURCE) {
				ownerId = sourceMfOnlineValidator.addValidation(model, addModel.getEntityId(), addModel.getOwnerName());
			} else {
				throw new ValidationException(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG, model.getOwnerType());
			}
			model.setOwnerId(ownerId);
			MessageFormatConfigModel addMfm = messageFormatConfigEditCopyService.add(model);
			response = new ResponseEntity<>(addMfm, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> modify(ModifyMessageFormatConfigModel updateModel) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFP_MODIFY_API_LOG_INFO, updateModel.getId()));
		ResponseEntity<?> response = null;
		try {
			mfPrivateOfflineValidator.modifyValidation(updateModel);
			MessageFormatConfigModel model = MfMgmtUtility.getMessageFormatModel(updateModel);
			OwnerType ownerType = mfPrivateOnlineValidator.getOwnerType(updateModel.getId());
			if (ownerType == null) {
				throw new ValidationException(MfMgmtMsgKeys.INVALID_MF_ID_ERROR, updateModel.getId());
			} else if (ownerType == OwnerType.TARGET) {
				targetMfOnlineValidator.modifyValidation(model);
			} else if (ownerType == OwnerType.SOURCE) {
				sourceMfOnlineValidator.modifyValidation(model);
			} else {
				throw new ValidationException(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG, model.getOwnerType());
			}
			MessageFormatConfigModel addMfm = messageFormatConfigEditCopyService.update(model);
			response = new ResponseEntity<>(addMfm, HttpStatus.OK);

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> delete(Long id, OwnerType type) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFP_DELETE_API_LOG_INFO, id, type.name()));
		ResponseEntity<?> response = null;
		try {
			if (type == OwnerType.TARGET) {
				targetMfOnlineValidator.deleteValidation(id);
			} else if (type == OwnerType.SOURCE) {
				sourceMfOnlineValidator.deleteValidation(id);
			} else {
				throw new ValidationException(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG, type);
			}
			messageFormatConfigEditCopyService.deleteById(id);
			response = new ResponseEntity<>("Success", HttpStatus.OK);

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getList(String entityId, String name, OwnerType type) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFP_GET_LIST_API_LOG_INFO, entityId, name, type.name()));
		ResponseEntity<?> response = null;
		try {
			Map<String, List<MessageFormatConfigModel>> map = new HashMap<String, List<MessageFormatConfigModel>>(2);

			List<MessageFormatConfigModel> master = null;

			if (type == OwnerType.TARGET) {
				master = targetMfMasterService.getList(entityId, name);
			} else if (type == OwnerType.SOURCE) {
				master = sourceMfMasterService.getList(entityId, name);
			} else {
				throw new ValidationException(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG, type);
			}

			if (master != null && !master.isEmpty()) {
				map.put("master", master);
			}

			List<MessageFormatConfigModel> editCopy = null;
			if (type == OwnerType.TARGET) {
				editCopy = targetMfEditCopyService.getList(entityId, name);
			} else if (type == OwnerType.SOURCE) {
				editCopy = sourceMfEditCopyService.getList(entityId, name);
			}

			if (editCopy != null && !editCopy.isEmpty()) {
				map.put("editCopy", editCopy);
			}
			if (!map.isEmpty()) {
				response = new ResponseEntity<>(map, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.MFP_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}
