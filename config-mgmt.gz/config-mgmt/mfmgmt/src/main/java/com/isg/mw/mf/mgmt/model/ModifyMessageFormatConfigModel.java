package com.isg.mw.mf.mgmt.model;

import com.isg.mw.core.model.mf.BusinessRule;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Model use in modify API of Message format Controller which contain Message
 * format configuration fields
 * 
 * @author prasad_t026
 *
 */
@ApiModel(description = "Modify message format config model")
@Getter
@Setter
public class ModifyMessageFormatConfigModel {
	/**
	 * DB ID should be auto increment
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.update.id.value}")
	private Long id;
	/**
	 * message transaction type
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.update.msgType.value}")
	private String msgType;
	/**
	 * message format
	 */
	@ApiModelProperty(required = true, value = "${swgr.mfc.model.update.msgFormat.value}")
	private String msgFormat;
	/**
	 * description of the message type
	 */
	@ApiModelProperty(value = "${swgr.mfc.model.update.description.value}")
	private String description;
	/**
	 * updated user name
	 */
	//@ApiModelProperty(required = true, value = "${swgr.mfc.model.update.updatedBy.value}")
	//private String updatedBy;
	/**
	 * Business Rule
	 */
	@ApiModelProperty(value = "${swgr.mfc.model.update.businessRule.value}")
	private BusinessRule businessRule;

}
