package com.isg.mw.mf.mgmt.service;

import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.OwnerType;

/**
 * Interface for operations on a services for a Configuration management service
 * 
 * @author sanchita3984
 *
 */
public interface ConfigMgmtService {
	/**
	 * Validate specific configuration for HSM
	 * 
	 * @param entityId - entity id of the specific configuration
	 * @param name     -name of the of specific configuration
	 * @param type     -SOURCE or TARGET or ISG_VANILLA configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> validate(String entityId, String name, OwnerType type);

	/**
	 * Get all specific configuration from DB base on entity id and owner type
	 * 
	 * @param entityId - Entity id of the specific configuration
	 * @param type     -SOURCE or TARGET or ISG_VANILLA configuration
	 * @return Configuration Object with 'OK' status if exists 'NOT_FOUND' status if
	 *         not exists 'INTERNAL_SERVER_ERROR' for any exception
	 */
	ResponseEntity<?> getAll(String entityId, OwnerType type);

}
