package com.isg.mw.mf.mgmt.utils;

import java.util.ArrayList;
import java.util.List;

import com.isg.mw.core.model.mf.ConfigSummary;

/**
 * Utility for Configuration Summary
 * 
 * @author rahul3983
 *
 */
public class ConfigSummaryUtil {
	/**
	 * Constructor should not access outside
	 */
	private ConfigSummaryUtil() {
	}

	/**
	 * convert into single configuration summary list of a specific configuration
	 * base on master and edit copy configuration summary list
	 * 
	 * @param masterList   - master configuration summary list
	 * @param editCopyList - edit copy configuration summary list
	 * @return - configuration summary list
	 */
	public static List<ConfigSummary> updateConfigSummaryList(List<ConfigSummary> masterList,
			List<ConfigSummary> editCopyList) {

		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		if (masterList != null) {
			for (ConfigSummary mc : masterList) {
				ConfigSummary ec = getByName(editCopyList, mc.getConfigName());
				list.add(merge(mc, ec));
			}
		}
		if (editCopyList != null) {
			for (ConfigSummary ec : editCopyList) {
				ConfigSummary mc = getByName(masterList, ec.getConfigName());
				if (mc == null) {
					list.add(duplicate(ec));
				}
			}
		}
		return list;

	}

	/**
	 * Get ConfigSummary based on list of ConfigSummay of specific configuration and
	 * name of specific ConfigSummary
	 * 
	 * @param list- list of ConfigSummay of specific configuration
	 * @param name  -name of specific ConfigSummary
	 * @return - ConfigSummary object
	 */
	public static ConfigSummary getByName(List<ConfigSummary> list, String name) {

		if (list != null) {
			for (ConfigSummary cs : list) {
				if (cs.getConfigName().equals(name)) {
					return cs;
				}
			}
		}
		return null;
	}

	/**
	 * Merge ConfigSummary based on master and editCopy ConfigSummary object
	 * 
	 * @param master   - ConfigSummary master object
	 * @param editCopy - ConfigSummary editCopy object
	 * @return -ConfigSummary
	 */
	public static ConfigSummary merge(ConfigSummary master, ConfigSummary editCopy) {

		ConfigSummary cs = new ConfigSummary();
		cs.setEntityId(master.getEntityId());
		cs.setConfigName(master.getConfigName());
		cs.setOwnerType(master.getOwnerType());
		cs.setMasterExists(true);
		cs.setConfigStatus(master.getConfigStatus());
		cs.setLockedState(master.getLockedState());
		if (editCopy != null) {
			cs.setEditCopyExists(true);
			cs.setEditStatus(editCopy.getEditStatus());
		}
		return cs;

	}

	/**
	 * Duplicate ConfigSummary based on editCopy ConfigSummary
	 * 
	 * @param editCopy - ConfigSummary editCopy object
	 * @return - ConfigSummary
	 */
	public static ConfigSummary duplicate(ConfigSummary editCopy) {

		ConfigSummary cs = new ConfigSummary();
		cs.setEntityId(editCopy.getEntityId());
		cs.setConfigName(editCopy.getConfigName());
		cs.setOwnerType(editCopy.getOwnerType());
		cs.setEditCopyExists(true);
		cs.setEditStatus(editCopy.getEditStatus());
		return cs;

	}

}
