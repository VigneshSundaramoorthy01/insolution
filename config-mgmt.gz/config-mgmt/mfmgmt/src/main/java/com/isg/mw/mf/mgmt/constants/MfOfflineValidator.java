package com.isg.mw.mf.mgmt.constants;

import com.isg.mw.core.model.validation.UserDataValidations;

/**
 * Message format offline Validation
 * 
 * @author prasad_t026
 *
 */
public class MfOfflineValidator {

	public static final String MSG_TYPE_EXPR = "^[0-9]*$";
	public static final int MSG_TYPE_LENGTH = 4;
	public static final boolean MSG_TYPE_REQ = true;
	public static final String MSG_TYPE_NAME = "mesType";

	public static final String MSG_FORMAT_EXPR = null;
	public static final int MSG_FORMAT_LENGTH = 20000;
	public static final String MSG_FORMAT_NAME = "mesFormat";

	public static final String DESCRIPTION_EXPR = null;
	public static final int DESCRIPTION_LENGTH = 100;
	public static final String DESCRIPTION_NAME = "description";

	public static final String BR_CLASSNAME_EXPR = "[a-zA-Z0-9_.]*";
	public static final int BR_CLASSNAME_LENGTH = 150;
	public static final String BR_CLASSNAME_NAME = "businessRule.className";

	public static final String BR_METHODNAME_EXPR = "[a-zA-Z0-9_.]*";
	public static final int BR_METHODNAME_LENGTH = 150;
	public static final String BR_METHODNAME_NAME = "businessRule.methodName";

	/**
	 * Offline Validation for message type base on msgType
	 * 
	 * @param msgType - message type of message format model object
	 */
	public static void messageTypeValidation(String msgType) {

		UserDataValidations.stringDataValidation(msgType, MSG_TYPE_EXPR, MSG_TYPE_NAME, true, MSG_TYPE_LENGTH);

	}

	/**
	 * Offline Validation for message format base on msgFormat
	 * 
	 * @param msgFormat - message format of message format model object
	 */
	public static void messageFormatValidation(String msgFormat) {

		UserDataValidations.stringDataValidation(msgFormat, MSG_FORMAT_EXPR, MSG_FORMAT_NAME, true, MSG_FORMAT_LENGTH);

	}

	/**
	 * Offline Validation for description base on description
	 * 
	 * @param description - description of message format model object
	 */
	public static void messageDescriptionValidation(String description) {

		UserDataValidations.stringDataValidation(description, DESCRIPTION_EXPR, DESCRIPTION_NAME, false,
				DESCRIPTION_LENGTH);

	}

	/**
	 * Offline Validation for business rule class name base on className
	 * 
	 * @param className - business rule class name of message format model object
	 */
	public static void brClssNameValidation(String className) {

		UserDataValidations.stringDataValidation(className, BR_CLASSNAME_EXPR, BR_CLASSNAME_NAME, true,
				BR_CLASSNAME_LENGTH);

	}

	/**
	 * Offline Validation for business rule method name base on methodName
	 * 
	 * @param methodName - business rule method name of message format model object
	 */
	public static void brMethodNameValidation(String methodName) {

		UserDataValidations.stringDataValidation(methodName, BR_METHODNAME_EXPR, BR_METHODNAME_NAME, false,
				BR_METHODNAME_LENGTH);

	}

}
