package com.isg.mw.mf.mgmt.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.mf.dao.service.MfIsgVanillaOnlineValidator;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.model.AddIsgVanillaMfConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.MessageFormatIsgVanillaMgmtService;
import com.isg.mw.mf.mgmt.utils.MfMgmtUtility;
import com.isg.mw.mf.mgmt.validations.MfIsgVanillaOfflineValidator;

/**
 * class implements {@link MessageFormatIsgVanillaMgmtService}
 * 
 * @author prasad_t026
 *
 */
@Service("messageFormatIsgVanillaMgmtService")
@Transactional
public class MessageFormatIsgVanillaMgmtServiceImpl implements MessageFormatIsgVanillaMgmtService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private MfIsgVanillaOfflineValidator mfIsgVanillaOfflineValidator;

	@Autowired
	private MfIsgVanillaOnlineValidator mfIsgVanillaOnlineValidator;

	@Autowired
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@Override
	public ResponseEntity<?> add(AddIsgVanillaMfConfigModel addModel) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFI_ADD_API_LOG_INFO));
		ResponseEntity<?> response = null;
		try {

			mfIsgVanillaOfflineValidator.addValidation(addModel);
			MessageFormatConfigModel model = MfMgmtUtility.getMessageFormatModel(addModel);
			model.setOwnerType(OwnerType.ISG_VANILLA);
			mfIsgVanillaOnlineValidator.addValidation(model);
			MessageFormatConfigModel addMfm = messageFormatConfigMasterService.add(model);

			response = new ResponseEntity<>(addMfm, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> modify(ModifyMessageFormatConfigModel updateModel) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFI_MODIFY_API_LOG_INFO, updateModel.getId()));
		ResponseEntity<?> response = null;
		try {

			mfIsgVanillaOfflineValidator.modifyValidation(updateModel);
			MessageFormatConfigModel model = MfMgmtUtility.getMessageFormatModel(updateModel);
			OwnerType ownerType = mfIsgVanillaOnlineValidator.getOwnerType(updateModel.getId());
			model.setOwnerType(ownerType);
			if (ownerType == null) {
				throw new ValidationException(MfMgmtMsgKeys.INVALID_MF_ID_ERROR, updateModel.getId());
			}

			mfIsgVanillaOnlineValidator.modifyValidation(model);

			MessageFormatConfigModel updateMfm = messageFormatConfigMasterService.update(model);

			response = new ResponseEntity<>(updateMfm, HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> delete(Long id) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFI_MODIFY_API_LOG_INFO, id));
		ResponseEntity<?> response = null;
		try {

			mfIsgVanillaOnlineValidator.deleteValidation(id);

			messageFormatConfigMasterService.deleteById(id);

			response = new ResponseEntity<>("Success", HttpStatus.OK);
		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public ResponseEntity<?> getList(String msgType) {
		LOG.info(PropertyUtils.getMessage(MfMgmtMsgKeys.MFI_GET_LIST_API_LOG_INFO, msgType));
		ResponseEntity<?> response = null;
		try {
			List<MessageFormatConfigModel> master = messageFormatConfigMasterService
					.getByOwnerAndOwnerTypeWithMsgType(null, OwnerType.ISG_VANILLA, msgType);

			if (master != null && !master.isEmpty()) {
				response = new ResponseEntity<>(master, HttpStatus.OK);
			} else {
				String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.MFI_LIST_EMPTY);
				response = new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
			}

		} catch (ValidationException e) {
			String errMsg = PropertyUtils.getMessage(e.getMessage(), e.getArgs());
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.error(errMsg, e);
			response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}
