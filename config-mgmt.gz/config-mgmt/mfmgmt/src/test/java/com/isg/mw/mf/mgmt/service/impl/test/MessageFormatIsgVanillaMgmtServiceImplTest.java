package com.isg.mw.mf.mgmt.service.impl.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatConfigMasterService;
import com.isg.mw.mf.dao.service.MfIsgVanillaOnlineValidator;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.model.AddIsgVanillaMfConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.impl.MessageFormatIsgVanillaMgmtServiceImpl;
import com.isg.mw.mf.mgmt.validations.MfIsgVanillaOfflineValidator;

public class MessageFormatIsgVanillaMgmtServiceImplTest {

	@Mock
	private MfIsgVanillaOfflineValidator mfIsgVanillaOfflineValidator;

	@Mock
	private MfIsgVanillaOnlineValidator mfIsgVanillaOnlineValidator;

	@Mock
	private MessageFormatConfigMasterService messageFormatConfigMasterService;

	@InjectMocks
	public MessageFormatIsgVanillaMgmtServiceImpl messageFormatIsgVanillaMgmtService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void addPT01() {
		Mockito.when(messageFormatConfigMasterService.add(Mockito.any()))
				.thenReturn(getMFCModel(123L, OwnerType.ISG_VANILLA));
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.add(getAddIsgModel());
		assertNotNull(add);
	}

	@Test
	public void addPT02() {
		String errorMSg = "Unknown message";
		Mockito.when(messageFormatConfigMasterService.add(Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.add(getAddIsgModel());
		assertEquals(add, response);
	}

	@Test
	public void addPT03() {
		String errorMSg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(messageFormatConfigMasterService.add(Mockito.any())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.add(getAddIsgModel());
		assertEquals(add, response);
	}

	@Test
	public void modifyPT01() {
		Mockito.when(mfIsgVanillaOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.ISG_VANILLA);
		Mockito.when(messageFormatConfigMasterService.update(Mockito.any()))
				.thenReturn(getMFCModel(123L, OwnerType.ISG_VANILLA));
		ResponseEntity<?> modify = messageFormatIsgVanillaMgmtService.modify(getModifyIsgModel());
		assertNotNull(modify);
	}

	@Test
	public void modifyNT01() {
		String errorMSg = "Unknown message";
		Mockito.when(mfIsgVanillaOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.ISG_VANILLA);
		Mockito.when(messageFormatConfigMasterService.update(Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> modify = messageFormatIsgVanillaMgmtService.modify(getModifyIsgModel());
		assertEquals(modify, response);
	}

	@Test
	public void modifyNT02() {
		String errorMSg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(mfIsgVanillaOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.ISG_VANILLA);
		Mockito.when(messageFormatConfigMasterService.update(Mockito.any())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> modify = messageFormatIsgVanillaMgmtService.modify(getModifyIsgModel());
		assertEquals(modify, response);
	}

	@Test
	public void modifyNT03() {
		String errorMSg = "Unknown message";
		Mockito.when(mfIsgVanillaOnlineValidator.getOwnerType(Mockito.any())).thenReturn(null);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> modify = messageFormatIsgVanillaMgmtService.modify(getModifyIsgModel());
		assertEquals(modify, response);
	}

	@Test
	public void deletePT01() {
		ResponseEntity<?> delete = messageFormatIsgVanillaMgmtService.delete(123L);
		assertNotNull(delete);
	}

	@Test
	public void deletePT02() {
		String errorMSg = "Unknown message";
		Mockito.doThrow(ValidationException.class).when(messageFormatConfigMasterService).deleteById(Mockito.any());
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> delete = messageFormatIsgVanillaMgmtService.delete(123L);
		assertEquals(delete, response);
	}

	@Test
	public void deletePT03() {
		String errorMSg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.doThrow(RuntimeException.class).when(messageFormatConfigMasterService).deleteById(Mockito.any());

		Mockito.when(messageFormatConfigMasterService.add(Mockito.any())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> delete = messageFormatIsgVanillaMgmtService.delete(123L);
		assertEquals(delete, response);
	}

	@Test
	public void getListPT01() {
		Mockito.when(messageFormatConfigMasterService.getByOwnerAndOwnerTypeWithMsgType(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(getMFCModelList(123L, OwnerType.ISG_VANILLA));
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.getList("0200");
		assertNotNull(add);
	}

	@Test
	public void getListPT02() {
		String errorMSg = "Unknown message";
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.NO_CONTENT);
		Mockito.when(messageFormatConfigMasterService.getByOwnerAndOwnerTypeWithMsgType(Mockito.any(), Mockito.any(),
				Mockito.any())).thenReturn(new ArrayList<MessageFormatConfigModel>());
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.getList("0200");
		assertEquals(add, response);
	}
	@Test
	public void getListPT03() {
		String errorMSg = "Unknown message";
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.EXPECTATION_FAILED);
		Mockito.when(messageFormatConfigMasterService.getByOwnerAndOwnerTypeWithMsgType(Mockito.any(), Mockito.any(),
				Mockito.any())).thenThrow(ValidationException.class);
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.getList("0200");
		assertEquals(add, response);
	}
	@Test
	public void getListPT04() {
		String errorMSg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(messageFormatConfigMasterService.getByOwnerAndOwnerTypeWithMsgType(Mockito.any(), Mockito.any(),
				Mockito.any())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMSg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> add = messageFormatIsgVanillaMgmtService.getList("0200");
		assertEquals(add, response);
	}

	private AddIsgVanillaMfConfigModel getAddIsgModel() {
		AddIsgVanillaMfConfigModel model = new AddIsgVanillaMfConfigModel();
		//model.setCreatedBy("john");
		model.setMsgType("0200");
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		return model;
	}

	private ModifyMessageFormatConfigModel getModifyIsgModel() {
		ModifyMessageFormatConfigModel model = new ModifyMessageFormatConfigModel();
		//model.setUpdatedBy("john");
		model.setMsgType("0200");
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		return model;
	}

	private MessageFormatConfigModel getMFCModel(Long ownerId, OwnerType type) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(124L);
		model.setOwnerId(ownerId);
		model.setOwnerType(type);
		model.setCreatedBy("john");
		model.setMsgType("0200");
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");

		return model;
	}

	private List<MessageFormatConfigModel> getMFCModelList(Long ownerId, OwnerType type) {
		List<MessageFormatConfigModel> list = new ArrayList<MessageFormatConfigModel>();
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setId(124L);
		model.setOwnerId(ownerId);
		model.setOwnerType(type);
		model.setCreatedBy("john");
		model.setMsgType("0200");
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		list.add(model);
		return list;
	}

}
