package com.isg.mw.mf.mgmt.utils.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.mf.mgmt.utils.ConfigSummaryUtil;

public class ConfigSummaryUtilTest {

	@Test
	public void updateConfigSummaryListPT01() {
      List<ConfigSummary> coList = getConfigSummuryMaster();
      ConfigSummary summary = coList.get(0);
		List<ConfigSummary> list = ConfigSummaryUtil.updateConfigSummaryList(getConfigSummuryMaster(), null);
	    ConfigSummary configSummary = list.get(0);
	   assertEquals(configSummary.getEntityId(),summary.getEntityId());
	   assertEquals( configSummary.getOwnerType(),summary.getOwnerType());
	   assertEquals(configSummary.getConfigName(),summary.getConfigName());
	   assertEquals(configSummary.getConfigStatus(),summary.getConfigStatus());
	   assertEquals(configSummary.isMasterExists(),summary.isMasterExists());
	   assertEquals(configSummary.getLockedState(),summary.getLockedState());
		 
	}
	@Test
	public void updateConfigSummaryListPT02() {
		ConfigSummary summary = getConfigSummuryEditCopy().get(0);
		List<ConfigSummary> list = ConfigSummaryUtil.updateConfigSummaryList(null, getConfigSummuryEditCopy());
	    ConfigSummary configSummary = list.get(0);
	    System.out.println( configSummary.getEntityId());
		   assertEquals(configSummary.getEntityId(),summary.getEntityId());
		   assertEquals( configSummary.getOwnerType(),summary.getOwnerType());
		   assertEquals(configSummary.getConfigName(),summary.getConfigName());
		   assertEquals(configSummary.getConfigStatus(),summary.getConfigStatus());
		   assertEquals(configSummary.isMasterExists(),summary.isMasterExists());
		   assertEquals(configSummary.getLockedState(),summary.getLockedState());
				   
	}
	@Test
	public void updateConfigSummaryListPT03() {
		List<ConfigSummary> master = getConfigSummuryMaster();
		List<ConfigSummary> editCopy = getConfigSummuryEditCopy();
		List<ConfigSummary> list = ConfigSummaryUtil.updateConfigSummaryList(master, editCopy);
	    ConfigSummary configSummary = list.get(0);
	    System.out.println( configSummary.getEntityId());
		   assertEquals(configSummary.getEntityId(),master.get(0).getEntityId());
		   assertEquals( configSummary.getOwnerType(),master.get(0).getOwnerType());
		   assertEquals(configSummary.getConfigName(),master.get(0).getConfigName());
		   assertEquals(configSummary.getConfigStatus(),master.get(0).getConfigStatus());
		   assertEquals(configSummary.isMasterExists(),master.get(0).isMasterExists());
		   assertEquals(configSummary.getLockedState(),master.get(0).getLockedState());
		   assertEquals(configSummary.getEditStatus(),editCopy.get(0).getEditStatus());
	
	}

	private static List<ConfigSummary> getConfigSummuryMaster() {
		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		ConfigSummary model = new ConfigSummary();
		model.setEntityId("123");
		model.setOwnerType(OwnerType.SOURCE);
		model.setConfigName("SCM");
		model.setConfigStatus(ConfigStatus.Active);
		model.setMasterExists(true);
		model.setLockedState(LockedState.Unlocked);
		list.add(model);
		return list;
	}

	private static List<ConfigSummary> getConfigSummuryEditCopy() {
		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		ConfigSummary model = new ConfigSummary();
		model.setEntityId("123");
		model.setOwnerType(OwnerType.SOURCE);
		model.setConfigName("SCM");
		model.setEditStatus(EditStatus.Inprogress);
		model.setMasterExists(false);
		list.add(model);
		return list;
	}


}
