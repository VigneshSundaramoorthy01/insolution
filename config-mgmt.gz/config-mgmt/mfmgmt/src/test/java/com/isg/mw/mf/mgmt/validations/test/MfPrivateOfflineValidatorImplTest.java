package com.isg.mw.mf.mgmt.validations.test;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.validations.MfPrivateOfflineValidatorImpl;

public class MfPrivateOfflineValidatorImplTest {

	@InjectMocks
	private MfPrivateOfflineValidatorImpl mfPrivateOfflineValidator;

	@Before
    public void init() {
    	MockitoAnnotations.initMocks(this);
    }
	@Test
	public void addValidationPT01() {
		mfPrivateOfflineValidator.addValidation(getAddMessageFormatModel());
	}
	
	@Test
	public void addValidationPT02() {
		mfPrivateOfflineValidator.modifyValidation(getModifyMessageFormatModel());
	}	
	
	private static BusinessRule getBusinessRule() {
		BusinessRule businessRule = new BusinessRule();
		businessRule.setClassName("Utility");
		businessRule.setMethodName("getUtility");
		return businessRule;
	}

	public static ModifyMessageFormatConfigModel getModifyMessageFormatModel() {
		ModifyMessageFormatConfigModel model = new ModifyMessageFormatConfigModel();
		model.setId(1L);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		//model.setUpdatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}

	public static AddMessageFormatConfigModel getAddMessageFormatModel() {
		AddMessageFormatConfigModel model = new AddMessageFormatConfigModel();
		model.setMsgType("0200");
		model.setOwnerName("SCM");
		model.setOwnerType(OwnerType.SOURCE);
		model.setEntityId("123L");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		//model.setCreatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}

	
	
	
	
}
