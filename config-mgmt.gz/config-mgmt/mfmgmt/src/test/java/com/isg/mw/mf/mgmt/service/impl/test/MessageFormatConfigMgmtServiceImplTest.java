package com.isg.mw.mf.mgmt.service.impl.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.dao.service.MessageFormatConfigEditCopyService;
import com.isg.mw.mf.dao.service.MfPrivateOnlineValidator;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.impl.MessageFormatConfigMgmtServiceImpl;
import com.isg.mw.mf.mgmt.validations.MfPrivateOfflineValidator;
import com.isg.mw.sc.dao.service.SourceMfEditCopyService;
import com.isg.mw.sc.dao.service.SourceMfMasterService;
import com.isg.mw.sc.dao.service.SourceMfOnlineValidator;
import com.isg.mw.tc.dao.service.TargetMfEditCopyService;
import com.isg.mw.tc.dao.service.TargetMfMasterService;
import com.isg.mw.tc.dao.service.TargetMfOnlineValidator;

public class MessageFormatConfigMgmtServiceImplTest {

	@Mock
	private MessageFormatConfigEditCopyService messageFormatConfigEditCopyService;

	@Mock
	private TargetMfOnlineValidator targetMfOnlineValidator;

	@Mock
	private SourceMfOnlineValidator sourceMfOnlineValidator;

	@Mock
	private MfPrivateOfflineValidator mfPrivateOfflineValidator;

	@Mock
	private MfPrivateOnlineValidator mfPrivateOnlineValidator;

	@Mock
	private TargetMfEditCopyService targetMfEditCopyService;

	@Mock
	private SourceMfEditCopyService sourceMfEditCopyService;

	@Mock
	private TargetMfMasterService targetMfMasterService;

	@Mock
	private SourceMfMasterService sourceMfMasterService;

	@InjectMocks
	private MessageFormatConfigMgmtServiceImpl messageFormatConfigMgmtService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void addPT01() {
		Mockito.when(messageFormatConfigEditCopyService.add(Mockito.any()))
				.thenReturn(getMessageFormatModel(OwnerType.TARGET));
		ResponseEntity<?> add = messageFormatConfigMgmtService.add(getAddMessageFormatModel(OwnerType.TARGET));
		assertEquals(add.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void addPT02() {
		Mockito.when(messageFormatConfigEditCopyService.add(Mockito.any()))
				.thenReturn(getMessageFormatModel(OwnerType.SOURCE));
		ResponseEntity<?> add = messageFormatConfigMgmtService.add(getAddMessageFormatModel(OwnerType.SOURCE));
		assertEquals(add.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void addNT01() {
		String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG,
				OwnerType.ISG_VANILLA);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> add = messageFormatConfigMgmtService.add(getAddMessageFormatModel(OwnerType.ISG_VANILLA));
		assertEquals(add, response);
	}

	@Test
	public void addNT02() {
		String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(messageFormatConfigEditCopyService.add(Mockito.any())).thenThrow(RuntimeException.class);

		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> add = messageFormatConfigMgmtService.add(getAddMessageFormatModel(OwnerType.SOURCE));
		assertEquals(add, response);
	}

	@Test
	public void modifyPT01() {
		Mockito.when(mfPrivateOnlineValidator.getOwnerType(Mockito.any())).thenReturn(null);
		String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INVALID_MF_ID_ERROR,
				getModifyMessageFormatModel().getId());
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> modify = messageFormatConfigMgmtService.modify(getModifyMessageFormatModel());
		assertEquals(modify, response);
	}

	@Test
	public void modifyPT02() {
		Mockito.when(mfPrivateOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.TARGET);
		Mockito.when(messageFormatConfigEditCopyService.update(Mockito.any()))
				.thenReturn(getMessageFormatModel(OwnerType.TARGET));
		ResponseEntity<?> modify = messageFormatConfigMgmtService.modify(getModifyMessageFormatModel());
		assertEquals(modify.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void modifyPT03() {
		Mockito.when(mfPrivateOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.SOURCE);
		Mockito.when(messageFormatConfigEditCopyService.update(Mockito.any()))
				.thenReturn(getMessageFormatModel(OwnerType.SOURCE));
		ResponseEntity<?> modify = messageFormatConfigMgmtService.modify(getModifyMessageFormatModel());
		assertEquals(modify.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void modifyNT01() {
		Mockito.when(mfPrivateOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.ISG_VANILLA);
		String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> modify = messageFormatConfigMgmtService.modify(getModifyMessageFormatModel());
		assertEquals(modify, response);
	}

	@Test
	public void modifyNT02() {
		Mockito.when(mfPrivateOnlineValidator.getOwnerType(Mockito.any())).thenReturn(OwnerType.SOURCE);
		Mockito.when(messageFormatConfigEditCopyService.update(Mockito.any())).thenThrow(RuntimeException.class);
		String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> modify = messageFormatConfigMgmtService.modify(getModifyMessageFormatModel());
		assertEquals(modify, response);
	}

	@Test
	public void deletePT01() {
		String errorMsg = null;
		ResponseEntity<?> response = null;
		try {
			messageFormatConfigMgmtService.delete(1L, OwnerType.TARGET);
			response = new ResponseEntity<>("Success", HttpStatus.OK);
		} catch (Exception e) {
			errorMsg = e.getMessage();
		}
		assertNull(errorMsg);
		assertEquals(response.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void deletePT02() {
		String errorMsg = null;
		ResponseEntity<?> response = null;
		try {
			messageFormatConfigMgmtService.delete(1L, OwnerType.SOURCE);
			response = new ResponseEntity<>("Success", HttpStatus.OK);
		} catch (Exception e) {
			errorMsg = e.getMessage();
		}
		assertNull(errorMsg);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void deleteNT01() {
		String errorMsg = null;
		ResponseEntity<?> response = null;
		try {
			messageFormatConfigMgmtService.delete(1L, OwnerType.ISG_VANILLA);
			response = new ResponseEntity<>(errorMsg, HttpStatus.EXPECTATION_FAILED);
		} catch (ValidationException e) {
			errorMsg = e.getMessage();
		}
		assertEquals(response.getStatusCode(), HttpStatus.EXPECTATION_FAILED);

	}

	@Test
	public void deleteNT02() {
		String errorMsg = null;
		ResponseEntity<?> response = null;
		try {
			Mockito.doThrow(RuntimeException.class).when(sourceMfOnlineValidator).deleteValidation(Mockito.anyLong());
			messageFormatConfigMgmtService.delete(1L, OwnerType.SOURCE);
			errorMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			response = new ResponseEntity<>(errorMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			errorMsg = e.getMessage();
		}
		assertNotNull(errorMsg);
		assertNotNull(response);
	}

	@Test
	public void getListPT01() {

		Mockito.when(targetMfMasterService.getList("123", "TCM"))
				.thenReturn(getMessageFormatModelList(OwnerType.TARGET));
		Mockito.when(targetMfEditCopyService.getList("123", "TCM"))
				.thenReturn(getMessageFormatModelList(OwnerType.TARGET));
		ResponseEntity<?> list = messageFormatConfigMgmtService.getList("123", "TCM", OwnerType.TARGET);
		assertNotNull(list);
	}
	@Test
	public void getListPT02() {

		Mockito.when(sourceMfMasterService.getList("123", "SCM"))
				.thenReturn(getMessageFormatModelList(OwnerType.TARGET));
		Mockito.when(sourceMfEditCopyService.getList("123", "SCM"))
				.thenReturn(getMessageFormatModelList(OwnerType.TARGET));
		ResponseEntity<?> list = messageFormatConfigMgmtService.getList("123", "SCM", OwnerType.SOURCE);
		assertNotNull(list);
	}
	
	@Test
	public void getListNT01() {
		String errMsg=PropertyUtils.getMessage(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG);
		ResponseEntity<?> response=new ResponseEntity<>(errMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> list = messageFormatConfigMgmtService.getList("123", "SCM", OwnerType.ISG_VANILLA);
		assertEquals(list,response);
	}
	
	@Test
	public void getListNT02() {
		String errMsg=PropertyUtils.getMessage(MfMgmtMsgKeys.MFP_LIST_EMPTY);
		ResponseEntity<?> response=new ResponseEntity<>(errMsg, HttpStatus.NO_CONTENT);
		ResponseEntity<?> list = messageFormatConfigMgmtService.getList("123", "SCM", OwnerType.SOURCE);
		assertEquals(list,response);
	}
	
	@Test
	public void getListNT03() {
		Mockito.when(sourceMfEditCopyService.getList("123", "SCM"))
		.thenThrow(RuntimeException.class);

		String errMsg=PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		ResponseEntity<?> response=new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> list = messageFormatConfigMgmtService.getList("123", "SCM", OwnerType.SOURCE);
		assertEquals(list,response);
	}

	public static AddMessageFormatConfigModel getAddMessageFormatModel(OwnerType type) {
		AddMessageFormatConfigModel model = new AddMessageFormatConfigModel();
		model.setOwnerType(type);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
	//	model.setCreatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}

	public static ModifyMessageFormatConfigModel getModifyMessageFormatModel() {
		ModifyMessageFormatConfigModel model = new ModifyMessageFormatConfigModel();
		model.setId(1L);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		//model.setUpdatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}

	private static BusinessRule getBusinessRule() {
		BusinessRule businessRule = new BusinessRule();
		businessRule.setClassName("Utility");
		businessRule.setMethodName("getUtility");
		return businessRule;
	}

	public static MessageFormatConfigModel getMessageFormatModel(OwnerType type) {
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setOwnerId(123L);
		model.setOwnerType(type);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		model.setCreatedBy("john");
		model.setUpdatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}

	public static List<MessageFormatConfigModel> getMessageFormatModelList(OwnerType type) {
		List<MessageFormatConfigModel> list = new ArrayList<MessageFormatConfigModel>();
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setOwnerId(123L);
		model.setOwnerType(type);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		model.setCreatedBy("john");
		model.setUpdatedBy("john");
		model.setBusinessRule(getBusinessRule());
		list.add(model);
		return list;
	}

}
