package com.isg.mw.mf.mgmt.service.impl.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.mf.ConfigSummary;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.core.utils.CoreUtils;
import com.isg.mw.core.utils.DateFormatUtils;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.service.impl.ConfigMgmtServiceImpl;
import com.isg.mw.mf.mgmt.validations.ConfigOfflineValidator;
import com.isg.mw.sc.dao.entities.SourceConfigEditCopyEntity;
import com.isg.mw.sc.dao.entities.SourceConfigMasterEntity;
import com.isg.mw.sc.dao.service.SourceConfigEditCopyService;
import com.isg.mw.sc.dao.service.SourceConfigMasterService;
import com.isg.mw.sc.dao.utils.SourceCommonUtil;
import com.isg.mw.tc.dao.entities.TargetConfigEditCopyEntity;
import com.isg.mw.tc.dao.entities.TargetConfigMasterEntity;
import com.isg.mw.tc.dao.service.TargetConfigEditCopyService;
import com.isg.mw.tc.dao.service.TargetConfigMasterService;
import com.isg.mw.tc.dao.utils.TargetCommonUtil;

public class ConfigMgmtServiceImplTest {

	@Mock
	private TargetConfigMasterService targetConfigMasterService;

	@Mock
	private SourceConfigMasterService sourceConfigMasterService;

	@Mock
	private SourceConfigEditCopyService sourceEditCopyService;

	@Mock
	private TargetConfigEditCopyService targetEditCopyService;

	@Mock
	private ConfigOfflineValidator configOfflineValidator;

	@InjectMocks
	private ConfigMgmtServiceImpl configMgmtService;

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void validatePT01() {
		Mockito.when(targetConfigMasterService.get(Mockito.any(), Mockito.any()))
				.thenReturn(getTargetMasterEntity(LockedState.Locked));
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.TARGET);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void validate02() {
		Mockito.when(targetConfigMasterService.get(Mockito.any(), Mockito.any()))
				.thenReturn(getTargetMasterEntity(LockedState.Unlocked));
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.TARGET);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void validate03() {
		Mockito.when(targetConfigMasterService.get(Mockito.any(), Mockito.any())).thenReturn(null);
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.TARGET);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void validatePT04() {
		Mockito.when(sourceConfigMasterService.get(Mockito.any(), Mockito.any()))
				.thenReturn(getSCMasterEntity(LockedState.Locked).get(0));
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.SOURCE);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void validate05() {
		Mockito.when(sourceConfigMasterService.get(Mockito.any(), Mockito.any()))
				.thenReturn(getSCMasterEntity(LockedState.Unlocked).get(0));
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.SOURCE);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void validate06() {
		Mockito.when(sourceConfigMasterService.get(Mockito.any(), Mockito.any())).thenReturn(null);
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.SOURCE);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);

	}

	@Test
	public void validateNT01() {
		String errorMsg = null;
		ResponseEntity<?> entity = null;
		try {
			entity = configMgmtService.validate("123", "TCM", OwnerType.ISG_VANILLA);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
		}
		assertNull(errorMsg);
		assertEquals(entity.getStatusCode(), HttpStatus.EXPECTATION_FAILED);
	}

	@Test
	public void validateNT02() {
		String errorMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(sourceConfigMasterService.get(Mockito.any(), Mockito.any())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.SOURCE);
		assertEquals(entity, response);
	}

	@Test
	public void getAllPT01() {
		String errorMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.OWNER_TYPE_NOT_BELONG_TO_ANY_CONFIG);
		ResponseEntity<?> response = new ResponseEntity<>(errorMsg, HttpStatus.EXPECTATION_FAILED);
		ResponseEntity<?> entity = configMgmtService.validate("123", "TCM", OwnerType.ISG_VANILLA);
		configMgmtService.getAll("123", OwnerType.ISG_VANILLA);
		assertEquals(response, entity);
	}

	@Test
	public void getAllPT02() {
		Mockito.when(targetConfigMasterService.getAll(Mockito.anyString()))
				.thenReturn(getConfigSummaryaTargetMaster(getTargetMasterEntity(LockedState.Unlocked)));
		Mockito.when(targetEditCopyService.getAll(Mockito.anyString()))
				.thenReturn(getConfigSummaryTargetEdit(getTargetEditCopyEntity()));

		ResponseEntity<?> entity = configMgmtService.getAll("123", OwnerType.TARGET);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void getAllPT03() {
		Mockito.when(sourceConfigMasterService.getAll(Mockito.anyString()))
				.thenReturn(getConfigSummuryMaster(getSCMasterEntity(LockedState.Unlocked).get(0)));

		Mockito.when(sourceEditCopyService.getAll(Mockito.anyString()))
				.thenReturn(getConfigSummuryEditCopy(getSCEditCopyEntity(EditStatus.Inprogress, "SCM").get(0)));

		ResponseEntity<?> entity = configMgmtService.getAll("123", OwnerType.SOURCE);
		assertNotNull(entity);
		assertEquals(entity.getStatusCode(), HttpStatus.OK);
	}

	@Test
	public void getallNT03() {
		String errorMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
		Mockito.when(sourceConfigMasterService.getAll(Mockito.anyString())).thenThrow(RuntimeException.class);
		ResponseEntity<?> response = new ResponseEntity<>(errorMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		ResponseEntity<?> entity = configMgmtService.getAll("123", OwnerType.SOURCE);
		assertEquals(entity, response);
	}

	private static List<ConfigSummary> getConfigSummuryMaster(SourceConfigMasterEntity entity) {
		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		ConfigSummary model = new ConfigSummary();
		model.setEntityId(entity.getEntityId());
		model.setOwnerType(OwnerType.SOURCE);
		model.setConfigName(entity.getName());
		model.setConfigStatus(entity.getStatus());
		model.setMasterExists(true);
		model.setLockedState(entity.getLockedState());
		list.add(model);
		return list;
	}

	private static List<ConfigSummary> getConfigSummuryEditCopy(SourceConfigEditCopyEntity entity) {
		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		ConfigSummary model = new ConfigSummary();
		model.setEntityId(entity.getEntityId());
		model.setOwnerType(OwnerType.SOURCE);
		model.setConfigName(entity.getName());
		model.setEditStatus(entity.getStatus());
		model.setMasterExists(true);
		list.add(model);
		return list;
	}

	private List<ConfigSummary> getConfigSummaryaTargetMaster(TargetConfigMasterEntity entity) {
		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		ConfigSummary model = new ConfigSummary();
		model.setEntityId(entity.getEntityId());
		model.setOwnerType(OwnerType.TARGET);
		model.setConfigName(entity.getName());
		model.setConfigStatus(entity.getStatus());
		model.setLockedState(entity.getLockedState());
		list.add(model);
		return list;
	}

	private List<ConfigSummary> getConfigSummaryTargetEdit(TargetConfigEditCopyEntity entity) {
		List<ConfigSummary> list = new ArrayList<ConfigSummary>();
		ConfigSummary model = new ConfigSummary();
		model.setEntityId(entity.getEntityId());
		model.setOwnerType(OwnerType.TARGET);
		model.setConfigName(entity.getName());
		model.setEditStatus(entity.getStatus());
		list.add(model);
		return list;
	}

	private TargetConfigMasterEntity getTargetMasterEntity(LockedState lockedState) {
		TargetConfigMasterEntity entity = new TargetConfigMasterEntity();
		entity.setId(1L);
		entity.setEntityId("123");
		entity.setName("TCM");
		entity.setTargetType(TargetType.Master);
		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setStatus(ConfigStatus.Active);
		entity.setCreatedBy("ISG client");
		entity.setUpdatedBy("ISG admin");
		entity.setLockedState(lockedState);
		entity.setConnections(TargetCommonUtil.convertTargetConnectionListToString(getConnections()));
		return entity;
	}

	private TargetConfigEditCopyEntity getTargetEditCopyEntity() {
		TargetConfigEditCopyEntity entity = new TargetConfigEditCopyEntity();
		entity.setId(123L);
		entity.setEntityId("1");
		entity.setName("master");
		entity.setTargetType(TargetType.Master);
		entity.setCreatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setUpdatedAt(DateFormatUtils.getCurrentOffsetDateTime());
		entity.setStatus(EditStatus.Inprogress);
		entity.setCreatedBy("ISG client");
		entity.setUpdatedBy("ISG admin");
		entity.setConnections(TargetCommonUtil.convertTargetConnectionListToString(getConnections()));
		return entity;
	}

	private List<SourceConfigEditCopyEntity> getSCEditCopyEntity(EditStatus status, String name) {
		List<SourceConfigEditCopyEntity> list = new ArrayList<SourceConfigEditCopyEntity>();
		SourceConfigEditCopyEntity entity = new SourceConfigEditCopyEntity();
		entity.setId(123L);
		entity.setName(name);
		entity.setStatus(status);
		list.add(entity);
		return list;
	}

	private byte[] byteConversion() {
		byte[] byteArr = "ABCD".getBytes();
		return byteArr;
	}

	private List<TargetConnection> getConnections() {
		List<TargetConnection> list = new ArrayList<TargetConnection>();
		TargetConnection conn = new TargetConnection();
		conn.setType(ConnectionType.ISO);
		conn.setUrlOrIp("192.168.34.32");
		conn.setPortOrHeaders("8090");
		list.add(conn);
		return list;
	}

	private List<SourceConfigMasterEntity> getSCMasterEntity(LockedState state) {
		List<SourceConfigMasterEntity> list = new ArrayList<SourceConfigMasterEntity>();
		SourceConfigMasterEntity entity = new SourceConfigMasterEntity();
		entity.setEntityId("123");
		entity.setName("SCM");
		entity.setDefaultTarget("TCM");
		entity.setTargetPreferences(CoreUtils.arrayToString(demoRecord()));
		entity.setConnectionType(ConnectionType.ISO);
		entity.setPortOrUri("9093");
		entity.setLockedState(state);
		entity.setId(2L);
		entity.setStatus(ConfigStatus.Active);
		list.add(entity);
		return list;
	}

	public static String[] demoRecord() {

		String[] merPrefArr = { "asdf", "asdf" };
		return merPrefArr;
	}

	public static MerchantPreference[] merPreferencesArray() {

		MerchantPreference[] merPrefArr = new MerchantPreference[] { MerchantPreference.ONUS,
				MerchantPreference.PRICING, MerchantPreference.MERCHANT_CHOICE };
		return merPrefArr;
	}

	public String merPreferencesString() {
		return SourceCommonUtil.convertTargetConnectionListToString(merPreferencesArray());
	}

}
