package com.isg.mw.mf.controller.test;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.mf.controller.CommonConfigController;
import com.isg.mw.mf.mgmt.constants.MessageFormatUri;
import com.isg.mw.mf.mgmt.service.ConfigMgmtService;

@RunWith(SpringJUnit4ClassRunner.class)
public class CommonConfigControllerTest {

	private MockMvc mockMvc;

	@Mock
	private ConfigMgmtService configMgmtService;
	
	@InjectMocks
	private CommonConfigController commonConfigController;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(commonConfigController).build();
	}

	@Test
	public void validate() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("entityId", "123L");
		requestParams.add("ownerName", "SCM");
		requestParams.add("ownerType", OwnerType.SOURCE.name());

		mockMvc.perform(
				MockMvcRequestBuilders.get(MessageFormatUri.PARENT_VD + MessageFormatUri.VALIDATE_VD).params(requestParams))
				.andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}
	
	@Test
	public void getAll() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("entityId", "123L");
		requestParams.add("ownerType", OwnerType.SOURCE.name());

		mockMvc.perform(
				MockMvcRequestBuilders.get(MessageFormatUri.PARENT_VD + MessageFormatUri.GET_ALL).params(requestParams))
				.andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}
	
		

}
