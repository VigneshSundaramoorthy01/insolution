package com.isg.mw.mf.controller.test;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.mf.controller.MessageFormatPrivateConfigController;
import com.isg.mw.mf.mgmt.constants.MessageFormatUri;
import com.isg.mw.mf.mgmt.model.AddMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.model.ModifyMessageFormatConfigModel;
import com.isg.mw.mf.mgmt.service.MessageFormatConfigMgmtService;

@RunWith(SpringJUnit4ClassRunner.class)
public class MessageFormatPrivateConfigControllerTest {

	private MockMvc mockMvc;

	@Mock
	private MessageFormatConfigMgmtService messageFormatConfigMgmtService;

	@InjectMocks
	private MessageFormatPrivateConfigController messageFormatPrivateConfigController;


	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(messageFormatPrivateConfigController).build();
	}

	@Test
	public void addPT01() throws Exception {
		AddMessageFormatConfigModel model = getAddModel();
		String requestBody = new ObjectMapper().valueToTree(model).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(MessageFormatUri.PARENT_PR + MessageFormatUri.ADD_PR)
				.content(requestBody).contentType(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(MockMvcResultMatchers.status().isOk());

	}

	@Test
	public void getModifyTest() throws Exception {
		ModifyMessageFormatConfigModel model = getModifyMessageFormatModel();
		String requestBody = new ObjectMapper().valueToTree(model).toString();

		mockMvc.perform(MockMvcRequestBuilders.post(MessageFormatUri.PARENT_PR + MessageFormatUri.MODIFY_PR)
				.content(requestBody).contentType(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());

	}

	@Test
	public void delete() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("id","123");
		requestParams.add("ownerType", OwnerType.SOURCE.name());
		mockMvc.perform(MockMvcRequestBuilders.get(MessageFormatUri.PARENT_PR + MessageFormatUri.DELETE_PR).params(requestParams)).andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void getList() throws Exception {
		LinkedMultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();
		requestParams.add("entityId", "123L");
		requestParams.add("name", "SCM");
		requestParams.add("ownerType", OwnerType.SOURCE.name());
		
		mockMvc.perform(MockMvcRequestBuilders.get(MessageFormatUri.PARENT_PR + MessageFormatUri.GET_LIST_PR)
				.params(requestParams)).andDo(print()).andExpect(MockMvcResultMatchers.status().isOk());
	}

	private AddMessageFormatConfigModel getAddModel() {
		AddMessageFormatConfigModel model = new AddMessageFormatConfigModel();
		//model.setCreatedBy("john");
		model.setMsgType("0200");
		model.setDescription("Isg vanila message");
		model.setBusinessRule(getBusinessRule());
		model.setMsgFormat(
				"01 28 60 00 56 00 00 02 00  30 20 05 80 20 C0 1A 06 00 00 00 00 00 00 00 30  00 00 00 31 00 51 00 56 00 64 A6 1B 69 D4 92 40  BB 29 2A 45 D7 62 F8 58 EE 97 2D 41 93 A1 A8 96  89 7D 1A E4 85 51 03 6B A9 1D 48 50 59 42 4C 30  30 37 48 50 59 42 49 4A 41 4C 49 50 30 30 30 30  37 B5 D8 1C 94 9C F5 06 36 09 87 65 43 21 00 00  06 01 45 9F 02 06 00 00 00 00 30 00 9F 03 06 00  00 00 00 00 00 84 07 A0 00 00 00 03 10 10 82 02  3C 00 9F 36 02 01 F7 9F 07 02 FF 00 9F 26 08 0F  38 0F 21 47 66 AD F8 9F 27 01 80 9F 34 03 42 03  00 9F 1E 08 30 31 30 31 35 37 34 34 9F 10 07 06  01 0A 03 A0 A8 04 9F 09 02 00 8C 9F 33 03 E0 F0  C8 9F 1A 02 03 56 9F 35 01 22 95 05 08 80 04 00  00 5F 2A 02 03 56 5F 34 01 01 9A 03 19 12 10 9C  01 00 9F 37 04 B1 F0 39  4E 9F 41 04 00 00 00 31  9F 53 01 52 00 06 30 30 30 30 33 32 00 35 30 30  30 36 30 38 30 31 30 31 35 37 34 34 30 30 30 35  30 30 30 30 30 34 33 30 30 30 31 33 35 36 33 35  36");
		return model;
	}

	private static BusinessRule getBusinessRule() {
		BusinessRule businessRule = new BusinessRule();
		businessRule.setClassName("Utility");
		businessRule.setMethodName("getUtility");
		return businessRule;
	}

	public static ModifyMessageFormatConfigModel getModifyMessageFormatModel() {
		ModifyMessageFormatConfigModel model = new ModifyMessageFormatConfigModel();
		model.setId(1L);
		model.setMsgType("0200");
		model.setMsgFormat("0200");
		model.setDescription("This is utijlity class");
		//model.setUpdatedBy("john");
		model.setBusinessRule(getBusinessRule());
		return model;
	}

}
