package com.isg.mw.mf.mgmt.validations.test;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;
import com.isg.mw.mf.mgmt.validations.ConfigOfflineValidatorImpl;

public class ConfigOfflineValidatorImplTest {

	@InjectMocks
	private ConfigOfflineValidatorImpl configOfflineValidator;

    @Before
    public void init() {
    	MockitoAnnotations.initMocks(this);
    }
    
	@Rule
	public final ExpectedException exception = ExpectedException.none();
    
    @Test
    public void validateValidationNT01() {
    	exception.expect(ValidationException.class);
    	exception.expectMessage(MfMgmtMsgKeys.Field_IS_MANDATORY);
    	configOfflineValidator.validateValidation(null, "SCM", OwnerType.SOURCE);
    }
    @Test
    public void validateValidationNT02() {
    	exception.expect(ValidationException.class);
    	exception.expectMessage(MfMgmtMsgKeys.Field_IS_MANDATORY);
    	configOfflineValidator.validateValidation("123L", null, OwnerType.SOURCE);
    }
    @Test
    public void validateValidationNT03() {
    	exception.expect(ValidationException.class);
    	exception.expectMessage(MfMgmtMsgKeys.Field_IS_MANDATORY);
    	configOfflineValidator.validateValidation("123L", "SCM", null);
    }
    @Test
    public void validateValidationPT01() {
    	configOfflineValidator.validateValidation("123L", "SCM", OwnerType.SOURCE);
    }
    @Test
    public void getAllValidationNT01() {
    	exception.expect(ValidationException.class);
    	exception.expectMessage(MfMgmtMsgKeys.Field_IS_MANDATORY);
    	configOfflineValidator.getAllValidation(null, OwnerType.SOURCE);
    }
    @Test
    public void getAllValidationPT01() {
    	configOfflineValidator.getAllValidation("123L", OwnerType.SOURCE);
    }
    
    
	
	
}
