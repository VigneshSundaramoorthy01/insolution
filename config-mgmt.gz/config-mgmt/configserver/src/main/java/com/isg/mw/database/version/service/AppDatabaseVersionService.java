package com.isg.mw.database.version.service;

import com.isg.mw.exception.ConfigMgmtServerInitializationException;

public interface AppDatabaseVersionService {

	/**
	 * Method which check the database version and application version and based on
	 * 
	 * @return Entity class object
	 * @throws ConfigMgmtServerInitializationException
	 */
	public boolean checkDbVesion() throws ConfigMgmtServerInitializationException;

}
