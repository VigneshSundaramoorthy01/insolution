package com.isg.mw.database.version.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.isg.mw.database.version.entity.AppDatabaseVersionEntity;

@Repository
public interface AppDatabaseVersionRepository extends CrudRepository<AppDatabaseVersionEntity, Long> {
	/**
	 * Method will find the selected version based on version and application
	 * version
	 * 
	 * @param version    database version
	 * @param appVersion application version
	 * @return return the entity class object
	 */

	@Query("SELECT e FROM AppDatabaseVersionEntity e where version = :version AND appVersion = :appVersion")
	AppDatabaseVersionEntity findByDbVersion(@Param("version") String version, @Param("appVersion") String appVersion);

}
