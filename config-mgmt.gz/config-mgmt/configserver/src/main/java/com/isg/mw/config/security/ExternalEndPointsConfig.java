//package com.isg.mw.config.security;
//
//
//import java.util.Arrays;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.annotation.Order;
//import org.springframework.core.env.Environment;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//@EnableWebSecurity
//@Order(1)
//public class ExternalEndPointsConfig extends WebSecurityConfigurerAdapter {
//
//	private final Logger logger = LogManager.getLogger(getClass());
//
//	@Autowired
//	private Environment env;
//
//	@Autowired
//	private JwtAuthorizationFilter jwtAuthFilter;
//
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		String[] authWhiteList = env.getProperty("config.uri.auth.whitelist", String[].class);
//		logger.trace("authWhiteList {}", Arrays.asList(authWhiteList));
//		http.cors().and().csrf().disable()
//				.authorizeRequests().antMatchers(authWhiteList).permitAll().anyRequest()
//				.authenticated().and()
//				.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
//				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
//	}
//}
