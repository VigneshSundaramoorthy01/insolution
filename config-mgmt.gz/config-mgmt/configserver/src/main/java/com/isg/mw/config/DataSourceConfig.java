package com.isg.mw.config;

import com.isg.mw.security.utils.PBEncryptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Primary
@Configuration
public class DataSourceConfig extends DataSourceProperties {

    @Value("${encryption.password}")
    private String encryptionPwd;

    @Value("${encrypted.password}")
    private String encryptedPwd;

    @Override
    public void afterPropertiesSet() throws Exception {
        this.setPassword(PBEncryptor.decrypt(encryptedPwd, encryptionPwd));
        super.afterPropertiesSet();
    }

}
