//package com.isg.mw.config.security;
//
//import java.io.IOException;
//import java.util.ArrayList;
//
//import javax.servlet.FilterChain;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.apache.commons.lang3.StringUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.stereotype.Component;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import com.isg.mw.core.rbac.model.Payload;
//import com.isg.mw.core.rbac.utils.RbacUtil;
//import com.isg.rbac.validation.TokenValidation;
//
//@Component
//public class JwtAuthorizationFilter extends OncePerRequestFilter {
//
//    private final Logger log = LogManager.getLogger(getClass());
//
//    private static final String AUTH_HEADER = "Authorization";
//
//	private static final String USER_NAME_HEADER = "User-Name";
//
//    @Value("${config.pr.jwt.key}")
//    private String configIntJwtSecret;
//
//    @Override
//    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//            throws ServletException, IOException {
//        String authHeader = request.getHeader(AUTH_HEADER);
//
//        if (StringUtils.isBlank(authHeader)) {
//
//            filterChain.doFilter(request, response);
//            return;
//        }
//        log.trace("Request URI: {}", request.getRequestURI());
//        UsernamePasswordAuthenticationToken authentication = getAuthentication(request);
//        if (authentication != null) {
//            SecurityContextHolder.getContext().setAuthentication(authentication);
//        }
//
//        filterChain.doFilter(request, response);
//    }
//
//    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
//        TokenValidation tokenValid = new TokenValidation();
//        boolean isValidToken = tokenValid.validateJwtToken(request.getHeader(AUTH_HEADER), configIntJwtSecret.trim(),request.getHeader(USER_NAME_HEADER));
//        log.trace("isValidToken: {}", isValidToken);
//        if (isValidToken) {
//            Payload payload = RbacUtil.getPayload(request.getHeader(AUTH_HEADER));
//            log.trace("User Name : {} ", payload.getUserName());
//            if (!StringUtils.isBlank(payload.getUserName())) {
//                return new UsernamePasswordAuthenticationToken(payload.getUserName(), null, new ArrayList<>());
//            }
//        }
//        return null;
//
//    }
//
//}