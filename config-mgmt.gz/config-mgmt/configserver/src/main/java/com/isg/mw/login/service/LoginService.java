package com.isg.mw.login.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.rbac.model.AuthParams;
import com.isg.mw.core.rbac.model.Payload;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.login.constant.RbacServerProperties;
import com.isg.mw.mf.mgmt.constants.MfMgmtMsgKeys;

import reactor.core.publisher.Mono;

@Service
public class LoginService {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Autowired
	private WebClient.Builder webClient;

	@Autowired
	private RbacServerProperties props;

	private static final String UNAUTHRISED_USER = "User name or Password is invalid";

	public ResponseEntity<?> login() {
		ResponseEntity<?> responseEntity = null;
		Map<String, Object> userMap = new HashMap<>();
		ResponseObj res =null;
		try {
			res= getJwtToken(props.getRbacUserName(), props.getRbacPassword(), props.getRbacLoginUri(),
					props.getRbacServer());
			// validation error
			if (res.getErrors() != null && !StringUtils.isBlank(res.getErrors())) {
				throw new ValidationException(res.getErrors());
			}
			// info message
			if (res.getStatusCode() != null && !res.getStatusCode().equalsIgnoreCase("R001")) {
				throw new ValidationException(res.getMsg());
			}

			JSONObject response = new JSONObject(res);
			String token =  response.getJSONObject("data").getString("token");
//			ObjectMapper mapper = new ObjectMapper();
//			Map<String, Object> userMap = map != null
//					? mapper.convertValue(map.get("Success"), new TypeReference<Map<String, Object>>() {
//					})
//					: null;
//			UserWithToken user = userMap != null
//					? mapper.convertValue(userMap.get("user"), new TypeReference<UserWithToken>() {
//					})
//					: null;

//			if (user == null) {
//				throw new ValidationException(UNAUTHRISED_USER);
//			}

			Payload payload = RbacUtil.getPayload(token);

			if (payload != null) {
				userMap.put("bankId", payload.getBankId());
				userMap.put("tempPswFlag", payload.getTempPswFlag());
				userMap.put("entityId", payload.getEntityId());
			}
			res.setDataMap(userMap);
			responseEntity = new ResponseEntity<>(res, HttpStatus.OK);

		} catch (ValidationException e) {
			String errMsg = e.getMessage();
			LOG.error(errMsg, e);
			responseEntity = new ResponseEntity<>(res, HttpStatus.EXPECTATION_FAILED);
		} catch (Exception e) {
			String errMsg = PropertyUtils.getMessage(MfMgmtMsgKeys.INTERNAL_ERROR);
			LOG.info(errMsg, e);
			responseEntity = new ResponseEntity<>(errMsg, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	public ResponseObj getJwtToken(String userName, String password, String loginUri, String server) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		String loginUrl = new StringBuilder().append(server).append(loginUri).toString();
		AuthParams authParams = new AuthParams();
		authParams.setPassword(password);
		authParams.setUserName(userName);
		Mono<ResponseObj> response = webClient.build().post().uri(loginUrl, headers)
				.body(Mono.just(authParams), AuthParams.class).retrieve().bodyToMono(ResponseObj.class);
		return response.block();
	}

}
