package com.isg.mw.config.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
@Order(2)
public class WebConfig extends WebSecurityConfigurerAdapter {

	private static final String WEB_URI_AUTH_WHITELIST = "config.web.uri.auth.whitelist";

	@Autowired
	private Environment env;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf().disable().authorizeRequests()
				.antMatchers(env.getProperty(WEB_URI_AUTH_WHITELIST, String[].class)).permitAll();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(env.getProperty(WEB_URI_AUTH_WHITELIST, String[].class));
	}
}