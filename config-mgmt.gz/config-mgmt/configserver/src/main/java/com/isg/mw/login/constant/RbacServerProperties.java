package com.isg.mw.login.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@Getter
@Setter
public class RbacServerProperties {

	@Value("${rbac.rest.server}")
	private String rbacServer;
	
	@Value("${rbac.rest.login.uri}")
	private String rbacLoginUri;
	
	@Value("${rbac.rest.userName}")
	private String rbacUserName;
	
	@Value("${rbac.rest.password}")
	private String rbacPassword;
}