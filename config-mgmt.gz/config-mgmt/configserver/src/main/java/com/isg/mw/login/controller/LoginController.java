package com.isg.mw.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isg.mw.login.service.LoginService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "GetJwtToken API", description = "Login Controller")
@RestController
public class LoginController {
	@Autowired
	LoginService loginservice;

	@Operation(summary = "API To Get JWT Token",description="In response will get JWT Token",tags = {"GetJwtToken API"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
    @CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(value = "/getJwtToken", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> login() {
		return loginservice.login();
	}

}
