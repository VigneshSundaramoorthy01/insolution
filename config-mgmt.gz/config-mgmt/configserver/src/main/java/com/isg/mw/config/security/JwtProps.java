package com.isg.mw.config.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author harika4294
 *
 */
@Configuration
@Setter
@Getter
public class JwtProps {	
	
	@Value("${config.pr.jwt.keystore-location}")
	private String intKeystoreLoc;

	@Value("${config.pr.jwt.keystore-password}")
	private String intKeystorePwd;
	
	@Value("${config.pr.jwt.keystore-enc-password}")
	private String intKeyEncryptionPwd;
	
	@Value("${config.pr.jwt.keystore-alias}")
	private String intKeystoreAlias;
}
