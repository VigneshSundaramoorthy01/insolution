package com.isg.mw.database.version.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.database.version.entity.AppDatabaseVersionEntity;
import com.isg.mw.database.version.repository.AppDatabaseVersionRepository;
import com.isg.mw.database.version.service.AppDatabaseVersionService;
import com.isg.mw.exception.ConfigMgmtServerInitializationException;

@Service("appDatabaseVersionServiceImpl")
public class AppDatabaseVersionServiceImpl implements AppDatabaseVersionService {

	private final Logger logger = LogManager.getLogger(getClass());

	@Autowired
	private AppDatabaseVersionRepository appDatabaseVersionRepo;

	@Value("${db.version}")
	private String dbVersion;

	@Value("${app.version}")
	private String appVersion;

	@Override
	public boolean checkDbVesion() throws ConfigMgmtServerInitializationException {

		AppDatabaseVersionEntity findDbVersion = appDatabaseVersionRepo.findByDbVersion(dbVersion, appVersion);
		if (findDbVersion != null) {
			String message = PropertyUtils.getMessage("CM-com.isg.mw.database.version.service.impl-001");
			logger.debug(message);
			return true;
		} else {
			throw new ConfigMgmtServerInitializationException(

					new StringBuilder(PropertyUtils.getMessage("CM-com.isg.mw.database.version.service.impl-002"))
							.append("DbVersion: " + dbVersion + " " + " Appversion: " + appVersion).toString());

		}

	}
}
