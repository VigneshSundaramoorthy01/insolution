package com.isg.mw.config.security;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
public class CorsConfig {

	@Value("${config.allowed.origins:*}")
	private String origins;

	@Bean
	public CorsConfigurationSource corsConfigSource() {
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "Accept","Access-Control-Allow-Origin","Content-Disposition","Access-Control-Expose-Headers"));
		config.setExposedHeaders(Arrays.asList("Content-Disposition"));
		config.setAllowedMethods(Arrays.asList("GET", "POST"));
		config.setAllowedOrigins(Arrays.asList(origins));
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);

		return source;
	}
}
