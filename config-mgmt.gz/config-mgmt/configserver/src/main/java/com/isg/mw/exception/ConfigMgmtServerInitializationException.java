package com.isg.mw.exception;

public class ConfigMgmtServerInitializationException extends Exception {

	private static final long serialVersionUID = 1L;

	public ConfigMgmtServerInitializationException() {
		super();
	}

	public ConfigMgmtServerInitializationException(String msg) {
		super(msg);

	}

}
