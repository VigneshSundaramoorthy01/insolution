package com.isg.mw.login.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(description = "Class represent user request model")
@Getter
@Setter
public class UserModelRequest {

	@ApiModelProperty(required = true, value = "userName")
	private String userName;

	@ApiModelProperty(required = true, value = "password")
	private String password;

}
