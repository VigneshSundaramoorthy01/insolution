package com.isg.mw.config.security;

import javax.crypto.SecretKey;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.isg.mw.core.utils.CommonJwtUtils;

@Configuration
public class JwtSecretConfig {

	private final Logger log = LogManager.getLogger(getClass());

	@Autowired
	private JwtProps jwtProps;

	@Bean
	public SecretKey configIntJwtSecret(@Autowired Environment env) {
		log.trace("KeyStore Location: {}", jwtProps.getIntKeystoreLoc());
		return CommonJwtUtils.getJwtSecretKey(jwtProps.getIntKeystoreLoc(),jwtProps.getIntKeystorePwd(),jwtProps.getIntKeyEncryptionPwd(),jwtProps.getIntKeystoreAlias());	
	}
}