package com.isg.mw;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;

@PropertySources({ @PropertySource("${spring.config.location}swagger-mf.properties"),
		@PropertySource("${spring.config.location}swagger-sc.properties"),
		@PropertySource("${spring.config.location}swagger-tc.properties"),
		@PropertySource("${spring.config.location}swagger-dstm.properties"),
		@PropertySource("${spring.config.location}swagger-mt.properties"),
		@PropertySource("${spring.config.location}swagger-maps.properties"),
		@PropertySource("${spring.config.location}swagger-bins.properties"),
		@PropertySource("${spring.config.location}swagger-sr.properties") })
@OpenAPIDefinition(info = @Info(title = "CONFIG API's", version = "v3", description = "CONFIG API of ISG", contact = @Contact(name = "Access Point Support Team", email = "juberk@insolutionsglobal.com", url = "https://accesspoint.insolutionsglobal.com")), servers = {
		@Server(url = "/accesspoint-config/",description = "Default Server Url"),@Server(url = "http://192.168.83.205:8081/accesspoint-config/", description = "UAT Server"),
		@Server(url = "https://10.159.37.11:8081/accesspoint-config/", description = "PROD Server") })
@Configuration
public class RcmSwaggerConfiguration {

	@Bean
	public OpenAPI configure() {
		return new OpenAPI()
				.components(new Components()
						.addSecuritySchemes("Authorization",
								new SecurityScheme().type(SecurityScheme.Type.APIKEY).in(SecurityScheme.In.HEADER)
										.name("Authorization"))
						.addSecuritySchemes("User-Name",
								new SecurityScheme().type(SecurityScheme.Type.APIKEY).in(SecurityScheme.In.HEADER)
										.name("User-Name")))
				.addSecurityItem(new SecurityRequirement().addList("Authorization"))
				.addSecurityItem(new SecurityRequirement().addList("User-Name"));
	}

}