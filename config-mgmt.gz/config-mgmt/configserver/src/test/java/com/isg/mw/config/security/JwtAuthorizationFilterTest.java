package com.isg.mw.config.security;



import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.IOException;

import javax.crypto.SecretKey;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class JwtAuthorizationFilterTest {

	@Mock
	private SecretKey configIntJwtSecret;
	
	@Mock
	private HttpServletRequest request;
	
	@Mock
	private HttpServletResponse response;
	
	@Mock
	private FilterChain filterChain;

	@BeforeEach
	public void init() 
	{
	  MockitoAnnotations.initMocks(this);
	}

}
