package com.isg.mw.config.security;


import static org.mockito.Mockito.when;

import javax.crypto.SecretKey;


import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

import com.isg.mw.core.utils.CommonJwtUtils;

public class JwtSecretConfigTest {

	/*
	 * @InjectMocks private JwtSecretConfig jwtSecretConfig;
	 * 
	 * @Mock private CommonJwtUtils utils;
	 * 
	 * @Mock private Environment env;
	 * 
	 * @Mock private JwtProps props;
	 * 
	 * @Before public void init() { MockitoAnnotations.initMocks(this); }
	 * 
	 * @Test public void configIntJwtSecretTest() { when(props.getIntKeystoreLoc())
	 * .thenReturn(
	 * "/home/harika4294/Desktop/tlm_res/jwt/keyprovider/configintjwt.keystore");
	 * when(props.getIntKeystoreLoc()) .thenReturn(
	 * "/home/ISG/sanchita3984/Desktop/isg/resourcesFolder/jwt/keyprovider/configintjwt.keystore"
	 * ); when(props.getIntKeystorePwd()).thenReturn(
	 * "fVMBLp9C5WPokoUMsqz6ZODJm+jylqx8RVr1Q/We/DekI+twLgOROLEjtd2DOqE0");
	 * when(props.getIntKeyEncryptionPwd()).thenReturn("configintsecret");
	 * when(props.getIntKeystoreAlias()).thenReturn("configintjwtsecret"); SecretKey
	 * secretKey = jwtSecretConfig.configIntJwtSecret(env);
	 * assertNotNull(secretKey); }
	 */
}
