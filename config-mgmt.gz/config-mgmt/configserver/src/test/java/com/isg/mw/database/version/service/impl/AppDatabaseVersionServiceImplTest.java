package com.isg.mw.database.version.service.impl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.database.version.entity.AppDatabaseVersionEntity;
import com.isg.mw.database.version.repository.AppDatabaseVersionRepository;
import com.isg.mw.exception.ConfigMgmtServerInitializationException;

public class AppDatabaseVersionServiceImplTest {

	@Mock
	private AppDatabaseVersionRepository appDatabaseVersionRepository;

	@InjectMocks
	private AppDatabaseVersionServiceImpl appDatabaseVersionServiceImpl;

	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void systemExitWithSelectedStatusCode0() throws ConfigMgmtServerInitializationException {

		assertThrows(ConfigMgmtServerInitializationException.class, () -> {
			appDatabaseVersionServiceImpl.checkDbVesion();
		});
	}

	@Test
	public void testCheckDbVersion() throws ConfigMgmtServerInitializationException {
		when(appDatabaseVersionRepository.findByDbVersion(Mockito.any(), Mockito.any()))
				.thenReturn(getAppDatabaseVersionEntity("1.0.2", "1.0.2"));
		boolean value = appDatabaseVersionServiceImpl.checkDbVesion();
		assertTrue(value);

	}

	public AppDatabaseVersionEntity getAppDatabaseVersionEntity(String dbversion, String appversion) {
		AppDatabaseVersionEntity appVersionEntity = new AppDatabaseVersionEntity();
		appVersionEntity.setVersion(dbversion);
		appVersionEntity.setAppVersion(appversion);
		return appVersionEntity;
	}

}
