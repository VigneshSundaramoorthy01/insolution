SELECT created_by, created_at, updated_by, updated_at, id, source_id, route_type, success_ratio_interval, success_ratio_max_txns, route_switching_percent, success_threshold, status, target_route_config, remarks
FROM public.smart_route_config_edit_copy;
