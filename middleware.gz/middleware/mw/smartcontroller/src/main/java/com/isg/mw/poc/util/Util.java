package com.isg.mw.poc.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Util {

	public static String formatDate(LocalDateTime date, String format) {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(format);
		return date.format(dateFormatter);
	}
	
}
