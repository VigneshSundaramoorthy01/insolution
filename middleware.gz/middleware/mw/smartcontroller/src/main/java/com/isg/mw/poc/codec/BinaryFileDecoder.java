package com.isg.mw.poc.codec;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;

@ChannelHandler.Sharable
public class BinaryFileDecoder extends MessageToMessageDecoder<ByteBuf> {

	private Logger logger = LogManager.getLogger(getClass());

	static final int PAYLOAD_SIZE = 8;

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf msg, List<Object> out) throws Exception {
		try {
			if (msg.isReadable()) {
				// fill byte array with incoming message
				byte[] bytes = new byte[msg.readableBytes()];
				int readerIndex = msg.readerIndex();
				msg.getBytes(readerIndex, bytes);

				out.add(bytes);
				msg.retain();
			} else {
				out.add(null);
			}
		} catch (Exception e) {
			logger.error("Exception while decoding", e);
		}
	}
}