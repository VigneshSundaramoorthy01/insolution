package com.isg.mw.smc;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.config.CacheHelper;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.service.TargetPaymentModeOptionService;
import com.isg.mw.cache.mgmt.service.TargetPaymentModeService;
import com.isg.mw.cache.mgmt.service.impl.AidSchemeMapServiceImpl;
import com.isg.mw.cache.mgmt.service.impl.BinExceptionServiceImpl;
import com.isg.mw.cache.mgmt.service.impl.BinInfoServiceImpl;
import com.isg.mw.cache.mgmt.service.impl.BinOnusMapServiceImpl;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.util.MwRedisCacheUtil;
import com.isg.mw.routing.RouteStartup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author prasad_t026
 */
@Component
public class SmartControllerImpl implements InitializingBean, SmartController {

    private static final Logger logger = LogManager.getLogger(SmartControllerImpl.class);

    @Autowired
    private HsmCommonService hsmCommonService;

    @Autowired
    private TargetPaymentModeService targetPaymentModeService;

    @Autowired
    private TargetPaymentModeOptionService targetPaymentModeOptionService;

    @Autowired
    private CacheServices cacheServices;

    @Autowired
    private InitRestClient initRestClient;

    @Value("${init.config.rest.page.size:50000}")
    private int pageSize;

    @Value("${bin.fetch.flag}")
    private String binFetchFlag;

    @Value("${raw.msg.encryption.enabled:false}")
    private boolean isEncryptionEnabled;

    @Value("${smart.route.init.status:false}")
    private boolean smartRouteInitStatus;

    @Value("${dcc.rate.lookup.init.status:false}")
    private boolean dccRateLookUpInitStatus;

    @Value("${eftpos.init.status:false}")
    private boolean eftposInitStatus;

    @Autowired
    private CacheHelper cacheHelper;
    
    @Autowired
    private MwRedisCacheUtil mwRedisUtil;

    @Override
    public void afterPropertiesSet() {

        init();

    }

    private void init() {

        logger.info("Initializing Middleware ...");

        TxnLogger.setEncryptionEnabled(isEncryptionEnabled);

        List<TargetConfigModel> targets = initRestClient.getTargetConfigs();
        logger.debug("Fetched Target Configs: {}", targets.size());

        List<SourceConfigModel> sources = initRestClient.getSourceConfigs();
        logger.debug("Fetched Source Configs: {}", sources.size());

        List<MessageTransformationConfigModel> msgTransformations = initRestClient.getMessageTransformationConfigs();
        logger.debug("Fetched Message Transformation Configs: {}", msgTransformations.size());


        List<PaymentModesModel> paymentModesModels=new ArrayList<PaymentModesModel>();
        List<PaymentModeOptionsModel> paymentModeOptionsModels=new ArrayList<PaymentModeOptionsModel>();
        List<TargetPaymentModesModel> targetPaymentModesModels=new ArrayList<TargetPaymentModesModel>();
        List<TargetPaymentModeOptionsModel> targetPaymentModeOptionsModels = new ArrayList<TargetPaymentModeOptionsModel>();
        List<MerchantPaymentModesModel> merchantPaymentModes=new ArrayList<MerchantPaymentModesModel>();
        List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptions=new ArrayList<MerchantPaymentModeOptionsModel>();
        List<MerchantTargetPreferencesModel> merchantTargetPreferences=new ArrayList<MerchantTargetPreferencesModel>();
        List<TargetLCRConfigModel> targetLCRConfigs=new ArrayList<TargetLCRConfigModel>();
        List<MerchantMasterModel> merchantMasterModels=new ArrayList<MerchantMasterModel>();
        List<SmartRouteConfigModel> smartRoutes=new ArrayList<SmartRouteConfigModel>();

        if (smartRouteInitStatus) {
        	smartRoutes = initRestClient.getSmartRouteConfigs();
            logger.debug("Fetched Smart Route Configs: {}", smartRoutes.size());
        	
            paymentModesModels = initRestClient.getPaymentModes();
            logger.debug("Fetched Payment Mode Configs: {}", paymentModesModels.size());

            paymentModeOptionsModels = initRestClient.getPaymentModeOptions();
            logger.debug("Fetched Payment Mode Options Configs: {}", paymentModeOptionsModels.size());

            targetPaymentModesModels = initRestClient.getTargetPaymentModes();
            logger.debug("Fetched Target Payment Mode Configs: {}", targetPaymentModesModels.size());

            targetPaymentModeOptionsModels = initRestClient.getTargetPaymentModeOptions();
            logger.debug("Fetched Target Payment Mode Options Configs: {}", targetPaymentModeOptionsModels.size());

            merchantPaymentModes = initRestClient.getMerchantPaymentModes();
            logger.debug("Fetched Merchant Payment Mode Configs: {}", merchantPaymentModes.size());

            merchantPaymentModeOptions = initRestClient.getMerchantPaymentModeOptions();
            logger.debug("Fetched Merchant Payment Mode Options Configs: {}", merchantPaymentModeOptions.size());

            merchantTargetPreferences = initRestClient.getMerchantTargetPreferences();
            logger.debug("Fetched Merchant Target Preferences Configs: {}", merchantTargetPreferences.size());

            targetLCRConfigs = initRestClient.getTargetLCRConfigs();
            logger.debug("Fetched Target LCR Configs: {}", targetLCRConfigs.size());

            Long merchantsCount = initRestClient.getMerchantsCount();
            logger.debug("Fetched Merchant Master Counts: {}", merchantsCount);
            if (merchantsCount == 0) {
                logger.error("Missing merchant configuration data");
                System.exit(0);
            }

            Long targetMerMasterCount = initRestClient.getTargetMerchantMasterCount();
            logger.debug("Fetched Target Merchant Master Counts: {}", targetMerMasterCount);
            if (targetMerMasterCount == 0) {
                logger.error("Missing Target merchant configuration data");
                System.exit(0);
            }

            merchantMasterModels = initMerchantMasterData(merchantsCount);
            initTargetMerchantMasterData(targetMerMasterCount);

        }
        if (targets.isEmpty() || sources.isEmpty() || msgTransformations.isEmpty()) {
            RuntimeException e = new RuntimeException("Missing configuration data");
            logger.error("", e);
            System.exit(0);
        }

        initMapsInfoData();
        initBinInfoData();
       if(eftposInitStatus) {
           initAidData();
           initBinExceptionData();
           initBinOnusMapData();
       }


        List<HsmConfigModel> dstms = initRestClient.getDstmConfigs();
        if (dstms != null && !dstms.isEmpty()) {
            hsmCommonService.init(dstms);
        }

        List<MftrBDKModel> mftrs = initRestClient.getMftrBdks();
        if (mftrs != null && !mftrs.isEmpty()) {
            cacheServices.initMftrConfigurations(mftrs);
        }
        
        //For the DCC txn and Rate Lookup.
        if (dccRateLookUpInitStatus) {
            initDccRateLookUp();
            initBillingCurriencies();
        }

        RouteStartup.initRouting(sources, targets, msgTransformations, smartRoutes, paymentModesModels, paymentModeOptionsModels,
                targetPaymentModesModels, targetPaymentModeOptionsModels, targetLCRConfigs, merchantPaymentModes, merchantPaymentModeOptions,
                merchantTargetPreferences, merchantMasterModels);

        RouteStartup.startRouting();
        logger.info("Middleware Initialization completed successfully...");
    }

    private void initTargetMerchantMasterData(Long targetMerchantMasterCount) {
        int pageNo = 0;
        while (pageNo < targetMerchantMasterCount) {
            List<TargetMerchantMasterModel> targetMerchantMasterModels = initRestClient.getTargetMerchantMaster(pageNo, pageSize);
            logger.debug("Fetched Target  Merchant Master Configs: {}", targetMerchantMasterModels.size());
            cacheHelper.initTargetMerchantMasterCache(targetMerchantMasterModels);
            pageNo += pageSize;
        }
    }

    private void initDccRateLookUp() {
    	
    	List<RateLookupModel> rateLookupModels = initRestClient.getRateLookups();
    	logger.info("Loading {} Rate Lookup data into memory...", rateLookupModels.size());
    	rateLookupModels.forEach(rateLookupModel -> mwRedisUtil.setDccRateLookUpData(rateLookupModel.getEntityId(), rateLookupModel.getDccTxnIsoCurrencyCode(), rateLookupModel));
        logger.info("{} Rate Lookup data loaded into memory successfully...", rateLookupModels.size());
    }
    
    private void initBillingCurriencies() {
    	
    	List<BillingCurrencyModel> billingCurrencies = initRestClient.getBillingCurrencies();
    	logger.info("Loading {} Billing Curreny data into memory...", billingCurrencies.size());
    	billingCurrencies.forEach(billingCurrency -> mwRedisUtil.setBillingCurrenciesData(billingCurrency.getBillingIsoCurrencyCode(), billingCurrency));
        logger.info("{} Billing Curreny data loaded into memory successfully...", billingCurrencies.size());
    }
    
    private List<MerchantMasterModel> initMerchantMasterData(Long merchantsCount) {
        int pageNo = 0;
        List<MerchantMasterModel> list = new ArrayList<>();
        while (pageNo < merchantsCount) {
            List<MerchantMasterModel> merchantMasterModels = initRestClient.getMerchantMaster(pageNo, pageSize);
            logger.debug("Fetched Merchant Master Configs: {}", merchantMasterModels.size());
            cacheServices.initMerchantMasterConfigurations(merchantMasterModels);
            list.addAll(merchantMasterModels);
            pageNo += pageSize;
        }
        return list;
    }

    private void initBinInfoData() {
        int pageNo;

        if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            Long binCount = initRestClient.getBinCount();
            if (binCount == 0) {
                logger.error("Missing BIN configuration data");
                System.exit(0);
            }

            long startTime = System.currentTimeMillis();
            pageNo = 0;
            while (pageNo < binCount) {
                List<BinInfoModel> binInfos = initRestClient.getBinInfos(pageNo, pageSize);
                cacheServices.initBinConfigurations(binInfos);
                pageNo += pageSize;
            }
            long totTime = System.currentTimeMillis() - startTime;
            logger.info("API BIN Count: {}, Added {} bin records into cache in {} seconds", binCount,
                    BinInfoServiceImpl.getBinCacheMap().size(), (totTime / 1000));
        } else if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            logger.info("Please Note: API mode is enabled to validate the BIN");
        }
    }

    private void initBinOnusMapData() {
        int pageNo;

        if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            Long binCount = initRestClient.getBinOnusCount();
            if (binCount == 0) {
                logger.error("Missing BIN ONUS MAP configuration data");
                System.exit(0);
            }

            long startTime = System.currentTimeMillis();
            pageNo = 0;
            while (pageNo < binCount) {
                List<BinOnusModel> binInfos = initRestClient.getBinOnusMapList(pageNo, pageSize);
                cacheServices.initBinOnusMapConfigurations(binInfos);
                pageNo += pageSize;
            }
            long totTime = System.currentTimeMillis() - startTime;
            logger.info("API BIN Count: {}, Added {} bin records into cache in {} seconds", binCount,
                    BinOnusMapServiceImpl.getBinOnusCacheMap().size(), (totTime / 1000));
        } else if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            logger.info("Please Note: API mode is enabled to validate the BIN");
        }
    }


    private void initBinExceptionData() {
        int pageNo;

        if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            Long binCount = initRestClient.getBinExceptionCount();
            if (binCount == 0) {
                logger.error("Missing BIN ONUS MAP configuration data");
                System.exit(0);
            }

            long startTime = System.currentTimeMillis();
            pageNo = 0;
            while (pageNo < binCount) {
                List<BinExceptionsModel> binInfos = initRestClient.getBinExceptionList(pageNo, pageSize);
                cacheServices.initBinExceptionConfigurations(binInfos);
                pageNo += pageSize;
            }
            long totTime = System.currentTimeMillis() - startTime;
            logger.info("API BIN Count: {}, Added {} bin records into cache in {} seconds", binCount,
                    BinExceptionServiceImpl.getBinExceptionCacheMap().size(), (totTime / 1000));
        } else if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            logger.info("Please Note: API mode is enabled to validate the BIN");
        }
    }



    private void initAidData() {
        int pageNo;

        if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            Long binCount = initRestClient.getAidCount();
            if (binCount == 0) {
                logger.error("Missing AID configuration data");
                System.exit(0);
            }

            long startTime = System.currentTimeMillis();
            pageNo = 0;
            while (pageNo < binCount) {
                List<AidSchemeModel> aidList = initRestClient.getAidList(pageNo, pageSize);
                cacheServices.initAidConfigurations(aidList);
                pageNo += pageSize;
            }
            long totTime = System.currentTimeMillis() - startTime;
            logger.info("API BIN Count: {}, Added {} bin records into cache in {} seconds", binCount, AidSchemeMapServiceImpl.getAidCacheMap().size(), (totTime / 1000));
        } else if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            logger.info("Please Note: API mode is enabled to validate the BIN");
        }
    }

    private void initMapsInfoData() {
        Long mapsCount = initRestClient.getMapsCount();
        logger.debug("Fetched Maps Data Counts: {}", mapsCount);
        if (mapsCount == 0) {
            logger.error("Missing merchant configuration data");
            System.exit(0);
        }

        int pageNo = 0;
        while (pageNo < mapsCount) {
            List<MapsInfoModel> mapsInfos = initRestClient.getMapsInfos(pageNo, pageSize);
            cacheServices.initMapsConfigurations(mapsInfos);
            pageNo += pageSize;
        }
    }
}
