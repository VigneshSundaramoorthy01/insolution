package com.isg.mw.smc;

/**
 * @author prasad_t026
 *
 */
public interface SmartController {

}
