package com.isg.mw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author sudharshan
 */
//@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@SpringBootApplication
@EnableEurekaClient
//@EnableCaching
@ComponentScan(basePackages = { "com.isg.mw.routing", "com.isg.mw.mtm", "com.isg.mw.dstm", "com.isg.mw.cache.mgmt",
		"com.isg.mw" })
public class SmartControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartControllerApplication.class, args);
	}

}
