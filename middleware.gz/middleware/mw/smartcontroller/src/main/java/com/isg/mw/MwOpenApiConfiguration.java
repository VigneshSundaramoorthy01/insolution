package com.isg.mw;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.models.OpenAPI;

@OpenAPIDefinition
(info = @Info(
        title = "MW API's",
        version = "v3",
        description = "Middleware API of ISG",
        contact = @Contact(
                name = "Access Point Support Team",
                email = "juberk@insolutionsglobal.com",
                url = "https://accesspoint.insolutionsglobal.com")),
        servers = {@Server(
                url = "/mw/", description = "Default Server Url"),@Server(
                url = "http://192.168.83.207:7072/mw/", description = "UAT Server"),
                @Server(
                        url = "https://10.159.37.11:8083/mw/", description = "PROD Server")
        })
@Configuration
//@EnableWebMvc
public class MwOpenApiConfiguration {
    @Bean
    public OpenAPI configure() {
        return new OpenAPI();
    }
}
