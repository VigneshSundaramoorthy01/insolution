package com.isg.mw;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.construct.sr.SmartRouteMsgTypeHelper;
import com.isg.mw.core.model.icici.UpiCallbackRequest;
import com.isg.mw.core.model.lyra.LyraMerchantResponseModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.model.tpsl.TpslMerchantRequestModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.core.utils.IsgCurrencyConversionUtils;
import com.isg.mw.core.utils.IsgXmlUtils;
import com.isg.mw.core.utils.SHA512Utils;
import com.isg.mw.core.utils.WibmoEncryptionDecryptionUtil;
import com.isg.mw.mtm.config.DecryptService;
import com.isg.mw.mtm.config.DecryptServiceImpl;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.routing.exception.RefundAmountExceededException;
import com.isg.mw.security.algorithms.AES;
import com.isg.mw.security.algorithms.RSA;
import com.isg.mw.security.security.Decryptor;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.scheduling.support.SimpleTriggerContext;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.JAXBException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.CertificateException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

import static com.isg.mw.core.model.constants.CommonConstants.EMPTY_STR;

public class AESAlgo {
    private static final int MIN_VALUE = 100000;
    private static final int MAX_VALUE = 999999;

    private String mobileNo;

    private String email;

    private String firstName;

    private String lastName;

    private String street;

    private String city;

    private String state;

    private String zip;

    private String UDF01;

    private String UDF02;

    private String UDF03;

    private String UDF04;

    private String UDF05;

    private String UDF06;

    private String UDF07;

    private String UDF08;

    private String UDF09;

    private String UDF10;

    private String international;

    private String debitCreditFlag;

    private String browserName;

    private String browserVersion;

    private String osName;


    public static String encrypt(String request, String key) throws InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {

        Cipher cipher = Cipher.getInstance("AES");

        cipher.init(Cipher.ENCRYPT_MODE,  new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8),"AES"));

        byte[] cipherText = cipher.doFinal(request.getBytes());

        return Base64.getEncoder().encodeToString(cipherText);

    }


    public static String decrypt(String request, String key) throws InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE,  new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8),"AES"));
        byte[] decode = Base64.getDecoder().decode(request.replaceAll(" ", "+").getBytes(StandardCharsets.UTF_8));
        byte[] bytes = cipher.doFinal(decode);
        return new String(bytes);
    }




    public static void main(String[] args) throws InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, JAXBException {
        //String EncyrpteDATA = "hI8DOoyOVnv2c2JlewRhRzW1uKIO0WrIz6HTec4dh4a/ri0v8XBq2eoLvPxp zWj3XDWyvBHQe/K R51PVmJ6v7pvVvHuBcfcPmY8QyGQFc=";

//        String toEncrypt ="PRN=6616427366&ITC=139080190922060232&AMT=1.00&CRN=INR&RU=https://geniuscrm.insolutionsglobal.com:8010/accesspoint/iciciretailresponse?eid=24520&mid=10000012345&tid=1000001&merchantTxnRefNo=6616427366&payopt=&redeemgc=&gcertno=&CG=Y";;
//
//        System.out.println(AESAlgo.encrypt(toEncrypt, "u$YKZx>pzrXq^HH$"));

       // System.out.println(AESAlgo.decrypt(EncyrpteDATA, "u$YKZx>pzrXq^HH$"));

//        String hashedValue = getAccountNo("676001309648");
//        System.out.println(hashedValue);
//        System.out.println(getOriginalString(hashedValue));
//        for(int i=0;i<=10;i++){
//            System.out.println(generateRandom());
//        }
//        String resBody = IsgJsonUtils.getJsonString(null);
//        String responseBody = resBody;
//        responseBody = removeQuotesAndUnescape(responseBody);
//        String[] split = responseBody.split(API_RESPONSE_SEPARATOR);
//        int status = 200;
//        String response = null;
//        if(!com.isg.mw.core.utils.StringUtils.isBlank(responseBody)){
//            status = Integer.parseInt(split[0]);
//            response = split[1];
//        }
        //02/07/2023 00:07:23
//        String input = "Hello! This is a @string with sp123ecial characters.";
//
//        // Define a regular expression pattern to match non-alphanumeric characters
//        Pattern pattern = Pattern.compile("[^a-zA-Z\\s]");
//
//        // Use a Matcher to find and replace special characters
//        Matcher matcher = pattern.matcher(input);
//        String result = matcher.replaceAll("");
//        String s = "8850889890";
//        double numericCellValue = new Double(s);
////        System.out.println(genkey());
//
//        try {
//            genJks();
//        } catch (KeyStoreException e) {
//            e.printStackTrace();
//        } catch (CertificateException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//       UpiResponse upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(getCheckVpaData().toString(),UpiResponse.class);
//        System.out.println("RESPONSE POJO :"+ upiResponse);
        ;

//         Decryptor<AES, SecretKey> decryptor;
//        decryptor = new Decryptor<AES, SecretKey>("/home/ISG/shital3986/secretkey.json");
//        System.out.println(decryptor.decrypt("01800378dad61f4d41d7775b481963488ea7ecd1005f000100156177732d63727970746f2d7075626c69632d6b657900444174507048504a4a6a49745a4e46445839354c4866304a614a4f55325a7877507a524a36777747497a494e343279502b455a35327469743077355678726e4b5843413d3d00010003495347001a736563726574000000800000000c4285587bc65537ec95ea993f00300eb5d03677b952ddaf9db597525fa76c1dcb16166d061569e93f23f709ded1f7b653937e68727ff78aa0fe7d0590725302000000000c0000100000000000000000000000000005837fb5116db608557315da0419e3f6ffffffff00000001000000000000000000000001000000107da663cf8af618e85486ff7fb48270a9065d5b1bfecfe136ebd85670230f83870067306502300c6193c4256dac4c61236b881043d50c84b526d679db946cfdace116a99819bc45771d5f09d223a133b5912144deb45b023100ed814b56ead2c1fdc69c73d03d20cd68f8b883a7ecee074d73b7a915b36d009ef481e82c1380526c5e3711b33a1a4a32"));



//        //seperate two word
//        String[] words = "".split(" ");
//
//        try {
//            System.out.println(words[0]);
//            System.out.println(words[1]);
//        }catch (ArrayIndexOutOfBoundsException e){
//            System.out.println("hii");
//        }

//        String dt = "04 / 23";
//        dt = dt.replaceAll("\\s+", "").replaceAll("\u2002","");
//        String[] split = dt.split("/");
//        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//        long minutesDifference = getMinutesDifference();
//        Object list = convertObjToList();
//        List<TransactionMessageModel> stringList = (List<TransactionMessageModel>) list;
//
//        System.out.println(stringList.get(0));
        //getLyraRes();
//        MerchantEncDataResponse txnStatusDataRes = new MerchantEncDataResponse();
//        txnStatusDataRes.setMessage("Invalid Secure Hash");
//        txnStatusDataRes.setStatus(PaymentStatus.FAILED.name());
//        System.out.println("JSON BODY::"+new JSONObject(txnStatusDataRes).toString() +"OBJECT MAPPER::"+IsgJsonUtils.getJsonString(txnStatusDataRes));

//        convertToJsonObject();
        //System.out.println(keepSpecificSpecialCharactersWithAlphaNumeric("M/S.Nilesh A"," "," "));
    //generateSecureReq();
//        String str= "1234512345-234512345-234512345";
//        //String str= "1234512345";
//        //String str= "";
//        String abc = !StringUtils.isBlank(str) ? (str.length() >=30 ? str.substring(0,30) :str) : null;
//        System.out.println(abc + ":: SIZE :: "+abc.length());


//        getLyraRes();
//        long currentTimestamp = System.currentTimeMillis() / 1000;
//
//        String authToken = generateHash("100001", "175f0289-0272-4cd2-bffa-51fc9b6c4101",
//                "100001-HDFC-2lP6tK9sB7", "HDFC5nN2pO3aR5", "f3a81ff0-e139-4e6a-8888-9709a0407713",
//                currentTimestamp);
//        System.out.println(authToken);

        //API 2
//        String tokenSecretKey = "f3a81ff0-e139-4e6a-8888-9709a0407713";
//        String iv = getRandomUuid();
//        System.out.println("iv" + iv);
//        String encryptedPayload = null;
//        try {
////             encryptedPayload = generateEncPayloadV3("Karchies Limited6", "4895380115392363", "505", "12",
////                    "2024" ,"pooja.patil@qfixinfo.com", "IN", iv, generateSecretKey(tokenSecretKey));
//             encryptedPayload = generateEncPayloadV3("Nilesh L", "2223520122351442", "000", "12",
//                    "2030" ,"N93536@isg.com", "IN", iv, generateSecretKey(tokenSecretKey));
//            System.out.println("Payload : " + encryptedPayload);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//        try {
//            String decrypt = decrypt(encryptedPayload, generateSecretKey("f3a81ff0-e139-4e6a-8888-9709a0407713"),
//                    iv.getBytes());
//            System.out.println("Decrypted Data : " + decrypt);
//        }catch (Exception e){
//            e.printStackTrace();
//        }


//        List<String> list = new ArrayList<>();
//        for(String s : list){
//            System.out.println("In FOR");
//        }

//        ResponseEntity<MapsInfoModel> result = new RestTemplate().exchange(
//                "http://192.168.83.207:8091/accesspoint-config" + "/maps/getMapInfoByKey" + "?merchantStatus=" + ActiveInactiveFlag.Active+"&key=" + "24520::10000012345::1000001",
//                HttpMethod.POST, buildHeaders(), MapsInfoModel.class);
//        if (result.getStatusCode() != HttpStatus.OK) {
//            throw new RuntimeException();
//        }
//        System.out.println(result.getBody());

//        decryptRawData();

//        compareTime();

//        ApiTxnModel apiTxnModel = new ApiTxnModel();
//        apiTxnModel.setTxnAmt("1000");
//        validatePosRefundAmt("10.00",apiTxnModel);

        if("SOUND BOX".equalsIgnoreCase("Sound Box") || "Sound Box".toUpperCase().startsWith("SOUND")) {
            System.out.println(true);
        }

    }

    public static void validatePosRefundAmt(String originalTxnAmt, ApiTxnModel apiTxnModel) {
        BigDecimal originalAmt = new BigDecimal(originalTxnAmt);
        String txnAmt = IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(apiTxnModel.getTxnAmt());
        BigDecimal refundTxnAmt = new BigDecimal(txnAmt);
        if (refundTxnAmt.compareTo(originalAmt) > 0) {
                        System.out.println("Txn amount has been exceeded, Original Txn Amt: " + originalTxnAmt + ", Dependent Txn Total Amt: "
                                + refundTxnAmt);
        }
    }

    private static void compareTime() {
        OffsetDateTime currentTime = OffsetDateTime.parse("2024-12-30T16:31:00.000000+05:30");
        System.out.println("Current : " + currentTime);
        LocalTime startTime = LocalTime.of(13, 30); // 1 PM
        LocalTime endTime = LocalTime.of(16, 0);   // 4 PM
        ZoneOffset currentOffset = currentTime.getOffset();
        OffsetDateTime startOffsetDateTime = OffsetDateTime.of(currentTime.toLocalDate(),startTime,currentOffset);
        System.out.println("startTime : " + startOffsetDateTime);
        OffsetDateTime endOffsetDateTime = OffsetDateTime.of(currentTime.toLocalDate(),endTime,currentOffset);
        System.out.println("endTime : " + endOffsetDateTime);

        // Compare the current time with the range
        if (currentTime.isAfter(startOffsetDateTime) && currentTime.isBefore(endOffsetDateTime)) {
            System.out.println("The current time is between 1:30 PM and 4 PM.");
        } else {
            System.out.println("The current time is not between 1 PM and 4 PM.");
        }
    }


    public static HttpEntity<String> buildHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return new HttpEntity<>(headers);
    }

    public static void decryptRawData(){
        String data = "01800378511a04b2d4dad638a42f6f9e2f1f8374005f000100156177732d63727970746f2d7075626c69632d6b657900444138464b4f51576d5458325031412b4f6e614c303652486e526a304c354961752b34656a3562684d6459547857714d4f44344578697642704b3978364b64677238413d3d00010003495347001a736563726574000000800000000cbb1002cf7ab5beae95d3021f00304ce577ac7002a8ae76ea27c8e25e487164bfaddfc19a4394b7f6bf3f099fa4a01c96460f7b706db4af013a69efac948f02000000000c000010000000000000000000000000003b231c047fe967f395b42669a36b9d3affffffff00000001000000000000000000000001000002f68353f30e1ed2b5d6f2307d37c35e5b8e89060c3a6be53331a1d9b035b804338433633ebc1ce73ff384f1b95bc70d48248fedb231884229a8bbb8fbf172fcd5c563f5227098bc9d0d7f6e0a32ff6525a181a936ef2dac52daef98402c43db099b19286caf51bbf648b24fdd9842495714ad1ae43446fa2aee6a52c61eec2826ff60ed492a965c1c4e5db386234e854a4ac0a980fa243215c058fe8364e9c4993159c038ad33339bf9c51038ac2e67b5abea507644a4bc3c7420154c0aa79e588dc74e0c0ee578309a1f20ed2a4615239a68d4fd6c2ef07d9fc3c3f3facc35f3f10ed650ef123708305fde554d1fd2f12c0f15a7a83e4c9e787d7f5c20b7f3d58c347596331086aafebd9850710319961e8ffaf6607b5929c3f4c20619c2191b5fdd8fb923a849804563938a6d264a3bbb5db79b7a6913fb0d51977c717ab5a5871894a68e25f7f159bc8eb867bac35c9f38761d6b53dc4ad76c21ab113ea15030d0a5271db16c5cc3aa99ba835c08b155c949c2adc03278e63aba9badaedf85d838f7bf7ab8144f70f03451b57bdf4549bdd006314a1b1f11aa4a3e9d66a9766c177b6ddb652dfb5d4fc83c3f3c5f4519b5c3de5729a0faae16d38ead0bc1a9001fec19947a275cd255f20245922f69d720e31b14d2278f46ec6c5124bcfa576e2e7d78b69947830d8214255e742f9a403cdd6dbadef3c27e70c6c078b611e908cc49f411d773ab86cd9c14aa7a37b15ec2b41aa80458fff7508eea54d680bf03fdc2e82925c7d14ec4d9be0bf2f07cab1bad80c3dd5f763c9d459cb7f1862a3a51e18f08bfab340e25d848e310aaf3edb3fac9d59edf3416a704518413b98c3655a94a196740b537c4969e2ad3d2e9e7d91a02985ced485a76a0b501ee63e0bfaa27eaf265e7bb986b3559d488308be1273097d43ff73e001a4254ab1b4b12e88e2f847ae51823cb26d26dbecbebb98d658c8fd27ceec95742a509297e0e6a8ff3d4e295027054c12863f09fb192a6e063dd5416578fafc5cbf2c5b167f49c4707c03e8b41234b0d584c3ad22f298869fe1d36ce2e4e390901979606953ef028747a7d1cd3fe0067306502301197abaf88ad82f702dad1747b5add42ff8ad4686931f0583ec99b78cda204cd8b3e9c6b36f9b6bd54e67848d2f145e0023100be245ee545510f8d99c8dc9714cd6ff0b37ab9ea07f05f600bd6264f6c063d38743c2fc31cd347e29a23ae68b1f2f6a7";
         Decryptor<AES, SecretKey> decryptor;
        String aesSecretKeyProviderPath = "/home/ISG/shital3986/Softwares/MW_SERVER/tlm/security/keyproviders/secretkey.json";

        decryptor = new Decryptor<AES, SecretKey>(aesSecretKeyProviderPath,"wBnjKRfoftKEccRnzg+qHQ9f+7/l27LErQA84VtiPSA=");
        String decrypt = decryptor.decrypt(data);
        System.out.println("Decrypted " + decrypt);
    }

    public static String decrypt(String cipherText, SecretKey key, byte[] IV) throws Exception {
        // Get Cipher Instance
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        // Create GCMParameterSpec
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, IV);
        // Initialize Cipher for DECRYPT_MODE
        cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
        // Perform Decryption
        byte[] decryptedText = cipher.doFinal(Hex.decodeHex(cipherText));
        return new String(decryptedText);
    }


    public static SecretKeySpec generateSecretKeySpec(String key){
        MessageDigest sha = null;
        SecretKeySpec secretKey = null;
        byte[] keyByte;
        try {
            keyByte = key.getBytes("UTF-8");
            sha = MessageDigest.getInstance("SHA-256");
            keyByte = sha.digest(keyByte);
            keyByte = Arrays.copyOf(keyByte, 16);
            secretKey = new SecretKeySpec(keyByte, "AES");
        } catch (NoSuchAlgorithmException e) {
        } catch (UnsupportedEncodingException e) {
        }
        return secretKey;
    }


    public static String getAccountDetails(String data, String key, byte[] IV) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException, BadPaddingException, IllegalBlockSizeException, InvalidAlgorithmParameterException {
        SecretKeySpec secretKeySpec = generateSecretKeySpec(key);
        IvParameterSpec ivSpec = new IvParameterSpec(IV);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivSpec);
        String accountDetails = new String(cipher.doFinal(java.util.Base64.getDecoder().decode(data)));
        return accountDetails;
    }

    private static SecretKey generateSecretKey(String secretKeyString) {
        secretKeyString = secretKeyString.replace("-", "");
        SecretKey secretKey = new SecretKeySpec(secretKeyString.getBytes(), 0,
                secretKeyString.length(), "AES");
        return secretKey;
    }

    private static String generateEncPayloadV3(final String customerName, final String pan,
                                               final String cvv, final String expMon, final String expYear, final String emailId,
                                               final String countryCode, final String iv, final SecretKey secretKey) throws Exception {
        final Gson gson = new Gson();
        final WibmoEncryptionDecryptionUtil encUtil = new WibmoEncryptionDecryptionUtil();
        final WibmoEncryptionDecryptionUtil.CustomerAccountDetails accDtls_GC = new WibmoEncryptionDecryptionUtil.CustomerAccountDetails();
        accDtls_GC.setCustomerName(customerName);
        accDtls_GC.setPan(pan);
        accDtls_GC.setSecurityCode(cvv);
        accDtls_GC.setExpiryMonth(expMon);
        accDtls_GC.setExpiryYear(expYear);
        accDtls_GC.setEmail(emailId);
        accDtls_GC.setCountryCode(countryCode);
        final String accDtlsJson_AmexGC = gson.toJson(accDtls_GC);
        final String encryptedPayload = encUtil.encrypt(accDtlsJson_AmexGC.getBytes(), secretKey,
                iv.getBytes());
        return encryptedPayload;
    }

    public static String generateHash(final String vaultId, final String clientId,
                                      final String apiUser, final String apiKey, final String salt, final long timestamp) {
        String digest = null;
        try {
            final String data = timestamp + "|" + vaultId + "|" + clientId + "|" + apiUser + "|"
                    + apiKey;
            System.out.println("Data: " + data);
            digest = getDigest("HmacSHA256", salt, data, false);
            digest = "wtv1:" + timestamp + ":" + digest;
        } catch (final Exception e) {
            e.printStackTrace();
        }
        return digest;
    }

    private static String getDigest(final String algorithm, final String sharedSecret,

                                    final String data, final boolean toLower) throws SignatureException {

        try {

            final Mac sha256HMAC = Mac.getInstance(algorithm);

            final SecretKeySpec secretKey = new SecretKeySpec(

                    sharedSecret.getBytes(StandardCharsets.UTF_8), algorithm);

            sha256HMAC.init(secretKey);

            final byte[] hashByte = sha256HMAC.doFinal(data.getBytes(StandardCharsets.UTF_8));

            final String hashString = toHex(hashByte);

            return toLower ? hashString.toLowerCase() : hashString;

        } catch (final Exception e) {

            throw new SignatureException(e);

        }

    }
    public static String toHex(final byte[] bytes) {

        final BigInteger bi = new BigInteger(1, bytes);

        return String.format("%0" + (bytes.length << 1) + "X", bi);

    }




    public static void  generateChecksum()
    {
        String req = "{\"uniqueId\":\"ICICI139225276321350248\",\"merchantNa\n" +
                "me\":\"M/S.TEST INSTABIZ 2\",\"merchantSector\":\"17\",\"CorporateAddress\":\"ICICI BANK LTD RD FLOOR CWIN\",\"CorporateAddressPincode\":\"400013\",\"CorporateAddressCountry\":\"INDIA\",\n" +
                "\"PurposeOfPG\":\"PG Transaction\",\"MerchantPAN\":\"ATIPK0794Q\",\"SignatoryPAN\":\"ATIPK0794Q\",\"MerchantGSTNo\":\"22AAAAA0000A1Z5\",\"ContactPerson\":\"MEHUL GALA\",\"Telepho\n" +
                "ne\":\"9167652246\",\"Email\":\"SOUBHAGYA.BEHERA@ICICIBANK.COM\",\"ExpectedNoOfTransactions\":\"101 - 500 trxn per month\",\"AverageTicketSize\":\"1001 - 5000\",\"MIDCategor\n" +
                "y\":\"TPSL Ingenico ecomsmall\",\"LegalRegisteredAddress\":\"ICICI BANK LTD RD FLOOR CWIN\",\"RegisteredAddPincode\":\"400013\",\"RegisteredAddCountry\":\"INDIA\",\"EntityTy\n" +
                "pe\":\"Society\",\"BusinessType\":\"ONLINE E COMMERCE\",\"ProductServices\":\"Product\",\"WebsiteStatus\":\"Ready\",\"TermsAndConditions\":\"Yes\",\"PrivacyPolicy\":\"Yes\",\"Refund\n" +
                "sAndCancellationPolicy\":\"Yes\",\"ContactDetailsAvailable\":\"Yes\",\"ProductDetailAndPricingStructure\":\"Yes\",\"MIDType\":\"Generic\",\"MerchantURL\":\"shop.9abc.fun\"}";

    }

    public String generateCheckSum(TpslMerchantRequestModel tpslMerchantRequestModel, String checkSumKey) {
        String reqForCheckSum = tpslMerchantRequestModel.getUniqueId() + "|" + tpslMerchantRequestModel.getMerchantName() + "|" + tpslMerchantRequestModel.getMerchantSector() + "|" + checkSumKey;
        try {
            return SHA512Utils.generateChecksum(reqForCheckSum);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static void generateSecureReq(){
//        try {
//            SecureAPIBuilder secureAPIBuilder = SecureAPIBuilder.getInstance();
//            secureAPIBuilder.setUpstreamServerDomain("https://apibankingonesandbox.icicibank.com/api/v1/tpsl/MerchantOnBoarding");
//            secureAPIBuilder.setUpstreamServerPort(443);
//            secureAPIBuilder.setAllowedTLSVersions(new String[]{"TLSv1.3", "TLSv1.2"});
//            secureAPIBuilder.setVerifyServerSSL(false);
//
//            SecureAPIConnection secureAPI = secureAPIBuilder.build(); // always reuse SecureAPIConnection object to avoid blocked by server for creating too many sessions
//            /*** *** *** Initialization complete *** *** ***/
//            String str = "{\"uniqueId\":\"ICICI139203519633330117\",\"merchantName\":\"M/S.Nilesh A\",\"merchantSector\":\"17\",\"checkSumValue\":\"2467FCE7F1FB932895E70F29CD3248D78CF4C4568D6E8B6AAF652881750D020653B6ACF99C46DDC95CCCA8FBEFA97B9989E4C3F4D964A22833C34A538D1E0048\",\"CorporateAddress\":\"TESTING ADDRESS\",\"CorporateAddressPincode\":\"486001\",\"CorporateAddressCountry\":\"INDIA\",\"PurposeOfPG\":\"Test\",\"MerchantPAN\":\"ASDFG1245P\",\"SignatoryPAN\":\"ASDFG1245P\",\"MerchantGSTNo\":\"27AABCL4084F1ZK\",\"ContactPerson\":\"shitalg\",\"Telephone\":\"9851241616\",\"Email\":\"N16136@isg.com\",\"ExpectedNoOfTransactions\":\"101 - 500 trxn per month\",\"AverageTicketSize\":\"1001 - 5000\",\"MIDCategory\":\"TPSL Ingenico ecomsmall\",\"LegalRegisteredAddress\":\"TESTING ADDRESS\",\"RegisteredAddPincode\":\"486001\",\"RegisteredAddCountry\":\"INDIA\",\"EntityType\":\"Society\",\"BusinessType\":\"AIRLINES\",\"ProductServices\":\"Product\",\"WebsiteStatus\":\"Ready\",\"TermsAndConditions\":\"Yes\",\"PrivacyPolicy\":\"Yes\",\"RefundsAndCancellationPolicy\":\"Yes\",\"ContactDetailsAvailable\":\"Yes\",\"ProductDetailAndPricingStructure\":\"Yes\",\"MIDType\":\"Generic\",\"MerchantURL\":\"www.xyz.com\"}\n";
//            // Call example API service "echo" over Secure API Connection
//            JSONObject data = new JSONObject(str);
////            data.put("data", "Hello World!");
//            String jsonStr = data.toString();
//            System.out.println("\nHTTP Request: " + jsonStr);
//
//            //APIResponse result = secureAPI.callSecureAPI(HttpMethod.POST, "/api/1/echo", data.toString());
//
//            APIResponse result = secureAPI.callSecureAPI(HttpMethod.POST, "", jsonStr);
//
//            System.out.println("\nHTTP Response Code: " + result.getResponseCode());
//            System.out.println("\nHTTP Version: " + result.getHTTPVersion());
//            System.out.println("\nHTTP Response Message: " + result.getResponseMessage());
//
//            System.out.println("\nHTTP Headers:");
//            for (Map.Entry<String, List<String>> entry : result.getHeaders().entrySet()) {
//                if (entry.getKey() == null) {
//                    System.out.println(entry.getValue().get(0));
//                    continue;
//                }
//                for (String value : entry.getValue()) {
//                    System.out.println(entry.getKey() + ": " + value);
//                }
//            }
//
//            System.out.println("\nResponse Body:\n" + result.getData().toString());
//            secureAPI.close();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
    }



    public static String keepSpecificSpecialCharacters(String inputString,String allowedCharacters){
        String regex = "[^a-zA-Z0-9" + Pattern.quote(allowedCharacters) + "]";
        // Use regular expression to remove unwanted characters
        return inputString.replaceAll(regex, "");
    }
    public static String keepSpecificSpecialCharactersWithAlphaNumeric(String inputString, String allowedCharacters,String replaceChar){
        String regex = "[^a-zA-Z0-9" + Pattern.quote(allowedCharacters) + "]";
        // Use regular expression to remove unwanted characters
        if (!com.isg.mw.core.utils.StringUtils.isBlank(inputString)) {
            return inputString.replaceAll(regex, replaceChar);
        }
        return null;
    }

    public static  void convertToJsonObject(){
        String json = "{\n" +
                "    \"statusCode\": \"00\",\n" +
                "    \"msg\": \"Refund has been initiated successfully\",\n" +
                "    \"data\": {\n" +
                "        \"RefundTxnId\": \"139183690769801836\"\n" +
                "    }\n" +
                "}";
        JSONObject jsonObject = new JSONObject(json);
        System.out.println(jsonObject.get("data"));
    }

    public static void getLyraRes(){
        String str = "{\n" +
                "    \"business\": {\n" +
                "        \"name\": \"Nilesh A\",\n" +
                "        \"dbaName\": \"Nilesh A\",\n" +
                "        \"integrationType\": \"POS\",\n" +
                "        \"dateOfEstablishment\": \"2024-01-22\",\n" +
                "        \"address\": \"Testing Address\",\n" +
                "        \"city\": \"MUMBAI\",\n" +
                "        \"state\": \"Maharashtra\",\n" +
                "        \"zipcode\": \"486001\",\n" +
                "        \"country\": \"INDIA\",\n" +
                "        \"ownership\": \"Partnership Firm\",\n" +
                "        \"salesPerson\": \"\",\n" +
                "        \"gstNo\": \"27AABCL4084F1ZK\",\n" +
                "        \"panNo\": \"ASDFG1245P\",\n" +
                "        \"mcc\": \"5399\",\n" +
                "        \"contact\": {\n" +
                "            \"name\": \"Nilesh A\",\n" +
                "            \"phone\": [\n" +
                "                \"9851583527\",\n" +
                "                \"9851583527\"\n" +
                "            ],\n" +
                "            \"email\": \"n583527@isg.com\"\n" +
                "        },\n" +
                "        \"registrationId\": \"LC0124000536\",\n" +
                "        \"websiteUrl\": \"\",\n" +
                "        \"creationDate\": \"2024-01-22T18:37:31.915243\"\n" +
                "    },\n" +
                "    \"bankDetails\": {\n" +
                "        \"ifsc\": \"ICIC0001045\",\n" +
                "        \"accountName\": \"EazypayPlus Coll AC Cards\",\n" +
                "        \"bankName\": \"ICICI\",\n" +
                "        \"accountNo\": \"075305500065\",\n" +
                "        \"accountType\": \"Current\"\n" +
                "    },\n" +
                "    \"risk\": {\n" +
                "        \"avgTicketSize\": \"5000.00\",\n" +
                "        \"txCap\": \"10000.00\",\n" +
                "        \"dailyCap\": \"500000.00\",\n" +
                "        \"dailyCount\": \"9999\"\n" +
                "    },\n" +
                "    \"pos\": [\n" +
                "        {\n" +
                "            \"terminalType\": \"\",\n" +
                "            \"terminalModel\": \"\",\n" +
                "            \"deviceSerialNo\": \"\",\n" +
                "            \"valueAddedService\": \"\",\n" +
                "            \"vpa\": \"ibkPOS.EP583527@icici\",\n" +
                "            \"mid\": \"100000000583526\",\n" +
                "            \"tid\": \"EP583527\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        LyraMerchantResponseModel object = getObjectFromJsonString(str, LyraMerchantResponseModel.class);
//        Object params = object.getPoi().getParams();
//        LyraMerchantResponseModel.Params jsonString = IsgJsonUtils.getObjectFromJsonString(params.toString(), LyraMerchantResponseModel.Params.class);
        System.out.println(object);
    }

    public static <T> T getObjectFromJsonString(String data, Class<T> valueType) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return mapper.readValue(data, valueType);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    private static Object convertObjToList(){
        List<TransactionMessageModel> list = new ArrayList<>();
        TransactionMessageModel model1 = new TransactionMessageModel();
        model1.setTransactionId("123456");
        list.add(model1);
        TransactionMessageModel model2 = new TransactionMessageModel();
        model2.setTransactionId("789456");
        list.add(model2);
        return list;
    }

    private static long getMinutesDifference() {
        OffsetDateTime parse = OffsetDateTime.parse("2023-10-10T09:10:00.920712+00:00");
        OffsetDateTime timeToGMT = convertTimeToGMT(OffsetDateTime.now().toString());
        System.out.println(timeToGMT);
        Duration duration = Duration.between(parse, timeToGMT);
        long minutesDifference = duration.toMinutes();
        return minutesDifference;
    }

    private static OffsetDateTime convertTimeToGMT(String requestReceivedTime) {
        ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(0, 0);
        OffsetDateTime dateTimeWithGMTOffset = OffsetDateTime.parse(requestReceivedTime).withOffsetSameInstant(gmtOffset);
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z");
//        System.out.println(dateTimeWithGMTOffset);
        return dateTimeWithGMTOffset;
    }

    private static OffsetDateTime convertGMTTOIST(String requestReceivedTime) {
        ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(5, 30);
        OffsetDateTime dateTimeWithGMTOffset = OffsetDateTime.parse(requestReceivedTime).withOffsetSameInstant(gmtOffset);
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z");
//        System.out.println(dateTimeWithGMTOffset);
        return dateTimeWithGMTOffset;
    }


    public static boolean compareTwoDate(){
        OffsetDateTime date = OffsetDateTime.now().minusDays(187);
        System.out.println(date);
        Duration duration = Duration.between(date,OffsetDateTime.now());
        long days = duration.toDays();
        System.out.println(days);
        if(days > 180L){
            System.out.println("Date Expired");
            return false;
        }else {
            System.out.println("Date Valid");
            return true;
        }
    }


    private static  String getRandomUuid() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().replace("-","");
    }






    public static SecretKey genkey() throws NoSuchAlgorithmException {
//        String encodeToString = "n20HaJCg5gTOTLM6tDGtnxjyWRTZt+1CE5Fj3HxQmYQ=";
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        generator.init(256); // The AES key size in number of bits
        SecretKey key1 =generator.generateKey();// Base64.getEncoder().encodeToString(generator.generateKey().getEncoded());
//        System.out.println("Secrte Key : " + encodeToString);
//        byte[] decodeKey = Base64.getDecoder().decode(encodeToString.getBytes());
//        SecretKey key1 = new SecretKeySpec(decodeKey, "AES");
        return key1;
    }

    public static void genJks() throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
        // Create a KeyStore instance
        KeyStore keyStore = KeyStore.getInstance("JCEKS");
        // Load the keystore (You can create a new keystore if it doesn't exist)
        char[] password = "".toCharArray();
        keyStore.load(null, null);
        // Get the secret key generated in Step 1
        SecretKey secretKey = genkey(); // Load your secret key here

        // Store the secret key in the keystore
        keyStore.setKeyEntry("secret", secretKey, null, null);

        // Save the keystore to a JKS file
        try (FileOutputStream fos = new FileOutputStream("/home/ISG/shital3986/tlm-secrete.jks")) {
            keyStore.store(fos, null);
        }

        try {
            Key secret = keyStore.getKey("secret", password);
            System.out.println(Base64.getEncoder().encodeToString(secret.getEncoded()));
        } catch (UnrecoverableKeyException e) {
            e.printStackTrace();
        }

//        File file = new File("/home/ISG/shital3986/aessecrete.jks");
//        KeyProvider keyProvider = KeyProviderLoader.readProvider(file);
//        keyProvider.getConfigs().put("secretKey",secretKey);
    }




    public static Object getData() throws JAXBException {
        UpiCallbackRequest upiResponse = new UpiCallbackRequest();
        upiResponse.setMessageType("0210");
        upiResponse.setProcCode("345201");
        upiResponse.setOriginalTxnId("fhhsdahfiejrejf");
        UpiCallbackRequest.Payer payer = new UpiCallbackRequest.Payer();
        payer.setAccountNo("134567");
        upiResponse.setPayer(payer);

        UpiCallbackRequest.Payee payee = new UpiCallbackRequest.Payee();
        payee.setAccountNo("134567");
        payee.setRespCode("00");
        upiResponse.setPayee(payee);
        String xml = IsgXmlUtils.convertObjectToXml(upiResponse, UpiCallbackRequest.class);
        return xml;
    }

    public static String getAmountStr(String amount, int length) {
        String amt = "00";
        if (!StringUtils.isBlank(amount)) {
            amt = amount;
        }
        return getFixedLengthData(amt, true, '0', length);
    }

    public static String getFixedLengthData(String data, boolean prefix, char fixStr, int length) {

        String ppStr = EMPTY_STR;
        String localdata = data;
        int dl = 0;
        if (data != null) {
            dl = data.length();
            if (dl > length) {

            }
        } else {
            localdata = EMPTY_STR;
        }
        for (int i = 0; i < length - dl; i++) {
            ppStr += fixStr;
        }
        if (prefix == true) {
            return ppStr + localdata;
        } else {
            return localdata + ppStr;
        }

    }



    private static String generateRandomForFile() {
        String format = String.format("%012d", new BigInteger(UUID.randomUUID().toString().replace("-", ""), 16));
        format = format.substring(format.length() - 12);
        return format;
    }

    // Method to convert MD5 digest to original string
    private static String getOriginalString(String md5Digest) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digestBytes = hexStringToByteArray(md5Digest);
            byte[] originalBytes = md.digest(digestBytes);
            return new String(originalBytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Helper method to convert a hexadecimal string to a byte array
    private static byte[] hexStringToByteArray(String hexString) {
        int len = hexString.length();
        byte[] byteArray = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            byteArray[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
                    + Character.digit(hexString.charAt(i + 1), 16));
        }
        return byteArray;
    }

    public static OffsetDateTime trimGmtDate(String input) {
        OffsetDateTime output = null;
        if (input != null && !input.equals("")) {
            try {
                ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(0, 0);
                OffsetDateTime parse = OffsetDateTime.parse(input.trim(), DateTimeFormatter.ISO_DATE_TIME);
                return parse.withOffsetSameInstant(gmtOffset);
            } catch (Exception ex) {
            }
        }
        return output;
    }

}
