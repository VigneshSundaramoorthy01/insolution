package com.isg.mw.poc.bean;

import java.io.IOException;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.mtm.parser.msg.Iso8583Message;

@Component
public class TransactionRequestRouteService {

	public void validateMsg(Exchange exchange) {

		String msg = exchange.getIn().getBody(String.class);
		// msg = msg.trim().replace(" ", "");

		if (msg == null || msg.trim().isEmpty()) {
			// stopping the further route processing, since msg is null
			exchange.setException(new ValidationException("Message is empty"));
			exchange.setProperty(Exchange.ROUTE_STOP, Boolean.TRUE);
		}
		exchange.getIn().setBody(msg);
	}

	public Iso8583Message toISO8583Object(String body) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		Iso8583Message trModel = null;
		try {
			trModel = objectMapper.readValue(body, Iso8583Message.class);
		} catch (IOException e) {
			throw new IOException(e.getMessage());
		}
		return trModel;
	}

}
