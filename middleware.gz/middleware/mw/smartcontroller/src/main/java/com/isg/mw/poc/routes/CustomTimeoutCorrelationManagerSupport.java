package com.isg.mw.poc.routes;

import org.apache.camel.component.netty.TimeoutCorrelationManagerSupport;

public class CustomTimeoutCorrelationManagerSupport extends TimeoutCorrelationManagerSupport {

	@Override
	public String getRequestCorrelationId(Object request) {
		return String.valueOf(System.currentTimeMillis());
	}

	@Override
	public String getResponseCorrelationId(Object response) {
		return null;
	}

}
