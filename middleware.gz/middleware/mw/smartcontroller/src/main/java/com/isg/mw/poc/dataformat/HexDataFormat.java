package com.isg.mw.poc.dataformat;

import java.io.InputStream;
import java.io.OutputStream;

import org.apache.camel.Exchange;
import org.apache.camel.spi.DataFormat;

public class HexDataFormat implements DataFormat {

	@Override
	public void start() {
	}

	@Override
	public void stop() {
	}

	@Override
	public void marshal(Exchange exchange, Object graph, OutputStream stream) throws Exception {
	}

	@Override
	public Object unmarshal(Exchange exchange, InputStream stream) throws Exception {
		int read;
		StringBuilder finalTxnString = new StringBuilder();
		while ((read = stream.read()) != -1) {
			finalTxnString.append(prefixZero(read) + "");
		}
		exchange.getIn().setBody(finalTxnString.toString());
		return finalTxnString.toString();
	}
	
	private String prefixZero(int data) {
		String hexString = Integer.toHexString(data);
		if (hexString.length() == 1) {
			hexString = "0" + hexString;
		}
		return hexString;
	}

}
