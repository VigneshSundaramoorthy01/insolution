package com.isg.mw.init;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.md.CountryInfoModel;
import com.isg.mw.core.model.md.CurrencyInfoModel;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;

//@RunWith(MockitoJUnitRunner.class)
public class InitRestClientImplTest {
	/*
	 * @Mock private InitProps initProps;
	 * 
	 * @Mock private ResponseEntity<SourceConfigModel[]> result;
	 * 
	 * @Mock private RestTemplate restTemplate;
	 * 
	 * @InjectMocks private InitRestClientImpl initRestClientImpl;
	 * 
	 * @Before public void init() { MockitoAnnotations.initMocks(this); }
	 * 
	 * @Test public void getSourceConfigsTest_Status_Is_OK() {
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getConfigSourceUri()).thenReturn("/source/getallactive");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigSourceUri(), HttpMethod.GET, buildHeaders(),
	 * SourceConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<SourceConfigModel[]>(getSourcArray(), HttpStatus.OK));
	 * List<SourceConfigModel> sourceConfigs =
	 * initRestClientImpl.getSourceConfigs(); assertNotNull(sourceConfigs); }
	 * 
	 * @Test public void getSourceConfigsTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getConfigSourceUri()).thenReturn("/source/getallactive");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigSourceUri(), HttpMethod.GET, buildHeaders(),
	 * SourceConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<SourceConfigModel[]>(getSourcArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getSourceConfigs(); }
	 * catch (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getTargetConfigsTest_Status_Is_OK() {
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * TargetConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<TargetConfigModel[]>(getTargetArray(), HttpStatus.OK));
	 * List<TargetConfigModel> targetConfig = initRestClientImpl.getTargetConfigs();
	 * assertNotNull(targetConfig); }
	 * 
	 * @Test public void getTargetConfigsTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * TargetConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<TargetConfigModel[]>(getTargetArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getTargetConfigs(); }
	 * catch (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getRouteDefConfigsTest_Status_Is_OK() {
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * MessageTransformationConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<MessageTransformationConfigModel[]>(
	 * getRouteDefinitionConfigArray(), HttpStatus.OK));
	 * List<MessageTransformationConfigModel> targetConfig =
	 * initRestClientImpl.getMessageTransformationConfigs();
	 * assertNotNull(targetConfig); }
	 * 
	 * @Test public void getRouteDefConfigsTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * MessageTransformationConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<MessageTransformationConfigModel[]>(
	 * getRouteDefinitionConfigArray(), HttpStatus.BAD_REQUEST)); try {
	 * initRestClientImpl.getMessageTransformationConfigs(); } catch
	 * (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getDstmConfigsTest_Status_Is_OK() {
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * HsmConfigModel[].class)) .thenReturn(new
	 * ResponseEntity<HsmConfigModel[]>(getHsmConfigModelArray(), HttpStatus.OK));
	 * List<HsmConfigModel> targetConfig = initRestClientImpl.getDstmConfigs();
	 * assertNotNull(targetConfig); }
	 * 
	 * @Test public void getDstmConfigsTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * HsmConfigModel[].class)).thenReturn( new
	 * ResponseEntity<HsmConfigModel[]>(getHsmConfigModelArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getDstmConfigs(); } catch
	 * (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getBinInfosTest_Status_Is_OK() {
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * BinInfoModel[].class)) .thenReturn(new
	 * ResponseEntity<BinInfoModel[]>(getBinInfoModelArray(), HttpStatus.OK));
	 * List<BinInfoModel> targetConfig = initRestClientImpl.getBinInfos();
	 * assertNotNull(targetConfig); }
	 * 
	 * @Test public void getBinInfosTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * BinInfoModel[].class)) .thenReturn(new
	 * ResponseEntity<BinInfoModel[]>(getBinInfoModelArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getBinInfos(); } catch
	 * (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getMapsInfosTest_Status_Is_OK() {
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * MapsInfoModel[].class)) .thenReturn(new
	 * ResponseEntity<MapsInfoModel[]>(getMapsInfoModelArray(), HttpStatus.OK));
	 * List<MapsInfoModel> targetConfig = initRestClientImpl.getMapsInfos();
	 * assertNotNull(targetConfig); }
	 * 
	 * @Test public void getMapsInfosTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getConfigServer()).thenReturn(
	 * "http://192.168.83.205:8081/accesspoint-config");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getConfigServer() +
	 * initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
	 * MapsInfoModel[].class)).thenReturn( new
	 * ResponseEntity<MapsInfoModel[]>(getMapsInfoModelArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getMapsInfos(); } catch
	 * (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getCountriesTest_Status_Is_OK() {
	 * when(initProps.getMasterServer()).thenReturn("http://192.168.83.205:8081");
	 * when(initProps.getMasterCountriesUri()).thenReturn("/countries");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getMasterServer() +
	 * initProps.getMasterCountriesUri(), HttpMethod.GET, buildHeaders(),
	 * CountryInfoModel[].class)) .thenReturn(new
	 * ResponseEntity<CountryInfoModel[]>(getCountryInfoModelArray(),
	 * HttpStatus.OK)); List<CountryInfoModel> targetConfig =
	 * initRestClientImpl.getCountries(); assertNotNull(targetConfig); }
	 * 
	 * @Test public void getCountriesTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getMasterServer()).thenReturn("http://192.168.83.205:8081");
	 * when(initProps.getMasterCountriesUri()).thenReturn("/countries");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getMasterServer() +
	 * initProps.getMasterCountriesUri(), HttpMethod.GET, buildHeaders(),
	 * CountryInfoModel[].class)).thenReturn( new
	 * ResponseEntity<CountryInfoModel[]>(getCountryInfoModelArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getCountries(); } catch
	 * (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * @Test public void getCurrenciesTest_Status_Is_OK() {
	 * when(initProps.getMasterServer()).thenReturn("http://192.168.83.205:8081");
	 * when(initProps.getMasterCurrenciesUri()).thenReturn("/currencies");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getMasterServer() +
	 * initProps.getMasterCurrenciesUri(), HttpMethod.GET, buildHeaders(),
	 * CurrencyInfoModel[].class)).thenReturn( new
	 * ResponseEntity<CurrencyInfoModel[]>(getCurrencyInfoModelArray(),
	 * HttpStatus.OK)); List<CurrencyInfoModel> targetConfig =
	 * initRestClientImpl.getCurrencies(); assertNotNull(targetConfig); }
	 * 
	 * @Test public void getCurrenciesTest_Status_Not_OK() { String msg = null;
	 * when(initProps.getMasterServer()).thenReturn("http://192.168.83.205:8081");
	 * when(initProps.getApplicstionInstnce()).thenReturn("devinstance1");
	 * when(restTemplate.exchange(initProps.getMasterServer() +
	 * initProps.getMasterCountriesUri(), HttpMethod.GET, buildHeaders(),
	 * CurrencyInfoModel[].class)).thenReturn( new
	 * ResponseEntity<CurrencyInfoModel[]>(getCurrencyInfoModelArray(),
	 * HttpStatus.BAD_REQUEST)); try { initRestClientImpl.getCurrencies(); } catch
	 * (RuntimeException e) { msg = e.getMessage(); } assertNull(msg); }
	 * 
	 * private CurrencyInfoModel[] getCurrencyInfoModelArray() { CurrencyInfoModel[]
	 * currencyInfoModelArray = new CurrencyInfoModel[2]; currencyInfoModelArray[0]
	 * = getCurrencyInfoModel(); return currencyInfoModelArray; }
	 * 
	 * private CurrencyInfoModel getCurrencyInfoModel() { CurrencyInfoModel
	 * CurrencyInfoModel = new CurrencyInfoModel();
	 * CurrencyInfoModel.setCurrencyCode("356"); return CurrencyInfoModel; }
	 * 
	 * private CountryInfoModel[] getCountryInfoModelArray() { CountryInfoModel[]
	 * countryInfoModelArray = new CountryInfoModel[2]; countryInfoModelArray[0] =
	 * getCountryInfoModel(); return countryInfoModelArray; }
	 * 
	 * private CountryInfoModel getCountryInfoModel() { CountryInfoModel
	 * countryInfoModel = new CountryInfoModel();
	 * countryInfoModel.setCountryCode("356"); return countryInfoModel; }
	 * 
	 * private MapsInfoModel[] getMapsInfoModelArray() { MapsInfoModel[]
	 * mapsInfoModelArray = new MapsInfoModel[2]; mapsInfoModelArray[0] =
	 * getMapsInfoModel(); return mapsInfoModelArray; }
	 * 
	 * private MapsInfoModel getMapsInfoModel() { MapsInfoModel mapsInfoModel = new
	 * MapsInfoModel(); mapsInfoModel.setAcquirerCurrencyCode("356"); return
	 * mapsInfoModel; }
	 * 
	 * private BinInfoModel[] getBinInfoModelArray() { BinInfoModel[]
	 * binInfoModelArray = new BinInfoModel[2]; binInfoModelArray[0] =
	 * getBinInfoModel(); return binInfoModelArray; }
	 * 
	 * private BinInfoModel getBinInfoModel() { BinInfoModel binInfoModel = new
	 * BinInfoModel(); binInfoModel.setActiveFlag(ActiveFlag.N); return
	 * binInfoModel; }
	 * 
	 * private HsmConfigModel[] getHsmConfigModelArray() { HsmConfigModel[]
	 * hsmConfigModelArray = new HsmConfigModel[2]; hsmConfigModelArray[0] =
	 * getHsmConfigModel(); return hsmConfigModelArray; }
	 * 
	 * private HsmConfigModel getHsmConfigModel() { HsmConfigModel hsmConfigModel =
	 * new HsmConfigModel(); hsmConfigModel.setEntityId("isg"); return
	 * hsmConfigModel; }
	 * 
	 * private MessageTransformationConfigModel[] getRouteDefinitionConfigArray() {
	 * MessageTransformationConfigModel[] MessageTransformationConfigModelArray =
	 * new MessageTransformationConfigModel[2];
	 * MessageTransformationConfigModelArray[0] =
	 * getMessageTransformationConfigModel(); return
	 * MessageTransformationConfigModelArray; }
	 * 
	 * private MessageTransformationConfigModel
	 * getMessageTransformationConfigModel() { MessageTransformationConfigModel
	 * MessageTransformationConfigModel = new MessageTransformationConfigModel();
	 * MessageTransformationConfigModel.setEntityId("isg"); return
	 * MessageTransformationConfigModel; }
	 * 
	 * private SourceConfigModel[] getSourcArray() { SourceConfigModel[]
	 * sourceConfigModelArray = new SourceConfigModel[2]; sourceConfigModelArray[0]
	 * = getSourceConfigModel(); return sourceConfigModelArray; }
	 * 
	 * private SourceConfigModel getSourceConfigModel() { SourceConfigModel
	 * sourceConfigModel = new SourceConfigModel();
	 * sourceConfigModel.setCapStatus(ActiveInactiveFlag.Active); return
	 * sourceConfigModel; }
	 * 
	 * private TargetConfigModel[] getTargetArray() { TargetConfigModel[]
	 * targetConfigModelArray = new TargetConfigModel[2]; targetConfigModelArray[0]
	 * = getTargetConfigModel(); return targetConfigModelArray; }
	 * 
	 * private TargetConfigModel getTargetConfigModel() { TargetConfigModel
	 * targetConfigModel = new TargetConfigModel();
	 * targetConfigModel.setEntityId("isg"); return targetConfigModel; }
	 * 
	 * private HttpEntity<String> buildHeaders() {
	 * 
	 * HttpHeaders headers = new HttpHeaders();
	 * headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	 * headers.add("instancename", initProps.getApplicstionInstnce()); return new
	 * HttpEntity<String>(headers);
	 * 
	 * }
	 */

}
