package com.isg.mw.init;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import com.isg.mw.cache.mgmt.init.MwRestTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

public class MwRestTemplateTest {

	@Mock
	private RestTemplateBuilder builder;
	
	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private MwRestTemplate mwRestTemplate;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(mwRestTemplate, "connectionTimeout", new Integer("15000"));
		ReflectionTestUtils.setField(mwRestTemplate, "readTimeout", new Integer("1000"));
	}

	@Test
	public void restTemplateTest() {
		when(builder.build()).thenReturn(restTemplate);
		when(builder.setReadTimeout(Mockito.any())).thenReturn(builder);
		when(builder.setConnectTimeout(Mockito.any())).thenReturn(builder);
		RestTemplate restTemplateObj = mwRestTemplate.restTemplate(builder);
		assertNotNull(restTemplateObj);
	}
}
