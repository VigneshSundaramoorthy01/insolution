//package com.isg.mw.init;
//
//import static org.junit.Assert.assertEquals;
//
//import com.isg.mw.cache.mgmt.init.InitProps;
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.InjectMocks;
//import org.mockito.MockitoAnnotations;
//
//public class InitPropsTest {
//	@InjectMocks
//	private InitProps initProps;
//
//	@Before
//	public void init() {
//		MockitoAnnotations.initMocks(this);
//	}
//
//	@Test
//	public void configServerTest() {
//		initProps.setConfigServer("http://192.168.83.205:8081/accesspoint-config");
//		assertEquals("http://192.168.83.205:8081/accesspoint-config", initProps.getConfigServer());
//	}
//
//
//	@Test
//	public void configSourceUriTest() {
//		initProps.setConfigSourceUri("/source/getallactive");
//		assertEquals("/source/getallactive", initProps.getConfigSourceUri());
//	}
//
//	@Test
//	public void configTargetUriTest() {
//		initProps.setConfigTargetUri("/target/getallactive");
//		assertEquals("/target/getallactive", initProps.getConfigTargetUri());
//	}
//	@Test
//	public void configRouteDefUriTest() {
//		initProps.setConfigRouteDefUri("/rd/getallactive");
//		assertEquals("/rd/getallactive", initProps.getConfigRouteDefUri());
//	}
//
//	@Test
//	public void configDstmUriTest() {
//		initProps.setConfigDstmUri("/hsm/getallactive");
//		assertEquals("/hsm/getallactive", initProps.getConfigDstmUri());
//	}
//	@Test
//	public void configBinsUriTest() {
//		initProps.setConfigBinsUri("/bin/allbins");
//		assertEquals("/bin/allbins", initProps.getConfigBinsUri());
//	}
//	@Test
//	public void configMapsUriTest() {
//		initProps.setConfigMapsUri("maps/allmaps");
//		assertEquals("maps/allmaps", initProps.getConfigMapsUri());
//	}
//	@Test
//	public void configOnusUriTest() {
//		initProps.setConfigOnusUri("/allbos");
//		assertEquals("/allbos", initProps.getConfigOnusUri());
//	}
//
//	@Test
//	public void restConnectionTimeoutTest() {
//		initProps.setRestConnectionTimeout("1500");
//		assertEquals("1500", initProps.getRestConnectionTimeout());
//	}
//	@Test
//	public void restReadTimeoutTest() {
//		initProps.setRestReadTimeout("1000");
//		assertEquals("1000", initProps.getRestReadTimeout());
//	}
//	@Test
//	public void applicstionInstnceTest() {
//		initProps.setApplicstionInstnce("evinstance1");
//		assertEquals("evinstance1", initProps.getApplicstionInstnce());
//	}
//	@Test
//	public void masterServerTest() {
//		initProps.setMasterServer("http://192.168.83.205:8081");
//		assertEquals("http://192.168.83.205:8081", initProps.getMasterServer());
//	}
//	@Test
//	public void masterCountriesUriTest() {
//		initProps.setMasterCountriesUri("/countries");
//		assertEquals("/countries", initProps.getMasterCountriesUri());
//	}
//
//	@Test
//	public void masterCurrenciesUriTest() {
//		initProps.setMasterCurrenciesUri("/currencies");
//		assertEquals("/currencies", initProps.getMasterCurrenciesUri());
//	}
//
//
//
//
//
//}
