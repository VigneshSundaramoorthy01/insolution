package com.isg.mw.poc.codec;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;

public class BinaryFileDecoderTest {

	@InjectMocks
	private BinaryFileDecoder binaryFileDecoder;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void decodeTest() throws Exception {
		String str = null;
		ChannelHandlerContext ctx =mock(ChannelHandlerContext.class);
		ByteBuf msg = mock(ByteBuf.class);
		List<Object> out = new ArrayList<Object>();
		when(msg.isReadable()).thenReturn(true);
		when(msg.readableBytes()).thenReturn(100);
		try {
			binaryFileDecoder.decode(ctx, msg, out);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	@Test
	public void decodeTest_Else() throws Exception { 
		String str = null;
		ChannelHandlerContext ctx =mock(ChannelHandlerContext.class);
		ByteBuf msg = mock(ByteBuf.class);
		List<Object> out = new ArrayList<Object>();
		when(msg.readableBytes()).thenReturn(100);
		try {
			binaryFileDecoder.decode(ctx, msg, out);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	@Test
	public void decodeTest_Exception() throws Exception { 
		String str = null;
		ChannelHandlerContext ctx =mock(ChannelHandlerContext.class);
		ByteBuf msg = mock(ByteBuf.class);
		try {
			binaryFileDecoder.decode(ctx, msg, null);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
}
