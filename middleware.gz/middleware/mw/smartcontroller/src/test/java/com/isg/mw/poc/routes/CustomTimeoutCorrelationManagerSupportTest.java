package com.isg.mw.poc.routes;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public  class CustomTimeoutCorrelationManagerSupportTest {
	
	@InjectMocks
	private CustomTimeoutCorrelationManagerSupport customTimeoutCorrelationManagerSupport;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void getRequestCorrelationIdTest() {
		Object request = mock(Object.class);
		String requestCorrelationId = customTimeoutCorrelationManagerSupport.getRequestCorrelationId(request);
		assertNotNull(requestCorrelationId);
	}
	
	@Test
	public void getResponseCorrelationIdTest() {
		Object request = mock(Object.class);
		String requestCorrelationId = customTimeoutCorrelationManagerSupport.getResponseCorrelationId(request);
		assertNull(requestCorrelationId);
	}
	

}
