package com.isg.mw.poc.codec;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import io.netty.channel.ChannelHandlerContext;

public class BinaryFileEncoderTest {
	@InjectMocks
	private BinaryFileEncoder binaryFileEncoder;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void encodeTest() throws Exception {
		String str = null;
		ChannelHandlerContext ctx = mock(ChannelHandlerContext.class);
		List<Object> out = new ArrayList<Object>();
		try {
			binaryFileEncoder.encode(ctx, "message", out);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

}
