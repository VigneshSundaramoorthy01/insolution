package com.isg.mw.poc.util;

import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class UtilTest {
	
	@InjectMocks
	private Util util;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void formatDateTest() {
		LocalDateTime rightNow = LocalDateTime.now();
		String formatDate = Util.formatDate(rightNow, "YY-MM-dd");
		assertNotNull(formatDate);
	}
}
