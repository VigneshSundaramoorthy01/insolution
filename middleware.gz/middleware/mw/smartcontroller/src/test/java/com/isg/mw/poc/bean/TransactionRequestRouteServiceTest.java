package com.isg.mw.poc.bean;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.math.BigInteger;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.jpos.iso.ISOException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.mtm.parser.msg.Iso8583Message;

public class TransactionRequestRouteServiceTest {

	@Mock
	private Message message;

	@InjectMocks
	private TransactionRequestRouteService transactionRequestRouteService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void validateMsgTest_Msg_Not_Null() {
		Exchange ex = mock(Exchange.class);
		String str = null;
		when(ex.getIn()).thenReturn(message);
		try {
			transactionRequestRouteService.validateMsg(ex);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void validateMsgTest_Msg_Null() {
		Exchange ex = mock(Exchange.class);
		String str = null;
		when(ex.getIn()).thenReturn(null);
		try {
			transactionRequestRouteService.validateMsg(ex);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void toISO8583ObjectTest_Exception() throws IOException, ISOException {
		ObjectMapper obj = new ObjectMapper();
		String str = null;
		Iso8583Message iso8583Object = null;
		String writeValueAsString = obj.writeValueAsString(getBinInfoModel());
		try {
			iso8583Object = transactionRequestRouteService.toISO8583Object(writeValueAsString);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(iso8583Object);
		assertNotNull(str);
	}

	private BinInfoModel getBinInfoModel() {
		BinInfoModel binInfo = new BinInfoModel();
		binInfo.setSchemeName("VISA");
		binInfo.setBinNumber(new BigInteger("452811"));
		binInfo.setBinLow(new BigInteger("800000000"));
		binInfo.setBinHigh(new BigInteger("900000000"));
		return binInfo;
	}
}
