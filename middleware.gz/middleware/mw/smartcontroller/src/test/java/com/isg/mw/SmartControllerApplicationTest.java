package com.isg.mw;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

public class SmartControllerApplicationTest {

	@InjectMocks
	private SmartControllerApplication smartControllerApplication;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void rmainTest() {
		String str =null;
		String [] args = { "one", "two", "three" };
		try {
			SmartControllerApplication.main(args);
		} catch (Exception e) {
			str = e.getMessage();
			e.printStackTrace();
		}
		assertNotNull(str);
	}
	
}
