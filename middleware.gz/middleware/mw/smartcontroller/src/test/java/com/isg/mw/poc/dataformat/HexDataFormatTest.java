package com.isg.mw.poc.dataformat;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class HexDataFormatTest {

	private String msgFormat;

	@Mock
	private Message message;

	@InjectMocks
	private HexDataFormat hexDataFormat;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void unmarshalTest() throws Exception {
		ClassLoader classLoader = this.getClass().getClassLoader();
        File file = new File(classLoader.getResource("oldMessageFormat.xml").getFile());
       String msgFormat = FileUtils.readFileToString(file);
		InputStream msgFormatStream = new ByteArrayInputStream(msgFormat.getBytes());
		Exchange ex = mock(Exchange.class);
		Message in = mock(Message.class);
		when(ex.getIn()).thenReturn(in);
		Object unmarshal = hexDataFormat.unmarshal(ex, msgFormatStream);
		assertNotNull(unmarshal);
	}

	@Test
	public void startTest() {
		String str = null;
		try {
			hexDataFormat.start();
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void stopTest() {
		String str = null;
		try {
			hexDataFormat.stop();
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void marshalTest() {
		Exchange exchange = mock(Exchange.class);
		Object graph = mock(Object.class);
		OutputStream stream = mock(OutputStream.class);
		String str = null;
		try {
			hexDataFormat.marshal(exchange, graph, stream);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

}
