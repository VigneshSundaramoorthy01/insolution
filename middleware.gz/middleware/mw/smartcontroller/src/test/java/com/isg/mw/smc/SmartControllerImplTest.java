package com.isg.mw.smc;

import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mf.BusinessRule;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.mt.MessageDefinition;
import com.isg.mw.core.model.mt.MessageMappingDefinition;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.routing.config.RoutingProperties;
import com.isg.mw.routing.context.RoutingInitializationContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

//@RunWith(SpringJUnit4ClassRunner.class)
public class SmartControllerImplTest {

	@Mock
	private HsmCommonService hsmCommonService;

	@Mock
	private CacheServices cacheServices;

	@Mock
	private InitRestClient initRestClient;

	@Mock
	private RoutingInitializationContext routingInitializationContext;
	

	@Mock
	private RoutingProperties routingProperties;
	

	@InjectMocks
	private SmartControllerImpl smartControllerImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	/*
	 * @Test public void afterPropertiesSetTest() throws Exception { String str =
	 * null; when(initRestClient.getTargetConfigs()).thenReturn(getTargets());
	 * when(initRestClient.getSourceConfigs()).thenReturn(getSources());
	 * when(initRestClient.getMessageTransformationConfigs()).thenReturn(getRoutes()
	 * ); when(initRestClient.getBinInfos(10,10)).thenReturn(getBinInfos());
	 * when(initRestClient.getMapsInfos(10,10)).thenReturn(getMapsInfos());
	 * when(initRestClient.getDstmConfigs()).thenReturn(getDstmConfigs()); try {
	 * smartControllerImpl.afterPropertiesSet(); } catch (Exception e) { str =
	 * e.getMessage(); } assertNull(str);
	 * 
	 * }
	 */

	/*
	 * @Test public void afterPropertiesSetTest_Dstm_Null() throws Exception {
	 * String str = null;
	 * when(initRestClient.getTargetConfigs()).thenReturn(getTargets());
	 * when(initRestClient.getSourceConfigs()).thenReturn(getSources());
	 * when(initRestClient.getMessageTransformationConfigs()).thenReturn(getRoutes()
	 * ); when(initRestClient.getBinInfos(10,10)).thenReturn(getBinInfos());
	 * when(initRestClient.getMapsInfos(10,10)).thenReturn(getMapsInfos());
	 * when(initRestClient.getDstmConfigs()).thenReturn(null); try {
	 * smartControllerImpl.afterPropertiesSet(); } catch (Exception e) { str =
	 * e.getMessage(); } assertNull(str); }
	 */

	/*
	 * @Test public void afterPropertiesSetTest_Dstm_Empty() throws Exception {
	 * String str = null;
	 * when(initRestClient.getTargetConfigs()).thenReturn(getTargets());
	 * when(initRestClient.getSourceConfigs()).thenReturn(getSources());
	 * when(initRestClient.getMessageTransformationConfigs()).thenReturn(getRoutes()
	 * ); when(initRestClient.getBinInfos(10,10)).thenReturn(getBinInfos());
	 * when(initRestClient.getMapsInfos(10,10)).thenReturn(getMapsInfos());
	 * when(initRestClient.getDstmConfigs()).thenReturn(new ArrayList<>()); try {
	 * smartControllerImpl.afterPropertiesSet(); } catch (Exception e) { str =
	 * e.getMessage(); } assertNull(str); }
	 */

	private List<TargetConfigModel> getTargets() {
		List<TargetConfigModel> targets = new ArrayList<>();
		TargetConfigModel targetConfigModel = new TargetConfigModel();
		targetConfigModel.setEntityId("isg");
		targetConfigModel.setName("Visa.Kotak");
		targetConfigModel.setMessageFormats(getMessageFormatConfigModel());
		targetConfigModel.setTargetType(TargetType.Pos);
		targetConfigModel.setPinTranslationType(PinTranslationType.DYNAMIC);
		targetConfigModel.setConnections(getTargetConnectionList());
		targetConfigModel.setSignonRequired(Boolean.TRUE);
		targets.add(targetConfigModel);
		return targets;
	}

	private List<TargetConnection> getTargetConnectionList() {
		List<TargetConnection> connections = new ArrayList<>();
		TargetConnection targetConnection = new TargetConnection();
		targetConnection.setUrlOrIp("192.168.83.63");
		targetConnection.setPortOrHeaders("8000");
		targetConnection.setType(ConnectionType.ISO);
		connections.add(targetConnection);
		return connections;
	}

	private List<SourceConfigModel> getSources() {
		List<SourceConfigModel> sources = new ArrayList<>();
		SourceConfigModel sourceConfigModel = new SourceConfigModel();
		sourceConfigModel.setEntityId("isg");
		sourceConfigModel.setMessageFormats(getMessageFormatConfigModel());
		sourceConfigModel.setName("Visa.Kotak");
		sourceConfigModel.setSourceType(TargetType.Pos);
		sources.add(sourceConfigModel);

		return sources;
	}

	private List<MessageFormatConfigModel> getMessageFormatConfigModel() {
		List<MessageFormatConfigModel> configModels = new ArrayList<>();
		MessageFormatConfigModel model = new MessageFormatConfigModel();
		model.setMsgType("0000");
		model.setBusinessRule(getBusinessRule());
		model.setMsgFormat(getMessageFormat());
		MessageFormatConfigModel model2 = new MessageFormatConfigModel();
		model2.setMsgType("0200");
		model2.setBusinessRule(getBusinessRule());
		model2.setMsgFormat("0200");
		configModels.add(model);
		configModels.add(model2);
		return configModels;
	}

	private BusinessRule getBusinessRule() {
		BusinessRule businessRule = new BusinessRule();
		businessRule.setClassName("com.isg.mw.mtm.transform.pos.PosMessageTransformation");
		businessRule.setMethodName("getSwitchToSchemePurchaseRequest");
		return businessRule;
	}

	private List<MessageTransformationConfigModel> getRoutes() {
		List<MessageTransformationConfigModel> routes = new ArrayList<>();
		MessageTransformationConfigModel MessageTransformationConfigModel = new MessageTransformationConfigModel();
		MessageTransformationConfigModel.setEntityId("isg");
		MessageTransformationConfigModel.setName("Visa.Kotak");
		List<MessageMappingDefinition> messageMappingDefinitions = new ArrayList<>();
		MessageMappingDefinition messageMappingDefinition = new MessageMappingDefinition();
		messageMappingDefinition.setDest(getMessageDefinition());
		messageMappingDefinition.setSrc(getMessageDefinition());
		messageMappingDefinition.setName("Visa.Kotak");
		messageMappingDefinitions.add(messageMappingDefinition);
		MessageTransformationConfigModel.setRules(messageMappingDefinitions);
		routes.add(MessageTransformationConfigModel);
		return routes;
	}

	private MessageDefinition getMessageDefinition() {
		MessageDefinition messageDefinition = new MessageDefinition();
		messageDefinition.setMsgType("0200");
		messageDefinition.setMsgTypeId("000000");
		messageDefinition.setTargetType(TargetType.Pos);
		return messageDefinition;
	}

	private List<BinInfoModel> getBinInfos() {
		List<BinInfoModel> binInfoModelList = new ArrayList<>();
		BinInfoModel binInfoModel = new BinInfoModel();
		binInfoModel.setActiveFlag(ActiveFlag.N);
		binInfoModelList.add(binInfoModel);
		return binInfoModelList;
	}

	private List<MapsInfoModel> getMapsInfos() {
		List<MapsInfoModel> mapsInfoModelList = new ArrayList<>();
		MapsInfoModel mapsInfoModel = new MapsInfoModel();
		mapsInfoModel.setEntityId("isg");
		mapsInfoModelList.add(mapsInfoModel);
		return mapsInfoModelList;
	}

	private List<HsmConfigModel> getDstmConfigs() {
		List<HsmConfigModel> hsmConfigModelList = new ArrayList<>();
		HsmConfigModel hsmConfigModel = new HsmConfigModel();
		hsmConfigModel.setEntityId("isg");
		hsmConfigModelList.add(hsmConfigModel);
		return hsmConfigModelList;
	}

	private String getMessageFormat() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" + "<!DOCTYPE isopackager PUBLIC\n"
				+ "        \"-//jPOS/jPOS Generic Packager DTD 1.0//EN\"\n"
				+ "        \"http://jpos.org/dtd/generic-packager-1.0.dtd\">\n" + "\n"
				+ "<!-- Master's Base field descriptions for GenericPackager -->\n" + "\n"
				+ "<isopackager headerLength=\"2\">\n" + "  <isofield\n" + "      id=\"0\"\n" + "      length=\"4\"\n"
				+ "      name=\"MESSAGE TYPE INDICATOR\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"1\"\n"
				+ "      length=\"16\"\n" + "      name=\"BIT MAP\"\n" + "      class=\"org.jpos.iso.IFB_BITMAP\"/>\n"
				+ "  <isofield\n" + "      id=\"2\"\n" + "      length=\"19\"\n"
				+ "      name=\"Primary Account Number (PAN)\"\n" + "      class=\"org.jpos.iso.IFE_LLNUM\"/>\n"
				+ "  <isofield\n" + "      id=\"3\"\n" + "      length=\"6\"\n" + "      name=\"Processing Code\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"4\"\n" + "      length=\"12\"\n" + "      name=\"Amount, Transaction\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"5\"\n" + "      length=\"12\"\n" + "      name=\"Amount, Settlement\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"6\"\n" + "      length=\"12\"\n" + "      name=\"Amount, Cardholder Billing\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"7\"\n" + "      length=\"10\"\n" + "      name=\"Transmission Date and Time\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"8\"\n" + "      length=\"8\"\n" + "      name=\"Amount, Cardholder Billing Fee\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"9\"\n" + "      length=\"8\"\n" + "      name=\"Conversion Rate, Settlement\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"10\"\n" + "      length=\"8\"\n" + "      name=\"Conversion Rate, Cardholder Billing\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"11\"\n" + "      length=\"6\"\n" + "      name=\"Systems Trace Audit Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"12\"\n" + "      length=\"6\"\n" + "      name=\"Time, Local Transaction\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"13\"\n" + "      length=\"4\"\n" + "      name=\"Date, Local Transaction\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"14\"\n" + "      length=\"4\"\n" + "      name=\"Date, Expiration\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"15\"\n" + "      length=\"4\"\n" + "      name=\"Date, Settlement\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"16\"\n" + "      length=\"4\"\n" + "      name=\"Date, Conversion\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"17\"\n" + "      length=\"4\"\n" + "      name=\"Date, Capture\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"18\"\n" + "      length=\"4\"\n" + "      name=\"Merchant Type\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"19\"\n" + "      length=\"3\"\n" + "      name=\"Acquiring Institution Country Code\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"20\"\n" + "      length=\"3\"\n"
				+ "      name=\"Primary Account Number (PAN) Country Code\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"21\"\n"
				+ "      length=\"3\"\n" + "      name=\"Forwarding Institution Country\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"22\"\n"
				+ "      length=\"3\"\n" + "      name=\"Point-of-Service (POS) Entry Mode\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"23\"\n"
				+ "      length=\"3\"\n" + "      name=\"Card Sequence Number\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"24\"\n"
				+ "      length=\"3\"\n" + "      name=\"Network International ID\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"25\"\n"
				+ "      length=\"2\"\n" + "      name=\"Point-of-Service (POS) Condition\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"26\"\n"
				+ "      length=\"2\"\n"
				+ "      name=\"Point-of-Service (POS) Personal ID Number (PIN) Capture Code\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"27\"\n" + "      length=\"1\"\n" + "      name=\"Authorization ID Response Length\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"28\"\n" + "      length=\"9\"\n" + "      name=\"Amount, Transaction Fee\"\n"
				+ "      class=\"org.jpos.iso.IFE_AMOUNT\"/>\n" + "  <isofield\n" + "      id=\"29\"\n"
				+ "      length=\"9\"\n" + "      name=\"Amount, Settlement Fee\"\n"
				+ "      class=\"org.jpos.iso.IFE_AMOUNT\"/>\n" + "  <isofield\n" + "      id=\"30\"\n"
				+ "      length=\"9\"\n" + "      name=\"Amount, Transaction Processing Fee\"\n"
				+ "      class=\"org.jpos.iso.IFE_AMOUNT\"/>\n" + "  <isofield\n" + "      id=\"31\"\n"
				+ "      length=\"9\"\n" + "      name=\"Amount, Settlement Processing Fee\"\n"
				+ "      class=\"org.jpos.iso.IFE_AMOUNT\"/>\n" + "  <isofield\n" + "      id=\"32\"\n"
				+ "      length=\"6\"\n" + "      name=\"Acquiring Institution ID Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLNUM\"/>\n" + "  <isofield\n" + "      id=\"33\"\n"
				+ "      length=\"6\"\n" + "      pad=\"true\"\n" + "      name=\"Forwarding Institution ID Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLNUM\"/>\n" + "  <isofield\n" + "      id=\"34\"\n"
				+ "      length=\"28\"\n" + "      name=\"Primary Account Number (PAN), Extended\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"35\"\n"
				+ "      length=\"37\"\n" + "      name=\"Track 2 Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"36\"\n"
				+ "      length=\"104\"\n" + "      name=\"Track 3 Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"37\"\n"
				+ "      length=\"12\"\n" + "      name=\"Retrieval Reference Number\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\" />\n" + "  <isofield\n" + "      id=\"38\"\n"
				+ "      length=\"6\"\n" + "      name=\"Authorization ID Response\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"39\"\n"
				+ "      length=\"2\"\n" + "      name=\"Response Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"40\"\n"
				+ "      length=\"3\"\n" + "      name=\"Service Restriction Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"41\"\n"
				+ "      length=\"8\"\n" + "      name=\"Card Acceptor Terminal ID\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"42\"\n"
				+ "      length=\"15\"\n" + "      name=\"Card Acceptor ID Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"43\"\n"
				+ "      length=\"40\"\n" + "      name=\"Card Acceptor Name/Location\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"44\"\n"
				+ "      length=\"25\"\n" + "      name=\"Additional Response Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"45\"\n"
				+ "      length=\"76\"\n" + "      name=\"Track 1 Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"46\"\n"
				+ "      length=\"999\"\n" + "      name=\"Additional Data—ISO Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"47\"\n"
				+ "      length=\"999\"\n" + "      name=\"Additional Data—National\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"48\"\n"
				+ "      length=\"999\"\n" + "      name=\"Additional Data—Private Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"49\"\n"
				+ "      length=\"3\"\n" + "      name=\"Currency Code, Transaction\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"50\"\n"
				+ "      length=\"3\"\n" + "      name=\"Currency Code, Settlement\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"51\"\n"
				+ "      length=\"3\"\n" + "      name=\"Currency Code, Cardholder Billing\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"52\"\n"
				+ "      length=\"8\"\n" + "      name=\"Personal ID Number (PIN) Data\"\n"
				+ "      class=\"org.jpos.iso.IFB_BINARY\"/>\n" + "  <isofield\n" + "      id=\"53\"\n"
				+ "      length=\"16\"\n" + "      name=\"Security-Related Control Information\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"54\"\n" + "      length=\"240\"\n" + "      name=\"Additional Amounts\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"55\"\n"
				+ "      length=\"255\"\n" + "      name=\"Card Acceptor ID Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLBINARY\"/>\n" + "  <isofield\n" + "      id=\"56\"\n"
				+ "      length=\"37\"\n" + "      name=\"Payment Account Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"57\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"58\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"59\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"60\"\n"
				+ "      length=\"60\"\n" + "      name=\"Advice Reason\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"61\"\n"
				+ "      length=\"26\"\n" + "      name=\"Point-of-Service (POS) Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"62\"\n"
				+ "      length=\"100\"\n" + "      name=\"Intermediate Network Facility (INF) Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"63\"\n"
				+ "      length=\"50\"\n" + "      name=\"Network Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"64\"\n"
				+ "      length=\"8\"\n" + "      name=\"Message Authentication Code\"\n"
				+ "      class=\"org.jpos.iso.IFB_BINARY\"/>\n" + "  <isofield\n" + "      id=\"65\"\n"
				+ "      length=\"8\"\n" + "      name=\"Bit Map, Extended\"\n"
				+ "      class=\"org.jpos.iso.IFB_BINARY\"/>\n" + "  <isofield\n" + "      id=\"66\"\n"
				+ "      length=\"1\"\n" + "      name=\"Settlement Code\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"67\"\n"
				+ "      length=\"2\"\n" + "      name=\"Extended Payment Code\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"68\"\n"
				+ "      length=\"3\"\n"
				+ "      name=\"Receiving Institution Country 69 Settlement Institution Country Code\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"69\"\n" + "      length=\"3\"\n" + "      name=\"Settlement Institution Country\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"70\"\n" + "      length=\"3\"\n" + "      name=\"Network Management Information Code\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"71\"\n" + "      length=\"4\"\n" + "      name=\"Message Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"72\"\n" + "      length=\"4\"\n" + "      name=\"Message Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"73\"\n" + "      length=\"6\"\n" + "      name=\"Date, Action\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"74\"\n" + "      length=\"10\"\n" + "      name=\"Credits, Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"75\"\n" + "      length=\"10\"\n" + "      name=\"Credits, Reversal Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"76\"\n" + "      length=\"10\"\n" + "      name=\"Debits, Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"77\"\n" + "      length=\"10\"\n" + "      name=\"Debits, Reversal Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"78\"\n" + "      length=\"10\"\n" + "      name=\"Transfers, Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"79\"\n" + "      length=\"10\"\n" + "      name=\"Transfers, Reversal Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"80\"\n" + "      length=\"10\"\n" + "      name=\"inquiries, Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"81\"\n" + "      length=\"10\"\n" + "      name=\"Authorizations, Number\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"82\"\n" + "      length=\"12\"\n" + "      name=\"Credits, Processing Fee Amount\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"83\"\n" + "      length=\"12\"\n" + "      name=\"Credits, Transaction Fee Amount\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"84\"\n" + "      length=\"12\"\n" + "      name=\"Debits, Processing Fee\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"85\"\n" + "      length=\"12\"\n" + "      name=\"Debits, Transaction Fee Amount\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"86\"\n" + "      length=\"16\"\n" + "      name=\"Credits, Amount\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"87\"\n" + "      length=\"16\"\n" + "      name=\"Credits, Reversal Amount\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"88\"\n" + "      length=\"16\"\n" + "      name=\"Debits, Amount\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"89\"\n" + "      length=\"16\"\n" + "      name=\"Debits, Reversal\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"90\"\n" + "      length=\"42\"\n" + "      name=\"Original Data Elements\"\n"
				+ "      pad=\"true\"\n" + "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n"
				+ "      id=\"91\"\n" + "      length=\"1\"\n" + "      name=\"Issuer File Update Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"92\"\n"
				+ "      length=\"2\"\n" + "      name=\"File Security Code\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"93\"\n"
				+ "      length=\"5\"\n" + "      name=\"Response\"\n" + "      class=\"org.jpos.iso.IFE_CHAR\"/>\n"
				+ "  <isofield\n" + "      id=\"94\"\n" + "      length=\"7\"\n" + "      name=\"Service Indicator\"\n"
				+ "      class=\"org.jpos.iso.IFE_CHAR\"/>\n" + "  <isofield\n" + "      id=\"95\"\n"
				+ "      length=\"42\"\n" + "      name=\"Replacement Amounts\"\n" + "      pad=\"true\"\n"
				+ "      class=\"org.jpos.iso.IFE_NUMERIC\"/>\n" + "  <isofield\n" + "      id=\"96\"\n"
				+ "      length=\"8\"\n" + "      name=\"Message Security Code\"\n"
				+ "      class=\"org.jpos.iso.IFB_BINARY\"/>\n" + "  <isofield\n" + "      id=\"97\"\n"
				+ "      length=\"17\"\n" + "      name=\"Amount, Net Settlement\"\n"
				+ "      class=\"org.jpos.iso.IFE_AMOUNT\"/>\n" + "  <isofield\n" + "      id=\"98\"\n"
				+ "      length=\"25\"\n" + "      name=\"Payee\"\n" + "      class=\"org.jpos.iso.IFE_CHAR\"/>\n"
				+ "  <isofield\n" + "      id=\"99\"\n" + "      length=\"11\"\n"
				+ "      name=\"Settlement Institution ID Code\"\n" + "      class=\"org.jpos.iso.IFE_LLNUM\"/>\n"
				+ "  <isofield\n" + "      id=\"100\"\n" + "      length=\"11\"\n"
				+ "      name=\"Receiving Institution ID Code\"\n" + "      class=\"org.jpos.iso.IFE_LLNUM\"/>\n"
				+ "  <isofield\n" + "      id=\"101\"\n" + "      length=\"17\"\n" + "      name=\"File Name\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"102\"\n"
				+ "      length=\"28\"\n" + "      name=\"Account ID-1\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"103\"\n"
				+ "      length=\"28\"\n" + "      name=\"Account ID-2\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLCHAR\"/>\n" + "  <isofield\n" + "      id=\"104\"\n"
				+ "      length=\"999\"\n" + "      name=\"Digital Payment Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"105\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for Mastercard\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"106\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for Mastercard\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"107\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for Mastercard\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"108\"\n"
				+ "      length=\"999\"\n" + "      name=\"Additional Transaction Reference Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"109\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for ISO Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"110\"\n"
				+ "      length=\"999\"\n" + "      name=\"Additional Data—2\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"111\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for ISO\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"112\"\n"
				+ "      length=\"100\"\n" + "      name=\"Additional Data (National Use)\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"113\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"114\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"115\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"116\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"117\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"118\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"119\"\n"
				+ "      length=\"999\"\n" + "      name=\"Reserved for National Use\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"120\"\n"
				+ "      length=\"999\"\n" + "      name=\"Record data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"121\"\n"
				+ "      length=\"6\"\n" + "      name=\"Authorizing Agent ID\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLNUM\"/>\n" + "  <isofield\n" + "      id=\"122\"\n"
				+ "      length=\"999\"\n" + "      name=\"Additional Record Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"123\"\n"
				+ "      length=\"512\"\n" + "      name=\"Receipt Free Text\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"124\"\n"
				+ "      length=\"199\"\n" + "      name=\"Member-defined Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"125\"\n"
				+ "      length=\"8\"\n" + "      name=\"New PIN Data\"\n"
				+ "      class=\"org.jpos.iso.IFB_BINARY\"/>\n" + "  <isofield\n" + "      id=\"126\"  \n"
				+ "      length=\"100\"\n" + "      name=\"Private Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"127\"  \n"
				+ "      length=\"100\"\n" + "      name=\"Private Data\"\n"
				+ "      class=\"org.jpos.iso.IFE_LLLCHAR\"/>\n" + "  <isofield\n" + "      id=\"128\"\n"
				+ "      length=\"8\"\n" + "      name=\"Message Authentication Code (MAC)\"\n"
				+ "      class=\"org.jpos.iso.IFB_BINARY\"/>\n" + "</isopackager>";
	}

}
