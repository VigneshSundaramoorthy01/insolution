package com.isg.mw.routing.context;

import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.routing.config.RoutingConstants;
import com.isg.mw.routing.exception.TargetNoResponseException;
import lombok.Getter;
import org.apache.camel.*;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.spi.Synchronization;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.net.ssl.SSLContext;

import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_CORRELATION_ID;

public class MwProducer {
    private Logger logger = LogManager.getLogger(this.getClass());

    @Getter
    private ProducerTemplate producerTemplate;


    /**
     * Returns instance of <code>ProducerTemplate</code>
     *
     * @return
     */
    public ProducerTemplate initializeProducerTemplate(CamelContext camelContext) {
        if (producerTemplate == null) {
            producerTemplate = camelContext.createProducerTemplate();
        }
        return producerTemplate;
    }


    /**
     * Sends a given message to endpoint and on completion a synchronization
     * callback is invoked.
     *
     * @param message       A message to be sent to endpoint.
     * @param correlationId
     */
    public Object sendMessage(Object message, String correlationId, Endpoint nettyEndpoint) {
        Object resObj = null;
        CompletableFuture<Exchange> response = this.producerTemplate.asyncCallback(nettyEndpoint, exchange -> {
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_CORRELATION_ID, correlationId);
            exchange.getIn().setBody(message);
        }, new Synchronization() {

            @Override
            public void onFailure(Exchange exchange) {
                logger.error("Failed to send transaction to target, RRN: {}", correlationId,
                        exchange.getException());
                throw new TargetNoResponseException("Target is not responding");
            }

            @Override
            public void onComplete(Exchange exchange) {
                logger.debug("Transaction successfully sent to target, RRN: {}", correlationId);
            }
        });

        try {
            resObj = ((Exchange) response.get()).getIn().getBody();
            logger.debug("Transaction response received from target, RRN: {}", correlationId);
        } catch (InterruptedException | ExecutionException e) {
            logger.error("Error while getting the response from target ",e);
            throw new TargetNoResponseException("Target is not responding");
        }
        return resObj;
    }

    /**
     * Sends a given message to endpoint and on completion a synchronization
     * callback is invoked.
     */
    public Object connect(Object message, String correlationId, Endpoint nettyEndpoint) {
        Object resObj = null;
        CompletableFuture<Exchange> response = this.producerTemplate.asyncCallback(nettyEndpoint, exchange -> {
            exchange.getIn().setBody("");
        }, new Synchronization() {

            @Override
            public void onFailure(Exchange exchange) {
                logger.error("Failed to send transaction to target, RRN: {}", correlationId,
                        exchange.getException());
            }

            @Override
            public void onComplete(Exchange exchange) {
                logger.debug("Transaction successfully sent to target, RRN: {}", correlationId);
            }
        });

        return resObj;
    }
    
    public Object callApi(String body, String url, Map<String, String> headers) {
        String responseBody=null;
        HttpStatus statusCode = null;
        try {
            SSLContext context = SSLContext.getInstance("TLSv1.2");
            context.init(null, null, new SecureRandom());
            CloseableHttpClient httpClient = HttpClientBuilder.create().setSSLContext(context)
                    .build();
            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
            factory.setConnectTimeout(20_000);
            factory.setReadTimeout(20_000);
            RestTemplate restTemplate = new RestTemplate(factory);


            logger.trace("Invoking API through Web Client: {}, with Request Body: {}", url, body);
//            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate(factory);
            HttpHeaders httpHeaders = new HttpHeaders();
            headers.forEach(httpHeaders::add);
            HttpEntity<String> request = new HttpEntity<>(body, httpHeaders);

            ResponseEntity<String> exchange = restTemplate.postForEntity(url, request, String.class);
            statusCode = exchange.getStatusCode();
            responseBody = exchange.getBody();
            HttpStatus httpStatus =  exchange.getStatusCode();
            if (httpStatus == HttpStatus.BAD_GATEWAY) {
                throw new TargetNoResponseException("Target is not responding");
            }
            String res = httpStatus.value() + API_RESPONSE_SEPARATOR + responseBody;
            logger.trace("API Response status: {}, Body: {}", statusCode, res);
            return res;

        } catch (HttpClientErrorException e) {
            responseBody = e.getMessage();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (ResourceAccessException e) {
            e.printStackTrace();
            throw new IllegalStateException("TimeoutException:: "+e.getMessage());
        }
        logger.trace("Response from API Status Code: {}, Body: {}", statusCode, responseBody);
        return responseBody;
    }


    public Object callApiUsingWebClient(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Header:{}, Request Body: {}", url, headers, body);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new TargetNoResponseException("Target is not responding");
        }
        //To test TimeOut Reversal
        /*if(url.equals("https://apitest.cybersource.com/pts/v2/payments")){
            throw new TargetNoResponseException("Target is not responding");
        }*/
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public Object callGetApiUsingWebClient(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Request Body: {}", url, body);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block;
        if (headers != null) {
            block = webClient.build()
                    .get()
                    .uri(url)
                    .headers(headers1 -> {
                        headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                    })
                    .exchange()
                    .block(Duration.ofSeconds(20));
        } else {
            block = webClient.build()
                    .get()
                    .uri(url)
                    .exchange()
                    .block(Duration.ofSeconds(20));
        }
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new TargetNoResponseException("Target is not responding");
        }
        //To test TimeOut Reversal
        /*if(url.equals("https://apitest.cybersource.com/pts/v2/payments")){
            throw new TargetNoResponseException("Target is not responding");
        }*/
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public Object callApiUsingProxyWebClient(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Request Body: {}", url, body);

        String host = MTMProperties.getProperty("icici.proxy.host");
        int port = Integer.parseInt(MTMProperties.getProperty("icici.proxy.port"));
        logger.info("Proxy Host ::"+ host + " Proxy Port :: " + port);
        HttpClient httpClient = HttpClient.create().tcpConfiguration(tcpClient -> tcpClient.proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP))
                .host(host)
                .port(port));
        ReactorClientHttpConnector reactorClientHttpConnector = new ReactorClientHttpConnector(httpClient);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient().clientConnector(reactorClientHttpConnector);
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new RuntimeException("Target is not responding");
        }
        //To test TimeOut Reversal
        /*if(url.equals("https://apitest.cybersource.com/pts/v2/payments")){
            throw new TargetNoResponseException("Target is not responding");
        }*/
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public Object sendMessage(String message, Endpoint nettyEndpoint, Map<String, String> headers) {
//        Map<String, Object> objHeaders = new HashMap<>(headers);
        Object resObj = null;
//        Object obj = producerTemplate.requestBodyAndHeaders(nettyEndpoint, message, objHeaders);
//        String url = "https://apitest.cybersource.com/pts/v2/payments";

//        resObj = this.producerTemplate.sendBodyAndHeaders(nettyEndpoint, ExchangePattern.InOut, message, objHeaders);
//        try {
//            resObj = objectCompletableFuture.get();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        }
//            logger.trace("Object returned {}", resObj);
        CompletableFuture<Exchange> response = this.producerTemplate.asyncCallback(nettyEndpoint, exchange -> {
            Map<String, Object> headers1 = exchange.getIn().getHeaders();
            headers1.putAll(headers);
            exchange.getIn().setBody(message, String.class);
        }, new Synchronization() {

            @Override
            public void onFailure(Exchange exchange) {
                logger.error("Failed to send transaction to target", exchange.getException());
//                throw new TargetNoResponseException("Target is not responding");
            }

            @Override
            public void onComplete(Exchange exchange) {
                logger.debug("Transaction successfully sent to target");
            }
        });

        try {
            resObj = (response.get()).getIn().getBody();
            logger.debug("Response received from target: {}", resObj);
        } catch (InterruptedException | ExecutionException e) {
            logger.error("Error while getting the response from target", e);
            //throw new RuntimeException(e);
//            throw new IssuerUnavailableException("Issuer is not available, RRN: " + correlationId);
            throw new TargetNoResponseException("Target is not responding");
        }
        return resObj;
    }

    /**
     * Sends a given message to endpoint synchronously.
     *
     * @param message       A message to be sent to endpoint.
     * @param correlationId
     */
    public void justSendMessage(Object message, String correlationId, NettyEndpoint nettyEndpoint) {

        this.producerTemplate.asyncSend(nettyEndpoint, exchange -> {
            exchange.getIn().getHeaders().put(RoutingConstants.CORRELATION_ID, correlationId);
            exchange.getIn().setBody(message);
        });

    }

}
