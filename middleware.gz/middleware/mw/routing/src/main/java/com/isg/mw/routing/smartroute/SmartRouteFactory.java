package com.isg.mw.routing.smartroute;

import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.constants.SourceProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class SmartRouteFactory {

    @Autowired
    private List<ISmartRoute> smartRoutesList;

    private static Map<RouteType, ISmartRoute> smartRoutesCache = new HashMap<>();

    @PostConstruct
    public void initSmartRoutes() {
        smartRoutesList.forEach(smartRoute ->
                smartRoutesCache.put(smartRoute.getRouteType(), smartRoute));
    }

    public static ISmartRoute getSmartRoute(RouteType routeType) {
        return smartRoutesCache.get(routeType);
    }
}
