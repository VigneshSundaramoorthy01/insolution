package com.isg.mw.routing.route.codec;

import com.isg.mw.dstm.utils.HsmCommandUtility;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.apache.camel.component.netty.ChannelHandlerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class ByteStreamDecoder extends ByteToMessageDecoder implements ChannelHandlerFactory {

    private Logger logger = LogManager.getLogger(getClass());

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf msg, List<Object> out) {
        try {
            while (msg.isReadable() && msg.readableBytes() != msg.capacity()) {
                byte[] msgBytes = new byte[msg.readableBytes()];
                msg.readBytes(msgBytes);
                out.add(msgBytes);
            }
        } catch (Exception e) {
            logger.trace("ByteStreamDecoder: Message - readableBytes: {}, Capacity: {}",
                    msg.readableBytes(), msg.capacity());
            logger.error("ByteStreamDecoder: Exception while decoding: {}", e.getMessage());
        }
    }

    @Override
    public ChannelHandler newChannelHandler() {
        return new ByteStreamDecoder();
    }
}