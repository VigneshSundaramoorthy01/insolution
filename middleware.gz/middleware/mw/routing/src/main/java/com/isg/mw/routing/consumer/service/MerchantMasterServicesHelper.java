package com.isg.mw.routing.consumer.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.hitachi.HitachiMerchantRequestModel;
import com.isg.mw.core.model.hitachi.HitachiMerchantResponseModel;
import com.isg.mw.core.model.icici.CheckVpaRequest;
import com.isg.mw.core.model.icici.StoreAccountDetailsRequest;
import com.isg.mw.core.model.icici.UpiResponse;
import com.isg.mw.core.model.lyra.LyraMerchantRequestModel;
import com.isg.mw.core.model.lyra.LyraMerchantResponseModel;
import com.isg.mw.core.model.lyra.LyraWibmoMerchantRequestModel;
import com.isg.mw.core.model.lyra.LyraWibmoMerchantResponseModel;
import com.isg.mw.core.model.payu.PayUAccessTokenResponseModel;
import com.isg.mw.core.model.payu.PayUMerchantModel;
import com.isg.mw.core.model.pos.*;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tpsl.TpslMerchantRequestModel;
import com.isg.mw.core.model.tpsl.TpslMerchantResponseModel;
import com.isg.mw.core.model.vizpay.VizPayMerchantRequestModel;
import com.isg.mw.core.model.vizpay.VizPayMerchantResponseModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.IsgXmlUtils;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.transform.hitachi.HitachiMessageTransformation;
import com.isg.mw.mtm.transform.icici.IciciMessageTransformation;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import com.isg.mw.mtm.transform.mosambee.MosambeeMessageTransformation;
import com.isg.mw.mtm.transform.payu.PayUMessageTransformation;
import com.isg.mw.mtm.transform.pos.PosMessageTransformation;
import com.isg.mw.mtm.transform.tpsl.TpslMessageTransformation;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.Data;
import org.apache.http.HttpHost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.xml.bind.JAXBException;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.*;

@Component
public class MerchantMasterServicesHelper {
    private final Logger logger = LogManager.getLogger(getClass());

    public PayUAccessTokenResponseModel callAccesssTokenApi(PayUMessageTransformation payUMessageTransformation
            , TargetConfigModel targetModel) {
        TargetApiInfo.PayU payUData = targetModel.getAdditionalData().getApiInfo().getPayU();
        String tokenUrl = payUData.getTokenUrl();
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());

        MultiValueMap<String, String> map = payUMessageTransformation.getAccessToken(targetModel);

        logger.info("Pay Access Token Headers: {}", headers);
        String accessToken = callApiUsingWebClient(map, null, tokenUrl, headers, null);
        return IsgJsonUtils.getObjectFromJsonString(accessToken, PayUAccessTokenResponseModel.class);
    }

    public LyraMerchantResponseModel callLyraCreateMerchantApi(LyraMessageTransformation lyraMessageTransformation,
                                                               MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) throws JsonProcessingException {
        logger.info("Calling Lyra PG Merchant API :  ");
        HttpHeaders httpHeaders = buildHeader(targetConfigModel.getAdditionalData());
        String lyraUrl = targetConfigModel.getAdditionalData().getApiInfo().getLyra().getMerchantUrl();
        TargetMerchantMasterModel targetMerchantMaster = fetchCacheTargetMerchantMaster(targetConfigModel.getId().toString(), merchantMasterModel.getMid());
        logger.info("Target Merchant Master Fetched From DB  : {}  ", targetMerchantMaster);
        LyraMerchantRequestModel lyraMerchantRequestModel = lyraMessageTransformation.createMerchant(merchantMasterModel);
        JSONObject jsonObject = new JSONObject(new ObjectMapper().writeValueAsString(lyraMerchantRequestModel));
        String res;
        try {
            if (targetMerchantMaster != null && ActiveInactiveFlag.Active.name().equals(targetMerchantMaster.getStatus()) && !StringUtils.isBlank(targetMerchantMaster.getKey())) {
                //httpHeaders.add("registration_id", targetMerchantMaster.getKey());
                lyraUrl = targetConfigModel.getAdditionalData().getApiInfo().getLyra().getMerchantUpdateUrl().replace("#registration_id#", targetMerchantMaster.getKey());
                res = callUpdateApiUsingWebClient(null, jsonObject.toString(), lyraUrl, null, httpHeaders);
            } else {
                res = callApiUsingWebClient(null, jsonObject.toString(), lyraUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Lyra API Request : {} ", e.getMessage());
        }
        logger.info("API response for Lyra : {} \n", res);
        LyraMerchantResponseModel responseModel = IsgJsonUtils.getObjectFromJsonString(res, LyraMerchantResponseModel.class);
        if (responseModel != null) {
            if (responseModel.getShop() != null && !StringUtils.isBlank(responseModel.getShop().getShopId())) {
                return responseModel;
            } else if (!StringUtils.isBlank(responseModel.getMessage())) {
                responseModel.setResMessage(responseModel.getCauses());
            } else {
                responseModel = new LyraMerchantResponseModel();
                responseModel.setResMessage("Exception While calling PG Lyra API");
            }
        } else {
            responseModel = new LyraMerchantResponseModel();
            responseModel.setResMessage(res);
        }
        return responseModel;
    }

    public LyraMerchantResponseModel callLyraPosCreateMerchantApi(LyraMessageTransformation lyraMessageTransformation,
                                                                  MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) throws JsonProcessingException {
        logger.info("Calling Lyra Pos Merchant API :  ");
        TargetMerchantMasterModel targetMerchantMaster = fetchCacheTargetMerchantMaster(targetConfigModel.getId().toString(), merchantMasterModel.getMid());
        logger.info("Target Merchant Master Fetched From DB  : {}  ", targetMerchantMaster);
        String lyraUrl;
        HttpHeaders httpHeaders = buildLyraPosHeader(targetConfigModel.getAdditionalData());
        if (targetMerchantMaster != null && (!StringUtils.isBlank(targetMerchantMaster.getTargetMid())
                || ActiveInactiveFlag.Active.name().equals(targetMerchantMaster.getStatus()))) {
            httpHeaders.add("registration_id", targetMerchantMaster.getTargetMid());
            lyraUrl = targetConfigModel.getAdditionalData().getApiInfo().getLyra().getPosUpdateMerchantUrl();
        } else {
            lyraUrl = targetConfigModel.getAdditionalData().getApiInfo().getLyra().getPosMerchantUrl();
        }
        LyraMerchantRequestModel lyraMerchantRequestModel = lyraMessageTransformation.createMerchant(merchantMasterModel);
        JSONObject jsonObject = new JSONObject(new ObjectMapper().writeValueAsString(lyraMerchantRequestModel));
        String res;
        try {
            res = callApiUsingWebClient(null, jsonObject.toString(), lyraUrl, null, httpHeaders);
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Lyra API Request : {} ", e.getMessage());
        }
        logger.info("API response for Lyra : {} \n", res);
        LyraMerchantResponseModel responseModel = IsgJsonUtils.getObjectFromJsonString(res, LyraMerchantResponseModel.class);
        if (responseModel != null && responseModel.getBusiness() != null &&
                (responseModel.getBusiness().getStatus() != null ?
                        responseModel.getBusiness().getStatus().equalsIgnoreCase("TO MODIFY") : true)) {
            return responseModel;
        }
        if (responseModel != null && !StringUtils.isBlank(responseModel.getMessage())) {
            responseModel.setResMessage(responseModel.getCauses());
        }
        if (responseModel == null) {
            responseModel = new LyraMerchantResponseModel();
            responseModel.setResMessage(res);
        }
        return responseModel;
    }

//    public CacheTargetMerchantMaster fetchCacheTargetMerchantMaster(String targetId, String mid) {
//        CacheTargetMerchantMaster targetMerchantMaster = SpringContextBridge.services().getCacheUtil().getTargetMerchantMasterData(targetId,
//                mid, ActiveInactiveFlag.Active.name());
//        TargetMerchantMasterModel model;
//        if (targetMerchantMaster == null || (targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Inprogress.name()) ||
//                targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Failed.name()))) {
//            List<TargetMerchantMasterModel> targetMerchantMaster1 = SpringContextBridge.services().getInitRestClient().getTargetMerchantMaster(targetId, mid, null, ActiveInactiveFlag.Active.name());
//            if(targetMerchantMaster1 != null && !targetMerchantMaster1.isEmpty()){
//                targetMerchantMaster = updateTargetMerchantMasterCache(targetMerchantMaster1.get(0));
//            }else{
//                return null;
//            }
//        }
//        return targetMerchantMaster;
//    }

       public TargetMerchantMasterModel fetchCacheTargetMerchantMaster(String targetId, String mid) {
        List<TargetMerchantMasterModel> targetMerchantMaster1 = SpringContextBridge.services().getInitRestClient().getTargetMerchantMaster(targetId, mid, null, ActiveInactiveFlag.Active.name());
        if (targetMerchantMaster1 != null && !targetMerchantMaster1.isEmpty()) {
            return targetMerchantMaster1.get(0);
        }
        return null;
    }

    public LyraWibmoMerchantResponseModel callWibmoLyraCreateMerchantApi(LyraMessageTransformation lyraMessageTransformation,
                                                                         MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) throws JsonProcessingException {
        logger.info("Calling Wibmo Merchant API :  ");
        String wibmoMerchantUrl = targetConfigModel.getAdditionalData().getApiInfo().getWibmoUrls().getWibmoMerchantUrl();
        String res;
        res = lyraMessageTransformation.generatedAccessToken(targetConfigModel.getAdditionalData(), true);
        LyraWibmoMerchantResponseModel responseModel = null;
        if (!StringUtils.isBlank(res) && !res.startsWith("Error ::")) {
            HttpHeaders httpHeaders = lyraMessageTransformation.buildWibmoApiHeader(targetConfigModel.getAdditionalData(), res);
            LyraWibmoMerchantRequestModel wibmoMerchantRequest = lyraMessageTransformation.createWibmoMerchantRequest(merchantMasterModel);
            JSONObject jsonObject = new JSONObject(new ObjectMapper().writeValueAsString(wibmoMerchantRequest));
            try {
                res = callApiUsingWebClient(null, jsonObject.toString(), wibmoMerchantUrl, null, httpHeaders);
            } catch (Exception e) {
                res = e.getMessage();
                logger.info("Exception while WIBMO API Request : {} ", e.getMessage());
            }
            logger.info("API response for WIBMO : {} \n", res);
            responseModel = IsgJsonUtils.getObjectFromJsonString(res, LyraWibmoMerchantResponseModel.class);
            if (responseModel != null && responseModel.getStatus().equalsIgnoreCase("SUCCESS")) {
                return responseModel;
            }
            if (responseModel != null && !StringUtils.isBlank(responseModel.getErrorDesc()) && !StringUtils.isBlank(responseModel.getErrorCode())) {
                responseModel.setResMessage(responseModel.getErrorDesc());
            }
        }
        if (responseModel == null) {
            responseModel = new LyraWibmoMerchantResponseModel();
            responseModel.setResMessage(res);
        }
        return responseModel;
    }

    public HttpHeaders buildHeader(TargetAdditionalData targetAdditionalData) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("apikey", targetAdditionalData.getApiInfo().getLyra().getMerchantApiKey());
        headers.setBasicAuth(targetAdditionalData.getApiInfo().getLyra().getMerchantAuthUsername(), targetAdditionalData.getApiInfo().getLyra().getMerchantAuthPassword());
        return headers;
    }

    public HttpHeaders buildLyraPosHeader(TargetAdditionalData targetAdditionalData) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("apikey", targetAdditionalData.getApiInfo().getLyra().getPosMerchantApiKey());
        headers.setBasicAuth(targetAdditionalData.getApiInfo().getLyra().getPosMerchantAuthUsername(), targetAdditionalData.getApiInfo().getLyra().getPosMerchantAuthPassword());
        return headers;
    }

    public TpslMerchantResponseModel callTpslCreateMerchantApi(TpslMessageTransformation tpslMessageTransformation,
                                                               MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) {
        logger.info("Calling Tpsl Merchant API :  ");
        String merchantUrl = targetConfigModel.getAdditionalData().getApiInfo().getTpsl().getMerchantUrl();
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("apikey", targetConfigModel.getAdditionalData().getApiInfo().getTpsl().getApikey());
        TpslMerchantRequestModel requestModel = tpslMessageTransformation.createMerchant(merchantMasterModel, targetConfigModel);
        String jsonString = IsgJsonUtils.getJsonString(requestModel);
        logger.info("API request for tpsl : {} \n", jsonString);
        String res;
        try {
            res = callApiUsingWebClient(null, jsonString, merchantUrl, headers, null);
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while TPSL API Request : {} ", e.getMessage());
        }
        logger.info("API response for tpsl : {} \n", res);
        TpslMerchantResponseModel tpslMerResponse = IsgJsonUtils.getObjectFromJsonString(res, TpslMerchantResponseModel.class);
        if (tpslMerResponse != null && !(tpslMerResponse.getErrorCode().equals("0") && tpslMerResponse.getErrorDesc().equalsIgnoreCase("success"))) {
            tpslMerResponse.setResMessage(res);
        }
        if (tpslMerResponse == null) {
            tpslMerResponse = new TpslMerchantResponseModel();
            tpslMerResponse.setResMessage(res);
        }

        return tpslMerResponse;
    }

//    public UpiResponse callIciciMerApi(IciciMessageTransformation iciciMessageTransformation,
//                                       TargetConfigModel targetConfigModel, MerchantMasterModel merchantMasterModel) throws JAXBException {
//        logger.info("Calling Icici Upi Merchant API :  ");
//        String merchantUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getMerchantUrl();
//        CheckVpaRequest checkVpaRequest = iciciMessageTransformation.buildCheckVpaRequest(merchantMasterModel);
//
//        String payload = IsgXmlUtils.convertObjectToXml(checkVpaRequest, CheckVpaRequest.class);
//        logger.info("API Request for Check VPA : {}", payload);
//
//        Map<String, String> headers = new HashMap<>();
//        headers.put("Content-Type", "application/xml");
//        logger.info("API Request Headers : {}", headers);
//        String res;
//        try {
//            res = callApiUsingWebClient(null, payload, merchantUrl, headers, null);
//            if (res.startsWith("status : 502 BAD_GATEWAY")) {
//                res = res.split("##")[0];
//            }
//        } catch (Exception e) {
//            res = e.getMessage();
//            logger.info("Exception while Calling Check VPA Request : {} ", e.getMessage());
//        }
//        logger.info("API response for Check VPA api : {}", res);
////        String upiResFromFile = getUpiResFromFile("CheckVpa");
////        res = upiResFromFile.replace("#targetTxnId#", checkVpaRequest.getSeqNo());
//        UpiResponse upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(res, UpiResponse.class);
//        if (upiResponse == null || (!"0".equalsIgnoreCase(upiResponse.getActCode()) &&
//                !"true".equalsIgnoreCase(upiResponse.getSuccess()))) {
//            upiResponse = new UpiResponse();
//            upiResponse.setResMessage(res);
//        } else {
//            StoreAccountDetailsRequest accountDetailsRequest = iciciMessageTransformation.buildStoreAccountDetailsRequest(merchantMasterModel);
//            String accDetailsPayload = IsgXmlUtils.convertObjectToXml(accountDetailsRequest, StoreAccountDetailsRequest.class);
//            String accDetailUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getAccountDetailsUrl();
//            try {
//                res = callApiUsingWebClient(null, accDetailsPayload, accDetailUrl, headers, null);
//            } catch (Exception e) {
//                res = e.getMessage();
//                logger.info("Exception while Calling Account Details Request : {} ", e.getMessage());
//            }
//            logger.info("API response for store account details api : {}", res);
////            String StoreAccUpiResFromFile = getUpiResFromFile("StoreAccountDetails");
////            res = StoreAccUpiResFromFile.replace("#targetTxnId#", accountDetailsRequest.getSeqNo());
//            upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(res, UpiResponse.class);
//            if (upiResponse == null || (!"0".equalsIgnoreCase(upiResponse.getActCode()) &&
//                    !"true".equalsIgnoreCase(upiResponse.getSuccess()))) {
//                upiResponse = new UpiResponse();
//                upiResponse.setResMessage(res);
//            }
//        }
//        return upiResponse;
//    }

    public UpiResponse callIciciMerApi(IciciMessageTransformation iciciMessageTransformation,
                                       TargetConfigModel targetConfigModel, MerchantMasterModel merchantMasterModel) throws JAXBException {
        logger.info("Calling Icici Upi Merchant API :  ");
        UpiResponse upiResponse = callCheckVpaApi(iciciMessageTransformation, targetConfigModel, merchantMasterModel);
        if (upiResponse != null && (!"0".equalsIgnoreCase(upiResponse.getActCode()))) {
            upiResponse.setResMessage(upiResponse.getResMessage());
        } else {
            upiResponse = callStoreAccountDetailsApi(iciciMessageTransformation, targetConfigModel, merchantMasterModel,upiResponse);
        }
        return upiResponse;
    }

    public UpiResponse callCheckVpaApi(IciciMessageTransformation iciciMessageTransformation,
                                       TargetConfigModel targetConfigModel, MerchantMasterModel merchantMasterModel) throws JAXBException {
        String merchantUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getMerchantUrl();
        CheckVpaRequest checkVpaRequest = iciciMessageTransformation.buildCheckVpaRequest(merchantMasterModel);

        String payload = IsgXmlUtils.convertObjectToXml(checkVpaRequest, CheckVpaRequest.class);
        logger.info("API Request for Check VPA : {}", payload);

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/xml");
        logger.info("API Request Headers : {}", headers);
        String res;
        try {
            res = callApiUsingWebClient(null, payload, merchantUrl, headers, null);
            if (res.startsWith("status : 502 BAD_GATEWAY")) {
                res = res.split("##")[0];
            }
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Calling Check VPA Request : {} ", e.getMessage());
        }
        logger.info("API response for Check VPA api : {}", res);
//        String upiResFromFile = getUpiResFromFile("CheckVpa");
//        res = upiResFromFile.replace("#targetTxnId#", checkVpaRequest.getSeqNo());
        UpiResponse upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(res, UpiResponse.class);
        if (upiResponse == null) {
            upiResponse = new UpiResponse();
            upiResponse.setResMessage(res);
        } else if (!"0".equalsIgnoreCase(upiResponse.getActCode())) {
            upiResponse.setResMessage(upiResponse.getMessage() != null ? upiResponse.getMessage() : res);
        }
        upiResponse.setPayeeVpa(checkVpaRequest.getVirtualAddress());
        return upiResponse;
    }

    public UpiResponse callStoreAccountDetailsApi(IciciMessageTransformation iciciMessageTransformation,
                                                  TargetConfigModel targetConfigModel, MerchantMasterModel merchantMasterModel,UpiResponse upiResponse) throws JAXBException{
        StoreAccountDetailsRequest accountDetailsRequest = iciciMessageTransformation.buildStoreAccountDetailsRequest(merchantMasterModel,upiResponse);
        String accDetailsPayload = IsgXmlUtils.convertObjectToXml(accountDetailsRequest, StoreAccountDetailsRequest.class);
        String accDetailUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getAccountDetailsUrl();
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/xml");
        logger.info("API Request Headers : {}", headers);
        String res;
        try {
            res = callApiUsingWebClient(null, accDetailsPayload, accDetailUrl, headers, null);
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Calling Account Details Request : {} ", e.getMessage());
        }
        logger.info("API response for store account details api : {}", res);
//        String StoreAccUpiResFromFile = getUpiResFromFile("StoreAccountDetails");
//        res = StoreAccUpiResFromFile.replace("#targetTxnId#", accountDetailsRequest.getSeqNo());
        upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(res, UpiResponse.class);
        if (upiResponse == null) {
            upiResponse = new UpiResponse();
            upiResponse.setResMessage(res);
        } else if (!"0".equalsIgnoreCase(upiResponse.getActCode())) {
            upiResponse.setResMessage(upiResponse.getMessage() != null ? upiResponse.getMessage() : res);
        }
        upiResponse.setPayeeVpa(accountDetailsRequest.getVirtualAddress());
        return upiResponse;
    }

    public String  getUpiResFromFile(String msgType){
        ObjectMapper parser = new ObjectMapper();
        String res;
        try {
            Object object = parser.readValue(new File(MTMProperties.getProperty("upi.txn.response")), Object.class);
            LinkedHashMap<String, String> map = (LinkedHashMap<String, String>) object;
            res = map.get(msgType);
        } catch (Exception e) {
            res = e.getMessage();
        }
        return res;
    }

    public PayUMerchantModel callPayUCreateMerchant(PayUMessageTransformation payUMessageTransformation,
                                                    TargetConfigModel targetModel, MerchantMasterModel merMasterModel,
                                                    PayUAccessTokenResponseModel tokenModel) {
        logger.info("Calling PayU Merchant API :  ");
        String createMerchantUrl = targetModel.getAdditionalData().getApiInfo().getPayU().getMerchantUrl();
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());
        headers.put("AUTHORIZATION", "Bearer " + tokenModel.getAccess_token());

        MultiValueMap<String, String> map = payUMessageTransformation.createMerchant(merMasterModel);
        String res = callApiUsingWebClient(map, null, createMerchantUrl, headers, null);
        logger.info("API response for payu : {}", res);
        PayUMerchantModel payUModel = IsgJsonUtils.getObjectFromJsonString(res, PayUMerchantModel.class);
        if (payUModel == null) {
            payUModel = new PayUMerchantModel();
            payUModel.setResMessage(res);
        }
        return payUModel;
    }

    public ResponseObj.Credentials callPayMerchantCredApi(TargetConfigModel targetModel,
                                                          PayUMerchantModel payUMerchantModel, PayUAccessTokenResponseModel accessTokenResModel) throws JsonProcessingException {
        ResponseObj.Credentials payUMerchantCred;
        String createMerchantUrl = targetModel.getAdditionalData().getApiInfo().getPayU().getMerchantUrl();
        String merchantId = String.valueOf(payUMerchantModel.getMid());
        if (createMerchantUrl != null) {
            createMerchantUrl = createMerchantUrl + "/" + merchantId + "/credential";
        }
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept", MediaType.APPLICATION_FORM_URLENCODED_VALUE + "," + MediaType.APPLICATION_JSON_VALUE);
        headers.put("Authorization", "Bearer " + accessTokenResModel.getAccess_token());
        String res = callGetApiUsingWebClient(createMerchantUrl, headers);
        logger.info("API response for payu merchant cred Api : {}", res);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonNode = mapper.readTree((res.split("##")[1]));
        String data1 = jsonNode.get("data").toString();
        payUMerchantCred = IsgJsonUtils.getObjectFromJsonString(data1, ResponseObj.Credentials.class);
        return payUMerchantCred;
    }

    public String callGetApiUsingWebClient(String url, Map<String, String> headers) {
        logger.info("Invoking API through Web Client with Request URL : {} and Headers : {}", url,headers);
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        } catch (SSLException e) {
            e.printStackTrace();
        }
        SslContext finalSslContext = sslContext;
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                .build()
                .get()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        String res = httpStatus + "##" + block.bodyToMono(String.class).block();
        logger.info("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public String callApiUsingWebClient(MultiValueMap<String, String> mapBody, String strBody, String url, Map<String, String> headers, HttpHeaders httpHeaders) {
        logger.info("Invoking API through Web Client with Request URL : {} and Headers : {}", url, headers != null ? headers : httpHeaders);
        logger.info("Invoking API With Request Body:  {}", !StringUtils.isBlank(strBody) ? strBody : mapBody);
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        } catch (SSLException e) {
            e.printStackTrace();
        }
        SslContext finalSslContext = sslContext;

        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);

        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = null;
        HttpStatus httpStatus = null;
        WebClient.RequestBodySpec requestBodySpec = null;
        if (headers != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .post()
                    .uri(url)
                    .headers(headers1 -> {
                        headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                    });
        } else if (httpHeaders != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .post()
                    .uri(url)
                    .headers(headers1 -> {
                        httpHeaders.forEach((key, value) -> headers1.put(key, value));
                    });
        }
        if (mapBody != null) {
            block = requestBodySpec.body(BodyInserters.fromFormData(mapBody)).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        } else if (strBody != null) {
            block = requestBodySpec.body(Mono.just(strBody), String.class).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        }
        String res = null;
        if (httpStatus == HttpStatus.OK || httpStatus == HttpStatus.CREATED || httpStatus == HttpStatus.ACCEPTED) {
            res = block.bodyToMono(String.class).block();
        } else {
            res = "status : " + httpStatus.toString() + "##" + " body : " + block.bodyToMono(String.class).block();
        }

        logger.info("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public String callUpdateApiUsingWebClient(MultiValueMap<String, String> mapBody, String strBody, String url, Map<String, String> headers, HttpHeaders httpHeaders) {
        logger.info("Invoking API through Web Client with Request URL : {} and Headers : {}", url, headers != null ? headers : httpHeaders);
        logger.info("Invoking API With Request Body:  {}", !StringUtils.isBlank(strBody) ? strBody : mapBody);
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        } catch (SSLException e) {
            e.printStackTrace();
        }
        SslContext finalSslContext = sslContext;
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = null;
        HttpStatus httpStatus = null;
        WebClient.RequestBodySpec requestBodySpec = null;
        if (headers != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .put()
                    .uri(url)
                    .headers(headers1 -> {
                        headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                    });
        } else if (httpHeaders != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .put()
                    .uri(url)
                    .headers(headers1 -> {
                        httpHeaders.forEach((key, value) -> headers1.put(key, value));
                    });
        }
        if (mapBody != null) {
            block = requestBodySpec.body(BodyInserters.fromFormData(mapBody)).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        } else if (strBody != null) {
            block = requestBodySpec.body(Mono.just(strBody), String.class).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        }
        String res = null;
        if (httpStatus == HttpStatus.OK || httpStatus == HttpStatus.CREATED || httpStatus == HttpStatus.ACCEPTED) {
            res = block.bodyToMono(String.class).block();
        } else {
            res = "status : " + httpStatus.toString() + "##" + " body : " + block.bodyToMono(String.class).block();
        }

        logger.info("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public String callApiUsingWebClientProxy(MultiValueMap<String, String> mapBody, String strBody, String url, Map<String, String> headers, HttpHeaders httpHeaders) {
        logger.info("Invoking API through Web Client with Request URL: {} and Headers: {}", url, headers != null ? headers : httpHeaders);
        logger.info("Invoking API With Request Body: {}", !StringUtils.isBlank(strBody) ? strBody : mapBody);

        // Configure SSLContext
        SslContext sslContext;
        try {
            sslContext = SslContextBuilder.forClient()
                    .build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize SSLContext", e);
        }

        // Configure proxy settings
        InetSocketAddress proxyAddress = new InetSocketAddress(
                MTMProperties.getProperty("mosambee.proxy.host"),
                Integer.parseInt(MTMProperties.getProperty("mosambee.proxy.port"))
        );
        logger.info("Configured proxy: {}", proxyAddress);

        // Create HttpClient with SSLContext and proxy settings
        HttpClient httpClient = HttpClient.create()
                .secure(t -> t.sslContext(sslContext)) // Use the SSLContext
                .proxy(proxySpec -> proxySpec
                        .type(ProxyProvider.Proxy.SOCKS5) // Use SOCKS5 proxy type
                        .address(proxyAddress)) // Configure the address
                .followRedirect(true); // Follow redirects if needed

        // Build WebClient with the custom HttpClient
        WebClient.Builder webClientBuilder = SpringContextBridge.services().getWebClient();
        WebClient webClient = webClientBuilder
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();

        WebClient.RequestBodySpec requestBodySpec = webClient.post()
                .uri(url);

        // Set headers if they are provided
        if (headers != null) {
            requestBodySpec = requestBodySpec.headers(headers1 ->
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)))
            );
        } else if (httpHeaders != null) {
            requestBodySpec = requestBodySpec.headers(headers1 ->
                    httpHeaders.forEach((key, value) -> headers1.put(key, value))
            );
        }

        // Send request and get response
        ClientResponse response;
        if (mapBody != null) {
            response = requestBodySpec.body(BodyInserters.fromFormData(mapBody)).exchange().block(Duration.ofSeconds(20));
        } else if (strBody != null) {
            response = requestBodySpec.body(Mono.just(strBody), String.class).exchange().block(Duration.ofSeconds(20));
        } else {
            throw new IllegalArgumentException("Request body cannot be null");
        }

        HttpStatus httpStatus = response.statusCode();
        String res;
        if (httpStatus.is2xxSuccessful()) {
            res = response.bodyToMono(String.class).block();
        } else {
            res = "Status: " + httpStatus + " ## Body: " + response.bodyToMono(String.class).block();
        }

        logger.info("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public MosambeeResponseModel callPosMosambeeMerchantApi(MosambeeMessageTransformation mosambeeMessageTransformation, MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) {
        logger.info("Calling Mosambee Pos Merchant API :  ");
        String mosambeeUrl="";
        MosambeeRequestModel requestModel = null;

        if(merchantMasterModel.getIsMosambeeAddEnable())
        {
            mosambeeUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getRegistrationUrl();
            requestModel = mosambeeMessageTransformation.createMerchant(merchantMasterModel);
        }
        else if(merchantMasterModel.getIsMosambeeUpdateEnable())
        {
            mosambeeUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getRegistrationEditUrl();
            requestModel = mosambeeMessageTransformation.createMerchantRegistrationUpdate(merchantMasterModel);
        }
        HttpHeaders httpHeaders = null;
        Calendar date = Calendar.getInstance();
        long millisecondsDate = date.getTimeInMillis();
        String res;
        String clientId = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getClientId();
        String hmacUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getHmacUrl();
        String hmacKey = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getHmacKey();

        String resEncryptData = getEncryptedPayloadForRegisterAndEditUrl(mosambeeMessageTransformation,requestModel,merchantMasterModel,targetConfigModel);
        JSONObject jsonForReqPayload = getJsonForReqPayload(resEncryptData,clientId);

        String hmacDataResult =  getHmacDataResult(hmacUrl,hmacKey,clientId,jsonForReqPayload,millisecondsDate);
        httpHeaders = buildMosambeeRegisterApiHeaders(clientId, hmacDataResult, millisecondsDate);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                res = callApiUsingWebClientProxy(null, jsonForReqPayload + "", mosambeeUrl, null, httpHeaders);
            } else {
                res = callApiUsingWebClient(null, jsonForReqPayload + "", mosambeeUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Registration  API Request : {} ", e.getMessage());
        }
        MosambeeResponseModel responseModel = IsgJsonUtils.getObjectFromJsonString(res, MosambeeResponseModel.class);
        if(responseModel ==null)
        {
            responseModel = new MosambeeResponseModel();
            responseModel.setResMessage(res);
        }
        else {
            responseModel.setResMessage(responseModel.getMessage());
        }
        return responseModel;
    }

    public MosambeeUpdateStatusResponseModel callPosMosambeeMerchantUpdateStatusApi(MosambeeMessageTransformation mosambeeMessageTransformation, MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel,String refId) {
        logger.info("Calling Pos Mosambee Merchant Update Status API :  ");

        HttpHeaders httpHeaders = new HttpHeaders();
        Calendar date = Calendar.getInstance();
        long millisecondsDate = date.getTimeInMillis();
        String res;

        String clientId = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getClientId();
        String hmacUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getHmacUrl();
        String hmacKey = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getHmacKey();

        MosambeeUpdateStatusRequestModel requestModel = mosambeeMessageTransformation.createMerchantUpdateStatus(merchantMasterModel, refId);

        String resEncryptData = getEncryptedPayloadForUpdateStatusUrl(mosambeeMessageTransformation, requestModel, merchantMasterModel, targetConfigModel);
        JSONObject jsonForReqPayload = getJsonForReqPayload(resEncryptData, clientId);

        String hmacDataResult = getHmacDataResult(hmacUrl, hmacKey, clientId, jsonForReqPayload, millisecondsDate);
        String updateStatusUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getUpdateStatusUrl();

        httpHeaders = buildMosambeeRegisterApiHeaders(clientId, hmacDataResult, millisecondsDate);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                res = callApiUsingWebClientProxy(null, jsonForReqPayload + "", updateStatusUrl, null, httpHeaders);
            } else {
                res = callApiUsingWebClient(null, jsonForReqPayload + "", updateStatusUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Mosambee Merchant Update Status  API Request : {} ", e.getMessage());
        }
        MosambeeUpdateStatusResponseModel responseModel = IsgJsonUtils.getObjectFromJsonString(res, MosambeeUpdateStatusResponseModel.class);
        if (responseModel == null) {
            responseModel = new MosambeeUpdateStatusResponseModel();
            responseModel.setResMessage(res);
        } else {
            responseModel.setResMessage(responseModel.getMessage());
        }
        return responseModel;
    }

    public VizPayMerchantResponseModel callVizPayCreateMerchantApi(IciciMessageTransformation lyraMessageTransformation,
                                                                   MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) throws JsonProcessingException {
        logger.info("Calling VizPay Merchant API :  ");
        String res;
        res = generateVizPayApiAccessToken(targetConfigModel.getAdditionalData());
        VizPayMerchantResponseModel responseModel = null;
        if (!StringUtils.isBlank(res) && !res.startsWith("Error ::")) {
            String uploadTerminalApiUrl = targetConfigModel.getAdditionalData().getApiInfo().getVizPay().getUploadTerminalApiUrl();
            HttpHeaders httpHeaders = buildVizPayApiHeader(targetConfigModel.getAdditionalData(), res);
            VizPayMerchantRequestModel vizPayMerchantRequest = createVizPayMerchantRequest(merchantMasterModel,targetConfigModel);
            JSONObject jsonObject = new JSONObject(new ObjectMapper().writeValueAsString(vizPayMerchantRequest));
            try {
                res = callApiUsingWebClient(null, jsonObject.toString(), uploadTerminalApiUrl, null, httpHeaders);
            } catch (Exception e) {
                res = e.getMessage();
                logger.info("Exception while VizPay API Request : {} ", e.getMessage());
            }
            logger.info("API response for Vizpay Upload Terminal Api : {} \n", res);
            responseModel = IsgJsonUtils.getObjectFromJsonString(res, VizPayMerchantResponseModel.class);
            if (responseModel != null && responseModel.getResponseCode().equalsIgnoreCase("00")) {
                return responseModel;
            }
            if (responseModel != null && !StringUtils.isBlank(responseModel.getResponseMessage()) && !StringUtils.isBlank(responseModel.getResponseCode())) {
                String statusMessage = responseModel.getRspData().get(0).getStatusMessage();
                responseModel.setResMessage(responseModel.getResponseMessage() + statusMessage);
            }
        }
        if (responseModel == null) {
            responseModel = new VizPayMerchantResponseModel();
            responseModel.setResMessage(res);
        }
        return responseModel;
    }

    public MosambeeRegTidResponseModel callPosMosambeeMerchantRegisterTidApi(MosambeeMessageTransformation mosambeeMessageTransformation, MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel, String refId) {
        logger.info("Calling Pos Mosambee Merchant Register Tid API :  ");

        HttpHeaders httpHeaders = new HttpHeaders();
        Calendar date = Calendar.getInstance();
        long millisecondsDate = date.getTimeInMillis();
        String res;

        String clientId = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getClientId();
        String hmacUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getHmacUrl();
        String hmacKey = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getHmacKey();

        MosambeeRegTidRequestModel requestModel = mosambeeMessageTransformation.createMerchantTidRegister(merchantMasterModel,refId);
        String resEncryptData = getEncryptedPayloadForRegisterTidUrl(mosambeeMessageTransformation,requestModel,merchantMasterModel,targetConfigModel);
        JSONObject jsonForReqPayload = getJsonForReqPayload(resEncryptData,clientId);

        String hmacDataResult =  getHmacDataResult(hmacUrl,hmacKey,clientId,jsonForReqPayload,millisecondsDate);
        String registerTidUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getRegisterTidUrl();

        httpHeaders = buildMosambeeRegisterApiHeaders(clientId, hmacDataResult, millisecondsDate);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                res = callApiUsingWebClientProxy(null, jsonForReqPayload + "", registerTidUrl, null, httpHeaders);
            } else {
                res = callApiUsingWebClient(null, jsonForReqPayload + "", registerTidUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            res = e.getMessage();
            logger.info("Exception while Registration  API Request : {} ", e.getMessage());
        }
        MosambeeRegTidResponseModel responseModel = IsgJsonUtils.getObjectFromJsonString(res, MosambeeRegTidResponseModel.class);

        if (responseModel == null) {
            responseModel = new MosambeeRegTidResponseModel();
            responseModel.setResMessage(res);
        } else {
            responseModel.setResMessage(responseModel.getMessage());
        }
        return responseModel;
    }

    private String getHmacDataResult(String hmacUrl,String hmacKey,String clientId,JSONObject jsonForReqPayload, long millisecondsDate) {
        String hmacRes;
        HttpHeaders httpHeaders = buildMosambeeHmacHeaders(hmacKey);
        String hmacReq = createHmacRequest(clientId, jsonForReqPayload, millisecondsDate);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                hmacRes = callApiUsingWebClientProxy(null, hmacReq, hmacUrl, null, httpHeaders);
            } else {
                hmacRes = callApiUsingWebClient(null, hmacReq, hmacUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            hmacRes = e.getMessage();
            logger.info("Exception while HMAC API Request : {} ", e.getMessage());
        }
        return hmacRes;
    }

    private JSONObject getJsonForReqPayload(String res,String clientId) {
        JSONObject jsonForReqPayload = new JSONObject();
        jsonForReqPayload.put("clientId", clientId);
        jsonForReqPayload.put("encRequestMsg", res);
        return jsonForReqPayload;
    }

    private String getEncryptedPayloadForRegisterAndEditUrl(MosambeeMessageTransformation mosambeeMessageTransformation, MosambeeRequestModel requestModel, MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) {
        String resEncrpt;
        String encryptionUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getEncryptionUrl();
        HttpHeaders httpHeaders = buildMosambeeEncryptionHeaders(targetConfigModel);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                resEncrpt = callApiUsingWebClientProxy(null, IsgJsonUtils.getJsonString(requestModel), encryptionUrl, null, httpHeaders);
            } else {
                resEncrpt = callApiUsingWebClient(null, IsgJsonUtils.getJsonString(requestModel), encryptionUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            resEncrpt = e.getMessage();
            logger.info("Exception while Encryption API Request : {} ", e.getMessage());
        }
        return resEncrpt;
    }

    private String getEncryptedPayloadForUpdateStatusUrl(MosambeeMessageTransformation mosambeeMessageTransformation, MosambeeUpdateStatusRequestModel requestModel, MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) {
        String resEncrpt;
        String encryptionUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getEncryptionUrl();
        HttpHeaders httpHeaders = buildMosambeeEncryptionHeaders(targetConfigModel);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                resEncrpt = callApiUsingWebClientProxy(null, IsgJsonUtils.getJsonString(requestModel), encryptionUrl, null, httpHeaders);
            } else {
                resEncrpt = callApiUsingWebClient(null, IsgJsonUtils.getJsonString(requestModel), encryptionUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            resEncrpt = e.getMessage();
            logger.info("Exception while Encryption API Request : {} ", e.getMessage());
        }
        return resEncrpt;
    }
    private String getEncryptedPayloadForRegisterTidUrl(MosambeeMessageTransformation mosambeeMessageTransformation, MosambeeRegTidRequestModel requestModel, MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) {
        String resEncrpt;
        String encryptionUrl = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getEncryptionUrl();
        HttpHeaders httpHeaders = buildMosambeeEncryptionHeaders(targetConfigModel);
        try {
            if (MTMProperties.getProperty("mosambee.proxy.required").equalsIgnoreCase("Y")) {
                resEncrpt = callApiUsingWebClientProxy(null, IsgJsonUtils.getJsonString(requestModel), encryptionUrl, null, httpHeaders);
            } else {
                resEncrpt = callApiUsingWebClient(null, IsgJsonUtils.getJsonString(requestModel), encryptionUrl, null, httpHeaders);
            }
        } catch (Exception e) {
            resEncrpt = e.getMessage();
            logger.info("Exception while Encryption API Request : {} ", e.getMessage());
        }
        return resEncrpt;
    }


    private HttpHeaders buildMosambeeRegisterApiHeaders(String clientId,String hmacRes, long millisecondsDate) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("clientId", clientId);
        headers.set("Content-Type", "application/json");
        headers.set("dateTime", String.valueOf(millisecondsDate));
        headers.set("hmac", hmacRes);
        return headers;
    }

    public String createHmacRequest(String clientId, JSONObject jsonForReqPayload, long millisecondsDate) {
        String reqPayload = clientId + millisecondsDate + jsonForReqPayload;
        return reqPayload;
    }

    private HttpHeaders buildMosambeeHmacHeaders(String hmacKey) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("hmacKey", hmacKey);
        return headers;
    }

    private HttpHeaders buildMosambeeEncryptionHeaders(TargetConfigModel targetConfigModel) {
        String secretKey = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getSecretKey();
        String nonce = targetConfigModel.getAdditionalData().getApiInfo().getMosambeeData().getNonce();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("secretKey", secretKey);
        headers.set("nonce", nonce);
        return headers;
    }

    private VizPayMerchantRequestModel createVizPayMerchantRequest(MerchantMasterModel merchantMasterModel,TargetConfigModel targetConfigModel) {
        VizPayMerchantRequestModel requestModel = new VizPayMerchantRequestModel();
        requestModel.setSourceId(targetConfigModel.getAdditionalData().getApiInfo().getVizPay().getSourceId());
        requestModel.setParticipantId(targetConfigModel.getAdditionalData().getApiInfo().getVizPay().getParticipantId());

        List<VizPayMerchantRequestModel.MidTid> midTids = new ArrayList<>();
        VizPayMerchantRequestModel.MidTid requestModelForMidTid = new VizPayMerchantRequestModel.MidTid();
        requestModelForMidTid.setTid(merchantMasterModel.getTid());
        requestModelForMidTid.setMerchantName(merchantMasterModel.getMerchantName());
        requestModelForMidTid.setMid(merchantMasterModel.getMid());
        requestModelForMidTid.setMccCode(merchantMasterModel.getMccCode());
        requestModelForMidTid.setMccDesc(merchantMasterModel.getMccCode());
        requestModelForMidTid.setAddress(merchantMasterModel.getMerchantAddress());
        requestModelForMidTid.setState("");
        requestModelForMidTid.setStateCode(merchantMasterModel.getMerchantStateCode());
        requestModelForMidTid.setPincode(merchantMasterModel.getMerchantPincode().toString());
        requestModelForMidTid.setCity(merchantMasterModel.getMerchantCity());
        requestModelForMidTid.setEmailId(merchantMasterModel.getMerchantEmail());
        requestModelForMidTid.setMobileNo(merchantMasterModel.getMerchantMobNo());
        requestModelForMidTid.setUpiId("ibkPOS."+merchantMasterModel.getTid()+"@icici");
        requestModelForMidTid.setTerminalType("2");
        requestModelForMidTid.setTerminalModel("QR70");
        requestModelForMidTid.setSoundboxLanguage(getSbLanguageCode(merchantMasterModel.getSbLanguage()));
        requestModelForMidTid.setDcc("0");
        requestModelForMidTid.setTip("0");
        requestModelForMidTid.setPreauth("0");
        requestModelForMidTid.setCcEmiFlag("0");
        requestModelForMidTid.setDcEmiFlag("0");
        requestModelForMidTid.setBrandEmiFlag("0");
        requestModelForMidTid.setBrandCcEmiFlag("0");
        requestModelForMidTid.setBrandDcEmiFlag("0");
        requestModelForMidTid.setAggregatorCode(CacheSrConfigProperties.getProperty("sb.aggregator.code"));
        requestModelForMidTid.setInternationalFlag("1");
        requestModelForMidTid.setAcqBank(CacheSrConfigProperties.getProperty("sb.acq.bank"));
        midTids.add(requestModelForMidTid);

        requestModel.setMidTid(midTids);
        return requestModel;
    }

    private String getSbLanguageCode(String sbLanguage){
        String value = null;
        if(!StringUtils.isBlank(sbLanguage)){
            switch (sbLanguage){
                case "HINDI":
                    value = "HI";
                    break;
                case "GUJARATI":
                    value = "GJ";
                    break;
                case "ODIA":
                    value = "OD";
                    break;
                case "MARATHI":
                    value = "MR";
                    break;
                default:
                    value = "EN";
                    break;
            }
        }
        return value;
    }

    private HttpHeaders buildVizPayApiHeader(TargetAdditionalData additionalData, String generatedAccessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(generatedAccessToken);
        headers.add("apikey",additionalData.getApiInfo().getVizPay().getVizpayApiKey());
        return headers;
    }


    private String generateVizPayApiAccessToken(TargetAdditionalData targetAdditionalData) {
        String accessTokenApiUrl = targetAdditionalData.getApiInfo().getVizPay().getAccessTokenApiUrl();
        String res;
        try {
            HttpHeaders headers = buildVizPayAccessTokenApiHeader(targetAdditionalData);
            headers.setContentType(MediaType.APPLICATION_JSON);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("clientname", targetAdditionalData.getApiInfo().getVizPay().getClientName());
            jsonObject.put("clientkey", targetAdditionalData.getApiInfo().getVizPay().getClientKey());
            res = callApiUsingWebClient(null, jsonObject.toString(), accessTokenApiUrl, null, headers);
            if (res != null && !res.startsWith("Error ::")) {
                res = new JSONObject(res).getString("token");
            }
        } catch (Exception e) {
            res = "Error ::" + e.getMessage();
            logger.info("Exception while calling Vizpay Generate Access Token API Request : {} ", e.getMessage());
        }
        return res;
    }

    private HttpHeaders buildVizPayAccessTokenApiHeader(TargetAdditionalData additionalData) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("apikey",additionalData.getApiInfo().getVizPay().getVizpayApiKey());
        return headers;
    }

    public HitachiMerchantResponseModel callHitachiCreateMerchantApi(HitachiMessageTransformation hitachiMessageTransformation,
                                                                     MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel) throws JsonProcessingException {
        logger.info("Calling Hitachi Merchant API :  ");
        String res;
        res = hitachiMessageTransformation.generateHitachiApiAccessToken(targetConfigModel.getAdditionalData(),merchantMasterModel);
        HitachiMerchantResponseModel responseModel = null;
        if (!StringUtils.isBlank(res) && !res.startsWith("Error ::")) {
            String uploadTerminalApiUrl = targetConfigModel.getAdditionalData().getApiInfo().getHitachi().getHitachiMerchantUrl();
            HttpHeaders httpHeaders = buildHitachiApiHeader(res);
            HitachiMerchantRequestModel hitachiMerchantRequest = hitachiMessageTransformation.createMerchant(merchantMasterModel);
            JSONObject jsonObject = new JSONObject(new ObjectMapper().writeValueAsString(hitachiMerchantRequest));
            try {
                res = callApiUsingWebClient(null, jsonObject.toString(), uploadTerminalApiUrl, null, httpHeaders);
            } catch (Exception e) {
                res = e.getMessage();
                logger.info("Exception while Hitachi API Request : {} ", e.getMessage());
            }
            logger.info("API response for Hitachi Upload Terminal Api : {} \n", res);
            responseModel = IsgJsonUtils.getObjectFromJsonString(res, HitachiMerchantResponseModel.class);
            if (responseModel != null && responseModel.getResponseCode().equalsIgnoreCase("00")) {
                return responseModel;
            }
            if (responseModel != null && !StringUtils.isBlank(responseModel.getResponseMessage()) && !StringUtils.isBlank(responseModel.getResponseCode())) {
                responseModel.setResMessage(responseModel.getResponseMessage());
            }
        }
        if (responseModel == null) {
            responseModel = new HitachiMerchantResponseModel();
            responseModel.setResMessage(res);
        }
        return responseModel;
    }

    private HttpHeaders buildHitachiApiHeader(String generatedAccessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(generatedAccessToken);
        return headers;
    }
}