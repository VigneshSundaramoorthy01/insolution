package com.isg.mw.routing.exception;

/**
 * 
 * @author shital3986
 *
 */
public class PosRefundTxnCountException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PosRefundTxnCountException(String errorMsg) {
		super(errorMsg);
	}

	public PosRefundTxnCountException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}
