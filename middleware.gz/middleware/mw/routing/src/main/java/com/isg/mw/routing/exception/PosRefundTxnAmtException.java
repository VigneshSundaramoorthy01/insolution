package com.isg.mw.routing.exception;

/**
 * 
 * @author shital3986
 *
 */
public class PosRefundTxnAmtException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PosRefundTxnAmtException(String errorMsg) {
		super(errorMsg);
	}

	public PosRefundTxnAmtException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}
