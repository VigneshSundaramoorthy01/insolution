package com.isg.mw.routing.exception;

public class TransactionDateExceededException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    private Object[] args = null;

    public TransactionDateExceededException(String errorMsg) {
        super(errorMsg);
    }

    public TransactionDateExceededException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

    public TransactionDateExceededException(String msg, Object ... args) {
        super(msg);
        this.args = args;
    }

    public Object[] getArgs() {
        return args;
    }
}
