package com.isg.mw.routing.route;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.routing.route.ITransactionProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TransactionProcessorFactory {

    @Autowired
    private List<ITransactionProcessor> transactionProcessorList;

    private static Map<SourceProcessor, ITransactionProcessor> transactionProcessorCache = new HashMap<>();

    @PostConstruct
    public void initTransactionProcessors() {
        transactionProcessorList.forEach(transactionProcessor ->
                transactionProcessorCache.put(transactionProcessor.getSourceProcessor(), transactionProcessor));
    }

    public static ITransactionProcessor getTransactionProcessor(SourceProcessor sourceProcessor) {
        return transactionProcessorCache.get(sourceProcessor);
    }
}
