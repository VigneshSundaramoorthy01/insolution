package com.isg.mw.routing.route.codec;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;

@ChannelHandler.Sharable
public class BinaryFileEncoder extends MessageToMessageEncoder<String> {
	private Logger logger = LogManager.getLogger(getClass());

	@Override
	protected void encode(ChannelHandlerContext ctx, String msg, List<Object> out) throws Exception {
		ByteBuf buf = ByteBufAllocator.DEFAULT.buffer(msg.length());
//		String schemeType = msg.substring(0, msg.indexOf("|"));
//		logger.trace("Scheme type encoder: {}", schemeType);
//		String rawMsg = msg.substring(msg.indexOf("|") + 1);
//		logger.trace("Raw msg in encoder: {}", rawMsg);
		byte[] encode = null;
//		if (schemeType.equals("pos")) {
//			encode = encode(rawMsg, 2);
//		} else if (schemeType.equals("visa")) {
//			encode = encode(rawMsg, 4);
//		}
		encode = encode(msg, 4);
		buf.writeBytes(encode); // 4 lenght is for VISA
		out.add(buf);
		logger.trace("BinaryFileEncoder encode method called:: ChannelHandlerContext: {}, Message: {}, Out object: {}",
				ctx, encode, out);
	}

	static int oneDigitHexToDec(char c) {
		int b = 0;
		switch (c) {
		case 'A':
			b = 10;
			break;
		case 'B':
			b = 11;
			break;
		case 'C':
			b = 12;
			break;
		case 'D':
			b = 13;
			break;
		case 'E':
			b = 14;
			break;
		case 'F':
			b = 15;
			break;
		case 'a':
			b = 10;
			break;
		case 'b':
			b = 11;
			break;
		case 'c':
			b = 12;
			break;
		case 'd':
			b = 13;
			break;
		case 'e':
			b = 14;
			break;
		case 'f':
			b = 15;
			break;
		default:
			b = c - '0';
			assert (b > 0 && b < 10) : "Invalid digit in raw message, can't conevrt to decimal";
		}
		return b;
	}

	/*
	 * Converst two digits hex into decimal. Input range: 00-FF Output range: -128
	 * to 127
	 */
	static byte twoDigitsHexToDecimal(char c1, char c2) {
		byte ch = 0;

		ch = (byte) (ch | oneDigitHexToDec(c1));
		ch = (byte) (ch << 4);

		if (c2 != 'Z') {
			ch = (byte) (ch | oneDigitHexToDec(c2));
		}

		return ch;
	}

	static byte[] encode(String rawMsgHex, int totMsgLengthLength) {
		int LoopCounter = 0;
		int intsize2, intsize3;
		char c5, c6;
		byte c4;
		int rawMsgDecimalArrLength = totMsgLengthLength;

		char[] rawMsgHexArr = rawMsgHex.toCharArray();
//		System.out.println("rawMsgHexArr length= " + rawMsgHexArr.length);
		byte[] rawMsgDecimalArr = new byte[rawMsgHexArr.length / 2 + rawMsgHexArr.length % 2 + totMsgLengthLength];

		for (LoopCounter = 0; LoopCounter < rawMsgHexArr.length; LoopCounter++) {
			c5 = rawMsgHexArr[LoopCounter++];
			if (LoopCounter < rawMsgHexArr.length) {
				c6 = rawMsgHexArr[LoopCounter];
			} else {
				c6 = 'Z';
			}
			c4 = twoDigitsHexToDecimal(c5, c6);
//			System.out.println("" + rawMsgDecimalArrLength + "\n");
			rawMsgDecimalArr[rawMsgDecimalArrLength++] = c4;
		}

		rawMsgDecimalArrLength -= totMsgLengthLength;
		intsize2 = rawMsgDecimalArrLength / 256;
		intsize3 = rawMsgDecimalArrLength % 256;
//		System.out.println("rawMsgDecimalArrLength=" + rawMsgDecimalArrLength + ", intsize2= " + intsize2
//				+ ", intsize3=" + intsize3 + "\n");

		String lenStr = String.format("%c%c", intsize2, intsize3);
		byte[] size1 = lenStr.getBytes();
		rawMsgDecimalArr[0] = size1[0];
		rawMsgDecimalArr[1] = size1[1];
		if (totMsgLengthLength == 4) {// Visa
			rawMsgDecimalArr[2] = 0;
			rawMsgDecimalArr[3] = 0;
			/*
			 * Update 4th byte of Header, applicable only for visa
			 */
			rawMsgDecimalArr[7] = size1[0];
			rawMsgDecimalArr[8] = size1[1];
		}
//		System.out.println("rawMsgDecimalArr.length= " + rawMsgDecimalArr.length + "\n");
		return (rawMsgDecimalArr);
	}
}