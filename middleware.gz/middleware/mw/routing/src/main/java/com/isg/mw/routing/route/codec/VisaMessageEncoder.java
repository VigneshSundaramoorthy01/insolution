package com.isg.mw.routing.route.codec;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.EbcdicHexInterpreter;
import org.jpos.iso.ISOUtil;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;

@ChannelHandler.Sharable
public class VisaMessageEncoder extends MessageToMessageEncoder<String> {
	private Logger logger = LogManager.getLogger(getClass());

	private static final byte[] HEX_EBCDIC = new byte[] { (byte) 0xF0, (byte) 0xF1, (byte) 0xF2, (byte) 0xF3,
			(byte) 0xF4, (byte) 0xF5, (byte) 0xF6, (byte) 0xF7, (byte) 0xF8, (byte) 0xF9, (byte) 0xC1, (byte) 0xC2,
			(byte) 0xC3, (byte) 0xC4, (byte) 0xC5, (byte) 0xC6 };

	@Override
	protected void encode(ChannelHandlerContext ctx, String msg, List<Object> out) throws Exception {
		ByteBuf buf = ByteBufAllocator.DEFAULT.buffer(msg.length());
		logger.trace("Visa Message before encoding: {}", msg);
		ISOUtil.byte2hex(msg.getBytes());
		buf.writeBytes(msg.getBytes()); // 4 length is for VISA
		out.add(buf);
		logger.trace("Visa Message after encoding: {}", buf);
	}

	public void interpret(byte[] data, byte[] b, int offset) {
		for (int i = 0; i < data.length; i++) {
			b[offset + i * 2] = HEX_EBCDIC[(data[i] & 0xF0) >> 4];
			b[offset + i * 2 + 1] = HEX_EBCDIC[data[i] & 0x0F];
		}
	}

}