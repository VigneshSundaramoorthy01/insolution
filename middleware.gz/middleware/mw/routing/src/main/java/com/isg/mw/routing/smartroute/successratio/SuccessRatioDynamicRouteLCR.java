package com.isg.mw.routing.smartroute.successratio;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_API_TXN_MODEL;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

import java.util.*;
import java.util.stream.Collectors;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.routing.exception.PaymentOptionMismatchException;
import org.apache.commons.lang3.StringUtils;
import com.isg.mw.cache.mgmt.config.CacheTargetPaymentModeAndOptions;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.isg.mw.cache.mgmt.config.TargetLcrKey;
import com.isg.mw.cache.mgmt.config.TargetLcrValue;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.smartroute.lcr.LeastCostRoute;
import org.springframework.util.CollectionUtils;

@Component
public class SuccessRatioDynamicRouteLCR extends SuccessRatioDynamicRoute {

    private final Logger logger = LogManager.getLogger();

    @Autowired
    private LeastCostRoute leastCostRoute;

    @Autowired
    private CacheServices cacheService;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    /**
     * Filters applied to get the target
     * Get the merchant from MID
     * If merchant MCR is enabled
     * get the merchant preferred target from cache
     * KEY: (entityId + mid + payModeId)
     * VALUE: (targetid, startDate, endDate)
     * get the targetconfigmode from the above target id
     * Else
     * 1. Get the targets based on success ratio
     * 2. Get the target based on selected payment mode from step 1 returned targets
     * 3. Get the lowest cost target from the step 2 returned targets
     *
     * @param exchange
     * @return
     */

    @Override
    public TargetConfigModel getTxnTarget(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        ApiTxnModel apiTxnModel = (ApiTxnModel) exchange.getIn().getHeader(EXCHANGE_HEADER_API_TXN_MODEL);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        // validate the merchant
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(sourceConfigModel.getEntityId(), apiTxnModel.getMid());
        // if merchant MCR is enabled then get its preferred target
        if (merchantMaster != null && !StringUtils.isBlank(merchantMaster.getMcrEnabled()) && merchantMaster.getMcrEnabled().equalsIgnoreCase("Y")) {
            return validateMerchantChoiceRouting(apiTxnModel, routingContext, merchantMaster);
        }
        //
        else {
            List<Long> targetIdList = validateTargetOptionAvailability(apiTxnModel, routingContext,reqSrcTmm);
            if (targetIdList != null && !targetIdList.isEmpty()) {
                List<TargetConfigModel> txnTargetList = getTxnTargetList(exchange);
                if (!CollectionUtils.isEmpty(targetIdList)) {
                    List<Long> finalTargetIdList = targetIdList;
                    txnTargetList = txnTargetList.stream().filter(targetConfigModel -> finalTargetIdList.contains(targetConfigModel.getId())).collect(Collectors.toList());
                    // filter target based on LCR
                    Map<TargetLcrKey, Set<TargetLcrValue>> targetLCRData = cacheUtil.getTargetLCRData(routingContext.getSource().getEntityId());
                    return getTargetByLCR(apiTxnModel, routingContext, txnTargetList, targetLCRData);
                }
            } else {
                throw new PaymentOptionMismatchException("Payment option mismatch for given payment mode Id : " + apiTxnModel.getPayModeId() + " and payment mode option: " + apiTxnModel.getPayModeOptionId(), routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
            }
        }
        return null;

    }


    private TargetConfigModel getTargetIfPanAbsent(RoutingContext routingContext, SourceConfigModel sourceConfigModel, List<TargetConfigModel> txnTargetList) {
        Optional<TargetConfigModel> targetConfigModel1 = null;
        int srcTotalTxnCount = cacheUtil.getSourceTotalTxnCount(cacheHelper.getSourceMapKey(sourceConfigModel),
                sourceConfigModel.getId().toString());
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        for (TargetConfigModel targetConfigModel : txnTargetList) {
            TargetInfo targetInfo = targets.get(new TargetKey(targetConfigModel.getId().toString()));
            Double computedRoutingPercent = ((double) targetInfo.getTotalTxnCount() / (double) srcTotalTxnCount) * 100;
            double currentRoutingPercent = (double) 100 / (double) txnTargetList.size();
            boolean isTargetEligible = computedRoutingPercent.compareTo(currentRoutingPercent) < 0;
            if (isTargetEligible && targetInfo.isAlive()) {
                targetConfigModel1 = routingContext.getTargets().stream().filter(tgtConfigModel -> tgtConfigModel.getId().toString().equals(targetConfigModel.getId().toString())).findFirst();
            }
            if (targetConfigModel1 != null && targetConfigModel1.isPresent()) {
                break;
            }
        }
        if (targetConfigModel1 != null && targetConfigModel1.isPresent()) {
            return targetConfigModel1.get();
        }
        return null;
    }

    private TargetConfigModel getTargetByLCR(ApiTxnModel apiTxnModel, RoutingContext routingContext, List<TargetConfigModel> txnTargetList, Map<TargetLcrKey, Set<TargetLcrValue>> targetLCRData) {
        BinInfoModel binInfoModel = cacheService.getSchemeBin(!StringUtils.isBlank(apiTxnModel.getCardNo())?apiTxnModel.getCardNo().replaceAll(" ",""):null);
        String cardCategory = null;
        if (binInfoModel != null) {
            cardCategory = binInfoModel.getCardCategory();
        }
        TargetLcrKey targetLcrKey = new TargetLcrKey(Long.parseLong(apiTxnModel.getPayModeId()),!StringUtils.isBlank(apiTxnModel.getPayModeOptionId())
                ? Long.parseLong(apiTxnModel.getPayModeOptionId()):null, apiTxnModel.getMcc(), cardCategory);
        Set<TargetLcrValue> targetLcrValues = targetLCRData.get(targetLcrKey);
        if (!txnTargetList.isEmpty() && targetLcrValues != null && !targetLcrValues.isEmpty()) {
            Set<Long> targetIds = txnTargetList.stream().map(TargetConfigModel::getId).collect(Collectors.toSet());
            targetLcrValues = targetLcrValues.stream().filter(lcrValue -> targetIds.contains(lcrValue.getTargetId())).collect(Collectors.toSet());
            return leastCostRoute.getTargetConfigModel(routingContext, apiTxnModel, targetLcrValues);
        } else if (txnTargetList.size() == 1) {
            return getTargetConfigById(routingContext, String.valueOf(txnTargetList.get(0).getId()));
        }
        return null;
    }

    private boolean getTargetPayModeAndOptionsData(RoutingContext routingContext, TargetConfigModel targetConfigModel, ApiTxnModel apiTxnModel) {
        CacheTargetPaymentModeAndOptions targetPayModeAndOptionsData = srCacheService.getTargetPayModeAndOptionsData(routingContext.getEntityId(), targetConfigModel.getId().toString(), apiTxnModel.getPayModeId(), apiTxnModel.getPayModeOptionId());
        if (targetPayModeAndOptionsData != null && targetPayModeAndOptionsData.getTargetPaymentMode() != null && targetPayModeAndOptionsData.getTargetPaymentModeOptions() != null) {
            return true;
        }
        return false;
    }

    /**
     * Get the targets which have success ratio more than threshold
     *
     * @param exchange Exchange object flowing for the current transaction
     * @return List of targets
     */
    public List<TargetConfigModel> getTxnTargetList(Exchange exchange) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
        logger.info("Getting targets for the source: {}", sourceConfigModel.getName());
        List<TargetConfigModel> targetConfigModels = new ArrayList<>();
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));

        if (allTargetsAreAlive(targets, null)) {
            if (successRatioSortedList.get(sourceConfigModel.getId().toString()) != null) {
                for (TargetKey targetKey : successRatioSortedList.get(sourceConfigModel.getId().toString())) {
                    setTargetList(routingContext, targets, targetKey, targetConfigModels, smartRouteConfigModel);
                }
            } else {
                for (TargetKey targetKey : targets.keySet()) {
                    TargetConfigModel targetConfigById = getTargetConfigById(routingContext, targetKey.getTargetId());
                    targetConfigModels.add(targetConfigById);
                }
            }
        }
        logger.info("Multiple targets identified for the source: {} is {}", sourceConfigModel.getName(),
                Arrays.toString(targetConfigModels.toArray()));
        return targetConfigModels;
    }

    private void setTargetList(RoutingContext routingContext, Map<TargetKey, TargetInfo> targets, TargetKey targetKey, List<TargetConfigModel> targetConfigModels, SmartRouteConfigModel smartRouteConfigModel) {
        TargetInfo targetInfo = targets.get(targetKey);
        Double targetSuccessThreshold = targetInfo.getPreviousSuccessRatio();
        if (targetSuccessThreshold.compareTo(smartRouteConfigModel.getSuccessThreshold()) > 0 && targetInfo.isAlive()) {
            TargetConfigModel targetConfigById = getTargetConfigById(routingContext, targetKey.getTargetId());
            targetConfigModels.add(targetConfigById);
        }
    }

    @Override
    public RouteType getRouteType() {
        return RouteType.SUCCESS_RATIO_DYNAMIC_LCR;
    }

}
