package com.isg.mw.routing.consumer;

import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.deserializers.MerchantMasterDeserializer;
import com.isg.mw.cache.mgmt.service.SmartRouteConfigService;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import com.isg.mw.routing.consumer.service.MerchantMasterService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * Consume the MapsInfo & MerchantMaster from kafka topic and push it to cache.
 */
@Component
public class LyraMerchantConsumer implements ApplicationRunner {
    private static final Logger logger = LogManager.getLogger(LyraMerchantConsumer.class);

    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

//    @Autowired
//    private TargetMerchantMasterMessenger targetMerchantMasterMessenger;

    @Autowired
    private MerchantMasterService merchantMasterService;

    @Autowired
    private SmartRouteConfigService smartRouteConfigService;

    /**
     * This method consume maps info model from kafka topic using reusable kafka
     * component.
     */

    @Override
    public void run(ApplicationArguments args) throws Exception {
        // change following logger
        logger.info("Maps info & Merchant Master Kafka Consumer Method Call");
        try {
            KafkaConsumer consumer1 = new KafkaConsumer(cacheKafkaConfig
                    .getKafkaConfig(cacheKafkaConfig.getOnboardMerchantMasterTopicName(), MerchantMasterDeserializer.class,
                            "Lyra_Sr_" + cacheKafkaConfig.getSrCommonGroupId() + "_"+
                                    cacheKafkaConfig.getOnboardMerchantMasterTopicName()),
                    this, "cacheMerchantMasterConsumer");
            consumer1.init();
            logger.info("Lyra Merchant Master Kafka Consumer Initialization Done...");
        } catch (Exception e) {
            logger.error("Exception While Consuming MapsInfo & Merchant Master: ", e);
        }
    }

    /**
     * This method store data into mapsInfocache
     *
     * @param merchantMasterModel
     */
    public void cacheMerchantMasterConsumer(MerchantMasterModel merchantMasterModel) {
        if (merchantMasterModel.getIsOnboardEnable()) {
            try {
                List<TargetMerchantMasterModel> targetMerchantMasterModels = merchantMasterService.
                        getTargetMerchantMasterModels(merchantMasterModel, LyraMessageTransformation.class, TargetType.Lyra.name());
                if(!CollectionUtils.isEmpty(targetMerchantMasterModels)) {
                    for (TargetMerchantMasterModel tMerMasterModel : targetMerchantMasterModels) {
                        if (!StringUtils.isBlank(tMerMasterModel.getTargetMid())) {
                            merchantMasterService.sendTargetMerchantMasterToCm(tMerMasterModel);
                            Boolean flag = smartRouteConfigService.updateTargetMerchantMasterCache(tMerMasterModel);
                            if(merchantMasterModel.getIntegrationType().equalsIgnoreCase("Pos")) {
                                if (flag == true) {
                                    logger.info("Added Entry For Lyra in Spring Cache Successfully: ");
                                }
                            }

//                                logger.error("Redis Cache Updated Successfully for Target Id : {} ", tMerMasterModel.getTargetId());
//                                merchantMasterService.sendTargetMerchantMasterToCm(tMerMasterModel);
////                                targetMerchantMasterMessenger.send(tMerMasterModel);
//                            }
                        }
                    }
                }
            } catch (Exception e) {
                logger.error("Exception while updating maps info cache: ", e);
            }
        }
    }

}
