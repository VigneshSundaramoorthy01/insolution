//package com.isg.mw.routing.smartroute;
//
//import com.isg.mw.cache.mgmt.config.CacheUtil;
//import com.isg.mw.cache.mgmt.config.MerchOrdTxnData;
//import com.isg.mw.core.model.constants.SourceProcessor;
//import com.isg.mw.core.model.sc.SourceConfigModel;
//import com.isg.mw.core.model.tc.TargetConfigModel;
//import com.isg.mw.mtm.transform.IMessageTransformation;
//import com.isg.mw.mtm.transform.IMessageTransformationFactory;
//import com.isg.mw.routing.context.RoutingContext;
//import com.isg.mw.routing.route.TransactionProcessorHelper;
//import lombok.Setter;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//import org.springframework.util.CollectionUtils;
//
//import java.time.Duration;
//import java.time.OffsetDateTime;
//import java.util.Map;
//
//@Component
//public class CheckTxnStatusTask implements Runnable {
//    private Logger logger = LogManager.getLogger();
//
//    @Setter
//    private RoutingContext routingContext;
//
//    public CheckTxnStatusTask() {
//    }
//
//    @Autowired
//    private CacheUtil cacheUtil;
//
//    @Value("${smartroute.txn.cache.expiration.minutes:30}")
//    private long cacheDurationLimit;
//
//    @Autowired
//    private TransactionProcessorHelper processorHelper;
//
//    @Override
//    public void run() {
//        logger.info("Start Scheduler to fetch records for pending status : ");
//        SourceConfigModel source = routingContext.getSource();
//        String flag;
//        if (source.getSourceProcessor() == SourceProcessor.SMART_ROUTE) {
//            String entityId = source.getEntityId();
//            Map<String, MerchOrdTxnData> txnDataEntries = cacheUtil.getTxnDataEntries(entityId);
////            logger.trace("MerchOrdTxnData entries in cache before process : "+txnDataEntries+" having size : "+txnDataEntries.size());
//            for (Map.Entry<String, MerchOrdTxnData> merchOrdTxnDataEntry : txnDataEntries.entrySet()) {
//                MerchOrdTxnData merchOrdTxnData = merchOrdTxnDataEntry.getValue();
//                String mid = merchOrdTxnDataEntry.getKey().split("::")[0];
//                String merchantOrderId = merchOrdTxnDataEntry.getKey().split("::")[1];
//                Map<String, MerchOrdTxnData.TxnData> txnDataMapModel = merchOrdTxnData.getTxnDataMapModel();
////                if (isTxnDataMapModelMapEmpty(txnDataMapModel) && isDurationComplete(merchOrdTxnData.getCreatedAt())) {
////                    cacheUtil.removeTxnData(entityId, mid, merchantOrderId);
////                    logger.trace("Successfully remove merchOrdTxnData having mid : "+mid+" and merchantOrderId "+merchantOrderId);
////                } else {
//                    if (!CollectionUtils.isEmpty(txnDataMapModel)) {
//                        for (Map.Entry<String, MerchOrdTxnData.TxnData> txnDataEntry : txnDataMapModel.entrySet()) {
//                            String targetId = txnDataEntry.getValue().getTargetId();
//                            String transactionId = txnDataEntry.getKey();
//                            String originalHashedTxnId = txnDataEntry.getValue().getOriginalHashedTxnId();
//                            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getId().toString().equals(targetId)).findFirst().get();
//                            try {
//                                IMessageTransformation iMessageTransformation = IMessageTransformationFactory.getMessageTransformation(targetConfigModel1.getTargetType());
//                                flag = iMessageTransformation.verifyPaymentStatusByTransactionId(originalHashedTxnId);
//                                setTxnStatus(merchOrdTxnData, txnDataMapModel, txnDataEntry.getValue(), entityId, merchOrdTxnDataEntry.getKey(), transactionId, flag);
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        }
//                    }
////                }
//            }
//            txnDataEntries = cacheUtil.getTxnDataEntries(entityId);
////            logger.trace("MerchOrdTxnData entries in cache after process : "+txnDataEntries+" having size : "+txnDataEntries.size());
//        }
//    }
//
//    private void setTxnStatus(MerchOrdTxnData merchOrdTxnData, Map<String, MerchOrdTxnData.TxnData> txnDataMapModelMap, MerchOrdTxnData.TxnData txnDataValue, String entityId, String midAndMerRefNo, String transactionId, String flag) {
//        String[] splitMidAndMerRefNo = midAndMerRefNo.split("::");
//        String mid = splitMidAndMerRefNo[0];
//        String merchantTxnRefNo = splitMidAndMerRefNo[1];
//        if (flag.equalsIgnoreCase("Success")) {
//            logger.trace("Initiate reversal transaction");
//        } else if (txnDataValue.getTxnStatus().equalsIgnoreCase("Pending") && flag.equalsIgnoreCase("Failed")) {
//            txnDataValue.setTxnStatus("Failed");
//            txnDataMapModelMap.put(transactionId, txnDataValue);
//            merchOrdTxnData.setTxnDataMapModel(txnDataMapModelMap);
//            cacheUtil.putTxnData(entityId, mid, merchantTxnRefNo, merchOrdTxnData);
//        }
//    }
//
//    private boolean isTxnDataMapModelMapEmpty(Map<String, MerchOrdTxnData.TxnData> txnDataMapModel) {
//        return txnDataMapModel == null || txnDataMapModel.isEmpty();
//    }
//
//    private boolean isDurationComplete(OffsetDateTime createdAt) {
//        Duration duration = Duration.between(
//                createdAt.toLocalTime(),
//                OffsetDateTime.now().toLocalTime()
//        );
//        long durationDifference = duration.toMinutes();
//        return durationDifference > cacheDurationLimit ? true : false;
//    }
//
//}