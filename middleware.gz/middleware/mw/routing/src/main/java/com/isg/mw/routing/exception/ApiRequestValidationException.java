package com.isg.mw.routing.exception;

public class ApiRequestValidationException extends RuntimeException{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Object[] args = null;

    public ApiRequestValidationException(String errorMsg) {
        super(errorMsg);
    }

    public ApiRequestValidationException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

    public ApiRequestValidationException(String msg, Object ... args) {
        super(msg);
        this.args = args;
    }

    public Object[] getArgs() {
        return args;
    }
}
