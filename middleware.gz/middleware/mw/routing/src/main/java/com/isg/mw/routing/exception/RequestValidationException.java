package com.isg.mw.routing.exception;

public class RequestValidationException extends RuntimeException{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Object[] args = null;

    public RequestValidationException(String errorMsg) {
        super(errorMsg);
    }

    public RequestValidationException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

    public RequestValidationException(String msg, Object ... args) {
        super(msg);
        this.args = args;
    }

    public Object[] getArgs() {
        return args;
    }
}
