/**
 *
 */
package com.isg.mw.routing.route;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.SpringContextBridge;

import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.exception.IssuerUnavailableException;
import com.isg.mw.routing.exception.TargetNoResponseException;
import com.sun.xml.bind.v2.TODO;
import org.apache.camel.Exchange;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.context.RoutingContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import static com.isg.mw.mtm.transform.TmmConstants.EFTPOS_SCHEME_TYPE;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_TARGET_SCHEME;

/**
 * @author vidyasagar
 *
 */
@Service
@PropertySource("${spring.config.location}routing-config.properties")
public class SwitchRouter implements IRouter {

    @Autowired
    private CacheServices cacheService;

    private static Logger logger = LogManager.getLogger();

    public static int txnCount = 0;
    @Value("${eftpos.key.exchange.max.trxn.count:2048}")
    private int eftposKeyExchangeCountLimit;

    @Autowired
    private NetworkManagement networkManagement;
    public TargetConfigModel getTargetEndpoint(RoutingContext routingContext, Exchange exchange, Object routingParam) {

        TargetConfigModel targetConfigModel = null;
        String targetScheme = cacheService.getSchemeName((String) routingParam);

        logger.trace(LogUtils.buildLogMessage(routingContext.getEntityId(), null, null, null, " Target scheme: {}"), targetScheme);

        Optional<TargetConfigModel> targetConfig = routingContext.getTargets().stream()
                .filter(target -> target.getTargetType().name().equalsIgnoreCase(targetScheme)).findFirst();

        if (targetConfig.isPresent()) {

            targetConfigModel = targetConfig.get();
            // TODO: right now getting the target connection at 1st index (21/8 - To create a seperate issue and take it up)
            String targetIp = targetConfigModel.getConnections().get(0).getUrlOrIp();

            String port = targetConfigModel.getConnections().get(0).getPortOrHeaders();

            logger.debug(LogUtils.buildLogMessage(routingContext.getEntityId(), targetConfigModel.getName(), null, null,
                    "Target endpoint identified as: {}:{}"), targetIp, port);

            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_SCHEME,
                    NettyConfig.getProducerEndpoint(routingContext, targetIp + ":" + port));

        }
        return targetConfigModel;
    }

    @Override
    public TargetConfigModel getTargetEndpoint(RoutingContext routingContext, Exchange exchange,
                                               TransactionMessageModel tmm) {
        TargetConfigModel targetConfigModel = null;

        Optional<TargetConfigModel> targetConfig = routingContext.getTargets().stream()
                    .filter(target -> target.getName().equals(tmm.getTarget())).findFirst();

        if (targetConfig.isPresent()) {
            targetConfigModel = targetConfig.get();

            String targetIp = targetConfigModel.getConnections().get(0).getUrlOrIp();

            String port = targetConfigModel.getConnections().get(0).getPortOrHeaders();

            logger.debug(LogUtils.buildLogMessage(routingContext.getEntityId(), targetConfigModel.getName(), null, null,
                    "Target endpoint identified as: {}:{}"), targetIp, port);

            ConnectionType connectionType = targetConfigModel.getConnections().get(0).getType();
            if (connectionType == ConnectionType.ISO) {
                exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_SCHEME,
                        NettyConfig.getProducerEndpoint(routingContext, targetIp + ":" + port));
            }
        }
        return targetConfigModel;
    }

    @Override
    public TargetConfigModel getTargetEndpointNew(RoutingContext routingContext, Exchange exchange,
                                               TransactionMessageModel tmm) {
        TargetConfigModel targetConfigModel = new  TargetConfigModel();
        TargetConfigModel targetConfig = new  TargetConfigModel();
        List<TargetConfigModel> eftposActiveTargets = new LinkedList<>();
        Map<String, String> checkMapData = new HashMap<>();
        List<TargetConfigModel> finalTargetModel = new LinkedList<>();

        // target routing Changes for EftPos
        targetConfigModel = routingContext.getTargets().stream().filter(target -> target.getName().equals(tmm.getTarget())).findFirst().orElse(null);
        if (targetConfigModel != null) {
            if(targetConfigModel.getTargetType().name().equalsIgnoreCase(TargetType.EftPos.name())){
                String lastUsedLinkName =  SpringContextBridge.services().getCacheService().getActiveTargetId();

                Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
                Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(tmm.getEntityId());
                endpointInfoMap.forEach((targetIp, endpointInfo) -> {
                    if(endpointInfo.getTargetConfigModel().getTargetType().name().equalsIgnoreCase(TargetType.EftPos.name())
                             && endpointInfo.isConnectionAlive() == true && endpointInfo.isSignedOn() == true) {
                            eftposActiveTargets.add(endpointInfo.getTargetConfigModel());

                    }
                });
                logger.info("Active target List :: {}",eftposActiveTargets.size());

                if(eftposActiveTargets.size() > 0){
                    Map<String, List<TargetConfigModel>> tempTargetLinkName =eftposActiveTargets.stream().
                            collect(Collectors.groupingBy(targetName -> targetName.getName().substring(0, targetName.getName().length()-1)));
                    if(tempTargetLinkName.size() > 1){
                        tempTargetLinkName.forEach((linkName, targetList)-> {
                            if(finalTargetModel.size() ==0) {
                                if ((StringUtils.isBlank(lastUsedLinkName) || null == lastUsedLinkName)) {
                                    finalTargetModel.add(targetList.get(0));
                                    SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                                    SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, targetList.get(0).getConnections().get(0).getPortOrHeaders());
                                } else if ((!(linkName.equalsIgnoreCase(lastUsedLinkName)))) {
                                	String lastUsedLinkPort =  SpringContextBridge.services().getCacheService().getActiveTargetPort(linkName);
                                	if ((StringUtils.isBlank(lastUsedLinkPort) || null == lastUsedLinkPort)) {
                                		finalTargetModel.add(targetList.get(0));
                                        SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                                        SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, targetList.get(0).getConnections().get(0).getPortOrHeaders());
                                	} else {
                                		if (targetList.size() > 1) {
                                			for (TargetConfigModel target : targetList) {
                                    			if (! lastUsedLinkPort.equals(target.getConnections().get(0).getPortOrHeaders())) {
                                    				finalTargetModel.add(target);
                                    				SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                                    				SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, target.getConnections().get(0).getPortOrHeaders());
                                    			}
                                    		}
                                		} else {
                                			finalTargetModel.add(targetList.get(0));
                            				SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                            				SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, targetList.get(0).getConnections().get(0).getPortOrHeaders());
                                		}
                                	}
                                    
                                }
                            }
                        });
                    }else{
                        tempTargetLinkName.forEach((linkName, targetList) ->{
                        	/*finalTargetModel.add(targetList.get(0));
                            SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                            SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, targetList.get(0).getConnections().get(0).getPortOrHeaders());*/
                            if (targetList.size() > 1) {
                                for (TargetConfigModel target : targetList) {
                                    String lastUsedLinkPort =  SpringContextBridge.services().getCacheService().getActiveTargetPort(linkName);
                                    if(finalTargetModel.size() ==0) {
                                        if ((StringUtils.isBlank(lastUsedLinkPort) || null == lastUsedLinkPort)) {
                                            finalTargetModel.add(targetList.get(0));
                                            SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                                            SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, targetList.get(0).getConnections().get(0).getPortOrHeaders());
                                        } else if (!lastUsedLinkPort.equals(target.getConnections().get(0).getPortOrHeaders())) {
                                            finalTargetModel.add(target);
                                            SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                                            SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, target.getConnections().get(0).getPortOrHeaders());
                                        }
                                    }
                                }
                            } else {
                                finalTargetModel.add(targetList.get(0));
                                SpringContextBridge.services().getCacheService().putActiveTargetId(linkName);
                                SpringContextBridge.services().getCacheService().putActiveTargetPort(linkName, targetList.get(0).getConnections().get(0).getPortOrHeaders());
                            }
                        });


                    }
                }else {
                    // TODO: 13-03-2024 Handle the exception
                     throw new IssuerUnavailableException("No Active eftpos Target  Found !!");
                }
                targetConfigModel = finalTargetModel.get(0);
            }

            String targetIp = targetConfigModel.getConnections().get(0).getUrlOrIp();
            String port = targetConfigModel.getConnections().get(0).getPortOrHeaders();
            logger.debug(LogUtils.buildLogMessage(routingContext.getEntityId(), targetConfigModel.getName(), null, null,
                    "Target endpoint identified as: {}:{}"), targetIp, port);

            ConnectionType connectionType = targetConfigModel.getConnections().get(0).getType();
            if (connectionType == ConnectionType.ISO) {
                exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_SCHEME, NettyConfig.getProducerEndpoint(routingContext, targetIp + ":" + port));
            }

            // put active userId for eftpos multiple targets
            if (TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(targetConfigModel.getTargetType().name())) {
                // Transaction Count store in spring cache for all eftpos target
                EFTPOSKeyModel eftposKeyModel = cacheService.getEftposKeyDetails(targetConfigModel.getName().substring(0, tmm.getTarget().length() - 1));
                Map<String, Integer> mapData = new HashedMap<>();
                if (eftposKeyModel.getTargetName() != null) {
                    String targetName1 = targetConfigModel.getName().substring(0, targetConfigModel.getName().length() - 1);
                    int count  = eftposKeyModel.getTargetName().entrySet().stream().filter(targetName -> targetName.getKey().equals(targetName1)).mapToInt(Map.Entry :: getValue).sum();
                    mapData.put(targetConfigModel.getName().substring(0, targetConfigModel.getName().length() - 1), count +1);
                } else {
                    mapData.put(targetConfigModel.getName().substring(0, targetConfigModel.getName().length() - 1), txnCount);
                }
                eftposKeyModel.setTargetName(mapData);
                cacheService.updateEftposKeyDetails(targetConfigModel.getName().substring(0, targetConfigModel.getName().length() - 1), eftposKeyModel);


                // Check transaction count limit
                EFTPOSKeyModel eftposKeyreqModel = cacheService.getEftposKeyDetails(targetConfigModel.getName().substring(0, targetConfigModel.getName().length()-1));
                Map<String, Integer> targetNameMapData = eftposKeyreqModel.getTargetName();
                Map<String, Integer> targetNameMap  = targetNameMapData.entrySet().stream().collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.summingInt(Map.Entry::getValue)));
                for (Map.Entry<String, Integer> targetNameEntry : targetNameMap.entrySet()) {
                    if (targetNameEntry.getValue() >= eftposKeyExchangeCountLimit) {
                        Map<String, Integer> map = new HashMap<>();
                        map.put(targetNameEntry.getKey(), 0);
                        eftposKeyModel.setSignonKey(false);
                        eftposKeyModel.setTrxnLimitExceededKey(true);
                        eftposKeyModel.setTargetName(map);
                        logger.info("Transaction Limit Key Exchange {}, count {} ", targetNameEntry.getKey(), targetNameEntry.getValue() );
                        cacheService.updateEftposKeyDetails(targetConfigModel.getName().substring(0,targetConfigModel.getName().length()-1), eftposKeyModel);
                        networkManagement.doDynamicKeyExchangeWithTargetName(routingContext, targetNameEntry.getKey());
                    }
                }

            }//END

        }


        return targetConfigModel;

    }

    public TargetConfigModel validatetarget(TargetConfigModel targetConfigModel, TransactionMessageModel tmm, RoutingContext routingContext, Exchange exchange){

        // put active userId for eftpos multiple targets
        if (TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(targetConfigModel.getTargetType().name())) {
            SpringContextBridge.services().getCacheService().putActiveTargetId(targetConfigModel.getName().substring(0, targetConfigModel.getName().length() - 1));

            // Transaction Count store in spring cache for all eftpos target
            EFTPOSKeyModel eftposKeyModel = cacheService.getEftposKeyDetails(tmm.getTarget().substring(0, tmm.getTarget().length() - 1));
            Map<String, Integer> mapData = new HashedMap<>();

            if (eftposKeyModel.getTargetName() != null) {
                int count = eftposKeyModel.getTargetName().get(targetConfigModel.getTarget().name());
                if (count == 0) {
                    txnCount = 1;
                    mapData.put(targetConfigModel.getTarget().name(), txnCount);
                } else {
                    mapData.put(targetConfigModel.getTarget().name(), txnCount);
                }
            } else {
                mapData.put(targetConfigModel.getTarget().name(), txnCount);
            }

            eftposKeyModel.setTargetName(mapData);
            cacheService.updateEftposKeyDetails(tmm.getTarget().substring(0, tmm.getTarget().length() - 1), eftposKeyModel);
            txnCount++;
        }//END

        String targetIp = targetConfigModel.getConnections().get(0).getUrlOrIp();
        String port = targetConfigModel.getConnections().get(0).getPortOrHeaders();
        logger.debug(LogUtils.buildLogMessage(routingContext.getEntityId(), targetConfigModel.getName(), null, null, "Target endpoint identified as: {}:{}"), targetIp, port);

        ConnectionType connectionType = targetConfigModel.getConnections().get(0).getType();
        if (connectionType == ConnectionType.ISO) {
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_SCHEME, NettyConfig.getProducerEndpoint(routingContext, targetIp + ":" + port));
        }
        return targetConfigModel;
    }
}
