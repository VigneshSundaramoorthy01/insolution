package com.isg.mw.routing.route.bmsswitch.hearbeat;

import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Component
@Getter
@Setter
public class ServicesConfig {
//    @Value("${health.service.cm.ip}")
//    private String cmIp;
//
//    @Value("${health.service.cm.port}")
//    private String cmPort;
//
//    @Value("${health.service.tlm.ip}")
//    private String tlmIp;
//
//    @Value("${health.service.tlm.port}")
//    private String tlmPort;
//
//    @Value("${health.service.bms.ip}")
//    private String bmsIp;
//
//    @Value("${health.service.bms.port}")
//    private String bmsPort;
    @Autowired
    private Environment env;

    List<services> services;

    @Value("${health.service.kafka.check}")
    private boolean kafkaCheck;

    private final Logger logger = LogManager.getLogger(getClass());

    @PostConstruct
    public void init() {
        services = new ArrayList<services>();

        logger.info("reading services from property");
        String baseKey = "health.service";
        String[] servicesNames = env.getProperty(baseKey, String[].class,new String[0]);

        logger.info("mapping services property : {} ",servicesNames.length);
        // Load properties for each service
        for (String service : servicesNames) {
            String ip = env.getProperty(baseKey + "." + service + ".ip");
            String port = env.getProperty(baseKey + "." + service + ".port");

            if (ip != null && port != null) {
                logger.info(baseKey + "." + service + ".ip="+ip);
                services.add(new services(ip,port,service));
            }
        }

    }



}
