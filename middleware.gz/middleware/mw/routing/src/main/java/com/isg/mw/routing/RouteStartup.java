package com.isg.mw.routing;

import java.util.List;

import com.isg.mw.core.model.sr.*;
import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;

import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.routing.context.RoutingInitializationContext;

public final class RouteStartup {

	private RouteStartup() {
	}

	private static CamelContext camelContext;

	public static void initRouting(List<SourceConfigModel> sourceList, List<TargetConfigModel> targetList,
								   List<MessageTransformationConfigModel> msgTransformationList, List<SmartRouteConfigModel> smartRoutesList,
								   List<PaymentModesModel> paymentModesModels, List<PaymentModeOptionsModel> paymentModeOptionsModels,
								   List<TargetPaymentModesModel> targetPaymentModesModels,
								   List<TargetPaymentModeOptionsModel> targetPaymentModeOptionsModels, List<TargetLCRConfigModel> targetLCRConfigs,
								   List<MerchantPaymentModesModel> merchantPaymentModesModels, List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptionsModels,
								   List<MerchantTargetPreferencesModel> merchantTargetPreferencesModels, List<MerchantMasterModel> merchantMasterModels) {
		camelContext = new DefaultCamelContext();
		RoutingInitializationContext.initializeRouting(sourceList, targetList, msgTransformationList,smartRoutesList, paymentModesModels, paymentModeOptionsModels,
				targetPaymentModesModels, targetPaymentModeOptionsModels, targetLCRConfigs, merchantPaymentModesModels, merchantPaymentModeOptionsModels, merchantTargetPreferencesModels, merchantMasterModels, camelContext);
	}

	public static void startRouting() {
		camelContext.start();
	}

	public static void stopRouting() {
		camelContext.stop();
	}
}
