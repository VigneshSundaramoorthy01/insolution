package com.isg.mw.routing.exception;

public class FormatErrorException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FormatErrorException(String expMsg) {
		super(expMsg);
	}

	public FormatErrorException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}
