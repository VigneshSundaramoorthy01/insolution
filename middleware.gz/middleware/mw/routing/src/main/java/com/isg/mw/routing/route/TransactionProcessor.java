package com.isg.mw.routing.route;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.routing.context.RoutingContext;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

@Component
public class TransactionProcessor {
    private final Logger logger = LogManager.getLogger(getClass());

    public void processRequest(Exchange exchange) {
        TransactionProcessorFactory.getTransactionProcessor(getSourceProcessor(exchange))
                .processTxnRequest(exchange);
    }

    public void processResponse(Exchange exchange) {
        ITransactionProcessor iTransactionProcessor = TransactionProcessorFactory.getTransactionProcessor(getSourceProcessor(exchange));

        iTransactionProcessor.processTxnResponse(exchange);
        iTransactionProcessor.clearLoggerContext();
    }

    public void processDecline(Exchange exchange) {
        ITransactionProcessor iTransactionProcessor = null;
        try {
            iTransactionProcessor = TransactionProcessorFactory.getTransactionProcessor(getSourceProcessor(exchange));
            iTransactionProcessor.processTxnDecline(exchange);

        } catch (Exception e) {
            logger.error("Unexpected error occurred", e);
        } finally {
            iTransactionProcessor.clearLoggerContext();
        }
    }

    private SourceProcessor getSourceProcessor(Exchange exchange) {
        RoutingContext routingContext =
                (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        return routingContext.getSource().getSourceProcessor();

    }
}
