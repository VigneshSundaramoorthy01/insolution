package com.isg.mw.routing.exception;

public class ResponseProcessingException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResponseProcessingException(String errorMsg) {
		super(errorMsg);
	}

	public ResponseProcessingException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}