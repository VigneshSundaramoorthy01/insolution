package com.isg.mw.routing.consumer;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.PropertyUtils;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TransactionMessageModelDeserializer implements Deserializer<TransactionMessageModel> {

	private Logger logger = LogManager.getLogger(getClass());

	@Override
	public TransactionMessageModel deserialize(String topic, byte[] data) {
		TransactionMessageModel trModel = null;
		ByteArrayInputStream bis = new ByteArrayInputStream(data);
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(bis);
			trModel = (TransactionMessageModel) ois.readObject();
			ois.close();
		} catch (IOException e) {
			logger.error(PropertyUtils.getMessage("TLM-com.isg.tlm.mgmt.consumer-003"), e);
		} catch (ClassNotFoundException e) {
			logger.error(PropertyUtils.getMessage("TLM-com.isg.tlm.mgmt.consumer-004"), e);
		}
		return trModel;
	}

}
