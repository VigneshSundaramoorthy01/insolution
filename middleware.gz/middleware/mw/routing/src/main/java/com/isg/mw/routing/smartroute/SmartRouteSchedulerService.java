package com.isg.mw.routing.smartroute;

import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SmartRouteSchedulerService implements ApplicationContextAware {

    private ScheduledExecutorService executor;

    private ApplicationContext applicationContext;

    @Value("${smart.route.success.ratio.calculation.thread.pool.size:1}")
    private Integer smartRouteSuccessRatioCalculationThreadPoolSize;

    public void scheduleTask(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel) {
        scheduleTask(sourceConfigModel, smartRouteConfigModel, smartRouteConfigModel.getSuccessRatioInterval());
    }

    public void scheduleTask(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, long calInterval) {
        executor = Executors.newScheduledThreadPool(smartRouteSuccessRatioCalculationThreadPoolSize);

        SmartRouteSchedulerTask smartRouteSchedulerTask = this.applicationContext.getBean(SmartRouteSchedulerTask.class);
        smartRouteSchedulerTask.setSourceConfigModel(sourceConfigModel);
        smartRouteSchedulerTask.setSmartRouteConfigModel(smartRouteConfigModel);
        executor.schedule(smartRouteSchedulerTask, calInterval, TimeUnit.MILLISECONDS);
    }

    public void scheduleTask(Runnable runnable, long delay) {
        executor = Executors.newScheduledThreadPool(smartRouteSuccessRatioCalculationThreadPoolSize);
        executor.schedule(runnable, delay, TimeUnit.MILLISECONDS);
    }

    public void stopScheduledTask() {
        executor.shutdownNow();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
