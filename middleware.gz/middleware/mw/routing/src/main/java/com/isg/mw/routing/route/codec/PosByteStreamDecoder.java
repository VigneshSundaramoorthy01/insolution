package com.isg.mw.routing.route.codec;

import com.isg.mw.dstm.utils.HsmCommandUtility;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.apache.camel.component.netty.ChannelHandlerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class PosByteStreamDecoder extends ByteToMessageDecoder implements ChannelHandlerFactory {

    private Logger logger = LogManager.getLogger(getClass());

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf msg, List<Object> out) {
        try {
            logger.trace("ByteStreamDecoder: Message - :{}",msg);
            byte[] twoBytesLength = new byte[2];
            for(int i = 0 ; i < 2 ; i++) {
                twoBytesLength[i] = msg.getByte(i);
            }
            logger.trace("ByteStreamDecoder: Message two bytes- :{}",twoBytesLength);
            String hexBinary = HsmCommandUtility.printHexBinary(twoBytesLength);
            int length = Integer.parseInt(hexBinary.substring(0, 4), 16);
            logger.trace("ByteStreamDecoder: Message - length: {}",length);

            // Make sure if there's enough bytes in the buffer.
            if (msg.readableBytes() <= length) {
                logger.trace("ByteStreamDecoder Reset Reader Index : {}");
                msg.resetReaderIndex();
            } else {
                while (msg.isReadable() && length > 0) {
                    byte[] msgBytes = new byte[msg.readableBytes()];
                    msg.readBytes(msgBytes);
                    out.add(msgBytes);
                    length--;
                }
            }

            /*while (msg.isReadable() && msg.readableBytes() != msg.capacity()) {
                byte[] msgBytes = new byte[msg.readableBytes()];
                msg.readBytes(msgBytes);
                out.add(msgBytes);
            }*/
        } catch (Exception e) {
            logger.trace("Pos ByteStreamDecoder: Message - readableBytes: {}, Capacity: {}",
                    msg.readableBytes(), msg.capacity());
            logger.error("Pos ByteStreamDecoder: Exception while decoding: {}", e.getMessage());
        }
    }


    @Override
    public ChannelHandler newChannelHandler() {
        return new ByteStreamDecoder();
    }
}