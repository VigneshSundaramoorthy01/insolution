package com.isg.mw.routing.smartroute;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheHelper;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.icici.UpiCallbackRequest;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.pg.MerchantEncDataRequest;
import com.isg.mw.core.model.pg.MerchantEncDataResponse;
import com.isg.mw.core.model.pg.MerchantEncReqRes;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.sr.TargetInfo;
import com.isg.mw.core.model.sr.TargetKey;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.PaymentLinkRequestModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.*;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.exception.BankServerException;
import com.isg.mw.mtm.exception.FileDetailsMissMatch;
import com.isg.mw.mtm.exception.TransactionCencelException;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.transform.icici.IciciMessageTransformation;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.config.RoutingConstants;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.exception.*;
import com.isg.mw.routing.route.ITransactionProcessor;
import com.isg.mw.routing.route.SwitchRouter;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import com.isg.mw.routing.smartroute.util.ResponseManipulatorUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import org.apache.camel.Exchange;
import org.apache.camel.component.netty.NettyConstants;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.component.netty.http.NettyHttpEndpoint;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOUtil;
import org.json.JSONObject;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.*;

import static com.isg.mw.routing.config.RoutingConstants.*;

@Component
public class SmartRouteTransactionProcessor implements ITransactionProcessor, ApplicationContextAware {

    private final Logger logger = LogManager.getLogger(getClass());
    private final Logger rawlogger = LogManager.getLogger("rawLog");

    private ApplicationContext applicationContext;

    @Autowired
    private CacheServices cacheService;

    @Autowired
    @Lazy
    private CacheUtil cacheUtil;

    @Autowired
    private CacheHelper cacheHelper;

    private ISmartRoute smartRoute;

    @Autowired
    private ResponseManipulatorUtil responseManipulatorUtil;

    @Autowired
    private SwitchRouter switchRouterService;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Autowired
    private ApiTransactionProcessor apiTransactionProcessor;

    @Autowired
    private SmartRouteTxnController smartRouteTxnController;

    @Autowired
    private SmartRouteTxnHelperController smartRouteTxnHelperController;

    @Autowired
    private SmartRouteOfflineTxnController smartRouteOfflineTxnController;

    @Value("${threshold.value:3}")
    private int threshold;

    @Override
    public void processTxnRequest(Exchange exchange) {
        try {
            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
            SourceConfigModel sourceConfigModel1 = routingContext.getSource();
            smartRoute = SmartRouteFactory.getSmartRoute(smartRouteConfigModel.getRouteType());

            if (exchange.getFromEndpoint() instanceof NettyHttpEndpoint) {
                String apiResponse = "";
                int startIndex = exchange.getFromEndpoint().getEndpointUri().lastIndexOf("/");
                int lastIndex = exchange.getFromEndpoint().getEndpointUri().lastIndexOf("?");
                String endpointUri = exchange.getFromEndpoint().getEndpointUri().substring(startIndex, lastIndex);
                ApiTxnModel apiTxnModel;
                switch (endpointUri) {
                    //Smart Route Transaction Helper Controller Apis
                    case "/validateAndGetPaymentDataEnc":
                        String validateAndGetPaymentDataEncResponse = smartRouteTxnHelperController.validateAndGetPaymentDataEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, validateAndGetPaymentDataEncResponse, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/validateAndGetPaymentData":
                        apiResponse = smartRouteTxnHelperController.validateAndGetPaymentData(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/checkStatusEnc":
                        String checkStatusEnc = smartRouteTxnHelperController.checkStatusEnc(exchange, routingContext, false);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, checkStatusEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/checkStatus":
                        apiResponse = smartRouteTxnHelperController.checkStatus(exchange, routingContext, false);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    //Check Txn Status For MERCHANT-KIT-INTEGRATION
                    case "/checkStatusMerchantKitEnc":
                        String checkStatusMKitEnc = smartRouteTxnHelperController.checkStatusEnc(exchange, routingContext, true);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, checkStatusMKitEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/checkStatusMerchantKit":
                        apiResponse = smartRouteTxnHelperController.checkStatus(exchange, routingContext, true);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/checkTxnStatusEnc":
                        String checkTxnStatusEnc = smartRouteTxnHelperController.checkTxnStatusEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, checkTxnStatusEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/checkTxnStatus":
                        apiResponse = smartRouteTxnHelperController.checkTxnStatus(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/getConvenienceFeeEnc":
                        String convenienceFeeEnc = smartRouteTxnHelperController.getConvenienceFeeEnc(exchange);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, convenienceFeeEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/getConvenienceFee":
                        apiResponse = smartRouteTxnHelperController.getConvenienceFee(exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/verifyVpaEnc":
                        String verifyVpaEnc = smartRouteTxnHelperController.verifyVpaEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, verifyVpaEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/verifyVpa":
                        apiResponse = smartRouteTxnHelperController.verifyVpa(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    //Smart Route Transaction Controller Apis
                    case "/getTargetLcr":
                        apiResponse = smartRouteTxnController.getTargetLcr(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/getTargetAndGenerateRequestEnc":
                        scheduleSuccessRatioJob(routingContext, smartRouteConfigModel, sourceConfigModel1);
                        String targetAndGenerateResponseEncResponse = smartRouteTxnController.getTargetAndGenerateRequestEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, targetAndGenerateResponseEncResponse, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/getTargetAndGenerateRequest":
                        scheduleSuccessRatioJob(routingContext, smartRouteConfigModel, sourceConfigModel1);
                        apiResponse = smartRouteTxnController.getTargetAndGenerateRequest(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/createRefundEnc":
                        String createRefundEnc = smartRouteTxnController.createRefundEnc(exchange);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, createRefundEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/createRefund":
                        apiResponse = smartRouteTxnController.createRefund(exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
//                    case "/createRefundFromPGEnc":
//                        String createRefundFromMerchantKitEncEnc = smartRouteTxnController.createRefundFromMerchantKitEnc(exchange);
//                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, createRefundFromMerchantKitEncEnc,  exchange);
//                        exchange.getIn().setBody(apiResponse);
//                        break;
//                    case "/createRefundFromPG":
//                        apiResponse = smartRouteTxnController.createRefundFromMerchantKit(exchange);
//                        exchange.getIn().setBody(apiResponse);
//                        break;
                    case "/createRefundFromMerchantKitEnc":
                        String createRefundFromMerchantKitEncEnc = smartRouteTxnController.createRefundFromMerchantKitEnc(exchange, true);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, createRefundFromMerchantKitEncEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/createRefundFromMerchantKit":
                        apiResponse = smartRouteTxnController.createRefundFromMerchantKit(exchange, true);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/payuSaveTransactionResponseEnc":
                        String payuSaveTransactionResponseEnc = smartRouteTxnController.saveTransactionResponseEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, payuSaveTransactionResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/tpslSaveTransactionResponseEnc":
                        String tpslSaveTransactionResponseEnc = smartRouteTxnController.saveTransactionResponseEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, tpslSaveTransactionResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/lyraSaveTransactionResponseEnc":
                        String lyraSaveTransactionResponseEnc = smartRouteTxnController.saveTransactionResponseEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, lyraSaveTransactionResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/payuSaveTransactionResponse":
                        apiResponse = smartRouteTxnController.saveTransactionResponse(exchange, routingContext,sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/tpslSaveTransactionResponse":
                        apiResponse = smartRouteTxnController.saveTransactionResponse(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/lyraSaveTransactionResponse":
                        apiResponse = smartRouteTxnController.saveTransactionResponse(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/retailSaveTransactionResponseEnc":
                        String retailSaveTransactionResponseEnc = smartRouteTxnController.saveTransactionResponseEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, retailSaveTransactionResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/retailSaveTransactionResponse":
                        apiResponse = smartRouteTxnController.saveTransactionResponse(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/corporateSaveTransactionResponseEnc":
                        String corporateSaveTransactionResponseEnc = smartRouteTxnController.saveTransactionResponseEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, corporateSaveTransactionResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/corporateSaveTransactionResponse":
                        apiResponse = smartRouteTxnController.saveTransactionResponse(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    //Smart Route Offline Transaction Controller Apis
                    case "/saveOfflineTransactionEnc":
                        String saveOfflineTransactionEnc = smartRouteOfflineTxnController.saveOfflineTransactionEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, saveOfflineTransactionEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/saveOfflineTransaction":
                        apiResponse = smartRouteOfflineTxnController.saveOfflineTransaction(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/validateNeftRtgsTransactionEnc":
                        String validateNeftRtgsTransactionEnc = smartRouteOfflineTxnController.validateNeftRtgsTransactionEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, validateNeftRtgsTransactionEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/validateNeftRtgsTransaction":
                        String validateNeftRtgsTransaction = smartRouteOfflineTxnController.validateNeftRtgsTransaction(exchange, routingContext);
                        exchange.getIn().setBody(validateNeftRtgsTransaction);
                        break;
                    case "/saveNeftResponseEnc":
                        String saveNeftResponseEnc = smartRouteOfflineTxnController.saveNeftResponseEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, saveNeftResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/saveNeftResponse":
                        String saveNeftResponse = smartRouteOfflineTxnController.saveNeftResponse(exchange, routingContext);
                        exchange.getIn().setBody(saveNeftResponse);
                        break;
                    case "/validateOfflineTransactionEnc":
                        String validateOfflineTransactionEnc = smartRouteOfflineTxnController.validateOfflineTransactionEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, validateOfflineTransactionEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/validateOfflineTransaction":
                        String validateOfflineTransaction = smartRouteOfflineTxnController.validateOfflineTransaction(exchange, routingContext);
                        exchange.getIn().setBody(validateOfflineTransaction);
                        break;
                    case "/saveOfflineResponseEnc":
                        String saveOfflineResponseEnc = smartRouteOfflineTxnController.saveOfflineResponseEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, saveOfflineResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/saveOfflineResponse":
                        String saveOfflineResponse = smartRouteOfflineTxnController.saveOfflineResponse(exchange, routingContext);
                        exchange.getIn().setBody(saveOfflineResponse);
                        break;
                    case "/generateOtpEnc":
                        String generateOtpEnc = smartRouteTxnHelperController.generateOtpEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, generateOtpEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/generateOtp":
                        apiResponse = smartRouteTxnHelperController.generateOtp(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/verifyOtpEnc":
                        String verifyOtpEnc = smartRouteTxnHelperController.verifyOtpEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, verifyOtpEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/verifyOtp":
                        apiResponse = smartRouteTxnHelperController.verifyOtp(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/generatePaymentLinkEnc":
                        String generatePaymentLinkEnc = smartRouteTxnHelperController.generatePaymentLinkEnc(exchange);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, generatePaymentLinkEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/generatePaymentLink":
                        String generatePaymentLinkResponse = smartRouteTxnHelperController.generatePaymentLink(exchange);
                        exchange.getIn().setBody(generatePaymentLinkResponse);
                        break;
                    case "/generateMerchantPaymentLink":
                        String generateMerchantPaymentLinkResponse = smartRouteTxnHelperController.generateMerchantPaymentLink(exchange);
                        exchange.getIn().setBody(generateMerchantPaymentLinkResponse);
                        break;
                    case "/getPaymentlinkDetailsEnc":
                        String getPaymentLinkDetailsResponseEnc = smartRouteTxnHelperController.getPaymentLinkDetailsEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, getPaymentLinkDetailsResponseEnc, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/getPaymentlinkDetails":
                        String getPaymentLinkDetailsResponse = smartRouteTxnHelperController.getPaymentLinkDetails(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(getPaymentLinkDetailsResponse);
                        break;
                    case "/upiresponse":
                        String upiresponse;
                        String reqBody = exchange.getIn().getBody(String.class);
                        logger.info("CallBack Response Body : {}", reqBody);
                        UpiCallbackRequest upiCallbackRequest = (UpiCallbackRequest) IsgXmlUtils.convertXmlToObject(reqBody, UpiCallbackRequest.class);
                        String payload = null;
                        if (!StringUtils.isBlank(reqBody) && upiCallbackRequest != null) {
                            payload = apiTransactionProcessor.sendCallBackAck(upiCallbackRequest);
                            if (!StringUtils.isBlank(payload)) {
                                exchange.getIn().setBody(payload);
                                logger.info("Callback Received And ACK Send Successfully : {}", upiCallbackRequest.getOriginalTxnId());
                            } else {
                                exchange.getIn().setBody("");
                                logger.info("Callback Received And ACK Sending Failed : {}", upiCallbackRequest.getOriginalTxnId());
                            }
                        }
                        if (upiCallbackRequest == null) {
                            logger.info("Callback Request Model Is Null Or Invalid : {}", upiCallbackRequest.getOriginalTxnId());
                        } else {
                            TransactionMessageModel reqSourceTmm = new TransactionMessageModel();
                            TransactionMessageModel originalTransaction = null;
                            reqSourceTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
                            String txnId = null;
                            if (!StringUtils.isBlank(upiCallbackRequest.getOriginalTxnId()) && "COLLECT".equalsIgnoreCase(upiCallbackRequest.getTxnType())) {
                                txnId = SpringContextBridge.services().getCacheUtil().getSeqNo(upiCallbackRequest.getOriginalTxnId());
                            } else if (!StringUtils.isBlank(upiCallbackRequest.getRefId()) && "PAY".equalsIgnoreCase(upiCallbackRequest.getTxnType())) {
                                txnId = SpringContextBridge.services().getCacheUtil().getSeqNo(upiCallbackRequest.getRefId());
                            }
                            logger.info("Fetched TxnId From Redis For Received Callback For : {} - {}", upiCallbackRequest.getTxnType(), txnId);
                            if (!StringUtils.isBlank(txnId)) {
                                reqSourceTmm.setTransactionId(processorHelper.getHashedValue(txnId));
                                originalTransaction = smartRouteTxnHelperController.getTmmByTransactionId(txnId);
                            }
                            if (originalTransaction != null) {
                                long timeDifference = processorHelper.calculateTimeDifference(originalTransaction.getRequestReceivedTime(), OffsetDateTime.now());
                                TransactionMessageModel resSourceTmm = IciciMessageTransformation.getSuccessResSourceTmmForUpi(originalTransaction.getResSmartRouteData().getUpiResponse(), upiCallbackRequest, originalTransaction);
                                apiTxnModel = new ApiTxnModel();
                                apiTxnModel.setMid(resSourceTmm.getCardAcceptorId());
                                apiTxnModel.setTid(resSourceTmm.getCardAcceptorTerminalId());
                                apiTxnModel.setMerchantTxnRefNo(originalTransaction.getMerchantTxnRefNo());
                                //difference between original txn and callback in min

                                MerchOrdTxnData merchOrdTxnData = cacheUtil.getTxnData(routingContext.getEntityId(), originalTransaction.getCardAcceptorId(), originalTransaction.getMerchantTxnRefNo());

                                if (timeDifference > 30) {
                                    if (upiCallbackRequest.getTxnStatus().equalsIgnoreCase("SUCCESS") &&
                                            upiCallbackRequest.getResponseCode().equalsIgnoreCase("00")) {
                                        resSourceTmm.setResCode("00");
                                        //SET TXN_MSG_MODEL
                                        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE, DbMessageType.UP_RES, resSourceTmm);
                                        logger.info(LogUtils.buildSMLogMessage(resSourceTmm.getEntityId(), resSourceTmm.getMerchantTxnRefNo(), resSourceTmm.getTransactionId(),
                                                resSourceTmm.getTransactionName(), "Callback Tmm Response : {}"), resSourceTmm);
                                        smartRouteTxnController.changeStatus(merchOrdTxnData, apiTxnModel, routingContext.getEntityId(), txnId, "Success");
                                        processorHelper.logToTlm(resSourceTmm, routingContext);
                                        logger.info("Callback received and status updated in DB : {}", upiCallbackRequest.getOriginalTxnId());
                                        apiTxnModel.setTxnAmt(Integer.valueOf(resSourceTmm.getTxnAmt()).toString());
                                        apiTxnModel.setOriginalHashedTxnId(processorHelper.getHashedValue(txnId));
                                        apiTxnModel.setDrCrFlag("R");
                                        apiResponse = smartRouteTxnController.createRefund(exchange, apiTxnModel);
                                        //update original txn as reversal
                                        TransactionMessageModel body = exchange.getIn().getBody(TransactionMessageModel.class);
                                        resSourceTmm.setDrcrFlag("R");
                                        resSourceTmm.setTlmMessageType(TlmMessageType.REQUEST);
                                        resSourceTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
                                        resSourceTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));
                                        resSourceTmm.setTargetType(body.getTargetType());
                                        processorHelper.logToTlm(resSourceTmm, routingContext);
                                        logger.info("Reversal has beed initiated : {}", apiResponse);
                                    } else if (!upiCallbackRequest.getTxnStatus().equalsIgnoreCase("PENDING")) {
                                        resSourceTmm.setResCode("91");
                                        MerchOrdTxnData.TxnData txnData = merchOrdTxnData.getTxnDataMapModel().get(txnId);
                                        if (!"Success".equalsIgnoreCase(txnData.getTxnStatus())) {
                                            //SET TXN_MSG_MODEL
                                            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE, DbMessageType.UP_RES, resSourceTmm);
                                            logger.info(LogUtils.buildSMLogMessage(resSourceTmm.getEntityId(), resSourceTmm.getMerchantTxnRefNo(), resSourceTmm.getTransactionId(),
                                                    resSourceTmm.getTransactionName(), "Callback Tmm Response : {}"), resSourceTmm);
                                            smartRouteTxnController.changeStatus(merchOrdTxnData, apiTxnModel, routingContext.getEntityId(), txnId, "Failed");
                                            processorHelper.logToTlm(resSourceTmm, routingContext);
                                        }
                                        logger.info("Callback received and status updated in DB : {}", upiCallbackRequest.getOriginalTxnId());
                                    }
                                    exchange.getIn().setBody(payload);
                                } else {
                                    if (upiCallbackRequest.getTxnStatus().equalsIgnoreCase("SUCCESS") &&
                                            upiCallbackRequest.getResponseCode().equalsIgnoreCase("00")) {
                                        resSourceTmm.setResCode("00");
                                        smartRouteTxnController.changeStatus(merchOrdTxnData, apiTxnModel, routingContext.getEntityId(), txnId, "Success");
                                        //SET TXN_MSG_MODEL
                                        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE, DbMessageType.UP_RES, resSourceTmm);
                                        logger.info(LogUtils.buildSMLogMessage(resSourceTmm.getEntityId(), resSourceTmm.getMerchantTxnRefNo(), resSourceTmm.getTransactionId(),
                                                resSourceTmm.getTransactionName(), "Callback Tmm Response : {}"), resSourceTmm);
                                        processorHelper.logToTlm(resSourceTmm, routingContext);
                                        logger.info("Callback received and status updated in DB : {}", upiCallbackRequest.getOriginalTxnId());
                                    } else if (!upiCallbackRequest.getTxnStatus().equalsIgnoreCase("PENDING")) {
                                        resSourceTmm.setResCode("91");
                                        MerchOrdTxnData.TxnData txnData = merchOrdTxnData.getTxnDataMapModel().get(txnId);
                                        if (!"Success".equalsIgnoreCase(txnData.getTxnStatus())) {
                                            //SET TXN_MSG_MODEL
                                            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE, DbMessageType.UP_RES, resSourceTmm);
                                            logger.info(LogUtils.buildSMLogMessage(resSourceTmm.getEntityId(), resSourceTmm.getMerchantTxnRefNo(), resSourceTmm.getTransactionId(),
                                                    resSourceTmm.getTransactionName(), "Callback Tmm Response : {}"), resSourceTmm);
                                            smartRouteTxnController.changeStatus(merchOrdTxnData, apiTxnModel, routingContext.getEntityId(), txnId, "Failed");
                                            processorHelper.logToTlm(resSourceTmm, routingContext);
                                            logger.info("Callback received and status updated in DB : {}", upiCallbackRequest.getOriginalTxnId());
                                        }
                                        logger.info("Callback received : {}", upiCallbackRequest.getOriginalTxnId());
                                    }
                                }
                            } else {
                                logger.info("Collect transaction not found in DB : {}", upiCallbackRequest.getOriginalTxnId());
                            }
                            if (originalTransaction != null) {
                                Object tmmList = smartRouteTxnHelperController.getTmmByTxnRefNo(originalTransaction.getMerchantTxnRefNo(), null,
                                        "00", originalTransaction.getCardAcceptorId(), originalTransaction.getCardAcceptorTerminalId());
                                List<TransactionMessageModel> tmmByTxnRefNo = tmmList != null ? (List<TransactionMessageModel>) tmmList : null;
                                if (tmmByTxnRefNo != null && !tmmByTxnRefNo.isEmpty() && (tmmByTxnRefNo.size() > 1)) {
                                    TransactionMessageModel resSourceTmm = IciciMessageTransformation.getSuccessResSourceTmmForUpi(originalTransaction.getResSmartRouteData().getUpiResponse(), upiCallbackRequest, originalTransaction);
                                    TransactionMessageModel messageModel = tmmByTxnRefNo.get(0);
                                    apiTxnModel = new ApiTxnModel();
                                    apiTxnModel.setMid(messageModel.getCardAcceptorId());
                                    apiTxnModel.setTid(messageModel.getCardAcceptorId());
                                    apiTxnModel.setTxnAmt(Integer.valueOf(messageModel.getTxnAmt()).toString());
                                    apiTxnModel.setOriginalHashedTxnId(messageModel.getOriginalHashedTxnId());
                                    apiTxnModel.setDrCrFlag("R");
                                    apiResponse = smartRouteTxnController.createRefund(exchange, apiTxnModel);
                                    TransactionMessageModel body = exchange.getIn().getBody(TransactionMessageModel.class);
                                    resSourceTmm.setDrcrFlag("R");
                                    resSourceTmm.setTlmMessageType(TlmMessageType.REQUEST);
                                    resSourceTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
                                    resSourceTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));
                                    resSourceTmm.setTargetType(body.getTargetType());
                                    //SET TXN_MSG_MODEL
                                    SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE, DbMessageType.UP_RES, resSourceTmm);
                                    logger.info(LogUtils.buildSMLogMessage(resSourceTmm.getEntityId(), resSourceTmm.getMerchantTxnRefNo(), resSourceTmm.getTransactionId(),
                                            resSourceTmm.getTransactionName(), "Reversal callback Tmm Response : {}"), resSourceTmm);
                                    processorHelper.logToTlm(resSourceTmm, routingContext);
                                    logger.info("Reversal has beed initiated : {}", apiResponse);
                                    exchange.getIn().setBody(payload);
                                }
                            }
                        }
                        break;
                    case "/smsPayFileUpload":
                        List<PaymentLinkRequestModel> paymentLinkRequestModels = null;
                        String res;
                        try {
                            paymentLinkRequestModels = smartRouteTxnHelperController.uploadExcelFile(exchange);
                            if (paymentLinkRequestModels.stream().count() > 200) {
                                res = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "File Count Exceeded", null);
                            } else {
                                res = smartRouteTxnHelperController.generatePaymentLink(exchange, paymentLinkRequestModels);
                            }
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                            res = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "File Not Present", null);
                        } catch (FileDetailsMissMatch e) {
                            res = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "File name already exist for given MID ::  " +
                                    exchange.getIn().getHeaders().get("mid"), null);
                        } catch (Exception e) {
                            res = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Error While Processing File", null);
                        }
                        exchange.getIn().setBody(res);
                        break;
                    case "/iciciUpiQR":
                        apiResponse = smartRouteTxnController.getTargetAndGenerateRequest(exchange, routingContext);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/iciciUpiQREnc":
                        String iciciUpiQREncResponse = smartRouteTxnController.getTargetAndGenerateRequestEnc(exchange, routingContext);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, iciciUpiQREncResponse, exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/callback":
                        JSONObject jsonObject = new JSONObject();
                        String apiRequest = exchange.getIn().getBody(String.class);
                        MerchantEncReqRes encReqObj = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantEncReqRes.class);
                        if (encReqObj != null && !StringUtils.isBlank(encReqObj.getMerchantId())
                                && !StringUtils.isBlank(encReqObj.getTerminalId())) {
                            jsonObject.put("MerchantId", encReqObj.getMerchantId());
                            jsonObject.put("Acknowledgement", "Received");
                            jsonObject.put("TerminalId", encReqObj.getTerminalId());
                            jsonObject.put("BankId", encReqObj.getBankId());
                            exchange.getIn().setBody(jsonObject);
                        } else {
                            jsonObject.put("statusCode", "01");
                            jsonObject.put("msg", "Invalid Request");
                            exchange.getIn().setBody(jsonObject);
                        }
                        break;
                    case "/generateReversal":
                        String generateReversal = smartRouteTxnController.generateReversal(exchange);
                        exchange.getIn().setBody(generateReversal);
                        break;
                    case "/validateTxnStatus":
                        String validateTxnStatus = smartRouteTxnHelperController.validateTxnStatus(exchange, routingContext);
                        exchange.getIn().setBody(validateTxnStatus);
                        break;
                    case "/getPaymentModeDetailsEnc":
                        String getPaymentModeDetailsEncResponse = smartRouteTxnHelperController.getPaymentModeDetailsEnc(exchange, routingContext, sourceConfigModel1);
                        apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, getPaymentModeDetailsEncResponse,  exchange);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/getPaymentModeDetails":
                        apiResponse = smartRouteTxnHelperController.getPaymentModeDetails(exchange, routingContext, sourceConfigModel1);
                        exchange.getIn().setBody(apiResponse);
                        break;
                    case "/produceTlm":
                        String apiRequest1 = exchange.getIn().getBody(String.class);
                        ObjectMapper mapper = new ObjectMapper();
                        TransactionMessageModel tmm = null;
                        try {
                            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                            mapper.registerModule(new JavaTimeModule());
                            tmm = mapper.readValue(apiRequest1, TransactionMessageModel.class);
                            logToTlm(tmm,routingContext);
                            exchange.getIn().setBody("Success");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            tmm = null;
                            exchange.getIn().setBody("Failed");
                        }
                        break;
                }
            }
        } catch (Exception e) {
            logger.error("Error while processing the request message", e);
            throw new RequestProcessingException("Error while processing the request message ", e);
        }
    }


    private void scheduleSuccessRatioJob(RoutingContext routingContext, SmartRouteConfigModel smartRouteConfigModel, SourceConfigModel sourceConfigModel1) {
        int sourceTotalTxnCount = cacheUtil.getSourceTotalTxnCount(cacheHelper.getSourceMapKey(sourceConfigModel1),
                sourceConfigModel1.getId().toString());
        boolean scheduleCalculationService = isScheduleCalculationService(smartRouteConfigModel, sourceConfigModel1);
        if (sourceTotalTxnCount == 0 && scheduleCalculationService) {
            SmartRouteSchedulerService existingSRSchedulerService = routingContext.getSmartRouteSchedulerService();
            if (existingSRSchedulerService != null) {
                existingSRSchedulerService.stopScheduledTask();
            }
            SmartRouteSchedulerService smartRouteSchedulerService = this.applicationContext.getBean(SmartRouteSchedulerService.class);
            routingContext.setSmartRouteSchedulerService(smartRouteSchedulerService);
            smartRouteSchedulerService.scheduleTask(sourceConfigModel1, smartRouteConfigModel);
            logger.info("Scheduler for {} millis has been set on source {}", smartRouteConfigModel.getSuccessRatioInterval(), sourceConfigModel1.getName());
        }

        cacheUtil.incrementSourceTotalTxnCount(cacheHelper.getSourceMapKey(sourceConfigModel1),
                sourceConfigModel1.getId().toString());
    }

    private void validateBin(RoutingContext routingContext, TransactionMessageModel tmm) {
        if (routingContext.getSource().isIssuerBinValidation()) {

            BinInfoModel binInfoModel = cacheService.getSchemeBin(tmm.getPan());
            if (binInfoModel == null) {
                throw new InvalidBinException("Bin: " + tmm.getPan() + ", is not valid");
            }

            if (binInfoModel.getTargetId() != null) {
                TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                        .filter(t -> t.getId().equals(Long.valueOf(binInfoModel.getTargetId()))).findFirst().get();

                tmm.setTarget(targetConfigModel.getName());
            } else {
                TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                        .filter(t -> t.getTarget() == Target.Scheme)
                        .filter(t -> t.getTargetType() == TargetType.valueOf(binInfoModel.getSchemeName())).findFirst()
                        .get();
                tmm.setTarget(targetConfigModel.getName());
            }

        }
    }

    private void processNormalTxn(Exchange exchange, TransactionMessageModel reqSrcTmm) {

        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        /*
         * Identify target end point and send request to target
         */

        TargetConfigModel txnTarget = smartRoute.getTxnTarget(exchange,reqSrcTmm);

        logger.info(LogUtils.buildLogMessage(reqSrcTmm.getEntityId(), reqSrcTmm.getSource(), reqSrcTmm.getMsgType(),
                reqSrcTmm.getTransactionId(), reqSrcTmm.getTransactionName(),
                "Constructing transaction for target: " + txnTarget.getName()));
        MessageContext tgtMsgCtx = MessageTransformer.constructMessage(reqSrcTmm, txnTarget.getName());
        TransactionMessageModel reqTgtTmm = prepareTgtMessageAndLogTlm(tgtMsgCtx, routingContext);
        reqTgtTmm.setTargetType(txnTarget.getTargetType());

        // putting RRN in header so that RoutingCorrelationManager can extract it.
        exchange.getIn().getHeaders().put(RoutingConstants.CORRELATION_ID, reqTgtTmm.getRetrievalRefNo());

        // TODO: right now getting the target connection at 1st index (21/8 - To create a seperate issue and take it up)
        String targetIp = txnTarget.getConnections().get(0).getUrlOrIp();
        String port = txnTarget.getConnections().get(0).getPortOrHeaders();

        NettyEndpoint producerEndpoint = NettyConfig.getProducerEndpoint(routingContext, targetIp + ":" + port);

        cacheUtil.incrementTargetTotalTxnCount(cacheHelper.getTargetMapKey(routingContext.getSource()),
                new TargetKey(txnTarget.getId().toString()));
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, txnTarget.getId());

        String correlationId = reqTgtTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTgtTmm.getRetrievalRefNo();

        Object resMessage = RoutingInitializationContext.getMwProducer().sendMessage(tgtMsgCtx.getRawMsg(),
                correlationId, producerEndpoint);
        logger.info(LogUtils.buildLogMessage(reqSrcTmm.getEntityId(), reqSrcTmm.getSource(), reqSrcTmm.getMsgType(),
                reqSrcTmm.getTransactionId(), reqSrcTmm.getTransactionName(),
                "Transaction sent to target: " + txnTarget.getName()));

        /*
         * set camel exchange with response received from target end point
         */
        if (resMessage != null) {

            TransactionMessageModel resSrcTmm = prepareResTargetTmm(reqSrcTmm, producerEndpoint, resMessage,
                    routingContext);
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
            exchange.getIn().setBody(resSrcTmm);
        } else {
            logger.error("Transaction could not be completed with target connection {}",
                    producerEndpoint.getEndpointUri());
            throw new IssuerUnavailableException("Issuer is not available");
        }
    }

    @Override
    public void processTxnResponse(Exchange exchange) {

        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        ConnectionType connectionType = routingContext.getSource().getConnectionType();
        if (connectionType == ConnectionType.API) {
            try {
//                apiTransactionProcessor.setApiHeader(exchange);
//                responseManipulatorUtil.manipulateTxnResponse(exchange, routingContext);
                processorHelper.removeCustomHeaders(exchange);
                validateAndCalculateSuccessRatio(routingContext);
                logger.info("Sending API Response : {}",exchange.getIn().getBody());
            } catch (Exception e) {
                throw new ResponseProcessingException("Error while processing the response message: ", e);
            }
        } else {
        	TransactionMessageModel responseSourceTmm = exchange.getIn().getBody(TransactionMessageModel.class);
        	responseManipulatorUtil.manipulateTxnResponse(exchange, routingContext);
        	
        	TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
        			.get(EXCHANGE_HEADER_REQ_SRC_TMM);
            try {
                logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(),
                        responseSourceTmm.getMsgType(), responseSourceTmm.getTransactionId(),
                        responseSourceTmm.getTransactionName(), "Transaction response received"));

                logger.info(
                        LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(),
                                responseSourceTmm.getMsgType(), responseSourceTmm.getTransactionId(),
                                responseSourceTmm.getTransactionName(), "Constructing transaction response for target"),
                        reqSrcTmm.getSource());
                MessageContext targetMsgContext = MessageTransformer.constructMessage(responseSourceTmm,
                        routingContext.getSource().getName());
                byte[] targetRawMsg = (byte[]) targetMsgContext.getRawMsg();

                TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();
                responseTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                responseTargetTmm.setResponseSentTime(OffsetDateTime.now());

                responseTargetTmm.setEpType(EpType.TARGET);

                logToTlm(responseTargetTmm, routingContext);
                ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(targetRawMsg);
                Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);
                openedChannel.writeAndFlush(rawMsgByteBuf);
                logger.info(
                        LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(),
                                responseSourceTmm.getMsgType(), responseSourceTmm.getTransactionId(),
                                responseSourceTmm.getTransactionName(), "Transaction response sent to target"),
                        reqSrcTmm.getSource());

            } catch (Exception e) {
                throw new ResponseProcessingException("Error while processing the response message: ", e);
            } finally {
                validateAndCalculateSuccessRatio(routingContext);
                responseSourceTmm = null;
                reqSrcTmm = null;
                
            }
        }
    }

    private void validateAndCalculateSuccessRatio(RoutingContext routingContext) {
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
        int sourceTotalTxnCount = cacheUtil.getSourceTotalTxnCount(cacheHelper.getSourceMapKey(sourceConfigModel),
                sourceConfigModel.getId().toString());
        boolean scheduleCalculationService = isScheduleCalculationService(smartRouteConfigModel, sourceConfigModel);
        if (sourceTotalTxnCount == smartRouteConfigModel.getSuccessRatioMaxTxns() && scheduleCalculationService) {
            logger.info("Maximum no of transactions {} for the source {} has been reached and hence calculating success ratio",
                    sourceTotalTxnCount, sourceConfigModel.getName());
            OffsetDateTime cacheLastCalculatedDate = cacheUtil.getSourceLastCalculationDate(sourceConfigModel);
            smartRoute.calculateSuccessRatio(sourceConfigModel, smartRouteConfigModel, cacheLastCalculatedDate);
            ((AbstractSmartRoute) smartRoute).logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.CALCULATION_INTERVAL);
            smartRoute.resetCache(sourceConfigModel, smartRouteConfigModel);
            routingContext.getSmartRouteSchedulerService().stopScheduledTask();
        }
    }

    @Override
    public void processTxnDecline(Exchange exchange) throws UnsupportedEncodingException {

        // increment txn failure count if its technical failure
        TransactionMessageModel declineModel = new TransactionMessageModel();
        Throwable exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class).getCause();
        TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
                .get(EXCHANGE_HEADER_REQ_SRC_TMM);
        TransactionMessageModel resTargetTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
                .get(EXCHANGE_HEADER_RES_TGT_TMM);
        ApiTxnModel apiTxnModel = (ApiTxnModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_RES_API_TXN_MODEL);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

        logger.error("Exception is ", exception);
        logger.trace("Exception type: {}", exception.getClass().getSimpleName());

        String resCode = null;
        String resDesc = null;
        String errorMsg =  null;
        Map<String, Object> resDataMap = new HashMap<>();
        MerchOrdTxnData merchOrdTxnData = null;
        DbMessageType dbMessageType = DbMessageType.INSERT;
        DbMessageType dbMessageTypeId = DbMessageType.IN_RES;
        switch (exception.getClass().getSimpleName()) {
            case "IssuerUnavailableException":
                Long id = (Long) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_TARGET_ID);
                cacheUtil.incrementTargetTotalFailedTxnCount(cacheHelper.getTargetMapKey(routingContext.getSource()),
                        new TargetKey(id.toString()));

                resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                resDesc = "IssuerUnavailableException";
                errorMsg = resDesc;
                break;

            case "BankServerException":
                Long targetId = (Long) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_TARGET_ID);
                cacheUtil.incrementTargetTotalFailedTxnCount(cacheHelper.getTargetMapKey(routingContext.getSource()),
                        new TargetKey(targetId.toString()));
                BankServerException bankServerException = (BankServerException) exception;
                String entityId = bankServerException.getEntityId();
                String mid = bankServerException.getMid();
                String merchantOrderId = bankServerException.getMerchantTxnRefNo();
                merchOrdTxnData = cacheUtil.getTxnData(entityId, mid, merchantOrderId);
                if (merchOrdTxnData != null) {
                    ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                    ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(entityId, mid);
                    if (StringUtils.isBlank(apiTxnModel.getPayOpt()) && StringUtils.isBlank(apiTxnModel.getLinkHashId()) && merchOrdTxnData.getRetryCount() >= 3) {
                        //decline the txn with retry count exhausted
                        Map<String, String> retryData = new HashMap<>();
                        MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(merchOrdTxnData.getEncData(),
                                merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                        MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
                        merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
                        merchantEncDataResponse.setRespDate(resTargetTmm.getResponseReceivedTime());
                        merchantEncDataResponse.setRespTime(resTargetTmm.getResponseReceivedTime());
                        merchantEncDataResponse.setMessage("RetryCount for this merchantOrderId : " + merchantOrderId + " is exceeded.");
                        merchantEncDataResponse.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                        String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                        errorMsg = "RetryCount for this merchantOrderId : " + merchantOrderId + " is exceeded.";
                        retryData.put("MerchantId", mid);
                        retryData.put("EncData", encMerchantData);
                        retryData.put("BankId", merchOrdTxnData.getBankId());
                        retryData.put("TerminalId", merchOrdTxnData.getTerminalId());
                        retryEvent.setRetryFlag(CommonConstants.N);
                        retryEvent.setRetryData(retryData);
                        redirectEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
                        resDataMap.put("redirectEvent",redirectEvent);
                        resDataMap.put("retryEvent",retryEvent);
                        resDataMap.put("retryCount","3");
                        merchOrdTxnData.setEncData(encMerchantData);
                        smartRouteTxnController.changeStatus(merchOrdTxnData,apiTxnModel,routingContext.getEntityId(),resTargetTmm.getTransactionId(),"Failed");
                        //cacheUtil.removeTxnData(entityId, mid, merchantOrderId);
                    } else {
                        retryEvent.setRetryFlag(CommonConstants.N);
                        if (resTargetTmm != null && (resTargetTmm.getLinkHashId() != null && !StringUtils.isBlank(resTargetTmm.getLinkHashId()))) {
                            smartRouteTxnController.paymentLinkResponse(redirectEvent, retryEvent, apiTxnModel, merchantMaster, resTargetTmm, merchOrdTxnData);
                            smartRouteTxnController.changeStatus(merchOrdTxnData,apiTxnModel,routingContext.getEntityId(),resTargetTmm.getTransactionId(),"Failed");
                            apiTxnModel.setPaymentAttemptCounter(merchOrdTxnData.getRetryCount().toString());
                            smartRouteTxnController.setPaymentStatus(null,apiTxnModel, PaymentStatus.FAILED);
                            errorMsg = "Transaction Failed.";
                        } else {
                            Map<String, String> retryData = new HashMap<>();
                            MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(merchOrdTxnData.getEncData(),
                                    merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                            MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
                            merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
                            merchantEncDataResponse.setRespDate(resTargetTmm.getResponseReceivedTime());
                            merchantEncDataResponse.setRespTime(resTargetTmm.getResponseReceivedTime());
                            merchantEncDataResponse.setMessage("Transaction Failed.");
                            merchantEncDataResponse.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                            String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                            retryData.put("merchantId", mid);
                            retryData.put("encData", encMerchantData);
                            retryData.put("bankId", merchOrdTxnData.getBankId());
                            retryData.put("terminalId", merchOrdTxnData.getTerminalId());
                            resDataMap.put("retryCount",merchOrdTxnData.getRetryCount());
                            retryEvent.setRetryFlag(CommonConstants.Y);
                            retryEvent.setRetryData(retryData);
                            if(!StringUtils.isBlank(apiTxnModel.getPayOpt()) ){
                                redirectEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
                            }else {
                                redirectEvent.setTargetUrl(merchOrdTxnData.getTxnFailedReturnUrl());
                            }
                            merchOrdTxnData.setEncData(encMerchantData);
                            smartRouteTxnController.changeStatus(merchOrdTxnData,apiTxnModel,routingContext.getEntityId(),resTargetTmm.getTransactionId(),"Failed");
                            errorMsg = "Transaction Failed.";
                        }
                        resDataMap.put("redirectEvent", redirectEvent);
                        resDataMap.put("retryEvent", retryEvent);
                    }
                }
                dbMessageType = DbMessageType.UPDATE;
                dbMessageTypeId = DbMessageType.UP_RES;
                reqSrcTmm = SerializationUtils.clone(resTargetTmm);
                reqSrcTmm.setDrcrFlag("N");
                resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                resDesc = "BankServerException";
                break;

            case "PaymentOptionMismatchException":
                PaymentOptionMismatchException paymentOptionMissmatchException = (PaymentOptionMismatchException) exception;
                merchOrdTxnData = cacheUtil.getTxnData(paymentOptionMissmatchException.getEntityId(), paymentOptionMissmatchException.getMid(), paymentOptionMissmatchException.getMerchantTxnRefNo());
                if(merchOrdTxnData != null) {
                    ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                    ResponseObj.RedirectEvent redirEvent = new ResponseObj.RedirectEvent();
                    retryEvent.setRetryFlag(CommonConstants.N);
                    if(apiTxnModel.getPayOpt() != null){
                        redirEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
                    }else {
                        redirEvent.setTargetUrl(merchOrdTxnData.getTxnFailedReturnUrl());
                    }
                    resDataMap.put("redirectEvent", redirEvent);
                    resDataMap.put("retryEvent", retryEvent);
                }
                reqSrcTmm.setDrcrFlag("N");
                resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                resDesc = "PaymentOptionMismatchException";
                errorMsg = "Transaction Failed.Please use another payment mode option";
                break;

            case "InvalidBinException":
                InvalidBinException invalidBinException = (InvalidBinException) exception;
                merchOrdTxnData = cacheUtil.getTxnData(invalidBinException.getEntityId(), invalidBinException.getMid(), invalidBinException.getMerchantTxnRefNo());
                if(merchOrdTxnData != null) {
                    ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                    ResponseObj.RedirectEvent redirEvent = new ResponseObj.RedirectEvent();
                    retryEvent.setRetryFlag(CommonConstants.N);
                    if(apiTxnModel.getPayOpt() != null){
                        redirEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
                    }else {
                        redirEvent.setTargetUrl(merchOrdTxnData.getTxnFailedReturnUrl());
                    }
                    resDataMap.put("redirectEvent", redirEvent);
                    resDataMap.put("retryEvent", retryEvent);
                }
                reqSrcTmm.setDrcrFlag("N");
                resCode = TmmConstants.RES_CODE_INVALID_CARD_NUMBER;
                resDesc = "InvalidBinException";
                errorMsg = "Card Number invalid! Kindly recheck";
                break;

            case "RefundAmountExceededException":
                resCode = TmmConstants.RES_CODE_REFUND_EXCEEDED;
                MerchantEncDataRequest refundDataReq =(MerchantEncDataRequest) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_SMART_ROUTE_REFUND_REQ);
                if(refundDataReq != null) {
                    MerchantEncDataResponse refundDataRes = new MerchantEncDataResponse();
                    refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
                    refundDataRes.setRetRefNo(reqSrcTmm.getTransactionId());
                    refundDataRes.setMessage("Refund amount exceeded");
                    refundDataRes.setStatus(PaymentStatus.FAILED.name());
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                    resDataMap.put("refundDataRes", refundDataRes);
                }
                resDesc = "Refund amount exceeded";
                errorMsg = resDesc;
                break;
            case "TransactionDateExceededException":
                resCode = TmmConstants.RES_CODE_INVALID_TXN;
                MerchantEncDataRequest refundDataRequest =(MerchantEncDataRequest) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_SMART_ROUTE_REFUND_REQ);
                if(refundDataRequest != null) {
                    MerchantEncDataResponse refundDataRes = new MerchantEncDataResponse();
                    refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataRequest);
                    refundDataRes.setRetRefNo(reqSrcTmm.getTransactionId());
                    refundDataRes.setMessage("Original Transaction Date Exceeded By 180 Days");
                    refundDataRes.setStatus(PaymentStatus.FAILED.name());
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                    resDataMap.put("refundDataRes", refundDataRes);
                }
                resDesc = "Original Transaction Date Exceeded By 180 Days";
                errorMsg = resDesc;
                break;
            case "ChargebackFoundException":
                resCode = TmmConstants.RES_CODE_INVALID_TXN;
                resDesc = "Charge Back Transaction Found";
                errorMsg = resDesc;
                break;
            case "AccountDetailsMissingException":
                resCode = TmmConstants.RES_CODE_MANDATORY_FIELD_NOT_PRESENT;
                resDesc = "Merchant account details are missing";
                errorMsg = resDesc;
                break;
            case "InvalidVoidOrReversalDataException":
            case "NotFound":
                resCode = TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_FOUND;
                resDesc = "Original txn not found";
                errorMsg = resDesc;
                break;

            case "InvalidRefundTransactionException":
                resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
                String message = exception.getMessage();
                resDesc = message;
                errorMsg = resDesc;
                break;
            case "DataAuthenticationException":
                resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                String msg = exception.getMessage();
                resDesc = msg;
                errorMsg = resDesc;
                break;
            case "TransactionCencelException":
                TransactionCencelException cancelException = (TransactionCencelException) exception;
                String cancelEntityId = cancelException.getEntityId();
                String cancelMid = cancelException.getMid();
                String cancelMerchantTxnRefNo = cancelException.getMerchantTxnRefNo();
                merchOrdTxnData = cacheUtil.getTxnData(cancelEntityId,cancelMid,cancelMerchantTxnRefNo);
                if (merchOrdTxnData != null) {
                    ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                    ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(cancelEntityId, cancelMid);
                    reqSrcTmm.setResCode(TmmConstants.RES_CODE_ISSUER_UNAVAILABLE);
                    reqSrcTmm.setTransactionName("transaction");
                    retryEvent.setRetryFlag(CommonConstants.N);
                    MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(merchOrdTxnData.getEncData(), merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                    if (reqSrcTmm != null && !StringUtils.isBlank(reqSrcTmm.getLinkHashId())) {
                        Map<String, String> retryData;
                        retryData = new HashMap<>();
                        retryData.put("TransactionId", reqSrcTmm.getTransactionId());
                        retryData.put("PaymentStatus", PaymentStatus.FAILED.name());
                        retryData.put("Email", merchantEncDataRequest.getEmail());
                        retryData.put("MobileNo", merchantEncDataRequest.getPhone());
                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                        Date date = Date.from(OffsetDateTime.now().toInstant());
                        retryData.put("Date", formatter.format(date));
                        retryData.put("OrderId", cancelMerchantTxnRefNo);
                        retryData.put("PaymentMode", "");
                        retryData.put("MerchantName", merchantMaster.getMerchantName());
                        retryData.put("Amount", IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(new BigInteger(reqSrcTmm.getTxnAmt()).toString()));
                        retryData.put("RRN", "NA");
                        redirectEvent.setTargetUrl("");
                        retryEvent.setRetryData(retryData);
                        smartRouteTxnController.setPaymentStatus(null, apiTxnModel, PaymentStatus.FAILED);
                        smartRouteTxnController.changeStatus(merchOrdTxnData,apiTxnModel,routingContext.getEntityId(),reqSrcTmm.getTransactionId(),"Failed");
                        errorMsg = "Transaction Canceled";
                    } else {
                        MerchantEncDataResponse merchantEncDataResponse = new MerchantEncDataResponse();
                        merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
                        merchantEncDataResponse.setRespDate(reqSrcTmm.getResponseReceivedTime());
                        merchantEncDataResponse.setRespTime(reqSrcTmm.getResponseReceivedTime());
                        merchantEncDataResponse.setMessage("Transaction Canceled");
                        merchantEncDataResponse.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                        String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                        Map<String, String> retryData = new HashMap<>();
                        retryData.put("MerchantId", cancelMid);
                        retryData.put("EncData", encMerchantData);
                        retryData.put("BankId", cancelEntityId);
                        retryData.put("TerminalId", merchOrdTxnData.getTerminalId());
                        retryEvent.setRetryData(retryData);
                        retryEvent.setRetryFlag("N");
                        redirectEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
                        errorMsg = "Transaction Canceled";
                        merchOrdTxnData.setEncData(encMerchantData);
                        smartRouteTxnController.changeStatus(merchOrdTxnData,apiTxnModel,routingContext.getEntityId(),reqSrcTmm.getTransactionId(),"Failed");
                    }
                    resDataMap.put("redirectEvent", redirectEvent);
                    resDataMap.put("retryEvent", retryEvent);
                }
                resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                resDesc = errorMsg;
                errorMsg = resDesc;
                break;
            default:
                resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
                resDesc = "Target Is Unavailable";
                errorMsg = resDesc;
                break;
        }

        if (reqSrcTmm == null) {
            declineModel.setEntityId(routingContext.getEntityId());
        } else {
            declineModel = reqSrcTmm;
            declineModel.setTransactionName(reqSrcTmm.getTransactionName() != null ? "decline." + reqSrcTmm.getTransactionName() : "transaction" );
        }

        declineModel.setResCode(resCode);
        declineModel.setTlmMessageType(TlmMessageType.RESPONSE);
        declineModel.setReasonCode(resCode);
        declineModel.setErrorDescription(resDesc);

        logger.trace("Decline Response Code: {}, Decline txn: {}", declineModel.getResCode(),
                declineModel.getTransactionName());

        if (routingContext.getSource().getConnectionType() == ConnectionType.ISO) {
            sendDeclineMessage(exchange, declineModel, reqSrcTmm, routingContext, resCode);
        } else if (routingContext.getSource().getConnectionType() == ConnectionType.API) {
            String apiResponse = null;
            //SET TXN_MSG_MODEL
            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(dbMessageType,dbMessageTypeId,declineModel);
            logger.info(LogUtils.buildSMLogMessage(declineModel.getEntityId(),declineModel.getMerchantTxnRefNo(),declineModel.getTransactionId(),
                    declineModel.getTransactionName(),"Decline Meesage Model : {}"), declineModel);

            logToTlm(declineModel, routingContext);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, errorMsg,resDataMap);
            if(apiTxnModel != null && !StringUtils.isBlank(apiTxnModel.getEncryptionEnable()) && apiTxnModel.getEncryptionEnable().equalsIgnoreCase("Y")){
                try {
                    String errorApiResponse = apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
                    apiResponse = apiTransactionProcessor.getSmartRouteApiResponse(ResponseMsgType.SUCCESS, null, errorApiResponse,  exchange);
                } catch (NoSuchAlgorithmException e) {
                    logger.info("Error while encrypting smart route exception response :"+e.getMessage());
                }
            }
            processorHelper.removeCustomHeaders(exchange);
            exchange.getIn().setBody(apiResponse);
        }
    }

    private void sendDeclineMessage(Exchange exchange, TransactionMessageModel declineModel, TransactionMessageModel reqSrcTmm, RoutingContext routingContext, String resCode) {
        MessageContext targetMsgContext = MessageTransformer.constructMessage(declineModel, reqSrcTmm.getSource());

        byte[] targetRawMsg = (byte[]) targetMsgContext.getRawMsg();

        TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();
        // setting drcr flag to N as txn is declined
        responseTargetTmm.setDrcrFlag("N");
        responseTargetTmm.setResCode(resCode);
        logToTlm(responseTargetTmm, routingContext);


        ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(targetRawMsg);

        Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);
        openedChannel.writeAndFlush(rawMsgByteBuf);
    }

    private void startScheduler(SmartRouteConfigModel smartRouteConfigModel) {

    }

    @Override
    public SourceProcessor getSourceProcessor() {
        return SourceProcessor.SMART_ROUTE;
    }

    private String generateTransactionId() {
        return Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
    }

    private void logToTlm(TransactionMessageModel tmm, RoutingContext routingContext) {
        if (routingContext.isTxnLoggingOn() && TmmConstants.isTxnLogRequired(tmm.getTransactionName())) {
            String epId = tmm.getSource() == null ? tmm.getTarget() : tmm.getSource();
            KafkaProducer kafkaProducer = RoutingInitializationContext.getKafkaProducer();
            KafkaProducer kafkaFeederProducer = RoutingInitializationContext.getKafkafeederProducer();
//            logger.debug(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
//                    "Logging transaction to TLM"));
            kafkaProducer.sendMessage(tmm, tmm.getTransactionId());
            kafkaFeederProducer.sendMessage(tmm,tmm.getTransactionId());
//            logger.info(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
//                    "Logged transaction to TLM"));
        }
    }

    private TransactionMessageModel prepareResTargetTmm(TransactionMessageModel reqSrcTmm,
                                                        NettyEndpoint producerEndpoint, Object resMessage, RoutingContext routingContext) {
        TransactionMessageModel resSrcTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, reqSrcTmm.getTransactionName());
        resSrcTmm.setEpType(EpType.SOURCE);
        resSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resSrcTmm.setResponseReceivedTime(OffsetDateTime.now());
        resSrcTmm.setTransactionId(reqSrcTmm.getTransactionId());
        resSrcTmm.setRawResponse(ISOUtil.byte2hex((byte[]) resMessage));
        resSrcTmm.setDrcrFlag(reqSrcTmm.getDrcrFlag());

// for batch settlement consistency
        resSrcTmm.setTerminalBatchNo(reqSrcTmm.getTerminalBatchNo());

// all transaction needs to be tested for the condition.
        resSrcTmm.setProcessingCode(reqSrcTmm.getProcessingCode());

// for getting consistency in data for void transactions.
        resSrcTmm.setOriginalTmm(reqSrcTmm.getOriginalTmm());

//        logger.trace(buildLogMessage(reqSrcTmm.getEntityId(), null, null, reqSrcTmm.getTransactionId(),
//                "Response Source Transaction message model: {}"), resSrcTmm);
        logToTlm(resSrcTmm, routingContext);

// set request data in response as required in SOURCE
        resSrcTmm.setNiiId(reqSrcTmm.getNiiId());
        resSrcTmm.setStan(reqSrcTmm.getStan());

        resSrcTmm.setSettlementCurrenyCode(reqSrcTmm.getSettlementCurrenyCode());

        String responseTxnName = resSrcTmm.getTransactionName().replace("response", "request");
        if (!reqSrcTmm.getTransactionName().equals(responseTxnName)) {
            String reqAsRes = reqSrcTmm.getTransactionName().replace("request", "response");
            resSrcTmm.setTransactionName(reqAsRes);
        }

        if (resSrcTmm.getResCode().equals(TmmConstants.RES_CODE_SUCCESS))
            logger.info("Transaction {} completed for target connection {}", reqSrcTmm.getTransactionName(),
                    producerEndpoint.getEndpointUri());

        return resSrcTmm;
    }


    private void synchronizedLogToTlm(TransactionMessageModel originalTmm, RoutingContext routingContext) {
        TlmMessageType msgType = TlmMessageType.RESPONSE;
        originalTmm.setTlmMessageType(msgType);
        logToTlm(originalTmm, routingContext);

        TransactionMessageModel clonedTmm = SerializationUtils.clone(originalTmm);
        clonedTmm.setTlmMessageType(TlmMessageType.REQUEST);
        logToTlm(clonedTmm, routingContext);
    }

    private TransactionMessageModel prepareTgtMessageAndLogTlm(MessageContext targetMsgContext,
                                                               RoutingContext routingContext) {
        TransactionMessageModel reqTgtTmm = targetMsgContext.getTransactionMessageModel();

        reqTgtTmm.setEpType(EpType.TARGET);
        reqTgtTmm.setTlmMessageType(TlmMessageType.REQUEST);
        reqTgtTmm.setTransactionId(reqTgtTmm.getTransactionId());
        reqTgtTmm.setRequestSentTime(OffsetDateTime.now());

//        logger.trace(buildLogMessage(reqTgtTmm.getEntityId(), reqTgtTmm.getSource(), reqTgtTmm.getMsgType(),
//                reqTgtTmm.getTransactionId(), "Request Target Transaction message model: " + reqTgtTmm));

        logToTlm(reqTgtTmm, routingContext);

        return reqTgtTmm;
    }

    private boolean isScheduleCalculationService(SmartRouteConfigModel smartRouteConfigModel, SourceConfigModel sourceConfigModel) {
        boolean scheduleCalculationService = true;
        if (smartRouteConfigModel.getRouteType() == RouteType.SUCCESS_RATIO_STATIC) {
            Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
            Iterator<TargetKey> iterator = targetData.keySet().iterator();
            while (iterator.hasNext()) {
                TargetKey targetKey = iterator.next();
                TargetInfo targetInfo = targetData.get(targetKey);
                if (targetInfo.getStaticTargetInfo().getPriority() == TargetPriority.SECONDARY && targetInfo.getStaticTargetInfo().getCurrentTarget()) {
                    scheduleCalculationService = false;
                }
            }
        }
        return scheduleCalculationService;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

}
