package com.isg.mw.routing.context;

import com.isg.kafka.config.KafkaConfig;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheHelper;
import com.isg.mw.cache.mgmt.config.InitSmartRouteCacheValue;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.SrcActionExtn;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import com.isg.mw.core.model.sr.TargetLCRConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.routing.config.RoutingProperties;
import com.isg.mw.routing.smartroute.SmartRouteSchedulerService;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.camel.CamelContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Component
public class RoutingInitializationContext {

    private static Logger logger = LogManager.getLogger(RoutingInitializationContext.class);

    private static AutowireCapableBeanFactory autowireBeanFactory;

    @Getter
    private static Map<String, Map<String, EndpointMetaData>> targetEndpointInfoMap = new ConcurrentHashMap<>();

    @Autowired
    private CacheHelper cacheHelper;

    private static CacheHelper cacheHelperStatic;

    @Getter
    private static KafkaProducer kafkaProducer;

    @Getter
    private static KafkaProducer kafkafeederProducer;

    @Getter
    private static KafkaProducer srKafkaProducer;

    @Getter
    private static KafkaProducer kafkaReversalProducer;

    @Getter
    private static MwProducer mwProducer;

    @Autowired
    private RoutingProperties msgTransformationProperties;

    private static RoutingProperties msgTransformationPropertiesStatic;

    @Getter
    private static KafkaProducer payLinkKafkaProducer;

    @Getter
    private static List<RoutingContext> routingContextList = new ArrayList<>();

    @Value("${smart.route.init.status:false}")
    private boolean smartRouteInitStatus;

    private static boolean smartRouteInitStatusStatic;

    @PostConstruct
    public void setProperties() {
        RoutingInitializationContext.msgTransformationPropertiesStatic = msgTransformationProperties;
        RoutingInitializationContext.cacheHelperStatic = cacheHelper;
        smartRouteInitStatusStatic = smartRouteInitStatus;
    }

    @Autowired
    public void setAutowireBeanFactory(AutowireCapableBeanFactory autowireBeanFactory) {
        RoutingInitializationContext.autowireBeanFactory = autowireBeanFactory;
    }

    public static MainRouteBuilder createMainRouteBuilderBean(List<RoutingContext> routingContextList,
                                                              CamelContext camelContext) {
        MainRouteBuilder mrb = new MainRouteBuilder(routingContextList, camelContext);
        autowireBeanFactory.autowireBean(mrb);
        return mrb;
    }

    private RoutingInitializationContext() {

    }

    /**
     * Endpoint Definition
     * <p>
     * key -> entityId value -> SourceConfigModel, TargetConfigModel
     * <p>
     * Route Definition
     *
     * @param camelContext
     */
    public static void initializeRouting(List<SourceConfigModel> sourceList, List<TargetConfigModel> targetList,
                                         List<MessageTransformationConfigModel> msgTransformationList, List<SmartRouteConfigModel> smartRoutesList,
                                         List<PaymentModesModel> paymentModesList, List<PaymentModeOptionsModel> paymentModesOptionsList,
                                         List<TargetPaymentModesModel> targetPaymentModesList, List<TargetPaymentModeOptionsModel> targetPaymentModeOptionsList,
                                         List<TargetLCRConfigModel> targetLCRConfigs, List<MerchantPaymentModesModel> merchantPaymentModesModels, List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptionsModels,
                                         List<MerchantTargetPreferencesModel> merchantTargetPreferencesModels, List<MerchantMasterModel> merchantMasterModels, CamelContext camelContext) {
        logger.info("Initializing routing module");

        initKafkaProducer(msgTransformationPropertiesStatic.getKafkaBrokers(), msgTransformationPropertiesStatic.getKafkaRoutingTopic());
        initKafkafeederProducer(msgTransformationPropertiesStatic.getKafkaBrokers(),msgTransformationPropertiesStatic.getKafkaFeederRoutingTopic());
        initSmartRouteKafkaProducer(msgTransformationPropertiesStatic.getKafkaBrokers(),
                msgTransformationPropertiesStatic.getSrkafkaTopic());
        initKafkaAutoReversalProducer(msgTransformationPropertiesStatic.getKafkaBrokers(), msgTransformationPropertiesStatic.getKafkaAutoReversalTopic());
        initPayLinksKafkaProducer(msgTransformationPropertiesStatic.getKafkaBrokers(),msgTransformationPropertiesStatic.getPayLinkskafkaTopic());
        initMwProducer(camelContext);

        MessageTransformationContext.initMTM(sourceList, targetList, msgTransformationList);

        if (smartRouteInitStatusStatic) {
            Map<Long, InitSmartRouteCacheValue> initSmartRouteCacheValueMap = cacheHelperStatic.initCache(sourceList, targetList, smartRoutesList,
                paymentModesList, paymentModesOptionsList, targetPaymentModesList, targetPaymentModeOptionsList,
                targetLCRConfigs, merchantPaymentModesModels, merchantPaymentModeOptionsModels, merchantTargetPreferencesModels, merchantMasterModels);
            initSmartRouteCache(initSmartRouteCacheValueMap);
        }
        sourceList.forEach(source -> {
            List<TargetConfigModel> targetListForEntity = targetList.stream()
                    .filter(targetFilter -> targetFilter.getEntityId().equals(source.getEntityId()))
                    .collect(Collectors.toList());

            List<MessageTransformationConfigModel> routingDefListForEntity = msgTransformationList.stream()
                    .filter(routingDefFilter -> routingDefFilter.getEntityId().equals(source.getEntityId()))
                    .collect(Collectors.toList());

            Optional<SmartRouteConfigModel> smartRouteConfigModel = smartRoutesList == null ? Optional.empty() : smartRoutesList.stream()
                    .filter(smartRouteConfigModel1 -> smartRouteConfigModel1.getSourceId().equals(source.getId()))
                    .findFirst();

            RoutingContext routingContext = new RoutingContext();
            routingContext.setEntityId(source.getEntityId());
            routingContext.setSource(source);
            routingContext.setTargets(targetListForEntity);
            routingContext.setTxnLoggingDebug(
                    source.getTxnLogging() == SrcActionExtn.DEBUG);
            routingContext.setTxnLoggingOn(source.getTxnLogging() == SrcActionExtn.DEBUG
                    || source.getTxnLogging() == SrcActionExtn.ON
                    || source.getTxnLogging() == SrcActionExtn.ON_NO_BATCH);
            routingContext.setConnectionType(source.getConnectionType());
            routingContext.setCamelContext(camelContext);
            routingContext.setMsgTransformationDefinitions(routingDefListForEntity);
            routingContext.setSmartRouteConfigModel(smartRouteConfigModel.orElse(null));
            routingContextList.add(routingContext);

            Map<String, EndpointMetaData> targetEpMap = new ConcurrentHashMap<>();
            targetListForEntity.forEach(target -> {
                target.getConnections().forEach(tarConn -> {
                    EndpointMetaData endpointMetaData = getEndpointMetaData(target, tarConn, source);
                    if (StringUtils.isBlank(tarConn.getPortOrHeaders())) {
                        targetEpMap.put(tarConn.getUrlOrIp(), endpointMetaData);
                    } else {
                        targetEpMap.put(tarConn.getUrlOrIp() + ":" + tarConn.getPortOrHeaders(), endpointMetaData);
                    }
                });
            });
           //if(!targetEndpointInfoMap.containsKey(source.getEntityId()))
            	targetEndpointInfoMap.put(source.getEntityId(), targetEpMap);
            logger.info("TargetEndPointMap: {}", targetEndpointInfoMap);
        });

        try {
            camelContext.addRoutes(createMainRouteBuilderBean(routingContextList, camelContext));
        } catch (Exception e) {
            logger.error("", e);
        }
    }

    private static void initSmartRouteCache(Map<Long, InitSmartRouteCacheValue> initSmartRouteCacheValueMap) {
        if (initSmartRouteCacheValueMap != null) {
            initSmartRouteCacheValueMap.forEach((key, value) -> {
                SmartRouteSchedulerService smartRouteSchedulerService = autowireBeanFactory.getBean(SmartRouteSchedulerService.class);

                long schedulerInterval = value.getSmartRouteConfigModel().getSuccessRatioInterval() - value.getTimeDiffInMillis();
                smartRouteSchedulerService.scheduleTask(value.getSourceConfigModel(), value.getSmartRouteConfigModel(), schedulerInterval);
                logger.info("Scheduler for {} millis has been set on source {}", schedulerInterval, value.getSourceConfigModel().getName());
            });
        }
    }

    private static void initKafkaProducer(String brokers, String topicName) {
        kafkaProducer = new KafkaProducer(getKafkaConfiguration(brokers, topicName, TransactionMessageModelSerializer.class));
        kafkaProducer.init();
    }

    private static void initKafkafeederProducer(String brokers, String topicName) {
        kafkafeederProducer = new KafkaProducer(getKafkaConfiguration(brokers, topicName, TransactionMessageModelSerializer.class));
        kafkafeederProducer.init();
    }

    private static void initSmartRouteKafkaProducer(String brokers, String topicName) {
        srKafkaProducer = new KafkaProducer(getKafkaConfiguration(brokers, topicName, SmartRouteStatisticsModelSerializer.class));
        srKafkaProducer.init();
    }

    private static void initPayLinksKafkaProducer(String brokers, String topicName) {
        payLinkKafkaProducer = new KafkaProducer(getKafkaConfiguration(brokers, topicName, PaymentLinksModelSerializer.class));
        payLinkKafkaProducer.init();
    }

    private static void initKafkaAutoReversalProducer(String brokers, String topicName) {
        kafkaReversalProducer = new KafkaProducer(getKafkaConfiguration(brokers, topicName, TransactionMessageModelSerializer.class));
        kafkaReversalProducer.init();
    }

    private static void initMwProducer(CamelContext camelContext) {
        mwProducer = new MwProducer();
        mwProducer.initializeProducerTemplate(camelContext);
        camelContext.start();
    }

    private static KafkaConfig getKafkaConfiguration(String brokers, String topicName, Class<?> serializer) {
        KafkaConfig config = new KafkaConfig();
        config.setTopicName(topicName);
        config.setBrokers(brokers);
        config.setValueSerializer(serializer);

        config.setKafkaSecurityEnabled(msgTransformationPropertiesStatic.isKafkaSecurityEnabled());
        config.setProtocol(msgTransformationPropertiesStatic.getProtocol());
        config.setTrustStoreLocation(msgTransformationPropertiesStatic.getTrustStoreLocation());
        config.setTrustStorePassword(msgTransformationPropertiesStatic.getTrustStorePassword());
        config.setTrustStoreType(msgTransformationPropertiesStatic.getTrustStoreType());
        config.setEndPointAlgorithm("");
        config.setSaslJaasConfig(msgTransformationPropertiesStatic.getSaslJaasConfig());
        config.setSaslMechanism(msgTransformationPropertiesStatic.getSaslMechanism());
        config.setMaxBlockMs(msgTransformationPropertiesStatic.getKafkaMaxBlockMs());

        return config;
    }

    private static EndpointMetaData getEndpointMetaData(TargetConfigModel target, TargetConnection tarConn, SourceConfigModel source) {
        EndpointMetaData endpointMetaData = new EndpointMetaData();
        endpointMetaData.setEntityId(target.getEntityId());
        endpointMetaData.setEpName(target.getName());
        endpointMetaData.setSignedOn(false);
        endpointMetaData.setPort(tarConn.getPortOrHeaders());
        endpointMetaData.setHeartBeatDelay(target.getHeartBeatDelay());
        endpointMetaData.setPinTranslationType(target.getPinTranslationType());
        endpointMetaData.setReconnectDelay(msgTransformationPropertiesStatic.getReconnectDelay());
        endpointMetaData.setSignOnRequired(target.isSignonRequired());
        endpointMetaData.setTargetConfigModel(target);
        endpointMetaData.setSourceProcessor(source.getSourceProcessor());
        endpointMetaData.setTargetType(target.getTargetType().name());
        endpointMetaData.setConnectionAlive(target.isConnectionAlive());
        return endpointMetaData;
    }

    @Setter
    @Getter
    @ToString
    public static class EndpointMetaData {
        private String entityId;
        private String epName;
        private boolean signedOn;
        private String port;
        private int heartBeatDelay;
        private PinTranslationType pinTranslationType;
        private int reconnectDelay;
        private boolean isSignOnRequired;
        private TargetConfigModel targetConfigModel;
        private boolean heartbeatScheduled;
        private boolean reconnectScheduled;
        private SourceProcessor sourceProcessor;
        private String targetType;
        private boolean isConnectionAlive;
    }
}
