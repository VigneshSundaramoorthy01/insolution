package com.isg.mw.routing.route;

import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.RequestProcessingException;
import com.isg.mw.routing.exception.ResponseProcessingException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.support.processor.idempotent.MemoryIdempotentRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;


import static com.isg.mw.routing.config.RoutingConstants.*;

public class SocketRouter extends RouteBuilder {

    private RoutingContext routingContext;

    @Autowired
    private TransactionProcessor transactionProcessor;

    @Autowired
    private NetworkManagement networkManagement;

    private final MemoryIdempotentRepository idempotentRepository = (MemoryIdempotentRepository) MemoryIdempotentRepository.memoryIdempotentRepository();

    public SocketRouter(RoutingContext routingContext) {
        this.routingContext = routingContext;
    }

    private final Logger logger = LogManager.getLogger(getClass());

    /**
     * source target 7070 8070 7070 8071
     */
    @Override
    public void configure() {

        networkManagement.doConnect(this.routingContext);
        networkManagement.doSignOn(this.routingContext);
        networkManagement.doHostSessionActivation(this.routingContext);
        networkManagement.doDynamicKeyExchange(this.routingContext);
        networkManagement.doHeartBeat(this, this.routingContext);
        networkManagement.doReconnectTarget(this, this.routingContext);
        networkManagement.doEftposReconnect(this, this.routingContext);
        networkManagement.doEftposSettlement(this, this.routingContext);
        networkManagement.doNpciHeartBeat(this, this.routingContext);



        //networkManagement.doSignOff(this.routingContext);
        NettyEndpoint consumerEndpoint = NettyConfig.getConsumerEndpoint(this.routingContext);

        //Following is being used to avoid duplicate txn, it keeps the entire request body as a unique key to identify
        //duplicate txn. Keeps 1000 entries in cache.
        from(consumerEndpoint)
                .idempotentConsumer(body(), idempotentRepository)
                .skipDuplicate(false)
                .process(
                        exchange -> exchange.getIn().getHeaders().put(EXCHANGE_HEADER_ROUTING_CTX, this.routingContext))
                .doTry().bean(transactionProcessor, "processRequest").doCatch(RequestProcessingException.class)
                .process(exchange -> transactionProcessor.processDecline(exchange)).end()
                .process(
                        exchange -> exchange.getIn().getHeaders().put(EXCHANGE_HEADER_ROUTING_CTX, this.routingContext))
                .doTry().bean(transactionProcessor, "processResponse").doCatch(ResponseProcessingException.class)
                .process(exchange -> transactionProcessor.processDecline(exchange)).end();
    //        networkManagement.doSignOff(this.routingContext);
    }

}
