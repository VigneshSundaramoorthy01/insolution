package com.isg.mw.routing.exception;

public class ReversalAmountExceededException extends RuntimeException{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public ReversalAmountExceededException(String errorMsg) {
        super(errorMsg);
    }

    public ReversalAmountExceededException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }
}
