package com.isg.mw.routing.config;

public final class RoutingConstants {


    private RoutingConstants() {
    }

    public final static String REQUEST = "Request";
    public final static String RESPONSE = "Response";

    public static final String EXCHANGE_HEADER_ROUTING_CTX = "routingContext";
    public static final String EXCHANGE_HEADER_TARGET_SCHEME = "targetScheme";
    public static final String EXCHANGE_HEADER_TARGET_IP = "targetIp";
    public static final String EXCHANGE_HEADER_EP_METADATA = "endpointMetaData";
    public static final String EXCHANGE_HEADER_API_TXN_MODEL = "apiTxnModel";
    public static final String EXCHANGE_HEADER_REQ_SRC_TMM = "reqSrcTmm";
    public static final String EXCHANGE_HEADER_REQ_TGT_TMM = "reqTgtTmm";
    public static final String EXCHANGE_HEADER_TARGET_ID = "targetId";
    public static final String EXCHANGE_HEADER_TARGET_BUSINESS_CLASS = "targetBusinessClass";
    public static final String EXCHANGE_HEADER_API_RESP_TMM = "resSrcTmm";
    public static final String EXCHANGE_HEADER_API_RESP_CYBS = "cybsRes";
    public static final String EXCHANGE_HEADER_TIMEOUTE_REVERSAL_TMM = "timeOutRevrsalTmm";
    public static final String EXCHANGE_HEADER_REPEAT_TIMEOUTE_REVERSAL = "repeatTimeOutRevrsa";
    public static final String EXCHANGE_HEADER_REQUEST_DECLINED = "RequestDeclined";
    public static final String EXCHANGE_HEADER_CORRELATION_ID = "correlationId";
    public static final String EXCHANGE_HEADER_RES_API_TXN_MODEL = "apiTxnModel";
    public static final String EXCHANGE_HEADER_SMART_ROUTE_REFUND_REQ = "merchantDataEncReq";
    public static final String EXCHANGE_HEADER_RES_TGT_TMM = "reqTgtTmm";
    public static final String EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE = "fundTransfer";
    public static final String EXCHANGE_HEADER_FUND_TRANSFER_BANK_ACC_NO = "creditAccNo";

    public static final String KAFKA_BROKERS = "kafka.brokers";
    public static final String KAFKA_TOPIC = "kafka.topic";

    public static final String CORRELATION_ID = "correlationId";
    public static final String NETTY_WORKERCOUNT = "netty.workercount";
    public static final String TARGET_REQUEST_TIMEOUT_GLOBAL_DEFAULT = "target.request.timeout.global.default";
    public static final String TARGET_CONNECT_TIMEOUT_GLOBAL_DEFAULT = "target.connect.timeout.global.default";
    public static final String TRANSACTION_RESPONSE_TIMEOUT = "transaction.response.timeout";
    public static final String RUPAY_MAC_ENABLE = "rupay.mac.enable";


    public static final String APPLICATION_DATA_JSON = "application-data.json";
    public static final String RRN_COUNTER = "rrnCounter";
    public static final String RRN_COUNTER_DEFAULT_VALUE = "";

    public static final String TERMINAL_KEYS = "terminalKeys";

    public static final String RESPONSE_DESC = "responseDesc";
    public static final String RESPONSE_CODE = "responseCode";
    public static final String RESPONSE_APPROVAL_CODE = "approvalCode";
    public static final String RESPONSE_ERR_REASON = "reason";
}
