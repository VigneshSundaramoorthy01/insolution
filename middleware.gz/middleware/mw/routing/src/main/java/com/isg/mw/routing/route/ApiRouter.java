package com.isg.mw.routing.route;

import com.isg.mw.core.model.sc.Urls;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.RequestProcessingException;
import com.isg.mw.routing.exception.ResponseProcessingException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.rest.RestEndpoint;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

public class ApiRouter extends RouteBuilder {

    private RoutingContext routingContext;

    @Autowired
    private TransactionProcessor transactionProcessor;

    @Autowired
    private NetworkManagement networkManagement;

    @Value("${api.server.port}")
    private String apiServerPort;

    public ApiRouter(RoutingContext routingContext) {
        this.routingContext = routingContext;
    }

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public void configure() {

        networkManagement.doSignOn(this.routingContext);
        networkManagement.doHostSessionActivation(this.routingContext);
        networkManagement.doDynamicKeyExchange(this.routingContext);
        networkManagement.doHeartBeat(this, this.routingContext);
        networkManagement.doReconnectTarget(this, this.routingContext);

        NettyConfig.setRestConfiguration(apiServerPort, this.routingContext);
        //RestEndpoint consumerEndpoint = NettyConfig.getRestConsumerEndpoint(this.routingContext);
        RestEndpoint consumerEndpoint = null;
        List<Urls> srcUrls = this.routingContext.getSource().getAdditionalData().getApiUrls().getUrls();
        for (Urls urls: srcUrls){
            consumerEndpoint = NettyConfig.getRestConsumerEndpoint(this.routingContext,urls);
            from(consumerEndpoint)
                    .process(exchange ->
                            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_ROUTING_CTX, this.routingContext))
                    .doTry().bean(transactionProcessor, "processRequest").doCatch(RequestProcessingException.class)
                    .process(exchange ->
                            transactionProcessor.processDecline(exchange)).stop().end()
                    .process(exchange ->
                            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_ROUTING_CTX, this.routingContext))
                    .doTry().bean(transactionProcessor, "processResponse").doCatch(ResponseProcessingException.class)
                    .process(exchange ->
                            transactionProcessor.processDecline(exchange)).stop().end();
        }
    }
}
