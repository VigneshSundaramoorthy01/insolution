package com.isg.mw.routing.route.bmsswitch;

import com.isg.bms.constant.BmsSwitchConstant;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.route.ITransactionProcessor;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.io.UnsupportedEncodingException;

import static com.isg.mw.routing.config.RoutingConstants.*;

@Component
public class BmsSwitchProcessor implements ITransactionProcessor {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    BmsProcessorHelper bmsProcessorHelper;

    @Override
    public void processTxnRequest(Exchange exchange) {

        logger.debug("Entry in [BmsSwitchProcessor] processTxnRequest method with exchange object::"+exchange);
        int startIndex = exchange.getFromEndpoint().getEndpointUri().lastIndexOf("/accesspoint/");
        int lastIndex = exchange.getFromEndpoint().getEndpointUri().lastIndexOf("?");
        String endpointUri = exchange.getFromEndpoint().getEndpointUri().substring(startIndex + 13, lastIndex);
        int index = endpointUri.indexOf("/");
        String actualEndpoint = (index<0) ? endpointUri : endpointUri.substring(0,index);
        logger.info("Actual Endpoint : {} " , actualEndpoint);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        try{
            String npciReq;
            switch (actualEndpoint){
                case BmsSwitchConstant.BILL_FETCH_REQUEST:
                    npciReq = exchange.getIn().getBody(String.class);
                    logger.debug("Bill Fetch Request Received : {} ",npciReq);
                    if (bmsProcessorHelper.xmlTagsValidate(npciReq, actualEndpoint)) {
                        String npciAck = bmsProcessorHelper.prepareNpciAck(npciReq, BmsSwitchConstant.BILL_FETCH_REQUEST);
                        exchange.getIn().setBody(npciAck);
                        logger.info("Bill Fetch Request Received And ACK Send Successfully : ");
                        exchange.getIn().setHeader(EXCHANGE_HEADER_ROUTING_CTX, routingContext);
                        bmsProcessorHelper.processNormalTransaction(exchange, npciReq, actualEndpoint, routingContext);
                    }
                    break;
                case BmsSwitchConstant.BILL_PAY_REQUEST:
                    npciReq = exchange.getIn().getBody(String.class);
                    logger.debug("Bill Pay Request Received : {} ",npciReq);
                    if (bmsProcessorHelper.xmlTagsValidate(npciReq, actualEndpoint)) {

                        String billPayNpciAck = bmsProcessorHelper.prepareNpciAck(npciReq, BmsSwitchConstant.BILL_PAY_REQUEST);
                        exchange.getIn().setBody(billPayNpciAck);
                        logger.info("Bill Payment Request Received And ACK Send Successfully : ");
                        exchange.getIn().setHeader(EXCHANGE_HEADER_ROUTING_CTX, routingContext);
                        bmsProcessorHelper.processNormalTransaction(exchange, npciReq, actualEndpoint, routingContext);
                    }
                    break;
                case BmsSwitchConstant.BILL_STATUS_REQUEST:
                    npciReq = exchange.getIn().getBody(String.class);
                    logger.debug("Bill Status Request Received : {} ",npciReq);
                    if (bmsProcessorHelper.xmlTagsValidate(npciReq, actualEndpoint)) {
                        String billStatusNpciAck = bmsProcessorHelper.prepareNpciAck(npciReq, BmsSwitchConstant.BILL_STATUS_REQUEST);
                        exchange.getIn().setBody(billStatusNpciAck);
                        logger.info("Bill Status Request Received And ACK Send Successfully : ");
                        exchange.getIn().setHeader(EXCHANGE_HEADER_ROUTING_CTX, routingContext);
                        bmsProcessorHelper.processNormalTransaction(exchange, npciReq, actualEndpoint, routingContext);
                    }
                    break;
                case BmsSwitchConstant.BILL_PAY_REVERSAL:
                    npciReq = exchange.getIn().getBody(String.class);
                    logger.debug("Bill Pay Reversal Request Received : {} ",npciReq);
                    if (bmsProcessorHelper.xmlTagsValidate(npciReq, actualEndpoint)) {
                        String npciRevrsalAck = bmsProcessorHelper.prepareNpciAck(npciReq, BmsSwitchConstant.BILL_PAY_REVERSAL);
                        exchange.getIn().setBody(npciRevrsalAck);
                        logger.info("Bill Pay Reversal Request Received And ACK Send Successfully : ");
                        exchange.getIn().setHeader(EXCHANGE_HEADER_ROUTING_CTX, routingContext);
                        bmsProcessorHelper.billPayReversalReq(exchange, npciReq, actualEndpoint);
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void processTxnResponse(Exchange exchange) {
        try {
            removeCustomHeaders(exchange);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void removeCustomHeaders(Exchange exchange) {
        exchange.getIn().removeHeader(EXCHANGE_HEADER_ROUTING_CTX);
        exchange.getIn().removeHeader(EXCHANGE_HEADER_TARGET_SCHEME);
        exchange.getIn().removeHeader("correlationId");
        exchange.getIn().removeHeader(EXCHANGE_HEADER_REQ_SRC_TMM);
        exchange.getIn().removeHeader(EXCHANGE_HEADER_API_TXN_MODEL);
        exchange.getIn().removeHeader(EXCHANGE_HEADER_REQ_TGT_TMM);
    }

    @Override
    public void processTxnDecline(Exchange exchange) throws UnsupportedEncodingException {

    }

    @Override
    public SourceProcessor getSourceProcessor() {
        return SourceProcessor.BBPSOU_BILLER;
    }
}
