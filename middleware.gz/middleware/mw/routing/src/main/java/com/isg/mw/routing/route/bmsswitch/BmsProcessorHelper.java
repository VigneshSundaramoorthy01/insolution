package com.isg.mw.routing.route.bmsswitch;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.bms.commonModels.BillPayTransactionDetails;
import com.isg.bms.commonModels.BmsTxnDataModel;
import com.isg.bms.commonModels.Tag;
import com.isg.bms.commonModels.XmlAckResponse;
import com.isg.bms.constant.BmsSwitchConstant;
import com.isg.bms.requestModels.BillFetchNpciRequest;
import com.isg.bms.requestModels.BillPayEnquiryNpciRequest;
import com.isg.bms.requestModels.BillPayNpciRequest;
import com.isg.bms.requestModels.BillPayReversalNpciRequest;
import com.isg.bms.responseModels.*;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.InitProps;
import com.isg.mw.cache.mgmt.producer.UpiFeederMessenger;
import com.isg.mw.cache.mgmt.producer.UpiTlmMessenger;
import com.isg.mw.cache.mgmt.producer.UpiTxnMessenger;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.upi.TransactionMessageModelV2;
import com.isg.mw.core.model.upi.UpiTxnRequestData;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.TxnIdGenerator;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.TargetNoResponseException;
import com.isg.mw.routing.route.SwitchRouter;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.route.bmsswitch.hearbeat.ServiceHeartbeatMonitor;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import org.apache.camel.Exchange;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import reactor.core.publisher.Mono;

import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class BmsProcessorHelper {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    UpiTlmMessenger upiTlmMessenger;

    @Autowired
    UpiTxnMessenger upiTxnMessenger;

    @Autowired
    CacheUtil cacheUtil;

    @Autowired
    InitProps initProps;

    @Autowired
    @Qualifier("plainTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private ProcessBbpsCuResponse processNpciResponse;

    @Autowired
    private SwitchRouter switchRouterService;

    @Autowired
    ServiceHeartbeatMonitor serviceHeartbeatMonitor;

    @Autowired
    TransactionProcessorHelper transactionProcessorHelper;

    @Autowired
    UpiFeederMessenger upiFeederMessenger;

    public void processNormalTransaction(Exchange exchange, String npciReq, String endpoint, RoutingContext routingContext){
        TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                .filter(t -> t.getTarget() == Target.Scheme)
                .filter(t -> t.getTargetType() == TargetType.Bms)
                .findFirst().get();
        try {
            callBmsHelper(exchange, npciReq, endpoint, targetConfigModel,routingContext);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Internal Error occurred::::" + ExceptionUtils.getStackTrace(e));
        }
    }

    public void billPayReversalReq(Exchange exchange,String npciReq, String actualEndpoint) throws JAXBException {

        BillPayReversalNpciRequest payReversalNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillPayReversalNpciRequest.class);
        String traceId = Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate()) + Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
        final String txnId = "BBPS" + transactionProcessorHelper.generateTxnId();
        saveTransactionData(BmsSwitchConstant.BILL_PAY_REVERSAL, npciReq, traceId, txnId, null);
        TransactionMessageModelV2 transactionMessageModelV2 = processNpciResponse.constructTmmv2ForReversal(exchange, payReversalNpciReq, null, txnId, traceId, 1,null);
        upiTlmMessenger.send(transactionMessageModelV2);
        BillPayTransactionDetails billPayTransaction = cacheUtil.getBillPayTransaction(payReversalNpciReq.getTxn().getTxnReferenceId());
        String payReversalNpciReqJson = IsgJsonUtils.getJsonString(payReversalNpciReq);
        if (validateNpciRequest(payReversalNpciReqJson, BmsSwitchConstant.BILL_PAY_REVERSAL)) {
            if (billPayTransaction != null) {
                String npciResponseXml = processNpciResponse.prepareReversalResponse(payReversalNpciReq, IsgJsonUtils.getJsonString(billPayTransaction), "REDIS");
                saveTransactionData(BmsSwitchConstant.BILL_PAY_REVERSAL, npciReq, traceId, txnId, npciResponseXml);
                BillPayReversalNpciResponse payReversalNpciResponse = JAXB.unmarshal(new StringReader(npciResponseXml), BillPayReversalNpciResponse.class);
                transactionMessageModelV2 = processNpciResponse.constructTmmv2ForReversal(exchange, payReversalNpciReq, payReversalNpciResponse, txnId, traceId, 0, null);
                upiTlmMessenger.send(transactionMessageModelV2);
                Object resAck = processNpciResponse.callNpci(npciResponseXml, initProps.getNpciReversalPayNpciResponseUrl());
                logger.info("Response Send Successfully To NPCI And Ack Received : {}", resAck);
            } else {
                //fetch payment transaction from DB and prepare reversal response
                String url = MTMProperties.getProperty("init.rest.tlm.getTransactionById.uri") + payReversalNpciReq.getTxn().getTxnReferenceId();
                logger.info("Calling TLM to Get Bill Pay Transaction By Id :::: {} with URL :: {}", txnId, url);
                WebClient webClient = SpringContextBridge.services().getWebClient().build();

                ClientResponse response = webClient
                    .get()
                    .uri(url)
                    .exchange()
                    .block(Duration.ofSeconds(20));
                HttpStatus httpStatus = response.statusCode();
                if (httpStatus == HttpStatus.BAD_GATEWAY) {
                    throw new TargetNoResponseException("Target is not responding");
                }
                String responseBody = response.bodyToMono(String.class).block();
                String npciResponseXml = processNpciResponse.prepareReversalResponse(payReversalNpciReq, responseBody, "DATABASE");
                saveTransactionData(BmsSwitchConstant.BILL_PAY_REVERSAL, npciReq, traceId, txnId, npciResponseXml);
                Object resAck = processNpciResponse.callNpci(npciResponseXml, initProps.getNpciReversalPayNpciResponseUrl());
                logger.info("Response Send Successfully To NPCI And Ack Received : {}", resAck);
            }
        }
    }

    public void callBmsHelper(Exchange exchange, String npciReq, String endPoint, TargetConfigModel targetConfigModel, RoutingContext routingContext) {
        String traceId = Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate()) + Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
        final String txnId = "BBPS" + transactionProcessorHelper.generateTxnId();
        ExecutorService executorService = Executors.newCachedThreadPool();
        Map<String, String> headers = new HashMap<>();

        Runnable runnableTask = () -> {
            ThreadContext.put(FilterConstants.threadContextAcpTraceId, traceId);
            ThreadContext.put(FilterConstants.threadContextSwitchTxnId, txnId);
            Object bmsResp;
            String bmsUrl = targetConfigModel.getConnections().get(0).getUrlOrIp() + targetConfigModel.getAdditionalData().getApiInfo().getBms().getInitiateBmsRequestUrl();
            Map<String, Object> requestBody = new HashMap<>();
            String resBody;
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(BmsSwitchConstant.npciRespDateFormat);
                switch (endPoint) {
                    case BmsSwitchConstant.BILL_FETCH_REQUEST:
                        BillFetchNpciRequest billFetchNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillFetchNpciRequest.class);
                        billFetchNpciReq.getHead().setTs(sdf.format(new Date()));
                        billFetchNpciReq.getTxn().setTs(sdf.format(new Date()));
                        boolean isRefIdPresent = validateRefId(npciReq,endPoint);
                        boolean isMsgIdPresent = validateMsgId(npciReq,endPoint);
                        if(isRefIdPresent && isMsgIdPresent) {
                            saveTransactionData(BmsSwitchConstant.BILL_FETCH_REQUEST, npciReq, traceId, txnId, null);
                            String billFetchNpciReqJsonString = IsgJsonUtils.getJsonString(billFetchNpciReq);
                            if (validateNpciRequest(billFetchNpciReqJsonString, BmsSwitchConstant.BILL_FETCH_REQUEST)) {
                                headers.put("Content-Type", "application/json");
                                requestBody.put(BmsSwitchConstant.BMS_REQUEST_BODY, billFetchNpciReqJsonString);
                                requestBody.put(BmsSwitchConstant.END_POINT, BmsSwitchConstant.BILL_FETCH_REQUEST);
                                bmsResp = callBmsApi(requestBody, bmsUrl, headers);
                                logger.info("Response From BMS : {}", bmsResp);
                                resBody = transactionProcessorHelper.parseResponse(bmsResp.toString());
                                BillFetchResponse billFetchResponse = IsgJsonUtils.getObjectFromJsonString(resBody, BillFetchResponse.class);
                                if (bmsResp != null && billFetchResponse.getBillFetchResponse().getReason().getResponseCode().equalsIgnoreCase("000")
                                        && billFetchNpciReq.getTxn().getMsgId().equals(billFetchResponse.getBillFetchResponse().getHead().getMsgId())) {
                                    BmsTxnDataModel bmsTxnDataModel = new BmsTxnDataModel();
                                    bmsTxnDataModel.setRefId(billFetchResponse.getBillFetchResponse().getHead().getRefId());
                                    bmsTxnDataModel.setMsgId(billFetchResponse.getBillFetchResponse().getHead().getMsgId());
                                    bmsTxnDataModel.setBillFetchStatus(BmsSwitchConstant.SUCCESS);
                                    bmsTxnDataModel.setBillerNumber(billFetchResponse.getBillFetchResponse().getBillerResponse().getBillNumber());
                                    cacheUtil.putBmsTxnData(cacheUtil.getBmsTxnDataKey(billFetchNpciReq.getHead().getRefId(), billFetchNpciReq.getBillDetails().getBiller().getId()), bmsTxnDataModel);
                                    List<String> listOfRefId = cacheUtil.getByBillNoData(cacheUtil.getByBillNoKey(billFetchResponse.getBillFetchResponse().getBillerResponse().getBillNumber(), billFetchNpciReq.getBillDetails().getBiller().getId()));
                                    if(listOfRefId == null){
                                        listOfRefId = new ArrayList<>();
                                    }
                                    listOfRefId.add(billFetchResponse.getBillFetchResponse().getHead().getRefId());
                                    cacheUtil.putByBillNoData(cacheUtil.getByBillNoKey(billFetchResponse.getBillFetchResponse().getBillerResponse().getBillNumber(),billFetchNpciReq.getBillDetails().getBiller().getId()),listOfRefId);
                                }
                                String npciResponseXml = processNpciResponse.prepareBillFetchResponse(bmsResp, billFetchNpciReq);
                                logger.info("Response Sending To NPCI : {}", npciResponseXml);
                                saveTransactionData(BmsSwitchConstant.BILL_FETCH_REQUEST, null, traceId, txnId, npciResponseXml);
                                Object resAck = processNpciResponse.callNpci(npciResponseXml, initProps.getBillFetchNpciResponseUrl());
                                logger.info("Response Send Successfully To NPCI And Ack Received : {}", resAck);
                            }
                        }
                        break;
                    case BmsSwitchConstant.BILL_PAY_REQUEST:
                        BillPayNpciRequest billPayNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillPayNpciRequest.class);
                        billPayNpciReq.getHead().setTs(sdf.format(new Date()));
                        billPayNpciReq.getTxn().setTs(sdf.format(new Date()));
                        boolean isValidRefId = validateRefId(npciReq, endPoint);
                        boolean isValidMsgId = validateMsgId(npciReq, endPoint);
                        boolean isBillNoValid=false;
                        List<String> byBillNoData = cacheUtil.getByBillNoData(cacheUtil.getByBillNoKey(billPayNpciReq.getBillerResponse().getBillNumber(), billPayNpciReq.getBillDetails().getBiller().getId()));
                        if(byBillNoData == null && !byBillNoData.isEmpty()){
                            String response = processNpciResponse.prepareBillPayErrorCodeResponse(billPayNpciReq, "096##Invalid Biller No Against BillerId");
                            logger.info("Response Is {} :" , response);
                        }else {
                            isBillNoValid = true;
                        }
                        if(isValidRefId && isValidMsgId && isBillNoValid) {
                            saveTransactionData(BmsSwitchConstant.BILL_PAY_REQUEST, npciReq, traceId, txnId, null);
                            TransactionMessageModelV2 transactionMessageModelV2 = processNpciResponse.constructTmmv2(exchange, billPayNpciReq, null, txnId, traceId, 1, targetConfigModel, routingContext);
                            upiTlmMessenger.send(transactionMessageModelV2);
                            upiFeederMessenger.send(processNpciResponse.constructTmmVersionV2(exchange, billPayNpciReq, null, txnId, traceId, 1, routingContext));
                            String billPaymentNpciReqJsonString = IsgJsonUtils.getJsonString(billPayNpciReq);
                            if (validateNpciRequest(billPaymentNpciReqJsonString, BmsSwitchConstant.BILL_PAY_REQUEST)) {
                                saveDataRedis(billPayNpciReq, traceId, txnId);
                                headers.put("Content-Type", "application/json");
                                requestBody.put(BmsSwitchConstant.BMS_REQUEST_BODY, billPaymentNpciReqJsonString);
                                requestBody.put(BmsSwitchConstant.END_POINT, BmsSwitchConstant.BILL_PAY_REQUEST);
                                logger.info("billPaymentNpciReqJsonString :::: {}", billPaymentNpciReqJsonString);
                                bmsResp = callBmsApi(requestBody, bmsUrl, headers);
                                logger.info("Response From BMS : {}", bmsResp);
                                resBody = transactionProcessorHelper.parseResponse(bmsResp.toString());
                                BillPayResponse billPaymentResponse = IsgJsonUtils.getObjectFromJsonString(resBody, BillPayResponse.class);
                                String npciResponseXml = processNpciResponse.prepareBillPaymentResponse(billPaymentResponse, billPayNpciReq);
                                saveTransactionData(BmsSwitchConstant.BILL_PAY_REQUEST, null, traceId, txnId, npciResponseXml);
                                if (billPaymentResponse != null && billPaymentResponse.getBillPayResponse().getReason().getResponseCode().equalsIgnoreCase("000")) {
                                    updateBillPayDataToRedis(billPayNpciReq.getTxn().getTxnReferenceId());
                                    BillPayNpciResponse billPaymentNpciResponse = JAXB.unmarshal(new StringReader(npciResponseXml), BillPayNpciResponse.class);
                                    transactionMessageModelV2 = processNpciResponse.constructTmmv2(exchange, billPayNpciReq, billPaymentNpciResponse, txnId, traceId, 0, targetConfigModel, routingContext);
                                    upiTlmMessenger.send(transactionMessageModelV2);
                                    upiFeederMessenger.send(processNpciResponse.constructTmmVersionV2(exchange, billPayNpciReq, billPaymentNpciResponse, txnId, traceId, 0, routingContext));
                                    BmsTxnDataModel bmsTxnData = cacheUtil.getBmsTxnData(cacheUtil.getBmsTxnDataKey(billPayNpciReq.getHead().getRefId(), billPayNpciReq.getBillDetails().getBiller().getId()));
                                    bmsTxnData.setBillPayStatus(BmsSwitchConstant.SUCCESS);
                                    cacheUtil.putBmsTxnData(cacheUtil.getBmsTxnDataKey(billPayNpciReq.getHead().getRefId(), billPayNpciReq.getBillDetails().getBiller().getId()),bmsTxnData);
                                }
                                logger.info("Response Sending To NPCI : {}", npciResponseXml);
                                Object resAck = processNpciResponse.callNpci(npciResponseXml, initProps.getBillPayNpciResponseUrl());
                                logger.info("Response Send Successfully To NPCI And Ack Received : {}", resAck);
                            }
                        }
                        break;
                    case BmsSwitchConstant.BILL_STATUS_REQUEST:
                        logger.info("exchange body :: {}", npciReq);
                        BillPayEnquiryNpciRequest billstatusNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillPayEnquiryNpciRequest.class);
                        billstatusNpciReq.getHead().setTs(sdf.format(new Date()));
                        billstatusNpciReq.getTxn().setTs(sdf.format(new Date()));
                        String billStatusNpciReqJsonString = IsgJsonUtils.getJsonString(billstatusNpciReq);
                        if (validateNpciRequest(billStatusNpciReqJsonString, BmsSwitchConstant.BILL_STATUS_REQUEST)) {
                            headers.put("Content-Type", "application/json");
                            requestBody.put(BmsSwitchConstant.BMS_REQUEST_BODY, billStatusNpciReqJsonString);
                            requestBody.put(BmsSwitchConstant.END_POINT, BmsSwitchConstant.BILL_STATUS_REQUEST);
                            bmsResp = callBmsApi(requestBody, bmsUrl, headers);
                            logger.info("{} Response From BMS : {}", endPoint, bmsResp);
                            resBody = transactionProcessorHelper.parseResponse(bmsResp.toString());
                            BillPayEnquiryResponse billPayEnquiryResponse = IsgJsonUtils.getObjectFromJsonString(resBody, BillPayEnquiryResponse.class);
                            String npciResponseXml = processNpciResponse.prepareBillStatusResponse(billPayEnquiryResponse, billstatusNpciReq);
                            logger.info("Response Sending To NPCI : {}", npciResponseXml);
                            Object resAck = processNpciResponse.callNpci(npciResponseXml,initProps.getBillPayStatusNpciResponseUrl());
                            logger.info("Response Send Successfully To NPCI And Ack Received : {}", resAck);
                        }
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
        executorService.execute(runnableTask);
    }

    private boolean validateMsgId(String npciReq, String endPoint) throws JAXBException {
        BmsTxnDataModel bmsTxnData;
        switch (endPoint) {
            case BmsSwitchConstant.BILL_FETCH_REQUEST:
                BillFetchNpciRequest billFetchNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillFetchNpciRequest.class);
                List<BmsTxnDataModel> allBmsTxnModelData = cacheUtil.getAllBmsTxnModelData(billFetchNpciReq.getBillDetails().getBiller().getId());
                if (allBmsTxnModelData != null && !allBmsTxnModelData.isEmpty()) {
                    BmsTxnDataModel model = allBmsTxnModelData.stream().filter(tmodel -> tmodel.getMsgId().equals(billFetchNpciReq.getTxn().getMsgId()))
                            .filter(tmodel -> tmodel.getBillFetchStatus().equals(BmsSwitchConstant.SUCCESS)).findAny().orElse(null);
                    if (model != null) {
                        String response = processNpciResponse.prepareBillFetchErrorCodeResponse(billFetchNpciReq, "096##MsgId Should Be Unique");
                        logger.info("Response Is {} :", response);
                        return false;
                    }
                    return true;
                }
            case BmsSwitchConstant.BILL_PAY_REQUEST:
                BillPayNpciRequest billPayNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillPayNpciRequest.class);
                allBmsTxnModelData = cacheUtil.getAllBmsTxnModelData(billPayNpciReq.getBillDetails().getBiller().getId());
                if (allBmsTxnModelData != null && !allBmsTxnModelData.isEmpty()) {
                    BmsTxnDataModel model = allBmsTxnModelData.stream().filter(tmodel -> tmodel.getMsgId().equals(billPayNpciReq.getTxn().getMsgId()))
                            .filter(tmodel -> tmodel.getBillFetchStatus().equals(BmsSwitchConstant.SUCCESS)).findAny().orElse(null);
                    if (model != null) {
                        String response = processNpciResponse.prepareBillPayErrorCodeResponse(billPayNpciReq, "096##MsgId Should Be Unique");
                        logger.info("Response Is {} :", response);
                        return false;
                    }
                    return true;
                }
        }
        return true;
    }

    private boolean validateRefId(String npciReq,String endPoint) throws JAXBException {
        BmsTxnDataModel bmsTxnData;
        switch (endPoint) {
            case BmsSwitchConstant.BILL_FETCH_REQUEST:
                BillFetchNpciRequest billFetchNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillFetchNpciRequest.class);
                bmsTxnData = cacheUtil.getBmsTxnData(cacheUtil.getBmsTxnDataKey(billFetchNpciReq.getHead().getRefId(), billFetchNpciReq.getBillDetails().getBiller().getId()));
                if(bmsTxnData != null){
                    String response = processNpciResponse.prepareBillFetchErrorCodeResponse(billFetchNpciReq, "096##RefId Should Be Unique");
                    logger.info("Response Is {} :" , response);
                    return false;
                }
                return true;
            case BmsSwitchConstant.BILL_PAY_REQUEST:
                BillPayNpciRequest billPayNpciReq = JAXB.unmarshal(new StringReader(npciReq), BillPayNpciRequest.class);
                bmsTxnData = cacheUtil.getBmsTxnData(cacheUtil.getBmsTxnDataKey(billPayNpciReq.getHead().getRefId(), billPayNpciReq.getBillDetails().getBiller().getId()));
                if(bmsTxnData == null){
                    String response = processNpciResponse.prepareBillPayErrorCodeResponse(billPayNpciReq, "096##RefId not Present / Bill Fetch Not Initiated");
                    logger.info("Response Is {} :" , response);
                    return false;
                }
                return true;
        }
       return true;
    }


    public void updateBillPayDataToRedis(String txnId) {
        BillPayTransactionDetails billPayTransactionDetails = cacheUtil.getBillPayTransaction(txnId);
        billPayTransactionDetails.setStatus(BmsSwitchConstant.SUCCESS);
        billPayTransactionDetails.setStatusCode("000");
        cacheUtil.updateBillPayTransaction(txnId, billPayTransactionDetails);
    }

    public boolean validateNpciRequest(String reqJsonString, String endPoint) {
        boolean isValidate = false;
        switch (endPoint) {
            case BmsSwitchConstant.BILL_FETCH_REQUEST:
                try {
                    ObjectMapper mapper = new ObjectMapper();
                    mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                    BillFetchNpciRequest billFetchNpciRequest = mapper.readValue(reqJsonString, BillFetchNpciRequest.class);
                    InputStream input = new BufferedInputStream(new FileInputStream(MTMProperties.getProperty(getMtmPropName(endPoint))));
                    JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4).getSchema(input);
                    JsonNode jsonNode = mapper.convertValue(billFetchNpciRequest, JsonNode.class);
                    Set<ValidationMessage> errors = schema.validate(jsonNode);

                    Optional<String> bbpsNpciReqValidationError = errors.stream().map(t -> t.getMessage()).findFirst();
                    if (bbpsNpciReqValidationError.isPresent()) {
                        logger.debug("bbpsNpciReqValidationError :: {} endPoint :: {}", bbpsNpciReqValidationError.get(), endPoint);
                        isValidate = false;
                    } else {
                        isValidate = true;
                    }
                    if(!isValidate){
                        String npciResponseXml = processNpciResponse.prepareBillFetchErrorCodeResponse(billFetchNpciRequest,bbpsNpciReqValidationError.get());
                        logger.info("Error Response Sending To NPCI : {}", npciResponseXml);
                        Object resAck = processNpciResponse.callNpci(npciResponseXml,initProps.getBillFetchNpciErrorResponseUrl());
                        logger.info("Error Response Send Successfully To NPCI And Ack Received : {}", resAck);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    isValidate = false;
                }
                break;
            case BmsSwitchConstant.BILL_PAY_REQUEST:
                try {
                    ObjectMapper mapper = new ObjectMapper();
                    BillPayNpciRequest billPaymentNpciRequest = mapper.readValue(reqJsonString, BillPayNpciRequest.class);
                    InputStream input = new BufferedInputStream(new FileInputStream(MTMProperties.getProperty(getMtmPropName(endPoint))));
                    JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4).getSchema(input);
                    JsonNode jsonNode = mapper.convertValue(billPaymentNpciRequest, JsonNode.class);
                    Set<ValidationMessage> errors = schema.validate(jsonNode);

                    Optional<String> bbpsNpciReqValidationError = errors.stream().map(t -> t.getMessage()).findFirst();
                    if (bbpsNpciReqValidationError.isPresent()) {
                        logger.debug("bbpsNpciReqValidationError :: {} endPoint :: {}", bbpsNpciReqValidationError.get(), endPoint);
                        isValidate = false;
                    } else {
                        if (billPaymentNpciRequest.getPaymentMethod().getSplitPay().equals("Yes")) {
                            boolean splitPayAmtFlag = !billPaymentNpciRequest.getAmount().getSplitPayAmount().isEmpty();
                            isValidate = splitPayAmtFlag ? (billPaymentNpciRequest.getAmount().getSplitPayAmount().length() <= 20) : false;
                            if (!isValidate) logger.info("SplitPayAmount is null");
                        } else {
                            isValidate = true;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    isValidate = false;
                }
                break;
            case BmsSwitchConstant.BILL_STATUS_REQUEST:
                try {
                    ObjectMapper mapper = new ObjectMapper();
                    BillPayEnquiryNpciRequest billStatusNpciRequest = mapper.readValue(reqJsonString, BillPayEnquiryNpciRequest.class);
                    InputStream input = new BufferedInputStream(new FileInputStream(MTMProperties.getProperty(getMtmPropName(endPoint))));
                    JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4).getSchema(input);
                    JsonNode jsonNode = mapper.convertValue(billStatusNpciRequest, JsonNode.class);
                    Set<ValidationMessage> errors = schema.validate(jsonNode);

                    Optional<String> bbpsNpciReqValidationError = errors.stream().map(t -> t.getMessage()).findFirst();
                    if (bbpsNpciReqValidationError.isPresent()) {
                        logger.debug("bbpsNpciReqValidationError :: {} endPoint :: {}", bbpsNpciReqValidationError.get(), endPoint);
                        isValidate = false;
                    } else {
                        isValidate = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    isValidate = false;
                }
                break;
            case BmsSwitchConstant.BILL_PAY_REVERSAL:
                try {
                    ObjectMapper mapper = new ObjectMapper();
                    BillPayReversalNpciRequest billPayReversalNpciReq = mapper.readValue(reqJsonString, BillPayReversalNpciRequest.class);
                    InputStream input = new BufferedInputStream(new FileInputStream(MTMProperties.getProperty(getMtmPropName(endPoint))));
                    JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4).getSchema(input);
                    JsonNode jsonNode = mapper.convertValue(billPayReversalNpciReq, JsonNode.class);
                    Set<ValidationMessage> errors = schema.validate(jsonNode);

                    Optional<String> bbpsNpciReqValidationError = errors.stream().map(t -> t.getMessage()).findFirst();
                    if (bbpsNpciReqValidationError.isPresent()) {
                        logger.debug("bbpsNpciReqValidationError :: {} endPoint :: {}", bbpsNpciReqValidationError.get(), endPoint);
                        isValidate = false;
                    } else {
                        isValidate = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    isValidate = false;
                }
                break;
        }
        logger.info("Validate {} is {}", endPoint, isValidate);
        return isValidate;
    }

    public Object callBmsApi(Map<String, Object> body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Header:{}, Request Body: {}", url, headers, body);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), Map.class)
                .exchange()
                .block(Duration.ofSeconds(90));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new TargetNoResponseException("Target is not responding");
        }
        String res = httpStatus.value() + TmmConstants.API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public String prepareNpciAck(String npciReq, String actualEndpoint) throws JAXBException {
        XmlAckResponse xmlAckResponse = new XmlAckResponse();
        xmlAckResponse.setRspCd("Successful");
        xmlAckResponse.setTs(OffsetDateTime.now().toString());

        switch (actualEndpoint) {
            case BmsSwitchConstant.BILL_FETCH_REQUEST:
                BillFetchNpciRequest billFetchNpciReqJson = JAXB.unmarshal(new StringReader(npciReq), BillFetchNpciRequest.class);
                xmlAckResponse.setApi(BmsSwitchConstant.BILL_FETCH_REQUEST);
                xmlAckResponse.setRefId(billFetchNpciReqJson.getHead().getRefId());
                xmlAckResponse.setMsgId(billFetchNpciReqJson.getTxn().getMsgId());
                break;
            case BmsSwitchConstant.BILL_PAY_REQUEST:
                BillPayNpciRequest billPayNpciReqJson = JAXB.unmarshal(new StringReader(npciReq), BillPayNpciRequest.class);
                xmlAckResponse.setApi(BmsSwitchConstant.BILL_PAY_REQUEST);
                xmlAckResponse.setRefId(billPayNpciReqJson.getHead().getRefId());
                xmlAckResponse.setMsgId(billPayNpciReqJson.getTxn().getMsgId());
                break;
            case BmsSwitchConstant.BILL_STATUS_REQUEST:
                BillPayEnquiryNpciRequest billstatusNpciReqJson = JAXB.unmarshal(new StringReader(npciReq), BillPayEnquiryNpciRequest.class);
                xmlAckResponse.setApi(BmsSwitchConstant.BILL_STATUS_REQUEST);
                xmlAckResponse.setRefId(billstatusNpciReqJson.getHead().getRefId());
                xmlAckResponse.setMsgId(billstatusNpciReqJson.getTxnStatusReq().getMsgId());
                break;

        }
        StringWriter ackxml = new StringWriter();
        JAXBContext contextObj = JAXBContext.newInstance(XmlAckResponse.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.marshal(xmlAckResponse, ackxml);
        return ackxml.toString();
    }

    public String getMtmPropName(String endPoint) {
        if (BmsSwitchConstant.BILL_FETCH_REQUEST.equals(endPoint)) {
            return "bms.fetch.bill.validation";
        } else if (BmsSwitchConstant.BILL_PAY_REQUEST.equals(endPoint)) {
            return "bms.pay.bill.validation";
        } else if (BmsSwitchConstant.BILL_STATUS_REQUEST.equals(endPoint)) {
            return "bms.bill.status.validation";
        } else if (BmsSwitchConstant.BILL_PAY_REVERSAL.equals(endPoint)) {
            return "bms.reversal.bill.pay.validation";
        } else {
            return null;
        }
    }

    private boolean saveDataRedis(BillPayNpciRequest billPayNpciReq, String traceId, String txnId) {
        try {
            logger.debug("Entry In save redis data method::::::::");
            BillPayTransactionDetails bmsTxnDetails = new BillPayTransactionDetails();

            String txnReferenceId = billPayNpciReq.getTxn().getTxnReferenceId();
            bmsTxnDetails.setTxnReferenceId(txnReferenceId);
            bmsTxnDetails.setTraceId(traceId);
            bmsTxnDetails.setAmount(billPayNpciReq.getAmount().getAmt().getAmount());
            bmsTxnDetails.setAgentId(billPayNpciReq.getAgent().getId());
            bmsTxnDetails.setStatus(BmsSwitchConstant.PENDING);
            bmsTxnDetails.setStatusCode("103");
            bmsTxnDetails.setCustomerName(billPayNpciReq.getBillerResponse().getCustomerName());
            bmsTxnDetails.setTxnType(billPayNpciReq.getTxn().getType());
            bmsTxnDetails.setCurrency(billPayNpciReq.getAmount().getAmt().getCurrency());
            bmsTxnDetails.setCustConvFee(billPayNpciReq.getAmount().getAmt().getCustConvFee());
            bmsTxnDetails.setMobile(billPayNpciReq.getCustomer().getMobile());
            bmsTxnDetails.setTxdId(txnId);
            bmsTxnDetails.setMsgId(billPayNpciReq.getTxn().getMsgId());
            bmsTxnDetails.setRefId(billPayNpciReq.getHead().getRefId());
            bmsTxnDetails.setPaymentRefId(billPayNpciReq.getTxn().getPaymentRefId());
            bmsTxnDetails.setPaymentMode(billPayNpciReq.getPaymentMethod().getPaymentMode());
            bmsTxnDetails.setBillDate(billPayNpciReq.getBillerResponse().getBillDate());
            bmsTxnDetails.setBillPeriod(billPayNpciReq.getBillerResponse().getBillPeriod());
            bmsTxnDetails.setBillNumber(billPayNpciReq.getBillerResponse().getBillNumber());
            bmsTxnDetails.setBillerId(billPayNpciReq.getBillDetails().getBiller().getId());
            bmsTxnDetails.setDueDate(billPayNpciReq.getBillerResponse().getDueDate());

            List<Tag> tags = billPayNpciReq.getAgent().getDevice().getTag();
            String ifscValue = tags.stream()
                    .filter(tag -> "IFSC".equals(tag.getName()))
                    .map(Tag::getValue)
                    .findFirst()
                    .orElse(null);
            bmsTxnDetails.setIfsc(ifscValue);

            bmsTxnDetails.setQuickPay(billPayNpciReq.getPaymentMethod().getQuickPay());
            bmsTxnDetails.setSplitPay(billPayNpciReq.getPaymentMethod().getSplitPay());
            bmsTxnDetails.setSplitPayAmount(billPayNpciReq.getAmount().getSplitPayAmount());
            bmsTxnDetails.setReqArrivalTime(billPayNpciReq.getTxn().getTs());

            cacheUtil.saveBillPayTransaction(txnReferenceId, bmsTxnDetails);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    public void doHeartBeatToNPCI() throws Exception {
        logger.debug("BBPS: HeartBeat proccess initiated at {} ", new Date().toString());
        String reqDiagString = processNpciResponse.prepareHeartBeatRequest();
        // condition need to check for CM TLM KAFKA & BMS
        logger.debug("BBPS : HeartBeat request   {} ", reqDiagString);
        String heartBeatUrl = initProps.getNpciHeartBeatUrl();
        logger.debug("HeartBeat NPCI Api  {} ", heartBeatUrl);

        logger.debug("BBPS : checking heartbeat of all services");
        JSONObject serviceHealth = serviceHeartbeatMonitor.isServicesUp();
        if(serviceHealth.getBoolean("STATUS")){
            logger.debug("BBPS : All Service are UP & Working");
            String respAck = (String)processNpciResponse.callNpci(reqDiagString,heartBeatUrl);
            if (respAck.contains("##")) {
                respAck = respAck.substring(respAck.indexOf("##") + 2).trim();
            }
            DiagnosticNpciResponse heartBeatApiResponse = JAXB.unmarshal(new StringReader(respAck), DiagnosticNpciResponse.class);
            logger.debug("HeartBeat NPCI Api Response Received {} ", respAck);
        }else{
            JSONArray downServices = serviceHealth.getJSONArray("DOWN_SERVICE");
            String message = "Unable to send Heartbeat to NPCI due to ";
            for(int i=0;i<downServices.length();i++){
                message += downServices.get(i);
                if(downServices.length()-1 > i){
                    message += " & ";
                }
            }
            message += " service  is down";
            logger.debug("BBPS : "+message);
        }
    }

    public void saveTransactionData(String endpoint, String requestXmlString, String traceId, String txnId, String responseString) {
        try {
            logger.debug("Save Transaction Data For TraceId And TxnId: {}  , {}",traceId,txnId);
            UpiTxnRequestData upiTxnRequestData = new UpiTxnRequestData();
            upiTxnRequestData.setRequestType(endpoint);
            upiTxnRequestData.setTraceId(traceId);
            upiTxnRequestData.setRequestDataDetails(requestXmlString);
            upiTxnRequestData.setTxnId(txnId);
            upiTxnRequestData.setResponseDataDetails(responseString);
            upiTxnMessenger.send(upiTxnRequestData);
        } catch (Exception e) {
            logger.error("Error while sending transaction data::::");
            e.printStackTrace();
        }
    }


    public Boolean xmlTagsValidate(String xml, String endpoint) {
        Boolean isValidate = false;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(xml));
            Document doc = builder.parse(is);

            switch(endpoint) {
                case BmsSwitchConstant.BILL_FETCH_REQUEST :
                    if (occurrence(doc.getElementsByTagName("Txn").getLength(), "Txn") &&
                            occurrence(doc.getElementsByTagName("Head").getLength(), "Head") &&
                            occurrence(doc.getElementsByTagName("Customer").getLength(), "Customer") &&
                            occurrence(doc.getElementsByTagName("Agent").getLength(), "Agent") &&
                            occurrence(doc.getElementsByTagName("BillDetails").getLength(), "BillDetails") &&
                            occurrence(doc.getElementsByTagName("Analytics").getLength(), "Analytics")
                    ) {
                        logger.info("XML IS VALID !");
                        isValidate = true;
                    } else {
                        isValidate = false;
                    }
                    break;
                case BmsSwitchConstant.BILL_PAY_REQUEST :
                    if (occurrence(doc.getElementsByTagName("Head").getLength(), "Head") &&
                            occurrence(doc.getElementsByTagName("Analytics").getLength(), "Analytics") &&
                            occurrence(doc.getElementsByTagName("Txn").getLength(), "Txn") &&
                            occurrence(doc.getElementsByTagName("Customer").getLength(), "Customer") &&
                            occurrence(doc.getElementsByTagName("Agent").getLength(), "Agent") &&
                            occurrence(doc.getElementsByTagName("BillDetails").getLength(), "BillDetails") &&
                            occurrence(doc.getElementsByTagName("BillerResponse").getLength(), "BillerResponse") &&
                            occurrence(doc.getElementsByTagName("AdditionalInfo").getLength(), "AdditionalInfo") &&
                            occurrence(doc.getElementsByTagName("PaymentMethod").getLength(), "PaymentMethod") &&
                            occurrence(doc.getElementsByTagName("Amount").getLength(), "Amount")
                    ) {
                        logger.info("XML IS VALID !");
                        isValidate = true;
                    } else {
                        isValidate = false;
                    }
                    break;
                case BmsSwitchConstant.BILL_STATUS_REQUEST :
                    if (occurrence(doc.getElementsByTagName("Head").getLength(), "Head") &&
                            occurrence(doc.getElementsByTagName("Txn").getLength(), "Txn") &&
                            occurrence(doc.getElementsByTagName("TxnStatusReq").getLength(), "TxnStatusReq")
                    ) {
                        logger.info("XML IS VALID !");
                        isValidate = true;
                    } else {
                        isValidate = false;
                    }
                    break;
                case BmsSwitchConstant.BILL_PAY_REVERSAL :
                    if (occurrence(doc.getElementsByTagName("Head").getLength(), "Head") &&
                            occurrence(doc.getElementsByTagName("Txn").getLength(), "Txn")
                    ) {
                        logger.info("XML IS VALID !");
                        isValidate = true;
                    } else {
                        isValidate = false;
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            isValidate = false;
        }
        return isValidate;
    }

    public Boolean occurrence(int n, String tagName) {
        Boolean isValid = false;
        switch(n) {
            case 0 :
                if(tagName.equalsIgnoreCase("Analytics") ||
                        tagName.equalsIgnoreCase("BillerResponse") ||
                        tagName.equalsIgnoreCase("AdditionalInfo")) {
                    isValid = true;
                } else {
                    logger.info("{} tag not present", tagName);
                }
                break;
            case 1 :
                //logger.info("tag is present");
                isValid = true;
                break;
            default:
                if (n > 1) {
                    logger.info("duplicate {} tags found.", tagName);
                }
                break;
        }
        return isValid;
    }


}
