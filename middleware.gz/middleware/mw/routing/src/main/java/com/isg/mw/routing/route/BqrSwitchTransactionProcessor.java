package com.isg.mw.routing.route;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.config.RoutingConstants;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.context.RoutingInitializationContext.EndpointMetaData;
import com.isg.mw.routing.exception.InvalidMessageException;
import com.isg.mw.routing.exception.RefundAmountExceededException;
import com.isg.mw.routing.exception.RequestProcessingException;
import com.isg.mw.routing.exception.ResponseProcessingException;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import com.isg.mw.routing.util.RouteUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.component.netty.NettyConstants;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.component.netty.http.NettyHttpEndpoint;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.xml.bind.DatatypeConverter;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.routing.config.RoutingConstants.*;

@Component
@PropertySource("${spring.config.location}routing-config.properties")
public class BqrSwitchTransactionProcessor implements ITransactionProcessor {
	private final Logger logger = LogManager.getLogger(getClass());

	private final Logger rawlogger = LogManager.getLogger("rawLog");
	@Value("${target.timeout.auto.reversal:true}")
	private boolean timeOutAutoReversal;

	@Autowired
	private TransactionProcessorHelper transactionProcessorHelper;

	@Autowired
	private ApiTransactionProcessor apiTransactionProcessor;

	@Autowired
	private TransactionProcessorHelper processorHelper;

    /*@Autowired
    private SwitchRouter switchRouterService;*/

	private static List<RoutingContext> routingContextList = RoutingInitializationContext.getRoutingContextList();

	public void processTxnRequest(TransactionMessageModel reqSrcTmm, String targetRemoteAdd, Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries, CamelContext camelContext) {
		TransactionMessageModel response = null;
		try {
			String entityId = reqSrcTmm.getEntityId();
			reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(reqSrcTmm.getTransactionId()));
			reqSrcTmm.setHashedTransactionId(transactionProcessorHelper.getHashedValue(reqSrcTmm.getTransactionId()));

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), null, reqSrcTmm.getTransactionId(), "Transaction received"));

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), reqSrcTmm.getTransactionId(),
					"Transaction type: " + reqSrcTmm.getTransactionName()
							+ ", TStan: " + reqSrcTmm.getTerminalStan()
							+ ", MID: " + reqSrcTmm.getCardAcceptorId()
							+ ", TID: " + reqSrcTmm.getCardAcceptorTerminalId()));

			logger.debug("Request Source Transaction Message Model: {}", reqSrcTmm);

			transactionProcessorHelper.logToTlmBqrMsg(reqSrcTmm);

			transactionProcessorHelper.validTxnType(reqSrcTmm);

			//transactionProcessorHelper.checkForMandatoryFields(reqSrcTmm);

			if (TmmConstants.isOriginalTxnRequired(reqSrcTmm.getTransactionName())) {
				reqSrcTmm.setOriginalTmm(fetchOriginalTransaction(reqSrcTmm));
				reqSrcTmm.setSchemeStan(reqSrcTmm.getOriginalTmm().getSchemeStan());
				reqSrcTmm.setHostBatchNo(reqSrcTmm.getOriginalTmm().getHostBatchNo());
				reqSrcTmm.setBatchStatus(reqSrcTmm.getOriginalTmm().getBatchStatus());
				reqSrcTmm.setAuthIdRes(reqSrcTmm.getOriginalTmm().getAuthIdRes());
				reqSrcTmm.setCardAcceptorId(reqSrcTmm.getOriginalTmm().getCardAcceptorId());
				reqSrcTmm.setCardAcceptorTerminalId(reqSrcTmm.getOriginalTmm().getCardAcceptorTerminalId());
			}

			transactionProcessorHelper.validateMerchantPan(reqSrcTmm);

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), reqSrcTmm.getTransactionId(),
					reqSrcTmm.getTransactionName(), "Bin validated"));

			TransactionMessageModel resSrcTmm = reqSrcTmm;
			resSrcTmm.setResCode(TmmConstants.RES_CODE_SUCCESS);

			response = processTxnResponse(resSrcTmm, targetRemoteAdd, targetEpEntries, camelContext);

		} catch (Exception e) {
			String exception = e.getClass().getSimpleName();
			response = processTxnDecline(reqSrcTmm, targetRemoteAdd, targetEpEntries, camelContext,exception);
			throw new RequestProcessingException("Error while processing the request message ", e);
		}
		finally {
			processMobileRequest(targetEpEntries, camelContext, response);
		}
	}

	public TransactionMessageModel processTxnDecline(TransactionMessageModel reqSrcTmm, String targetRemoteAdd, Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries, CamelContext camelContext,String exception){
		TransactionMessageModel declineModel = new TransactionMessageModel();
		String resCode = null;
		switch (exception){
			case "InvalidMerchantException":
				resCode = TmmConstants.RES_CODE_INVALID_MERCHANT;
				break;

			case "InvalidBinException":
			case "InvalidTxnException":
			case "RefundLimitExceededException":
				resCode = TmmConstants.RES_CODE_INVALID_TXN;

			case "FormatErrorException":
				resCode = TmmConstants.RES_CODE_MANDATORY_FIELD_NOT_PRESENT;
				break;

			/*case "NullPointerException":
			case "InternalServerError":
			case "SystemErrorException":
			case "DuplicateTxnException":
				resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
				break;*/

			case "InvalidCardNumberException":
				resCode = TmmConstants.RES_CODE_INVALID_CARD_NUMBER;
				break;

			case "ExecutionException":
			case "InterruptedException":
			case "IssuerUnavailableException":
				resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
				break;

			case "InvalidVoidOrReversalDataException":
			case "NotFound":
				if ("R".equals(reqSrcTmm.getDrcrFlag())){
					resCode = TmmConstants.RES_CODE_SUCCESS;
				}
				else {
					resCode = TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_PRESENT;
				}
				break;
			case "InvalidTxnAmtException":
				resCode = TmmConstants.RES_CODE_INVALID_TXN_AMT;
				break;
			case "MacValidationException":
				resCode = TmmConstants.RES_CODE_INVALID_MAC;
				break;

			default:
				resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
				break;
		}

		if (reqSrcTmm == null){
			declineModel.setTransactionName("decline.bqr.purchase.request");
			//declineModel.setEntityId(.getEntityId());
		}else{
			declineModel = reqSrcTmm;
			declineModel.setTransactionName("decline."+ reqSrcTmm.getTransactionName());
		}

		declineModel.setResCode(resCode);
		logger.trace("Decline Response Code: {}, Decline Txn: {}", declineModel.getResCode(),
				declineModel.getTransactionName());

		declineModel.setSourceProcessor(reqSrcTmm.getSourceProcessor());
		//MessageContext targetMsgContext = MessageTransformer.constructMessage(declineModel,
		//		reqSrcTmm.getSource());
		//TransactionMessageModel resSrcTmm = reqSrcTmm;
		//resSrcTmm.setResCode(declineModel.getResCode());
		TransactionMessageModel response = processTxnResponse(declineModel, targetRemoteAdd, targetEpEntries, camelContext);
		return response;
	}


	public TransactionMessageModel processTxnResponse (TransactionMessageModel resSrcTmm, String remoteAdd, Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries, CamelContext camelContext){

		logger.info(LogUtils.buildLogMessage(resSrcTmm.getEntityId(), resSrcTmm.getTarget(), resSrcTmm.getMsgType(),
				resSrcTmm.getTransactionId(), "Transaction Response Received"));

		try{

			logger.info(LogUtils.buildLogMessage(resSrcTmm.getEntityId(), resSrcTmm.getTarget(), resSrcTmm.getMsgType(),
					resSrcTmm.getTransactionId(), "Constructing transaction response for target"));
			//resSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());

			MessageContext targetMsgContext = MessageTransformer.constructMessage(resSrcTmm,
					resSrcTmm.getSource());
			byte[] targetRawMsg = (byte[]) targetMsgContext.getRawMsg();

			TransactionMessageModel resTargetTmm = targetMsgContext.getTransactionMessageModel();
			resTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
			resTargetTmm.setResponseSentTime(OffsetDateTime.now());

			logger.trace("Response Target Transaction message model: {}", resTargetTmm);

			resTargetTmm.setEpType(EpType.TARGET);


			transactionProcessorHelper.logToTlmBqrMsg(resTargetTmm);

			TxnLogger.logRawMsg(MsgFlow.OUTBOUND, targetRawMsg, resTargetTmm);


			sentResToTarget(remoteAdd, targetEpEntries, camelContext, targetMsgContext, resTargetTmm);

			logger.info(LogUtils.buildLogMessage(resSrcTmm.getEntityId(), resSrcTmm.getTarget(), resSrcTmm.getMsgType(),
					resSrcTmm.getTransactionId(), resSrcTmm.getTransactionName(), "Transaction response sent to target"), resSrcTmm.getSource());


		} catch (Exception e){
			throw new ResponseProcessingException("Error while processing the response message: ", e);
		}
		return resSrcTmm;
	}


	private void sentResToTarget(String remoteAdd,
								 Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries, CamelContext camelContext,
								 MessageContext targetMsgContext, TransactionMessageModel resTargetTmm) {

		EndpointMetaData epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, resTargetTmm.getAquirerIdCode(), remoteAdd);

		NettyEndpoint nEp = NettyConfig.getProducerEndpoint(camelContext, remoteAdd, epByAcqId.getTargetConfigModel());

		RoutingInitializationContext.getMwProducer().justSendMessage(targetMsgContext.getRawMsg(), resTargetTmm.getRetrievalRefNo(), nEp);

	}


	private void processMobileRequest(Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries,
									  CamelContext camelContext, TransactionMessageModel resTargetTmm) {

		TargetConfigModel targetConfigModel =null;

		resTargetTmm.setMsgType("0110");
		resTargetTmm.setProcessingCode("800000");
		resTargetTmm.setTransactionName(TmmConstants.BQR_NOTIFY_REQUEST);

		logger.debug("Request Source Transaction Message Model: {}", resTargetTmm);
		for(RoutingContext routingContext: routingContextList){

			for(TargetConfigModel target: routingContext.getTargets()) {
				if (TargetType.Bqr.name().equals(target.getTargetType().name())){
					targetConfigModel = target;
					break;
				}
			}
			//targetConfigModel = routingContext.getTargets().stream().filter(target -> TargetType.Bqr.name().equals(target.getTargetType().name())).findFirst().get();
		}
		TargetConnection targetConnection = targetConfigModel.getConnections().get(0);

		MessageContext targetMsgContext = MessageTransformer.constructMessage(resTargetTmm, targetConfigModel.getName());

		String bqrRequest = MessageTransformer.getPgResponse(targetMsgContext);

		TxnLogger.logRawMsg(MsgFlow.OUTBOUND, bqrRequest.getBytes(), resTargetTmm);

		String sourceRemoteAdd = targetConnection.getUrlOrIp() + ":" + targetConnection.getPortOrHeaders();

		EndpointMetaData epByAcqIdBqr = RouteUtil.getEndpointByAcquirerId(targetEpEntries, "0", sourceRemoteAdd);

		NettyEndpoint nEpMM = NettyConfig.getProducerEndpoint(camelContext, sourceRemoteAdd, epByAcqIdBqr.getTargetConfigModel());


		RoutingInitializationContext.getMwProducer().sendMessage(bqrRequest.getBytes(), resTargetTmm.getRetrievalRefNo(), nEpMM);

		logger.info(LogUtils.buildLogMessage(resTargetTmm.getEntityId(), resTargetTmm.getSource(), resTargetTmm.getMsgType(),
				resTargetTmm.getTransactionId(), resTargetTmm.getTransactionName(), "Transaction sent to target: " + targetConfigModel.getName()));

		/*
		 * set camel exchange with response received from target end point
		 */
	}



	@Override
	public void processTxnDecline (Exchange exchange){
		TransactionMessageModel declineModel = new TransactionMessageModel();

		Throwable exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class).getCause();
		TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_SRC_TMM);
		RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

		logger.error("Exception :", exception);

		String resCode = null;

		switch (exception.getClass().getSimpleName()){
			case "InvalidMerchantException":
				resCode = TmmConstants.RES_CODE_INVALID_MERCHANT;
				break;

			case "InvalidBinException":
			case "InvalidTxnException":
			case "RefundLimitExceededException":
				resCode = TmmConstants.RES_CODE_INVALID_TXN;

			case "FormatErrorException":
				resCode = TmmConstants.RES_CODE_MANDATORY_FIELD_NOT_PRESENT;
				break;

			case "NullPointerException":
			case "InternalServerError":
			case "SystemErrorException":
			case "DuplicateTxnException":
				resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
				break;

			case "InvalidCardNumberException":
				resCode = TmmConstants.RES_CODE_INVALID_CARD_NUMBER;
				break;

			case "ExecutionException":
			case "InterruptedException":
			case "IssuerUnavailableException":
				resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
				break;

			case "InvalidVoidOrReversalDataException":
			case "NotFound":
				if ("R".equals(reqSrcTmm.getDrcrFlag())){
					resCode = TmmConstants.RES_CODE_SUCCESS;
				}
				else {
					resCode = TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_PRESENT;
				}
				break;

			case "InvalidTxnAmtException":
				resCode = TmmConstants.RES_CODE_INVALID_TXN_AMT;
				break;

			case "MacValidationException":
				resCode = TmmConstants.RES_CODE_INVALID_MAC;
				break;

			default:
				resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
				break;
		}

		if (reqSrcTmm == null){
			declineModel.setTransactionName("decline.bqr.purchase.request");
			declineModel.setEntityId(routingContext.getEntityId());
		}else{
			declineModel = reqSrcTmm;
			declineModel.setTransactionName("decline."+ reqSrcTmm.getTransactionName());
		}

		declineModel.setResCode(resCode);

		logger.trace("Decline Response Code: {}, Decline Txn: {}", declineModel.getResCode(),
				declineModel.getTransactionName());

		declineModel.setSourceProcessor(routingContext.getSource().getSourceProcessor());

		MessageContext targetMsgContext = MessageTransformer.constructMessage(declineModel,
				reqSrcTmm.getSource());

		if (("decline."+TmmConstants.BQR_REFUND_REQUEST).equals(reqSrcTmm.getTransactionName())) {

			String bqrResponse = MessageTransformer.getPgResponse(targetMsgContext);

			TransactionMessageModel resTargetTmm = targetMsgContext.getTransactionMessageModel();
			resTargetTmm.setAcpTraceId(reqSrcTmm.getAcpTraceId());
			resTargetTmm.setDrcrFlag("N");
			transactionProcessorHelper.logToTlm(resTargetTmm, routingContext);


			String reqMsgLength = bqrResponse.split("\\|")[0];
			TxnLogger.logPgRawMsg(MsgFlow.OUTBOUND, bqrResponse);
			TxnLogger.logPgTxnDetail(MsgFlow.OUTBOUND, bqrResponse.substring(reqMsgLength.length() + 1), resTargetTmm);

			logger.trace("Decline Response Transaction message model: {}", resTargetTmm);

			exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQUEST_DECLINED, true);

			ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(bqrResponse.getBytes());

			Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);

			openedChannel.writeAndFlush(rawMsgByteBuf);
		}

	}


	@Override
	public void processTxnRequest(Exchange exchange) {
		try {
			RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
			String entityId = routingContext.getEntityId();
			String txnId = processorHelper.generateTransactionId();

			if (routingContext.isTxnLoggingDebug()) {
				rawlogger.info(LogUtils.buildLogMessage(routingContext.getEntityId(),
								routingContext.getSource().getName(), null, txnId, "Txn Name : {}, {} : [{}]"), null,
						RoutingConstants.REQUEST);
			}

			logger.info(LogUtils.buildLogMessage(entityId, routingContext.getSource().getName(), null, txnId,
					"Transaction received"));

			TransactionMessageModel reqSrcTmm = null;
			if (exchange.getFromEndpoint() instanceof NettyHttpEndpoint) {
				reqSrcTmm = apiTransactionProcessor.toPojo(exchange);
			} else {
				byte[] srcRawMsgBytes = (byte[]) exchange.getIn().getBody();

				if (srcRawMsgBytes.length == 0) {
					throw new InvalidMessageException("Request message is empty");
				}
				String srcRawMsg = new String(srcRawMsgBytes);
				TxnLogger.logPgRawMsg(MsgFlow.INBOUND, srcRawMsg);

                /*if (!srcRawMsg.contains("|")) {
                	DecryptService decryptionService = SpringContextBridge.services().getDecryptionService();
                	srcRawMsg = decryptionService.decrypt(srcRawMsg);
                	isEncrypt = true;
                }*/

				reqSrcTmm = MessageTransformer.toPojo(entityId, OffsetDateTime.now(),
						routingContext.getSource().getName(), srcRawMsg, TlmMessageType.REQUEST, null);
				reqSrcTmm.setRawRequest(TxnLogger.encryptRawMsg(srcRawMsg));
			}


			String acpTraceId = reqSrcTmm.getCardAcceptorId() + reqSrcTmm.getCardAcceptorTerminalId() + reqSrcTmm.getStan();
			reqSrcTmm.setAcpTraceId(acpTraceId);

			setLoggerContext(reqSrcTmm);

			reqSrcTmm.setEpType(EpType.SOURCE);
			reqSrcTmm.setTransactionId(txnId);
			//reqSrcTmm.setRawRequest(TxnLogger.encryptRawMsg(srcRawMsg));
			reqSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
			reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
			reqSrcTmm.setHashedTransactionId(transactionProcessorHelper.getHashedValue(txnId));

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
					"Transaction type: " + reqSrcTmm.getTransactionName()
							+ ", TStan: " + reqSrcTmm.getTerminalStan()
							+ ", MID: " + reqSrcTmm.getCardAcceptorId()
							+ ", TID: " + reqSrcTmm.getCardAcceptorTerminalId()));

			logger.debug("Request Source Transaction Message Model: {}", reqSrcTmm);
			exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);

			transactionProcessorHelper.checkForDuplicateTxn(exchange);

			transactionProcessorHelper.validTxnType(reqSrcTmm);

			//transactionProcessorHelper.checkForMandatoryFields(reqSrcTmm);

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
					reqSrcTmm.getTransactionName(), "Merchant validated: " + reqSrcTmm.getCardAcceptorId()));


			if (TmmConstants.isOriginalTxnRequired(reqSrcTmm.getTransactionName())) {
				reqSrcTmm.setOriginalTmm(fetchOriginalTransaction(reqSrcTmm));
				reqSrcTmm.setSchemeStan(reqSrcTmm.getOriginalTmm().getSchemeStan());
				reqSrcTmm.setHostBatchNo(reqSrcTmm.getOriginalTmm().getHostBatchNo());
				reqSrcTmm.setBatchStatus(reqSrcTmm.getOriginalTmm().getBatchStatus());
				reqSrcTmm.setAuthIdRes(reqSrcTmm.getOriginalTmm().getAuthIdRes());
			}

			transactionProcessorHelper.logToTlm(reqSrcTmm, routingContext);

			//writeRawMsgToFile(srcRawMsg, reqSrcTmm, routingContext.isDebug());

			processBqrSwitchTxn(exchange, reqSrcTmm);

		} catch (Exception e) {
			// TODO: use LogUtils.buildLogMsg (21/8 - To create seperate issue on loggers
			// and take it up)
			throw new RequestProcessingException("Error while processing the request message ", e);
		}
	}

	static byte[] packData(byte[] data) {
		int len = data.length;
		byte buf[] = new byte[len + 2];
		buf[0] = (byte) (len >> 8 & 255);
		buf[1] = (byte) (len & 255);
		System.arraycopy(data, 0, buf, 2, len);
		return buf;
	}


	void processBqrSwitchTxn(Exchange exchange, TransactionMessageModel reqSrcTmm) {
		//RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

		if (reqSrcTmm.getTxnAmt() != null
				&& !reqSrcTmm.getTxnAmt().isEmpty())
		{
			if(TmmConstants.BQR_REFUND_REQUEST.equals(reqSrcTmm.getTransactionName())){
				if (reqSrcTmm.getOriginalTmm().getTxnAmt() != null
						&& !reqSrcTmm.getOriginalTmm().getTxnAmt().isEmpty())
				{

					Double refundAmt = Double.valueOf(reqSrcTmm.getTxnAmt());
					Double originalTxnAmt = Double.valueOf(reqSrcTmm.getOriginalTmm().getTxnAmt());
					if (refundAmt.compareTo(originalTxnAmt) > 0) {
						throw new RefundAmountExceededException(
								("Refund txn limit has been exceeded, expected: " + originalTxnAmt + ", got: "
										+ refundAmt));
					}
				}
			}

			exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
			TransactionMessageModel reqTmm = SerializationUtils.clone(reqSrcTmm);
			// pan is transient field, hence not getting copied while cloning.
			reqTmm.setPan(reqSrcTmm.getPan());
			reqTmm.setResCode(TmmConstants.RES_CODE_SUCCESS);
			exchange.getIn().setBody(reqTmm);
		}
	}


	@Override
	public void processTxnResponse(Exchange exchange) {

		Object requestDeclined = exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQUEST_DECLINED);
		if (transactionProcessorHelper.isRequestDeclined(requestDeclined)) return;

		TransactionMessageModel responseSourceTmm = exchange.getIn().getBody(TransactionMessageModel.class);
		TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_SRC_TMM);
		logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(), responseSourceTmm.getMsgType(),
				responseSourceTmm.getTransactionId(), responseSourceTmm.getTransactionName(), "Transaction response received"));
		String bqrResponse = null;

		try {
			RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

			//transactionProcessorHelper.checkForMandatoryFields(responseSourceTmm);

			logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(), responseSourceTmm.getMsgType(),
					responseSourceTmm.getTransactionId(), responseSourceTmm.getTransactionName(), "Constructing transaction response for target"), reqSrcTmm.getSource());
			responseSourceTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
			MessageContext targetMsgContext = MessageTransformer.constructMessage(responseSourceTmm,
					routingContext.getSource().getName());
			//byte[] targetRawMsg = (byte[]) targetMsgContext.getRawMsg();
			bqrResponse = MessageTransformer.getPgResponse(targetMsgContext);

			TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();
			responseTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
			responseTargetTmm.setResponseSentTime(OffsetDateTime.now());
			responseTargetTmm.setAcpTraceId(reqSrcTmm.getAcpTraceId());

			logger.trace("Response Target Transaction message model: {}", responseTargetTmm);

			responseTargetTmm.setEpType(EpType.TARGET);

			if ((TmmConstants.RES_CODE_SUCCESS.equals(responseTargetTmm.getResCode())
					|| TmmConstants.RES_CODE_AMT_VERFICATION.equals(responseTargetTmm.getResCode()))
					&& TmmConstants.isOriginalTxnRequired(reqSrcTmm.getTransactionName())) {
				transactionProcessorHelper.updateOriginalTxnAndLogTlm(reqSrcTmm.getOriginalTmm(), reqSrcTmm.getDrcrFlag(), routingContext);
				responseTargetTmm.setHostBatchNo(reqSrcTmm.getOriginalTmm().getHostBatchNo());
				responseTargetTmm.setBatchStatus(reqSrcTmm.getOriginalTmm().getBatchStatus());
			}

			transactionProcessorHelper.logToTlm(responseTargetTmm, routingContext);

			logger.trace("Response to BQR: {}", bqrResponse);
			String reqMsgLength = bqrResponse.split("\\|")[0];
			TxnLogger.logPgRawMsg(MsgFlow.OUTBOUND, bqrResponse);
			TxnLogger.logPgTxnDetail(MsgFlow.OUTBOUND, bqrResponse.substring(reqMsgLength.length() + 1), responseTargetTmm);

			ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(bqrResponse.getBytes());

			Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);

			openedChannel.writeAndFlush(rawMsgByteBuf);
			logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(), responseSourceTmm.getMsgType(),
					responseSourceTmm.getTransactionId(), responseSourceTmm.getTransactionName(), "Transaction response sent to target"), reqSrcTmm.getSource());


		} catch (Exception e) {
			throw new ResponseProcessingException("Error while processing the response message: ", e);
		}

	}

	@Override
	public SourceProcessor getSourceProcessor () {
		return SourceProcessor.BQR_SWITCH;
	}
}
