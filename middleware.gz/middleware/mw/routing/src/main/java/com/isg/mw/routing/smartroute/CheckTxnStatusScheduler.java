//package com.isg.mw.routing.smartroute;
//
//import com.isg.mw.routing.context.RoutingContext;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.PropertySource;
//import org.springframework.stereotype.Component;
//
//import java.util.concurrent.Executors;
//import java.util.concurrent.ScheduledExecutorService;
//import java.util.concurrent.TimeUnit;
//
//@Component
//@PropertySource("${spring.config.location}application-uat.properties")
//public class CheckTxnStatusScheduler{
//
//    private Logger logger = LogManager.getLogger();
//
//    private ScheduledExecutorService executor;
//
//    @Autowired
//    private CheckTxnStatusTask checkTxnStatusTask;
//
//
//    @Value("${routing.smartroute.txn.status.thread.pool.size:1}")
//    private Integer threadPoolSize;
//
//    @Value("${smartroute.txn.status.scheduler.delay:300000}")
//    private Integer delay;
//
//    public void scheduleTaskToCheckStatus(RoutingContext routingContext) {
//        logger.trace("Starting CheckTxnStatus Scheduler :: ");
//        executor = Executors.newScheduledThreadPool(threadPoolSize);
//        checkTxnStatusTask.setRoutingContext(routingContext);
//        executor.scheduleAtFixedRate(checkTxnStatusTask, Long.valueOf(delay), Long.valueOf(delay), TimeUnit.MILLISECONDS);
//    }
//
//}
