package com.isg.mw.routing.smartroute;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.mw.cache.mgmt.config.*;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.init.InitProps;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.icici.UpiResponse;
import com.isg.mw.core.model.icici.UpiTxnStatusResponse;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.pg.*;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.PaymentFileDetailsModel;
import com.isg.mw.core.model.tlm.PaymentLinkRequestModel;
import com.isg.mw.core.model.tlm.PaymentLinksModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.notification.model.DataElements;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.core.utils.IsgCurrencyConversionUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.exception.BankServerException;
import com.isg.mw.mtm.exception.FileDetailsMissMatch;
import com.isg.mw.mtm.transform.icici.IciciMessageTransformation;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import com.isg.mw.mtm.transform.payu.PayUMessageTransformation;
import com.isg.mw.mtm.transform.tpsl.TpslMessageTransformation;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import com.isg.mw.routing.util.RouteUtil;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.*;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.activation.DataHandler;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.net.ssl.SSLException;
import javax.xml.bind.JAXBException;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;
import static com.isg.mw.routing.config.RoutingConstants.*;
import static org.apache.poi.ss.usermodel.Cell.*;

@Component
public class SmartRouteTxnHelperController {

    private final Logger logger = LogManager.getLogger(getClass());

    /*
     * URL to get merchant convenience fee details
     */
    @Value("${smartroute.conveniencefee.check.api}")
    private String checkConvenienceFeeApi;


    @Value("${smartroute.conveniencefee.check.Flag.oracle}")
    private String getDetailsConvenienceFeeFlagDb;

    @Value("${smartroute.conveniencefee.get.details.api}")
    private String getDetailsConvenienceFeeApi;


    @Value("${smartroute.conveniencefee.get.oracle.db}")
    private String getDetailsConvenienceFeeDb;


    @Value("${smartroute.conveniencefee.access.token.api}")
    private String getConvenienceFeeAccessTokenApi;

    @Autowired
    private InitProps initProps;

    @Autowired
    @Lazy
    private CacheUtil cacheUtil;

    @Autowired
    private SmartRouteSpringCacheService srCacheService;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Autowired
    private ApiTransactionProcessor apiTransactionProcessor;

    @Autowired
    private SmartRouteTxnController smartRouteTxnController;

    @Value("${smartroute.paymentLink.hashId.url}")
    private String paymentLinkHashIdUrl;

    public String validateAndGetPaymentDataEnc(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        Map<String, Object> resDataMap = validateAndGetPaymentDataMap(exchange, routingContext, sourceConfigModel1, apiRequest);
        String apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Success", resDataMap);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }


    public String validateAndGetPaymentData(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1) {
        String apiRequest = exchange.getIn().getBody(String.class);
        Map<String, Object> resDataMap = validateAndGetPaymentDataMap(exchange, routingContext, sourceConfigModel1, apiRequest);
        String apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Success", resDataMap);
        return apiResponse;
    }

    public String checkStatusEnc(Exchange exchange, RoutingContext routingContext,Boolean isMerchantKitReq) throws InstantiationException, IllegalAccessException, JsonProcessingException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        MerchantEncDataRequest txnStatusDataReq = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantEncDataRequest.class);
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), txnStatusDataReq.getMerchantId());
        JSONObject jsonObject = new JSONObject(apiRequest);
        String secureHash = apiTransactionProcessor.generateMerchantSecureHash(jsonObject, merchantMaster.getSecretKey());
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantEncDataResponse txnStatusDataRes = new MerchantEncDataResponse();
        txnStatusDataRes = txnStatusDataRes.getMerchantTxnStatusDataRes(txnStatusDataReq);
        txnStatusDataRes.setRespDate(OffsetDateTime.now());
        txnStatusDataRes.setRespTime(OffsetDateTime.now());
        if (isMerchantKitReq) {
            String invalidData = null ;
            if(!"Pay".equalsIgnoreCase(txnStatusDataReq.getTxnType()) && !"Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                invalidData = "Txn Type is invalid,It should be Pay or Refund";
            }else if("Pay".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                invalidData = apiTransactionProcessor.validateMerchantKitJson(txnStatusDataReq, CacheSrConfigProperties.getProperty("smartroute.sale.status.api.validation"));
            }else if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                invalidData = apiTransactionProcessor.validateMerchantKitJson(txnStatusDataReq, CacheSrConfigProperties.getProperty("smartroute.refund.status.api.validation"));
            }
            if(!StringUtils.isBlank(invalidData)){
                MerchantEncDataResponse errorStatusDataRes = txnStatusDataRes;
                errorStatusDataRes.setMessage(invalidData);
                if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())) {
                    errorStatusDataRes.setStatus(PaymentStatus.FAILED.name());
                }else{
                    errorStatusDataRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                }
                errorStatusDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(errorStatusDataRes, merchantMaster.getSecretKey());
                resDataMap.put("txnStatusRes", errorStatusDataRes);
                if (isMerchantKitReq) {
                    return IsgJsonUtils.getJsonString(errorStatusDataRes);
                } else {
                    return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, invalidData, resDataMap);
                }
            }
        }
        if (isMerchantKitReq && !secureHash.equalsIgnoreCase(txnStatusDataReq.getSecureHash())) {
            MerchantEncDataResponse errorStatusDataRes = txnStatusDataRes;
            errorStatusDataRes.setMessage("Invalid Secure Hash");
            if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())) {
                errorStatusDataRes.setStatus(PaymentStatus.FAILED.name());
            }else{
                errorStatusDataRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
            }
            errorStatusDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(errorStatusDataRes, merchantMaster.getSecretKey());
            resDataMap.put("txnStatusRes", errorStatusDataRes);
            if (isMerchantKitReq) {
                return IsgJsonUtils.getJsonString(errorStatusDataRes);
            } else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Invalid Secure Hash", resDataMap);
            }
        }
        ApiTxnModel apiTxnModel = new ApiTxnModel();
        apiTxnModel.setMid(txnStatusDataReq.getMerchantId());
        apiTxnModel.setTid(txnStatusDataReq.getTerminalId());
        apiTxnModel.setOriginalHashedTxnId(txnStatusDataReq.getRetRefNo());
        apiTxnModel.setTxnAmt(txnStatusDataReq.getRefundAmount());
        String apiResponse = checkStatus(exchange, routingContext, apiTxnModel, txnStatusDataReq,isMerchantKitReq,merchantMaster);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String checkStatus(Exchange exchange, RoutingContext routingContext,Boolean isMerchantKitReq) throws InstantiationException, IllegalAccessException, JsonProcessingException {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("checkTxnStatus Body: {}", apiRequest);
        MerchantEncDataRequest txnStatusDataReq = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantEncDataRequest.class);
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), txnStatusDataReq.getMerchantId());
        JSONObject jsonObject = new JSONObject(apiRequest);
        String secureHash = apiTransactionProcessor.generateMerchantSecureHash(jsonObject, merchantMaster.getSecretKey());
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantEncDataResponse txnStatusDataRes = new MerchantEncDataResponse();
        txnStatusDataRes = txnStatusDataRes.getMerchantTxnStatusDataRes(txnStatusDataReq);
        if (isMerchantKitReq) {
            String invalidData = null ;
            if(!"Pay".equalsIgnoreCase(txnStatusDataReq.getTxnType()) && !"Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                invalidData = "Txn Type is invalid,It should be Pay or Refund";
            }else if("Pay".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                invalidData = apiTransactionProcessor.validateMerchantKitJson(txnStatusDataReq, CacheSrConfigProperties.getProperty("smartroute.sale.status.api.validation"));
            }else if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                invalidData = apiTransactionProcessor.validateMerchantKitJson(txnStatusDataReq, CacheSrConfigProperties.getProperty("smartroute.refund.status.api.validation"));
            }
            if(!StringUtils.isBlank(invalidData)){
                MerchantEncDataResponse errorStatusDataRes = txnStatusDataRes;
                errorStatusDataRes.setMessage(invalidData);
                if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())) {
                    errorStatusDataRes.setStatus(PaymentStatus.FAILED.name());
                }else{
                    errorStatusDataRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                }
                errorStatusDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(errorStatusDataRes, merchantMaster.getSecretKey());
                resDataMap.put("txnStatusRes", errorStatusDataRes);
                if (isMerchantKitReq) {
                    return IsgJsonUtils.getJsonString(errorStatusDataRes);
                } else {
                    return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, invalidData, resDataMap);
                }
            }
        }
        if (isMerchantKitReq && !secureHash.equalsIgnoreCase(txnStatusDataReq.getSecureHash())) {
            MerchantEncDataResponse errorStatusDataRes = txnStatusDataRes;
            errorStatusDataRes.setMessage("Invalid Secure Hash");
            if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())) {
                errorStatusDataRes.setStatus(PaymentStatus.FAILED.name());
            }else{
                errorStatusDataRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
            }
            errorStatusDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(errorStatusDataRes, merchantMaster.getSecretKey());
            resDataMap.put("txnStatusRes", errorStatusDataRes);
            if (isMerchantKitReq) {
                return IsgJsonUtils.getJsonString(errorStatusDataRes);
            } else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Invalid Secure Hash", resDataMap);
            }
        }
        ApiTxnModel apiTxnModel = new ApiTxnModel();
        apiTxnModel.setMid(txnStatusDataReq.getMerchantId());
        apiTxnModel.setTid(txnStatusDataReq.getTerminalId());
        apiTxnModel.setOriginalHashedTxnId(txnStatusDataReq.getRetRefNo());
        apiTxnModel.setTxnAmt(txnStatusDataReq.getRefundAmount());
        return checkStatus(exchange, routingContext, apiTxnModel, txnStatusDataReq,isMerchantKitReq,merchantMaster);
    }


    private String checkStatus(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel, MerchantEncDataRequest txnStatusDataReq ,Boolean isMerchantKitReq,MerchantMasterModel merchantMaster) {
        String apiResponse = null;
        Map<String, Object> resDataMap = new HashMap<>();
        String msg = null;
        ResponseMsgType responseMsgType = null;
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        Object tmmByTxnRefNo = null;
        if ("Pay".equalsIgnoreCase(txnStatusDataReq.getTxnType().toString())) {
            tmmByTxnRefNo = getTmmByTxnRefNo(txnStatusDataReq.getTxnRefNo(), txnStatusDataReq.getTxnType(), null,
                    txnStatusDataReq.getMerchantId(), txnStatusDataReq.getTerminalId());
        } else if ("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType().toString())) {
            tmmByTxnRefNo = getTmmByTxnRefNo(txnStatusDataReq.getRefCancelId(), txnStatusDataReq.getTxnType(), null,
                    txnStatusDataReq.getMerchantId(), txnStatusDataReq.getTerminalId());
        }
        TransactionMessageModel originalTransaction = tmmByTxnRefNo != null ? mapper.convertValue(tmmByTxnRefNo,TransactionMessageModel.class) : null;
//        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), txnStatusDataReq.getMerchantId());
        if (originalTransaction == null) {
            MerchantEncDataResponse errorStatusDataRes = new MerchantEncDataResponse();
            errorStatusDataRes = errorStatusDataRes.getMerchantTxnStatusDataRes(txnStatusDataReq);
            errorStatusDataRes.setMessage("TransactionMessageModel is not present with input request");
            errorStatusDataRes.setRespDate(OffsetDateTime.now());
            errorStatusDataRes.setRespTime(OffsetDateTime.now());
            if("Refund".equalsIgnoreCase(txnStatusDataReq.getTxnType())){
                errorStatusDataRes.setStatus(PaymentStatus.FAILED.name());
            }else{
                errorStatusDataRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
            }
            msg = "Original TransactionMessageModel Not Found";
            responseMsgType = ResponseMsgType.ERROR;
            errorStatusDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(errorStatusDataRes, merchantMaster.getSecretKey());
            resDataMap.put("txnStatusRes", errorStatusDataRes);
            if(isMerchantKitReq){
                apiResponse = IsgJsonUtils.getJsonString(errorStatusDataRes);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(responseMsgType, msg, resDataMap);
            }
        } else {
            MerchantEncReqRes orgTxnMerchantIntReqData = originalTransaction.getMerchantIntegrationReqRes();
            MerchantEncDataRequest encDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(orgTxnMerchantIntReqData.getEncData(),
                    merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            if (originalTransaction.getMsgType().equalsIgnoreCase(IciciMsgType.Pay.msgType) || originalTransaction.getMsgType().equalsIgnoreCase(IciciMsgType.UpiQR.msgType) || originalTransaction.getMsgType().equalsIgnoreCase(IciciMsgType.NbCorpPay.msgType) || originalTransaction.getMsgType().equalsIgnoreCase(IciciMsgType.NbRetailPay.msgType)) {
                MerchantPayAndRefundStatusRes txnPayStatusRes = new MerchantPayAndRefundStatusRes();
                if (originalTransaction.getResCode().equalsIgnoreCase("00")) {
                    txnPayStatusRes = txnPayStatusRes.getMerchantTxnPayStatusDataRes(txnStatusDataReq);
                    txnPayStatusRes.setPayStatusAdditionalData(txnPayStatusRes,originalTransaction,encDataRequest);
                    txnPayStatusRes.setMessage("Success,Sale Transaction Is found.");
                    txnPayStatusRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.SUCCESS));
                    txnPayStatusRes.setRespDate(originalTransaction.getResponseReceivedTime());
                    txnPayStatusRes.setRespTime(originalTransaction.getResponseReceivedTime());
                    msg = "Success,Sale Transaction Is found.";
                    responseMsgType = ResponseMsgType.SUCCESS;
                } else {
                    txnPayStatusRes = txnPayStatusRes.getMerchantTxnPayStatusDataRes(txnStatusDataReq);
                    txnPayStatusRes.setPayStatusAdditionalData(txnPayStatusRes,originalTransaction,encDataRequest);
                    txnPayStatusRes.setRespDate(originalTransaction.getResponseReceivedTime());
                    txnPayStatusRes.setRespTime(originalTransaction.getResponseReceivedTime());
                    if (originalTransaction.getResCode().equalsIgnoreCase("-1")) {
                        txnPayStatusRes.setMessage("Pending,Sale Transaction Is found.");
                        txnPayStatusRes.setResponseCode(originalTransaction.getResCode());
                    } else {
                        txnPayStatusRes.setMessage("Failed,Sale Transaction Is found.");
                        txnPayStatusRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                    }
                    msg = "Failed,Sale Transaction Is found.";
                    responseMsgType = ResponseMsgType.ERROR;
                }
                txnPayStatusRes = apiTransactionProcessor.getMerchantResWithSecureHash(txnPayStatusRes, merchantMaster.getSecretKey());
                resDataMap.put("txnStatusRes", txnPayStatusRes);
                if(isMerchantKitReq){
                    apiResponse = IsgJsonUtils.getJsonString(txnPayStatusRes);
                }else{
                    apiResponse = apiTransactionProcessor.getApiResponse(responseMsgType, msg, resDataMap);
                }
            }
            if (originalTransaction.getMsgType().equalsIgnoreCase("Refund")) {
                MerchantPayAndRefundStatusRes txnRefundStatusRes = new MerchantPayAndRefundStatusRes();
                if (originalTransaction.getResCode().equalsIgnoreCase("00")) {
                    txnRefundStatusRes = txnRefundStatusRes.getMerchantTxnRefundStatusDataRes(txnStatusDataReq);
                    txnRefundStatusRes.setRespDate(originalTransaction.getResponseReceivedTime());
                    txnRefundStatusRes.setRespTime(originalTransaction.getResponseReceivedTime());
                    txnRefundStatusRes.setMessage("Success,Refund Transaction Is found.");
                    txnRefundStatusRes.setStatus(PaymentStatus.SUCCESS.name());
                    txnRefundStatusRes.setRefundStatusAdditionalData(txnRefundStatusRes,originalTransaction);
                    msg = "Success,Refund Transaction Is found.";
                    responseMsgType = ResponseMsgType.SUCCESS;
                } else {
                    txnRefundStatusRes = txnRefundStatusRes.getMerchantTxnRefundStatusDataRes(txnStatusDataReq);
                    txnRefundStatusRes.setRespDate(originalTransaction.getResponseReceivedTime());
                    txnRefundStatusRes.setRespTime(originalTransaction.getResponseReceivedTime());
                    txnRefundStatusRes.setMessage("Failed,Refund Transaction Is found.");
                    txnRefundStatusRes.setStatus(PaymentStatus.FAILED.name());
                    txnRefundStatusRes.setRefundStatusAdditionalData(txnRefundStatusRes,originalTransaction);
                    msg = "Failed,Refund Transaction Is found.";
                    responseMsgType = ResponseMsgType.ERROR;
                }
                txnRefundStatusRes = apiTransactionProcessor.getMerchantResWithSecureHash(txnRefundStatusRes, merchantMaster.getSecretKey());
                resDataMap.put("txnStatusRes", txnRefundStatusRes);
                if(isMerchantKitReq){
                    apiResponse = IsgJsonUtils.getJsonString(txnRefundStatusRes);
                }else{
                    apiResponse = apiTransactionProcessor.getApiResponse(responseMsgType, msg, resDataMap);
                }
            }
        }

        return apiResponse;
    }

    public String checkTxnStatusEnc(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException, JsonProcessingException, NoSuchAlgorithmException, JAXBException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("checkTxnStatus Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = checkTxnStatus(exchange, routingContext, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String checkTxnStatus(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException, JsonProcessingException, JAXBException {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("checkTxnStatus Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return checkTxnStatus(exchange, routingContext, apiTxnModel);
    }

    public String checkTxnStatus(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException, JsonProcessingException, JAXBException {
        String apiResponse = null;
        String response = null;
        if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("payu")) {
            PayUMessageTransformation payUMessageTransformation = PayUMessageTransformation.class.newInstance();
            response = payUMessageTransformation.verifyPaymentStatusByTransactionId(apiTxnModel.getOriginalHashedTxnId());
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, response);
        } else if (apiTxnModel.getPaymentSource() != null && (apiTxnModel.getPaymentSource().equalsIgnoreCase("upi"))) {
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Icici &&
                    apiTxnModel.getPaymentSource().equalsIgnoreCase(targetConfigModel.getAdditionalData().getPaymentSource())).findFirst().get();
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID,targetConfigModel1.getId());
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
            IciciMessageTransformation iciciMessageTransformation = IciciMessageTransformation.class.newInstance();
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            transactionMessageModel.setOriginalHashedTxnId(apiTxnModel.getOriginalHashedTxnId());
            transactionMessageModel.setSourceProcessor(SourceProcessor.SMART_ROUTE);
            transactionMessageModel.setTarget(targetConfigModel1.getName());
            transactionMessageModel.setMsgType(IciciMsgType.TransactionStatus.msgType);
            TransactionMessageModel originalTmm = null;
            Map<String, Object> upiObjectMap = new HashMap<>();
            try {
                originalTmm = fetchOriginalTransaction(transactionMessageModel);
            }catch(Exception e){
                logger.info("Exception While fetching UPI original transaction model: {} ",e.getMessage());
                upiObjectMap.put("message", "pending");
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.PENDING, upiObjectMap.get("message").toString(), upiObjectMap);

            }
            originalTmm.setLinkHashId(apiTxnModel.getLinkHashId());
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_TGT_TMM,originalTmm);
            if ((originalTmm != null && "-1".equalsIgnoreCase(originalTmm.getResCode()))
                    && (originalTmm.getResSmartRouteData().getUpiResponse() != null)
                    && !("92".equalsIgnoreCase(originalTmm.getResSmartRouteData().getUpiResponse().getActCode())
                    || "0".equalsIgnoreCase(originalTmm.getResSmartRouteData().getUpiResponse().getActCode()))) {
                throw new BankServerException("Upi Transaction Failed : ", routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
            } else {
                if ((originalTmm != null && "-1".equalsIgnoreCase(originalTmm.getResCode()))
                        && (originalTmm.getResSmartRouteData().getUpiResponse() != null)) {
                    UpiResponse upiResponse = originalTmm.getResSmartRouteData().getUpiResponse();
                    transactionMessageModel.setProcessingCode(apiTxnModel.getPayModeId());
                    UpiTxnStatusResponse statusResponse = iciciMessageTransformation.checkTransactionStatus(targetConfigModel1, transactionMessageModel, originalTmm);
                    ObjectMapper mapper = new ObjectMapper();
                    upiObjectMap.put("transactionId", originalTmm.getTransactionId());
                    MerchOrdTxnData txnData = cacheUtil.getTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
                    if (statusResponse != null && "0".equalsIgnoreCase(statusResponse.getActCode())) {
                        upiResponse.setActCode(statusResponse.getActCode());
                        upiResponse.setBankRRN(statusResponse.getBankRRN());
                        UpiTxnStatusResponse.MobileAppData mobileAppData = statusResponse.getMobileAppData();
                        if (mobileAppData != null && mobileAppData.getDetails() != null && mobileAppData
                                .getDetails().getTxnStatusData() != null) {
                            UpiTxnStatusResponse.TxnStatusData txnStatusData = mobileAppData.getDetails().getTxnStatusData();
                            if (!StringUtils.isBlank(txnStatusData.getTxnStatus()) && "SUCCESS".equalsIgnoreCase(txnStatusData.getTxnStatus())) {
                                upiResponse.setTxnStatus(txnStatusData.getTxnStatus());
                                upiResponse.setPayeeVpa(txnStatusData.getPayeeVa());
                                upiResponse.setPayerIFSC(txnStatusData.getPayerIFSC());
                                upiResponse.setPayerAccount(txnStatusData.getPayerAccount());
                                upiResponse.setPayerVpa(txnStatusData.getPayerVa());
                                upiResponse.setAccountType(txnStatusData.getPayerAccountType());
                                upiResponse.setTxnStatus(txnStatusData.getTxnStatus());
                                upiObjectMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {
                                });
                                upiObjectMap.put("message", "Transaction Successful");
                                originalTmm.getSmartRouteData().setUpiResponse(upiResponse);
                                originalTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                originalTmm.setRetrievalRefNo(txnStatusData.getRrn());
                                originalTmm.setResCode("00");
                                smartRouteTxnController.changeStatus(txnData,apiTxnModel,routingContext.getEntityId(),originalTmm.getTransactionId(),"Success");
                                //SET TXN_MSG_MODEL
                                SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,originalTmm);
                                logger.info(LogUtils.buildSMLogMessage(originalTmm.getEntityId(),originalTmm.getMerchantTxnRefNo(),originalTmm.getTransactionId(),
                                        originalTmm.getTransactionName(),"Check Status Success Tmm Response  : {}"), originalTmm);
                                processorHelper.logToTlm(originalTmm, routingContext);
                                //Merchant Enc Data Generation
                                ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                                retryEvent.setRetryFlag("N");
                                ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
                                Map<String, String> retryData = new HashMap<>();
                                MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), originalTmm.getCardAcceptorId());
                                if (!StringUtils.isBlank(apiTxnModel.getLinkHashId())) {
                                    String encData = txnData.getEncData();
                                    MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encData, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                                    retryData.put("TransactionId", originalTmm.getTransactionId());
                                    retryData.put("PaymentStatus", PaymentStatus.SUCCESS.name());
                                    retryData.put("OrderId", originalTmm.getMerchantTxnRefNo());
                                    retryData.put("PaymentMode", "Upi");
                                    retryData.put("MerchantName", merchantMaster.getMerchantName());
                                    retryData.put("Amount", IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(Integer.valueOf(originalTmm.getTxnAmt()).toString()));
                                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                                    Date date = Date.from(originalTmm.getResponseReceivedTime().toInstant());
                                    retryData.put("Date", formatter.format(date));
                                    retryData.put("Email", merchantEncDataRequest.getEmail());
                                    retryData.put("MobileNo", merchantEncDataRequest.getPhone());
                                    retryData.put("RRN", originalTmm.getRetrievalRefNo());
                                    retryEvent.setRetryData(retryData);
                                    redirectEvent.setTargetUrl("");
                                    upiObjectMap.put("retryEvent", retryEvent);
                                    upiObjectMap.put("redirectEvent", redirectEvent);
                                } else {
                                    String encData = txnData.getEncData();
                                    MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encData, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                                    MerchantEncDataResponse merchantEncDataRes = apiTransactionProcessor.toMerchantEncDataRes(merchantEncDataRequest);
                                    merchantEncDataRes.setRetRefNo(originalTmm.getTransactionId());
                                    merchantEncDataRes.setResponseCode("00");
                                    merchantEncDataRes.setMessage("Transaction Successful");
                                    merchantEncDataRes.setRespDate(originalTmm.getResponseReceivedTime());
                                    merchantEncDataRes.setRespTime(originalTmm.getResponseReceivedTime());
                                    encData = apiTransactionProcessor.encryptMerchantData(merchantEncDataRes, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                                    retryData.put("MerchantId", originalTmm.getCardAcceptorId());
                                    retryData.put("EncData", encData);
                                    retryData.put("BankId", txnData.getBankId());
                                    retryData.put("TerminalId", originalTmm.getCardAcceptorTerminalId());
                                    retryEvent.setRetryData(retryData);
                                    redirectEvent.setTargetUrl(txnData.getMerchantReturnUrl());
                                    upiObjectMap.put("retryEvent", retryEvent);
                                    upiObjectMap.put("redirectEvent", redirectEvent);
                                }
                                apiTxnModel.setPaymentAttemptCounter(txnData.getRetryCount().toString());
                                smartRouteTxnController.setPaymentStatus(null, apiTxnModel, PaymentStatus.SUCCESS);
                                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, upiObjectMap.get("message").toString(), upiObjectMap);
                            } else if (!StringUtils.isBlank(txnStatusData.getTxnStatus()) && "FAILURE".equalsIgnoreCase(txnStatusData.getTxnStatus())) {
                                throw new BankServerException("Upi Transaction Failed : ", routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
                            } else {
                                return getUpiResponseForPendingStatus(routingContext, apiTxnModel, originalTmm, upiObjectMap, upiResponse, mapper, txnData);
                            }
                        } else {
                            return getUpiResponseForPendingStatus(routingContext, apiTxnModel, originalTmm, upiObjectMap, upiResponse, mapper, txnData);
                        }
                    } else {
                        return getUpiResponseForPendingStatus(routingContext, apiTxnModel, originalTmm, upiObjectMap, upiResponse, mapper, txnData);
                    }
                } else if ((originalTmm != null && "00".equalsIgnoreCase(originalTmm.getResCode()))
                        && (originalTmm.getResSmartRouteData().getUpiResponse() != null
                        && ("SUCCESS".equalsIgnoreCase(originalTmm.getResSmartRouteData().getUpiResponse().getTxnStatus()))
                        && "0".equalsIgnoreCase(originalTmm.getResSmartRouteData().getUpiResponse().getActCode()))) {
                    UpiResponse upiResponse = originalTmm.getResSmartRouteData().getUpiResponse();
                    ObjectMapper mapper = new ObjectMapper();
                    upiObjectMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {
                    });
                    MerchOrdTxnData txnData = cacheUtil.getTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
                    upiObjectMap.put("transactionId", originalTmm.getTransactionId());
                    upiObjectMap.put("message", "Transaction Successful");
                    //Merchant Enc Data Generation
                    ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                    retryEvent.setRetryFlag("N");
                    ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
                    String encData = txnData.getEncData();
                    Map<String, String> retryData = new HashMap<>();
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), originalTmm.getCardAcceptorId());
                    if (!StringUtils.isBlank(apiTxnModel.getLinkHashId())) {
                        MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encData, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                        retryData.put("TransactionId", originalTmm.getTransactionId());
                        retryData.put("PaymentStatus", PaymentStatus.SUCCESS.name());
                        retryData.put("OrderId", originalTmm.getMerchantTxnRefNo());
                        retryData.put("PaymentMode", "Upi");
                        retryData.put("MerchantName", merchantMaster.getMerchantName());
                        retryData.put("Amount", IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(Integer.valueOf(originalTmm.getTxnAmt()).toString()));
                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                        Date date = Date.from(originalTmm.getResponseReceivedTime().toInstant());
                        retryData.put("Date", formatter.format(date));
                        retryData.put("Email", merchantEncDataRequest.getEmail());
                        retryData.put("MobileNo", merchantEncDataRequest.getPhone());
                        retryData.put("RRN", upiResponse.getBankRRN());
                        retryEvent.setRetryData(retryData);
                        redirectEvent.setTargetUrl("");
                        upiObjectMap.put("retryEvent", retryEvent);
                        upiObjectMap.put("redirectEvent", redirectEvent);
                    } else {
                        MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encData, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                        MerchantEncDataResponse merchantEncDataRes = apiTransactionProcessor.toMerchantEncDataRes(merchantEncDataRequest);
                        merchantEncDataRes.setRespDate(originalTmm.getResponseReceivedTime());
                        merchantEncDataRes.setRespTime(originalTmm.getResponseReceivedTime());
                        merchantEncDataRes.setRetRefNo(originalTmm.getTransactionId());
                        merchantEncDataRes.setResponseCode("00");
                        merchantEncDataRes.setMessage("Transaction Successful");
                        encData = apiTransactionProcessor.encryptMerchantData(merchantEncDataRes, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
                        retryData.put("MerchantId", originalTmm.getCardAcceptorId());
                        retryData.put("EncData", encData);
                        retryData.put("BankId", txnData.getBankId());
                        retryData.put("TerminalId", originalTmm.getCardAcceptorTerminalId());
                        retryEvent.setRetryData(retryData);
                        redirectEvent.setTargetUrl(txnData.getMerchantReturnUrl());
                        upiObjectMap.put("retryEvent", retryEvent);
                        upiObjectMap.put("redirectEvent", redirectEvent);
                        upiObjectMap.put("targetUrl", txnData.getMerchantReturnUrl());
                    }
                    apiTxnModel.setPaymentAttemptCounter(txnData.getRetryCount().toString());
                    smartRouteTxnController.setPaymentStatus(null, apiTxnModel, PaymentStatus.SUCCESS);
                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, upiObjectMap.get("message").toString(), upiObjectMap);
                } else {
                    throw new BankServerException("Upi Transaction Failed : ", routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
//                UpiResponse upiResponse = originalTmm.getResSmartRouteData().getUpiResponse();
//                ObjectMapper mapper = new ObjectMapper();
//                upiObjectMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {
//                });
//                ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
//                ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
//                Map<String, String> retryData = new HashMap<>();
//                MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), originalTmm.getCardAcceptorId());
//                if (!StringUtils.isBlank(apiTxnModel.getLinkHashId())) {
//                    retryData.put("TransactionId", originalTmm.getTransactionId());
//                    retryData.put("PaymentStatus", PaymentStatus.FAILED.name());
//                    retryData.put("OrderId", originalTmm.getMerchantTxnRefNo());
//                    retryData.put("PaymentMode", "Upi");
//                    retryData.put("MerchantName", merchantMaster.getMerchantName());
//                    retryData.put("Amount", IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(Integer.valueOf(originalTmm.getTxnAmt()).toString()));
//                    retryData.put("Date", "");
//                    retryEvent.setRetryFlag("N");
//                    retryEvent.setRetryData(retryData);
//                    redirectEvent.setTargetUrl("");
//                    upiObjectMap.put("retryEvent", retryEvent);
//                    upiObjectMap.put("redirectEvent", redirectEvent);
//                } else {
//                    MerchOrdTxnData txnData = cacheUtil.getTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
//                    upiObjectMap.put("transactionId", originalTmm.getTransactionId());
//                    upiObjectMap.put("message", "Transaction Failed.");
//                    upiObjectMap.put("targetUrl", txnData.getTxnFailedReturnUrl());
//                    upiObjectMap.put("merchantId", originalTmm.getCardAcceptorId());
//                    upiObjectMap.put("encData", txnData.getEncData());
//                    upiObjectMap.put("bankId", txnData.getBankId());
//                    upiObjectMap.put("terminalId", originalTmm.getCardAcceptorTerminalId());
//                }
//                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiObjectMap.get("message").toString(), upiObjectMap);
                }
            }
        } else if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("lyra")) {
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            transactionMessageModel.setTransactionId(apiTxnModel.getTransactionId());
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Lyra).findFirst().get();
            LyraMessageTransformation lyraMessageTransformation = LyraMessageTransformation.class.newInstance();
            Map<String, Object> objectMap = lyraMessageTransformation.checkTrxnStatusRequest(transactionMessageModel, targetConfigModel1);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, objectMap);
        }else if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("tpsl")) {
            Map<String, Object> tpslObjectMap = new HashMap<>();
            ObjectMapper mapper = new ObjectMapper();
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Tpsl).findFirst().get();
            TpslMessageTransformation tpslMessageTransformation = TpslMessageTransformation.class.newInstance();
            String tpslTxnSatusRes = tpslMessageTransformation.getTpslTxnSatusReq(transactionMessageModel, targetConfigModel1);
            tpslObjectMap = mapper.readValue(tpslTxnSatusRes, new TypeReference<Map<String, Object>>() {});
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, tpslObjectMap);
        }
        return apiResponse;
    }

    private String getUpiResponseForPendingStatus(RoutingContext routingContext, ApiTxnModel apiTxnModel, TransactionMessageModel originalTmm, Map<String, Object> upiObjectMap, UpiResponse upiResponse, ObjectMapper mapper, MerchOrdTxnData txnData) throws JsonProcessingException {
        Boolean isRetryExceeded = false;
        ResponseObj.RetryEvent retryEvent =  new ResponseObj.RetryEvent();
        ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
        retryEvent.setRetryData(new HashMap<>());
        String encData = txnData.getEncData();
        isRetryExceeded = smartRouteTxnController.isRetryExceeded(txnData, isRetryExceeded);
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), originalTmm.getCardAcceptorId());
        MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encData, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
        MerchantEncDataResponse merchantEncDataRes = apiTransactionProcessor.toMerchantEncDataRes(merchantEncDataRequest);

        if (isRetryExceeded) {
            merchantEncDataRes.setMessage("Payment for given merchant txn reference number:  " + apiTxnModel.getMerchantTxnRefNo() + " is already processed.");
            merchantEncDataRes.setStatus(PaymentStatus.FAILED.name());
            merchantEncDataRes.setRespDate(originalTmm.getResponseReceivedTime());
            merchantEncDataRes.setRespTime(originalTmm.getResponseReceivedTime());
            encData = apiTransactionProcessor.encryptMerchantData(merchantEncDataRes, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            Map<String, String> retryData = new HashMap<>();
            retryData.put("MerchantId", apiTxnModel.getMid());
            retryData.put("EncData", encData);
            retryData.put("BankId", routingContext.getEntityId());
            retryData.put("TerminalId", apiTxnModel.getTid());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl(merchantEncDataRequest.getReturnURL());
            upiObjectMap.put("retryEvent", retryEvent);
            upiObjectMap.put("redirectEvent", redirectEvent);
            upiObjectMap.put("retryCount", txnData.getRetryCount());
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.PENDING, "Payment for given merchant txn reference number: " + apiTxnModel.getMerchantTxnRefNo() + " is already processed.", upiObjectMap);
        }else if(!StringUtils.isBlank(apiTxnModel.getTimer()) && apiTxnModel.getTimer().equals("00") && !StringUtils.isBlank(apiTxnModel.getLinkHashId())){
            Map<String, String> retryData = new HashMap<>();
            retryData.put("TransactionId", originalTmm.getTransactionId());
            retryData.put("PaymentStatus", PaymentStatus.FAILED.name());
            retryData.put("OrderId", originalTmm.getMerchantTxnRefNo());
            retryData.put("PaymentMode", "Upi");
            retryData.put("MerchantName",merchantMaster.getMerchantName());
            retryData.put("Amount", IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(new BigInteger(originalTmm.getTxnAmt()).toString()));
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            Date date = Date.from(originalTmm.getResponseReceivedTime().toInstant());
            retryData.put("Date", formatter.format(date));
            retryData.put("Email", merchantEncDataRequest.getEmail());
            retryData.put("MobileNo", merchantEncDataRequest.getPhone());
            retryData.put("RRN", upiResponse.getBankRRN());
            retryEvent.setRetryData(retryData);
            redirectEvent.setTargetUrl("");
            upiObjectMap.put("retryEvent",retryEvent);
            upiObjectMap.put("redirectEvent",redirectEvent);
            apiTxnModel.setPaymentAttemptCounter(txnData.getRetryCount().toString());
            smartRouteTxnController.setPaymentStatus(null, apiTxnModel, PaymentStatus.FAILED);
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Upi Payment Failed", upiObjectMap);
        } else {
            Map<String, String> retryData = new HashMap<>();
            retryData.put("MerchantId", apiTxnModel.getMid());
            retryData.put("EncData", encData);
            retryData.put("BankId", routingContext.getEntityId());
            retryData.put("TerminalId", apiTxnModel.getTid());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag("Y");
            redirectEvent.setTargetUrl(null);
            upiObjectMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {
            });
            upiObjectMap.put("message", "pending");
            upiObjectMap.put("retryEvent", retryEvent);
            upiObjectMap.put("redirectEvent", redirectEvent);
            upiObjectMap.put("retryCount", txnData.getRetryCount());
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.PENDING, upiObjectMap.get("message").toString(), upiObjectMap);
        }
    }

    public String validateTxnStatus(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException, JsonProcessingException, JAXBException {
        String apiResponse = null;
        String response = null;
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("checkTxnStatus Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("payu")) {
            PayUMessageTransformation payUMessageTransformation = PayUMessageTransformation.class.newInstance();
            response = payUMessageTransformation.verifyPaymentStatusByTransactionId(apiTxnModel.getOriginalHashedTxnId());
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, response);
        } else if (apiTxnModel.getPaymentSource() != null && (apiTxnModel.getPaymentSource().equalsIgnoreCase("upi"))) {
            Map<String, Object> upiObjectMap = new HashMap<>();
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Icici &&
                    apiTxnModel.getPaymentSource().equalsIgnoreCase(targetConfigModel.getAdditionalData().getPaymentSource())).findFirst().get();
            IciciMessageTransformation iciciMessageTransformation = IciciMessageTransformation.class.newInstance();
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            transactionMessageModel.setProcessingCode(apiTxnModel.getPayModeId());
            UpiTxnStatusResponse statusResponse = iciciMessageTransformation.checkTransactionStatus(targetConfigModel1, transactionMessageModel, null);
            ObjectMapper mapper = new ObjectMapper();
            if (statusResponse != null) {
                upiObjectMap = mapper.readValue(IsgJsonUtils.getJsonString(statusResponse), new TypeReference<Map<String, Object>>() {
                });
            }
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, upiObjectMap);
        } else if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("lyra")) {
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Lyra).findFirst().get();
            LyraMessageTransformation lyraMessageTransformation = LyraMessageTransformation.class.newInstance();
            Map<String, Object> objectMap = lyraMessageTransformation.checkTrxnStatusRequest(transactionMessageModel, targetConfigModel1);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, objectMap);
        } else if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("tpsl")) {
            Map<String, Object> tpslObjectMap = new HashMap<>();
            ObjectMapper mapper = new ObjectMapper();
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            transactionMessageModel.setTransactionId(apiTxnModel.getTransactionId());
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Tpsl).findFirst().get();
            TpslMessageTransformation tpslMessageTransformation = TpslMessageTransformation.class.newInstance();
            String tpslTxnSatusRes = tpslMessageTransformation.getTpslTxnSatusReq(transactionMessageModel, targetConfigModel1);
            tpslObjectMap = mapper.readValue(tpslTxnSatusRes, new TypeReference<Map<String, Object>>() {
            });
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, tpslObjectMap);
        }
        return apiResponse;
    }

    public String generateOtpEnc(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("generateOtpEnc Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = generateOtp(exchange, routingContext, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String generateOtp(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.info("generate OTP Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return generateOtp(exchange, routingContext, apiTxnModel);
    }

    public String generateOtp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        String response = null;
        String apiResponse = null;
        if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("lyra")) {
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Lyra).findFirst().get();
            LyraMessageTransformation lyraMessageTransformation = LyraMessageTransformation.class.newInstance();
            response = lyraMessageTransformation.generateOtpRequest(transactionMessageModel, targetConfigModel1);
            String responseCode = null;
            if(StringUtils.isBlank(response)) {
                JSONObject generateOtpResponse = new JSONObject(response);
                responseCode = (String) generateOtpResponse.get("code");
            }
            if ("200" == responseCode || "00" == responseCode) {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, response, null);
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, response, null);
            }
        }
        return apiResponse;
    }

    public String verifyOtpEnc(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("verify OTP Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = verifyOtp(exchange, routingContext, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String verifyOtp(Exchange exchange, RoutingContext routingContext) throws InstantiationException, IllegalAccessException {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.info("verify OTP Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return verifyOtp(exchange, routingContext, apiTxnModel);
    }

    public String verifyOtp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        String apiResponse = null;
        if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("lyra")) {
            TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
            TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Lyra).findFirst().get();
            LyraMessageTransformation lyraMessageTransformation = LyraMessageTransformation.class.newInstance();
            String response = lyraMessageTransformation.verifyOtpRequest(transactionMessageModel, targetConfigModel1);
            JSONObject verifyOtpResponse = new JSONObject(response);
            String responseCode = (String) verifyOtpResponse.get("responseCode");
            if ("200".equalsIgnoreCase(responseCode) || "00".equalsIgnoreCase(responseCode)) {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, response, null);
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, response, null);
            }
        }
        return apiResponse;
    }

    public String getConvenienceFeeEnc(Exchange exchange) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("Convenience Fee Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = getConvenienceFee(exchange, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String getConvenienceFee(Exchange exchange) {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("Convenience Fee Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return getConvenienceFee(exchange, apiTxnModel);
    }

    public String getConvenienceFee(Exchange exchange, ApiTxnModel apiTxnModel) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        String apiResponse = null;
        apiTxnModel.setBankName("");
        apiTxnModel.setTxnType("SALES");
        switch (apiTxnModel.getPayModeId()){
            case "1" :
                if (!StringUtils.isBlank(apiTxnModel.getPayModeOptionId())) {
                    Long payModeOptionId = Long.valueOf(apiTxnModel.getPayModeOptionId());
                    String modeOptionName = srCacheService.getPaymentModeOption(payModeOptionId).getModeOptionName();
                    apiTxnModel.setBankName(!StringUtils.isBlank(modeOptionName) ? modeOptionName : "");
                }
                apiTxnModel.setSchemeType("NB");
                break;
            case "2" :
                apiTxnModel.setWallet("WALLET");
                apiTxnModel.setSchemeType("WALLET");
                break;
            case "3" :
                BinInfoModel binInfoModel = SpringContextBridge.services().getCacheService().getSchemeBin(apiTxnModel.getCardNo().replaceAll(" ", ""));
                if(binInfoModel != null){
                    String cardProgram = binInfoModel.getCardProgram();
                    LOFO lofo = binInfoModel.getLofo();
                    String cardCategory = binInfoModel.getCardCategory();
                    String schemeName = binInfoModel.getSchemeName();
                    //SET CARDPROGRAM
                    if (!StringUtils.isBlank(cardProgram) && cardProgram.trim().equalsIgnoreCase("DEBIT")) {
                        apiTxnModel.setDrCrFlag("D");
                    } else if (!StringUtils.isBlank(cardProgram) && cardProgram.trim().equalsIgnoreCase("CREDIT")) {
                        apiTxnModel.setDrCrFlag("C");
                    } else if (!StringUtils.isBlank(cardProgram) && cardProgram.trim().equalsIgnoreCase("PREPAID")) {
                        apiTxnModel.setDrCrFlag("P");
                    }
                    //SET LOFO
                    if (lofo.equals(LOFO.F)) {
                        apiTxnModel.setOwnLoFo("F");
                    } else if (lofo.equals(LOFO.L)) {
                        apiTxnModel.setOwnLoFo("L");
                    }
                    //SET CARDCATEGORY
                    if (!StringUtils.isBlank(cardCategory)) {
                        apiTxnModel.setCardCategory(cardCategory);
                    }
                    //SET CARDCATEGORY
                    if (!StringUtils.isBlank(schemeName)) {
                        apiTxnModel.setNetwork(schemeName.toUpperCase());
                    }
                }
                apiTxnModel.setTxnCat("OFFUS");
                apiTxnModel.setSchemeType("ECOM");
                break;
            case "4" :
                apiTxnModel.setSchemeType("UPI");
                break;
            case "5" :
                apiTxnModel.setOfflinePaymentMode("CASH");
                apiTxnModel.setSchemeType("OFFLINEPAYMENTMODE");
                break;
            case "6" :
                apiTxnModel.setOfflinePaymentMode("CHEQUE");
                apiTxnModel.setSchemeType("OFFLINEPAYMENTMODE");
                break;
            case "7" :
                apiTxnModel.setOfflinePaymentMode("NEFT/RTGS");
                apiTxnModel.setSchemeType("OFFLINEPAYMENTMODE");
                break;
        }
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
        if(merchantMaster.getMerchantStateCode().equalsIgnoreCase("MH")){
            apiTxnModel.setCgstPer(MTMProperties.getProperty("sm.convenience.cgst.mh.state"));
            apiTxnModel.setSgstPer(MTMProperties.getProperty("sm.convenience.sgst.mh.state"));
            apiTxnModel.setIgstPer(MTMProperties.getProperty("sm.convenience.igst.mh.state"));
        }else{
            apiTxnModel.setCgstPer(MTMProperties.getProperty("sm.convenience.cgst.other.state"));
            apiTxnModel.setSgstPer(MTMProperties.getProperty("sm.convenience.sgst.other.state"));
            apiTxnModel.setIgstPer(MTMProperties.getProperty("sm.convenience.igst.other.state"));
        }
        BigDecimal amount = IsgCurrencyConversionUtils.convertPaisaToRupees(apiTxnModel.getTxnAmt());
        String conFeeDetailsRes = null;
        if(ConnectionType.API.name().equals(MTMProperties.getProperty("convenience.type"))) {
            conFeeDetailsRes = getConvenienceFeeDetails(apiTxnModel, getDetailsConvenienceFeeApi);
        }
        else {
            conFeeDetailsRes = getConvenienceFeeDB(apiTxnModel, getDetailsConvenienceFeeDb);
        }
        if (!StringUtils.isBlank(conFeeDetailsRes)) {
            DecimalFormat df = new DecimalFormat("0.00");
            String convFeeResponse = getConvFeeResponse(conFeeDetailsRes, getDetailsConvenienceFeeApi);
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> nodeMap = null;
            try {
                nodeMap = mapper.readValue(convFeeResponse, new TypeReference<Map<String, Object>>() {
                });
                Double convenienceFee = (double) nodeMap.get("commission");
                Double cgst = (double) nodeMap.get("cgstAmt");
                Double sgst = (double)nodeMap.get("sgstAmt");
                Double igst = (double)nodeMap.get("igstAmt");
                BigDecimal convenienceFeeAmt = IsgCurrencyConversionUtils.convertPaisaToRupees(convenienceFee.toString());
                BigDecimal cgstAmt = IsgCurrencyConversionUtils.convertPaisaToRupees(cgst.toString());
                BigDecimal sgstAmt = IsgCurrencyConversionUtils.convertPaisaToRupees(sgst.toString());
                BigDecimal igstAmt = IsgCurrencyConversionUtils.convertPaisaToRupees(igst.toString());
                BigDecimal orderTotalAmt = amount.add(convenienceFeeAmt).add(cgstAmt).add(sgstAmt).add(igstAmt);
                nodeMap.put("convenienceFee", convenienceFeeAmt);
                nodeMap.put("cgstAmt", cgstAmt);
                nodeMap.put("sgstAmt", sgstAmt);
                nodeMap.put("igstAmt", igstAmt);
                nodeMap.put("orderTotalAmt",orderTotalAmt);
                nodeMap.put("txnAmt", amount);
                apiResponse = mapper.convertValue(nodeMap, JsonNode.class).toString();
            } catch (JsonProcessingException e) {
                logger.trace("error while parsing conFeeDetailsRes : " + e);
            }
        }
        return apiResponse;
    }
    public String verifyVpaEnc(Exchange exchange, RoutingContext routingContext) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("verifyVpaEnc Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = verifyVpa(exchange, routingContext, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String verifyVpa(Exchange exchange, RoutingContext routingContext) {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("verifyVpa Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return verifyVpa(exchange, routingContext, apiTxnModel);
    }

    public String verifyVpa(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) {
        apiTxnModel.setMsgType("VerifyVPA");
        Map<String, Object> resDataMap = smartRouteTxnController.verifyVPA(exchange, routingContext, apiTxnModel);
//        Map<String, Object> resDataMap = smartRouteTxnController.getTargetAndGenerateRequest(exchange, routingContext, apiTxnModel);
        if (resDataMap == null) {
            TransactionMessageModel body = exchange.getIn().getBody(TransactionMessageModel.class);
            UpiResponse upiResponse = body.getUpiResponse();
            if (upiResponse != null && "0".equalsIgnoreCase(upiResponse.getActCode())) {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Verified VPA", null);
            } else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage(), null);
            }
        } else {
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, null, resDataMap);
        }
    }

    private Map<String, Object> validateAndGetPaymentDataMap(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1, String apiRequest) {
        //validate the merchant
        //String encReqBody = exchange.getIn().getBody(String.class);
        ApiTxnModel apiTxnModel = new ApiTxnModel();
        ResponseObj responseObj = new ResponseObj();
        ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
        ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantEncReqRes encReqObj = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantEncReqRes.class);
        String merchantId = encReqObj.getMerchantId();
        String terminalId = encReqObj.getTerminalId();
        String entityId = encReqObj.getBankId();
        logger.trace("Merchant : {} with Bank id : {}", merchantId, entityId);
        MapsInfoModel mapsInfoModel;
        MerchantMasterModel merchantMaster;
        try {
            mapsInfoModel = processorHelper.validateMerchant(entityId, merchantId, terminalId);
            merchantMaster = processorHelper.validateMerchantMaster(entityId, merchantId);
        }catch (Exception e){
            String message = e.getMessage();
            Map<String, Object> orderDetails = new HashMap<>();
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl("");
            orderDetails.put("orderDetails","");
            responseObj.setData(orderDetails);
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            responseObj.setMsg(message);
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }
        logger.info("Domain URL From Browser : {} ,  And Merchant Website URL : {}", encReqObj.getDomainUrl() ,merchantMaster.getWebsiteURL());
        if("Y".equalsIgnoreCase(MTMProperties.getProperty("domain.url.enable.flag"))) {
            try {
                URI domainURL = new URI(encReqObj.getDomainUrl());
                URI websiteURL = new URI(merchantMaster.getWebsiteURL());
                if (domainURL != null && !domainURL.getHost().equals(websiteURL.getHost())) {
                    Map<String, Object> orderDetails = new HashMap<>();
                    retryEvent.setRetryFlag("N");
                    redirectEvent.setTargetUrl("");
                    orderDetails.put("orderDetails","");
                    responseObj.setData(orderDetails);
                    responseObj.setRedirectEvent(redirectEvent);
                    responseObj.setRetryEvent(retryEvent);
                    responseObj.setStatusCode("01");
                    responseObj.setMsg("Domain validation failed for given merchant :  " + merchantId);
                    resDataMap.put("responseObj", responseObj);
                    return resDataMap;
                }
            } catch (Exception e) {
                logger.trace("Exception while retrive host from  {}");
            }
        }

        //will always be merchant SDK encrypted
        MerchantEncDataRequest merchantEncDataRequest;
        boolean isPymnetLink;
        String validateAmount;
        if (encReqObj.getEncData() != null) {
            merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encReqObj.getEncData(),
                    merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            if (merchantEncDataRequest == null) {
                Map<String, Object> orderDetails = new HashMap<>();
                responseObj.setStatusCode("01");
                retryEvent.setRetryFlag("N");
                redirectEvent.setTargetUrl("");
                orderDetails.put("orderDetails","");
                responseObj.setData(orderDetails);
                responseObj.setRedirectEvent(redirectEvent);
                responseObj.setRetryEvent(retryEvent);
                responseObj.setMsg("Invalid Key and Salt For Given MID : " + encReqObj.getMerchantId() + " And TID : " + encReqObj.getTerminalId());
                resDataMap.put("responseObj", responseObj);
                return resDataMap;
            }
//            String amount = merchantEncDataRequest.getAmount();
//            validateAmount =  merchantEncDataRequest.getAmount();
//            merchantEncDataRequest.setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(amount));
        } else {
            //String apiRequest = exchange.getIn().getBody(String.class);
            apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
            merchantEncDataRequest = new MerchantEncDataRequest();
            merchantEncDataRequest.setMerchantId(merchantId);
            merchantEncDataRequest.setTerminalId(terminalId);
            merchantEncDataRequest.setTxnRefNo(apiTxnModel.getMerchantTxnRefNo());
            merchantEncDataRequest.setMcc(merchantMaster.getMccCode());
//            validateAmount =  apiTxnModel.getTxnAmt();
            merchantEncDataRequest.setAmount(apiTxnModel.getTxnAmt());
            merchantEncDataRequest.setTxnType("Pay");
            merchantEncDataRequest.setVersion("1");
            merchantEncDataRequest.setCurrency(mapsInfoModel.getAcquirerCurrencyCode());
            merchantEncDataRequest.setReturnURL(apiTxnModel.getReturnUrl());
            merchantEncDataRequest.setUdf01(apiTxnModel.getUdf01());
            merchantEncDataRequest.setUdf02(apiTxnModel.getUdf02());
            merchantEncDataRequest.setUdf03(apiTxnModel.getUdf03());
            merchantEncDataRequest.setUdf04(apiTxnModel.getUdf04());
            merchantEncDataRequest.setUdf05(apiTxnModel.getUdf05());
            merchantEncDataRequest.setUdf06(apiTxnModel.getUdf06());
            merchantEncDataRequest.setUdf07(apiTxnModel.getUdf07());
            merchantEncDataRequest.setUdf08(apiTxnModel.getUdf08());
            merchantEncDataRequest.setUdf09(apiTxnModel.getUdf09());
            merchantEncDataRequest.setUdf10(apiTxnModel.getUdf10());
            merchantEncDataRequest.setEmail(apiTxnModel.getCustomerEmail());
            merchantEncDataRequest.setPhone(apiTxnModel.getCustomerMobNo());
            merchantEncDataRequest.setOrderInfo(apiTxnModel.getRemark());
            String encryptMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataRequest, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            merchantEncDataRequest.setLinkHashId(apiTxnModel.getLinkHashId());
            encReqObj.setEncData(encryptMerchantData);
            encReqObj.setRetryFlag("Y");
        }

        //Validate Merchant Fields
        boolean isInvalidMerchantFields = validateAndGetPaymentDataValidation(merchantEncDataRequest, merchantMaster, encReqObj, responseObj, retryEvent, redirectEvent, resDataMap);
        if(isInvalidMerchantFields){
            return resDataMap;
        }

        if(!merchantEncDataRequest.getCurrency().equalsIgnoreCase(mapsInfoModel.getAcquirerCurrencyCode())){
            //String amount = merchantEncDataRequest.getAmount();
            MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
            merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
            //merchantEncDataResponse.setAmount(IsgCurrencyConversionUtils.convertRupeesToPaisa(amount));
            merchantEncDataResponse.setMessage("Currency Code : " + merchantEncDataRequest.getCurrency() + ", is invalid for selected merchant " + merchantId);
            merchantEncDataResponse.setStatus(PaymentStatus.FAILED.name());
            merchantEncDataResponse.setRespDate(OffsetDateTime.now());
            merchantEncDataResponse.setRespTime(OffsetDateTime.now());
            String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            encReqObj.setEncData(encMerchantData);
            Map<String, String> retryData = new HashMap<>();
            retryData.put("MerchantId", encReqObj.getMerchantId());
            retryData.put("EncData", encReqObj.getEncData());
            retryData.put("BankId", encReqObj.getBankId());
            retryData.put("TerminalId", encReqObj.getTerminalId());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl(merchantEncDataRequest.getReturnURL());
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            responseObj.setMsg("Currency Code : " + merchantEncDataRequest.getCurrency() + ", is invalid for selected merchant " + merchantId);
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }

        if("Y".equalsIgnoreCase(MTMProperties.getProperty("sm.mcc.enable.flag")) && !merchantEncDataRequest.getMcc().equals(merchantMaster.getMccCode())){
            MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
            merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
            merchantEncDataResponse.setMessage("Mcc Code : " + merchantEncDataRequest.getMcc() + ", is invalid for selected merchant " + merchantId);
            merchantEncDataResponse.setStatus(PaymentStatus.FAILED.name());
            merchantEncDataResponse.setRespDate(OffsetDateTime.now());
            merchantEncDataResponse.setRespTime(OffsetDateTime.now());
            String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            encReqObj.setEncData(encMerchantData);
            Map<String, String> retryData = new HashMap<>();
            retryData.put("MerchantId", encReqObj.getMerchantId());
            retryData.put("EncData", encReqObj.getEncData());
            retryData.put("BankId", encReqObj.getBankId());
            retryData.put("TerminalId", encReqObj.getTerminalId());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl(merchantEncDataRequest.getReturnURL());
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            responseObj.setMsg("Mcc Code : " + merchantEncDataRequest.getMcc() + ", is invalid for selected merchant " + merchantId);
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }
        // get merchant payment mode and options
        List<UnifiedPaymentMode> unifiedPayModeAndOps = getMerchantPayModeAndOps(entityId, merchantMaster.getMid());
        // get unified target payment options with removing merchant payment mode and options
        unifiedPayModeAndOps = getUnifiedPayModeAndOps(entityId,unifiedPayModeAndOps);
        resDataMap.put("paymentModes", unifiedPayModeAndOps.stream().sorted(Comparator.comparing(UnifiedPaymentMode :: getPayModeId)).collect(Collectors.toList()));
        /*
        Convert Amount Rupees To Paisa for
         */
        String amount = merchantEncDataRequest.getAmount();
        merchantEncDataRequest.setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(amount));
        resDataMap.put("orderDetails", merchantEncDataRequest);
        MerchantDetails merchantDetails = new MerchantDetails();
        merchantDetails.setMerchantName(merchantMaster.getMerchantName());
        //Convenience fee flag check
        String conFeeDetailsRes = null;
        String convFeeFlag = "N";
        if (merchantMaster.getConvFeeFlag() != null && merchantMaster.getConvFeeFlag() == ActiveInactiveFlag.Active) {
            apiTxnModel = new ApiTxnModel();
            apiTxnModel.setMid(merchantId);

            if(ConnectionType.API.name().equals(MTMProperties.getProperty("convenience.type"))) {
                conFeeDetailsRes = getConvenienceFeeDetails(apiTxnModel, checkConvenienceFeeApi);
            }
            else {
                conFeeDetailsRes = getConvenienceFeeDB(apiTxnModel, getDetailsConvenienceFeeFlagDb);
            }
            if (!StringUtils.isBlank(conFeeDetailsRes)) {
                convFeeFlag = getConvFeeResponse(conFeeDetailsRes, checkConvenienceFeeApi);
            }
        }

        merchantDetails.setConvFeeFlag(convFeeFlag);
        resDataMap.put("merchantDetails", merchantDetails);

        String txnRefNo = merchantEncDataRequest.getTxnRefNo();
        MerchOrdTxnData merchOrdTxnData = cacheUtil.getTxnData(routingContext.getEntityId(), merchantId, txnRefNo);
        boolean isTxnRefNoAlreadyExist = false;
        if ("N".equals(encReqObj.getRetryFlag())) {
            // Check if transaction done using payment link base on retry flag and count, if not then it will be normal transaction from merchant store
//            if (!StringUtils.isBlank(merchantEncDataRequest.getLinkHashId()) && merchOrdTxnData != null && merchOrdTxnData.getRetryCount() <= 0) {
//                isTxnRefNoAlreadyExist = false;
//            } else {
            isTxnRefNoAlreadyExist = merchOrdTxnData == null ? false : true;
//            }
        }
        //Retry Flag other Than 'Y'
        else if (!"Y".equals(encReqObj.getRetryFlag())) {
            Map<String, Object> orderDetails = new HashMap<>();
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl("");
            orderDetails.put("orderDetails", "");
            responseObj.setData(orderDetails);
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            responseObj.setMsg("Something went wrong! Please try again");
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }
        if (merchOrdTxnData == null) {
            merchOrdTxnData = new MerchOrdTxnData();
        }
        //Check Transaction is exist with success status in merchOrdTxnData map
        boolean isSuccessTxnExist = false;
        boolean isRetryExceeded = false;
        isSuccessTxnExist = smartRouteTxnController.isSuccessTxnExist(merchOrdTxnData, isSuccessTxnExist);
        isRetryExceeded = smartRouteTxnController.isRetryExceeded(merchOrdTxnData, isRetryExceeded);
        logger.info("Link Hash ID : {} , IsSuccessTxnExist : {}, isRetryExceeded : {}, isTxnRefAlreadyExist : {} ",merchantEncDataRequest.getLinkHashId(),
                isSuccessTxnExist,isRetryExceeded,isTxnRefNoAlreadyExist);
        if (StringUtils.isBlank(merchantEncDataRequest.getLinkHashId()) && (isSuccessTxnExist || isRetryExceeded || isTxnRefNoAlreadyExist)) {
            String rupeesAmount = merchantEncDataRequest.getAmount();
            MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
            merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
            merchantEncDataResponse.setAmount(IsgCurrencyConversionUtils.convertRupeesToPaisa(rupeesAmount));
            merchantEncDataResponse.setMessage("Payment for given merchant txn reference number:  " + txnRefNo + " is already processed.");
            merchantEncDataResponse.setStatus(PaymentStatus.FAILED.name());
            merchantEncDataResponse.setRespDate(OffsetDateTime.now());
            merchantEncDataResponse.setRespTime(OffsetDateTime.now());
            String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            encReqObj.setEncData(encMerchantData);
            Map<String, String> retryData = new HashMap<>();
            retryData.put("MerchantId", encReqObj.getMerchantId());
            retryData.put("EncData", encReqObj.getEncData());
            retryData.put("BankId", encReqObj.getBankId());
            retryData.put("TerminalId", encReqObj.getTerminalId());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl(merchantEncDataRequest.getReturnURL());
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            responseObj.setMsg("Payment for given merchant txn reference number:  " + txnRefNo + " is already processed.");
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }
        merchOrdTxnData.setTerminalId(encReqObj.getTerminalId());
        merchOrdTxnData.setBankId(encReqObj.getBankId());
        merchOrdTxnData.setEncData(encReqObj.getEncData());
        merchOrdTxnData.setCreatedAt(OffsetDateTime.now());
        merchOrdTxnData.setTxnStatus("Pending");
        merchOrdTxnData.setMerchantEncryptionKey(merchantMaster.getEncryptionKey());
        merchOrdTxnData.setMerchantSecretKey(merchantMaster.getSecretKey());
        cacheUtil.putTxnData(routingContext.getEntityId(), merchantId, txnRefNo, merchOrdTxnData);
        return resDataMap;
    }

    private boolean validateAndGetPaymentDataValidation(MerchantEncDataRequest merchantEncDataRequest, MerchantMasterModel merchantMaster, MerchantEncReqRes encReqObj, ResponseObj responseObj, ResponseObj.RetryEvent retryEvent, ResponseObj.RedirectEvent redirectEvent, Map<String, Object> resDataMap) {
        String inValidMsg = apiTransactionProcessor.validateMerchantKitJson(merchantEncDataRequest, CacheSrConfigProperties.getProperty("smartroute.sale.api.validation"));
        if(!StringUtils.isBlank(inValidMsg)){
            MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
            merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
            merchantEncDataResponse.setMessage(inValidMsg);
            merchantEncDataResponse.setRespDate(OffsetDateTime.now());
            merchantEncDataResponse.setRespTime(OffsetDateTime.now());
            responseObj.setMsg("Invalid Request");
            merchantEncDataResponse.setStatus(PaymentStatus.FAILED.name());
            String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
            encReqObj.setEncData(encMerchantData);
            Map<String, String> retryData = new HashMap<>();
            retryData.put("MerchantId", encReqObj.getMerchantId());
            retryData.put("EncData", encReqObj.getEncData());
            retryData.put("BankId", encReqObj.getBankId());
            retryData.put("TerminalId", encReqObj.getTerminalId());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl(merchantEncDataRequest.getReturnURL());
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            resDataMap.put("responseObj", responseObj);
            return true;
        }
        return false;
    }

    private List<UnifiedPaymentMode> getMerchantPayModeAndOps(String entityId, String mid) {
        List<UnifiedPaymentMode> unifiedPaymentModes = new ArrayList<>();
        List<CacheMerchantPaymentModeAndOptions> cacheMerchPayModeAndOps = srCacheService.getMerchantPayModeAndOptionsData(entityId, mid);
        if (cacheMerchPayModeAndOps != null) {
            for (CacheMerchantPaymentModeAndOptions cachMerch : cacheMerchPayModeAndOps) {
                if (cachMerch.getMerchantPaymentMode().getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name()) &&
                        RouteUtil.isDateInBetweenEndPoints(cachMerch.getMerchantPaymentMode().getStartDate(), cachMerch.getMerchantPaymentMode().getEndDate(), OffsetDateTime.now())) {
                    Long paymentModeId = cachMerch.getMerchantPaymentMode().getPaymentModeId();
                    String paymentModeName = srCacheService.getPaymentMode(paymentModeId).getPaymentModeName();
                    Set<UnifiedPaymentModeOptions> unifiedPaymentModeOptions = new HashSet<>();
                    if (!StringUtils.isBlank(paymentModeName) && (!(paymentModeName.toLowerCase().contains("cards") || paymentModeName.toLowerCase().contains("upi")))) {
                        List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptions = cachMerch.getMerchantPaymentModeOptions();
                        if (merchantPaymentModeOptions != null && !merchantPaymentModeOptions.isEmpty()) {
                            Collection<MerchantPaymentModeOptionsModel> values = merchantPaymentModeOptions;
//                            logger.info("Payment Modes Options For Payment Mode Id : {} Is  : {}" ,paymentModeId, values.size());
                            for (MerchantPaymentModeOptionsModel model : values) {
                                if (model != null && cachMerch.getMerchantPaymentMode().getMerchantPaymentModeId().equals(model.getMerchantPaymentModeId())) {
//                                   logger.info("Merchant Payment Mode And Merchant Payment Mode Option :{}", merchPayOp);
//                                   if (RouteUtil.isDateInBetweenEndPoints(merchPayOp.getStartDate(), merchPayOp.getEndDate(), OffsetDateTime.now())) {
                                    Long paymentModeOptionId = model.getPaymentModeOptionId();
                                    String modeOptionName = srCacheService.getPaymentModeOption(paymentModeOptionId).getModeOptionName();
                                    UnifiedPaymentModeOptions unifiedPaymentModeOptions1 = new UnifiedPaymentModeOptions(paymentModeOptionId, modeOptionName);
                                    unifiedPaymentModeOptions.add(unifiedPaymentModeOptions1);
//                                   } else {
//                                       logger.warn("Merchant payment mode option : {}, has ELAPSED... Hence skipping", merchPayOp);
//                                   }
                                }
                            }
                        }
                    }
                    UnifiedPaymentMode unifiedPaymentMode = new UnifiedPaymentMode(paymentModeId, paymentModeName, unifiedPaymentModeOptions);
                    unifiedPaymentModes.add(unifiedPaymentMode);
                } else {
                    logger.warn("Merchant payment mode : {}, has ELAPSED... Hence skipping", cachMerch);
                }
            }
        }
        logger.info("Unified Merchant Payment Modes : {} ", unifiedPaymentModes);
        return unifiedPaymentModes;
    }

    private List<UnifiedPaymentMode> getUnifiedPayModeAndOps(String entityId, List<UnifiedPaymentMode> unifiedPayModeAndOps) {
        Set<CacheTargetPaymentModeAndOptions> targetPayModeAndOptionsData = srCacheService.getAllTargetPayModeAndOptionsData(entityId);
        Map<Long, UnifiedPaymentMode> unifiedPaymentModeMap = new HashMap<>();
        for (CacheTargetPaymentModeAndOptions cacheTgtPayModeOps : targetPayModeAndOptionsData) {
            TargetPaymentModesModel tgtPayMode = cacheTgtPayModeOps.getTargetPaymentMode();
            if (RouteUtil.isDateInBetweenEndPoints(tgtPayMode.getStartDate(), tgtPayMode.getEndDate(), OffsetDateTime.now())) {
                Set<UnifiedPaymentModeOptions> unifiedPayModeOpsList = new HashSet<>();
                String paymentModeName = srCacheService.getPaymentMode(tgtPayMode.getPaymentModeId()).getPaymentModeName();
                if (!StringUtils.isBlank(paymentModeName) && !(paymentModeName.toLowerCase().contains("Card".toLowerCase()))) {
                    for (TargetPaymentModeOptionsModel tgtPayModeOp : cacheTgtPayModeOps.getTargetPaymentModeOptions()) {
                        if (RouteUtil.isDateInBetweenEndPoints(tgtPayModeOp.getStartDate(), tgtPayModeOp.getEndDate(), OffsetDateTime.now())) {
                            PaymentModeOptionsModel paymentModeOption = srCacheService.getPaymentModeOption((tgtPayModeOp.getPaymentModeOptionId()));
                            UnifiedPaymentModeOptions unifiedPayModeOps = new UnifiedPaymentModeOptions(tgtPayModeOp.getPaymentModeOptionId(), paymentModeOption.getModeOptionName());
                            unifiedPayModeOpsList.add(unifiedPayModeOps);
                        } else {
                            logger.warn("Target payment mode option: {}, has ELAPSED... Hence skipping", tgtPayModeOp);
                        }
                    }
                }
                UnifiedPaymentMode unifiedPaymentMode = new UnifiedPaymentMode(tgtPayMode.getPaymentModeId(),
                        srCacheService.getPaymentMode(tgtPayMode.getPaymentModeId()).getPaymentModeName(), unifiedPayModeOpsList);
                if (unifiedPaymentModeMap.containsKey(unifiedPaymentMode.getPayModeId())) {
                    UnifiedPaymentMode existingSinglePayMode = unifiedPaymentModeMap.get(unifiedPaymentMode.getPayModeId());
                    Set<UnifiedPaymentModeOptions> existingSinglePayModeOpsList = existingSinglePayMode.getPayModeOptions();

                    Set<UnifiedPaymentModeOptions> newSinglePayModeOpsList = unifiedPaymentMode.getPayModeOptions();
                    existingSinglePayModeOpsList.addAll(newSinglePayModeOpsList);
                } else {
                    unifiedPaymentModeMap.put(unifiedPaymentMode.getPayModeId(), unifiedPaymentMode);
                }
            } else {
                logger.warn("Target payment mode: {}, has ELAPSED... Hence skipping", tgtPayMode);
            }
        }
        List<UnifiedPaymentMode> values = new ArrayList<>(unifiedPaymentModeMap.values());
        if(unifiedPayModeAndOps != null && !unifiedPayModeAndOps.isEmpty()) {
            for (UnifiedPaymentMode unifiedPaymentModes : unifiedPayModeAndOps) {
                Set<UnifiedPaymentModeOptions> payModeOptions = unifiedPaymentModes.getPayModeOptions();
                if (payModeOptions != null && !payModeOptions.isEmpty()) {
                    for(UnifiedPaymentModeOptions unifiedPaymentModeOptions : payModeOptions)
                        values.stream().forEach(unifiedPaymentMode -> {
                            if(unifiedPaymentMode.getPayModeOptions().contains(unifiedPaymentModeOptions)){
                                unifiedPaymentMode.getPayModeOptions().remove(unifiedPaymentModeOptions);}});
                }else {
                    values.remove(unifiedPaymentModes);
                }
            }
        }
        logger.trace("Unified pay options for entity: {}, {}", entityId, values);
        return values;
    }



    private List<UnifiedPaymentMode> getUnifiedPayModeAndOps(String entityId) {
        Set<CacheTargetPaymentModeAndOptions> targetPayModeAndOptionsData = srCacheService.getAllTargetPayModeAndOptionsData(entityId);
        Map<Long, UnifiedPaymentMode> unifiedPaymentModeMap = new HashMap<>();

        for (CacheTargetPaymentModeAndOptions cacheTgtPayModeOps : targetPayModeAndOptionsData) {
            TargetPaymentModesModel tgtPayMode = cacheTgtPayModeOps.getTargetPaymentMode();
            if (RouteUtil.isDateInBetweenEndPoints(tgtPayMode.getStartDate(), tgtPayMode.getEndDate(), OffsetDateTime.now())) {
                Set<UnifiedPaymentModeOptions> unifiedPayModeOpsList = new HashSet<>();
                String paymentModeName = srCacheService.getPaymentMode(tgtPayMode.getPaymentModeId()).getPaymentModeName();
                if (!StringUtils.isBlank(paymentModeName) && !(paymentModeName.toLowerCase().contains("Card".toLowerCase()))) {
                    for (TargetPaymentModeOptionsModel tgtPayModeOp : cacheTgtPayModeOps.getTargetPaymentModeOptions()) {
                        if (RouteUtil.isDateInBetweenEndPoints(tgtPayModeOp.getStartDate(), tgtPayModeOp.getEndDate(), OffsetDateTime.now())) {
                            PaymentModeOptionsModel paymentModeOption = srCacheService.getPaymentModeOption((tgtPayModeOp.getPaymentModeOptionId()));
                            UnifiedPaymentModeOptions unifiedPayModeOps = new UnifiedPaymentModeOptions(tgtPayModeOp.getPaymentModeOptionId(), paymentModeOption.getModeOptionName());
                            unifiedPayModeOpsList.add(unifiedPayModeOps);
                        } else {
                            logger.warn("Target payment mode option: {}, has ELAPSED... Hence skipping", tgtPayModeOp);
                        }
                    }
                }
                UnifiedPaymentMode unifiedPaymentMode = new UnifiedPaymentMode(tgtPayMode.getPaymentModeId(),
                        srCacheService.getPaymentMode(tgtPayMode.getPaymentModeId()).getPaymentModeName(), unifiedPayModeOpsList);
                if (unifiedPaymentModeMap.containsKey(unifiedPaymentMode.getPayModeId())) {
                    UnifiedPaymentMode existingSinglePayMode = unifiedPaymentModeMap.get(unifiedPaymentMode.getPayModeId());
                    Set<UnifiedPaymentModeOptions> existingSinglePayModeOpsList = existingSinglePayMode.getPayModeOptions();

                    Set<UnifiedPaymentModeOptions> newSinglePayModeOpsList = unifiedPaymentMode.getPayModeOptions();
                    existingSinglePayModeOpsList.addAll(newSinglePayModeOpsList);
                } else {
                    unifiedPaymentModeMap.put(unifiedPaymentMode.getPayModeId(), unifiedPaymentMode);
                }
            } else {
                logger.warn("Target payment mode: {}, has ELAPSED... Hence skipping", tgtPayMode);
            }
        }
        List<UnifiedPaymentMode> values = new ArrayList<>(unifiedPaymentModeMap.values());
        logger.trace("Unified pay options for entity: {}, {}", entityId, values);
        return values;
    }

    public String getConvenienceFeeDetails(ApiTxnModel apiTxnModel, String url) {
        HttpHeaders headers = getConvenienceHttpHeaders();
        headers.add("Authorization", getConvenienceAccessToken());
        logger.info("Convenience Fee Api Request URL : {} , Headers : {} , Body : {} ",url,headers,new JSONObject(apiTxnModel).toString());
        String res = null;
        try {
            SslContext sslContext = null;
            try {
                sslContext = SslContextBuilder.forClient()
                        .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
            } catch (SSLException e) {
                e.printStackTrace();
            }
            SslContext finalSslContext = sslContext;
            HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
            WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
            ClientResponse block = webClient.clientConnector(new ReactorClientHttpConnector(httpClient)).build().post().uri(url).headers(httpHeaders -> {
                        httpHeaders.addAll(headers);
                    }).body(Mono.just(apiTxnModel),
                            ApiTxnModel.class).exchange()
                    .block(Duration.ofSeconds(20));

            HttpStatus httpStatus = block.statusCode();
            if (httpStatus.value() == 200) {
                res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
            }
            logger.info("Convenience Fee Api  Response : {}",res);
        } catch (Exception e) {
            logger.trace("ConvenienceFee Api Issue : " + e.getMessage());
        }
        return res;
    }



    public String getConvenienceFeeDB(ApiTxnModel apiTxnModel, String url) {
        logger.info("Convenience Fee from db Request URL : {} , Body : {} ",url,new JSONObject(apiTxnModel).toString());
        String res = null;
        try {
            SslContext sslContext = null;
            try {
                sslContext = SslContextBuilder.forClient()
                        .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
            } catch (SSLException e) {
                e.printStackTrace();
            }
            SslContext finalSslContext = sslContext;
            HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
            WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
            ClientResponse block = webClient.clientConnector(new ReactorClientHttpConnector(httpClient)).build().post().uri(url).body(Mono.just(apiTxnModel),
                            ApiTxnModel.class).exchange()
                    .block(Duration.ofSeconds(20));

            HttpStatus httpStatus = block.statusCode();
            if (httpStatus.value() == 200) {
                res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
            }
            logger.info("Convenience Fee from db  Response : {}",res);
        } catch (Exception e) {
            logger.trace("ConvenienceFee from db Issue : " + e.getMessage());
        }
        return res;
    }


    private String getConvenienceAccessToken() {
        String res = null;
        Map<String, Object> nodemap = new HashMap<>();
        nodemap.put("clientId", initProps.getClientId());
        nodemap.put("clientSecret", initProps.getClientSecret());
        nodemap.put("requestorId", initProps.getRequestorId());
        nodemap.put("inputterId", initProps.getInputterId());
        nodemap.put("approverId", initProps.getApproverId());
        nodemap.put("ticketId", initProps.getTicketId());
        nodemap.put("ipAddress", getConvenienceIpAddress());
        nodemap.put("requestDateTime", getConvenienceRrequestDateTime());
        try {
            SslContext sslContext = null;
            try {
                sslContext = SslContextBuilder.forClient()
                        .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
            } catch (SSLException e) {
                e.printStackTrace();
            }
            SslContext finalSslContext = sslContext;
            HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
            WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
            ClientResponse block = webClient.clientConnector(new ReactorClientHttpConnector(httpClient)).build().post().uri(getConvenienceFeeAccessTokenApi).headers(httpHeaders -> {
                        httpHeaders.addAll(getConvenienceHttpHeaders());
                    }).body(BodyInserters.fromValue(nodemap)).exchange()
                    .block(Duration.ofSeconds(20));

            HttpStatus httpStatus = block.statusCode();
            if (httpStatus.value() == 200) {
                res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
                res = getConvFeeResponse(res, getConvenienceFeeAccessTokenApi);
            }
        } catch (Exception e) {
            logger.trace("ConvenienceFee access token api issue : " + e.getMessage());
        }
        return res;
    }

    private String getConvenienceRrequestDateTime() {
        LocalDate date = LocalDate.now();
        return date.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
    }

    private HttpHeaders getConvenienceHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add("clientId", initProps.getClientId());
        headers.add("clientSecret", initProps.getClientSecret());
        headers.add("requestorId", initProps.getRequestorId());
        headers.add("inputterId", initProps.getInputterId());
        headers.add("approverId", initProps.getApproverId());
        headers.add("ticketId", initProps.getTicketId());
        headers.add("ipAddress", getConvenienceIpAddress());
        headers.add("requestDateTime", getConvenienceRrequestDateTime());
        return headers;
    }

    private String getConvenienceIpAddress() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isLoopback() || !iface.isUp() || iface.isVirtual() || iface.isPointToPoint())
                    continue;
                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress addr = addresses.nextElement();
                    final String ip = addr.getHostAddress();
                    if (Inet4Address.class == addr.getClass()) return ip;
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getConvFeeResponse(String conFeeDetailsRes, String uri) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonNode = null;
        String res = null;
        try {
            String[] split = conFeeDetailsRes.split("##");
            String httpStatus = split[0];
            String httpResponse = split[1];
            if (httpStatus.equals("200")) {
                jsonNode = mapper.readTree(httpResponse);
                if (uri.equals(checkConvenienceFeeApi)) {
                    res = jsonNode.get("data").get("Status").asText();
                    if (res.equalsIgnoreCase("NO")) {
                        return "N";
                    }
                    if (res.equalsIgnoreCase("YES")) {
                        return "Y";
                    }
                }
                if (uri.equals(getDetailsConvenienceFeeApi)) {
                    res = jsonNode.get("data").get("ConvenienceFee").toString();
                    return res;
                }
                if (uri.equals(getConvenienceFeeAccessTokenApi)) {
                    res = jsonNode.get("token").asText();
                    return res;
                }
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return res;
    }

    public String generatePaymentLinkEnc(Exchange exchange) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("GeneratePaymentLinkEnc Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = generatePaymentLink(exchange, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);

    }

    public String generatePaymentLink(Exchange exchange) {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("GeneratePaymentLink Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return generatePaymentLink(exchange, apiTxnModel);
    }

    public String generatePaymentLink(Exchange exchange, List<PaymentLinkRequestModel> linkRequestModelList) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        for (PaymentLinkRequestModel model : linkRequestModelList) {
            ApiTxnModel apiTxnModel = model.toApiTxnModel();
            apiTxnModel.setEntityId(routingContext.getEntityId());
            apiTxnModel.setMid((String) exchange.getIn().getHeaders().get("mid"));
            apiTxnModel.setTid((String) exchange.getIn().getHeaders().get("tid"));
            apiTxnModel.setNoOfFileRecord(String.valueOf(linkRequestModelList.size()));
            logger.trace("GeneratePaymentLink Response : {}", generatePaymentLink(exchange, apiTxnModel));
        }
        PaymentLinksModel model = new PaymentLinksModel();
        model.setRefNo(linkRequestModelList.get(0).getRefNo());
        model.setFileName(linkRequestModelList.get(0).getFileName());
        model.setStaticFileName(linkRequestModelList.get(0).getStaticFileName());
        model.setStatus(PaymentStatus.SUCCESS);
        processorHelper.logPaymentLinksModelToTlm(model);
        Map<String, String> resMap = new HashMap<>();
        resMap.put("refNo", linkRequestModelList.get(0).getRefNo());
        return apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "File Received Successfully", resMap);
    }

    public String generatePaymentLink(Exchange exchange, ApiTxnModel apiTxnModel) {
        String apiResponse;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
        OffsetDateTime currentDateTime = OffsetDateTime.now();
        Map<String, Object> resMap = new HashMap<>();
        PaymentLinksModel paymentLinksModel = apiTxnModel.toPaymentLinkModel();
        String validatePaymentLinkJson = apiTransactionProcessor.validateMerchantKitJson(paymentLinksModel, CacheSrConfigProperties.getProperty("smartroute.payment.link.validation"));
        if(!StringUtils.isBlank(validatePaymentLinkJson)){
            ResponseObj responseObj = new ResponseObj();
            responseObj.setStatusCode("01");
            responseObj.setMsg(validatePaymentLinkJson);
            resMap.put("responseObj", responseObj);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR,"Invalid Data", resMap);
            return apiResponse;
        }
        MerchantMasterModel merchantMasterModel;
        try {
            merchantMasterModel = processorHelper.validateMerchantMaster(paymentLinksModel.getEntityId(), paymentLinksModel.getMid());
            logger.info("Merchant present in merchant master");
        }catch (Exception e){
            ResponseObj responseObj = new ResponseObj();
            responseObj.setStatusCode("01");
            responseObj.setMsg(e.getMessage());
            resMap.put("responseObj", responseObj);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR,"Invalid Merchant", resMap);
            return apiResponse;
        }
        paymentLinksModel.setStatus(PaymentStatus.EXPIRED);
        PaymentLinksModel originalLinksModel = (PaymentLinksModel) fetchPaymentLinksModel(paymentLinksModel, "validate.payment.link.tlm.api", false);
        if (originalLinksModel == null || originalLinksModel.getStatus() == PaymentStatus.EXPIRED) {
            String paymentLinkId = processorHelper.generatePaymentLinkId();
            String hashedValue = processorHelper.getHashedValue(paymentLinkId);
            paymentLinksModel.setPaymentLinkId(paymentLinkId);
            paymentLinksModel.setLinkHashId(hashedValue);
            paymentLinksModel.setStatus(PaymentStatus.PENDING);
            paymentLinksModel.setStatusDate(currentDateTime);
            String entityId = apiTxnModel.getEntityId();
            String paymentLink = paymentLinkHashIdUrl + "?link_hash_id=" + hashedValue + "&BankId=" + entityId;
            if ("Y".equalsIgnoreCase(MTMProperties.getProperty("smartroute.paymentLink.shotrner.url.enable"))) {
                try {
                    //Fetching Shortner url
                    String shortnerId = fetchPaymentLinkUrlShortnerApi(paymentLink, MTMProperties.getProperty("smartroute.paymentLink.create.shortner.url"));
                    if (StringUtils.isBlank(shortnerId)) {
                        ResponseObj responseObj = new ResponseObj();
                        responseObj.setStatusCode("01");
                        responseObj.setMsg("Exception While Calling Url Shortner Api : ");
                        resMap.put("responseObj", responseObj);
                        return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, null, resMap);
                    } else {
                        paymentLinksModel.setShortnerId(shortnerId);
                        paymentLink = MTMProperties.getProperty("smartroute.paymentLink.retrive.shotrner.url") + shortnerId;
                    }
                } catch (Exception e) {
                    ResponseObj responseObj = new ResponseObj();
                    responseObj.setStatusCode("01");
                    responseObj.setMsg("Exception While Calling Url Shortner Api : ");
                    resMap.put("responseObj", responseObj);
                    return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, null, resMap);
                }
            }
            processorHelper.logPaymentLinksModelToTlm(paymentLinksModel);
            resMap.put("paymentLink", paymentLink);
            resMap.put("orderId", paymentLinksModel.getOrderId());
            resMap.put("linkHashId", paymentLinkId);
            String customerMobNo = paymentLinksModel.getMobileNo();
            String customerEmail = paymentLinksModel.getEmailId();
//            MerchantMasterModel merchantMasterModel = processorHelper.validateMerchantMaster(entityId, paymentLinksModel.getMid());
            DataElements dataElements = new DataElements();
            if (!StringUtils.isBlank(apiTxnModel.getTxnAmt())) {
                dataElements.setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(apiTxnModel.getTxnAmt()));
            }
            dataElements.setPaymentLink(paymentLink);
            String merchantName = merchantMasterModel.getMerchantName();
            dataElements.setMerchantName(!StringUtils.isBlank(merchantName) ? (merchantName.length() >=30 ? merchantName.substring(0,30) :merchantName) : "");
            dataElements.setPaymentId(paymentLinkId + " - " + paymentLink);
            dataElements.setTransactionDate(formatter.format(currentDateTime));
            dataElements.setLinkExpiryDate(paymentLinksModel.getLinkExpiryDate() != null
                    ? formatter.format(paymentLinksModel.getLinkExpiryDate()) : null);
            try {
                if (!StringUtils.isBlank(paymentLinksModel.getFileName()) && !paymentLinksModel.getFileName().startsWith("Error")) {
                    if (!StringUtils.isBlank(customerMobNo)) {
                        processorHelper.sendNotificationMail(entityId, customerMobNo, null, dataElements);
                    }
                    if (!StringUtils.isBlank(customerEmail)) {
                        processorHelper.sendNotificationMail(entityId, null, customerEmail, dataElements);
                    }
                } else if (StringUtils.isBlank(paymentLinksModel.getFileName())) {
                    if (!StringUtils.isBlank(customerMobNo)) {
                        processorHelper.sendNotificationMail(entityId, customerMobNo, null, dataElements);
                    }
                    if (!StringUtils.isBlank(customerEmail)) {
                        processorHelper.sendNotificationMail(entityId, null, customerEmail, dataElements);
                    }
                }
            } catch (Exception e) {
                ResponseObj responseObj = new ResponseObj();
                responseObj.setStatusCode("01");
                responseObj.setMsg("Exception While Sending Notification : ");
                resMap.put("responseObj", responseObj);
            }
        } else {
            ResponseObj responseObj = new ResponseObj();
            responseObj.setStatusCode("01");
            responseObj.setMsg("PaymentLink already generated for this OrderId : " + originalLinksModel.getOrderId());
            resMap.put("responseObj", responseObj);
        }
        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Payment Link Generated Successfully.", resMap);
        return apiResponse;
    }

    public String generateMerchantPaymentLink(Exchange exchange) {

        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("GeneratePaymentLink Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        String paymentLink;
        String apiResponse;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
        OffsetDateTime currentDateTime = OffsetDateTime.now();
        Map<String, Object> resMap = new HashMap<>();
        PaymentLinksModel paymentLinksModelReq = apiTxnModel.toPaymentLinkModel();
        Map<String, Object> resDataMap = new HashMap<>();
        PaymentLinksModel paymentLinksModelRes = new PaymentLinksModel();
        String validatePaymentLinkJson = apiTransactionProcessor.validateMerchantKitJson(paymentLinksModelReq, CacheSrConfigProperties.getProperty("smartroute.payment.link.validation"));
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(paymentLinksModelReq.getEntityId(), paymentLinksModelReq.getMid());
        JSONObject jsonObject = new JSONObject(apiRequest);
        String secureHash = apiTransactionProcessor.generateMerchantSecureHash(jsonObject, merchantMaster.getSecretKey());
        if(!StringUtils.isBlank(validatePaymentLinkJson)){
            paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
            paymentLinksModelRes.setMessage(validatePaymentLinkJson);
            paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
            paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
            apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
            return apiResponse;
        }
        if (!secureHash.equalsIgnoreCase(paymentLinksModelReq.getSecureHash().toLowerCase())) {
            paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
            paymentLinksModelRes.setMessage("Invalid Secure Hash");
            paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
            paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
            apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
            return apiResponse;
        }

        paymentLinksModelReq.setStatus(PaymentStatus.EXPIRED);
        PaymentLinksModel originalLinksModel = (PaymentLinksModel) fetchPaymentLinksModel(paymentLinksModelReq, "validate.payment.link.tlm.api", false);
        if (originalLinksModel == null || originalLinksModel.getStatus() == PaymentStatus.EXPIRED) {
            String paymentLinkId = processorHelper.generatePaymentLinkId();
            String hashedValue = processorHelper.getHashedValue(paymentLinkId);
            paymentLinksModelReq.setPaymentLinkId(paymentLinkId);
            paymentLinksModelReq.setLinkHashId(hashedValue);
            paymentLinksModelReq.setStatus(PaymentStatus.PENDING);
            paymentLinksModelReq.setStatusDate(currentDateTime);
            String entityId = apiTxnModel.getEntityId();
            paymentLink = paymentLinkHashIdUrl + "?link_hash_id=" + hashedValue + "&BankId=" + entityId;
            if ("Y".equalsIgnoreCase(MTMProperties.getProperty("smartroute.paymentLink.shotrner.url.enable"))) {
                try {
                    //Fetching Shortner url
                    String shortnerId = fetchPaymentLinkUrlShortnerApi(paymentLink, MTMProperties.getProperty("smartroute.paymentLink.create.shortner.url"));
                    if (StringUtils.isBlank(shortnerId)) {
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        paymentLinksModelRes.setMessage("Exception While Calling Url Shortner Api : ");
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;

                    } else {
                        paymentLinksModelReq.setShortnerId(shortnerId);
                        paymentLink = MTMProperties.getProperty("smartroute.paymentLink.retrive.shotrner.url") + shortnerId;
                    }
                } catch (Exception e) {
                    paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                    paymentLinksModelRes.setMessage("Exception While Calling Url Shortner Api : ");
                    paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                    paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                    apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                    return apiResponse;
                }
            }
            processorHelper.logPaymentLinksModelToTlm(paymentLinksModelReq);
            String customerMobNo = paymentLinksModelReq.getMobileNo();
            String customerEmail = paymentLinksModelReq.getEmailId();
//            MerchantMasterModel merchantMasterModel = processorHelper.validateMerchantMaster(entityId, paymentLinksModel.getMid());
            DataElements dataElements = new DataElements();
            if (!StringUtils.isBlank(apiTxnModel.getTxnAmt())) {
                dataElements.setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(apiTxnModel.getTxnAmt()));
            }
            dataElements.setPaymentLink(paymentLink);
            String merchantName = merchantMaster.getMerchantName();
            dataElements.setMerchantName(!StringUtils.isBlank(merchantName) ? (merchantName.length() >=30 ? merchantName.substring(0,30) :merchantName) : "");
            dataElements.setPaymentId(paymentLinkId + " - " + paymentLink);
            dataElements.setTransactionDate(formatter.format(currentDateTime));
            dataElements.setLinkExpiryDate(paymentLinksModelReq.getLinkExpiryDate() != null
                    ? formatter.format(paymentLinksModelReq.getLinkExpiryDate()) : null);


            try {
                if (!StringUtils.isBlank(paymentLinksModelReq.getFileName()) && !paymentLinksModelReq.getFileName().startsWith("Error")) {
                    if (!StringUtils.isBlank(customerMobNo)) {
                        processorHelper.sendNotificationMail(entityId, customerMobNo, null, dataElements);
                    }
                    if (!StringUtils.isBlank(customerEmail)) {
                        processorHelper.sendNotificationMail(entityId, null, customerEmail, dataElements);
                    }
                } else if (StringUtils.isBlank(paymentLinksModelReq.getFileName())) {

                    if(
                            StringUtils.equals("Y", paymentLinksModelReq.getEmailEnabled()) &&
                                    !StringUtils.isBlank(customerEmail) &&
                                    StringUtils.equals("Y", paymentLinksModelReq.getSmsEnabled()) &&
                                    !StringUtils.isBlank(customerMobNo)
                    )
                    {
                        processorHelper.sendNotificationMail(entityId, customerMobNo, customerEmail, dataElements);
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        paymentLinksModelRes.setPaymentLink(paymentLink);
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.SUCCESS));
                        paymentLinksModelRes.setMessage("PaymentLink Generated Successfully");
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;
                    } else if (StringUtils.equals("Y", paymentLinksModelReq.getEmailEnabled()) && !StringUtils.isBlank(customerEmail)){
                        processorHelper.sendNotificationMail(entityId, null, customerEmail, dataElements);
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        paymentLinksModelRes.setPaymentLink(paymentLink);
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.SUCCESS));
                        paymentLinksModelRes.setMessage("PaymentLink Generated Successfully");
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;
                    } else if (StringUtils.equals("Y", paymentLinksModelReq.getSmsEnabled()) && !StringUtils.isBlank(customerMobNo)){
                        processorHelper.sendNotificationMail(entityId, customerMobNo , null , dataElements);
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        paymentLinksModelRes.setPaymentLink(paymentLink);
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.SUCCESS));
                        paymentLinksModelRes.setMessage("PaymentLink Generated Successfully");
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;
                    } else if (
                            StringUtils.equals("Y", paymentLinksModelReq.getEmailEnabled()) &&
                                    StringUtils.isBlank(customerEmail) &&
                                    StringUtils.equals("Y", paymentLinksModelReq.getSmsEnabled()) &&
                                    StringUtils.isBlank(customerMobNo)
                    ){
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        //paymentLinksModelRes.setPaymentLink(paymentLink);
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                        paymentLinksModelRes.setMessage("Since emailEnabled is 'Y', and since smsEnabled is 'Y' emailId field required ERROR CODE :: IS001 and customerMobNo field also required. ERROR CODE :: IS002");
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;
                    } else if (StringUtils.equals("Y", paymentLinksModelReq.getEmailEnabled()) && StringUtils.isBlank(customerEmail)){
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        //paymentLinksModelRes.setPaymentLink(paymentLink);
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                        paymentLinksModelRes.setMessage("Since emailEnabled is 'Y', emailId field required. ERROR CODE :: IS001");
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;
                    } else if (StringUtils.equals("Y", paymentLinksModelReq.getSmsEnabled()) && StringUtils.isBlank(customerMobNo)){
                        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                        //paymentLinksModelRes.setPaymentLink(paymentLink);
                        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                        paymentLinksModelRes.setMessage("Since smsEnabled is 'Y', customerMobNo field required. ERROR CODE :: IS002");
                        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                        return apiResponse;
                    }

                    //paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                    //paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                    //paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                    //apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                    //return apiResponse;

                    //paymentLinksModelRes.setMessage("PaymentLink Generated Successfully");


                    //if(!StringUtils.isBlank(paymentLinksModelReq.getEmailEnabled()) &&
                    //        StringUtils.equals("Y", paymentLinksModelReq.getEmailEnabled()) && !StringUtils.isBlank(customerEmail)){
                    //    //send email
                    //    processorHelper.sendNotificationMail(entityId, null, customerEmail, dataElements);
                    //}else if(StringUtils.equals("Y", paymentLinksModelReq.getEmailEnabled()) && StringUtils.isBlank(customerEmail) ){
                    //    // since Y provide customerEmail
                    //    paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                    //    paymentLinksModelRes.setMessage("Since emailEnabled is 'Y', emailId field required. ERROR CODE :: IS001");
                    //    paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                    //    paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                    //    apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                    //    return apiResponse;
                    //}


                    //if(!StringUtils.isBlank(paymentLinksModelReq.getSmsEnabled()) &&
                    //        StringUtils.equals("Y", paymentLinksModelReq.getSmsEnabled()) && !StringUtils.isBlank(customerMobNo)){
                    //    //send sms
                    //    processorHelper.sendNotificationMail(entityId, customerMobNo, null, dataElements);
                    //}else if(StringUtils.equals("Y", paymentLinksModelReq.getSmsEnabled()) && StringUtils.isBlank(customerMobNo)) {
                    //    // since Y provide customerMobile
                    //    paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
                    //    paymentLinksModelRes.setMessage("Since smsEnabled is 'Y', customerMobNo field required. ERROR CODE :: IS002");
                    //    paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                    //    paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
                    //    apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
                    //    return apiResponse;
                    //}
                }
            } catch (Exception e) {
                ResponseObj responseObj = new ResponseObj();
                responseObj.setStatusCode("01");
                responseObj.setMsg("Exception While Sending Notification : ");

                logger.info("Exception While Sending Notification : ");
                resMap.put("responseObj", responseObj);

                //refundDataRes.setMessage("Exception While Sending Notification : ");
                //refundDataRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
                //refundDataRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                //apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                //return apiResponse;
            }
        } else {
            paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
            paymentLinksModelRes.setMessage("PaymentLink already generated for this OrderId : " + originalLinksModel.getOrderId());
            paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.ERROR));
            paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
            apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
            return apiResponse;
        }
        paymentLinksModelRes = paymentLinksModelRes.getMerchantPaymentLinksDataRes(paymentLinksModelReq);
        paymentLinksModelRes.setPaymentLink(paymentLink);
        //paymentLinksModelRes.setMessage("PaymentLink Generated Successfully");
        paymentLinksModelRes.setMessage("PaymentLink Generated Successfully");
        paymentLinksModelRes.setResponseCode(ResponseMsgType.getTwoDigitOrdinal(ResponseMsgType.SUCCESS));
        paymentLinksModelRes = apiTransactionProcessor.getMerchantPaymentLinkResWithSecureHash(paymentLinksModelRes, merchantMaster.getSecretKey());
        apiResponse = IsgJsonUtils.getJsonString(paymentLinksModelRes);
        return apiResponse;
    }

    public String fetchPaymentLinkUrlShortnerApi(String data, String apiUrl) {
        //https://geniuscrm.insolutionsglobal.com:8010/short/shortURL
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.TEXT_PLAIN));
        logger.trace("Fetching Url Shortner Api: {}", apiUrl);
        try {
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            HttpEntity<String> request = new HttpEntity<>(data, headers);
            ResponseEntity<String> exchange = restTemplate.exchange(apiUrl, HttpMethod.POST, request,
                    String.class);
            if (exchange.getStatusCode() == HttpStatus.OK && exchange.getBody() != null) {
                logger.trace(" Url Shortner API Response: {}", exchange.getBody());
                return exchange.getBody();
            } else {
                return null;
            }
        } catch (RuntimeException e) {
            logger.error(" Failed to fetch Url Shortner Api " + e);
        }
        return null;
    }

    public String getPaymentLinkDetailsEnc(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1) throws JsonProcessingException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("GetPaymentLinkDetailsEnc Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = getPaymentLinkDetails(exchange, routingContext, sourceConfigModel1, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String getPaymentLinkDetails(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1) throws JsonProcessingException {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("GetPaymentLinkDetails Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return getPaymentLinkDetails(exchange, routingContext, sourceConfigModel1, apiTxnModel);
    }

    public String getPaymentLinkDetails(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1, ApiTxnModel apiTxnModel) throws JsonProcessingException {
        String apiResponse;
        Map<String, Object> resMap = new HashMap<>();
        PaymentLinksModel paymentLinksModel = apiTxnModel.toPaymentLinkModel();
        //How to call MerchantEncReqRes
        PaymentLinksModel originalLinksModel = (PaymentLinksModel) fetchPaymentLinksModel(paymentLinksModel, "get.payment.link.tlm.api", false);
        if (originalLinksModel != null && originalLinksModel.getLinkExpiryDate().isBefore(apiTransactionProcessor.trimGmtDate(OffsetDateTime.now().toString()))) {
            originalLinksModel.setStatus(PaymentStatus.EXPIRED);
        }
        if (originalLinksModel != null && (originalLinksModel.getStatus() == PaymentStatus.PENDING || originalLinksModel.getStatus() == PaymentStatus.INITIATED || originalLinksModel.getStatus() == PaymentStatus.FAILED)) {
            ObjectMapper mapper = new ObjectMapper();
            String jsonString = IsgJsonUtils.getJsonStringWithTimeStampValue(originalLinksModel);
            Map<String, Object> nodeMap = mapper.readValue(jsonString, new TypeReference<Map<String, Object>>() {
            });
            nodeMap.put("MerchantId", originalLinksModel.getMid());
            nodeMap.put("TerminalId", originalLinksModel.getTid());
            nodeMap.put("BankId", originalLinksModel.getEntityId());
            nodeMap.put("merchantTxnRefNo", originalLinksModel.getOrderId());
            nodeMap.put("txnAmt", originalLinksModel.getAmount());
            nodeMap.put("customerEmail", originalLinksModel.getEmailId());
            nodeMap.put("customerMobNo", originalLinksModel.getMobileNo());
            exchange.getIn().setBody(mapper.writeValueAsString(nodeMap));
            apiResponse = validateAndGetPaymentData(exchange, routingContext, sourceConfigModel1);
        } else {
            ResponseObj responseObj = new ResponseObj();
            responseObj.setStatusCode("01");
            if (originalLinksModel != null) {
                switch (originalLinksModel.getStatus()) {
                    case EXPIRED:
                        processorHelper.logPaymentLinksModelToTlm(originalLinksModel);
                        responseObj.setMsg("PaymentLink expired for this OrderId : " + originalLinksModel.getOrderId());
                        break;
                    case SUCCESS:
                        responseObj.setMsg("Transaction for using paymentLink is already succeed with OrderId : " + originalLinksModel.getOrderId());
                        break;
                }
            } else {
                responseObj.setMsg("Payment Link Model Not Found : ");
            }
            resMap.put("responseObj", responseObj);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, null, resMap);
        }
        return apiResponse;
    }

    public Object fetchPaymentLinksModel(PaymentLinksModel paymentLinksModel, String apiUrl, boolean isFilePresent) {



        logger.info("Fetching payment links model : ");
        String JWT_KEY = "";
        String USER_NAME_HEADER = "";
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
        logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        String url = MTMProperties.getProperty(apiUrl);
        logger.trace("Fetch existing transaction: {}", url);
        if (isFilePresent) {
            return callTlmApiForFileDetails(url, headers, paymentLinksModel);
        }
        return callTlmApi(url, headers, paymentLinksModel);
    }

    private PaymentFileDetailsModel callTlmApiForFileDetails(String url, HttpHeaders headers, PaymentLinksModel paymentLinksModel) {
        PaymentFileDetailsModel fileDetailsModel = null;
        try {
            logger.error("Payment link details for file configuration with Url :{} ,Headers :{} and Body :{} ",url,headers,paymentLinksModel);
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            ResponseEntity<PaymentFileDetailsModel[]> exchange = restTemplate.exchange(url + "?mid=" + paymentLinksModel.getMid() +
                            "&refNoOrFileName=" + paymentLinksModel.getFileName() + "&isNoOfFilesRequired=N", HttpMethod.GET, new HttpEntity<>(headers),
                    PaymentFileDetailsModel[].class);
            if (exchange.getBody() != null) {
                List<PaymentFileDetailsModel> paymentFileDetailsModels = Arrays.asList(exchange.getBody());
                logger.trace("PaymentLinksModel API Response: {}", paymentFileDetailsModels.get(0));
                return paymentFileDetailsModels.get(0);
            }
        } catch (RuntimeException e) {
            logger.error(" Failed to fetch payment links model " + e);
        }
        return fileDetailsModel;
    }

    private PaymentLinksModel callTlmApi(String url, HttpHeaders headers,
                                         PaymentLinksModel paymentLinksModel) {
        PaymentLinksModel model = null;
        try {
            logger.error("Payment link details with Url :{} ,Headers :{} and Body :{} ",url,headers,paymentLinksModel);
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            HttpEntity<PaymentLinksModel> request = new HttpEntity<>(paymentLinksModel, headers);
            ResponseEntity<PaymentLinksModel> exchange = restTemplate.exchange(url,
                    HttpMethod.POST, request, PaymentLinksModel.class);
            model = exchange.getBody();
            logger.trace("PaymentLinksModel API Response: {}", model);
        } catch (RuntimeException e) {
            logger.error(" Failed to fetch payment links model " + e);
        }
        return model;
    }

    public TransactionMessageModel getTmmByTransactionId(String txnId) {
        String url = MTMProperties.getProperty("check.tmm.exist.by.transactionId") + "?transactionId=" + txnId;

        logger.info("Calling Tlm Api To Get Tmm By TransactionId : {} " , url);
        TransactionMessageModel tmm = null;
        try {
            String JWT_KEY = "";
            String USER_NAME_HEADER = "";
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
            logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            ResponseEntity<TransactionMessageModel> exchange = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(headers),
                    TransactionMessageModel.class);
            tmm = exchange.getBody();
            logger.trace("TransactionMessageModel is preesent: {}", tmm);
        } catch (RuntimeException e) {
            logger.error(" Failed to fetch TransactionMessageModel model " + e);
        }
        return tmm;
    }

    public Object getTmmByTxnRefNo(String txnRefNo, String txnType, String resCode,String mid,String tid) {
        String url = null;
        Object responseObj = null;
        if (!StringUtils.isBlank(resCode) && StringUtils.isBlank(txnType)) {
            url = MTMProperties.getProperty("check.tmm.exist.by.txnrefno") + "?merchantTxnRefNo=" + txnRefNo + "&resCode=" + resCode + "&mid=" + mid + "&tid=" + tid;
        }else if (!StringUtils.isBlank(txnType) && StringUtils.isBlank(resCode))  {
            url = MTMProperties.getProperty("check.tmm.exist.by.txnrefno") + "?merchantTxnRefNo=" + txnRefNo + "&txnType=" + txnType + "&mid=" + mid + "&tid=" + tid;
        }else if(StringUtils.isBlank(txnType) && StringUtils.isBlank(resCode)){
            url = MTMProperties.getProperty("check.tmm.exist.by.txnrefno") + "?merchantTxnRefNo=" + txnRefNo + "&mid=" + mid + "&tid=" + tid;
        }

        try {
            String JWT_KEY = "";
            String USER_NAME_HEADER = "";
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
            logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            ResponseEntity<Object> exchange = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(headers),
                    Object.class);
            responseObj = exchange.getBody();
            logger.trace("TransactionMessageModel is preesent: {}", responseObj);
        } catch (RuntimeException e) {
            logger.error(" Failed to fetch TransactionMessageModel model " + e);
        }
        return responseObj;
    }

    public List<PaymentLinkRequestModel> uploadExcelFile(Exchange exchange) throws IOException, MessagingException {
        List<PaymentLinkRequestModel> paymentLinkRequestModels = new ArrayList<>();
        MimeBodyPart mimeBodyPart = getDataHandlerForMultipart(exchange);
        String fileName = mimeBodyPart.getFileName();
        if (StringUtils.isBlank(fileName)) {
            throw new FileNotFoundException();
        }
        //validate api call
        validateFileDetails(exchange, fileName);
        DataHandler dataHandler = mimeBodyPart.getDataHandler();
        InputStream stream = dataHandler.getInputStream();
        Workbook workbook = new XSSFWorkbook(stream);
        Sheet sheet = workbook.getSheetAt(0); // Assuming the first sheet is the desired one
        List<List<Object>> rows = new ArrayList<>();
        Iterator<Row> rowIterator = sheet.iterator();
        //check and validate header
        List<String> headers = extractedHeaderData(rowIterator);
        //Read data Value
        paymentLinkRequestModels = extractedRowData(rowIterator, fileName);
        workbook.close();

        return paymentLinkRequestModels;
    }

    private void validateFileDetails(Exchange exchange, String fileName) {
        PaymentLinksModel paymentLinksModel = new PaymentLinksModel();
        String mid = (String) exchange.getIn().getHeaders().get("mid");
        paymentLinksModel.setMid(mid);
        paymentLinksModel.setFileName(fileName);
        PaymentFileDetailsModel fileDetailsModel = (PaymentFileDetailsModel) fetchPaymentLinksModel(paymentLinksModel, "validate.file.details.tlm.api", true);
        if (fileDetailsModel != null) {
            if (paymentLinksModel.getFileName().equalsIgnoreCase(fileDetailsModel.getFileName())
                    && paymentLinksModel.getMid().equalsIgnoreCase(fileDetailsModel.getMid())) {
                throw new FileDetailsMissMatch("File Already Exist For Mid : {}" + fileDetailsModel.getMid());
            }
        }
    }

    public MimeBodyPart getDataHandlerForMultipart(Exchange exchange) throws IOException, MessagingException {
        // Get the parts from the MIME multipart data
        InputStream inputStream = exchange.getIn().getBody(InputStream.class);
        MimeBodyPart mimeBodyPart = new MimeBodyPart(inputStream);
        return mimeBodyPart;
    }

    private static String generateRandomForFile() {
        String format = String.format("%012d", new BigInteger(UUID.randomUUID().toString().replace("-", ""), 16));
        format = format.substring(format.length() - 12);
        return format;
    }

    private static List<PaymentLinkRequestModel> extractedRowData(Iterator<Row> rowIterator, String fileName) {
        List<PaymentLinkRequestModel> cells = new ArrayList<>();
        String refNo = generateRandomForFile();
        while (rowIterator.hasNext()) {
            int cellid = 0;
            PaymentLinkRequestModel requestModel = new PaymentLinkRequestModel();
            Row row = rowIterator.next();
            //requestModel.setEntityId(getStringValue(row.getCell(cellid++)));
            requestModel.setRemark(getStringValue(row.getCell(cellid++)));
            requestModel.setTxnAmt(getStringValue(row.getCell(cellid++)));
            requestModel.setMerchantTxnRefNo(getStringValue(row.getCell(cellid++)));
            requestModel.setCustomerMobNo(getStringValue(row.getCell(cellid++)));
            requestModel.setLinkExpiryDate(getStringValue(row.getCell(cellid++)));
            requestModel.setCustomerEmail(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf01(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf02(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf03(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf04(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf05(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf06(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf07(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf08(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf09(getStringValue(row.getCell(cellid++)));
            requestModel.setUdf10(getStringValue(row.getCell(cellid++)));
            requestModel.setFileName(fileName);
            requestModel.setStaticFileName(fileName);
            requestModel.setRefNo(refNo);
            validatePaymentLinkModel(requestModel);
            cells.add(requestModel);
        }
        return cells;
    }

    private static void validatePaymentLinkModel(PaymentLinkRequestModel requestModel) {
        String jsonSchema = "{\n" +
                "  \"$id\": \"http://example.com/example.json\",\n" +
                "  \"$schema\": \"http://json-schema.org/draft-07/schema\",\n" +
                "  \"default\": {},\n" +
                "  \"description\": \"The root schema comprises the entire JSON document.\",\n" +
                "  \"required\": [\n" +
                "    \"txnAmt\",\n" +
                "    \"merchantTxnRefNo\",\n" +
                "    \"customerMobNo\",\n" +
                "    \"customerEmail\"\n" +
                "  ],\n" +
                "  \"title\": \"Payment Link Request Model\",\n" +
                "  \"type\": \"object\",\n" +
                "  \"properties\": {\n" +
                "    \"remark\": {\n" +
                "      \"$id\": \"#/properties/remark\",\n" +
                "      \"title\": \"The remark schema\",\n" +
                "      \"pattern\": \"^[a-zA-Z0-9]*$\",\n" +
                "      \"type\": [\n" +
                "        \"string\",\n" +
                "        \"null\"\n" +
                "      ]\n" +
                "    },\n" +
                "    \"txnAmt\": {\n" +
                "      \"$id\": \"#/properties/txnAmt\",\n" +
                "      \"title\": \"The txnAmt schema\",\n" +
                "      \"pattern\": \"^[0-9]*$\",\n" +
                "      \"type\": [\n" +
                "        \"string\",\n" +
                "        \"null\"\n" +
                "      ]\n" +
                "    },\n" +
                "    \"merchantTxnRefNo\": {\n" +
                "      \"$id\": \"#/properties/merchantTxnRefNo\",\n" +
                "      \"title\": \"The merchantTxnRefNo schema\",\n" +
                "      \"pattern\": \"^[0-9]*$\",\n" +
                "      \"type\": [\n" +
                "        \"string\",\n" +
                "        \"null\"\n" +
                "      ]\n" +
                "    },\n" +
                "    \"customerMobNo\": {\n" +
                "      \"$id\": \"#/properties/customerMobNo\",\n" +
                "      \"title\": \"The customerMobNo schema\",\n" +
                "      \"pattern\": \"^(\\\\+\\\\d{1,3}( )?)?((\\\\(\\\\d{1,3}\\\\))|\\\\d{1,3})[- .]?\\\\d{3,4}[- .]?\\\\d{4}$\",\n" +
                "      \"type\": [\n" +
                "        \"string\",\n" +
                "        \"null\"\n" +
                "      ]\n" +
                "    },\n" +
                "    \"customerEmail\": {\n" +
                "      \"$id\": \"#/properties/customerEmail\",\n" +
                "      \"title\": \"The customerEmail schema\",\n" +
                "      \"pattern\": \"^(?=.{1,64}@)[A-Za-z0-9_-]+(\\\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\\\.[A-Za-z0-9-]+)*(\\\\.[A-Za-z]{2,})$\",\n" +
                "      \"type\": [\n" +
                "        \"string\",\n" +
                "        \"null\"\n" +
                "      ]\n" +
                "    },\n" +
                "    \"linkExpiryDate\": {\n" +
                "      \"$id\": \"#/properties/linkExpiryDate\",\n" +
                "      \"title\": \"The linkExpiryDate schema\",\n" +
                "      \"pattern\": \"\\\\d{4}\\\\-(0?[1-9]|1[012])\\\\-(0?[1-9]|[12][0-9]|3[01])*\",\n" +
                "      \"type\": [\n" +
                "        \"string\",\n" +
                "        \"null\"\n" +
                "      ]\n" +
                "    }\n" +
                "  },\n" +
                "  \"additionalProperties\": true\n" +
                "}";
        StringBuilder errorsCombined = new StringBuilder();
        ObjectMapper om = new ObjectMapper();
        InputStream schemaAsStream = new ByteArrayInputStream(jsonSchema.getBytes(StandardCharsets.UTF_8));
        JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7).getSchema(schemaAsStream);
        JsonNode jsonNode = om.convertValue(requestModel, JsonNode.class);
        Set<ValidationMessage> errors = schema.validate(jsonNode);
        for (ValidationMessage error : errors) {
            errorsCombined.append(error.toString()).append(System.lineSeparator());
        }
        if (!errors.isEmpty()) {
            requestModel.setFileName("Error:: Invalid Payment Link Data :" + System.lineSeparator() + errorsCombined);
        }
    }

    private static String getStringValue(Cell cell) {
        if (cell == null) {
            return null;
        }
        switch (cell.getCellType()) {
            case CELL_TYPE_STRING:
                return cell.getStringCellValue();
            case CELL_TYPE_NUMERIC:
                double cellValue = cell.getNumericCellValue();
                if (DateUtil.isCellDateFormatted(cell)) {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
                    return LocalDate.parse(cell.toString(), formatter).toString();
                }
                return new BigDecimal(cellValue).toString();
            case CELL_TYPE_BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case CELL_TYPE_BLANK:
                return null;
        }
        return null;
    }

    private static List<String> extractedHeaderData(Iterator<Row> rowIterator) {
        List<String> cells = new ArrayList<>();
        if (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                switch (cell.getCellType()) {
                    case CELL_TYPE_STRING:
                        cells.add(cell.getStringCellValue());
                        break;
                }
            }
        }
        return cells;
    }

    public String getPaymentModeDetails(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1) {
        String apiRequest = exchange.getIn().getBody(String.class);
        Map<String, Object> resDataMap = getPaymentModeDetailsMap(exchange, routingContext, sourceConfigModel1, apiRequest);
        String apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Success", resDataMap);
        return apiResponse;
    }

    public String getPaymentModeDetailsEnc(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        Map<String, Object> resDataMap = getPaymentModeDetailsMap(exchange, routingContext, sourceConfigModel1, apiRequest);
        String apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Success", resDataMap);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    private Map<String, Object> getPaymentModeDetailsMap(Exchange exchange, RoutingContext routingContext, SourceConfigModel sourceConfigModel1, String apiRequest) {
        //validate the merchant
        ApiTxnModel apiTxnModel = new ApiTxnModel();
        ResponseObj responseObj = new ResponseObj();
        ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
        ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantEncReqRes encReqObj = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantEncReqRes.class);
        String merchantId = encReqObj.getMerchantId();
        String terminalId = encReqObj.getTerminalId();
        String entityId = encReqObj.getBankId();
        logger.trace("Get Payment Mode Api Calling For Merchant : {} with Bank id : {}", merchantId, entityId);
        MapsInfoModel mapsInfoModel;
        MerchantMasterModel merchantMaster;
        try {
            mapsInfoModel = processorHelper.validateMerchant(entityId, merchantId, terminalId);
            merchantMaster = processorHelper.validateMerchantMaster(entityId, merchantId);
        }catch (Exception e){
            String message = e.getMessage();
            Map<String, Object> orderDetails = new HashMap<>();
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl("");
            orderDetails.put("orderDetails","");
            responseObj.setData(orderDetails);
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setStatusCode("01");
            responseObj.setMsg(message);
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }
        //will always be merchant SDK encrypted
//        MerchantEncDataRequest merchantEncDataRequest = null;
//        if (encReqObj.getEncData() != null) {
//            merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encReqObj.getEncData(),
//                    merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
//            if (merchantEncDataRequest == null) {
//                Map<String, Object> orderDetails = new HashMap<>();
//                responseObj.setStatusCode("01");
//                retryEvent.setRetryFlag("N");
//                redirectEvent.setTargetUrl("");
//                orderDetails.put("orderDetails","");
//                responseObj.setData(orderDetails);
//                responseObj.setRedirectEvent(redirectEvent);
//                responseObj.setRetryEvent(retryEvent);
//                responseObj.setMsg("Invalid Key and Salt For Given MID : " + encReqObj.getMerchantId() + " And TID : " + encReqObj.getTerminalId());
//                resDataMap.put("responseObj", responseObj);
//                return resDataMap;
//            }
//        }

        // get merchant preferred payment options
        List<UnifiedPaymentMode> unifiedPayModeAndOps = getMerchantPayModeAndOps(entityId, merchantMaster.getMid());
        if (unifiedPayModeAndOps.isEmpty()) {
            Map<String, Object> orderDetails = new HashMap<>();
            responseObj.setStatusCode("01");
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl("");
            orderDetails.put("orderDetails","");
            responseObj.setData(orderDetails);
            responseObj.setRedirectEvent(redirectEvent);
            responseObj.setRetryEvent(retryEvent);
            responseObj.setMsg("Payment Mode And It's Options Not Present For Given MID : " + encReqObj.getMerchantId() + " And TID : " + encReqObj.getTerminalId());
            resDataMap.put("responseObj", responseObj);
            return resDataMap;
        }
        resDataMap.put("paymentModes", unifiedPayModeAndOps.stream().sorted(Comparator.comparing(UnifiedPaymentMode :: getPayModeId)).collect(Collectors.toList()));
        return resDataMap;
    }


}