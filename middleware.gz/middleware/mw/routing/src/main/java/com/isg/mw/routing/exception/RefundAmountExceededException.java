package com.isg.mw.routing.exception;

public class RefundAmountExceededException  extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public RefundAmountExceededException(String errorMsg) {
        super(errorMsg);
    }

    public RefundAmountExceededException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}
