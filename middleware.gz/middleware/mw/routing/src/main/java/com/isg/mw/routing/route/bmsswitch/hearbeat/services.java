package com.isg.mw.routing.route.bmsswitch.hearbeat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
@NoArgsConstructor
public class services {

    public services(String ip, String port, String name) {
        this.ip = ip;
        this.port = port;
        this.name = name;
    }

    private String ip;
    private String port;
    private String name;

    @Override
    public String toString() {
        return "{ip='" + ip + "'" +", port='" + port + "'" +", name='" + name + "'" +"}";
    }
}
