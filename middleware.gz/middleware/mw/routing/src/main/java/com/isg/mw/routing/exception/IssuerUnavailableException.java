package com.isg.mw.routing.exception;

public class IssuerUnavailableException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IssuerUnavailableException(String errorMsg) {
		super(errorMsg);
	}

	public IssuerUnavailableException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}

}
