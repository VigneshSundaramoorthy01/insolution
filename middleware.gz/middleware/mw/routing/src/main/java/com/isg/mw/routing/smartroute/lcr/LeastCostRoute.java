package com.isg.mw.routing.smartroute.lcr;

import com.isg.mw.cache.mgmt.config.TargetLcrKey;
import com.isg.mw.cache.mgmt.config.TargetLcrValue;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.TargetInfo;
import com.isg.mw.core.model.sr.TargetKey;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.smartroute.AbstractSmartRoute;
import com.isg.mw.routing.util.RouteUtil;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.*;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_API_TXN_MODEL;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

@Component
public class LeastCostRoute extends AbstractSmartRoute {

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Autowired
    private CacheServices cacheService;

    @Override
    public TargetConfigModel getTxnTarget(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        ApiTxnModel apiTxnModel = (ApiTxnModel) exchange.getIn().getHeader(EXCHANGE_HEADER_API_TXN_MODEL);

        Map<TargetLcrKey, Set<TargetLcrValue>> targetLCRData = cacheUtil.getTargetLCRData(routingContext.getSource().getEntityId());

        String cardType = cacheService.getSchemeBin(apiTxnModel.getCardNo()).getCardCategory();
        TargetLcrKey targetLcrKey = new TargetLcrKey(Long.parseLong(apiTxnModel.getPayModeId()), Long.parseLong(apiTxnModel.getPayModeOptionId()),
                apiTxnModel.getMcc(), cardType);

        Set<TargetLcrValue> targetLcrValueList = targetLCRData.get(targetLcrKey);

        return getTargetConfigModel(routingContext, apiTxnModel, targetLcrValueList);
    }

    public TargetConfigModel getTargetConfigModel(RoutingContext routingContext, ApiTxnModel apiTxnModel, Set<TargetLcrValue> targetLcrValueList) {
        Map<Double, List<Long>> leastCostTargetMap = new HashMap<>();
        double txnAmt = Double.parseDouble(apiTxnModel.getTxnAmt());
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        for (TargetLcrValue targetLcrValue : targetLcrValueList) {
            // first check if the target payment option is in valid range
            if (RouteUtil.isDateInBetweenEndPoints(targetLcrValue.getStartDate(), targetLcrValue.getEndDate(), OffsetDateTime.now())) {
                // if price is fixed & price pct both are present then add both
                double cost = 0;
                if (txnAmt < 2000) {
                    cost = getCostForTxnAmt(targetLcrValue.getBelow2000PriceFixed(), targetLcrValue.getBelow2000PricePct(), cost, txnAmt);
                } else {
                    cost = getCostForTxnAmt(targetLcrValue.getPriceFixed(), targetLcrValue.getPricePct(), cost, txnAmt);
                }

                if (!leastCostTargetMap.isEmpty() && leastCostTargetMap.containsKey(cost)) {
                    leastCostTargetMap.get(cost).add(targetLcrValue.getTargetId());
                } else {
                    ArrayList<Long> targetId = new ArrayList<>();
                    targetId.add(targetLcrValue.getTargetId());
                    leastCostTargetMap.put(cost, targetId);
                }
            }
        }
        Optional<Double> first = leastCostTargetMap.keySet().stream().sorted().findFirst();
        if (first.isPresent()) {
            Double lowestCost = first.get();
            List<Long> lowestCostTargetIds = leastCostTargetMap.get(lowestCost);
            Optional<TargetConfigModel> targetConfigModel1 = null;
            int srcTotalTxnCount = cacheUtil.getSourceTotalTxnCount(cacheHelper.getSourceMapKey(sourceConfigModel),
                    sourceConfigModel.getId().toString());
            Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
            for (Long lowestCostTargetId : lowestCostTargetIds) {
                TargetInfo targetInfo = targets.get(new TargetKey(lowestCostTargetId.toString()));
                Double computedRoutingPercent = ((double) targetInfo.getTotalTxnCount() / (double) srcTotalTxnCount) * 100;
                double currentRoutingPercent = (double) 100 / (double) lowestCostTargetIds.size();
                boolean isTargetEligible = computedRoutingPercent.compareTo(currentRoutingPercent) <= 0;
                if (isTargetEligible && targetInfo.isAlive()) {
                    targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getId().equals(lowestCostTargetId)).findFirst();
                }
                if (targetConfigModel1 != null && targetConfigModel1.isPresent()){break;}
            }
            return targetConfigModel1.get();
        }
        return null;
    }

    private static double getCostForTxnAmt(Double priceFixed, Double pricePct, double cost, double txnAmt) {
        if (priceFixed != null && priceFixed != 0) {
            cost = priceFixed;
        }
        if (pricePct != null && pricePct != 0) {
            cost = ((txnAmt * pricePct) / 100);
        }
        if (priceFixed != null && priceFixed != 0 && pricePct != null && pricePct != 0) {
            cost = ((txnAmt * pricePct) / 100) + priceFixed;
        }
        return cost;
    }

    @Override
    public RouteType getRouteType() {
        return RouteType.LEAST_COST;
    }
}
