package com.isg.mw.routing.exception;

public class ApiFailedResponseException extends RuntimeException{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Object[] args = null;

    public ApiFailedResponseException(String errorMsg) {
        super(errorMsg);
    }

    public ApiFailedResponseException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

    public ApiFailedResponseException(String msg, Object ... args) {
        super(msg);
        this.args = args;
    }

    public Object[] getArgs() {
        return args;
    }
}
