package com.isg.mw.routing.consumer.service;

import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetConfigModel;

import java.util.List;

public interface MerchantMasterService {

    List<TargetMerchantMasterModel> getTargetMerchantMasterModels(MerchantMasterModel merchantMasterModel,Class<?> className,String targetType);

    boolean sendTargetMerchantMasterToCm(TargetMerchantMasterModel tMerMasterModel);

}
