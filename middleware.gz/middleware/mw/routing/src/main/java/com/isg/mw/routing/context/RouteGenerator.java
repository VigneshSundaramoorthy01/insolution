package com.isg.mw.routing.context;

import java.util.HashSet;
import java.util.Set;

import com.isg.mw.routing.route.ApiRouter;
import org.apache.camel.builder.RouteBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.routing.route.SocketRouter;

@Component
public class RouteGenerator {

	private Logger logger = LogManager.getLogger(getClass());

	private Set<RouteBuilder> routeBuilders = new HashSet<>();

	@Autowired
	private AutowireCapableBeanFactory autowireBeanFactory;

	public SocketRouter createSocketRouterBean(RoutingContext routingContext) {
		SocketRouter socketRouter = new SocketRouter(routingContext);
		autowireBeanFactory.autowireBean(socketRouter);
		return socketRouter;
	}

    public ApiRouter createApiRouterBean(RoutingContext routingContext) {
        ApiRouter apiRouter = new ApiRouter(routingContext);
        autowireBeanFactory.autowireBean(apiRouter);
        return apiRouter;
    }

    public String generateRoute(RoutingContext routingContext) {
        String directRoute = "direct:";
        logger.info("## Starting route: {}", routingContext.getSource().getName());
        if (routingContext.getConnectionType() == ConnectionType.ISO) {
            routeBuilders.add(createSocketRouterBean(routingContext));
            directRoute += "socketRoute." + routingContext.getSource().getName();
        } else if (routingContext.getConnectionType() == ConnectionType.API) {
            routeBuilders.add(createApiRouterBean(routingContext));
            directRoute += "apiRoute." + routingContext.getSource().getName();
        }
        return directRoute;
    }

    public Set<RouteBuilder> getRouteBuilders() {
        return routeBuilders;
    }
}
