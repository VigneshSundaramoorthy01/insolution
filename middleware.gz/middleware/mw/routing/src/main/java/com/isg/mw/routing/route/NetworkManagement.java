package com.isg.mw.routing.route;

import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.SignOnSignOffModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.route.bmsswitch.BmsProcessorHelper;
import com.isg.mw.routing.smartroute.ISmartRoute;
import com.isg.mw.routing.smartroute.SmartRouteFactory;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.TxnIdGenerator;
import com.isg.mw.routing.util.RouteUtil;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.isg.mw.core.utils.LogUtils.buildLogMessage;
import static com.isg.mw.mtm.transform.MessageTransformer.constructMessage;
import static com.isg.mw.mtm.transform.TmmConstants.*;


@Component
@PropertySource("${spring.config.location}routing-config.properties")
public class NetworkManagement {

    @Value("${eftpos.signon.wait.time:5000}")
    private long eftposConnectWaitTime;

    @Value("${eftpos.recnnect.wait.time:5000}")
    private long eftposReconnectWaitTime;

    @Value("${eftpos.settlement.time:0 00 10 * * ?}")
    private String eftposSettlementTime;

    @Value("${eftpos.init.status:true}")
    private boolean eftposInitStatus;

    @Autowired
    BmsProcessorHelper bmsProcessorHelper;

    private final Logger logger = LogManager.getLogger(getClass());


    private String generateTransactionId() {
        return Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
    }

    void doConnect(RoutingContext routingContext) {
        try {
            if (eftposInitStatus) {
                String entityId = routingContext.getEntityId();
                logger.info("Establish Socket connection for eftpos : {}", entityId);
                Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
                Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);
                endpointInfoMap.forEach((targetIp, endpointInfo) -> {
                    if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(endpointInfo.getTargetType())) {
                        initiateConnection(TransactionCategory.SIGNON, targetIp, endpointInfo, routingContext);
                        try {
                            Thread.sleep(eftposConnectWaitTime);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }
        } catch (Exception e) {
            logger.error("Error occurred during establish connection !");
        }
    }

    void doSignOn(RoutingContext routingContext) {
        try {
            String entityId = routingContext.getEntityId();
            logger.info("Starting sign on for all targets for entity: {}", entityId);

            Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
            Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);
            // Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
            endpointInfoMap.forEach((targetIp, endpointInfo) -> {
                if (endpointInfo.isSignOnRequired() && !endpointInfo.isSignedOn()) {
                    boolean isSignOnSuccess = false;
                    int count = 0;
                    if (!TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(endpointInfo.getTargetType())) {
                        do {
                            isSignOnSuccess = initiateRequest(TransactionCategory.SIGNON, targetIp, endpointInfo, routingContext);
                            count++;
                        } while (!isSignOnSuccess && count < 3);
                    } else {
                        isSignOnSuccess = initiateRequest(TransactionCategory.SIGNON, targetIp, endpointInfo, routingContext);
                    }
                    endpointInfo.setSignedOn(isSignOnSuccess);
                    /*if(endpointInfo.isSignedOn()) {
                        RouteUtil.updateEndPointSignOnStatusByEpName(targetEpEntries, endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length() -1), isSignOnSuccess);
                    }*/
                }
            });
            endpointInfoMap.forEach((targetIp, endpointInfo) -> {
                SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
                if (smartRouteConfigModel != null && endpointInfo.isSignOnRequired()) {
                    ISmartRoute smartRoute = SmartRouteFactory.getSmartRoute(smartRouteConfigModel.getRouteType());
                    smartRoute.setTargetIsAlive(routingContext.getSource(), smartRouteConfigModel,
                            endpointInfo.getTargetConfigModel().getId().toString(), endpointInfo.isSignedOn());
                }
            });
        } catch (Exception e) {
            logger.error("Error occurred during target sign on");
        }
    }

    void doSignOff(RoutingContext routingContext) {
        String entityId = routingContext.getEntityId();
        logger.info("Starting sign off for all targets for entity: {}", entityId);
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);

        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if (endpointInfo.isSignedOn()) {
                boolean isSignOffSuccess = initiateRequest(TransactionCategory.SIGNOFF, targetIp, endpointInfo, routingContext);
                if (isSignOffSuccess) {
                    endpointInfo.setSignedOn(false);
                }
            }
        });
    }

    void doDynamicKeyExchange(RoutingContext routingContext) {
        String entityId = routingContext.getEntityId();
        logger.info("Starting Dynamic KeyExchange for all targets for entity: {}", entityId);
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);
        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if (((endpointInfo.isSignedOn()  && endpointInfo.isSignOnRequired()) || TargetType.Amex.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name()))
                    && endpointInfo.getPinTranslationType().equals(PinTranslationType.DYNAMIC)
                    && SourceProcessor.POS_SWITCH == endpointInfo.getSourceProcessor()) {
                TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(endpointInfo.getEpName());
                String dynamicKey = SpringContextBridge.services().getMwRedisCacheUtil().
                        getTargetDynamicKeyData(entityId + "_" + SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(entityId) +
                                TmmConstants.DYNAMIC_KEY, targetType);
                if (dynamicKey == null) {
                    initiateRequest(TransactionCategory.DYNAMIC_KEY_EXCHANGE, targetIp, endpointInfo, routingContext);
                } else {
                    logger.info("Dynamic key found for the endpoint {}:{} in cache", targetIp, endpointInfo.getPort());
                }
            }
            if(endpointInfo.isSignedOn() &&  endpointInfo.getTargetType().equalsIgnoreCase(EFTPOS_SCHEME_TYPE)) {
                RouteUtil.updateEndPointSignOnStatusByEpName(targetEpEntries, endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length() -1), true);
            }
        });
    }


    void doDynamicKeyExchangeWithTargetName(RoutingContext routingContext, String targetName) {
        String entityId = routingContext.getEntityId();
        logger.info("Starting Dynamic KeyExchange for all targets for entity: {}", entityId);
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);
        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if (endpointInfo.getTargetConfigModel().isSignonRequired()  && endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length()-1).equalsIgnoreCase(targetName)) {
                TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(endpointInfo.getEpName());
                String dynamicKey = SpringContextBridge.services().getMwRedisCacheUtil().
                        getTargetDynamicKeyData(entityId + "_" + SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(entityId) +
                                TmmConstants.DYNAMIC_KEY, targetType);
                if (dynamicKey == null) {
                    initiateRequest(TransactionCategory.DYNAMIC_KEY_EXCHANGE, targetIp, endpointInfo, routingContext);
                } else {
                    logger.info("Dynamic key found for the endpoint {}:{} in cache", targetIp, endpointInfo.getPort());
                }
            }
        });
    }

    protected void doEftposReconnect(RouteBuilder routeBuilder, RoutingContext routingContext){
        try {
            if (eftposInitStatus) {
                Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
                Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(routingContext.getEntityId());
                Map<String, RoutingInitializationContext.EndpointMetaData> filteredEpInfoMap = new HashMap<>();
                if (!filteredEpInfoMap.isEmpty()) {
                    filteredEpInfoMap.forEach((key, value) -> scheduleEftposReconnect(key, value, routeBuilder, routingContext));
                } else {
                    endpointInfoMap.forEach((key, value) -> scheduleEftposReconnect(key, value, routeBuilder, routingContext));
                }
            }
        }
        catch (Exception e){
            logger.error("Error occurred while scheduling heartbeat");
        }
    }

    private void scheduleEftposReconnect(String targetIp, RoutingInitializationContext.EndpointMetaData endpointInfo, RouteBuilder routeBuilder, RoutingContext routingContext) {
        String schedulerName = endpointInfo.getEpName() + "-eftposReconnectScheduler";
        long heartBeatDelay =eftposReconnectWaitTime;
        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        routeBuilder.from("scheduler:" + schedulerName + "?delay=" + heartBeatDelay + "&initialDelay=" + heartBeatDelay)
                .process(exchange -> {
                    SignOnSignOffModel signOnSignOffModel =  SpringContextBridge.services().getCacheService().getEftposSignOnStatus();
                    if(signOnSignOffModel.isReSignOn() == true && signOnSignOffModel.getTargetIp().equals(endpointInfo.getEpName())) {
                        boolean isSignOnSuccess = initiateRequest(TransactionCategory.SIGNON, targetIp, endpointInfo, routingContext);
                        endpointInfo.setSignedOn(isSignOnSuccess);
                        if (isSignOnSuccess) {
                            EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length()-1));
                            eftposKeyModel.setSignonKey(false);
                            SpringContextBridge.services().getCacheService().updateEftposKeyDetails(endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length()-1), eftposKeyModel);
                            logger.info("Sending an KeyExchange to target: {}", endpointInfo.getEpName());
                            initiateRequest(TransactionCategory.DYNAMIC_KEY_EXCHANGE, targetIp, endpointInfo, routingContext);
                            SpringContextBridge.services().getCacheService().putSignOffStatus(false, endpointInfo.getEpName());
                            SpringContextBridge.services().getCacheService().putEftposSignOnStatus(false, endpointInfo.getEpName());

                            if(endpointInfo.isSignedOn() &&  endpointInfo.getTargetType().equalsIgnoreCase(EFTPOS_SCHEME_TYPE)) {
                                RouteUtil.updateEndPointSignOnStatusByEpName(targetEpEntries, endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length() -1), true);
                            }

                        }
                    }
                });
    }


    void doHostSessionActivation(RoutingContext routingContext) {
        String entityId = routingContext.getEntityId();
        logger.info("Starting Host session activation on for all targets for entity: {}", entityId);
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);

        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if (TargetType.Master.equals(endpointInfo.getTargetConfigModel().getTargetType())
                    && endpointInfo.isSignedOn()
                    && PinTranslationType.DYNAMIC.equals(endpointInfo.getPinTranslationType())) {
                initiateRequest(TransactionCategory.HOST_SESSION_ACTIVATION, targetIp, endpointInfo, routingContext);
            }
        });
    }

    void doHostSessionDeactivation(RoutingContext routingContext) {
        String entityId = routingContext.getEntityId();
        logger.info("Starting Host session deactivation for all targets for entity: {}", entityId);
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);

        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if (TargetType.Master.equals(endpointInfo.getTargetConfigModel().getTargetType())
                    && endpointInfo.isSignedOn()
                    && PinTranslationType.DYNAMIC.equals(endpointInfo.getPinTranslationType())) {
                initiateRequest(TransactionCategory.HOST_SESSION_DEACTIVATION, targetIp, endpointInfo, routingContext);
            }
        });
    }

    void doHeartBeat(RouteBuilder routeBuilder, RoutingContext routingContext) {
        try {
            Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext
                    .getTargetEndpointInfoMap();
            Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap
                    .get(routingContext.getEntityId());

            SmartRouteConfigModel smrtRtCfgModel = routingContext.getSmartRouteConfigModel();
            Map<String, RoutingInitializationContext.EndpointMetaData> filteredEpInfoMap = new HashMap<>();
            if (smrtRtCfgModel != null) {
                for (SmartRouteTargetDefinition targetDef : smrtRtCfgModel.getTargetRouteConfig()) {
                    Map<String, RoutingInitializationContext.EndpointMetaData> collectMap = endpointInfoMap.entrySet().stream()
                            .filter(entry -> entry.getValue().getTargetConfigModel().getId().equals(targetDef.getTargetId()))
                            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                    filteredEpInfoMap.put(collectMap.keySet().iterator().next(), collectMap.values().iterator().next());
                }
            }
            if (!filteredEpInfoMap.isEmpty()) {
                filteredEpInfoMap.forEach((key, value) -> scheduleHeartBeat(key, value, routeBuilder, routingContext));
            } else {
                endpointInfoMap.forEach((key, value) -> scheduleHeartBeat(key, value, routeBuilder, routingContext));
            }
        } catch (Exception e) {
            logger.error("Error occurred while scheduling heartbeat");
        }
    }


    private void scheduleHeartBeat(String targetIp, RoutingInitializationContext.EndpointMetaData endpointInfo,
                                   RouteBuilder routeBuilder, RoutingContext routingContext) {

        boolean signOffStatus = SpringContextBridge.services().getCacheService().getSignOffStatus(endpointInfo.getEpName());

        if (!endpointInfo.isHeartbeatScheduled()) {
            String schedulerName = endpointInfo.getEpName() + "-heartBeatScheduler";
            int heartBeatDelay = endpointInfo.getHeartBeatDelay();
            routeBuilder.from("scheduler:" + schedulerName + "?delay=" + heartBeatDelay + "&initialDelay=" + heartBeatDelay)
                    .process(exchange -> {
                        if (endpointInfo.isSignedOn()) {
                            boolean isSignOnSuccess = false;
                            logger.info("Sending an HeartBeat to target: {}", endpointInfo.getEpName());
                            isSignOnSuccess = initiateRequest(TransactionCategory.HEARTBEAT, targetIp, endpointInfo,
                                    routingContext);
                            if(isSignOnSuccess) {
                                endpointInfo.setConnectionAlive(true);
                            }
                            if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(endpointInfo.getTargetType()) && isSignOnSuccess == false) {
                                endpointInfo.setConnectionAlive(false);
                                initiateConnection(TransactionCategory.SIGNON, targetIp, endpointInfo, routingContext);
                            }
                        }

                        if(endpointInfo.getTargetType().equalsIgnoreCase(TargetType.Bms.name())){
                            bmsProcessorHelper.doHeartBeatToNPCI();
                        }
                    });
            endpointInfo.setHeartbeatScheduled(true);
        }
    }

    void doReconnectTarget(RouteBuilder routeBuilder, RoutingContext routingContext) {
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext
                .getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap
                .get(routingContext.getEntityId());
        logger.info("calling Reconnect Target Method : ");
        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if ((endpointInfo.isSignOnRequired() && !endpointInfo.isReconnectScheduled())
                    || (TargetType.Amex.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name())
                    && SourceProcessor.POS_SWITCH == endpointInfo.getSourceProcessor())) {
                String schedulerName = endpointInfo.getEpName()+ "-reconnectScheduler";
                int reconnectDelay = endpointInfo.getReconnectDelay();
                logger.info("calling scheduler : ");
                routeBuilder.from("scheduler:" + schedulerName + "?delay=" + reconnectDelay + "&initialDelay=" + reconnectDelay)
                        .process(exchange -> {
                            if (!endpointInfo.isSignedOn() || TargetType.Amex.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name()) || TargetType.EftPos.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name())) {
                                boolean signOnSuccess = false;
                                if(!(TargetType.Amex.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name()) || TargetType.EftPos.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name()))) {
                                    logger.info("reconnecting to target: {}", endpointInfo.getEpName());
                                    signOnSuccess = initiateRequest(TransactionCategory.SIGNON, targetIp, endpointInfo,
                                            routingContext);
                                    endpointInfo.setSignedOn(signOnSuccess);
                                }

                                if (signOnSuccess || TargetType.Amex.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name()) || TargetType.EftPos.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name())) {
                                    boolean hostSessionActSuccess = false;
                                    if (endpointInfo.getTargetConfigModel().getTargetType().equals(TargetType.Master)) {
                                        hostSessionActSuccess = initiateRequest(TransactionCategory.HOST_SESSION_ACTIVATION, targetIp, endpointInfo, routingContext);
                                    }

                                    if (endpointInfo.getPinTranslationType().equals(PinTranslationType.DYNAMIC)) {
                                        if ((hostSessionActSuccess && endpointInfo.getTargetConfigModel().getTargetType().equals(TargetType.Master)) ||
                                                endpointInfo.getTargetConfigModel().getTargetType().equals(TargetType.Rupay) ||
                                                TargetType.Amex.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name()) ||  TargetType.EftPos.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name())) {
                                            if(TargetType.EftPos.name().equals(endpointInfo.getTargetConfigModel().getTargetType().name())) {
                                                EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(endpointInfo.getTargetConfigModel().getTarget().name().substring(0, endpointInfo.getTargetConfigModel().getTarget().name().length()-1));
                                                eftposKeyModel.setSignonKey(false);

                                                Map<String, Integer> map = new HashMap<>();
                                                map.put(endpointInfo.getTargetConfigModel().getTarget().name().substring(0, endpointInfo.getTargetConfigModel().getTarget().name().length()-1), 0);
                                                eftposKeyModel.setTargetName(map);

                                                SpringContextBridge.services().getCacheService().updateEftposKeyDetails(endpointInfo.getTargetConfigModel().getTarget().name().substring(0, endpointInfo.getTargetConfigModel().getTarget().name().length()-1), eftposKeyModel);
                                            }


                                            initiateRequest(TransactionCategory.DYNAMIC_KEY_EXCHANGE, targetIp, endpointInfo, routingContext);
                                        }
                                    }
                                }
                            }
                        });
                endpointInfo.setReconnectScheduled(true);
            }
        });
    }

    boolean initiateRequest(TransactionCategory transactionCategory, String targetIp, RoutingInitializationContext.EndpointMetaData endpointInfo, RoutingContext routingContext) {
        boolean isRspSuccess = false;

        logger.info("Initializing {} for target: {}", transactionCategory.name(), targetIp);

        TransactionMessageModel requestSourceTmm = new TransactionMessageModel();
        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(endpointInfo.getEpName());

        // schemetype.mti.processingcode
        String processingCode = null;
        String transactionInfo = null;
        if (TargetType.Amex.name().equals(targetType.name())) {
            transactionInfo = targetType.name() + "." + REQ_NW_MGMT_MSG_TYPE_AMEX + "." + processingCode;
            requestSourceTmm.setMsgType(REQ_NW_MGMT_MSG_TYPE_AMEX);
        } else if(TargetType.EftPos.name().equals(targetType.name()) &&(transactionCategory.name().equals(TransactionCategory.DYNAMIC_KEY_EXCHANGE.name())
                || transactionCategory.name().equals(TransactionCategory.SIGNOFF.name()))){
            transactionInfo = targetType.name() + "." + REQ_NW_MGMT_MSG_TYPE_EFTPOS + "." + processingCode;
            requestSourceTmm.setMsgType(REQ_NW_MGMT_MSG_TYPE_EFTPOS);
        } else {
            transactionInfo = targetType.name() + "." + REQ_NW_MGMT_MSG_TYPE + "." + processingCode;
            requestSourceTmm.setMsgType(REQ_NW_MGMT_MSG_TYPE);
        }
        Set<String> txnNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap().get(transactionInfo);
        String txnName = txnNameSet.stream().findFirst().orElse(null);

        requestSourceTmm.setTransactionName(txnName);
        requestSourceTmm.setEntityId(routingContext.getEntityId());
        requestSourceTmm.setTlmMessageType(TlmMessageType.REQUEST);
        requestSourceTmm.setTransactionCategory(transactionCategory);
        requestSourceTmm.setTransactionId(generateTransactionId());
        requestSourceTmm.setForwardingInstIdCode(endpointInfo.getTargetConfigModel().getAdditionalData().getFwdInstId());
        requestSourceTmm.setSignOnId(endpointInfo.getTargetConfigModel().getAdditionalData().getSignOnId());
        try {
            requestSourceTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
            MessageContext targetMsgContext = constructMessage(requestSourceTmm, endpointInfo.getEpName());
            TransactionMessageModel requestTargetTmm = targetMsgContext.getTransactionMessageModel();
            requestTargetTmm.setEpType(EpType.TARGET);

            String correlationId = requestTargetTmm.getRetrievalRefNo();
            if (requestTargetTmm.getAquirerIdCode() != null)
                correlationId = requestTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + requestTargetTmm.getRetrievalRefNo();
            if (correlationId == null) {
                correlationId = requestTargetTmm.getStan();
            }


            Object resMessage = null;
            TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) targetMsgContext.getRawMsg(), requestTargetTmm);

            if (TargetType.Amex.name().equals(targetType.name())) {
                String host = endpointInfo.getTargetConfigModel().getConnections().get(0).getUrlOrIp() + endpointInfo.getTargetConfigModel().getAdditionalData().getApiInfo().getAmex().getTxnUrl();
                resMessage = RoutingInitializationContext.getMwProducer()
                        .callApi(targetMsgContext.getRawMsg().toString(), host, targetMsgContext.getApiHeaders());

            } else {
                NettyEndpoint producerEndpoint = NettyConfig.getProducerEndpoint(routingContext, targetIp);
                resMessage = RoutingInitializationContext.getMwProducer().sendMessage(targetMsgContext.getRawMsg(),
                        correlationId, producerEndpoint);
            }

            if (resMessage != null) {
                TransactionMessageModel responseTmm = null;
                if (TargetType.Amex.name().equals(targetType.name())) {
                    String resBody = IsgJsonUtils.getJsonString(resMessage);
                    Class<?> businessRuleClass = targetMsgContext.getMessageTransformationConfig().getBusinessRuleClass();
                    //responseTmm = processTargetApiResponse(resBody, businessRuleClass, exchange);

                    BaseMessageTransformation baseMsgTransformation = (BaseMessageTransformation) businessRuleClass.newInstance();
                    responseTmm = baseMsgTransformation.parseResponse(resBody, requestTargetTmm, null, null, null);
                } else {
                    responseTmm = MessageTransformer.toResponsePojo(null, null,
                            (byte[]) resMessage, requestSourceTmm.getTransactionName());
                }
                responseTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                responseTmm.setTransactionId(requestSourceTmm.getTransactionId());
                responseTmm.setTransactionCategory(requestTargetTmm.getTransactionCategory());

                logger.trace(buildLogMessage(responseTmm.getEntityId(), responseTmm.getTarget(), null,
                        responseTmm.getTransactionId(), "Response code: {}"), responseTmm.getResCode());

                // TODO: check response code in business class and use it here
                if (TmmConstants.RES_CODE_SUCCESS.equals(responseTmm.getResCode())
                        || TmmConstants.RES_AMEX_KEY_EXCHANE_CODE_SUCCESS.equals(responseTmm.getResCode())) {
                    isRspSuccess = true;
                    logger.info("{} completed for target connection {}", transactionCategory.name(), targetIp);
                }
            } else {
                logger.error("Failed to do {} with target connection {}", transactionCategory.name(), targetIp);
            }
        } catch (Exception e) {
            logger.error("Failed to do {} with target connection {}", transactionCategory.name(), targetIp, e);
        }
        return isRspSuccess;
    }


    void initiateConnection(TransactionCategory transactionCategory, String targetIp, RoutingInitializationContext.EndpointMetaData endpointInfo, RoutingContext routingContext) {

        logger.info("Initializing {} for target: {}", transactionCategory.name(), targetIp);
        NettyEndpoint producerEndpoint = NettyConfig.getProducerEndpoint(routingContext, targetIp);

        try {
            Object resMessage = RoutingInitializationContext.getMwProducer().connect("", "", producerEndpoint);
            if (resMessage != null) {
                logger.info("Connection establish with target: {}", endpointInfo.getEpName());
            } else {
                logger.info("Connection to establish connection with target: {}", endpointInfo.getEpName());
            }
        } catch (Exception e) {
            logger.error("Failed to do {} with target connection {}", transactionCategory.name(), targetIp, e);
        }
    }

    void doDyanmicKeyDeactivation(RoutingContext routingContext) {
        String entityId = routingContext.getEntityId();
        logger.info("Starting Dynamic Key deactivation for Amex for entity: {}", entityId);
        Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
        Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);

        endpointInfoMap.forEach((targetIp, endpointInfo) -> {
            if (TargetType.Amex.equals(endpointInfo.getTargetConfigModel().getTargetType())
                    && (SourceProcessor.POS_SWITCH.name().equals(endpointInfo.getSourceProcessor().name()))) {
                TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(endpointInfo.getEpName());
                SpringContextBridge.services().getMwRedisCacheUtil().
                        removeTargetDynamicKeyData(entityId + "_" + SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(entityId) +
                                TmmConstants.DYNAMIC_KEY, targetType);
            }
        });

    }


    // For Eftpos Settlement
    void doEftposSettlement(RouteBuilder routeBuilder, RoutingContext routingContext) {
        try {
            if (eftposInitStatus) {
                String entityId = routingContext.getEntityId();
                logger.info("Starting settlement for all targets for entity: {}", entityId);
                Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext.getTargetEndpointInfoMap();
                Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap.get(entityId);

                endpointInfoMap.forEach((key, value) -> scheduleEftposSettlement(key, value, routeBuilder, routingContext));
            }
        } catch (Exception e) {
            logger.error("Error occurred during target sign on");
        }
    }

    private void scheduleEftposSettlement(String targetIp, RoutingInitializationContext.EndpointMetaData endpointInfo, RouteBuilder routeBuilder, RoutingContext routingContext) {

        if (endpointInfo.isSignOnRequired()
                && TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(endpointInfo.getTargetType())) {
            logger.info("Starting settlement for all targetIp: {}, having target name: {} ", targetIp, endpointInfo.getEpName());
            String schedulerName = endpointInfo.getEpName() + "-eftposSettlementScheduler";
            routeBuilder.from("cron:" + schedulerName + "?schedule="+ eftposSettlementTime)
                    .process(exchange -> {
                        logger.info("Sending an Eftpos Settlement to target: {}", endpointInfo.getEpName());
                        if(routingContext.getTargets().get(0).getTargetType().name().equals(TargetType.EftPos.name())) {
                            initiateEftposSettlementRequest(TransactionCategory.CUTOVER, targetIp, endpointInfo, routingContext);
                        }
                    });
        }
    }

    boolean initiateEftposSettlementRequest(TransactionCategory transactionCategory, String targetIp, RoutingInitializationContext.EndpointMetaData endpointInfo, RoutingContext routingContext) {
        boolean isRspSuccess = false;
        logger.info("Initializing {} for target: {}", transactionCategory.name(), targetIp);
        TransactionMessageModel requestSourceTmm = new TransactionMessageModel();
        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(endpointInfo.getEpName());

        String processingCode = null;
        String transactionInfo = null;
        transactionInfo = targetType.name() + "." + "0520" + "." + null;
        Set<String> txnNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap().get(transactionInfo);
        String txnName = txnNameSet.stream().findFirst().orElse(null);
        requestSourceTmm.setEntityId(routingContext.getEntityId());
        requestSourceTmm.setTarget(endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length() -1));
        requestSourceTmm = SwitchBaseMessageConstruction.fetchSettlementTxnTransactionEftpos(requestSourceTmm);
        requestSourceTmm.setTransactionName(txnName);
        requestSourceTmm.setEntityId(routingContext.getEntityId());
        requestSourceTmm.setTlmMessageType(TlmMessageType.REQUEST);
        requestSourceTmm.setTransactionCategory(transactionCategory);
        requestSourceTmm.setTransactionId(generateTransactionId());
        requestSourceTmm.setMsgType("0520");
        requestSourceTmm.setForwardingInstIdCode(endpointInfo.getTargetConfigModel().getAdditionalData().getFwdInstId());
        requestSourceTmm.setAquirerIdCode(endpointInfo.getTargetConfigModel().getAdditionalData().getAcquirerId());
        try {
            requestSourceTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
            MessageContext targetMsgContext = constructMessage(requestSourceTmm, endpointInfo.getEpName());
            TransactionMessageModel requestTargetTmm = targetMsgContext.getTransactionMessageModel();
            requestTargetTmm.setEpType(EpType.TARGET);

            String correlationId = requestTargetTmm.getRetrievalRefNo();
            if (requestTargetTmm.getAquirerIdCode() != null)
                correlationId = requestTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + requestTargetTmm.getRetrievalRefNo();
            if (correlationId == null) {
                correlationId = requestTargetTmm.getStan();
            }


            Object resMessage = null;
            NettyEndpoint producerEndpoint = NettyConfig.getProducerEndpoint(routingContext, targetIp);
            resMessage = RoutingInitializationContext.getMwProducer().sendMessage(targetMsgContext.getRawMsg(), correlationId, producerEndpoint);
            TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) targetMsgContext.getRawMsg(), requestTargetTmm);

            if (resMessage != null) {
                TransactionMessageModel responseTmm = null;
                responseTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, requestSourceTmm.getTransactionName());
                responseTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                responseTmm.setTransactionId(requestSourceTmm.getTransactionId());
                responseTmm.setTransactionCategory(requestTargetTmm.getTransactionCategory());

                logger.trace(buildLogMessage(responseTmm.getEntityId(), responseTmm.getTarget(), null, responseTmm.getTransactionId(), "Response code: {}"), responseTmm.getResCode());

                // TODO: check response code in business class and use it here
                if (TmmConstants.RES_CODE_SUCCESS.equals(responseTmm.getResCode())) {
                    isRspSuccess = true;
                    logger.info("{} completed for target connection {}", transactionCategory.name(), targetIp);
                }
            } else {
                logger.error("Failed to do {} with target connection {}", transactionCategory.name(), targetIp);
            }
        } catch (Exception e) {
            logger.error("Failed to do {} with target connection {}", transactionCategory.name(), targetIp, e);
        }
        return isRspSuccess;
    }

    public void doNpciHeartBeat(RouteBuilder routeBuilder, RoutingContext routingContext) {
        try {
            Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext
                    .getTargetEndpointInfoMap();
            Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap
                    .get(routingContext.getEntityId());


            endpointInfoMap.forEach((key, value) -> scheduleHeartBeat(key, value, routeBuilder, routingContext));
        } catch (Exception e) {
            logger.error("Error occurred while scheduling heartbeat");
        }
    }

}