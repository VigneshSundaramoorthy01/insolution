package com.isg.mw.routing.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@Setter
@Getter
@PropertySources({
        @PropertySource("${spring.config.location}kafka-config.properties"),
        @PropertySource("${spring.config.location}routing-config.properties")})
public class RoutingProperties {
	
	@Value("${smart.route.kafka.topic}")
	private String srkafkaTopic;

    @Value("${kafka.brokers}")
    private String kafkaBrokers;

    @Value("${kafka.tlm.routing.topic}")
    private String kafkaRoutingTopic;

    @Value("${kafka.feeder.routing.topic}")
    private String kafkaFeederRoutingTopic;

    @Value("${kafka.topic.auto.reversal}")
    private String kafkaAutoReversalTopic;

    @Value("${kafka.security.enabled:false}")
    private boolean kafkaSecurityEnabled;

    @Value("${kafka.truststore.location:}")
    private String trustStoreLocation;

    @Value("${kafka.truststore.password:}")
    private String trustStorePassword;

    @Value("${kafka.set.protocol:}")
    private String protocol;

    @Value("${kafka.set.sasl.mechanism:}")
    private String saslMechanism;

    @Value("${kafka.truststore.type:}")
    private String trustStoreType;

    @Value("${kafka.jaas.config:}")
    private String saslJaasConfig;

    @Value("${netty.workercount:256}")
    private int nettyWorkercount;

    @Value("${netty.bosscount:1}")
    private int nettyBossCount;

    @Value("${netty.backlog:65536}")
    private int nettyBacklog;

    /*
     * Flag to support native transport for performance improvement
     * 0 - Disabled
     * NonZero - Enabled
     */
    @Value("${netty.nativetransport:0}")
    private int nettyNativeTransport;

    @Value("${target.request.timeout.global.default}")
    private int targetRequestTimeoutGlobalDefault;

    @Value("${target.connect.timeout.global.default}")
    private int targetConnectTimeoutGlobalDefault;

    @Value("${transaction.response.timeout}")
    private int transactionResponseTimeout;

    @Value("${reconnect.delay}")
    private int reconnectDelay;

    @Value("${kafka.block.max.ms:10000}")
    private int kafkaMaxBlockMs;

    @Value("${payment.links.kafka.topic}")
    private String payLinkskafkaTopic;

    /*@Value("${resource.path}")
    private String path;

    private static ResourceBundle messagesBundle;

    @PostConstruct
    public void postConstruct() throws MalformedURLException {
        File file = new File(path);
        URL[] urls = {file.toURI().toURL()};
        ClassLoader loader = new URLClassLoader(urls);
        if (!(path.isEmpty()) || path != null) {
            RoutingProperties.messagesBundle = ResourceBundle.getBundle("routing-config", new Locale("en"), loader);
        } else {
            ResourceBundle.getBundle("routing-config", new Locale("en"));
        }
    }

    public static String getProperty(String msgKey) {
        String msg = null;
        try {
            msg = (String) messagesBundle.getObject(msgKey);
        } catch (NullPointerException | MissingResourceException ex) {
            msg = "Unknown message";
        }
        return msg;
    }*/
}
