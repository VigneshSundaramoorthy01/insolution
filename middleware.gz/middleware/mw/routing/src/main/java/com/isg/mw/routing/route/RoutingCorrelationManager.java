package com.isg.mw.routing.route;

import static com.isg.mw.core.utils.LogUtils.buildLogMessage;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isRupayCutOverMsg;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isVisaEchoMsg;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isVisaSigOff;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isVisaSigOn;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

import javax.annotation.PostConstruct;

import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.KeyModel;
import com.isg.mw.core.model.eftpos.SignOnSignOffModel;
import com.isg.mw.core.model.eftpos.TempKeyModel;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.camel.component.netty.NettyCamelState;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.component.netty.TimeoutCorrelationManagerSupport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.model.constants.EpType;
import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.MsgFlow;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.TlvDataList;
import com.isg.mw.dstm.service.IPinTranslationService;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.context.RoutingInitializationContext.EndpointMetaData;
import com.isg.mw.routing.exception.InvalidMessageException;
import com.isg.mw.routing.util.RouteUtil;
import com.isg.mw.core.utils.TxnIdGenerator;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;

@Component
public class RoutingCorrelationManager extends TimeoutCorrelationManagerSupport implements ApplicationContextAware {

    private static ApplicationContext applicationContext;
    private final Logger logger = LogManager.getLogger(getClass());

    private String correlationId;
    
    @Autowired
    private TransactionProcessorHelper transactionProcessorHelper;

    private static TransactionProcessorHelper transactionProcessorHelperStatic;

    @Autowired
    private NetworkManagement networkManagement;

    @Autowired
    private BqrSwitchTransactionProcessor bqrSwitchTransactionProcessor;

    private static BqrSwitchTransactionProcessor bqrSwitchTransactionProcessorStatic;

    @PostConstruct
    public void setProperties() {
    	RoutingCorrelationManager.transactionProcessorHelperStatic = transactionProcessorHelper;
        RoutingCorrelationManager.bqrSwitchTransactionProcessorStatic = bqrSwitchTransactionProcessor;
    }


    public RoutingCorrelationManager() {
        super();
    }

    public RoutingCorrelationManager(int responseTimeout) {
        super();
        super.setTimeout(responseTimeout);
    }

    @Override
    public void putState(Channel channel, NettyCamelState state) {
        this.correlationId = (String) state.getExchange().getIn().getHeader("correlationId");
        super.putState(channel, state);
    }

    @Override
    public String getRequestCorrelationId(Object request) {
        logger.trace("Correlation id while sending a request: {}", this.correlationId);
        return this.correlationId;
    }

    @Override
    public NettyCamelState getState(ChannelHandlerContext ctx, Channel channel, Object msg) {
    	TxnLogger.logRawMsg(MsgFlow.INBOUND, (byte[]) msg);
    	TransactionMessageModel pojoResponse = null;
    	
    	if (msg == null || ((byte[]) msg).length == 0) {
    		throw new InvalidMessageException("Response Message Is Empty");
    	}

    	String remoteAddTmp = channel.remoteAddress().toString();
    	final String targetRemoteAdd = remoteAddTmp.substring(remoteAddTmp.indexOf("/") + 1);

    	/*
    	 * Following assumes that target ip address will be unique across the entities
    	 */
    	Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
    	for (Map.Entry<String, Map<String, EndpointMetaData>> entry : targetEpEntries) {
    		String key = entry.getKey();
    		Map<String, EndpointMetaData> value = entry.getValue();
    		EndpointMetaData endpointMetaData = value.get(targetRemoteAdd);
    		if (endpointMetaData != null) {
    			logger.trace("Target Remote Address: {}", targetRemoteAdd);
    			try {
    				if (endpointMetaData.getTargetConfigModel() != null
    						&& endpointMetaData.getTargetConfigModel().getAdditionalData().getTargetProcessor() != null) {

    					switch (endpointMetaData.getTargetConfigModel().getAdditionalData().getTargetProcessor()) {

    					case BQRPROCESSOR:
    						ExecutorService executorService = RouteUtil.getExecutorService();
    						executorService.submit(() -> processBqrSwitchTxn(msg, targetRemoteAdd, targetEpEntries, key, endpointMetaData));
    						break;
    					default:
    						break;
    					}
    				} else {
    					pojoResponse = MessageTransformer
    							.toResponsePojo(endpointMetaData.getEntityId(), endpointMetaData.getEpName(), (byte[]) msg, null);

    					processSchemeResponse(msg, targetRemoteAdd, targetEpEntries, key, endpointMetaData,
    							pojoResponse);

                        if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(pojoResponse.getTargetType().name()) &&
                                "0830".equalsIgnoreCase(pojoResponse.getMsgType()) && "101".equalsIgnoreCase(pojoResponse.getNetworkMgmtInfoCode())){

                            TempKeyModel tempKeyModel = SpringContextBridge.services().getCacheService().getTempEftposKeyDetails(pojoResponse.getSource().substring(0,pojoResponse.getSource().length()-1));
                            EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(pojoResponse.getSource().substring(0, pojoResponse.getSource().length()-1));
                            logger.info("ZpkUnderLMK :: {}, targetName ::{} , SignStatus {}", tempKeyModel.getZpkUnderLMK(), pojoResponse.getSource(), eftposKeyModel.isSignonKey());
                            if(eftposKeyModel.isSignonKey() == true || eftposKeyModel.isTrxnLimitExceededKey()== true) {
                                KeyModel keyModel =  new KeyModel();
                                keyModel.setZpkUnderLMK(tempKeyModel.getZpkUnderLMK());
                                keyModel.setZpkUnderZMK(tempKeyModel.getZpkUnderZMK());
                                keyModel.setZpkKCV(tempKeyModel.getZpkKCV());
                                keyModel.setZakUnderLMK(tempKeyModel.getZakUnderLMK());
                                keyModel.setZakUnderZMK(tempKeyModel.getZakUnderZMK());
                                keyModel.setZakKCV(tempKeyModel.getZakKCV());
                                keyModel.setZekUnderLMK(tempKeyModel.getZekUnderLMK());
                                keyModel.setZekUnderZMK(tempKeyModel.getZekUnderZMK());
                                keyModel.setZekKCV(tempKeyModel.getZekKCV());

                                Map<String, KeyModel> tempKeyData = new HashMap<>();
                                tempKeyData.put(pojoResponse.getSource().substring(0, pojoResponse.getSource().length()-1), keyModel);
                                eftposKeyModel.setTargetKey(tempKeyData);

                                eftposKeyModel.setKeySetId(pojoResponse.getSecurityControlInfo());
                                eftposKeyModel.setSignonKey(false);
                                SpringContextBridge.services().getCacheService().updateEftposKeyDetails(pojoResponse.getSource().substring(0, pojoResponse.getSource().length()-1), eftposKeyModel);
                            }
                        }

                        if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(pojoResponse.getTargetType().name()) &&
                                "0820".equalsIgnoreCase(pojoResponse.getMsgType()) && "002".equalsIgnoreCase(pojoResponse.getNetworkMgmtInfoCode())){
                        	RouteUtil.updateEndPointSignOnStatusByEpName(targetEpEntries, endpointMetaData.getEpName().substring(0, endpointMetaData.getEpName().length() -1), false);
                            SpringContextBridge.services().getCacheService().putSignOffStatus(true, pojoResponse.getSource());
                        }
                        boolean signOnSignOffModel=  SpringContextBridge.services().getCacheService().getSignOffStatus(pojoResponse.getSource());
                        if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(pojoResponse.getTargetType().name()) &&
                                "0800".equalsIgnoreCase(pojoResponse.getMsgType()) && "001".equalsIgnoreCase(pojoResponse.getNetworkMgmtInfoCode()) && signOnSignOffModel == true){
                            SpringContextBridge.services().getCacheService().putEftposSignOnStatus(true, pojoResponse.getSource());
                        }

    				}
    			} catch (Exception exception) {
    				logger.error("Error occurred", exception.getStackTrace());
    			}
    			break;
    		}
    	}

    	NettyCamelState state = null;
        if (!(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(pojoResponse.getTargetType().name()) && ("0800".equals(pojoResponse.getMsgType()) || "0820".equals(pojoResponse.getMsgType())))) {
            state = super.getState(ctx, channel, msg);
            /*
             *  State is null if txn Response Time > Timeout time .......generate reversal
             * */
            if (state == null) {
                handleTimedOutResponse((byte[]) msg, targetRemoteAdd);
            }
        }
    	MtmUtil.clearLoggerContext();
    	return state;
    }

    private void processBqrSwitchTxn(Object msg, String targetRemoteAdd, Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries, String key, EndpointMetaData endpointMetaData) {
        TransactionMessageModel bqrRequestTmm = parseBqrRawMsg(msg, endpointMetaData);
        bqrRequestTmm.setSourceProcessor(SourceProcessor.BQR_SWITCH);
        if (TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(bqrRequestTmm.getMsgType())
                || TmmConstants.RES_NW_MGMT_MSG_TYPE.equals(bqrRequestTmm.getMsgType())) {
            processSchemeResponse(msg, targetRemoteAdd, targetEpEntries, key, endpointMetaData,
                    bqrRequestTmm);
        } else {
            bqrSwitchTransactionProcessorStatic.processTxnRequest(bqrRequestTmm, targetRemoteAdd, targetEpEntries, this.getCamelContext());
        }
    }

    private void processSchemeResponse(Object msg, final String targetRemoteAdd,
                                       Set<Map.Entry<String, Map<String, EndpointMetaData>>> targetEpEntries, String key,
                                       EndpointMetaData endpointMetaData, TransactionMessageModel pojoResponse) {
    	
    	this.correlationId = pojoResponse.getRetrievalRefNo();
    	EndpointMetaData epByAcqId = endpointMetaData;

    	if (pojoResponse.getAquirerIdCode() != null) {
    		if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(endpointMetaData.getTargetType())){
    			this.correlationId = pojoResponse.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + pojoResponse.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR + pojoResponse.getStan();
    		} else {
    			this.correlationId = pojoResponse.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + pojoResponse.getRetrievalRefNo();
    		}
    		epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, pojoResponse.getAquirerIdCode(), targetRemoteAdd);
    		if (epByAcqId != null) {
    			pojoResponse.setEntityId(epByAcqId.getEntityId());
    			pojoResponse.setSource(epByAcqId.getEpName());
    			logger.trace("Corrected Entity Id for the Response from {} to {}", endpointMetaData.getEntityId(), pojoResponse.getEntityId());
    		}
    	}
    	if (TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(pojoResponse.getMsgType())
    			|| TmmConstants.REQ_RECONCILE_MSG_TYPE.equals(pojoResponse.getMsgType()) ||
    			(TmmConstants.REQ_NW_MGMT_MSG_TYPE_EFTPOS.equals(pojoResponse.getMsgType())
    					&& (pojoResponse.getNetworkMgmtInfoCode().equals("101") || pojoResponse.getNetworkMgmtInfoCode().equals("002")))){

    		EndpointMetaData finalEpByAcqId = epByAcqId;
    		ExecutorService executorService = RouteUtil.getExecutorService();
    		executorService.submit(() -> {
    			if (!TmmConstants.REQ_RECONCILE_MSG_TYPE.equals(pojoResponse.getMsgType())) {
    				setTxnCategory(key, pojoResponse);
    			}
    			processSchemeNwMgmtResponse(pojoResponse.getEntityId(), pojoResponse.getSource(), targetRemoteAdd,
    					(byte[]) msg, finalEpByAcqId.getTargetConfigModel(), pojoResponse.getTransactionName());
    			if(TmmConstants.REQ_NW_MGMT_MSG_TYPE_EFTPOS.equals(pojoResponse.getMsgType()) && "002".equals(pojoResponse.getNetworkMgmtInfoCode())) {
    				//endpointMetaData.setSignedOn(false);
    				RouteUtil.updateEndPointSignOnStatusByEpName(targetEpEntries, endpointMetaData.getEpName().substring(0, endpointMetaData.getEpName().length() -1), false);
    			}
    		});
    	} else if (this.correlationId == null) {
    		this.correlationId = pojoResponse.getStan();
    	}

    	logger.trace(
    			buildLogMessage(pojoResponse.getEntityId(), pojoResponse.getSource(), pojoResponse.getMsgType(),
    					pojoResponse.getTransactionId(), "Correlation Id in getState(): {}"), this.correlationId);
    }

    private TransactionMessageModel parseBqrRawMsg(Object msg, EndpointMetaData endpointMetaData) {
        TransactionMessageModel bqrRequestTmm = MessageTransformer
                .toPojo(endpointMetaData.getEntityId(), OffsetDateTime.now(), endpointMetaData.getEpName(), (byte[]) msg, TlmMessageType.REQUEST, null);

        String txnId = Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
        bqrRequestTmm.setEpType(EpType.TARGET);
        bqrRequestTmm.setTransactionId(txnId);
        bqrRequestTmm.setRawRequest(TxnLogger.encryptRawMsg((byte[]) msg));

        return bqrRequestTmm;
    }


    private void handleTimedOutResponse(byte[] msg, String remoteAdd) {
        for (Map.Entry<String, Map<String, EndpointMetaData>> entry : RoutingInitializationContext.getTargetEndpointInfoMap().entrySet()) {
            Map<String, EndpointMetaData> endpointMetaDataMap = entry.getValue();
            EndpointMetaData endpointMetaData = endpointMetaDataMap.get(remoteAdd);
            if (endpointMetaData != null) {
                try {
                    TransactionMessageModel pojoRsp = MessageTransformer.toResponsePojo(null, null, msg, null);

                    pojoRsp.setTransactionId(generateTransactionId());
                    pojoRsp.setSourceProcessor(endpointMetaData.getSourceProcessor());
                    RouteUtil.logToTlmForAutoReversal(pojoRsp);
                    if (pojoRsp.getResCode().equals(TmmConstants.RES_CODE_SUCCESS) &&
                            TmmConstants.getTxnEligibleForAutoReversal().contains(pojoRsp.getTransactionName())) {
                        /**
                         *  Using targetIpAndPort for sending target IP through Kafka so that we can generate reversal.
                         *  TODO : Design a new approach to generate reversal for late or no response from Target..
                         *  Note : Using Kafka for generating reversal is not proper approach.
                         */

                        pojoRsp.setTargetIpAndPort(remoteAdd);
                        ExecutorService executorService = RouteUtil.getExecutorService();
                        executorService.submit(() -> {
                        	transactionProcessorHelperStatic.generateAutoReversalTxn(pojoRsp, pojoRsp.getSourceProcessor(), pojoRsp.getTransactionName());
                        });
//                        RoutingInitializationContext.getKafkaReversalProducer().sendMessage(pojoRsp, pojoRsp.getTransactionId());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    private void setTxnCategory(String entityId, TransactionMessageModel pojoResponse) {
        /*
         * Schemes Signon and HeartBeat messages, process request and send response,
         * don't maintain Netty Camel State
         */
        if (pojoResponse.getTargetType().equals(TargetType.Visa)) {
            if (isVisaEchoMsg(pojoResponse.getNetworkMgmtInfoCode())) {
                pojoResponse.setTransactionCategory(TransactionCategory.HEARTBEAT);
            } else if (isVisaSigOn(pojoResponse.getNetworkMgmtInfoCode())) {
                pojoResponse.setTransactionCategory(TransactionCategory.SIGNON);
            } else if (isVisaSigOff(pojoResponse.getNetworkMgmtInfoCode())) {
                pojoResponse.setTransactionCategory(TransactionCategory.SIGNOFF);
            }

        } else if (pojoResponse.getTargetType().equals(TargetType.Master)) {

            switch (pojoResponse.getNetworkMgmtInfoCode()) {
                case TmmConstants.MASTERCARD_SCHEME_INIT_KEY_EXCHANGE_NW_INFO_CODE:
                    TlvDataList tlv = new TlvDataList(pojoResponse.getPrivateAd(), 2, 2);
                    String dynamicKey = tlv.getTagValue("11").substring(6, 38);
                    getKeyFromHSMandStoreInDynamicKeyMap(pojoResponse, dynamicKey, entityId);
                    break;

                case TmmConstants.MASTERCARD_ECHO_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.HEARTBEAT);
                    break;

                case TmmConstants.MASTERCARD_SIGNON_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNON);
                    break;

                case TmmConstants.MASTERCARD_SIGNOFF_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNOFF);
                    break;

                default:
                    break;
            }

        } else if (pojoResponse.getTargetType().equals(TargetType.Rupay)) {

            switch (pojoResponse.getNetworkMgmtInfoCode()) {
                case TmmConstants.RUPAY_SCHEME_INIT_KEY_EXCHANGE_NW_MGMT_CODE:
                    String dynamicKey = pojoResponse.getPrivateAd().substring(0, 32);
                    getKeyFromHSMandStoreInDynamicKeyMap(pojoResponse, dynamicKey, entityId);
                    break;

                case TmmConstants.RUPAY_CUT_OVER_NW_MGMT_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.CUTOVER);
                    break;

                case TmmConstants.RUPAY_ECHO_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.HEARTBEAT);
                    break;

                case TmmConstants.RUPAY_SIGNON_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNON);
                    break;

                case TmmConstants.RUPAY_SIGNOFF_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNOFF);
                    break;

                default:
                    break;
            }
        } else if (pojoResponse.getTargetType().equals(TargetType.EftPos)) {

            switch (pojoResponse.getNetworkMgmtInfoCode()) {

                case TmmConstants.EFTPOS_KEYEXCHANE_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.DYNAMIC_KEY_EXCHANGE);
                    break;

                case TmmConstants.EFTPOS_HEARTBEAT_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.HEARTBEAT);
                    break;

                case TmmConstants.EFTPOS_SIGNON_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNON);
                    break;

                case TmmConstants.EFTPOS_SIGNOFF_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNOFF);
                    break;

                default:
                    break;
            }
        } else if (pojoResponse.getTargetType().equals(TargetType.Amex)) {

            switch (pojoResponse.getNetworkMgmtInfoCode()) {
                case TmmConstants.AMEX_KEY_EXCHANGE_NW_INFO_CODE:
                	pojoResponse.setTransactionCategory(TransactionCategory.DYNAMIC_KEY_EXCHANGE);
                    break;

                case TmmConstants.AMEX_ECHO_MESSAGE_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.HEARTBEAT);
                    break;

                case TmmConstants.AMEX_SIGNON_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNON);
                    break;

                case TmmConstants.AMEX_SIGNOFF_NW_INFO_CODE:
                    pojoResponse.setTransactionCategory(TransactionCategory.SIGNOFF);
                    break;

                default:
                    break;
            }
        }
    }

    private void processSchemeNwMgmtResponse(String entityId, String epId, String remoteAdd, byte[] rawMsg, TargetConfigModel targetConfigModel, String txnName) {
        TransactionMessageModel pojoReq = MessageTransformer.toResponsePojo(entityId, epId, rawMsg, txnName);

        String txnId = Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
        pojoReq.setTransactionId(txnId);
        pojoReq.setTlmMessageType(TlmMessageType.REQUEST);

        if (!(TmmConstants.REQ_RECONCILE_MSG_TYPE.equals(pojoReq.getMsgType())
        		|| TmmConstants.RES_RECONCILE_MSG_TYPE.equals(pojoReq.getMsgType()))) {
            setTxnCategory(entityId, pojoReq);
        }
        logger.trace("{} Msg Request Tmm: {}", pojoReq.getTransactionCategory(), pojoReq);

        logToTlm(pojoReq);

        // setting the res code as success
        pojoReq.setResCode(TmmConstants.RES_CODE_SUCCESS);
        //TODO: to set source processor in exchange header and then take it from there
        pojoReq.setSourceProcessor(SourceProcessor.POS_SWITCH);
        pojoReq.setForwardingInstIdCode(targetConfigModel.getAdditionalData().getFwdInstId());
        pojoReq.setSignOnId(targetConfigModel.getAdditionalData().getSignOnId());
        
        MessageContext tgtMsgCtx = MessageTransformer.constructMessage(pojoReq, epId);
        NettyEndpoint nEp = NettyConfig.getProducerEndpoint(this.getCamelContext(), remoteAdd, targetConfigModel);
        String corrId = null;
        if (pojoReq.getRetrievalRefNo() != null)
            corrId = pojoReq.getRetrievalRefNo();
        if (corrId == null && pojoReq.getStan() != null)
            corrId = pojoReq.getStan();
        if (corrId == null)
            corrId = new StringBuilder().append(TmmConstants.RES_NW_MGMT_MSG_TYPE).append(".").append(entityId)
                    .append(".").append(epId).toString();

        RoutingInitializationContext.getMwProducer().justSendMessage(tgtMsgCtx.getRawMsg(), corrId, nEp);
        String successMsg = "Successfully sent";
        String failureMsg = "Failed to send";

        TransactionMessageModel responseTargetTmm = tgtMsgCtx.getTransactionMessageModel();

        String reqAsRes = pojoReq.getTransactionName().replace("request", "response");
        responseTargetTmm.setTransactionName(reqAsRes);
        responseTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        responseTargetTmm.setResponseSentTime(OffsetDateTime.now());

        TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) tgtMsgCtx.getRawMsg(), responseTargetTmm);

        logger.trace("{} Msg Response Tmm: {}", responseTargetTmm.getTransactionCategory(), responseTargetTmm);

        logToTlm(responseTargetTmm);

        logger.trace(LogUtils.buildLogMessage(entityId, epId, TmmConstants.RES_NW_MGMT_MSG_TYPE,
                pojoReq.getTransactionId(), successMsg));
    }

    @Override
    public String getResponseCorrelationId(Object response) {
        return this.correlationId;
    }

    /*
     * To store only the Cut over network message in the Db for MTI= 800. To store
     * the request and response both in the database using this method.
     *
     */
    private void logToTlm(TransactionMessageModel tmm) {
        if (isRupayCutOverMsg(tmm)) {

            String epId = tmm.getSource() == null ? tmm.getTarget() : tmm.getSource();
            logger.debug(buildLogMessage(tmm.getEntityId(), epId, null, tmm.getTransactionId(),
                    "Logging transaction to TLM"));
            KafkaProducer kafkaProducer = RoutingInitializationContext.getKafkaProducer();
            logger.trace("Tlm Message Type of transaction: {}", tmm.getTlmMessageType());
            kafkaProducer.sendMessage(tmm, tmm.getTransactionId());
        }
    }

    private void getKeyFromHSMandStoreInDynamicKeyMap(TransactionMessageModel pojoResponse, String dynamicKey,
                                                      String entityId) {

        pojoResponse.setTransactionCategory(TransactionCategory.DYNAMIC_KEY_EXCHANGE);
        HsmVendor hsmVendor = SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(pojoResponse.getEntityId());
        IPinTranslationService pinTranslationService = SpringContextBridge
                .getPinTranslationService(hsmVendor, PinTranslationType.DYNAMIC);

        String translatedDynamicKey = pinTranslationService.keyTranslation(entityId, pojoResponse.getSource(),
                pojoResponse.getSource(), dynamicKey);

        if (translatedDynamicKey != null && translatedDynamicKey.length() > 32) {
            /*
             * Exclude KCV ( Key Check Value ) i.e Last Six Digit.
             */
            SpringContextBridge.services().getMwRedisCacheUtil().
                    putTargetDynamicKeyData(pojoResponse.getEntityId() + "_" + hsmVendor + TmmConstants.DYNAMIC_KEY,
                            pojoResponse.getTargetType(), translatedDynamicKey.substring(0, translatedDynamicKey.length() - 6));
        }
    }

    private String generateTransactionId() {
        return Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        RoutingCorrelationManager.applicationContext = applicationContext;

    }
}
