package com.isg.mw.routing.exception;

public class MacValidationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public MacValidationException(String errorMsg) {
        super(errorMsg);
    }

    public MacValidationException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }
}
