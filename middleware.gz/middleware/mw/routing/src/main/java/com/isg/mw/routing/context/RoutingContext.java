package com.isg.mw.routing.context;

import java.util.List;
import java.util.Map;

import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.routing.smartroute.SmartRouteSchedulerService;
import org.apache.camel.CamelContext;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RoutingContext {

    private String entityId;
    private SourceConfigModel source;
    private List<TargetConfigModel> targets;
    private ConnectionType connectionType;
    private boolean isTxnLoggingDebug;
    private boolean isTxnLoggingOn;
    private CamelContext camelContext;
    private List<MessageTransformationConfigModel> msgTransformationDefinitions;
    private Map<String, Boolean> targetSignOnFlag;
    private SmartRouteConfigModel smartRouteConfigModel;
    private SmartRouteSchedulerService smartRouteSchedulerService;
}
