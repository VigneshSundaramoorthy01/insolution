package com.isg.mw.routing.smartroute;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.cache.mgmt.config.*;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.common.CheckBITransactionResponse;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.common.VizpayCheckTransactionResponse;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.construct.sr.SmartRouteMsgTypeHelper;
import com.isg.mw.core.model.icici.LyraCheckTxnStatusResponse;
import com.isg.mw.core.model.icici.UpiResponse;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.pg.*;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.PaymentLinksModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.*;
import com.isg.mw.mtm.config.EncryptService;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.exception.*;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.transform.icici.IciciMessageTransformation;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import com.isg.mw.mtm.transform.payu.PayUMessageTransformation;
import com.isg.mw.mtm.transform.tpsl.TpslMessageTransformation;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.RefundAmountExceededException;
import com.isg.mw.routing.route.SwitchRouter;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.regex.Pattern;

import static com.isg.mw.core.model.constants.CommonConstants.REFUND_TXN;
import static com.isg.mw.core.model.constants.CommonConstants.REVERSAL_TXN;
import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;
import static com.isg.mw.mtm.transform.TmmConstants.getTxnEligibleForAutoReversal;
import static com.isg.mw.routing.APEncrypt.decryptMerchantEncryptedRequest;
import static com.isg.mw.routing.config.RoutingConstants.*;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_REQ_SRC_TMM;

@Component
public class SmartRouteTxnController {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    @Lazy
    private CacheUtil cacheUtil;

    @Autowired
    private CacheHelper cacheHelper;

    @Autowired
    private CacheServices cacheServices;

    @Autowired
    private SmartRouteSpringCacheService srCacheServices;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Autowired
    private ApiTransactionProcessor apiTransactionProcessor;

    @Autowired
    private SmartRouteTxnHelperController smartRouteTxnHelperController;

    @Autowired
    private EncryptService encryptionService;

    @Autowired
    private SwitchRouter switchRouterService;

    @Autowired
    private SmartRouteSpringCacheService srCacheService;

    @Value("${threshold.value:3}")
    private int threshold;

    /*
     * URL to get merchant convenience fee details
     */
    @Value("${smartroute.conveniencefee.check.api}")
    private String checkConvenienceFeeApi;

    @Value("${smartroute.conveniencefee.get.details.api}")
    private String getDetailsConvenienceFeeApi;

    private ISmartRoute smartRoute;

    public String getTargetLcr(Exchange exchange,RoutingContext routingContext) {
        SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
        smartRoute = SmartRouteFactory.getSmartRoute(smartRouteConfigModel.getRouteType());
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateRequest(exchange);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_API_TXN_MODEL, apiTxnModel);
        TargetConfigModel txnTarget = smartRoute.getTxnTarget(exchange,null);
        String apiResponse = apiTransactionProcessor.getEncryptedApiResponse(ResponseMsgType.SUCCESS, null, txnTarget.getName(), null, exchange);
        logger.trace("Least cost target: {}", txnTarget.getName());
        return apiResponse;
    }

    public  Map<String, Object>  verifyVPA(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) {
        Map<String, Object> resDataMap =null;
        SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
        smartRoute = SmartRouteFactory.getSmartRoute(smartRouteConfigModel.getRouteType());
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        String txnId = generateTransactionId();
        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setRequestReceivedTime(OffsetDateTime.now());
        reqSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
        reqSrcTmm.setEntityId(routingContext.getEntityId());
        reqSrcTmm.setSource(routingContext.getSource().getName());
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_API_TXN_MODEL, apiTxnModel);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        TargetConfigModel txnTarget = smartRoute.getTxnTarget(exchange,reqSrcTmm);
        reqSrcTmm.setTarget(txnTarget.getName());
        CacheTargetMerchantMaster cacheTargetMerchantMaster = srCacheServices.getTargetMerchantMasterModel(txnTarget.getId().toString(), reqSrcTmm.getCardAcceptorId(),reqSrcTmm.getCardAcceptorTerminalId());
        reqSrcTmm.setTargetMid(cacheTargetMerchantMaster.getTargetMid());
        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(txnTarget.getName());
        String txnTypeName = null;
        Set<String> txnNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                .get(targetType + "." + apiTxnModel.getMsgType() + "." + apiTxnModel.getPayModeId());
        
        if (txnNameSet.size() == 1) {
        	txnTypeName = txnNameSet.stream().findFirst().orElse(null);
        } else if (txnNameSet.size() > 1 && StringUtils.isNotBlank(reqSrcTmm.getTransactionName()) ) {
        	txnTypeName = txnNameSet.stream().filter(str -> str.equals(reqSrcTmm.getTransactionName().replace("request", "response"))).findAny()
  		  .orElse(null);
        }
        
        reqSrcTmm.setTransactionName(txnTypeName);
        if (txnTarget != null && txnTarget.getAdditionalData().getMerchantOnboardFlag().equalsIgnoreCase("Y")) {
            CacheTargetMerchantMaster targetMerchantMaster = srCacheServices.getTargetMerchantMasterModel(String.valueOf(txnTarget.getId()), reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId());
            if (targetMerchantMaster == null || !targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                resDataMap = new HashMap<>();
                Long paymentModeId = Long.valueOf(apiTxnModel.getPayModeId());
                PaymentModesModel paymentMode = srCacheService.getPaymentMode(paymentModeId);
                ResponseObj responseObj = new ResponseObj();
                ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                ResponseObj.RedirectEvent redirEvent = new ResponseObj.RedirectEvent();
                retryEvent.setRetryFlag(CommonConstants.N);
                redirEvent.setTargetUrl(apiTxnModel.getMerchantReturnUrl());
                responseObj.setStatusCode("03");
                responseObj.setMsg(paymentMode.getPaymentModeName() +" transactions is unavailable");
                responseObj.setRedirectEvent(redirEvent);
                responseObj.setRetryEvent(retryEvent);
                logger.info("Target " + txnTarget.getId() + " is unavailable");
                resDataMap.put("responseObj", responseObj);
                return resDataMap;
            }
        }
        processorHelper.processNormalTxn(exchange, reqSrcTmm);
        return resDataMap;
    }

    public Map<String, Object> getTargetAndGenerateRequest(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) {
        SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();
        smartRoute = SmartRouteFactory.getSmartRoute(smartRouteConfigModel.getRouteType());
        String merchantOrderId = apiTxnModel.getMerchantTxnRefNo();
        String txnId = generateTransactionId();
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setRequestReceivedTime(OffsetDateTime.now());
        reqSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
        reqSrcTmm.setEntityId(routingContext.getEntityId());
        if(!StringUtils.isBlank(apiTxnModel.getLinkHashId())){
            PaymentLinksModel paymentLinksModel = new PaymentLinksModel();
            paymentLinksModel.setLinkHashId(apiTxnModel.getLinkHashId());
            paymentLinksModel =(PaymentLinksModel) smartRouteTxnHelperController.fetchPaymentLinksModel(paymentLinksModel,"get.payment.link.tlm.api",false);
            reqSrcTmm.setMobileNo(paymentLinksModel.getMobileNo());
            reqSrcTmm.setEmail(paymentLinksModel.getEmailId());
        }
        if (!StringUtils.isBlank(apiTxnModel.getCardNo())) {
            reqSrcTmm.setEncryptedPan(encryptionService.encrypt(apiTxnModel.getCardNo().replaceAll(" ", "")));
            String expiryDate = apiTxnModel.getExpiryDate().replaceAll("\\s+", "").replaceAll("\u2002","");
            String[] split = expiryDate.split("/");
            //set expiryDate in YYMM format
            reqSrcTmm.setEncryptedExpirationDate(encryptionService.encrypt(split[0]+split[1]));
        }
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_API_TXN_MODEL, apiTxnModel);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        if(apiTxnModel.getPayModeId().equalsIgnoreCase("0")){
            throw new TransactionCencelException("Transaction Cancel",routingContext.getEntityId(), apiTxnModel.getMid(), merchantOrderId);
        }
        // mid, txnAmt, payMode, payModeOption
        TargetConfigModel txnTarget = smartRoute.getTxnTarget(exchange,reqSrcTmm);
        if (txnTarget != null && txnTarget.getAdditionalData().getMerchantOnboardFlag().equalsIgnoreCase("Y")) {
            CacheTargetMerchantMaster targetMerchantMaster = processorHelper.fetchCacheTargetMerchantMaster(String.valueOf(txnTarget.getId()), reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId());
            if (targetMerchantMaster == null || !targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                Long paymentModeId = Long.valueOf(apiTxnModel.getPayModeId());
                PaymentModesModel paymentMode = srCacheService.getPaymentMode(paymentModeId);
                Map<String, Object> resDataMap = new HashMap<>();
                ResponseObj responseObj = new ResponseObj();
                ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
                ResponseObj.RedirectEvent redirEvent = new ResponseObj.RedirectEvent();
                retryEvent.setRetryFlag(CommonConstants.N);
                responseObj.setStatusCode("03");
                responseObj.setMsg(paymentMode.getPaymentModeName() +" transactions is unavailable");
                responseObj.setRedirectEvent(redirEvent);
                responseObj.setRetryEvent(retryEvent);
                logger.info("Target " + txnTarget.getId() + " is unavailable");
                resDataMap.put("responseObj", responseObj);
                return resDataMap;
            }
        }
        cacheUtil.incrementTargetTotalTxnCount(cacheHelper.getTargetMapKey(routingContext.getSource()),
                new TargetKey(txnTarget.getId().toString()));
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, txnTarget.getId());
        // putting the retry count in cache
        ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
        ResponseObj.RedirectEvent redirEvent = new ResponseObj.RedirectEvent();
        MerchOrdTxnData merchOrdTxnData = cacheUtil.getTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), merchantOrderId);
        setMerchantEncReqRes(apiTxnModel.getMid(), reqSrcTmm, merchOrdTxnData);
        if (merchOrdTxnData == null) {
            merchOrdTxnData = new MerchOrdTxnData();
            merchOrdTxnData.setTerminalId(apiTxnModel.getTid());
            merchOrdTxnData.setMerchantId(apiTxnModel.getMid());
            merchOrdTxnData.setCreatedAt(OffsetDateTime.now());
            merchOrdTxnData.setTxnStatus("Pending");
        }
        if (merchOrdTxnData.getTxnDataMapModel() == null) {
            merchOrdTxnData.setRetryCount(1);
            merchOrdTxnData.setMerchantId(apiTxnModel.getMid());
            merchOrdTxnData.setMerchantReturnUrl(apiTxnModel.getMerchantReturnUrl());
            merchOrdTxnData.setTxnFailedReturnUrl(apiTxnModel.getTxnFailedReturnUrl());
            //Implementing TxnData map
            MerchOrdTxnData.TxnData txnData = new MerchOrdTxnData.TxnData("Pending");
            txnData.setTargetId(txnTarget.getId().toString());
            txnData.setOriginalHashedTxnId(processorHelper.getHashedValue(txnId));
            txnData.setTargetName(txnTarget.getName());
            txnData.setTargetType(txnTarget.getTargetType());
            txnData.setTxnAmt(apiTxnModel.getTxnAmt());
            txnData.setPayModeId(apiTxnModel.getPayModeId());
            txnData.setMerchantTxnRefNo(merchantOrderId);
            txnData.setCustomerVpa(apiTxnModel.getCustomerVpa());
            txnData.setTxnId(txnId);
            Map<String, MerchOrdTxnData.TxnData> txnMap = new HashMap<>();
            txnMap.put(txnId, txnData);
            merchOrdTxnData.setTxnDataMapModel(txnMap);
            cacheUtil.putTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), merchantOrderId, merchOrdTxnData);
            //Implementing retryEvent in ResponseObj
            Map<String, String> retryData = new HashMap<>();
            retryData.put("merchantId", apiTxnModel.getMid());
            retryData.put("encData", merchOrdTxnData.getEncData());
            retryData.put("bankId", merchOrdTxnData.getBankId());
            retryData.put("terminalId", merchOrdTxnData.getTerminalId());
            retryEvent.setRetryData(retryData);
            retryEvent.setRetryFlag(CommonConstants.Y);
        } else if (merchOrdTxnData != null) {
//            if (merchOrdTxnData.getRetryCount() >= 3 && (txnTarget.getAdditionalData().getPaymentSource() != null
//             && txnTarget.getAdditionalData().getPaymentSource().equalsIgnoreCase("upi"))) {
//                //decline the txn with retry count exhausted
//                Map<String, Object> resDataMap = new HashMap<>();
//                Map<String, Object> resData = new HashMap<>();
//                Map<String, String> retryData = new HashMap<>();
//                Map<String, String> redirectEvent = new HashMap<>();
//                Map<String, Object> retryedEvent = new HashMap<>();
//                ResponseObj responseObj = new ResponseObj();
//                MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
//                MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(merchOrdTxnData.getEncData(),
//                        merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
//                MerchantEncDataResponse merchantEncDataResponse= new MerchantEncDataResponse();
//                merchantEncDataResponse = merchantEncDataResponse.getMerchantDataRes(merchantEncDataRequest);
//                merchantEncDataResponse.setMessage("RetryCount for this merchantOrderId : " + merchantOrderId + " is exceeded.");
//                merchantEncDataResponse.setStatus(PaymentStatus.FAILED.name());
//                String encMerchantData = apiTransactionProcessor.encryptMerchantData(merchantEncDataResponse, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
//                responseObj.setStatusCode("03");
//                responseObj.setMsg("RetryCount for this merchantOrderId : " + merchantOrderId + " is exceeded.");
//                retryData.put("MerchantId", apiTxnModel.getMid());
//                retryData.put("EncData", encMerchantData);
//                retryData.put("BankId", merchOrdTxnData.getBankId());
//                retryData.put("TerminalId", merchOrdTxnData.getTerminalId());
//                retryedEvent.put("retryData",retryData);
//                retryedEvent.put("retryFlag",CommonConstants.N);
//                resData.put("retryEvent",retryedEvent);
//                resData.put("retryCount","3");
//                redirectEvent.put("targetUrl",merchOrdTxnData.getMerchantReturnUrl());
//                resData.put("redirectEvent",redirectEvent);
//                responseObj.setData(resData);
//                resDataMap.put("responseObj", responseObj);
//                //Following Condition Required
//                //cacheUtil.removeTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), merchantOrderId);
//                return resDataMap;
//            }
            boolean isSuccessTxnExist = false;
            Map<String, Object> resDataMap = new HashMap<>();
            isSuccessTxnExist = isSuccessTxnExist(merchOrdTxnData, isSuccessTxnExist);
            if (isSuccessTxnExist) {
                ResponseObj responseObj = new ResponseObj();
                responseObj.setStatusCode("03");
                responseObj.setMsg("Payment for this " + merchantOrderId + " is already processed.");
                resDataMap.put("responseObj", responseObj);
                return resDataMap;
            } else {
                MerchOrdTxnData.TxnData txnData = new MerchOrdTxnData.TxnData("Pending");
                txnData.setTargetId(txnTarget.getId().toString());
                txnData.setTargetName(txnTarget.getName());
                txnData.setTargetType(txnTarget.getTargetType());
                txnData.setOriginalHashedTxnId(processorHelper.getHashedValue(txnId));
                txnData.setTxnId(txnId);
                txnData.setTxnAmt(apiTxnModel.getTxnAmt());
                txnData.setPayModeId(apiTxnModel.getPayModeId());
                txnData.setMerchantTxnRefNo(apiTxnModel.getMerchantTxnRefNo());
                txnData.setCustomerVpa(apiTxnModel.getCustomerVpa());
                merchOrdTxnData.getTxnDataMapModel().put(txnId, txnData);
                int retryCount = merchOrdTxnData.getRetryCount() + 1;
                merchOrdTxnData.setRetryCount(retryCount);
                apiTxnModel.setPaymentAttemptCounter(String.valueOf(retryCount));
                cacheUtil.putTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), merchantOrderId, merchOrdTxnData);
                Map<String, String> retryData = new HashMap<>();
                retryData.put("merchantId", apiTxnModel.getMid());
                retryData.put("encData", merchOrdTxnData.getEncData());
                retryData.put("bankId", merchOrdTxnData.getBankId());
                retryData.put("terminalId", merchOrdTxnData.getTerminalId());
                retryEvent.setRetryData(retryData);
                retryEvent.setRetryFlag(CommonConstants.Y);
            }
        }
        setMerchantOrdEncDataToReqSrcTmm(merchOrdTxnData.getEncData(),reqSrcTmm);
//        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setTarget(txnTarget.getName());
        reqSrcTmm.setEntityId(routingContext.getEntityId());
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        reqSrcTmm.setSource(routingContext.getSource().getName());
        MapsInfoModel mapsInfoModel = cacheServices.validateAndGetMerchant(routingContext.getEntityId(), reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId(), null);
//        reqSrcTmm.setTxnCurrencyCode(mapsInfoModel.getAcquirerCurrencyCode());

        CacheTargetMerchantMaster cacheTargetMerchantMaster = srCacheServices.getTargetMerchantMasterModel(txnTarget.getId().toString(), reqSrcTmm.getCardAcceptorId(),reqSrcTmm.getCardAcceptorTerminalId());
        reqSrcTmm.setTargetMid(cacheTargetMerchantMaster.getTargetMid());
        if(!StringUtils.isBlank(reqSrcTmm.getSmartRouteData().getPayModeOptionId())){
            PaymentModeOptionsModel paymentModeOption = srCacheService.getPaymentModeOption(Long.valueOf(reqSrcTmm.getSmartRouteData().getPayModeOptionId()));
            reqSrcTmm.getSmartRouteData().setIssuerName(paymentModeOption.getModeOptionName());
        }

        reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
        reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));

        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(txnTarget.getName());
        String txnTypeName = null;
        Set<String> txnNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                .get(targetType + "." + apiTxnModel.getMsgType() + "." + apiTxnModel.getPayModeId());
        
        if (txnNameSet.size() == 1) {
        	txnTypeName = txnNameSet.stream().findFirst().orElse(null);
        } else if (txnNameSet.size() > 1 && StringUtils.isAllEmpty(reqSrcTmm.getTransactionName()) ) {
        	txnTypeName = txnNameSet.stream().filter(str -> str.equals(reqSrcTmm.getTransactionName().replace("request", "reponse"))).findAny()
  		  .orElse(null);
        }
        
        reqSrcTmm.setTransactionName(txnTypeName);

        processorHelper.processNormalTxn(exchange, reqSrcTmm);
        TransactionMessageModel body = exchange.getIn().getBody(TransactionMessageModel.class);

        Map<String, Object> resDataMap = new HashMap<>();

        ResponseObj.RedirectEvent redirectEvent = new ResponseObj.RedirectEvent();
        redirectEvent.setTargetUrl(body.getSmartRouteData().getRedirectUrl() != null ?
                body.getSmartRouteData().getRedirectUrl() :
                body.getIciciNbCorporateUrl());
        redirectEvent.setTargetEncFormData(body.getSmartRouteData().getRedirectData());
        logger.trace("Redirect Url with Data :: "+redirectEvent.getTargetUrl(),redirectEvent.getTargetEncFormData());
        ResponseObj.PaymentData paymentData = new ResponseObj.PaymentData();
        paymentData.setTxnid(body.getTransactionId());
        resDataMap.put("paymentData", paymentData);
        resDataMap.put("redirectEvent", redirectEvent);
        resDataMap.put("retryEvent", retryEvent);
        return resDataMap;
    }

    public boolean isSuccessTxnExist(MerchOrdTxnData merchOrdTxnData, boolean isSuccessTxnExist) {
        Map<String, MerchOrdTxnData.TxnData> txnDataMapModel = merchOrdTxnData.getTxnDataMapModel();
        if (txnDataMapModel != null && !txnDataMapModel.isEmpty()) {
            for (Map.Entry<String, MerchOrdTxnData.TxnData> dataModelEntry : txnDataMapModel.entrySet()) {
                if (dataModelEntry.getValue().getTxnStatus().equalsIgnoreCase("Success")) {
                    isSuccessTxnExist = true;
                    break;
                }
            }
        }
        return isSuccessTxnExist;
    }

    public boolean isRetryExceeded(MerchOrdTxnData merchOrdTxnData, boolean isRetryExceeded) {
        Map<String, MerchOrdTxnData.TxnData> txnDataMapModel = merchOrdTxnData.getTxnDataMapModel();
        if (txnDataMapModel != null && !txnDataMapModel.isEmpty()) {
            if (merchOrdTxnData.getRetryCount() >= 3) {
                isRetryExceeded = true;
            }
        }
        return isRetryExceeded;
    }

    private void setMerchantOrdEncDataToReqSrcTmm(String encData, TransactionMessageModel reqSrcTmm) {
        MerchantEncDataRequest merchantEncDataRequest;
        MapsInfoModel mapsInfoModel = processorHelper.validateMerchant(reqSrcTmm.getEntityId(), reqSrcTmm.getCardAcceptorId(),reqSrcTmm.getCardAcceptorTerminalId());
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(reqSrcTmm.getEntityId(), reqSrcTmm.getCardAcceptorId());
        merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(encData,
                merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
        reqSrcTmm.setMobileNo(!StringUtils.isBlank(reqSrcTmm.getMobileNo()) ? reqSrcTmm.getMobileNo() : merchantEncDataRequest.getPhone());
        reqSrcTmm.setEmail(!StringUtils.isBlank(reqSrcTmm.getEmail()) ? reqSrcTmm.getEmail() : merchantEncDataRequest.getEmail());
        reqSrcTmm.setFirstName(!StringUtils.isBlank(merchantEncDataRequest.getFirstName()) ? merchantEncDataRequest.getFirstName(): mapsInfoModel.getMerchantName());
        reqSrcTmm.setLastName(merchantEncDataRequest.getLastName());
        reqSrcTmm.setStreet(merchantEncDataRequest.getStreet());
        reqSrcTmm.setCity(!StringUtils.isBlank(merchantEncDataRequest.getCity()) ? merchantEncDataRequest.getCity() : mapsInfoModel.getMerchantCity());
        reqSrcTmm.setState(merchantEncDataRequest.getState());
        reqSrcTmm.setZip(merchantEncDataRequest.getZip());
        reqSrcTmm.setUDF01(merchantEncDataRequest.getUdf01());
        reqSrcTmm.setUDF02(merchantEncDataRequest.getUdf02());
        reqSrcTmm.setUDF03(merchantEncDataRequest.getUdf03());
        reqSrcTmm.setUDF04(merchantEncDataRequest.getUdf04());
        reqSrcTmm.setUDF05(merchantEncDataRequest.getUdf05());
        reqSrcTmm.setUDF06(merchantEncDataRequest.getUdf06());
        reqSrcTmm.setUDF07(merchantEncDataRequest.getUdf07());
        reqSrcTmm.setUDF08(merchantEncDataRequest.getUdf08());
        reqSrcTmm.setUDF09(merchantEncDataRequest.getUdf09());
        reqSrcTmm.setUDF10(merchantEncDataRequest.getUdf10());
        reqSrcTmm.setCustomerRemarks(merchantEncDataRequest.getOrderInfo());
        reqSrcTmm.setMerchantCountryCode(mapsInfoModel.getMerchantShortCountryCode());
        reqSrcTmm.setMerchantURL(merchantMaster.getMerchantURL());

    }

    public void setMerchantEncReqRes(String mid, TransactionMessageModel reqSrcTmm, MerchOrdTxnData merchOrdTxnData) {
        MerchantEncReqRes merchantEncReqRes = new MerchantEncReqRes();
        merchantEncReqRes.setMerchantId(mid);
        merchantEncReqRes.setBankId(merchOrdTxnData.getBankId());
        merchantEncReqRes.setTerminalId(merchOrdTxnData.getTerminalId());
        merchantEncReqRes.setEncData(merchOrdTxnData.getEncData());
        reqSrcTmm.setMerchantIntegrationReqRes(merchantEncReqRes);
    }

    public String getTargetAndGenerateRequestEnc(Exchange exchange, RoutingContext routingContext) throws JsonProcessingException, NoSuchAlgorithmException {
        ApiTxnModel apiTxnModel;
        String decryptSmartRouteReq = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(decryptSmartRouteReq, exchange);
        Map<String, Object> resDataMap = getTargetAndGenerateRequest(exchange, routingContext, apiTxnModel);
        setPaymentStatus(null,apiTxnModel, PaymentStatus.INITIATED);
        String targetAndGenerateResponse = getTargetAndGenerateResponse(exchange, routingContext, apiTxnModel, resDataMap);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, targetAndGenerateResponse);
    }

    public String getTargetAndGenerateRequest(Exchange exchange, RoutingContext routingContext) throws JsonProcessingException {
        String apiRequest = exchange.getIn().getBody(String.class);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        Map<String, Object> resDataMap = getTargetAndGenerateRequest(exchange, routingContext, apiTxnModel);
        setPaymentStatus(null,apiTxnModel, PaymentStatus.INITIATED);
        return getTargetAndGenerateResponse(exchange, routingContext, apiTxnModel, resDataMap);
    }

    public String getTargetAndGenerateResponse(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel, Map<String, Object> resDataMap) throws JsonProcessingException {
        String apiResponse;
        if ("4".equals(apiTxnModel.getPayModeId()) && TmmConstants.isIciciUpiMsgType(apiTxnModel.getMsgType())) {
            if (resDataMap != null) {
                if (resDataMap.get("responseObj") != null) {
                    ResponseObj responseObj = (ResponseObj) resDataMap.get("responseObj");
                    if (!"00".equalsIgnoreCase(responseObj.getStatusCode())) {
                        return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, null, resDataMap);
                    }
                }
            }
            TransactionMessageModel resTargetTmm = exchange.getIn().getBody(TransactionMessageModel.class);
            UpiResponse upiResponse = resTargetTmm.getUpiResponse();
            Map<String, Object> upiResMap = getUpiResMap(routingContext, apiTxnModel, resDataMap, upiResponse,resTargetTmm);
            if(upiResponse.getSuccess().equalsIgnoreCase("false")){
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage(), upiResMap);
                //setPaymentStatus(resDataMap, apiTxnModel, PaymentStatus.INITIATED);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, upiResponse.getMessage(), upiResMap);
                //setPaymentStatus(resDataMap, apiTxnModel, PaymentStatus.INITIATED);
            }
        } else {
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, null, resDataMap);
        }
        return apiResponse;
    }

    private Map<String, Object> getUpiResMap(RoutingContext routingContext, ApiTxnModel apiTxnModel, Map<String, Object> resDataMap,
                                             UpiResponse upiResponse,TransactionMessageModel resTargetTmm) throws JsonProcessingException {
        MerchantMasterModel masterModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchantMaster(resTargetTmm.getEntityId(), resTargetTmm.getCardAcceptorId());
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> upiResMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {});;
        ResponseObj.RedirectEvent redirectEvent = (ResponseObj.RedirectEvent) resDataMap.get("redirectEvent");
        ResponseObj.RetryEvent retryEvent = (ResponseObj.RetryEvent) resDataMap.get("retryEvent");
        MerchOrdTxnData merchOrdTxnData = cacheUtil.getTxnData(routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
        if(upiResponse.getSuccess().equalsIgnoreCase("false")){
            Map<String, String> retryData = retryEvent.getRetryData();
            retryData.put("encData", merchOrdTxnData.getEncData());
            retryData.put("bankId", merchOrdTxnData.getBankId());
            retryEvent.setRetryFlag("Y");
            retryEvent.setRetryData(retryData);
            redirectEvent.setTargetUrl(merchOrdTxnData.getTxnFailedReturnUrl());
        }else{
            retryEvent.setRetryFlag("N");
            redirectEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
            upiResMap.put("customerVpa",apiTxnModel.getCustomerVpa());
            upiResMap.put("merchnatName",masterModel.getMerchantName());
            upiResMap.put("currency",resTargetTmm.getTxnCurrencyCode());
        }
        upiResMap.put("retryEvent", retryEvent);
        upiResMap.put("redirectEvent", redirectEvent);
        upiResMap.put("txnId",resTargetTmm.getHashedTransactionId());
        if (IciciMsgType.UpiQR.msgType.equalsIgnoreCase(apiTxnModel.getMsgType())) {
            String qrData = getQRData(routingContext,upiResponse, resTargetTmm,masterModel);
            upiResMap.put("qrData", qrData);
        }
        return upiResMap;
    }
    public static String getQRData(RoutingContext routingContext, UpiResponse upiResponse, TransactionMessageModel resTargetTmm, MerchantMasterModel masterModel) {
        ///pay?pa=testiclt2@icici&pn=PGINSTAZERO&tr=CLT220429162107667599&am=235.00&cu=INR&mc=8299

        TargetConfigModel targetConfigModel = routingContext.getTargets().stream().filter(target-> target.getTargetType() == TargetType.Icici &&
                "upi".equalsIgnoreCase(target.getAdditionalData().getPaymentSource())).findFirst().get();

        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(targetConfigModel.getName());

        CacheTargetMerchantMaster targetMerchantMaster = SpringContextBridge.services().getSrCacheService().getTargetMerchantMasterModel(targetId, resTargetTmm.getCardAcceptorId(),
                resTargetTmm.getCardAcceptorTerminalId());

        StringBuilder sb = new StringBuilder();
        sb.append("pay?")
                .append("pa="+targetMerchantMaster.getMerchantVpa())
                .append("&pn=" + masterModel.getMerchantName())
                .append("&tr="+ "EPG"+resTargetTmm.getTransactionId())
                .append("&am="+IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(resTargetTmm.getTxnAmt()))
                .append("&cu=INR")
                .append("&mc="+masterModel.getMccCode());
        return sb.toString();
    }

    public String generateReversal(Exchange exchange) {
        String apiRequest = exchange.getIn().getBody(String.class);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        logger.trace("createRefund Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        Map<String, Object> resDataMap = new HashMap<>();
        String apiResponse = null;
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
        apiTxnModel.setMsgType(REVERSAL_TXN);
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        if (!Pattern.matches("^[0-9]*", reqSrcTmm.getTxnAmt())) {
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Transaction Amount Is Not Valid", null);
            return apiResponse;
        }
        String txnId = generateTransactionId();
        reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
        reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));
        reqSrcTmm.setOriginalHashedTxnId(processorHelper.getHashedValue(apiTxnModel.getOriginalHashedTxnId()));
        reqSrcTmm.setRequestReceivedTime(OffsetDateTime.now());
        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        reqSrcTmm.setMerchantTxnRefNo(String.valueOf(processorHelper.generateMerchantTxnRefNo()));
        resDataMap.put("RefundTxnId", txnId);
        TransactionMessageModel originalTmm = fetchOriginalTransaction(reqSrcTmm);
        TransactionMessageModel.SmartRouteData originalSRData = originalTmm.getSmartRouteData();
        if (originalSRData != null && (originalSRData.getPayModeId().equalsIgnoreCase("5")
                || originalSRData.getPayModeId().equalsIgnoreCase("6") ||
                originalSRData.getPayModeId().equalsIgnoreCase("7"))) {
            throw new InvalidRefundTransactionException("Refund Not Applicable For Offline Transaction.");
        }
        if (originalTmm != null) {
            logger.info("Calling Refund API Without Fund Transfer : ");
            processorHelper.validateRefundRequest(reqSrcTmm, originalTmm);
            TargetConfigModel tgtEndPoint = switchRouterService.getTargetEndpoint(routingContext, exchange,
                    reqSrcTmm);
            ConnectionType targetConnectionType = tgtEndPoint.getConnections().get(0).getType();
            if (targetConnectionType == ConnectionType.API) {
                processorHelper.processAPIRequest(exchange, reqSrcTmm, routingContext, tgtEndPoint);
            }
            TransactionMessageModel body = (TransactionMessageModel) exchange.getIn().getBody();
            if (body.getResCode().equalsIgnoreCase("00")) {
                logger.info("Refund has been initiated successfully : ");
                originalTmm.setDrcrFlag("R");
                originalTmm.setTlmMessageType(TlmMessageType.REQUEST);
                originalTmm.setTargetType(body.getTargetType());
                //SET TXN_MSG_MODEL
                SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_REQ,originalTmm);
                logger.info(LogUtils.buildSMLogMessage(originalTmm.getEntityId(),originalTmm.getMerchantTxnRefNo(),originalTmm.getTransactionId(),
                                originalTmm.getTransactionName(),"Refund has been initiated successfully  : {}"), originalTmm);
                processorHelper.logToTlm(originalTmm, routingContext);
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund has been initiated successfully", resDataMap);
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed", resDataMap);
            }
        } else {
            throw new InvalidVoidOrReversalDataException("NotFound");
        }
        return apiResponse;
    }

    public String createRefundEnc(Exchange exchange) throws JsonProcessingException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("createRefundEnc Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        exchange.getIn().setBody(IsgJsonUtils.getJsonString(apiTxnModel));
        String apiResponse = createRefund(exchange);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String createRefund(Exchange exchange) throws JsonProcessingException {
        String apiRequest = exchange.getIn().getBody(String.class);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        logger.trace("createRefund Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        MerchantMasterModel merchantMaster;
        try {
            merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
        } catch (Exception e) {
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Merchant " + apiTxnModel.getMid() + " Is Invalid", null);
        }
        if (StringUtils.isBlank(merchantMaster.getAccountNo())) {
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Merchant account details are missing", null);
        }
        if (merchantMaster != null && "PG".equalsIgnoreCase(merchantMaster.getIntegrationType())) {
            if ("Y".equalsIgnoreCase(MTMProperties.getProperty("sr.pg.refund.enable"))) {
                return createRefund(exchange, apiTxnModel);
            }else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "PG Refund Disable", null);
            }
        } else if (merchantMaster != null && "POS".equalsIgnoreCase(merchantMaster.getIntegrationType())) {
            if ("Y".equalsIgnoreCase(MTMProperties.getProperty("sr.pos.refund.enable"))) {
                return createPosRefund(exchange, apiTxnModel);
            } else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "POS Refund Disable", null);
            }
        } else {
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Integration Type For Mid " + apiTxnModel.getMid() + " Is Invalid", null);
        }
    }

    public String createRefund(Exchange exchange,ApiTxnModel apiTxnModel) throws JsonProcessingException {
        String apiResponse = null;
        Map<String, Object> resDataMap = new HashMap<>();
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        if("R".equalsIgnoreCase(apiTxnModel.getDrCrFlag())){
            apiTxnModel.setMsgType(REVERSAL_TXN);
        }else {
            apiTxnModel.setMsgType(REFUND_TXN);
        }
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL,apiTxnModel);
        String txnId = generateTransactionId();
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        if(StringUtils.isBlank(reqSrcTmm.getTxnAmt())){
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Transaction Amount Is Mandatory", null);
            return apiResponse;
        }else if(!Pattern.matches("^[0-9]*", reqSrcTmm.getTxnAmt())){
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Transaction Amount Is Not Valid", null);
            return apiResponse;
        }
        reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
        reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));
        reqSrcTmm.setOriginalHashedTxnId(processorHelper.getHashedValue(apiTxnModel.getOriginalHashedTxnId()));
        reqSrcTmm.setOriginalTransactionId(apiTxnModel.getOriginalHashedTxnId());
        reqSrcTmm.setRequestReceivedTime(OffsetDateTime.now());
        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        reqSrcTmm.setMerchantTxnRefNo(String.valueOf(processorHelper.generateMerchantTxnRefNo()));
        resDataMap.put("RefundTxnId", txnId);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        processorHelper.processNormalTxn(exchange, reqSrcTmm);
        String creditAccNo = (String) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_FUND_TRANSFER_BANK_ACC_NO);
        JSONObject fundTransferResp = (JSONObject)exchange.getIn().getHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE);
        if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable")) && fundTransferResp == null) {
            logger.info("Initial Fund Transfer Failed : ");
            reqSrcTmm.setResCode("91");
            reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
            reqSrcTmm.setErrorDescription("Initial Fund Transfer Failed");
            reqSrcTmm.setReasonCode("91");
            //SET TXN_MSG_MODEL
            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
            logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                    reqSrcTmm.getTransactionName(),"Initial Fund Transfer Failed  : {}"), reqSrcTmm);
            processorHelper.logToTlm(reqSrcTmm, routingContext);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Initial Fund Transfer Failed.", null);
        } else {
            TransactionMessageModel body = exchange.getIn().getBody(TransactionMessageModel.class);
            if (body.getSmartRouteData() != null && "4".equals(body.getSmartRouteData().getPayModeId()) && TmmConstants.isIciciUpiMsgType(body.getMsgType())) {
                logger.info("Calling Refund For UPI : ");
                UpiResponse upiResponse = body.getUpiResponse();
                ObjectMapper mapper = new ObjectMapper();
                Map<String, Object> upiResMap = null;
                upiResMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {});
                upiResMap.put("RefundTxnId",txnId);
                if ("true".equalsIgnoreCase(upiResponse.getSuccess()) && "0".equalsIgnoreCase(upiResponse.getActCode())) {
                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund has been initiated successfully", upiResMap);
                } else {
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                    if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable"))) {
                        JSONObject transferApiRes = processorHelper.callFundTransferApi("PG",body, creditAccNo,
                                merchantMaster.getAccountNo(), reqSrcTmm.getTxnAmt(),null);
                        if (transferApiRes != null) {
                            String actCode = fundTransferResp.getJSONObject("ActCode").get("#text").toString();
                            if (actCode.equalsIgnoreCase("000") || actCode.equalsIgnoreCase("913")) {
                                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage() + " :: Refund has been failed and Fund rollback successfully.", upiResMap);
                            } else {
                                reqSrcTmm.setResCode("91");
                                reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                reqSrcTmm.setReasonCode("91");
                                //SET TXN_MSG_MODEL
                                logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                        reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                processorHelper.logToTlm(reqSrcTmm, routingContext);
                                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage() + " :: Refund has been failed and Fund rollback failed.", upiResMap);
                            }
                        } else {
                            reqSrcTmm.setResCode("91");
                            reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                            reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                            reqSrcTmm.setReasonCode("91");
                            //SET TXN_MSG_MODEL
                            logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                    reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed : {}"), reqSrcTmm);
                            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                            processorHelper.logToTlm(reqSrcTmm, routingContext);
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage() + " :: Refund has been failed and Fund rollback failed.", upiResMap);
                        }
                    } else {
                        logger.info("Refund has been failed without fund transfer api call :");
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed.", upiResMap);
                    }
                }
            } else {
                try{
                    if (body.getResCode().equalsIgnoreCase("00")) {
                        logger.info("Refund has been initiated successfully : ");
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund has been initiated successfully", resDataMap);
                    } else if ((IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(body.getMsgType()) ||
                            IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(body.getMsgType()) && !body.getResCode().equalsIgnoreCase("00"))) {
                        logger.info("Refund has been failed : ");
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed ", resDataMap);
                    } else {
                        if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable"))) {
                            MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                            JSONObject transferApiRes = processorHelper.callFundTransferApi("PG", body, creditAccNo,
                                    merchantMaster.getAccountNo(), reqSrcTmm.getTxnAmt(),null);
                            try {
                                if (transferApiRes != null) {
                                    String actCode = transferApiRes.getJSONObject("ActCode").get("#text").toString();
                                    logger.info("Fund Rollback Act Code Text : {} ", actCode);
                                    if (actCode.equalsIgnoreCase("000") || actCode.equalsIgnoreCase("913")) {
                                        logger.info("Refund has been failed and fund rollback successful : ");
                                        reqSrcTmm.setResCode("91");
                                        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                        reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                        reqSrcTmm.setReasonCode("91");
                                        //SET TXN_MSG_MODEL
                                        logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                                reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                        processorHelper.logToTlm(reqSrcTmm, routingContext);
                                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback successfully.", resDataMap);
                                    } else {
                                        logger.info("Refund has been failed and fund rollback failed : ");
                                        reqSrcTmm.setResCode("91");
                                        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                        reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                        reqSrcTmm.setReasonCode("91");
                                        //SET TXN_MSG_MODEL
                                        logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                                reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                        processorHelper.logToTlm(reqSrcTmm, routingContext);
                                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback failed.", resDataMap);
                                    }
                                } else {
                                    logger.info("Refund has been failed and fund rollback failed :");
                                    reqSrcTmm.setResCode("91");
                                    reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                    reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                    reqSrcTmm.setReasonCode("91");
                                    //SET TXN_MSG_MODEL
                                    logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                            reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                    SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                    processorHelper.logToTlm(reqSrcTmm, routingContext);
                                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback failed.", resDataMap);

                                }
                            } catch (Exception e) {
                                logger.info("Refund has been failed and Fund rollback failed. :");
                                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback failed.", resDataMap);
                            }
                        } else {
                            logger.info("Refund has been failed without fund transfer api call :");
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed.", resDataMap);
                        }
                    }
                }catch (Exception e){
                    logger.info("Failed To Call Refund Api :");
                    e.printStackTrace();
                }

            }
        }
        return apiResponse;
    }

    public String createRefundFromMerchantKitEnc(Exchange exchange,Boolean isMerchantKitReq) throws JsonProcessingException, NoSuchAlgorithmException {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("createRefundEnc Body: {}", apiRequest);
        apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        MerchantCheckStatusAndRefundReq refundDataReq = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantCheckStatusAndRefundReq.class);
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
        JSONObject jsonObject = new JSONObject(apiRequest);
        String secureHash = apiTransactionProcessor.generateMerchantSecureHash(jsonObject, merchantMaster.getSecretKey());
        String apiResponse = null;
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantRefundRes refundDataRes = new MerchantRefundRes();
        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
        refundDataRes.setRespDate(OffsetDateTime.now());
        refundDataRes.setRespTime(OffsetDateTime.now());
        if (isMerchantKitReq) {
            String invalidData = null ;
            if(!"Refund".equalsIgnoreCase(refundDataReq.getTxnType())){
                invalidData = "Txn Type is invalid,It should be Pay or Refund";
            }if("Refund".equalsIgnoreCase(refundDataReq.getTxnType())){
                invalidData = apiTransactionProcessor.validateMerchantKitJson(refundDataReq, CacheSrConfigProperties.getProperty("smartroute.refund.api.validation"));
            }
            if(!StringUtils.isBlank(invalidData)){
                refundDataRes.setMessage(invalidData);
                refundDataRes.setStatus(PaymentStatus.FAILED.name());
                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                resDataMap.put("refundDataRes", refundDataRes);
                if (isMerchantKitReq) {
                    return IsgJsonUtils.getJsonString(refundDataRes);
                } else {
                    return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, invalidData, resDataMap);
                }
            }
        }
        if (isMerchantKitReq && !secureHash.equalsIgnoreCase(refundDataReq.getSecureHash().toLowerCase())) {
            refundDataRes.setMessage("Invalid Secure Hash");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if (isMerchantKitReq) {
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Invalid Secure Hash", resDataMap);
            }
            return apiResponse;
        }
        ApiTxnModel apiTxnModel = new ApiTxnModel();
        apiTxnModel.setMid(refundDataReq.getMerchantId());
        apiTxnModel.setTid(refundDataReq.getTerminalId());
        apiTxnModel.setOriginalHashedTxnId(processorHelper.getHashedValue(refundDataReq.getRetRefNo()));
        apiTxnModel.setTxnAmt(refundDataReq.getRefundAmount());
        apiTxnModel.setMerchantTxnRefNo(refundDataReq.getRefCancelId());
        if (StringUtils.isBlank(merchantMaster.getAccountNo())) {
            refundDataRes.setMessage("Merchant account details are missing");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if (isMerchantKitReq) {
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Merchant account details are missing", resDataMap);
            }
            return apiResponse;
        }
        if (merchantMaster != null && "PG".equalsIgnoreCase(merchantMaster.getIntegrationType())) {
            apiResponse = createRefundFromMerchantKit(exchange, apiTxnModel, refundDataReq, isMerchantKitReq);
        } else if (merchantMaster != null && "POS".equalsIgnoreCase(merchantMaster.getIntegrationType())) {
            return createPosRefundFromMerchantKit(exchange, apiTxnModel,refundDataReq, isMerchantKitReq);
        } else {
            refundDataRes.setMessage("Integration Type For Mid " + apiTxnModel.getMid() + " Is Invalid");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Integration Type For Mid " + apiTxnModel.getMid() + " Is Invalid", resDataMap);
        }
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String createRefundFromMerchantKit(Exchange exchange,Boolean isMerchantKitReq) throws JsonProcessingException {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("createRefund Body: {}", apiRequest);
        MerchantCheckStatusAndRefundReq refundDataReq = IsgJsonUtils.getObjectFromJsonString(apiRequest, MerchantCheckStatusAndRefundReq.class);
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
        JSONObject jsonObject = new JSONObject(apiRequest);
        String secureHash = apiTransactionProcessor.generateMerchantSecureHash(jsonObject, merchantMaster.getSecretKey());
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantRefundRes refundDataRes = new MerchantRefundRes();
        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
        refundDataRes.setRespDate(OffsetDateTime.now());
        refundDataRes.setRespTime(OffsetDateTime.now());
        if (isMerchantKitReq && !secureHash.equalsIgnoreCase(refundDataReq.getSecureHash().toLowerCase())) {
            refundDataRes.setMessage("Invalid Secure Hash");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if (isMerchantKitReq) {
                return IsgJsonUtils.getJsonString(refundDataRes);
            } else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Invalid Secure Hash", resDataMap);
            }
        }
        ApiTxnModel apiTxnModel = new ApiTxnModel();
        apiTxnModel.setMid(refundDataReq.getMerchantId());
        apiTxnModel.setTid(refundDataReq.getTerminalId());
        apiTxnModel.setOriginalHashedTxnId(processorHelper.getHashedValue(refundDataReq.getRetRefNo()));
        apiTxnModel.setTxnAmt(refundDataReq.getRefundAmount());
        apiTxnModel.setMerchantTxnRefNo(refundDataReq.getRefCancelId());

        if (StringUtils.isBlank(merchantMaster.getAccountNo())) {
            refundDataRes.setMessage("Merchant account details are missing");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if (isMerchantKitReq) {
                return IsgJsonUtils.getJsonString(refundDataRes);
            } else {
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Merchant account details are missing", resDataMap);
            }
        }
        if (merchantMaster != null && "PG".equalsIgnoreCase(merchantMaster.getIntegrationType())) {
            if ("Y".equalsIgnoreCase(MTMProperties.getProperty("sr.pg.refund.enable"))) {
                return createRefundFromMerchantKit(exchange, apiTxnModel, refundDataReq, isMerchantKitReq);
            }else{
                refundDataRes.setMessage("PG Refund Disable");
                refundDataRes.setStatus(PaymentStatus.FAILED.name());
                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                resDataMap.put("refundDataRes", refundDataRes);
                if (isMerchantKitReq) {
                    return IsgJsonUtils.getJsonString(refundDataRes);
                }
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "PG Refund Disable", resDataMap);
            }
        } else if (merchantMaster != null && "POS".equalsIgnoreCase(merchantMaster.getIntegrationType())) {
            if ("Y".equalsIgnoreCase(MTMProperties.getProperty("sr.pos.refund.enable"))) {
                return createPosRefundFromMerchantKit(exchange, apiTxnModel,refundDataReq, isMerchantKitReq);
            }else {
                refundDataRes.setMessage("POS Refund Disable");
                refundDataRes.setStatus(PaymentStatus.FAILED.name());
                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                resDataMap.put("refundDataRes", refundDataRes);
                if (isMerchantKitReq) {
                    return IsgJsonUtils.getJsonString(refundDataRes);
                }
                return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "POS Refund Disable", resDataMap);
            }
        } else {
            refundDataRes.setMessage("Integration Type For Mid " + apiTxnModel.getMid() + " Is Invalid");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if (isMerchantKitReq) {
                return IsgJsonUtils.getJsonString(refundDataRes);
            }
            return apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Integration Type For Mid " + apiTxnModel.getMid() + " Is Invalid", resDataMap);
        }
    }



    public String createRefundFromMerchantKit(Exchange exchange,ApiTxnModel apiTxnModel,MerchantCheckStatusAndRefundReq refundDataReq,Boolean isMerchantKitReq) throws JsonProcessingException {
        String apiResponse = null;
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        apiTxnModel.setMsgType(REFUND_TXN);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL,apiTxnModel);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_SMART_ROUTE_REFUND_REQ,refundDataReq);
        String txnId = generateTransactionId();
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        OffsetDateTime refundTxnReqTime = OffsetDateTime.now();
        if(StringUtils.isBlank(reqSrcTmm.getTxnAmt())){
            Map<String, Object> resDataMap = new HashMap<>();
            MerchantRefundRes refundDataRes = new MerchantRefundRes();
            refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
            refundDataRes.setRespDate(refundTxnReqTime);
            refundDataRes.setRespTime(refundTxnReqTime);
            refundDataRes.setMessage("Transaction Amount Is Mandatory");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if(isMerchantKitReq){
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Transaction Amount Is Mandatory", resDataMap);
            }
            return apiResponse;
        }else if(!Pattern.matches("^[0-9]*", reqSrcTmm.getTxnAmt())){
            Map<String, Object> resDataMap = new HashMap<>();
            MerchantRefundRes refundDataRes = new MerchantRefundRes();
            refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
            refundDataRes.setRespDate(refundTxnReqTime);
            refundDataRes.setRespTime(refundTxnReqTime);
            refundDataRes.setMessage("Transaction Amount Is Not Valid");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if(isMerchantKitReq){
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Transaction Amount Is Not Valid", resDataMap);
            }
            return apiResponse;
        }
        reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
        reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));
        reqSrcTmm.setRequestReceivedTime(refundTxnReqTime);
        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setOriginalTransactionId(refundDataReq.getRetRefNo());
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        try {
            Boolean isPresent = (Boolean)smartRouteTxnHelperController.getTmmByTxnRefNo(refundDataReq.getRefCancelId(), null, null, refundDataReq.getMerchantId(), refundDataReq.getTerminalId());
            if(isPresent){
                throw new InvalidVoidOrReversalDataException("RefCancelId is already present");
            }
            TransactionMessageModel originalTmm = fetchOriginalTransaction(reqSrcTmm);
            if (originalTmm != null) {
                if (!originalTmm.getMerchantTxnRefNo().equalsIgnoreCase(refundDataReq.getTxnRefNo())) {
                    throw new InvalidVoidOrReversalDataException("TxnRefNo is invalid");
                }
            } else {
                throw new InvalidVoidOrReversalDataException("NotFound");
            }
            processorHelper.processNormalTxn(exchange, reqSrcTmm);
        }catch (Exception e){
            String exceptionMsg = e.getMessage();
            Map<String, Object> resDataMap = new HashMap<>();
            MerchantRefundRes refundDataRes = new MerchantRefundRes();
            refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
            refundDataRes.setRespDate(refundTxnReqTime);
            refundDataRes.setRespTime(refundTxnReqTime);
            switch (e.getClass().getSimpleName()) {
                case "RefundAmountExceededException":
                case "AccountDetailsMissingException":
                case "InvalidVoidOrReversalDataException":
                case "ChargebackFoundException":
                case "InvalidRefundTransactionException":
                case "TransactionDateExceededException":
                    refundDataRes.setRetRefNo(refundDataReq.getRetRefNo());
                    break;
                default:
                    refundDataRes.setRetRefNo(txnId);
                    break;
            }
            refundDataRes.setMessage(exceptionMsg);
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if(isMerchantKitReq){
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, exceptionMsg, resDataMap);
            }
            return apiResponse;
        }
        String creditAccNo = (String) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_FUND_TRANSFER_BANK_ACC_NO);
        JSONObject fundTransferResp = (JSONObject)exchange.getIn().getHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE);
        if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable")) && fundTransferResp == null) {
            logger.info("Initial Fund Transfer Failed : ");
            reqSrcTmm.setResCode("91");
            reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
            reqSrcTmm.setErrorDescription("Initial Fund Transfer Failed");
            reqSrcTmm.setReasonCode("91");
            //SET TXN_MSG_MODEL
            logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                    reqSrcTmm.getTransactionName(),"Initial Fund Transfer Failed  : {}"), reqSrcTmm);
            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
            processorHelper.logToTlm(reqSrcTmm, routingContext);
            Map<String, Object> resDataMap = new HashMap<>();
            MerchantRefundRes refundDataRes = new MerchantRefundRes();
            refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
            refundDataRes.setRespDate(refundTxnReqTime);
            refundDataRes.setRespTime(refundTxnReqTime);
            refundDataRes.setRetRefNo(txnId);
            refundDataRes.setMessage("Initial Fund Transfer Failed.");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
            resDataMap.put("refundDataRes", refundDataRes);
            if(isMerchantKitReq){
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Initial Fund Transfer Failed.", resDataMap);
            }
        } else {
            TransactionMessageModel body = exchange.getIn().getBody(TransactionMessageModel.class);
            if (body.getSmartRouteData() != null && "4".equals(body.getSmartRouteData()) && TmmConstants.isIciciUpiMsgType(apiTxnModel.getMsgType())) {
                logger.info("Calling Refund For UPI : ");
                UpiResponse upiResponse = body.getUpiResponse();
                ObjectMapper mapper = new ObjectMapper();
                Map<String, Object> upiResMap = null;
                upiResMap = mapper.readValue(IsgJsonUtils.getJsonString(upiResponse), new TypeReference<Map<String, Object>>() {});
                if ("true".equalsIgnoreCase(upiResponse.getSuccess()) && "0".equalsIgnoreCase(upiResponse.getActCode())) {
                    MerchantRefundRes refundDataRes = new MerchantRefundRes();
                    refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
                    refundDataRes.setRespDate(refundTxnReqTime);
                    refundDataRes.setRespTime(refundTxnReqTime);
                    refundDataRes.setRetRefNo(txnId);
                    refundDataRes.setMessage("Refund has been initiated successfully");
                    refundDataRes.setStatus(PaymentStatus.SUCCESS.name());
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                    upiResMap.put("refundDataRes", refundDataRes);
                    if(isMerchantKitReq){
                        apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                    }else{
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund has been initiated successfully", upiResMap);
                    }
                }else {
                    MerchantRefundRes refundDataRes = new MerchantRefundRes();
                    refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
                    refundDataRes.setRespDate(refundTxnReqTime);
                    refundDataRes.setRespTime(refundTxnReqTime);
                    refundDataRes.setRetRefNo(txnId);
                    refundDataRes.setStatus(PaymentStatus.FAILED.name());
                    MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                    if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable"))) {
                        JSONObject transferApiRes = processorHelper.callFundTransferApi("PG",body, creditAccNo,
                                merchantMaster.getAccountNo(), reqSrcTmm.getTxnAmt(),null);
                        if (transferApiRes != null) {
                            String actCode = fundTransferResp.getJSONObject("ActCode").get("#text").toString();
                            if (actCode.equalsIgnoreCase("000") || actCode.equalsIgnoreCase("913")) {
                                refundDataRes.setMessage("Refund has been failed and Fund rollback successfully.");
                                upiResMap.put("refundDataRes", refundDataRes);
                                if(isMerchantKitReq){
                                    apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                                }else{
                                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage() + " :: Refund has been failed and Fund rollback successfully.", upiResMap);
                                }
                            } else {
                                reqSrcTmm.setResCode("91");
                                reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                reqSrcTmm.setReasonCode("91");
                                //SET TXN_MSG_MODEL
                                logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                        reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                processorHelper.logToTlm(reqSrcTmm, routingContext);
                                refundDataRes.setMessage("Refund has been failed and Fund rollback failed.");
                                upiResMap.put("refundDataRes", refundDataRes);
                                if(isMerchantKitReq){
                                    apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                                }else{
                                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage() + " :: Refund has been failed and Fund rollback failed.", upiResMap);
                                }
                            }
                        } else {
                            reqSrcTmm.setResCode("91");
                            reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                            reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                            reqSrcTmm.setReasonCode("91");
                            //SET TXN_MSG_MODEL
                            logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                    reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                            SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                            processorHelper.logToTlm(reqSrcTmm, routingContext);
                            refundDataRes.setMessage("Refund has been failed and Fund rollback failed.");
                            upiResMap.put("refundDataRes", refundDataRes);
                            if(isMerchantKitReq){
                                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                            }else{
                                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, upiResponse.getMessage() + " :: Refund has been failed and Fund rollback failed.", upiResMap);
                            }
                        }
                    }else{
                        logger.info("Refund has been failed without fund transfer api call :");
                        refundDataRes.setMessage("Refund has been failed.");
                        upiResMap.put("refundDataRes", refundDataRes);
                        if(isMerchantKitReq){
                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                        }else{
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed.", upiResMap);
                        }
                    }
                }
            } else {
                Map<String, Object> resDataMap = new HashMap<>();
                ResponseObj.PaymentData paymentData = new ResponseObj.PaymentData();
                paymentData.setTxnid(body.getOriginalHashedTxnId());
                MerchantRefundRes refundDataRes = new MerchantRefundRes();
                MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
                try{
                    if (body.getResCode().equalsIgnoreCase("00")) {
                        logger.info("Refund has been initiated successfully : ");
                        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
                        refundDataRes.setRespDate(refundTxnReqTime);
                        refundDataRes.setRespTime(refundTxnReqTime);
                        refundDataRes.setMessage("Refund has been initiated successfully");
                        refundDataRes.setStatus(PaymentStatus.SUCCESS.name());
                        refundDataRes.setRetRefNo(txnId);
                        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                        resDataMap.put("refundDataRes", refundDataRes);
                        if(isMerchantKitReq){
                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                        }else{
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund has been initiated successfully", resDataMap);
                        }
                    }  else if ((IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(body.getMsgType()) ||
                            IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(body.getMsgType()) && !body.getResCode().equalsIgnoreCase("00"))) {
                        logger.info("Refund has been failed : ");
                        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
                        refundDataRes.setRespDate(refundTxnReqTime);
                        refundDataRes.setRespTime(refundTxnReqTime);
                        refundDataRes.setMessage("Refund has been failed");
                        refundDataRes.setStatus(PaymentStatus.FAILED.name());
                        refundDataRes.setRetRefNo(txnId);
                        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                        resDataMap.put("refundDataRes", refundDataRes);
                        if(isMerchantKitReq){
                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                        }else{
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed ", resDataMap);
                        }
                    }else {
                        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
                        refundDataRes.setStatus(PaymentStatus.FAILED.name());
                        refundDataRes.setRespDate(refundTxnReqTime);
                        refundDataRes.setRespTime(refundTxnReqTime);
                        if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable"))) {
                            JSONObject transferApiRes = processorHelper.callFundTransferApi("PG",body,creditAccNo,
                                    merchantMaster.getAccountNo(),  reqSrcTmm.getTxnAmt(),null);
                            try {
                                if (transferApiRes != null) {
                                    String actCode = transferApiRes.getJSONObject("ActCode").get("#text").toString();
                                    logger.info("Fund Rollback Act Code Text : {} ", actCode);
                                    if (actCode.equalsIgnoreCase("000") || actCode.equalsIgnoreCase("913")) {
                                        logger.info("Refund has been failed and fund rollback successful : ");
                                        reqSrcTmm.setResCode("91");
                                        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                        reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                        reqSrcTmm.setReasonCode("91");
                                        //SET TXN_MSG_MODEL
                                        logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                                reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                        processorHelper.logToTlm(reqSrcTmm, routingContext);
                                        refundDataRes.setMessage("Refund has been failed and Fund rollback successfully.");
                                        refundDataRes.setRetRefNo(txnId);
                                        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                                        resDataMap.put("refundDataRes", refundDataRes);
                                        if(isMerchantKitReq){
                                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                                        }else{
                                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback successfully.", resDataMap);
                                        }
                                    } else {
                                        logger.info("Refund has been failed and fund rollback failed : ");
                                        reqSrcTmm.setResCode("91");
                                        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                        reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                        reqSrcTmm.setReasonCode("91");
                                        //SET TXN_MSG_MODEL
                                        logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                                reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                        processorHelper.logToTlm(reqSrcTmm, routingContext);
                                        refundDataRes.setMessage("Refund has been failed and Fund rollback failed.");
                                        refundDataRes.setRetRefNo(txnId);
                                        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                                        resDataMap.put("refundDataRes", refundDataRes);
                                        if(isMerchantKitReq){
                                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                                        }else{
                                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback failed.", resDataMap);
                                        }
                                    }
                                } else {
                                    logger.info("Refund has been failed and fund rollback failed :");
                                    reqSrcTmm.setResCode("91");
                                    reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
                                    reqSrcTmm.setErrorDescription("Refund has been failed and Fund rollback failed");
                                    reqSrcTmm.setReasonCode("91");
                                    //SET TXN_MSG_MODEL
                                    logger.info(LogUtils.buildSMLogMessage(reqSrcTmm.getEntityId(),reqSrcTmm.getMerchantTxnRefNo(),reqSrcTmm.getTransactionId(),
                                            reqSrcTmm.getTransactionName(),"Refund has been failed and Fund rollback failed  : {}"), reqSrcTmm);
                                    SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,reqSrcTmm);
                                    processorHelper.logToTlm(reqSrcTmm, routingContext);
                                    refundDataRes.setMessage("Refund has been failed and Fund rollback failed.");
                                    refundDataRes.setRetRefNo(txnId);
                                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                                    resDataMap.put("refundDataRes", refundDataRes);
                                    if(isMerchantKitReq){
                                        apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                                    }else{
                                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback failed.", resDataMap);
                                    }
                                }
                            } catch (Exception e) {
                                logger.info("Refund has been failed and Fund rollback failed. :");
                                refundDataRes.setMessage("Refund has been failed and Fund rollback failed.");
                                refundDataRes.setRetRefNo(txnId);
                                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                                resDataMap.put("refundDataRes", refundDataRes);
                                if(isMerchantKitReq){
                                    apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                                }else{
                                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed and Fund rollback failed.", resDataMap);
                                }
                            }
                        } else {
                            logger.info("Refund has been failed without fund transfer api call :");
                            refundDataRes.setMessage("Refund has been failed.");
                            refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                            refundDataRes.setRetRefNo(txnId);
                            resDataMap.put("refundDataRes", refundDataRes);
                            if(isMerchantKitReq){
                                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                            }else{
                                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund has been failed.", resDataMap);
                            }
                        }
                    }
                }catch (Exception e){
                    logger.info("Failed To Call Refund Api :");
                    refundDataRes.setMessage("Failed To Call Refund Api.");
                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes,merchantMaster.getSecretKey());
                    refundDataRes.setRetRefNo(txnId);
                    resDataMap.put("refundDataRes", refundDataRes);
                    if(isMerchantKitReq){
                        apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                    }else{
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Failed To Call Refund Api.", resDataMap);
                    }
                    e.printStackTrace();
                }

            }
        }
        return apiResponse;
    }

    public String createPosRefund(Exchange exchange, ApiTxnModel apiTxnModel){
        String apiResponse = null;
        apiTxnModel.setMsgType(REFUND_TXN);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        LyraMessageTransformation lyraMessageTransformation = new LyraMessageTransformation();
        CheckBITransactionResponse biTransactionResponse = callTransactionDetailsApi(lyraMessageTransformation, apiTxnModel);
        if (biTransactionResponse != null && biTransactionResponse.getData() != null && !biTransactionResponse.getData().isEmpty()) {
            CheckBITransactionResponse.Data data = biTransactionResponse.getData().get(0);
            if ("Cards".equalsIgnoreCase(data.getModeOfPayment())) {
                String cardChargeBack = processorHelper.callCardChargeBack(apiTxnModel.getOriginalHashedTxnId(), apiTxnModel.getTid());
                if (!StringUtils.isBlank(cardChargeBack) && "Y".equalsIgnoreCase(cardChargeBack)) {
                    throw new ChargebackFoundException("ChargeBack is initiated for given transaction id.");
                } else {
                    if ("0".equalsIgnoreCase(data.getTotalRefund())) {
                        validatePosRefundAmt(data.getTransactionAmount(),apiTxnModel);
                        apiResponse = initiatePosRefund(apiTxnModel, routingContext, lyraMessageTransformation, data,MTMProperties.getProperty("pos.sr.icici.fund.transfer.card.accno"));
                    } else {
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Already Processed", null);
                    }
                }
            } else if ("Upi".equalsIgnoreCase(data.getModeOfPayment())) {
                String upiChargeBack = processorHelper.callUpiChargeBack(apiTxnModel.getOriginalHashedTxnId(), apiTxnModel.getTid());
                if (!StringUtils.isBlank(upiChargeBack) && "Y".equalsIgnoreCase(upiChargeBack)) {
                    throw new ChargebackFoundException("ChargeBack is initiated for given transaction id.");
                } else {
                    if ("0".equalsIgnoreCase(data.getTotalRefund())) {
                        validatePosRefundAmt(data.getTransactionAmount(),apiTxnModel);
                        apiResponse = initiatePosRefund(apiTxnModel, routingContext, lyraMessageTransformation, data,MTMProperties.getProperty("pos.sr.icici.fund.transfer.upi.accno"));
                    } else {
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Already Processed", null);
                    }
                }
            }
        } else {
            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Original Txn Not Found.", null);
        }
        return apiResponse;
    }


    private String initiatePosRefund(ApiTxnModel apiTxnModel, RoutingContext routingContext, LyraMessageTransformation lyraMessageTransformation, CheckBITransactionResponse.Data data,String bankAccNo) {
        String apiResponse;
        if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pos.sr.icici.fund.transfer.enable"))) {
            MerchantMasterModel merchantMaster = SpringContextBridge.services().getCacheService().validateAndGetMerchantMaster(routingContext.getEntityId(), apiTxnModel.getMid());
            JSONObject fundTransferResp = processorHelper.callFundTransferApi("POS", apiTxnModel.buildTmm(), merchantMaster.getAccountNo(),bankAccNo
                    ,apiTxnModel.getTxnAmt(),data.getRefNo());
            if (fundTransferResp != null) {
                VizpayCheckTransactionResponse refundResponse = callPosRefund(lyraMessageTransformation, apiTxnModel,data);
                if (refundResponse != null && refundResponse.getRspCode() != null && refundResponse.getRspCode().equalsIgnoreCase("00")) {
                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund Successful.", refundResponse);
                } else {
                    JSONObject fundRollbackResp = processorHelper.callFundTransferApi("POS", apiTxnModel.buildTmm(),MTMProperties.getProperty("pos.sr.icici.fund.transfer.card.accno"),
                            merchantMaster.getAccountNo(), apiTxnModel.getTxnAmt(),data.getRefNo());
                    if (fundRollbackResp != null) {
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Failed And Fund Is Rollback Successfully.", fundRollbackResp);
                    } else {
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Failed And Fund Is Rollback Unsuccessfully.", fundRollbackResp);
                    }
                }
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Initial Fund Transfer Failed", null);
            }
        } else {
            VizpayCheckTransactionResponse refundResponse = callPosRefund(lyraMessageTransformation, apiTxnModel, data);
            if (refundResponse != null && refundResponse.getRspCode() != null && refundResponse.getRspCode().equalsIgnoreCase("00")) {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund Successful.", refundResponse);
            } else {
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Failed.", refundResponse);
            }
        }
        return apiResponse;
    }



    public String createPosRefundFromMerchantKit(Exchange exchange, ApiTxnModel apiTxnModel, MerchantCheckStatusAndRefundReq refundDataReq, Boolean isMerchantKitReq) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("createRefund Body: {}", apiRequest);
        apiTxnModel.setMid(refundDataReq.getMerchantId());
        apiTxnModel.setTid(refundDataReq.getTerminalId());
        apiTxnModel.setOriginalHashedTxnId(refundDataReq.getRetRefNo());
        apiTxnModel.setTxnid(refundDataReq.getRetRefNo());
        apiTxnModel.setTxnAmt(refundDataReq.getRefundAmount());
        apiTxnModel.setMerchantTxnRefNo(refundDataReq.getTxnRefNo());
        return createPosRefundFromMerchantKit(exchange,refundDataReq,apiTxnModel,isMerchantKitReq);
    }

    public String createPosRefundFromMerchantKit(Exchange exchange,MerchantCheckStatusAndRefundReq refundDataReq, ApiTxnModel apiTxnModel,Boolean isMerchantKitReq){
        String apiResponse = null;
        apiTxnModel.setMsgType(REFUND_TXN);
        Map<String, Object> resDataMap = new HashMap<>();
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        MerchantRefundRes refundDataRes = new MerchantRefundRes();
        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
        refundDataRes.setRespDate(OffsetDateTime.now());
        refundDataRes.setRespTime(OffsetDateTime.now());
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
        LyraMessageTransformation lyraMessageTransformation = new LyraMessageTransformation();
        CheckBITransactionResponse biTransactionResponse = callTransactionDetailsApi(lyraMessageTransformation, apiTxnModel);
        if (biTransactionResponse != null && biTransactionResponse.getData() != null && !biTransactionResponse.getData().isEmpty()) {
            CheckBITransactionResponse.Data data = biTransactionResponse.getData().get(0);
            if ("Cards".equalsIgnoreCase(data.getModeOfPayment())) {
                String cardChargeBack = processorHelper.callCardChargeBack(apiTxnModel.getOriginalHashedTxnId(), apiTxnModel.getTid());
                if (!StringUtils.isBlank(cardChargeBack) && "Y".equalsIgnoreCase(cardChargeBack)) {
                    refundDataRes.setMessage("ChargeBack is initiated for given transaction id.");
                    refundDataRes.setStatus(PaymentStatus.FAILED.name());
                    resDataMap.put("refundDataRes", refundDataRes);
                    if(isMerchantKitReq){
                        apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                    }else{
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "ChargeBack is initiated for given transaction id.", resDataMap);
                    }
                    return apiResponse;
                } else {
                    if ("0".equalsIgnoreCase(data.getTotalRefund())) {
                        validatePosRefundAmt(data.getTransactionAmount(),apiTxnModel);
                        apiResponse = initiatePosRefundFromMerchantKit(apiTxnModel, routingContext, lyraMessageTransformation, data,MTMProperties.getProperty("pos.sr.icici.fund.transfer.card.accno"),isMerchantKitReq,refundDataReq);
                    } else {
                        refundDataRes.setMessage("Refund Already Processed.");
                        refundDataRes.setStatus(PaymentStatus.FAILED.name());
                        resDataMap.put("refundDataRes", refundDataRes);
                        if(isMerchantKitReq){
                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                        }else{
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Already Processed.", resDataMap);
                        }
                    }
                }
            } else if ("Upi".equalsIgnoreCase(data.getModeOfPayment())) {
                String upiChargeBack = processorHelper.callUpiChargeBack(apiTxnModel.getOriginalHashedTxnId(), apiTxnModel.getTid());
                if (!StringUtils.isBlank(upiChargeBack) && "Y".equalsIgnoreCase(upiChargeBack)) {
                    throw new ChargebackFoundException("ChargeBack is initiated for given transaction id.");
                } else {
                    if ("0".equalsIgnoreCase(data.getTotalRefund())) {
                        validatePosRefundAmt(data.getTransactionAmount(),apiTxnModel);
                        apiResponse = initiatePosRefundFromMerchantKit(apiTxnModel, routingContext, lyraMessageTransformation, data,MTMProperties.getProperty("pos.sr.icici.fund.transfer.upi.accno"),isMerchantKitReq,refundDataReq);
                    } else {
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Already Processed", null);
                    }
                }
            }
        } else {
            refundDataRes.setMessage("Original Txn Not Found.");
            refundDataRes.setStatus(PaymentStatus.FAILED.name());
            resDataMap.put("refundDataRes", refundDataRes);
            if(isMerchantKitReq){
                apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
            }else{
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Original Txn Not Found.", resDataMap);
            }
        }
        return apiResponse;
    }


    private String initiatePosRefundFromMerchantKit(ApiTxnModel apiTxnModel, RoutingContext routingContext, LyraMessageTransformation lyraMessageTransformation,
                                                    CheckBITransactionResponse.Data data,String bankAccNo, Boolean isMerchantKitReq, MerchantCheckStatusAndRefundReq refundDataReq) {
        String apiResponse;
        Map<String, Object> resDataMap = new HashMap<>();
        MerchantRefundRes refundDataRes = new MerchantRefundRes();
        refundDataRes = refundDataRes.getMerchantRefundDataRes(refundDataReq);
        refundDataRes.setRespDate(OffsetDateTime.now());
        refundDataRes.setRespTime(OffsetDateTime.now());
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(routingContext.getEntityId(), refundDataReq.getMerchantId());
        if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pos.sr.icici.fund.transfer.enable"))) {
            JSONObject fundTransferResp = processorHelper.callFundTransferApi("POS",apiTxnModel.buildTmm(), merchantMaster.getAccountNo(),
                    bankAccNo,apiTxnModel.getTxnAmt(),data.getRefNo());
            if (fundTransferResp != null) {
                VizpayCheckTransactionResponse refundResponse = callPosRefund(lyraMessageTransformation, apiTxnModel,data);
                if (refundResponse != null && refundResponse.getRspCode() != null && refundResponse.getRspCode().equalsIgnoreCase("00")) {
                    refundDataRes.setMessage("Refund Successful.");
                    refundDataRes.setStatus(PaymentStatus.SUCCESS.name());
                    refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                    resDataMap.put("refundDataRes", refundDataRes);
                    if(isMerchantKitReq){
                        apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                    }else{
                        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund Successful.", resDataMap);
                    }
                } else {
                    JSONObject fundRollbackResp = processorHelper.callFundTransferApi("POS", apiTxnModel.buildTmm(),MTMProperties.getProperty("pos.sr.icici.fund.transfer.card.accno"),
                            merchantMaster.getAccountNo(), apiTxnModel.getTxnAmt(),data.getRefNo());
                    if (fundRollbackResp != null) {
                        refundDataRes.setMessage("Refund Failed And Fund Is Rollback Successfully.");
                        refundDataRes.setStatus(PaymentStatus.FAILED.name());
                        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                        resDataMap.put("refundDataRes", refundDataRes);
                        if(isMerchantKitReq){
                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                        }else{
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Failed And Fund Is Rollback Successfully.", resDataMap);
                        }
                    } else {
                        refundDataRes.setMessage("Refund Failed And Fund Is Rollback Unsuccessfully.");
                        refundDataRes.setStatus(PaymentStatus.FAILED.name());
                        refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                        resDataMap.put("refundDataRes", refundDataRes);
                        if(isMerchantKitReq){
                            apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                        }else{
                            apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Failed And Fund Is Rollback Unsuccessfully.", fundRollbackResp);
                        }
                    }
                }
            } else {
                refundDataRes.setMessage("Initial Fund Transfer Failed");
                refundDataRes.setStatus(PaymentStatus.FAILED.name());
                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                resDataMap.put("refundDataRes", refundDataRes);
                if(isMerchantKitReq){
                    apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                }else{
                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Initial Fund Transfer Failed", resDataMap);
                }
            }
        } else {
            VizpayCheckTransactionResponse refundResponse = callPosRefund(lyraMessageTransformation, apiTxnModel, data);
            if (refundResponse != null && refundResponse.getRspCode() != null && refundResponse.getRspCode().equalsIgnoreCase("00")) {
                refundDataRes.setMessage("Refund Successful.");
                refundDataRes.setStatus(PaymentStatus.SUCCESS.name());
                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                resDataMap.put("refundDataRes", refundDataRes);
                if(isMerchantKitReq){
                    apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                }else{
                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Refund Successful.", refundResponse);
                }
            } else {
                refundDataRes.setMessage("Refund Failed.");
                refundDataRes.setStatus(PaymentStatus.FAILED.name());
                refundDataRes = apiTransactionProcessor.getMerchantResWithSecureHash(refundDataRes, merchantMaster.getSecretKey());
                resDataMap.put("refundDataRes", refundDataRes);
                if(isMerchantKitReq){
                    apiResponse = IsgJsonUtils.getJsonString(refundDataRes);
                }else{
                    apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, "Refund Failed.", refundResponse);
                }
            }
        }
        return apiResponse;
    }

    public void validatePosRefundAmt(String originalTxnAmt, ApiTxnModel apiTxnModel) {
        BigDecimal originalAmt = new BigDecimal(originalTxnAmt);
        String txnAmt = IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(apiTxnModel.getTxnAmt());
        BigDecimal refundTxnAmt = new BigDecimal(txnAmt);
        if (refundTxnAmt.compareTo(originalAmt) > 0) {
            if (SmartRouteMsgTypeHelper.isRefund(apiTxnModel.getMsgType(), apiTxnModel.getProcessingCode()))
                throw new RefundAmountExceededException(
                        ("Txn amount has been exceeded, Original Txn Amt: " + originalTxnAmt + ", Txn Amt: "
                                + refundTxnAmt));
        }
    }

    public CheckBITransactionResponse callTransactionDetailsApi(LyraMessageTransformation lyraMessageTransformation,ApiTxnModel apiTxnModel) {
        logger.info("Calling BI Api To Fetch Original POS Txn :");
        JSONObject biJsonObject = new JSONObject();
        biJsonObject.put("txnId", apiTxnModel.getOriginalHashedTxnId());
        biJsonObject.put("merchantId", apiTxnModel.getMid());
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(MTMProperties.getProperty("sr.host.txn.username"), MTMProperties.getProperty("sr.host.txn.password"));
        String res = null;
        try {
            res = lyraMessageTransformation.callApiByWebClient(MTMProperties.getProperty("sr.host.txn.api.url"), headers, biJsonObject);
//            res = MTMProperties.getProperty("vizpay.ori.txn.res");
            logger.info("Fetched Original POS Txn Response : {}  ",res);
            if(res != null) {
                String[] split = res.split(API_RESPONSE_SEPARATOR);
                int status = Integer.parseInt(split[0]);
                res = split[1];
                return IsgJsonUtils.getObjectFromJsonString(res, CheckBITransactionResponse.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private VizpayCheckTransactionResponse callPosRefund(LyraMessageTransformation lyraMessageTransformation,
                                                         ApiTxnModel apiTxnModel, CheckBITransactionResponse.Data data) {
        logger.info("Calling POS Refund Api : ");
        JSONObject refundJsonObject = new JSONObject();
        refundJsonObject.put("Source", MTMProperties.getProperty("vizpay.txn.source"));
        refundJsonObject.put("Mid", apiTxnModel.getMid());
        refundJsonObject.put("Tid",apiTxnModel.getTid());
        refundJsonObject.put("RRN", data.getRefNo());
        refundJsonObject.put("InvoiceNo", data.getInvoiceNo());
        refundJsonObject.put("Amount", IsgCurrencyConversionUtils.getFixedLengthAmt(apiTxnModel.getTxnAmt(), 12));
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        logger.info("apikey : {} ",MTMProperties.getProperty("vizpay.api.key"));
        headers.add("apikey",MTMProperties.getProperty("vizpay.api.key"));
        String refundRes = null;
        try {
            refundRes = lyraMessageTransformation.callApiByWebClient(MTMProperties.getProperty("vizpay.refund.txn.url"), headers, refundJsonObject);
            logger.info("Pos Refund Response : {} ", refundRes);
        } catch (Exception e) {
            e.printStackTrace();
//            refundRes = MTMProperties.getProperty("vizpay.refund.response");
        }
        if(refundRes != null) {
            String[] split = refundRes.split("##");
            refundRes = split[1];
            return IsgJsonUtils.getObjectFromJsonString(refundRes, VizpayCheckTransactionResponse.class);
        }else {
            return null;
        }
    }

    public String saveTransactionResponseEnc(Exchange exchange, RoutingContext routingContext,SourceConfigModel sourceConfigModel) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        ApiTxnModel apiTxnModel;
        String decryptSmartRouteReq = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        decryptSmartRouteReq = URLDecoder.decode(decryptSmartRouteReq.replace("+", "%2B"), StandardCharsets.UTF_8.name())
                .replace("%2B", "+");
        logger.info("Decrypted Save Response : {}",decryptSmartRouteReq);
        apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(decryptSmartRouteReq, exchange);
        String saveTransactionResponse = saveTransactionResponse(exchange, routingContext, sourceConfigModel, apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, saveTransactionResponse);
    }

    public String saveTransactionResponse(Exchange exchange, RoutingContext routingContext,SourceConfigModel sourceConfigModel) throws UnsupportedEncodingException {
        String apiRequest = exchange.getIn().getBody(String.class);
        logger.trace("SaveTransactionResponse Body: {}", apiRequest);
        apiRequest = java.net.URLDecoder.decode(apiRequest.replace("+", "%2B"), StandardCharsets.UTF_8.name()).replace("%2B", "+");
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return saveTransactionResponse(exchange,routingContext,sourceConfigModel,apiTxnModel);
    }

    public String saveTransactionResponse(Exchange exchange, RoutingContext routingContext,SourceConfigModel sourceConfigModel,ApiTxnModel apiTxnModel) throws UnsupportedEncodingException {
        String apiResponse;
        TransactionMessageModel resTargetTmm = null;
        try {
            apiTxnModel.setEntityId(routingContext.getEntityId());
            if (apiTxnModel.getTpslMerchantCode() != null) {
                resTargetTmm = tpslSaveTransResp(exchange, routingContext, apiTxnModel);
            } else if (apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("payu")) {
                resTargetTmm = payuSaveTranResp(exchange, routingContext, apiTxnModel);
            }else if(apiTxnModel.getUuid() != null && apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("lyra")){
                //Check Transaction status
                logger.info("Lyra check Transaction status method call:: {}",new JSONObject(apiTxnModel));
                checkLyaraTransactionStatus(routingContext, apiTxnModel);
                //Save Lyara Transaction
                logger.info("Lyra save Transaction method call:: ",new JSONObject(apiTxnModel));
                resTargetTmm = lyraSaveTranResp(exchange, routingContext, apiTxnModel);
            }else if(apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("iciciretail")){
                resTargetTmm = retailNbSaveTranResp(exchange, routingContext, apiTxnModel);
            }else if(apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("icicicorporate")){
                resTargetTmm = corporateNbSaveTranResp(exchange, routingContext, apiTxnModel);
            }
        } catch (InstantiationException | IllegalAccessException e) {
            logger.trace(e.getMessage());
            throw new RuntimeException(e);
        }
        MerchantEncReqRes merchantEncReqRes = apiTransactionProcessor.generateMerchantEncryptedData(routingContext, apiTxnModel,resTargetTmm);
        resTargetTmm.setMerchantIntegrationReqRes(merchantEncReqRes);
        //SET TXN_MSG_MODEL
        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.UPDATE,DbMessageType.UP_RES,resTargetTmm);
        logger.info(LogUtils.buildSMLogMessage(resTargetTmm.getEntityId(),resTargetTmm.getMerchantTxnRefNo(),resTargetTmm.getTransactionId(),
                resTargetTmm.getTransactionName(),"Response Source Transaction message model  : {}"), resTargetTmm);
        apiResponse = resData(routingContext.getEntityId(), apiTxnModel, resTargetTmm, merchantEncReqRes);
        processorHelper.logToTlm(resTargetTmm, routingContext);
        return apiResponse;
    }

    private ApiTxnModel checkLyaraTransactionStatus(RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        TransactionMessageModel transactionMessageModel = apiTxnModel.buildTmm();
        transactionMessageModel.setTransactionId(apiTxnModel.getTransactionId());
        TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Lyra).findFirst().get();
        LyraMessageTransformation lyraMessageTransformation = LyraMessageTransformation.class.newInstance();
        Map<String, Object> checkTxnStatusMap = lyraMessageTransformation.checkTrxnStatusRequest(transactionMessageModel, targetConfigModel1);
        LyraCheckTxnStatusResponse checkTxnStatusResponse = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            checkTxnStatusResponse = IsgJsonUtils.getObjectFromJsonString(objectMapper.writeValueAsString(checkTxnStatusMap), LyraCheckTxnStatusResponse.class);
        }catch (Exception e){
            logger.info("Error while decrypting response of check transaction status api:: {}",e.getMessage());
        }
        if(checkTxnStatusMap != null && !checkTxnStatusMap.isEmpty()){
            JSONObject jsonObject = new JSONObject(checkTxnStatusMap);
            String paymentLinkQuery = checkTxnStatusResponse.getPaymentLink();
            apiTxnModel.setTxnid(getValueFromQuery(paymentLinkQuery ,"transactionId"));
            apiTxnModel.setLinkHashId(getValueFromQuery(paymentLinkQuery,"linkHashId"));
            apiTxnModel.setPayOpt(getValueFromQuery(paymentLinkQuery,"payOpt"));
            apiTxnModel.setStatus(checkTxnStatusResponse.getStatus());
            apiTxnModel.setOrderId(checkTxnStatusResponse.getOrderId());
            apiTxnModel.setDate(checkTxnStatusResponse.getDate());
            apiTxnModel.setLyraAmount(String.valueOf(checkTxnStatusResponse.getAmount()));
            apiTxnModel.setDue(String.valueOf(checkTxnStatusResponse.getDue()));
            apiTxnModel.setPaid(String.valueOf(checkTxnStatusResponse.getPaid()));
            apiTxnModel.setRefunded(String.valueOf(checkTxnStatusResponse.getRefunded()));
            apiTxnModel.setCurrency(checkTxnStatusResponse.getCurrency());
            LyraCheckTxnStatusResponse.Transaction transaction = checkTxnStatusResponse.getTransactions().get(0);
            logger.info("Lyra transactions object ::  {}",transaction);
            apiTxnModel.setExternalId(transaction.getExternalId());
            apiTxnModel.setAuthResponseCode(transaction.getAuthResponseCode());
//            apiTxnModel.setAuthNum((String) checkTxnStatusMap.get("authNum"));
            apiTxnModel.setOrigTxnAmt(getValueFromQuery(paymentLinkQuery ,"origTxnAmt"));
        }
        return apiTxnModel;
    }


    public static String getValueFromQuery(String query, String val) {
        try {
            String[] queryWithoutQuetionMark = query.split("\\?");
            if (queryWithoutQuetionMark != null && queryWithoutQuetionMark.length > 1) {
                String[] params = queryWithoutQuetionMark[1].split("&");
                Map<String, String> map = new HashMap<String, String>();
                for (String param : params) {
                    String[] p = param.split("=");
                    String name = p[0];
                    if (p.length > 1) {
                        String value = p[1];
                        map.put(name, value);
                    } else {
                        map.put(name, "");
                    }
                }
                String value = map != null && !map.isEmpty() ? (String) map.get(val) : "";
                return !StringUtils.isBlank(value) ? value : "";
            }
        } catch (Exception e) {
            return "";
        }
        return "";
    }

    private TransactionMessageModel corporateNbSaveTranResp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        TransactionMessageModel resTargetTmm;
        TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Icici &&
                apiTxnModel.getPaymentSource().equalsIgnoreCase(targetConfigModel.getAdditionalData().getPaymentSource())).findFirst().get();
        IciciMessageTransformation iciciMessageTransformation = IciciMessageTransformation.class.newInstance();
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, targetConfigModel1.getId());
        resTargetTmm = iciciMessageTransformation.parseCorporateResponse(apiTxnModel, targetConfigModel1);
        resTargetTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        resTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resTargetTmm.setResponseSentTime(OffsetDateTime.now());
        resTargetTmm.setEpType(EpType.TARGET);
        resTargetTmm.setTargetType(TargetType.Icici);
        resTargetTmm.setLinkHashId(apiTxnModel.getLinkHashId());
        resTargetTmm.setMsgType(IciciMsgType.NbCorpPay.msgType);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_TGT_TMM, resTargetTmm);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
        iciciMessageTransformation.validateResponseErrorCode(apiTxnModel, targetConfigModel1);
        return resTargetTmm;
    }

    private TransactionMessageModel retailNbSaveTranResp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        TransactionMessageModel resTargetTmm;
        TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Icici &&
                apiTxnModel.getPaymentSource().equalsIgnoreCase(targetConfigModel.getAdditionalData().getPaymentSource())).findFirst().get();
        IciciMessageTransformation iciciMessageTransformation = IciciMessageTransformation.class.newInstance();
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, targetConfigModel1.getId());
        resTargetTmm = iciciMessageTransformation.parseRetailResponse(apiTxnModel, targetConfigModel1);
        resTargetTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        resTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resTargetTmm.setResponseSentTime(OffsetDateTime.now());
        resTargetTmm.setEpType(EpType.TARGET);
        resTargetTmm.setTargetType(TargetType.Icici);
        resTargetTmm.setLinkHashId(apiTxnModel.getLinkHashId());
        resTargetTmm.setMsgType(IciciMsgType.NbRetailPay.msgType);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_TGT_TMM, resTargetTmm);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
        iciciMessageTransformation.validateResponseErrorCode(apiTxnModel, targetConfigModel1);
        return resTargetTmm;
    }


    private TransactionMessageModel lyraSaveTranResp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        TransactionMessageModel resTargetTmm;
        TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Lyra).findFirst().get();
        LyraMessageTransformation lyraMessageTransformation = LyraMessageTransformation.class.newInstance();
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        reqSrcTmm.setLinkHashId(apiTxnModel.getLinkHashId());
        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        reqSrcTmm.setResponseSentTime(OffsetDateTime.now());
        reqSrcTmm.setEpType(EpType.TARGET);
        reqSrcTmm.setMsgType("Pay");
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, targetConfigModel1.getId());
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        resTargetTmm = lyraMessageTransformation.parseResponse(apiTxnModel, targetConfigModel1);
        resTargetTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        resTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resTargetTmm.setResponseSentTime(OffsetDateTime.now());
        resTargetTmm.setEpType(EpType.TARGET);
        resTargetTmm.setTargetType(TargetType.Lyra);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_TGT_TMM, resTargetTmm);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
        lyraMessageTransformation.validateResponseErrorCode(apiTxnModel, targetConfigModel1);
        return resTargetTmm;
    }

    private TransactionMessageModel payuSaveTranResp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        TransactionMessageModel resTargetTmm;
        TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.PayU).findFirst().get();
        PayUMessageTransformation payUMessageTransformation = PayUMessageTransformation.class.newInstance();
        apiTxnModel.setMid(apiTxnModel.getUdf2());
        apiTxnModel.setTid(apiTxnModel.getUdf4());
        apiTxnModel.setEntityId(routingContext.getEntityId());
        apiTxnModel.setMerchantTxnRefNo(apiTxnModel.getUdf1());
        apiTxnModel.setLinkHashId(!StringUtils.isBlank(apiTxnModel.getUdf3()) ? (apiTxnModel.getUdf3()) : null);
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        reqSrcTmm.setLinkHashId(apiTxnModel.getUdf3());
        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        reqSrcTmm.setResponseSentTime(OffsetDateTime.now());
        reqSrcTmm.setEpType(EpType.TARGET);
        reqSrcTmm.setMsgType("Pay");
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, targetConfigModel1.getId());
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        resTargetTmm = payUMessageTransformation.parseResponse(apiTxnModel, targetConfigModel1);
        resTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resTargetTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        resTargetTmm.setResponseSentTime(OffsetDateTime.now());
        resTargetTmm.setEpType(EpType.TARGET);
        resTargetTmm.setTargetType(TargetType.PayU);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_TGT_TMM, resTargetTmm);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
        payUMessageTransformation.validateResponseErrorCode(apiTxnModel, targetConfigModel1);
        return resTargetTmm;
    }

    private TransactionMessageModel tpslSaveTransResp(Exchange exchange, RoutingContext routingContext, ApiTxnModel apiTxnModel) throws InstantiationException, IllegalAccessException {
        TransactionMessageModel resTargetTmm;
        TargetConfigModel targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getTargetType() == TargetType.Tpsl).findFirst().get();
        TpslMessageTransformation tpslMessageTransformation = TpslMessageTransformation.class.newInstance();
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        reqSrcTmm.setResponseSentTime(OffsetDateTime.now());
        reqSrcTmm.setEpType(EpType.TARGET);
        reqSrcTmm.setMsgType("Pay");
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_ID, targetConfigModel1.getId());
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        resTargetTmm = tpslMessageTransformation.parseResponse(apiTxnModel, targetConfigModel1);
        resTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resTargetTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        resTargetTmm.setResponseSentTime(OffsetDateTime.now());
        resTargetTmm.setEpType(EpType.TARGET);
        resTargetTmm.setTargetType(TargetType.Tpsl);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_TGT_TMM, resTargetTmm);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL, apiTxnModel);
        tpslMessageTransformation.validateResponseErrorCode(apiTxnModel,targetConfigModel1);
        return resTargetTmm;
    }

    private String resData(String entityId, ApiTxnModel apiTxnModel,TransactionMessageModel resTargetTmm ,MerchantEncReqRes merchantEncReqRes) {
        String apiResponse = "";
        String errorMsg = "";
        Map<String, Object> resDataMap = new HashMap<>();
        ResponseObj.RetryEvent retryEvent = new ResponseObj.RetryEvent();
        ResponseObj.RedirectEvent redirEvent = new ResponseObj.RedirectEvent();
        resDataMap.put("redirectEvent", redirEvent);
        resDataMap.put("retryEvent", retryEvent);
        String mid = apiTxnModel.getMid();
        String orderId = apiTxnModel.getMerchantTxnRefNo();
        Map<String, String> retryData = null;
        MerchOrdTxnData merchOrdTxnData = cacheUtil.getTxnData(entityId, mid, orderId);
        merchOrdTxnData.setEncData(merchantEncReqRes.getEncData());
        if (merchOrdTxnData != null) {
            MerchantMasterModel merchantMasterModel = processorHelper.validateMerchantMaster(entityId, mid);
            //merchOrdTxnData.setRetryCount(merchOrdTxnData.getRetryCount() + 1);
            Map<String, MerchOrdTxnData.TxnData> txnDataMapModel = merchOrdTxnData.getTxnDataMapModel();
            boolean isSuccessTxnExist = false;
            if (resTargetTmm.getResCode().equals("00")) {
                for (Map.Entry<String, MerchOrdTxnData.TxnData> dataModelEntry : txnDataMapModel.entrySet()) {
                    if (dataModelEntry.getValue().getTxnStatus().equalsIgnoreCase("Success")) {
                        isSuccessTxnExist = true;
                        break;
                    }
                }
                if (isSuccessTxnExist) {
                    // initiate reversal for current txn
                    logger.trace("initiate reversal for current txn");
                }
                changeStatus(merchOrdTxnData, apiTxnModel, entityId, resTargetTmm.getTransactionId(), "Success");
                retryEvent.setRetryFlag(CommonConstants.N);
                if (!StringUtils.isBlank(apiTxnModel.getLinkHashId())) {
                    paymentLinkResponse(redirEvent,retryEvent,apiTxnModel,merchantMasterModel,resTargetTmm,merchOrdTxnData);
                } else {
                    redirEvent.setTargetUrl(merchOrdTxnData.getMerchantReturnUrl());
                }
                redirEvent.setTargetEncFormData(merchantEncReqRes);
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Transaction completed successfully.", resDataMap);
                setPaymentStatus(resDataMap,apiTxnModel,PaymentStatus.SUCCESS);
            } else {
                changeStatus(merchOrdTxnData, apiTxnModel, entityId, resTargetTmm.getTransactionId(), "Failed");
                retryData = new HashMap<>();
                retryData.put("merchantId", mid);
                retryData.put("encData", merchOrdTxnData.getEncData());
                retryData.put("bankId", merchOrdTxnData.getBankId());
                retryData.put("terminalId", merchOrdTxnData.getTerminalId());
                retryEvent.setRetryData(retryData);
                retryEvent.setRetryFlag(CommonConstants.Y);
                if (apiTxnModel.getLinkHashId() != null && !StringUtils.isBlank(apiTxnModel.getLinkHashId())) {
                    paymentLinkResponse(redirEvent,retryEvent,apiTxnModel,merchantMasterModel,resTargetTmm,merchOrdTxnData);
                    errorMsg = "Transaction Failed.";
                } else {
                    redirEvent.setTargetUrl(merchOrdTxnData.getTxnFailedReturnUrl());
                    errorMsg = "Transaction Failed.";
                }
                redirEvent.setTargetEncFormData(merchantEncReqRes);
                apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.ERROR, errorMsg, resDataMap);
                setPaymentStatus(resDataMap,apiTxnModel,PaymentStatus.FAILED);
            }
        }
        return apiResponse;
    }

    public void paymentLinkResponse(ResponseObj.RedirectEvent redirEvent, ResponseObj.RetryEvent retryEvent, ApiTxnModel apiTxnModel, MerchantMasterModel merchantMasterModel, TransactionMessageModel resTargetTmm, MerchOrdTxnData merchOrdTxnData) {
        Map<String, String> retryData;
        MerchantEncDataRequest merchantEncDataRequest = apiTransactionProcessor.decryptMerchantEncryptedRequest(merchOrdTxnData.getEncData(), merchantMasterModel.getSecretKey(), merchantMasterModel.getEncryptionKey());
        retryData = new HashMap<>();
        retryData.put("TransactionId", resTargetTmm.getTransactionId());
        if(resTargetTmm.getResCode().equals("00")){
            retryData.put("PaymentStatus", PaymentStatus.SUCCESS.name());
        }else{
            retryData.put("PaymentStatus", PaymentStatus.FAILED.name());
        }
        retryData.put("Email", merchantEncDataRequest.getEmail());
        retryData.put("MobileNo", merchantEncDataRequest.getPhone());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date date = Date.from(resTargetTmm.getResponseReceivedTime().toInstant());
        retryData.put("Date", formatter.format(date));
        retryData.put("Amount", IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(new BigInteger(resTargetTmm.getTxnAmt()).toString()));
        retryData.put("Remark", !StringUtils.isBlank(merchantEncDataRequest.getOrderInfo()) ? merchantEncDataRequest.getOrderInfo() : "");
        if(apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("payu") && apiTxnModel.getMihpayid() != null){
            TransactionMessageModel.PayUData payUData = resTargetTmm.getSmartRouteData().getPayUData();
            retryData.put("OrderId", payUData.getUdf1());
            retryData.put("PaymentMode", payUData.getMode());
            retryData.put("MerchantName",merchantMasterModel.getMerchantName());
            retryData.put("RRN", "NA");
        }if(apiTxnModel.getTpslMerchantCode() != null){
            TransactionMessageModel.TpslData tpslData = resTargetTmm.getSmartRouteData().getTpslData();
            retryData.put("OrderId", apiTxnModel.getMerchantTxnRefNo());
            retryData.put("MerchantName",merchantMasterModel.getMerchantName());
            retryData.put("PaymentMode", apiTxnModel.getPaymentFamily());
            retryData.put("RRN", resTargetTmm.getTargetTxnId());
        }if(apiTxnModel.getUuid() != null){
            TransactionMessageModel.LyraData lyraData = resTargetTmm.getSmartRouteData().getLyraData();
            retryData.put("OrderId", lyraData.getOrderId());
            retryData.put("PaymentMode", "Card");
            retryData.put("MerchantName",merchantMasterModel.getMerchantName());
            retryData.put("RRN", lyraData.getExternalId());
        }if(apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("iciciretail")){
            TransactionMessageModel.IciciRetailData iciciRetailData = resTargetTmm.getSmartRouteData().getIciciRetailData();
            retryData.put("OrderId", resTargetTmm.getMerchantTxnRefNo());
            retryData.put("PaymentMode", "Netbanking");
            retryData.put("MerchantName",merchantMasterModel.getMerchantName());
            retryData.put("RRN", iciciRetailData.getBid());
        }if(apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("icicicorporate")){
            retryData.put("OrderId", resTargetTmm.getMerchantTxnRefNo());
            retryData.put("PaymentMode", "Netbanking");
            retryData.put("MerchantName",merchantMasterModel.getMerchantName());
            retryData.put("RRN", resTargetTmm.getTargetTxnId());
        }if(apiTxnModel.getPaymentSource() != null && apiTxnModel.getPaymentSource().equalsIgnoreCase("upi")){
            retryData.put("OrderId", resTargetTmm.getMerchantTxnRefNo());
            retryData.put("PaymentMode", "Upi");
            retryData.put("MerchantName",merchantMasterModel.getMerchantName());
            String bankRRN = null;
            try {
                bankRRN = resTargetTmm.getResSmartRouteData().getUpiResponse().getBankRRN();
            } catch (Exception e) {
                logger.info("Error While Fetching RRN For Failed UPI Transaction :: {}", resTargetTmm.getResSmartRouteData());
            }
            retryData.put("RRN", bankRRN);
        }
        redirEvent.setTargetUrl("");
        retryEvent.setRetryData(retryData);
    }

    public void changeStatus(MerchOrdTxnData merchOrdTxnData, ApiTxnModel apiTxnModel, String entityId, String transactionId, String newStatus) {
        Map<String, MerchOrdTxnData.TxnData> txnDataMapModelMap = merchOrdTxnData.getTxnDataMapModel();
        if (txnDataMapModelMap != null && !txnDataMapModelMap.isEmpty()) {
            for (Map.Entry<String, MerchOrdTxnData.TxnData> dataModelEntry : txnDataMapModelMap.entrySet()) {
                if (dataModelEntry.getKey().equals(transactionId)) {
                    MerchOrdTxnData.TxnData txnDataValue = dataModelEntry.getValue();
                    if ((txnDataValue.getTxnStatus().equals("Pending") || txnDataValue.getTxnStatus().equals("Failed")) && newStatus.equals("Success")) {
                        long txnCount = merchOrdTxnData.getTxnDataMapModel().values().stream().filter(txnData -> txnData.getTxnStatus().equals("Pending")).count();
//                    if (txnCount == 1) {
//                        cacheUtil.removeTxnData(entityId, apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
//                    } else {
                    txnDataValue.setTxnStatus("Success");
                    txnDataMapModelMap.put(transactionId, txnDataValue);
                    merchOrdTxnData.setTxnDataMapModel(txnDataMapModelMap);
                    cacheUtil.putTxnData(entityId, apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo(), merchOrdTxnData);
//                    }
                    }
                    if (txnDataValue.getTxnStatus().equals("Pending") && newStatus.equals("Failed")) {
                        txnDataValue.setTxnStatus("Failed");
                        txnDataMapModelMap.put(transactionId, txnDataValue);
                        merchOrdTxnData.setTxnDataMapModel(txnDataMapModelMap);
                        cacheUtil.putTxnData(entityId, apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo(), merchOrdTxnData);
                    }
                }
            }
        }
    }

    public String generateTransactionId() {
        return Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
    }

    public void setPaymentStatus(Map<String, Object> resDataMap, ApiTxnModel apiTxnModel, PaymentStatus status) {
//        if (resDataMap != null && apiTxnModel.getLinkHashId() != null) {
        if (!StringUtils.isBlank(apiTxnModel.getLinkHashId())) {
            PaymentLinksModel paymentLinksModel = new PaymentLinksModel();
            paymentLinksModel.setLinkHashId(apiTxnModel.getLinkHashId());
            paymentLinksModel.setStatus(status);
            paymentLinksModel.setStatusDate(OffsetDateTime.now());
            if (!StringUtils.isBlank(apiTxnModel.getPaymentAttemptCounter())) {
                paymentLinksModel.setPaymentAttemptCounter(Integer.getInteger(apiTxnModel.getPaymentAttemptCounter()));
            }
            processorHelper.logPaymentLinksModelToTlm(paymentLinksModel);
        }
    }
}
