package com.isg.mw.routing.route.codec;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import org.apache.camel.component.netty.ChannelHandlerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class VisaCustomLengthFieldBasedFrameDecoder extends LengthFieldBasedFrameDecoder implements ChannelHandlerFactory {
    private final Logger logger = LogManager.getLogger(getClass());

    public VisaCustomLengthFieldBasedFrameDecoder(int maxFrameLength, int lengthFieldOffset, int lengthFieldLength) {
        super(maxFrameLength, lengthFieldOffset, lengthFieldLength);
    }

    public VisaCustomLengthFieldBasedFrameDecoder(
            int maxFrameLength,
            int lengthFieldOffset, int lengthFieldLength,
            int lengthAdjustment, int initialBytesToStrip) {
        super(
                maxFrameLength,
                lengthFieldOffset, lengthFieldLength, lengthAdjustment,
                initialBytesToStrip);
    }

    @Override
    protected Object decode(ChannelHandlerContext ctx, ByteBuf in) throws Exception {
        Object decode = super.decode(ctx, in);
        if (decode instanceof ByteBuf) {
            ByteBuf byteBuf = null;
            byte[] msgBytes = null;
            try {
                byteBuf = (ByteBuf) decode;
                msgBytes = new byte[byteBuf.readableBytes()];
                byteBuf.readBytes(msgBytes);
            } catch (Exception e) {
                logger.error("Error caught", e);
            } finally {
                byteBuf.release();
            }
            return msgBytes;
        }
        return null;
    }

    @Override
    public ChannelHandler newChannelHandler() {
        return new VisaCustomLengthFieldBasedFrameDecoder(512, 0, 2, 2, 0);
    }
}
