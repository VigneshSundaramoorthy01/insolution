package com.isg.mw.routing.config;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sc.Urls;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tc.TargetConnection;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.route.RoutingCorrelationManager;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.route.codec.ByteStreamDecoder;
import com.isg.mw.routing.route.codec.CustomLengthFieldBasedFrameDecoder;
import com.isg.mw.routing.route.codec.PosByteStreamDecoder;
import com.isg.mw.routing.route.codec.VisaCustomLengthFieldBasedFrameDecoder;
import org.apache.camel.CamelContext;
import org.apache.camel.component.netty.NettyConfiguration;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.component.netty.http.NettyHttpConfiguration;
import org.apache.camel.component.netty.http.NettyHttpEndpoint;
import org.apache.camel.component.rest.RestEndpoint;
import org.apache.camel.spi.RestConfiguration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

@Component
public class NettyConfig {

    private final static Logger logger = LogManager.getLogger();

    @Autowired
    private RoutingProperties routingProperties;

    private static RoutingProperties routingPropertiesStatic;

    private final ObjectProvider<CustomLengthFieldBasedFrameDecoder> decoders;

    private static ObjectProvider<CustomLengthFieldBasedFrameDecoder> decodersStatic;

    private final ObjectProvider<VisaCustomLengthFieldBasedFrameDecoder> visaDecoders;

    private static ObjectProvider<VisaCustomLengthFieldBasedFrameDecoder> visaDecodersStatic;

    @Autowired
    NettyConfig(ObjectProvider<CustomLengthFieldBasedFrameDecoder> decoders,
                ObjectProvider<VisaCustomLengthFieldBasedFrameDecoder> visaDecoders) {
        this.decoders = decoders;
        this.visaDecoders = visaDecoders;
    }

    @PostConstruct
    public void setProperties() {
        NettyConfig.routingPropertiesStatic = routingProperties;
        NettyConfig.decodersStatic = decoders;
        NettyConfig.visaDecodersStatic = visaDecoders;
    }

    public static NettyEndpoint getConsumerEndpoint(RoutingContext routingContext) {
        NettyEndpoint nettyConsumerEndpoint = routingContext.getCamelContext()
                .getEndpoint(getConsumerUri(routingContext.getSource().getPortOrUri()), NettyEndpoint.class);
        nettyConsumerEndpoint.setConfiguration(getConsumerConfig(routingContext));

        return nettyConsumerEndpoint;
    }

    private static String getConsumerUri(String port) {
        return "netty:tcp://0.0.0.0:" + port;
    }

    private static NettyConfiguration getConsumerConfig(RoutingContext routingContext) {
        /*
         * Disabling worker group for Netty Server AND
         * Using what Netty has provided
         * Worker Pool: NettyServerTCPWorker
         * Boss Pool: NettyServerTCPBoss
         EventLoopGroup sharedWorkerServerGroup
                = new NettyWorkerPoolBuilder()
                .withName("NettyTCPConsumerWorkerPool")
                .build();
         nettyConfig.setWorkerGroup(sharedWorkerServerGroup);
         */
        NettyConfiguration nettyConfig = new NettyConfiguration();
        nettyConfig.setProtocol("tcp");

        logger.info("Source Processor : {}", routingContext.getSource().getSourceProcessor());
        if (routingContext.getSource().getSourceProcessor() == SourceProcessor.PG_SWITCH) {
            nettyConfig.addDecoder(new ByteStreamDecoder());
        }else{
            nettyConfig.addDecoder(new PosByteStreamDecoder());
        }
        nettyConfig.setSync(false);
        nettyConfig.setBossCount(routingPropertiesStatic.getNettyBossCount());
        nettyConfig.setWorkerCount(routingPropertiesStatic.getNettyWorkercount());
        nettyConfig.setHost("0.0.0.0");
        nettyConfig.setPort(Integer.parseInt(routingContext.getSource().getPortOrUri()));
        nettyConfig.setReuseChannel(true);
        nettyConfig.setUseByteBuf(true);
        nettyConfig.setTcpNoDelay(true);
        nettyConfig.setUsingExecutorService(false);
        nettyConfig.setBacklog(routingPropertiesStatic.getNettyBacklog());
        nettyConfig.setBossCount(routingPropertiesStatic.getNettyBossCount());
        nettyConfig.setNativeTransport(routingPropertiesStatic.getNettyNativeTransport() != 0);
        return nettyConfig;
    }

    public static NettyEndpoint getProducerEndpoint(RoutingContext routingContext, String ipAndPort) {
        String urlOrIp = null;
        String portOrHeaders = null;
        TargetConfigModel targetConfigModel = null;
        List<TargetConfigModel> targets = routingContext.getTargets();
        for (TargetConfigModel tcm : targets) {
            List<TargetConnection> connections = tcm.getConnections();
            for (TargetConnection targetConnection : connections) {
                urlOrIp = targetConnection.getUrlOrIp();
                portOrHeaders = targetConnection.getPortOrHeaders();
                String modelIpAndPort = urlOrIp + ":" + portOrHeaders;
                if (modelIpAndPort.equals(ipAndPort)) {
                    targetConfigModel = tcm;
                    break;
                }
            }
            if (targetConfigModel != null) {
                break;
            }
        }
        NettyEndpoint nettyProducerEndpoint = routingContext.getCamelContext().getEndpoint(getProducerUri(ipAndPort),
                NettyEndpoint.class);
        nettyProducerEndpoint.setConfiguration(NettyConfig.getProducerConfig(ipAndPort, targetConfigModel));
        return nettyProducerEndpoint;
    }

    public static NettyEndpoint getProducerEndpoint(CamelContext camelContext, String ipAndPort, TargetConfigModel targetConfigModel) {
        NettyEndpoint nettyProducerEndpoint = camelContext.getEndpoint(getProducerUri(ipAndPort),
                NettyEndpoint.class);
        nettyProducerEndpoint.setConfiguration(NettyConfig.getProducerConfig(ipAndPort, targetConfigModel));
        return nettyProducerEndpoint;
    }

    private static String getProducerUri(String ipPort) {
        return "netty:tcp://" + ipPort;
    }

    private static NettyConfiguration getProducerConfig(String urlOrIp, TargetConfigModel configModel) {
        NettyConfiguration nettyConfig = new NettyConfiguration();
        nettyConfig.setHost(urlOrIp.substring(0, urlOrIp.indexOf(":")));

        String port = urlOrIp.substring(urlOrIp.indexOf(":") + 1);
        nettyConfig.setPort(Integer.parseInt(port));

        nettyConfig.setProtocol("tcp");
        if (configModel.getTargetType() == TargetType.Visa) {
            nettyConfig.addDecoder(visaDecodersStatic.getObject(
                    configModel.getNettyParameters().getPacketMaxFrameLength(),
                    configModel.getNettyParameters().getPacketLengthOffset(),
                    configModel.getNettyParameters().getPacketLengthFieldLength(),
                    configModel.getNettyParameters().getPacketLengthFieldAdjustment(),
                    configModel.getNettyParameters().getPacketInitialBytesToStrip()));
        } else {
            nettyConfig.addDecoder(decodersStatic.getObject(
                    configModel.getNettyParameters().getPacketMaxFrameLength(),
                    configModel.getNettyParameters().getPacketLengthOffset(),
                    configModel.getNettyParameters().getPacketLengthFieldLength(),
                    configModel.getNettyParameters().getPacketLengthFieldAdjustment(),
                    configModel.getNettyParameters().getPacketInitialBytesToStrip()));
        }

        nettyConfig.setSync(true);
        nettyConfig.setCorrelationManager(new RoutingCorrelationManager(routingPropertiesStatic.getTransactionResponseTimeout()));
        nettyConfig.setWorkerCount(routingPropertiesStatic.getNettyWorkercount());

        if (configModel.getRequestTimeout() > 0) {
            nettyConfig.setRequestTimeout(configModel.getRequestTimeout());
        } else {
            nettyConfig.setRequestTimeout(routingPropertiesStatic.getTargetRequestTimeoutGlobalDefault());
        }
        nettyConfig.setClientMode(true);
        nettyConfig.setReuseChannel(true);
        if (configModel.getConnectTimeout() > 0) {
            nettyConfig.setConnectTimeout(configModel.getConnectTimeout());
        } else {
            nettyConfig.setConnectTimeout(routingPropertiesStatic.getTargetConnectTimeoutGlobalDefault());
        }

        nettyConfig.setDisconnect(false);
        nettyConfig.setDisconnectOnNoReply(false);
        nettyConfig.setKeepAlive(true);
        nettyConfig.setProducerPoolEnabled(false);
        nettyConfig.setUseByteBuf(true);
        return nettyConfig;
    }

    public static void setRestConfiguration(String port, RoutingContext routingContext) {
        RestConfiguration restConfiguration = new RestConfiguration();
        restConfiguration.setHost("0.0.0.0");
        restConfiguration.setPort(Integer.parseInt(port));
        restConfiguration.setApiComponent("netty-http");
        routingContext.getCamelContext().setRestConfiguration(restConfiguration);
    }

   /* public static RestEndpoint getRestConsumerEndpoint(RoutingContext routingContext) {
        Urls urls = routingContext.getSource().getAdditionalData().getApiUrls().getUrls().get(0);
        RestEndpoint restEndpoint = routingContext.getCamelContext()
                .getEndpoint(getHttpConsumerUri(urls.getUrl()), RestEndpoint.class);
        restEndpoint.setConsumes(MediaType.APPLICATION_JSON_VALUE);
        restEndpoint.setProduces(MediaType.APPLICATION_JSON_VALUE);
        restEndpoint.setPath("accesspoint/" + urls.getUrl());
        restEndpoint.setBindingMode(RestConfiguration.RestBindingMode.json);
        restEndpoint.setMethod("post");
        restEndpoint.setInType(ApiTxnModel.class.getName());
        return restEndpoint;
    }*/

    public static RestEndpoint getRestConsumerEndpoint(RoutingContext routingContext, Urls urls) {
        //Urls urls = routingContext.getSource().getAdditionalData().getApiUrls().getUrls().get(0);
        RestEndpoint restEndpoint = routingContext.getCamelContext()
                .getEndpoint(getHttpConsumerUri(urls.getUrl()), RestEndpoint.class);
        restEndpoint.setConsumes(MediaType.APPLICATION_JSON_VALUE);
        restEndpoint.setProduces(MediaType.APPLICATION_JSON_VALUE);
        restEndpoint.setPath("accesspoint/" + urls.getUrl());
        restEndpoint.setBindingMode(RestConfiguration.RestBindingMode.json);
        restEndpoint.setMethod("post");
        restEndpoint.setInType(ApiTxnModel.class.getName());
        return restEndpoint;
    }

    private static String getHttpConsumerUri(String uriPath) {
        return "rest://post:" + "accesspoint/" + uriPath;
    }

    private static String getHttpProducerUri(String uriPath) {
        return "rest://post:" + uriPath;
    }

    public static RestEndpoint getRestProducerEndpoint(TargetConfigModel configModel, RoutingContext routingContext) {
        String targetUrl = TransactionProcessorHelper.getTxnUrl(configModel);
        String host = configModel.getConnections().get(0).getUrlOrIp();
        RestEndpoint restEndpoint = routingContext.getCamelContext()
                .getEndpoint(getHttpProducerUri(targetUrl), RestEndpoint.class);
        String port = configModel.getConnections().get(0).getPortOrHeaders();
        if (port != null && !port.isEmpty()) {
            host += ":" + port;
        }
        restEndpoint.setHost(host);
//        restEndpoint.setConsumes(MediaType.APPLICATION_JSON_VALUE);
//        restEndpoint.setProduces(MediaType.APPLICATION_JSON_VALUE);
        restEndpoint.setPath(targetUrl);
        restEndpoint.setBindingMode(RestConfiguration.RestBindingMode.json);
        restEndpoint.setMethod("post");
        restEndpoint.setProducerComponentName("netty-http");
//        NettyHttpComponent nettyHttpComponent = new NettyHttpComponent();
//        nettyHttpComponent.setConfiguration(getHttpProducerConfig(configModel));
//        restEndpoint.setComponent(nettyHttpComponent);
        return restEndpoint;
    }

    public static NettyEndpoint getHttpProducerEndpoint(CamelContext camelContext, TargetConfigModel configModel) {
        String targetUrl = TransactionProcessorHelper.getTxnUrl(configModel);
        String host = configModel.getConnections().get(0).getUrlOrIp();
        NettyHttpEndpoint nettyProducerEndpoint = camelContext.getEndpoint(getNettyHttpProducerUri(host + targetUrl),
                NettyHttpEndpoint.class);
        nettyProducerEndpoint.setConfiguration(NettyConfig.getHttpProducerConfig(configModel));
        return nettyProducerEndpoint;
    }

    private static NettyConfiguration getHttpProducerConfig(TargetConfigModel configModel) {
        NettyHttpConfiguration nettyConfig = new NettyHttpConfiguration();
        String targetUrl = TransactionProcessorHelper.getTxnUrl(configModel);
        String host = configModel.getConnections().get(0).getUrlOrIp();
        nettyConfig.setHost(host);
        nettyConfig.setPort(443);
//        nettyConfig.setProtocol("https");
        nettyConfig.setPath(targetUrl);
        nettyConfig.setUrlDecodeHeaders(false);
        nettyConfig.setLogWarnOnBadRequest(true);
        nettyConfig.setUseRelativePath(true);
        return nettyConfig;
    }

    private static String getNettyHttpProducerUri(String uriPath) {
        return "netty-http:" + uriPath;
    }

}