package com.isg.mw.routing.exception;

public class InvalidMessageException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidMessageException(String errorMsg) {
		super(errorMsg);
	}

	public InvalidMessageException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}
