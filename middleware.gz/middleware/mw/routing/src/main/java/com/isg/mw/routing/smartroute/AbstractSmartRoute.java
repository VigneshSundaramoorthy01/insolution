package com.isg.mw.routing.smartroute;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheHelper;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.StatsType;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.SmartRouteStatisticsModel;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.routing.smartroute.util.ResponseManipulatorUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Component
public abstract class AbstractSmartRoute implements ISmartRoute {

    private Logger logger = LogManager.getLogger();

    @Autowired
    protected CacheUtil cacheUtil;

    @Autowired
    protected CacheHelper cacheHelper;

    @Autowired
    protected SmartRouteSpringCacheService srCacheService;

    @Autowired
    private ResponseManipulatorUtil manipulatorUtil;

    @Override
    public synchronized void calculateSuccessRatio(SourceConfigModel sourceConfigModel,
                                                   SmartRouteConfigModel smartRouteConfigModel, OffsetDateTime threadCacheLastCalculatedDate) {
        Map<String, SourceInfo> sourceData = cacheUtil.getSourceData(cacheHelper.getSourceMapKey(sourceConfigModel));
        logger.debug("Current state of source in cache: {}, {}", sourceConfigModel.getName(), sourceData);

        Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        logger.debug("Current state of targets in cache for source: {}, {}", sourceConfigModel.getName(), targetData);

        targetData.forEach((targetKey, targetInfo) -> {
            int successTxns = targetInfo.getTotalTxnCount() - targetInfo.getTotalTxnFailed();
            if (targetInfo.getTotalTxnCount() > 0) {
                double successRatio = ((double) successTxns / (double) targetInfo.getTotalTxnCount()) * 100;
                targetInfo.setCurrentSuccessRatio(successRatio);
                targetInfo.setPreviousSuccessRatio(successRatio);
                cacheUtil.putTargetData(cacheHelper.getTargetMapKey(sourceConfigModel), targetKey, targetInfo);
                logger.info("Success ratio for target: {}, is {} and threshold is {}",
                        targetInfo.getTargetName(), successRatio, smartRouteConfigModel.getSuccessThreshold());
            }
        });

        SourceInfo sourceInfo = sourceData.get(sourceConfigModel.getId().toString());
        OffsetDateTime now = OffsetDateTime.now();
        sourceInfo.setLastCalculatedDate(now);
        cacheUtil.getLocalSourceCalculationTime().put(sourceConfigModel.getId().toString(), now);
        //following is to update last calculated date in cache
        cacheUtil.updateSourceLastCalculationDate(cacheHelper.getSourceMapKey(sourceConfigModel), smartRouteConfigModel.getSourceId().toString(),
                now);
    }

    @Override
    public synchronized void resetCache(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel) {
        //following is to reset source data in cache
        cacheUtil.putSourceData(cacheHelper.getSourceMapKey(sourceConfigModel), smartRouteConfigModel.getSourceId().toString(),
                new SourceInfo());

        Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        targetData.forEach((targetKey, targetInfo) -> {
            targetInfo.setTotalTxnCount(0);
            targetInfo.setTotalTxnFailed(0);
            targetInfo.setCurrentSuccessRatio(0d);
            cacheUtil.putTargetData(cacheHelper.getTargetMapKey(sourceConfigModel), targetKey, targetInfo);
        });
        logger.info("Cached data for the source {} and its target has been reset", sourceConfigModel.getName());
    }

    /**
     * @param sourceConfigModel
     * @param targetId
     * @param isAlive
     * @return -1 if target not found in test file
     * 0 if target is alive from test file
     * 1 if target is not alive from test file
     */
    protected boolean getAliveFromTestFile(SourceConfigModel sourceConfigModel, String targetId, boolean isAlive) {
        boolean tgtAlive = false;
        List<Target> targets = manipulatorUtil.readSimulatorTestFile();
        int testFileValue = -1;
        if (targets != null) {
            Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(
                    cacheHelper.getTargetMapKey(sourceConfigModel));
            Iterator<Map.Entry<TargetKey, TargetInfo>> entryIterator = targetData.entrySet().iterator();

            parent:
            while (entryIterator.hasNext()) {
                TargetKey targetKey = entryIterator.next().getKey();
                if (!targetKey.getTargetId().equals(targetId))
                    continue;
                TargetInfo targetInfo = targetData.get(targetKey);
                for (Target target : targets) {
                    if (target.getTargetName().equals(targetInfo.getTargetName())) {
                        testFileValue = target.getIsAlive() ? 0 : 1;
                        break parent;
                    }
                }
            }
        }
        tgtAlive = isTgtAlive(isAlive, tgtAlive, testFileValue);
        return tgtAlive;
    }

    private boolean isTgtAlive(boolean isAlive, boolean tgtAlive, int retValue) {
        switch (retValue) {
            case -1:
                tgtAlive = isAlive;
                break;
            case 0:
                tgtAlive = true;
                break;
            case 1:
                tgtAlive = false;
                break;
        }
        return tgtAlive;
    }

    protected boolean isThreadAllowedToCalculate(SourceConfigModel sourceConfigModel, OffsetDateTime threadCacheLastCalculatedDate) {
        OffsetDateTime cacheLastCalculatedDate = cacheUtil.getSourceLastCalculationDate(sourceConfigModel);
        /**
         * In case of multiple threads waiting on to calculate success ratio only 1 thread
         * will do the calculation and will update the timestamp and for others threadCacheLastCalculatedDate will
         * be outdated
         */
        return threadCacheLastCalculatedDate != null && threadCacheLastCalculatedDate.compareTo(cacheLastCalculatedDate) < 0;
    }

    protected boolean isTargetBelowThreshold(TargetInfo targetInfo, SmartRouteConfigModel smartRouteConfigModel) {
        return targetInfo.getCurrentSuccessRatio().compareTo(smartRouteConfigModel.getSuccessThreshold()) < 0;
    }

    @Override
    public void setTargetIsAlive(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, String targetId, boolean isAlive) {
        boolean tgtAlive = getAliveFromTestFile(sourceConfigModel, targetId, isAlive);

        String targetMapKey = cacheHelper.getTargetMapKey(sourceConfigModel);
        Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(
                targetMapKey);

        for (Map.Entry<TargetKey, TargetInfo> entry : targetData.entrySet()) {
            if (entry.getKey().getTargetId().equals(targetId)) {
                TargetInfo targetInfo = entry.getValue();
                targetInfo.setAlive(tgtAlive);
                cacheUtil.updateTargetIsAlive(targetMapKey, entry.getKey(), tgtAlive);
                logger.info("Target: {}, Is Alive: {}", targetInfo.getTargetName(), targetInfo.isAlive());
                break;
            }
        }
    }

    public boolean isCalculationNeeded(OffsetDateTime cacheLastCalculatedDate, String srcId) {
        OffsetDateTime localLastCalculatedDate = cacheUtil.getLocalSourceCalculationTime().get(srcId);
        logger.info("Local last calculated date for the source {} is {}", srcId, localLastCalculatedDate);
        if (localLastCalculatedDate != null && cacheLastCalculatedDate != null) {
            return localLastCalculatedDate.compareTo(cacheLastCalculatedDate) >= 0;
        }
        return true;
    }

    protected SmartRouteTargetDefinition getTargetDefinitionById(SmartRouteConfigModel
                                                                         smartRouteConfigModel, String targetId) {
        Optional<SmartRouteTargetDefinition> smartRouteTargetDefinition = smartRouteConfigModel.getTargetRouteConfig().stream()
                .filter(targetConfig -> targetConfig.getTargetId().toString().equals(targetId))
                .findFirst();
        return smartRouteTargetDefinition.orElse(null);
    }

    protected TargetConfigModel getTargetConfigById(RoutingContext routingContext, String targetId) {
        Optional<TargetConfigModel> targetConfigModel = routingContext.getTargets().stream()
                .filter(targetConfigModel1 ->
                        targetConfigModel1.getId().toString().equals(targetId))
                .findFirst();
        return targetConfigModel.orElse(null);
    }

    protected Map.Entry<TargetKey, TargetInfo> getTargetById(Map<TargetKey, TargetInfo> targets, String targetId) {
        return targets.entrySet().stream()
                .filter(entry -> entry.getKey().getTargetId().equals(targetId))
                .findFirst().orElse(null);
    }

    public SmartRouteStatisticsModel prepareStatsModel(SourceConfigModel sourceConfigModel,
                                                       SmartRouteConfigModel srModel, StatsType statsType) {
        Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        Map<String, SourceInfo> sourceData = cacheUtil.getSourceData(cacheHelper.getSourceMapKey(sourceConfigModel));
        List<TargetInfoStatistics> targetStats = new ArrayList<>(targetData.size());
        SmartRouteStatisticsModel model = new SmartRouteStatisticsModel();
        SourceInfoStatistics srcInfoStats = new SourceInfoStatistics();
        srcInfoStats.setSourceName(sourceConfigModel.getName());
        srcInfoStats.setSourceInfo(sourceData.get(srModel.getSourceId().toString()));
        srcInfoStats.setSuccessRatioThreshold(srModel.getSuccessThreshold());
        long seconds = (TimeUnit.MILLISECONDS.toSeconds(srModel.getSuccessRatioInterval()));
        srcInfoStats.setTps(
                ((double) sourceData.get(srModel.getSourceId().toString()).getTotalTxnCount() / seconds));
        model.setSourceInfoStats(srcInfoStats);
        model.setSourceId(srModel.getSourceId());
        model.setCalculationDate(cacheUtil.getLocalSourceCalculationTime().get(srModel.getSourceId().toString()));
        targetData.forEach((key, value) -> {
            targetStats.add(new TargetInfoStatistics(key.getTargetId(), value));
            model.setTargets(targetStats);
        });
        model.setEntityId(sourceConfigModel.getEntityId());
        model.setRouteType(srModel.getRouteType());
        model.setStatsType(statsType);
        logger.trace("Smart route stats model {}", model);
        return model;
    }

    public void logSmartRouteStatisticsToTlm(SourceConfigModel sourceConfigModel,
                                             SmartRouteConfigModel smartRouteConfigModel, StatsType statsType) {
        SmartRouteStatisticsModel srModel = prepareStatsModel(sourceConfigModel, smartRouteConfigModel, statsType);
        if (srModel != null) {
            KafkaProducer kafkaProducer = RoutingInitializationContext.getSrKafkaProducer();
            logger.debug("Logging Smart Route Statistics to TLM");
            kafkaProducer.sendMessage(srModel);
            logger.debug("Logged Smart Route Statistics to TLM");
        }
    }
}
