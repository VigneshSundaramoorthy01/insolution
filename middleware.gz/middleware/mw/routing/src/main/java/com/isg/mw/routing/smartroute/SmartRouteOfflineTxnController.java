package com.isg.mw.routing.smartroute;

import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.offline.*;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.utils.*;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.RequestValidationException;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_RES_API_TXN_MODEL;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_RES_TGT_TMM;

@Component
public class SmartRouteOfflineTxnController {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Autowired
    private ApiTransactionProcessor apiTransactionProcessor;

    @Autowired
    private CacheServices cacheServices;

    @Autowired
    private SmartRouteTxnController smartRouteTxnController;

    public String saveOfflineTransactionEnc(Exchange exchange, RoutingContext routingContext) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("saveOfflineTransactionEnc Body: {}", apiRequest);
        ApiTxnModel apiTxnModel = apiTransactionProcessor.decryptAndValidateSmartRouteRequest(apiRequest, exchange);
        String apiResponse = saveOfflineTransaction(exchange, routingContext,apiTxnModel);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }
    public String saveOfflineTransaction(Exchange exchange, RoutingContext routingContext) {
        String apiRequest = exchange.getIn().getBody(String.class);
        ApiTxnModel apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, ApiTxnModel.class);
        return saveOfflineTransaction(exchange,routingContext,apiTxnModel);
    }

    public String saveOfflineTransaction(Exchange exchange, RoutingContext routingContext,ApiTxnModel apiTxnModel) {
        String apiResponse;
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL,apiTxnModel);
        TransactionMessageModel reqSrcTmm = apiTxnModel.buildTmm();
        reqSrcTmm.setRequestReceivedTime(OffsetDateTime.now());
        String txnId = smartRouteTxnController.generateTransactionId();
        reqSrcTmm.setTransactionId(txnId);
        reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));
        if (apiTxnModel.getPayModeId().equals("5")) {
            reqSrcTmm.setTransactionName("offline.cash.request");
        } else if (apiTxnModel.getPayModeId().equals("6")) {
            reqSrcTmm.setTransactionName("offline.cheque.request");
        } else if (apiTxnModel.getPayModeId().equals("7")) {
            reqSrcTmm.setVanNumber("IBMS" + txnId);
            reqSrcTmm.setTransactionName("offline.neft.rtgs.request");
        }
        reqSrcTmm.setTlmMessageType(TlmMessageType.REQUEST);
        reqSrcTmm.setResCode("-1");
        reqSrcTmm.setMsgType("OfflinePay");
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        reqSrcTmm.setEntityId(routingContext.getEntityId());
        reqSrcTmm.setDrcrFlag("D");
        reqSrcTmm.setRequestSentTime(OffsetDateTime.now());
        reqSrcTmm.setMerchantTxnRefNo(apiTxnModel.getMerchantTxnRefNo());
        MapsInfoModel mapsInfoModel = cacheServices.validateAndGetMerchant(routingContext.getEntityId(), reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId(), null);
        reqSrcTmm.setTxnCurrencyCode(mapsInfoModel.getAcquirerCurrencyCode());
        processorHelper.logToTlm(reqSrcTmm, routingContext);
        TransactionMessageModel resTmm = SerializationUtils.clone(reqSrcTmm);
        resTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        processorHelper.logToTlm(resTmm, routingContext);
        apiResponse = apiTransactionProcessor.getApiResponse(ResponseMsgType.SUCCESS, "Transaction Initiated",
                generateSaveOfflineTxn(reqSrcTmm, routingContext, apiTxnModel));
        return apiResponse;
    }

    public String validateNeftRtgsTransactionEnc(Exchange exchange, RoutingContext routingContext) throws JAXBException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("validateNeftRtgsTransactionEnc Body: {}", apiRequest);
        String cval = (String) exchange.getIn().getHeader("cval");
        String generateChecksum = apiTransactionProcessor.generateChecksum(apiRequest);
        if (!cval.equals(generateChecksum)) {
            throw new RequestValidationException("Invalid Request :" + System.lineSeparator() + "$.checksum: is mismatched or invalid");
        }
        ValidateNeftRtgsTransactionRequest neftRtgsTransactionRequest = (ValidateNeftRtgsTransactionRequest) IsgXmlUtils.
                convertXmlToObject(apiRequest, ValidateNeftRtgsTransactionRequest.class);
        String apiResponse = validateNeftRtgsTransaction(exchange, routingContext,neftRtgsTransactionRequest);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String validateNeftRtgsTransaction(Exchange exchange, RoutingContext routingContext) throws JAXBException {
        String xmBody = exchange.getIn().getBody(String.class);
        logger.trace("validateNeftRtgsTransactionEnc Body: {}", xmBody);
//        ValidateOfflineTransactionRequest offlineTransactionRequest = (ValidateOfflineTransactionRequest) IsgXmlUtils.
//                convertXmlToObject(xmBody, ValidateOfflineTransactionRequest.class);
        ValidateNeftRtgsTransactionRequest neftRtgsTransactionRequest =  IsgJsonUtils.getObjectFromJsonString(xmBody, ValidateNeftRtgsTransactionRequest.class);
        return validateNeftRtgsTransaction(exchange,routingContext,neftRtgsTransactionRequest);
    }

    public String validateNeftRtgsTransaction(Exchange exchange, RoutingContext routingContext, ValidateNeftRtgsTransactionRequest transactionRequest) throws JAXBException {
        TransactionMessageModel reqSrcTmm = new TransactionMessageModel();
        String txnId = transactionRequest.getVan();
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        if (!StringUtils.isBlank(txnId)) {
            txnId = txnId.substring(4);
        }
        reqSrcTmm.setOriginalHashedTxnId(processorHelper.getHashedValue(txnId));
        TransactionMessageModel originalTmm = null;
        try{
            originalTmm = fetchOriginalTransaction(reqSrcTmm);
        }catch (Exception e){
            logger.info("Original transaction not found for NEFT/RTGS::");
        }
        ValidateNeftRtgsTransactionRequest response = new ValidateNeftRtgsTransactionRequest();
        response.setCustomerCode(transactionRequest.getCustomerCode());
        response.setVan(transactionRequest.getVan());
        response.setAmount(transactionRequest.getAmount());
        response.setUtr(transactionRequest.getUtr());
        response.setCurrencyCode(transactionRequest.getCurrencyCode());
        response.setPaymentMode(transactionRequest.getPaymentMode());
        response.setRemitterName(transactionRequest.getRemitterName());
        response.setRemitterMobileNo(transactionRequest.getRemitterMobileNo());
        response.setRemitterAccNo(transactionRequest.getRemitterAccNo());
        response.setRemitterBankName(transactionRequest.getRemitterBankName());
        response.setRemitterIfsc(transactionRequest.getRemitterIfsc());
        response.setCreditAccountNumber(transactionRequest.getCreditAccountNumber());
        response.setAddInfo(transactionRequest.getAddInfo());
        String jsonString;
        if (originalTmm != null) {
            List<String> payMode = getPayMode(originalTmm.getSmartRouteData().getPayModeId());
            if (originalTmm.getTxnAmt().equals(IsgCurrencyConversionUtils.getFixedLengthAmt(transactionRequest.getAmount(),12)) &&
                    payMode.contains(transactionRequest.getPaymentMode())) {
                response.setStatus("Accept");
                response.setRemark("Transaction Accepted");
            } else {
                response.setStatus("Reject");
                response.setRemark("Transaction Rejected");
            }
        } else {
            response.setStatus("Reject");
            response.setRemark("Original Transaction Not Found");
        }
        jsonString = IsgJsonUtils.getJsonString(response);
//        ValidateOffline`1`TransactionResponse xmlAttributeWithContent = getXmlAttributeWithContent(routingContext, offlineTransactionRequest, originalTmm);
//        String xmlResponse = IsgXmlUtils.convertObjectToXml(xmlAttributeWithContent, ValidateOfflineTransactionResponse.class);
        return jsonString;
    }

    private  List<String>  getPayMode(String payModeId) {
        List<String> list = new ArrayList();
        if(!StringUtils.isBlank(payModeId) && payModeId.equals("7")){
            list.add("RTGS");
            list.add("NEFT");
            list.add("IMPS");
        }
        return list;
    }

    public String saveNeftResponseEnc(Exchange exchange, RoutingContext routingContext) throws NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("saveOfflineResponse Body: {}", apiRequest);
        String cval = (String) exchange.getIn().getHeader("cval");
        String generateChecksum = apiTransactionProcessor.generateChecksum(apiRequest);
        if (!cval.equals(generateChecksum)) {
            throw new RequestValidationException("Invalid Request :" + System.lineSeparator() + "$.checksum: is mismatched or invalid");
        }
        SaveNeftRtgsTrabsactionResponse saveNeftRtgsReq = (SaveNeftRtgsTrabsactionResponse) IsgJsonUtils.
                getObjectFromJsonString(apiRequest, SaveNeftRtgsTrabsactionResponse.class);
        String apiResponse = saveNeftResponse(exchange, routingContext,saveNeftRtgsReq);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String saveNeftResponse(Exchange exchange, RoutingContext routingContext) {
        String apiRequest = exchange.getIn().getBody(String.class);
        SaveNeftRtgsTrabsactionResponse apiTxnModel = IsgJsonUtils.getObjectFromJsonString(apiRequest, SaveNeftRtgsTrabsactionResponse.class);
        return saveNeftResponse(exchange,routingContext,apiTxnModel);
    }

    public String saveNeftResponse(Exchange exchange, RoutingContext routingContext,SaveNeftRtgsTrabsactionResponse transactionRequest) {
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_RES_API_TXN_MODEL,transactionRequest);
        TransactionMessageModel reqSrcTmm = new TransactionMessageModel();
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        String txnId = transactionRequest.getVan();
        TransactionMessageModel originalTmm = null;
        if (!StringUtils.isBlank(txnId)) {
            txnId = txnId.substring(4);
        }
        reqSrcTmm.setOriginalHashedTxnId(processorHelper.getHashedValue(txnId));
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        try{
            originalTmm = fetchOriginalTransaction(reqSrcTmm);
        }catch (Exception e){
            logger.info("Original transaction not found for NEFT/RTGS::");
        }
        SaveNeftRtgsTrabsactionResponse response = new SaveNeftRtgsTrabsactionResponse();
        response.setCustomerCode(transactionRequest.getCustomerCode());
        response.setVan(transactionRequest.getVan());
        response.setAmount(transactionRequest.getAmount());
        response.setUtr(transactionRequest.getUtr());
        response.setRemitterName(transactionRequest.getRemitterName());
        response.setRemitterMobileNo(transactionRequest.getRemitterMobileNo());
        response.setRemitterAccNo(transactionRequest.getRemitterAccNo());
        response.setRemitterBankName(transactionRequest.getRemitterBankName());
        response.setRemitterIfsc(transactionRequest.getRemitterIfsc());
        response.setCreditAccountNumber(transactionRequest.getCreditAccountNumber());
        response.setAddInfo(transactionRequest.getAddInfo());
        response.setPaymentMode(transactionRequest.getPaymentMode());
        if (originalTmm != null) {
            response.setCurrencyCode(originalTmm.getTxnCurrencyCode());
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            Date date = Date.from(originalTmm.getRequestReceivedTime().toInstant());
            response.setTranDate(formatter.format(date));
            SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MM-yyyy HH:MM:SS");
            Date date2 = Date.from(originalTmm.getResponseSentTime().toInstant());
            response.setConfirmationDateTime(formatter2.format(date2));
            if (originalTmm.getResCode().equals("00")) {
                response.setConfirmationStatusCode("Reject");
                response.setConfirmationMessage("Transaction Already Settled For Given VAN No!");
            } else {
                if (originalTmm.getTxnAmt().equals(IsgCurrencyConversionUtils.getFixedLengthAmt(transactionRequest.getAmount(),12))) {
                    response.setConfirmationStatusCode("Accept");
                    response.setConfirmationMessage("Transaction Settled");
                    originalTmm.setResCode("00");
                } else {
                    response.setConfirmationStatusCode("Reject");
                    response.setConfirmationMessage("Amount Mismatched !");
                }
            }
            originalTmm.setTlmMessageType(TlmMessageType.RESPONSE);
            originalTmm.setResponseSentTime(OffsetDateTime.now());
            originalTmm.setMerchantTxnRefNo(originalTmm.getMerchantTxnRefNo());
            originalTmm.setMsgType(originalTmm.getMsgType());
            originalTmm.setTargetTxnId(transactionRequest.getUtr());
            originalTmm.setVanNumber(transactionRequest.getVan());
            originalTmm.getSmartRouteData().setPayModeOptionId(transactionRequest.getPaymentMode());
            originalTmm.setTransactionName(originalTmm.getTransactionName().replaceFirst(".request", ".response"));
            MapsInfoModel mapsInfoModel = cacheServices.validateAndGetMerchant(routingContext.getEntityId(), originalTmm.getCardAcceptorId(), originalTmm.getCardAcceptorTerminalId(), null);
            originalTmm.setTxnCurrencyCode(mapsInfoModel.getAcquirerCurrencyCode());
            processorHelper.logToTlm(originalTmm, routingContext);
        } else {
            response.setConfirmationStatusCode("Reject");
            response.setConfirmationMessage("Original Transaction Not Found !");
        }
        return IsgJsonUtils.getJsonString(response);
    }

    public String validateOfflineTransactionEnc(Exchange exchange, RoutingContext routingContext) throws JAXBException, NoSuchAlgorithmException {
        String apiRequest = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("validateOfflineTransactionEnc Body: {}", apiRequest);
        String cval = (String) exchange.getIn().getHeader("cval");
        String generateChecksum = apiTransactionProcessor.generateChecksum(apiRequest);
        if (!cval.equals(generateChecksum)) {
            throw new RequestValidationException("Invalid Request :" + System.lineSeparator() + "$.checksum: is mismatched or invalid");
        }
        ValidateOfflineTransactionRequest offlineTransactionRequest = (ValidateOfflineTransactionRequest) IsgXmlUtils.
                convertXmlToObject(apiRequest, ValidateOfflineTransactionRequest.class);
        String apiResponse = validateOfflineTransaction(exchange, routingContext,offlineTransactionRequest);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String validateOfflineTransaction(Exchange exchange, RoutingContext routingContext) throws JAXBException {
        String xmBody = exchange.getIn().getBody(String.class);
        logger.trace("validateOfflineTransactionEnc Body: {}", xmBody);
//        ValidateOfflineTransactionRequest offlineTransactionRequest = (ValidateOfflineTransactionRequest) IsgXmlUtils.
//                convertXmlToObject(xmBody, ValidateOfflineTransactionRequest.class);
        ValidateOfflineTransactionRequest offlineTransactionRequest =  IsgJsonUtils.getObjectFromJsonString(xmBody, ValidateOfflineTransactionRequest.class);
        return validateOfflineTransaction(exchange,routingContext,offlineTransactionRequest);
    }

    public String validateOfflineTransaction(Exchange exchange, RoutingContext routingContext, ValidateOfflineTransactionRequest offlineTransactionRequest) throws JAXBException {
        TransactionMessageModel reqSrcTmm = new TransactionMessageModel();
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        reqSrcTmm.setOriginalHashedTxnId(processorHelper.getHashedValue(offlineTransactionRequest.getClientValidateNo()));
        TransactionMessageModel originalTmm = null;
        try {
            originalTmm = fetchOriginalTransaction(reqSrcTmm);
        } catch (Exception e) {
            logger.info("Original transaction not found for NEFT/RTGS::");
        }
        ValidateOfflineTransactionResponse response = new ValidateOfflineTransactionResponse();
        response.setClientCode(offlineTransactionRequest.getClientCode());
        response.setClientValidateNo(offlineTransactionRequest.getClientValidateNo());
        String jsonString;
        if (originalTmm != null) {
            String txnAmt = originalTmm.getTxnAmt();
            response.setAmount(new BigDecimal(txnAmt).toString());
            if (originalTmm.getSmartRouteData().getPayModeId().equals(verifyPayMode(offlineTransactionRequest.getPayMode()))) {
                response.setStatus("Accept");
                response.setRejReason("");
            } else {
                response.setStatus("Reject");
                response.setRejReason("Pay Mode Doesn't Match!");
            }
        } else {
            response.setStatus("Reject");
            response.setRejReason("Original Transaction Not Found!");
        }
        jsonString = IsgJsonUtils.getJsonString(response);
//        ValidateOfflineTransactionResponse xmlAttributeWithContent = getXmlAttributeWithContent(routingContext, offlineTransactionRequest, originalTmm);
//        String xmlResponse = IsgXmlUtils.convertObjectToXml(xmlAttributeWithContent, ValidateOfflineTransactionResponse.class);
        return jsonString;
    }

    private String verifyPayMode(String paymentMode) {
        String payMode = null;
        if ("CA".equals(paymentMode)) {
            payMode = "5";
        } else if ("CQ".equals(paymentMode)) {
            payMode = "6";
        }
        return payMode;
    }


    public String saveOfflineResponseEnc(Exchange exchange, RoutingContext routingContext) throws JAXBException, NoSuchAlgorithmException {
        String xmBody = apiTransactionProcessor.decryptSmartRouteReq(exchange);
        logger.trace("saveOfflineResponse Body: {}", xmBody);
        String cval = (String) exchange.getIn().getHeader("cval");
        String generateChecksum = apiTransactionProcessor.generateChecksum(xmBody);
        if (!cval.equals(generateChecksum)) {
            throw new RequestValidationException("Invalid Request :" + System.lineSeparator() + "$.checksum: is mismatched or invalid");
        }
        SaveOfflineRequest saveOfflineReq = (SaveOfflineRequest) IsgXmlUtils.
                convertXmlToObject(xmBody, SaveOfflineRequest.class);
        String apiResponse = saveOfflineResponse(exchange, routingContext,saveOfflineReq);
        return apiTransactionProcessor.getSmartRouteEncApiResponse(exchange, apiResponse);
    }

    public String saveOfflineResponse(Exchange exchange, RoutingContext routingContext) throws JAXBException {
        String xmBody = exchange.getIn().getBody(String.class);
        logger.trace("saveOfflineResponse Body: {}", xmBody);
//        SaveOfflineRequest saveOfflineReq = (SaveOfflineRequest) IsgXmlUtils.
//                convertXmlToObject(xmBody, SaveOfflineRequest.class);
        SaveOfflineRequest saveOfflineReq = IsgJsonUtils.getObjectFromJsonString(xmBody, SaveOfflineRequest.class);
        return saveOfflineResponse(exchange, routingContext, saveOfflineReq);
    }

    public String saveOfflineResponse(Exchange exchange, RoutingContext routingContext,SaveOfflineRequest saveOfflineReq) throws JAXBException {
        TransactionMessageModel reqSrcTmm = new TransactionMessageModel();
        reqSrcTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        reqSrcTmm.setOriginalHashedTxnId(processorHelper.getHashedValue(saveOfflineReq.getClientValidateNo()));
        TransactionMessageModel originalTmm = null;
        try {
            originalTmm = fetchOriginalTransaction(reqSrcTmm);
        } catch (Exception e) {
            logger.info("Original transaction not found for NEFT/RTGS::");
        }
        SaveOfflineResponse saveOfflineResponse = new SaveOfflineResponse();
        saveOfflineResponse.setClientCode(saveOfflineReq.getClientCode());
        saveOfflineResponse.setClientValidateNo(saveOfflineReq.getClientValidateNo());
        if (originalTmm != null) {
            if (originalTmm.getResCode().equals("00")) {
                saveOfflineResponse.setStatus("Reject");
                saveOfflineResponse.setRejReason("Transaction Already Settled For Given Client Validate No!");
            } else {
                if (!originalTmm.getTxnAmt().equals(IsgCurrencyConversionUtils.getFixedLengthAmt(saveOfflineReq.getAmount(),12))) {
                    saveOfflineResponse.setStatus("Reject");
                    saveOfflineResponse.setRejReason("Amount Mismatched !");
                } else if (!originalTmm.getSmartRouteData().getPayModeId().equals(verifyPayMode(saveOfflineReq.getPayMode()))) {
                    saveOfflineResponse.setStatus("Reject");
                    saveOfflineResponse.setRejReason("Pay Mode Mismatched !");
                } else {
                    saveOfflineResponse.setStatus("Accept");
                    saveOfflineResponse.setRejReason("");
                    originalTmm.setResCode("00");
                }
            }
            originalTmm.setTlmMessageType(TlmMessageType.RESPONSE);
            originalTmm.setResponseSentTime(OffsetDateTime.now());
            reqSrcTmm.setResponseReceivedTime(OffsetDateTime.now());
            reqSrcTmm.setMerchantTxnRefNo(originalTmm.getMerchantTxnRefNo());
            originalTmm.setTransactionName(originalTmm.getTransactionName().replaceFirst(".request", ".response"));
            TransactionMessageModel.SmartRouteData smartRouteData = originalTmm.getSmartRouteData();
            TransactionMessageModel.OfflineTransactionData offlineTxnData = smartRouteData.getOfflineTxnData();
            offlineTxnData.setMicrCode(saveOfflineReq.getMicrCode());
            offlineTxnData.setBankName(saveOfflineReq.getBankName());
            offlineTxnData.setBranchName(saveOfflineReq.getBranchName());
            offlineTxnData.setInstrumentNo(saveOfflineReq.getInstrumentNo());
            offlineTxnData.setInstrumentDate(saveOfflineReq.getInstrumentDate());
            offlineTxnData.setUserId(saveOfflineReq.getUserId());
            smartRouteData.setOfflineTxnData(offlineTxnData);
            originalTmm.setTargetTxnId(saveOfflineReq.getIsureid());
            processorHelper.logToTlm(originalTmm, routingContext);
        } else {
            saveOfflineResponse.setStatus("Reject");
            saveOfflineResponse.setRejReason("Original Transaction Not Found !");
        }
        String xmlResponse = IsgJsonUtils.getJsonString(saveOfflineResponse);
        return xmlResponse;
    }


    private SaveOfflineTransaction generateSaveOfflineTxn(TransactionMessageModel reqSrcTmm,
                                                          RoutingContext routingContext, ApiTxnModel apiTxnModel) {
        SaveOfflineTransaction saveOfflineModel = new SaveOfflineTransaction();
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        MerchantMasterModel merchantMasterModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchantMaster(routingContext.getEntityId(), reqSrcTmm.getCardAcceptorId());

        saveOfflineModel.setTransactionId(reqSrcTmm.getTransactionId());
        saveOfflineModel.setTxnDate(formatter.format(date));
        saveOfflineModel.setTotalTxnAmt(IsgCurrencyConversionUtils.convertPaisaToRupees(reqSrcTmm.getTxnAmt()));
        saveOfflineModel.setTxnAmt(IsgCurrencyConversionUtils.convertPaisaToRupees(reqSrcTmm.getTxnAmt()));
        saveOfflineModel.setConvFee(0L);
        saveOfflineModel.setGst(0L);
        saveOfflineModel.setEmailId(merchantMasterModel.getMerchantEmail());
        saveOfflineModel.setMobNo(merchantMasterModel.getMerchantMobNo());
        saveOfflineModel.setOrderInfo(apiTxnModel.getOrderInfo());
        saveOfflineModel.setChequeNumber(apiTxnModel.getChequeNumber());
        saveOfflineModel.setAccountNumber("IBMS"+merchantMasterModel.getAccountNo());
        saveOfflineModel.setIfscCode(CacheSrConfigProperties.getProperty("offline.txn.ifsc.code"));
        saveOfflineModel.setMerchantName(merchantMasterModel.getMerchantName());
        if(!StringUtils.isBlank(apiTxnModel.getChequeDate())) {
            saveOfflineModel.setChequeDate(apiTxnModel.getChequeDate());
        }else{
            saveOfflineModel.setChequeDate("");
        }
        return saveOfflineModel;
    }

//    private ValidateOfflineTransactionResponse getXmlAttributeWithContent(RoutingContext routingContext,
//                                                                          ValidateOfflineTransactionRequest offlineTransactionRequest,
//                                                                          TransactionMessageModel originalTmm) {
//        ValidateOfflineTransactionResponse res = new ValidateOfflineTransactionResponse();
//        MerchantMasterModel merchantMasterModel = SpringContextBridge.services().getCacheService().
//                validateAndGetMerchantMaster(routingContext.getEntityId(), originalTmm.getCardAcceptorId());
//
//        ValidateOfflineTransactionResponse.ClientCode cCode = new ValidateOfflineTransactionResponse.ClientCode();
//        cCode.setClientCode(offlineTransactionRequest.getClientCode());
//        cCode.setLabelname("Client Code");
//        cCode.setDispflg(ActiveFlag.N.name());
//        cCode.setPopflg(ActiveFlag.Y.name());
//        cCode.setEditflg(ActiveFlag.N.name());
//        res.setClientCode(cCode);
//
//        ValidateOfflineTransactionResponse.IcmmMerchantName icmmMerName = new ValidateOfflineTransactionResponse.IcmmMerchantName();
//        icmmMerName.setIcmmMerchantName(merchantMasterModel.getMerchantName());
//        icmmMerName.setLabelname("Merchant Name");
//        icmmMerName.setDispflg(ActiveFlag.Y.name());
//        icmmMerName.setPopflg(ActiveFlag.Y.name());
//        icmmMerName.setEditflg(ActiveFlag.N.name());
//        res.setIcmmMerchantName(icmmMerName);
//
//        ValidateOfflineTransactionResponse.IctMobNo ictMobNo = new ValidateOfflineTransactionResponse.IctMobNo();
//        ictMobNo.setIctMobNo(merchantMasterModel.getMerchantMobNo());
//        ictMobNo.setLabelname("Payer Mobile No");
//        ictMobNo.setDispflg(ActiveFlag.Y.name());
//        ictMobNo.setPopflg(ActiveFlag.Y.name());
//        ictMobNo.setEditflg(ActiveFlag.N.name());
//        res.setIctMobNo(ictMobNo);
//
//
//        ValidateOfflineTransactionResponse.ClientValidateNo clientValidateNo = new ValidateOfflineTransactionResponse.ClientValidateNo();
//        clientValidateNo.setClientValidateNo(originalTmm.getTransactionId());
//        clientValidateNo.setLabelname("Unique Ref no");
//        clientValidateNo.setDispflg(ActiveFlag.Y.name());
//        clientValidateNo.setPopflg(ActiveFlag.Y.name());
//        clientValidateNo.setEditflg(ActiveFlag.N.name());
//        res.setClientValidateNo(clientValidateNo);
//
//        ValidateOfflineTransactionResponse.IctTranAmt ictTranAmt = new ValidateOfflineTransactionResponse.IctTranAmt();
//        ictTranAmt.setIctTranAmt(Double.valueOf(originalTmm.getTxnAmt()).intValue());
//        ictTranAmt.setLabelname("Amount");
//        ictTranAmt.setDispflg(ActiveFlag.Y.name());
//        ictTranAmt.setPopflg(ActiveFlag.Y.name());
//        ictTranAmt.setEditflg(ActiveFlag.N.name());
//        res.setIctTranAmt(ictTranAmt);
//
//        ValidateOfflineTransactionResponse.IctInstrumentType ictInstrumentType = new ValidateOfflineTransactionResponse.IctInstrumentType();
//        ictInstrumentType.setIctInstrumentType("");
//        ictInstrumentType.setLabelname("Instrument Type");
//        ictInstrumentType.setDispflg(ActiveFlag.Y.name());
//        ictInstrumentType.setPopflg(ActiveFlag.Y.name());
//        ictInstrumentType.setEditflg(ActiveFlag.N.name());
//        res.setIctInstrumentType(ictInstrumentType);
//
//        ValidateOfflineTransactionResponse.Status status = new ValidateOfflineTransactionResponse.Status();
//        status.setStatus("accept");
//        status.setLabelname("Status");
//        status.setDispflg(ActiveFlag.Y.name());
//        status.setPopflg(ActiveFlag.Y.name());
//        status.setEditflg(ActiveFlag.N.name());
//        res.setStatus(status);
//
//        ValidateOfflineTransactionResponse.PayMode payMode = new ValidateOfflineTransactionResponse.PayMode();
//        payMode.setPayMode(originalTmm.getSmartRouteData().getPayModeId());
//        payMode.setLabelname("Client Paymode");
//        payMode.setDispflg(ActiveFlag.Y.name());
//        payMode.setPopflg(ActiveFlag.Y.name());
//        payMode.setEditflg(ActiveFlag.N.name());
//        res.setPayMode(payMode);
//        return res;
//    }
}

