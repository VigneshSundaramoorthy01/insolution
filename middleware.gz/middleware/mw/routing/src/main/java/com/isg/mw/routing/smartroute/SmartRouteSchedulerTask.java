package com.isg.mw.routing.smartroute;

import com.isg.mw.core.model.constants.StatsType;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SmartRouteSchedulerTask implements Runnable {
    private Logger logger = LogManager.getLogger();

    @Setter
    private SourceConfigModel sourceConfigModel;

    @Setter
    private SmartRouteConfigModel smartRouteConfigModel;

    @Autowired
    protected CacheUtil cacheUtil;

    @Override
    public void run() {
        logger.info("Calculating success ratio for source: {}", sourceConfigModel.getName());

        ISmartRoute smartRoute = SmartRouteFactory.getSmartRoute(smartRouteConfigModel.getRouteType());

        OffsetDateTime cacheLastCalculatedDate = cacheUtil.getSourceLastCalculationDate(sourceConfigModel);
        if (((AbstractSmartRoute) smartRoute).isCalculationNeeded(cacheLastCalculatedDate, sourceConfigModel.getId().toString())) {
            smartRoute.calculateSuccessRatio(sourceConfigModel, smartRouteConfigModel, cacheLastCalculatedDate);
            ((AbstractSmartRoute) smartRoute).logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.CALCULATION_INTERVAL);
            smartRoute.resetCache(sourceConfigModel, smartRouteConfigModel);

            logger.info("Success ratio calculation completed for source: {}", sourceConfigModel.getName());
        }
    }

}
