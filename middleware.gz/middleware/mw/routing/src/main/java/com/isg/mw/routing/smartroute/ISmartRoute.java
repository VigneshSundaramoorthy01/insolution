package com.isg.mw.routing.smartroute;

import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import org.apache.camel.Exchange;

import java.time.OffsetDateTime;

public interface ISmartRoute {

    void calculateSuccessRatio(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel,
                               OffsetDateTime cacheLastCalculatedDate);

    void resetCache(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel);

    TargetConfigModel getTxnTarget(Exchange exchange, TransactionMessageModel reqSrcTmm);

    void setTargetIsAlive(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, String targetId, boolean isAlive);

    RouteType getRouteType();
}
