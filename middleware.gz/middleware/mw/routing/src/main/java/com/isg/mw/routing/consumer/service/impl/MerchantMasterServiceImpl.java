package com.isg.mw.routing.consumer.service.impl;


import com.isg.mw.cache.mgmt.config.CacheHelper;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.SmartRouteConfigService;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.hitachi.HitachiMerchantResponseModel;
import com.isg.mw.core.model.icici.UpiResponse;
import com.isg.mw.core.model.lyra.LyraMerchantResponseModel;
import com.isg.mw.core.model.lyra.LyraWibmoMerchantResponseModel;
import com.isg.mw.core.model.payu.PayUAccessTokenResponseModel;
import com.isg.mw.core.model.payu.PayUMerchantModel;
import com.isg.mw.core.model.pos.MosambeeRegTidResponseModel;
import com.isg.mw.core.model.pos.MosambeeResponseModel;
import com.isg.mw.core.model.pos.MosambeeUpdateStatusResponseModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.model.tpsl.TpslMerchantResponseModel;
import com.isg.mw.core.model.vizpay.VizPayMerchantResponseModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.transform.hitachi.HitachiMessageTransformation;
import com.isg.mw.mtm.transform.icici.IciciMessageTransformation;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import com.isg.mw.mtm.transform.mosambee.MosambeeMessageTransformation;
import com.isg.mw.mtm.transform.payu.PayUMessageTransformation;
import com.isg.mw.mtm.transform.pos.PosMessageTransformation;
import com.isg.mw.mtm.transform.tpsl.TpslMessageTransformation;
import com.isg.mw.routing.consumer.service.MerchantMasterService;
import com.isg.mw.routing.consumer.service.MerchantMasterServicesHelper;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service("merchantMasterService")
public class MerchantMasterServiceImpl implements MerchantMasterService {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private CacheUtil cacheUtil;

    @Autowired
    private CacheHelper cacheHelper;

    @Autowired
    private InitRestClient initRestClient;

    @Autowired
    private MerchantMasterServicesHelper merMasterServiceHelper;

    @Autowired
    private SmartRouteConfigService smartRouteConfigService;


    @Override
    public List<TargetMerchantMasterModel> getTargetMerchantMasterModels(MerchantMasterModel merchantMasterModel, Class<?> className, String targetType) {
        List<TargetConfigModel> targetConfigs = initRestClient.getTargetConfigs();
        List<TargetConfigModel> targetConfigMasters = targetConfigs.stream().filter(tmodel -> tmodel.getEntityId().equals(merchantMasterModel.getEntityId())).
                filter(tmodel -> tmodel.getTargetType().toString().equals(targetType)).collect(Collectors.toList());
        List<TargetMerchantMasterModel> targetMerchantModels = new ArrayList<>();
        for (TargetConfigModel targetModel : targetConfigMasters) {
            if (targetModel.getAdditionalData().getMerchantOnboardFlag().equals(ActiveFlag.Y.name())) {
                getTargetMerchantModel(targetModel, merchantMasterModel, className, targetMerchantModels,targetConfigs);
            }
        }
        return targetMerchantModels;
    }

    private void getTargetMerchantModel(TargetConfigModel targetModel, MerchantMasterModel merchantMasterModel,
                                        Class<?> className, List<TargetMerchantMasterModel> targetMerchantModels, List<TargetConfigModel> targetConfigs) {
        TargetMerchantMasterModel targetMerchantMasterModel = new TargetMerchantMasterModel();
        targetMerchantMasterModel.setTargetId(targetModel.getId());
        targetMerchantMasterModel.setMid(merchantMasterModel.getMid());
        targetMerchantMasterModel.setTid(merchantMasterModel.getTid());
        List<TargetType> targetTypes = merchantMasterModel.getTargetTypes();
        if(targetTypes != null && !targetTypes.isEmpty()) {
            if ("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType()) &&
                    !("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND"))) {
                if (targetModel.getTargetType() == TargetType.PayU && targetTypes.contains(TargetType.PayU)) {
                    targetMerchantMasterModel = callPayUMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);
                    targetMerchantModels.add(targetMerchantMasterModel);
                } else if (targetModel.getTargetType() == TargetType.Icici && targetTypes.contains(TargetType.Icici)) {
                    targetMerchantMasterModel = callIciciMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);
                    targetMerchantModels.add(targetMerchantMasterModel);
                } else if (targetModel.getTargetType() == TargetType.Tpsl && targetTypes.contains(TargetType.Tpsl)) {
                    targetMerchantMasterModel = callTpslMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);
                    targetMerchantModels.add(targetMerchantMasterModel);
                } else if (targetModel.getTargetType() == TargetType.Lyra && targetTypes.contains(TargetType.Lyra)) {
                    targetMerchantMasterModel = callLyraMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel, targetConfigs);
                    targetMerchantModels.add(targetMerchantMasterModel);
                } else if (targetModel.getTargetType() == TargetType.Wibmo && targetTypes.contains(TargetType.Wibmo)) {
                    targetMerchantMasterModel = callWibmoMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);
                    targetMerchantModels.add(targetMerchantMasterModel);
                }else if (("Y".equalsIgnoreCase(merchantMasterModel.getEmiAllowedFlag())) &&
                        (targetModel.getTargetType() == TargetType.Hitachi && targetTypes.contains(TargetType.Hitachi))) {
                    targetMerchantMasterModel = callHitachiMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);
                    targetMerchantModels.add(targetMerchantMasterModel);
                }
            } else if(("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND"))
                    && targetModel.getTargetType() == TargetType.VizPay && targetTypes.contains(TargetType.VizPay)){
                targetMerchantMasterModel = callVizPayMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);
                targetMerchantModels.add(targetMerchantMasterModel);
            }else if ("POS".equalsIgnoreCase(merchantMasterModel.getIntegrationType()) && targetModel.getTargetType() == TargetType.Icici
                    && targetTypes.contains(TargetType.Icici) &&
                    !("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND"))) {
                callPosMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel, targetConfigs);
            } else if ("POS".equalsIgnoreCase(merchantMasterModel.getIntegrationType()) && targetModel.getTargetType() == TargetType.Icici &&
                    targetTypes.size() == 1 && targetTypes.contains(TargetType.Lyra)
                    && !("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND"))) {
                TargetMerchantMasterModel masterModel = SerializationUtils.clone(targetMerchantMasterModel);
                TargetMerchantMasterModel targetMerchantMaster = merMasterServiceHelper.fetchCacheTargetMerchantMaster(targetModel.getId().toString(), merchantMasterModel.getMid());
                String merchantVpa = targetMerchantMaster.getMerchantVpa();//cacheUtil.getMerchantVpa(targetModel.getId().toString(), merchantMasterModel.getMid(), merchantMasterModel.getTid());
                String targetMid = targetMerchantMaster.getTargetMid();//cacheUtil.getTargetMid(targetModel.getId().toString(), merchantMasterModel.getMid(), merchantMasterModel.getTid());
                if (!StringUtils.isBlank(merchantVpa) && !StringUtils.isBlank(targetMid)) {
                    targetMerchantMasterModel.setMerchantVpa(merchantVpa);
                    targetMerchantMasterModel.setTargetMid(targetMid);
                    targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
                    callPosLyraOnboardApi(merchantMasterModel, targetMerchantMasterModel, masterModel, targetConfigs);
                } else {
                    logger.info("MERCHANT VPA IS NOT CREATED FOR GIVEN MERCHANT : {}", masterModel.getMid());
                }
            } else if ("POS".equalsIgnoreCase(merchantMasterModel.getIntegrationType()) && targetModel.getTargetType() == TargetType.Mosambee
                    && targetTypes.contains(TargetType.Mosambee)) {
                callPosMosambeeMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel, targetConfigs);
                targetMerchantModels.add(targetMerchantMasterModel);
            }
        }
    }

    private TargetMerchantMasterModel callHitachiMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel, Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel) {
        HitachiMerchantResponseModel hitachiMerchantResponseModel = new HitachiMerchantResponseModel();
        if ("Pg".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            try {
                HitachiMessageTransformation hitachiMessageTransformation = (HitachiMessageTransformation) className.newInstance();
                hitachiMerchantResponseModel = merMasterServiceHelper.callHitachiCreateMerchantApi(hitachiMessageTransformation, merchantMasterModel, targetModel);
            } catch (Exception e) {
                logger.error("Exception while Calling Vizpay Merchant API: {}  ", e);
                targetMerchantMasterModel.setExceptionMessage(e.getMessage());
            }
        }
        if ((hitachiMerchantResponseModel != null && hitachiMerchantResponseModel.getResMessage() == null)) {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        } else {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
            targetMerchantMasterModel.setExceptionMessage(hitachiMerchantResponseModel != null ? hitachiMerchantResponseModel.getResMessage() : "Exception While calling Wibmo API");
            targetMerchantMasterModel.setDpaId(null);
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        }
        return targetMerchantMasterModel;
    }

    private TargetMerchantMasterModel callVizPayMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel, Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel) {
        VizPayMerchantResponseModel vizPayMerchantResponseModel = null;
        if ("SOUND BOX".equalsIgnoreCase(merchantMasterModel.getTerminalType()) || merchantMasterModel.getTerminalType().toUpperCase().startsWith("SOUND")) {
            try {
                IciciMessageTransformation iciciMessageTransformation = (IciciMessageTransformation) className.newInstance();
                vizPayMerchantResponseModel = merMasterServiceHelper.callVizPayCreateMerchantApi(iciciMessageTransformation, merchantMasterModel, targetModel);
            } catch (Exception e) {
                logger.error("Exception while Calling Vizpay Merchant API: {}  ", e);
                targetMerchantMasterModel.setExceptionMessage(e.getMessage());
            }
        }
        if ((vizPayMerchantResponseModel != null && vizPayMerchantResponseModel.getResMessage() == null)) {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        } else {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
            targetMerchantMasterModel.setExceptionMessage(vizPayMerchantResponseModel != null ? vizPayMerchantResponseModel.getResMessage() : "Exception While calling Wibmo API");
            targetMerchantMasterModel.setDpaId(null);
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        }
        return targetMerchantMasterModel;
    }

    private TargetMerchantMasterModel callWibmoMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel, Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel) {

        LyraWibmoMerchantResponseModel wibmoMerchantResponseModel = null;
        if ("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            try {
                LyraMessageTransformation lyraMessageTransformation = (LyraMessageTransformation) className.newInstance();
                wibmoMerchantResponseModel = merMasterServiceHelper.callWibmoLyraCreateMerchantApi(lyraMessageTransformation, merchantMasterModel, targetModel);
            } catch (Exception e) {
                logger.error("Exception while Calling WIMBO Merchant API: {}  ", e);
                targetMerchantMasterModel.setExceptionMessage(e.getMessage());
            }
        }
        if ((wibmoMerchantResponseModel != null && wibmoMerchantResponseModel.getResMessage() == null)) {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setDpaId(wibmoMerchantResponseModel.getMdesSrciDpaId());
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        } else {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
            targetMerchantMasterModel.setExceptionMessage(wibmoMerchantResponseModel != null ? wibmoMerchantResponseModel.getResMessage() : "Exception While calling Wibmo API");
            targetMerchantMasterModel.setDpaId(null);
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        }
        return targetMerchantMasterModel;
    }

    private TargetMerchantMasterModel callLyraMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel, Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel, List<TargetConfigModel> targetConfigs) {
        LyraMerchantResponseModel responseModel = null;
        if ("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            TargetConfigModel wimboConfigModel = targetConfigs.stream().filter(tmodel -> tmodel.getEntityId().equals(merchantMasterModel.getEntityId())).
                    filter(tmodel -> tmodel.getTargetType().toString().equals(TargetType.Wibmo.name())).findFirst().orElse(null);
            try {
                LyraMessageTransformation lyraMessageTransformation = (LyraMessageTransformation) className.newInstance();
                responseModel = merMasterServiceHelper.callLyraCreateMerchantApi(lyraMessageTransformation, merchantMasterModel, targetModel);
            } catch (Exception e) {
                logger.error("Exception while Calling Lyra PG Merchant API: {}  ", e);
                targetMerchantMasterModel.setExceptionMessage(e.getMessage());
            }
            if ((responseModel != null && responseModel.getResMessage() == null)) {
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
                targetMerchantMasterModel.setKey(responseModel.getBusiness() != null ? responseModel.getBusiness().getRegistrationId():null);
                targetMerchantMasterModel.setTargetMid(responseModel.getShop() != null ? responseModel.getShop().getShopId():merchantMasterModel.getMid());
                targetMerchantMasterModel.setProdApiKey(responseModel.getShop() != null ?responseModel.getShop().getApiKeyProd():null);
                targetMerchantMasterModel.setTestApiKey(responseModel.getShop() != null ?responseModel.getShop().getApiKeyTest():null);
                targetMerchantMasterModel.setDpaId(wimboConfigModel != null ? wimboConfigModel.getId().toString() : null);
            } else {
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
                targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
                targetMerchantMasterModel.setProdApiKey(null);
                targetMerchantMasterModel.setTestApiKey(null);
                targetMerchantMasterModel.setExceptionMessage(responseModel != null ? responseModel.getResMessage() : "Exception While calling PG Lyra API");
                targetMerchantMasterModel.setDpaId(wimboConfigModel != null ? wimboConfigModel.getId().toString() : null);
            }
        } else if ("POS".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            try {
                LyraMessageTransformation lyraMessageTransformation = (LyraMessageTransformation) className.newInstance();
                responseModel = merMasterServiceHelper.callLyraPosCreateMerchantApi(lyraMessageTransformation, merchantMasterModel, targetModel);
            } catch (Exception e) {
                logger.error("Exception while Calling Lyra POS Merchant API: {}  ", e);
                targetMerchantMasterModel.setExceptionMessage(e.getMessage());
            }

            if (responseModel != null && responseModel.getResMessage() == null) {
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
                if (responseModel.getBusiness() != null) {
                    targetMerchantMasterModel.setTargetMid(responseModel.getBusiness().getRegistrationId() != null ? responseModel.getBusiness().getRegistrationId() : merchantMasterModel.getMid());
                }
                targetMerchantMasterModel.setProdApiKey(responseModel.getShop() != null ? responseModel.getShop().getApiKeyProd() : null);
                targetMerchantMasterModel.setTestApiKey(responseModel.getShop() != null ? responseModel.getShop().getApiKeyTest() : null);
            } else {
                targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
                targetMerchantMasterModel.setMerchantVpa(null);
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
                targetMerchantMasterModel.setExceptionMessage(responseModel != null ? responseModel.getResMessage() : "Exception While calling POS Lyra API");
            }
        }
        return targetMerchantMasterModel;
    }

    private void callPosMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel, Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel, List<TargetConfigModel> targetConfigs) {
//        TargetMerchantMasterModel targetMerMastModel;
        TargetMerchantMasterModel masterModel = SerializationUtils.clone(targetMerchantMasterModel);

        //call POS UPI onboarding API
        targetMerchantMasterModel = callIciciMerchantApi(merchantMasterModel, targetModel, className, targetMerchantMasterModel);

        sendTargetMerchantMasterToCm(targetMerchantMasterModel);

        //call POS Lyra onboarding API
        callPosLyraOnboardApi(merchantMasterModel, targetMerchantMasterModel, masterModel, targetConfigs);
    }

    private void callPosLyraOnboardApi(MerchantMasterModel merchantMasterModel, TargetMerchantMasterModel targetMerMastModel,
                                       TargetMerchantMasterModel masterModel, List<TargetConfigModel> targetConfigs) {
        //call POS Lyra onboarding API
        TargetConfigModel configModel = targetConfigs.stream().filter(tmodel -> tmodel.getEntityId().equals(merchantMasterModel.getEntityId())).
                filter(tmodel -> tmodel.getTargetType().toString().equals(TargetType.Lyra.name())).findFirst().orElse(null);
//        TargetMerchantMasterModel tmmModel=null;
        if (targetMerMastModel.getStatus() == ActiveInactiveFlag.Active.name()) {
            merchantMasterModel.setMerchantVpa(targetMerMastModel.getMerchantVpa());
            if (configModel.getAdditionalData().getMerchantOnboardFlag().equals(ActiveFlag.Y.name())) {
                masterModel.setTargetId(configModel.getId());
                masterModel = callLyraMerchantApi(merchantMasterModel, configModel, LyraMessageTransformation.class, masterModel, targetConfigs);
                sendTargetMerchantMasterToCm(masterModel);
            }
        } else if (targetMerMastModel.getStatus() == ActiveInactiveFlag.Failed.name()) {
            masterModel.setTargetId(configModel.getId());
            masterModel.setTargetMid(merchantMasterModel.getMid());
            masterModel.setMerchantVpa(null);
            masterModel.setStatus(ActiveInactiveFlag.Failed.name());
            sendTargetMerchantMasterToCm(masterModel);
        }
    }

    private TargetMerchantMasterModel callTpslMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel, Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel) {
        if ("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            TpslMerchantResponseModel responseModel = null;
            try {
                TpslMessageTransformation tpslMessageTransformation = (TpslMessageTransformation) className.newInstance();
                responseModel = merMasterServiceHelper.callTpslCreateMerchantApi(tpslMessageTransformation, merchantMasterModel, targetModel);
            } catch (Exception e) {
                logger.error("Exception while Calling TPSL Merchant API: {}  ", e);
            }
            if (responseModel != null && responseModel.getResMessage() == null) {
                targetMerchantMasterModel.setTargetMid(responseModel.getUniqueId());
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            } else {
                targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
                targetMerchantMasterModel.setExceptionMessage(responseModel.getResMessage());
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
            }
        }
        return targetMerchantMasterModel;
    }


    private TargetMerchantMasterModel callIciciMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel,
                                                           Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel) {
        UpiResponse upiResponse = null;
        try {
            IciciMessageTransformation iciciMessageTransformation = (IciciMessageTransformation) className.newInstance();
            upiResponse = merMasterServiceHelper.callIciciMerApi(iciciMessageTransformation, targetModel, merchantMasterModel);
        } catch (Exception e) {
            logger.error("Exception while Calling ICICI UPI Merchant API: {}  ", e);
            targetMerchantMasterModel.setExceptionMessage(e.getMessage());
        }
        if (upiResponse != null && "0".equalsIgnoreCase(upiResponse.getActCode())
                && upiResponse.getResMessage() == null) {
            targetMerchantMasterModel.setMerchantVpa(upiResponse.getPayeeVpa());
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setTargetMid(!StringUtils.isBlank(upiResponse.getUserProfile()) ? upiResponse.getUserProfile() : merchantMasterModel.getMid());
        } else {
            targetMerchantMasterModel.setMerchantVpa(null);
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
            targetMerchantMasterModel.setExceptionMessage(upiResponse.getResMessage());
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid() );
        }
        return targetMerchantMasterModel;
    }

    public TargetMerchantMasterModel callPayUMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetModel,
                                                         Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel) {
        if ("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            PayUMerchantModel payUMerchantModel = null;
            PayUMessageTransformation payUMessageTransformation = null;
            PayUAccessTokenResponseModel accessTokenResModel = null;
            try {
                payUMessageTransformation = (PayUMessageTransformation) className.newInstance();
                accessTokenResModel = merMasterServiceHelper.callAccesssTokenApi(payUMessageTransformation, targetModel);
                payUMerchantModel = merMasterServiceHelper.callPayUCreateMerchant(payUMessageTransformation, targetModel, merchantMasterModel, accessTokenResModel);
            } catch (Exception e) {
                logger.error("Exception while Calling PayU Merchant API: {}  ", e);
                targetMerchantMasterModel.setExceptionMessage(e.getMessage());
            }
            ResponseObj.Credentials merchantCredentials = null;
            if (payUMerchantModel != null && payUMerchantModel.getMid() != 0 && payUMerchantModel.getResMessage() == null) {
                try {
                    merchantCredentials = merMasterServiceHelper.callPayMerchantCredApi(targetModel, payUMerchantModel, accessTokenResModel);
                } catch (Exception e) {
                    logger.error("Exception while getting PayU Merchant credentials: {}  ", e);
                    targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
                    targetMerchantMasterModel.setExceptionMessage(e.getMessage());
                }
                if (merchantCredentials != null) {
                    targetMerchantMasterModel.setTargetMid(String.valueOf(payUMerchantModel.getMid()));
                    targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
                    targetMerchantMasterModel.setKey(merchantCredentials.getKey());
                    targetMerchantMasterModel.setSalt(merchantCredentials.getSalt());
                } else if (merchantCredentials == null) {
                    targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
                    targetMerchantMasterModel.setExceptionMessage("Failed To Get Merchant credentials");
                }
            } else if (accessTokenResModel == null || payUMerchantModel == null) {
                targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
                targetMerchantMasterModel.setExceptionMessage(payUMerchantModel.getResMessage());
            }
            targetMerchantMasterModel.setMerchantVpa(null);
        }
        return targetMerchantMasterModel;
    }

    public boolean sendTargetMerchantMasterToCm(TargetMerchantMasterModel targetMerchantMasterModel) {
        String url = MTMProperties.getProperty("send.target.merchant.master");

        logger.info("Calling CM Api To Update Target Merchant Master In DB : {} ", url);
        TransactionMessageModel tmm = null;
        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            HttpEntity request = new HttpEntity<>(targetMerchantMasterModel, headers);
            ResponseEntity<String> exchange = restTemplate.exchange(url,
                    HttpMethod.POST, request, String.class);
            HttpStatus statusCode = exchange.getStatusCode();
            if(statusCode ==  HttpStatus.OK){
                return true;
            }
            logger.info("Updated Model Successfully In Database With status : {}  and response Body : {} " ,statusCode , exchange.getBody());
        } catch (RuntimeException e) {
            logger.error("Failed to post target merchant master model " + e);
        }
        return false;
    }


    private TargetMerchantMasterModel callPosMosambeeMerchantApi(MerchantMasterModel merchantMasterModel, TargetConfigModel targetConfigModel,
                                                                 Class<?> className, TargetMerchantMasterModel targetMerchantMasterModel, List<TargetConfigModel> targetConfigModelList) {
        MosambeeResponseModel mosResModel = null;
        MosambeeRegTidResponseModel mosRegTidResModel = null;
        MosambeeUpdateStatusResponseModel mosUpdateStatusResModel = null;
        logger.info("Calling Mosambee Pos Merchant API :  ");
        TargetMerchantMasterModel targetMerchantMaster = merMasterServiceHelper.fetchCacheTargetMerchantMaster(targetConfigModel.getId().toString(), merchantMasterModel.getMid());

        try {

            MosambeeMessageTransformation mosambeeMessageTransformation = (MosambeeMessageTransformation) className.newInstance();
            if (merchantMasterModel.getIsMosambeeTidRegEnable()) {
                if (targetMerchantMaster != null && !StringUtils.isBlank(targetMerchantMaster.getTargetMid())) {
                    String refId = targetMerchantMaster.getTargetMid();
                    mosRegTidResModel = merMasterServiceHelper.callPosMosambeeMerchantRegisterTidApi(mosambeeMessageTransformation, merchantMasterModel, targetConfigModel, refId);
                }
            } else if (merchantMasterModel.getIsMosambeeUpdateEnable()) {
                if (merchantMasterModel.getStatus().equals(ActiveInactiveFlag.Inactive)) {
                    if (targetMerchantMaster != null && !StringUtils.isBlank(targetMerchantMaster.getTargetMid())) {
                        String refId = targetMerchantMaster.getTargetMid();
                        mosUpdateStatusResModel = merMasterServiceHelper.callPosMosambeeMerchantUpdateStatusApi(mosambeeMessageTransformation, merchantMasterModel, targetConfigModel, refId);
                    } else {
                        mosResModel = merMasterServiceHelper.callPosMosambeeMerchantApi(mosambeeMessageTransformation, merchantMasterModel, targetConfigModel);
                    }
                } else {
                    mosResModel = merMasterServiceHelper.callPosMosambeeMerchantApi(mosambeeMessageTransformation, merchantMasterModel, targetConfigModel);
                }
            } else {
                mosResModel = merMasterServiceHelper.callPosMosambeeMerchantApi(mosambeeMessageTransformation, merchantMasterModel, targetConfigModel);
            }
        } catch (Exception e) {
            logger.error("Exception while Calling Mosambee Merchant API: {}  ", e);
            targetMerchantMasterModel.setExceptionMessage(e.getMessage());
        }
        if ((mosResModel != null && mosResModel.getMidDetails() != null)) {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setTargetMid(mosResModel.getMerchantRefNo());
            targetMerchantMasterModel.setTestApiKey(mosResModel.getMidDetails().getTidDetails().get(0).getTidRefId());
        } else if ((mosRegTidResModel != null && mosRegTidResModel.getTidDetails() != null)) {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setTargetMid(mosRegTidResModel.getMidRefId());
            targetMerchantMasterModel.setTid(merchantMasterModel.getTid());
            targetMerchantMasterModel.setTestApiKey(mosRegTidResModel.getTidDetails().get(0).getTidRefId());
        } else if (mosUpdateStatusResModel != null && mosUpdateStatusResModel.getResponseCode().equals("00")) {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Active.name());
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
        } else {
            targetMerchantMasterModel.setStatus(ActiveInactiveFlag.Failed.name());
            targetMerchantMasterModel.setTargetMid(merchantMasterModel.getMid());
            if (merchantMasterModel.getIsMosambeeTidRegEnable()) {
                targetMerchantMasterModel.setExceptionMessage(mosRegTidResModel.getResMessage());
            } else if (merchantMasterModel.getStatus().equals(ActiveInactiveFlag.Inactive) && targetMerchantMaster != null && !StringUtils.isBlank(targetMerchantMaster.getTargetMid())) {
                targetMerchantMasterModel.setExceptionMessage(mosUpdateStatusResModel.getResMessage());
            } else if (merchantMasterModel.getIsMosambeeAddEnable() || merchantMasterModel.getIsMosambeeUpdateEnable()) {
                targetMerchantMasterModel.setExceptionMessage(mosResModel.getResMessage());
            } else {
                targetMerchantMasterModel.setExceptionMessage("");
            }
        }
        return targetMerchantMasterModel;
    }

}
