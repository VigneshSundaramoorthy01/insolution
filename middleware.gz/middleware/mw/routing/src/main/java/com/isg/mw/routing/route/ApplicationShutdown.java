package com.isg.mw.routing.route;

import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ApplicationShutdown implements ApplicationListener<ContextClosedEvent> {

    private final Logger logger = LogManager.getLogger();

    @Autowired
    private NetworkManagement networkManagement;

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        List<RoutingContext> routingContextList = RoutingInitializationContext.getRoutingContextList();
        routingContextList.forEach(routingContext -> {
        	networkManagement.doDyanmicKeyDeactivation(routingContext);
            networkManagement.doHostSessionDeactivation(routingContext);
            networkManagement.doSignOff(routingContext);
        });

    }
}
