package com.isg.mw.routing.route;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.uuid.Generators;
import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.init.InitProps;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.common.FundTransferRequestModel;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.cybs.CybsMsgType;
import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.core.model.construct.sr.SmartRouteMsgTypeHelper;
import com.isg.mw.core.model.dstm.MacFields;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.maps.MerchantPanData;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.PaymentLinksModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.notification.model.DataElements;
import com.isg.mw.core.notification.model.NotificationReqModel;
import com.isg.mw.core.notification.model.NotificationResModel;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.utils.*;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.exception.*;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.transform.pos.util.MandatoryFieldUtility;
import com.isg.mw.mtm.util.MtmConstants;
import com.isg.mw.mtm.util.MwRedisCacheUtil;
import com.isg.mw.routing.config.NettyConfig;
import com.isg.mw.routing.config.RoutingConstants;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.exception.*;
import com.isg.mw.routing.notification.model.NotificationReqBody;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import com.isg.mw.routing.util.RouteUtil;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.DatatypeConverter;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

import static com.isg.mw.core.model.constants.CommonConstants.*;
import static com.isg.mw.core.utils.LogUtils.buildLogMessage;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;
import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.mtm.transform.MessageTransformer.constructMessage;
import static com.isg.mw.mtm.transform.TmmConstants.*;
import static com.isg.mw.routing.config.RoutingConstants.*;

@Component
public class TransactionProcessorHelper {
    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private PosSwitchTransactionProcessor posSwitchProcessor;

    private static Map<String, TransactionMessageModel> map = new HashMap<>();
    
    @Autowired
    private SwitchRouter switchRouterService;

    @Autowired
    private CacheServices cacheService;

    @Autowired
    private HsmCommonService hsmCommonService;

    @Autowired
    private ApiTransactionProcessor apiTransactionProcessor;

    @Autowired
    private NotificationReqBody notificationReqBody;

    @Autowired
    private InitProps initProps;
    
    @Autowired
    private MwRedisCacheUtil mwRedisCacheUtil;

    public void processNormalTxn(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        if (SourceProcessor.SMART_ROUTE.equals(reqSrcTmm.getSourceProcessor())
                && (REFUND_TXN.equalsIgnoreCase(reqSrcTmm.getMsgType()) || REVERSAL_TXN.equalsIgnoreCase(reqSrcTmm.getMsgType()))) {
            TransactionMessageModel originalTmm = fetchOriginalTransaction(reqSrcTmm);
            if (originalTmm != null && "00".equalsIgnoreCase(originalTmm.getResCode())) {
                TransactionMessageModel.SmartRouteData originalSRData = originalTmm.getSmartRouteData();
                if(originalSRData != null && (originalSRData.getPayModeId().equalsIgnoreCase("5")
                    || originalSRData.getPayModeId().equalsIgnoreCase("6") ||
                        originalSRData.getPayModeId().equalsIgnoreCase("7"))){
                    throw new InvalidRefundTransactionException("Refund Not Applicable For Offline Transaction.");
                }
                String creditAccNo = getBankAccountNoByPaymentMode(originalTmm);
                logger.info("Fund Transfer Bank Acc No  : {}",creditAccNo);
                exchange.getIn().getHeaders().put(EXCHANGE_HEADER_FUND_TRANSFER_BANK_ACC_NO, creditAccNo);
                JSONObject jsonObject = callChargeBack(originalTmm.getTransactionId());
                if (jsonObject != null) {
                    throw new ChargebackFoundException("ChargeBack is initiated for given transaction id.");
                } else {
                    if ("Y".equalsIgnoreCase(MTMProperties.getProperty("pg.sr.icici.fund.transfer.enable"))) {
                        logger.info("Calling Fund Transfer API : ");
                        MerchantMasterModel merchantMaster = cacheService.validateAndGetMerchantMaster(routingContext.getEntityId(), reqSrcTmm.getCardAcceptorId());
                        if (StringUtils.isBlank(merchantMaster.getAccountNo())) {
                            throw new AccountDetailsMissingException("Merchant account details are missing");
                        }

                        //Amount exceeded check for RETAIL and CORPORATE Txn
                        if(IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType()) ||
                                IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())){
                            validateRefundRequest(reqSrcTmm, originalTmm);
                        }
                        JSONObject fundTransferResp = callFundTransferApi("PG",originalTmm, merchantMaster.getAccountNo(),
                                creditAccNo,reqSrcTmm.getTxnAmt(),null);
                        if (fundTransferResp != null) {
                            String actCodeText;
                            try {
                                actCodeText = fundTransferResp.getJSONObject("ActCode").get("#text").toString();
                                exchange.getIn().setHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE,fundTransferResp);
                            } catch (Exception e) {
                                logger.info("Error While Calling Fund Transfer API :");
                                e.printStackTrace();
                                exchange.getIn().setHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE, null);
                                return;
                            }
                            logger.info("Fund Transfer Act Code Text : {} ", actCodeText);
                            if (!StringUtils.isBlank(actCodeText) && (actCodeText.equalsIgnoreCase("000") || actCodeText.equalsIgnoreCase("913"))) {
                                logger.info("Calling Refund API After Fund Transfer : ");
                                if (IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType()) ||
                                        IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())) {
                                    TransactionMessageModel resSrcTmm = saveCibRibNetBankingRefundToTlm(reqSrcTmm, routingContext, originalTmm, "00");
                                    exchange.getIn().setBody(resSrcTmm);
                                    return;
                                } else {
                                    validateRefundRequest(reqSrcTmm, originalTmm);
                                }
                            } else {
                                if (IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType()) ||
                                        IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())) {
                                    TransactionMessageModel resSrcTmm = saveCibRibNetBankingRefundToTlm(reqSrcTmm, routingContext, originalTmm, "96");
                                    exchange.getIn().setHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE, new JSONObject());
                                    exchange.getIn().setBody(resSrcTmm);
                                    return;
                                } else {
                                    logger.info("Initial Fund Transfer Failed : ");
                                    exchange.getIn().setHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE, null);
                                    return;
                                }
                            }
                        } else {
                            logger.info("Error While Calling Fund Transfer API : ");
                            exchange.getIn().setHeader(EXCHANGE_HEADER_FUND_TRANSFER_RESPONSE, null);
                            return;
                        }
                    }else {
                        logger.info("Calling Refund API Without Fund Transfer : ");
                        if (IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType()) ||
                                IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())) {
                            throw new InvalidRefundTransactionException("Fund Transfer Disabled,Hence Refund Has Been Failed");
                        } else {
                            validateRefundRequest(reqSrcTmm, originalTmm);
                        }
                    }
                }
            } else {
                throw new InvalidVoidOrReversalDataException("NotFound");
            }
        }
        /*
         * Identify target end point and send request to target
         */
        TargetConfigModel tgtEndPoint = switchRouterService.getTargetEndpointNew(routingContext, exchange, reqSrcTmm);

        ConnectionType targetConnectionType = tgtEndPoint.getConnections().get(0).getType();

        if (targetConnectionType == ConnectionType.ISO) {
            processISORequest(exchange, reqSrcTmm, routingContext, tgtEndPoint);
        } else if (targetConnectionType == ConnectionType.API) {
            processAPIRequest(exchange, reqSrcTmm, routingContext, tgtEndPoint);
        }
    }

    private TransactionMessageModel saveCibRibNetBankingRefundToTlm(TransactionMessageModel reqSrcTmm, RoutingContext routingContext,
                                                 TransactionMessageModel originalTmm, String resCode) {
        if (IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())){
            reqSrcTmm.setTransactionName("icici.nb.corporate.refund.request");
        }else if( IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())){
            reqSrcTmm.setTransactionName("icici.nb.retail.refund.request");
        }
        reqSrcTmm.setDrcrFlag("C");
        reqSrcTmm.setTlmMessageType(TlmMessageType.REQUEST);
        logToTlm(reqSrcTmm, routingContext);
        reqSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        if(!StringUtils.isBlank(resCode) && !("00".equalsIgnoreCase(resCode))){
            String replace = reqSrcTmm.getTransactionName().replace(".request", ".response");
            reqSrcTmm.setTransactionName("decline." + replace);
        }else {
            reqSrcTmm.setTransactionName(reqSrcTmm.getTransactionName().replace(".request", ".response"));
        }
        reqSrcTmm.setResCode(resCode);
        logToTlm(reqSrcTmm, routingContext);
        if (IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())){
            reqSrcTmm.setMsgType(IciciMsgType.NbCorpRefund.msgType);
        }else if( IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType())){
            reqSrcTmm.setMsgType(IciciMsgType.NbRetailRefund.msgType);
        }
        return reqSrcTmm;
    }

    public void validateRefundRequest(TransactionMessageModel reqSrcTmm, TransactionMessageModel originalTmm) {
        Set<String> txnTypeNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                .get(originalTmm.getTargetType() + "." + reqSrcTmm.getMsgType() + "." + originalTmm.getSmartRouteData().getPayModeId());
        reqSrcTmm.setOriginalTmm(originalTmm);
        reqSrcTmm.setTransactionName(txnTypeNameSet.stream().findFirst().orElse(null));
        reqSrcTmm.setEntityId(originalTmm.getEntityId());
        reqSrcTmm.setTarget(originalTmm.getTarget());
        reqSrcTmm.setCardAcceptorId(originalTmm.getCardAcceptorId());
        reqSrcTmm.setCardAcceptorTerminalId(originalTmm.getCardAcceptorTerminalId());
        reqSrcTmm.setSmartRouteData(originalTmm.getSmartRouteData());
        reqSrcTmm.setTxnCurrencyCode(originalTmm.getTxnCurrencyCode());
        reqSrcTmm.setTargetMid(originalTmm.getTargetMid());
        reqSrcTmm.setTxnSource(originalTmm.getTxnSource());
        reqSrcTmm.setMaskedPan(originalTmm.getMaskedPan());
        reqSrcTmm.setEncryptedPan(originalTmm.getEncryptedPan());
        reqSrcTmm.setResSmartRouteData(originalTmm.getResSmartRouteData());
        reqSrcTmm.setCardType(originalTmm.getCardType());
        reqSrcTmm.setOriginalTargetTransactionId(originalTmm.getTargetTxnId());
        reqSrcTmm.setOriginalTransactionId(originalTmm.getTransactionId());
//        reqSrcTmm.setMerchantTxnRefNo(originalTmm.getMerchantTxnRefNo());
        validateDependentTransaction(reqSrcTmm);
    }

    public void processAPIRequest(Exchange exchange, TransactionMessageModel reqSrcTmm, RoutingContext routingContext, TargetConfigModel tgtEndPoint) {
        if (PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
            processPgOnlineOfflineRefund(exchange, reqSrcTmm, routingContext, tgtEndPoint);
        } /*else if (reqSrcTmm.getSourceProcessor().equals(SourceProcessor.SMART_ROUTE)
                && reqSrcTmm.getMsgType().equalsIgnoreCase(REFUND_TXN)) {
            TransactionMessageModel originalTmm = fetchOriginalTransaction(reqSrcTmm);
            reqSrcTmm.setOriginalTmm(originalTmm);
        }*/
        TransactionMessageModel resSrcTmm = apiTransactionProcessor.sendApiRequest(exchange, reqSrcTmm, tgtEndPoint);
        String txnUrl = null;
        if (resSrcTmm.getTargetType() == TargetType.PayU || resSrcTmm.getTargetType() == TargetType.Tpsl ||
                resSrcTmm.getTargetType() == TargetType.Icici || resSrcTmm.getTargetType() == TargetType.Lyra) {
            txnUrl = getTxnUrl(tgtEndPoint);
        }
        prepareResTargetTmm(reqSrcTmm, resSrcTmm, txnUrl, resSrcTmm.getRawResponse(), routingContext);
        if (PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
            setSourceDataInResponse(reqSrcTmm, resSrcTmm);
            resSrcTmm.getPgData().setOnlineRefundAuthIdRes(resSrcTmm.getAuthIdRes());
            resSrcTmm.getPgData().setOnlineRefundResCode(resSrcTmm.getResCode());
            resSrcTmm.setPgData(resSrcTmm.getPgData());
            resSrcTmm.setSourceProcessor(SourceProcessor.PG_SWITCH);
            logToTlm(resSrcTmm, routingContext);
        }
        exchange.getIn().setBody(resSrcTmm);
    }

    public String callCardChargeBack(String txnId,String tid) {
        String url = MTMProperties.getProperty("pos.card.charge.back.api.url");
        url = url + "?" + "id="+txnId+ "&" + "tID=" + tid;
        Object res = null;
        try {
            res = RoutingInitializationContext.getMwProducer().callGetApiUsingWebClient(null, url, null);
            return (String)res;
        } catch (Exception e) {
            logger.info("Failed To call Charge back API {}", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public String callUpiChargeBack(String txnId,String tid) {
        String url = MTMProperties.getProperty("pos.upi.charge.back.api.url");
        url = url + "?" + "id="+txnId+ "&" + "tID=" + tid;
        Object res = null;
        try {
            res = RoutingInitializationContext.getMwProducer().callGetApiUsingWebClient(null, url, null);
            if (res != null) {
                ObjectMapper mapper = new ObjectMapper();
                Map<String, String> nodeMap = null;
                nodeMap = mapper.readValue((String) res, new TypeReference<Map<String, String>>() {
                });
                res = nodeMap.get("STATUS");

            }
            return (String) res;
        } catch (Exception e) {
            logger.info("Failed To call Charge back API {}", e.getMessage());
            e.printStackTrace();
        }

        return null;
    }

    public JSONObject callChargeBack(String txnId) {
        String url = MTMProperties.getProperty("charge.back.api.url");
        url = url + "id="+txnId;
        Object res = null;
        try {
            res = RoutingInitializationContext.getMwProducer().callGetApiUsingWebClient(null, url, null);
            JSONObject jsonObject = null;
            if (res != null && res.toString().startsWith("200##")) {
                jsonObject =  new JSONObject(res);
                return jsonObject;
            }
        } catch (Exception e) {
            logger.info("Failed To call Charge back API {}", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }


    public JSONObject callFundTransferApi(String integrationType,TransactionMessageModel originalTmm, String srcAccNo, String destAccNo,String refundAmt,String posRRN) {
        FundTransferRequestModel model = new FundTransferRequestModel();
        model.getTranAmt().setText(getAmountStr(refundAmt,16));
        model.getAuthNum().setText(generateAuthRandom());
        model.getLocalTxnDtTime().setText(getDate("yyyyMMddHHmmss"));
        model.getCaptureDt().setText(getDate("yyyyMMdd"));
        model.getAccNum().setText(getSrcAccountNo(srcAccNo));
        model.getDestAccNum().setText(getDestAccountNo(destAccNo));
        if ("PG".equalsIgnoreCase(integrationType)) {
            model.getDeliveryChannelCtrlID().setText(MTMProperties.getProperty("pg.smart.route.fund.transfer.channel.id"));
            model.getAddnDataPvt125().setText(MTMProperties.getProperty("pg.smart.route.fund.transfer.addn.data.pvt.125")+originalTmm.getTransactionId());
        } else if ("POS".equalsIgnoreCase(integrationType)) {
            model.getDeliveryChannelCtrlID().setText(MTMProperties.getProperty("pos.smart.route.fund.transfer.channel.id"));
            model.getAddnDataPvt125().setText(MTMProperties.getProperty("pos.smart.route.fund.transfer.addn.data.pvt.125")+posRRN);
        }
        String jsonString = IsgJsonUtils.getJsonString(model);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Connection","keep-alive");
        headers.setContentType(MediaType.APPLICATION_JSON);
//        JSONObject json =new JSONObject(jsonString);
        HttpEntity<String> request = new HttpEntity(jsonString, headers);
        ResponseEntity<String> response= null;
        JSONObject jsonObject = null;
        logger.info("Jks Path For Fund Transfer :: {} ",MTMProperties.getProperty("fund.transfer.provider.path"));
        UpiKeyModel upiKeyModel = RSAUtil.readProviders(new File(MTMProperties.getProperty("fund.transfer.provider.path")));
        String url=null;
        if ("PG".equalsIgnoreCase(integrationType)) {
            url = MTMProperties.getProperty("pg.smart.route.fund.transfer.url");
        } else if ("POS".equalsIgnoreCase(integrationType)) {
            url = MTMProperties.getProperty("pos.smart.route.fund.transfer.url");
        }
        try {
            logger.info("Request For Calling Fund Transfer API Url: {} with Request: {} ", url , request);

            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadKeyMaterial(RSAUtil.loadKeyStore(upiKeyModel.getKeyStorePath(), upiKeyModel.getKeyStoreCred(), "JKS"),
                            upiKeyModel.getKeyStoreCred().toCharArray())
                    .loadTrustMaterial(null, new TrustSelfSignedStrategy()).build();

            // Create a custom HttpClient with the custom SSLContext
            CloseableHttpClient httpClient = HttpClients.custom().setSSLContext(sslContext)
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();

            // Create an HttpComponentsClientHttpRequestFactory with the custom HttpClient
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
            requestFactory.setConnectTimeout(10000);
            restTemplate.setRequestFactory(requestFactory);
            response =restTemplate.postForEntity(url, request, String.class);
        } catch (Exception e) {
//            response = new ResponseEntity<>(MTMProperties.getProperty("fund.transfer.response"),HttpStatus.OK);
            logger.info("Error While calling fund transfer API :{}" , e.getMessage());
        }
        logger.info("Response From Fund Transfer API : {}",response);
        if (response != null) {
            String body = response.getBody();
            try {
                jsonObject = new JSONObject(body);
                logger.info("Fund Transfer Json Body : {}",jsonObject);
            }catch (Exception e){
                logger.info("Json Parsing Failed While Fund Transfer : {}",e.getMessage());
                return null;
            }
        }
        return jsonObject;
    }

    private String generateAuthRandom() {
        String format = String.format("%012d", new BigInteger(UUID.randomUUID().toString().replace("-", ""), 16));
        format = format.substring(format.length() - 12);
        return format;
    }

    public static String getAmountStr(String amount, int length) {
        String amt = "00";
        if (!StringUtils.isBlank(amount)) {
            amt = amount;
        }
        return getFixedLengthData(amt, true, '0', length);
    }

    public static String getFixedLengthData(String data, boolean prefix, char fixStr, int length) {

        String ppStr = EMPTY_STR;
        String localdata = data;
        int dl = 0;
        if (data != null) {
            dl = data.length();
            if (dl > length) {

            }
        } else {
            localdata = EMPTY_STR;
        }
        for (int i = 0; i < length - dl; i++) {
            ppStr += fixStr;
        }
        if (prefix == true) {
            return ppStr + localdata;
        } else {
            return localdata + ppStr;
        }

    }

    public static String getSrcAccountNo(String accNum ) {
        String accountNo="ICI";
        accountNo= StringUtils.rightPad(accountNo,11," ")+accNum.substring(0,4);
        accountNo= StringUtils.rightPad(accountNo,19," ")+accNum;
        return accountNo;
    }

    public static String getDestAccountNo(String accNum ) {
        String accountNo="  ICI";
        accountNo= StringUtils.rightPad(accountNo,13," ")+accNum.substring(0,4);
        accountNo= StringUtils.rightPad(accountNo,21," ")+accNum;
        return accountNo;
    }

    public static String getDate(String pattern) {
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern(pattern);
        String format = myFormatObj.format(myDateObj);
        return format;
    }

    private static int generateRandom() {
        int MIN_VALUE = 100000;
        int MAX_VALUE = 999999;
        Set<Integer> generatedNumbers = new HashSet<>();
        Random random = new Random();
        int randomNum = 0;
        int uniqueNumberCount = 0;
        while (uniqueNumberCount < (MAX_VALUE - MIN_VALUE + 1)) {
            randomNum = random.nextInt(MAX_VALUE - MIN_VALUE + 1) + MIN_VALUE;

            if (!generatedNumbers.contains(randomNum)) {
                generatedNumbers.add(randomNum);
                uniqueNumberCount++;
                break;
            }
        }
        return randomNum;
    }

    private void processPgOnlineOfflineRefund(Exchange exchange, TransactionMessageModel reqSrcTmm, RoutingContext routingContext, TargetConfigModel tgtEndPoint) {
        TransactionMessageModel isCaptureTmm = SerializationUtils.clone(reqSrcTmm);
        isCaptureTmm.setMsgType(CybsMsgType.CapturePay.msgType);

        TransactionMessageModel reqSrcCaptureTmm = null;
        try {
            reqSrcCaptureTmm = fetchOriginalTransaction(isCaptureTmm);
        } catch (InvalidVoidOrReversalDataException ex) {
            if (reqSrcCaptureTmm == null) {
                reqSrcCaptureTmm = SerializationUtils.clone(reqSrcTmm);
                reqSrcCaptureTmm.setTransactionId(generateTransactionId());
                reqSrcCaptureTmm.setMsgType("0220");
                reqSrcCaptureTmm.setProcessingCode("03");
                reqSrcCaptureTmm.setTransactionName("pg.capture.request");

                logger.trace(LogUtils.buildLogMessage(reqSrcCaptureTmm.getEntityId(), reqSrcCaptureTmm.getSource(),
                        reqSrcCaptureTmm.getMsgType(), reqSrcCaptureTmm.getTransactionId(), reqSrcCaptureTmm.getTransactionName(),
                        "Request Source Transaction Message Model: " + reqSrcCaptureTmm));
                logToTlm(reqSrcCaptureTmm);
                TransactionMessageModel resSrcCaptureTmm = apiTransactionProcessor.sendApiRequest(exchange, reqSrcCaptureTmm, tgtEndPoint);
                //TODO: capture response should be stored in TLM
                setSourceDataInResponse(reqSrcCaptureTmm, resSrcCaptureTmm);
                resSrcCaptureTmm.getPgData().setOnlineRefundAuthIdRes(resSrcCaptureTmm.getAuthIdRes());
                resSrcCaptureTmm.getPgData().setOnlineRefundResCode(resSrcCaptureTmm.getResCode());
                resSrcCaptureTmm.setPgData(resSrcCaptureTmm.getPgData());
                resSrcCaptureTmm.setSourceProcessor(SourceProcessor.PG_SWITCH);
                logToTlm(resSrcCaptureTmm, routingContext);
            }
        }
    }

    private void processISORequest(Exchange exchange, TransactionMessageModel reqSrcTmm, RoutingContext routingContext, TargetConfigModel tgtEndPoint) {
        logger.info(LogUtils.buildLogMessage(reqSrcTmm.getEntityId(), reqSrcTmm.getSource(), reqSrcTmm.getMsgType(),
                reqSrcTmm.getTransactionId(), reqSrcTmm.getTransactionName(), "Constructing transaction for target: " + tgtEndPoint.getName()));
        MessageContext tgtMsgCtx = MessageTransformer.constructMessage(reqSrcTmm, tgtEndPoint.getName());
        TransactionMessageModel reqTgtTmm = prepareTgtMessageAndLogTlm(tgtMsgCtx, routingContext);
        reqTgtTmm.setTargetType(tgtEndPoint.getTargetType());

        logger.info("tgtEndPoint getTargetType :: {} ", tgtEndPoint.getTargetType().name());
        // putting RRN in header so that RoutingCorrelationManager can extract it.
        if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(tgtEndPoint.getTargetType().name())){
            exchange.getIn().getHeaders().put(RoutingConstants.CORRELATION_ID, reqTgtTmm.getAquirerIdCode() +TmmConstants.CORRELATION_ID_SEPARATOR +
                    reqTgtTmm.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR+reqTgtTmm.getStan());
        }else{
            exchange.getIn().getHeaders().put(RoutingConstants.CORRELATION_ID, reqTgtTmm.getRetrievalRefNo());
        }

        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_TGT_TMM, reqTgtTmm);

        NettyEndpoint producerEndpoint = (NettyEndpoint) exchange.getIn().getHeaders()
                .get(EXCHANGE_HEADER_TARGET_SCHEME);

        TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) tgtMsgCtx.getRawMsg(), reqTgtTmm);

        String correlationId = null;
        if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(tgtEndPoint.getTargetType().name())){
            correlationId = reqTgtTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTgtTmm.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR+reqTgtTmm.getStan();
        }else{
            correlationId = reqTgtTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTgtTmm.getRetrievalRefNo();
        }
        logger.info("Target Co-relation Id :: {} ", correlationId);

        Object resMessage = RoutingInitializationContext.getMwProducer().sendMessage(tgtMsgCtx.getRawMsg(),
                correlationId, producerEndpoint);
        logger.info(LogUtils.buildLogMessage(reqSrcTmm.getEntityId(), reqSrcTmm.getSource(), reqSrcTmm.getMsgType(),
                reqSrcTmm.getTransactionId(), reqSrcTmm.getTransactionName(), "Transaction sent to target: " + tgtEndPoint.getName()));

        /*
         * set camel exchange with response received from target end point
         */
        if (resMessage != null) {
        	reqTgtTmm = null;
            TransactionMessageModel resSrcTmm = null;
            if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(tgtEndPoint.getTargetType().name())){
                 resSrcTmm = MessageTransformer.toResponsePojo(tgtEndPoint.getEntityId(), tgtEndPoint.getName(), (byte[]) resMessage, reqSrcTmm.getTransactionName());
                //getDataforReversal(resSrcTmm);
            } else {
                 resSrcTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, reqSrcTmm.getTransactionName());
            }
            prepareResTargetTmm(reqSrcTmm, resSrcTmm, producerEndpoint.getEndpointUri(), resMessage, routingContext);
            resSrcTmm.setConnectionType(tgtEndPoint.getConnections().get(0).getType());
            if (PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
                setSourceDataInResponse(reqSrcTmm, resSrcTmm);
                resSrcTmm.getPgData().setOnlineRefundAuthIdRes(resSrcTmm.getAuthIdRes());
                resSrcTmm.getPgData().setOnlineRefundResCode(resSrcTmm.getResCode());
                resSrcTmm.setPgData(resSrcTmm.getPgData());
                resSrcTmm.setSourceProcessor(SourceProcessor.PG_SWITCH);
                logger.trace(buildLogMessage(reqSrcTmm.getEntityId(), resSrcTmm.getSource(), resSrcTmm.getMsgType(), reqSrcTmm.getTransactionId(), "Response Source Transaction message model: {}"),
                        resSrcTmm);
                logToTlm(resSrcTmm, routingContext);
            } else {
                exchange.getIn().setBody(resSrcTmm);
                performRupayMacValidation(reqSrcTmm, resSrcTmm, producerEndpoint);
            }
        } else {
            logger.error("Transaction could not be completed with target connection {}",
                    producerEndpoint.getEndpointUri());
            throw new IssuerUnavailableException("Issuer is not available");
        }
    }

    public static Map<String,TransactionMessageModel> getDataforReversal(TransactionMessageModel model){
       if(model == null){
           return  map;
       }else{
           map.put("getreversalData",model);
           return  map;
       }
    }
    public void processVoidOrReversal(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        TransactionMessageModel originalTmm = reqSrcTmm.getOriginalTmm();
        String resCode = null;
        if (originalTmm == null) {
            switch (reqSrcTmm.getDrcrFlag()) {
                case "V":
                    // Send decline response to POS if original txn is not found.
                    resCode = TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_PRESENT;
                    break;
                case "R":
                    // Send success response to POS if original txn is not found.
                    resCode = TmmConstants.RES_CODE_SUCCESS;
            }
        } else if (TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_PRESENT.equals(originalTmm.getResCode())) {
            throw new InvalidVoidOrReversalDataException(
                    "PAN no mismatch, expected: " + originalTmm.getPan() + ", got: " + MaskingUtility.maskCardNumber(reqSrcTmm.getPan()));
        } else {

            switch (originalTmm.getDrcrFlag()) {
                case "V":
                case "R":
                    resCode = TmmConstants.RES_CODE_SUCCESS;
                    break;
                case "C":
                case "D":
                case "N":
                    if (isPreAuthCompletionRequest(originalTmm.getMsgType(), originalTmm.getProcessingCode())
                            || isOfflineRequest(originalTmm.getMsgType(), originalTmm.getProcessingCode())
                            || PgMsgTypeHelper.isCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                            || PgMsgTypeHelper.isOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                            || PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                            || PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                            || PgMsgTypeHelper.isMotoCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
                        resCode = TmmConstants.RES_CODE_SUCCESS;
                    } else {
                        processNormalTxn(exchange, reqSrcTmm);
                    }
                    break;
                default:
                    throw new RequestProcessingException(
                            LogUtils.buildLogMessage(reqSrcTmm.getEntityId(), reqSrcTmm.getSource(), reqSrcTmm.getMsgType(),
                                    reqSrcTmm.getTransactionId(), "Invalid DrCr Flag: " + originalTmm.getDrcrFlag()));
            }
        }
        if (resCode != null) {
            reqSrcTmm.setResCode(resCode);
            posSwitchProcessor.processPosSwitchTxn(exchange, reqSrcTmm);
        }
    }

    public TransactionMessageModel prepareTgtMessageAndLogTlm(MessageContext targetMsgContext, RoutingContext routingContext) {
        TransactionMessageModel reqTgtTmm = targetMsgContext.getTransactionMessageModel();

        reqTgtTmm.setEpType(EpType.TARGET);
        reqTgtTmm.setTlmMessageType(TlmMessageType.REQUEST);
        reqTgtTmm.setTransactionId(reqTgtTmm.getTransactionId());
        reqTgtTmm.setRequestSentTime(OffsetDateTime.now());

        reqTgtTmm.setAcpTraceId(ThreadContext.get(FilterConstants.threadContextAcpTraceId));
        //SET TXN_MSG_MODEL
        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.INSERT,DbMessageType.IN_REQ,reqTgtTmm);
        logger.trace(buildLogMessage(reqTgtTmm.getEntityId(), reqTgtTmm.getSource(), reqTgtTmm.getMsgType(), reqTgtTmm.getTransactionId(),
                "Request Target Transaction message model: " + reqTgtTmm));

        logToTlm(reqTgtTmm, routingContext);

        return reqTgtTmm;
    }

    public TransactionMessageModel prepareResTargetTmm(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSrcTmm,
                                                       String endpoint, Object resMessage, RoutingContext routingContext) {
        resSrcTmm.setEpType(EpType.SOURCE);
        resSrcTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resSrcTmm.setResponseReceivedTime(OffsetDateTime.now());
        resSrcTmm.setTransactionId(reqSrcTmm.getTransactionId());
        resSrcTmm.setAcpTraceId(reqSrcTmm.getAcpTraceId());
        resSrcTmm.setTxnAmt(reqSrcTmm.getTxnAmt());

        if (resMessage instanceof byte[])
            resSrcTmm.setRawResponse(TxnLogger.encryptRawMsg((byte[]) resMessage));
        else
            resSrcTmm.setRawResponse(TxnLogger.encryptRawMsg((String) resMessage));
        resSrcTmm.setDrcrFlag(reqSrcTmm.getDrcrFlag());
        resSrcTmm.setTarget(routingContext.getSource().getName());
        resSrcTmm.setSourceProcessor(reqSrcTmm.getSourceProcessor());

        // for batch settlement consistency
        resSrcTmm.setTerminalBatchNo(reqSrcTmm.getTerminalBatchNo());

        // all transaction needs to be tested for the condition.
        resSrcTmm.setLocalTxnDate(reqSrcTmm.getLocalTxnDate() != null ? reqSrcTmm.getLocalTxnDate() : resSrcTmm.getLocalTxnDate());
        resSrcTmm.setLocalTxnTime(reqSrcTmm.getLocalTxnTime() != null ? reqSrcTmm.getLocalTxnTime() : resSrcTmm.getLocalTxnTime());


        // for getting consistency in data for void transactions.
        resSrcTmm.setOriginalTmm(reqSrcTmm.getOriginalTmm());
        resSrcTmm.setEncryptedExpirationDate(reqSrcTmm.getEncryptedExpirationDate());

        //amex switch to pg response getting null

        if (TargetType.Amex.equals(resSrcTmm.getTargetType()) && PgMsgTypeHelper.isReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {

            resSrcTmm.setAuthIdRes(reqSrcTmm.getAuthIdRes());
        }

        resSrcTmm.setSchemeStan(resSrcTmm.getStan());
        // set request data in response as required in SOURCE
        resSrcTmm.setNiiId(reqSrcTmm.getNiiId());
        resSrcTmm.setStan(reqSrcTmm.getStan());
        resSrcTmm.setSettlementCurrenyCode(reqSrcTmm.getSettlementCurrenyCode());
        resSrcTmm.setCardHolderBillingCurrencyCode(reqSrcTmm.getCardHolderBillingCurrencyCode());
        resSrcTmm.setIpAddress(reqSrcTmm.getIpAddress());
        resSrcTmm.setLongitude(reqSrcTmm.getLongitude());
        resSrcTmm.setLatitude(reqSrcTmm.getLatitude());
        String responseTxnName = resSrcTmm.getTransactionName().replace("response", "request");
        if (!reqSrcTmm.getTransactionName().equals(responseTxnName)) {
            String reqAsRes = reqSrcTmm.getTransactionName().replace("request", "response");
            resSrcTmm.setTransactionName(reqAsRes);
        }
        //SET TXN_MSG_MODEL
        SpringContextBridge.services().getCacheUtil().putTxnMsgModel(DbMessageType.INSERT,DbMessageType.IN_RES,resSrcTmm);
        resSrcTmm.setDeviceMftr(reqSrcTmm.getDeviceMftr());
        if ((!PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode()))
                || (!PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode()))) {
            logger.trace(buildLogMessage(reqSrcTmm.getEntityId(), resSrcTmm.getSource(), resSrcTmm.getMsgType(), reqSrcTmm.getTransactionId(), "Response Source Transaction message model: {}"),
                    resSrcTmm);
            logToTlm(resSrcTmm, routingContext);
        }

        resSrcTmm.setProcessingCode(reqSrcTmm.getProcessingCode());
        resSrcTmm.setDeviceMftr(reqSrcTmm.getDeviceMftr());

        if (resSrcTmm.getResCode().equals(TmmConstants.RES_CODE_SUCCESS) || "000".equals(resSrcTmm.getResCode()))
            logger.info("Transaction {} completed for target connection {}", reqSrcTmm.getTransactionName(),
                    endpoint);

        return resSrcTmm;
    }

    public void logToTlm(TransactionMessageModel tmm, RoutingContext routingContext) {
        if (routingContext.isTxnLoggingOn() && TmmConstants.isTxnLogRequired(tmm.getTransactionName())) {
            logToTlm(tmm);
        }
    }

    public void logToTlmBqrMsg(TransactionMessageModel tmm) {
        logToTlm(tmm);
    }

    private void logToTlm(TransactionMessageModel tmm) {
        String epId = tmm.getSource() == null ? tmm.getTarget() : tmm.getSource();
        KafkaProducer kafkaProducer = RoutingInitializationContext.getKafkaProducer();
        KafkaProducer kafkaFeederProducer = RoutingInitializationContext.getKafkafeederProducer();
        logger.debug(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
                "Logging transaction to TLM"));
        kafkaProducer.sendMessage(tmm, tmm.getTransactionId());
        kafkaFeederProducer.sendMessage(tmm,tmm.getTransactionId());
        logger.info(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
                "Logged transaction to TLM"));
    }

    public void logTipToTlm(TransactionMessageModel tmm, RoutingContext routingContext) {
        if (routingContext.isTxnLoggingOn()) {
            logToTlm(tmm);
        }
    }

    public void asyncLogToTlm(TransactionMessageModel tmm, RoutingContext routingContext) {
        if (routingContext.isTxnLoggingOn() && TmmConstants.isTxnLogRequired(tmm.getTransactionName())) {
            asyncLogToTlm(tmm);
        }
    }

    private void asyncLogToTlm(TransactionMessageModel tmm) {
        String epId = tmm.getSource() == null ? tmm.getTarget() : tmm.getSource();
        KafkaProducer kafkaProducer = RoutingInitializationContext.getKafkaProducer();
        logger.debug(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
                "Logging transaction to TLM"));
        kafkaProducer.sendAsyncMessage(tmm, tmm.getTransactionId());
        logger.info(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
                "Logged transaction to TLM"));
    }

    /**
     * Update original transactions for Tip Adjust, Void & Reversal and log to TLM.
     *
     * @param originalTmm
     */
    public void updateOriginalTxnAndLogTlm(TransactionMessageModel originalTmm, String reqDrcrFlag, RoutingContext routingContext) {
        if (originalTmm != null && reqDrcrFlag != null && (reqDrcrFlag.equals("V") || reqDrcrFlag.equals("R") || reqDrcrFlag.equals("N"))) {
            originalTmm.setDrcrFlag(reqDrcrFlag);
            synchronizedLogToTlm(originalTmm, routingContext, false);
        }
    }

    public void synchronizedLogToTlm(TransactionMessageModel originalTmm, RoutingContext routingContext, boolean isTipTxn) {
        TlmMessageType msgType = TlmMessageType.RESPONSE;
        originalTmm.setTlmMessageType(msgType);
        if (isTipTxn) {
            logTipToTlm(originalTmm, routingContext);
        } else {
            logToTlm(originalTmm, routingContext);
        }

        TransactionMessageModel clonedTmm = SerializationUtils.clone(originalTmm);
        clonedTmm.setTlmMessageType(TlmMessageType.REQUEST);
        if (isTipTxn) {
            logTipToTlm(clonedTmm, routingContext);
        } else {
            logToTlm(clonedTmm, routingContext);
        }
    }

    public void validTxnType(TransactionMessageModel tmm) {
        if (!TmmConstants.isValidTxnType(tmm.getTransactionName())) {

            throw new InvalidTxnException("Transaction : " + tmm.getTransactionName() + ", is not valid");
        }
    }

    public void validPgTxnType(TransactionMessageModel tmm) {
        if ((!TmmConstants.isValidTxnType(tmm.getTransactionName()))
                && (!TmmConstants.pgMsgTypwAndMsgTypeIdValidation(tmm.getProcessingCode().concat(tmm.getMsgType())))) {
            throw new InvalidTxnException("Transaction : " + tmm.getTransactionName() + ", is not valid");
        }
    }

    public void checkForMandatoryFields(TransactionMessageModel tmm) {
        TransactionMessageModel obj = new TransactionMessageModel();
        TransactionMessageModel.PgData pgDataObj = new TransactionMessageModel.PgData();

        Map<String, Set<String>> txnFieldMap = MandatoryFieldUtility.getTxnfieldMap();
        Set<String> fieldset = txnFieldMap.get(tmm.getTransactionName());

        if (fieldset != null && !fieldset.isEmpty()) {
            Class<?> className = obj.getClass();
            Method[] methods = className.getMethods();
            verifyMandatoryFields(methods, fieldset, tmm, null);
            Class<?> pgClass = pgDataObj.getClass();
            Method[] pgMethods = pgClass.getMethods();
            verifyMandatoryFields(pgMethods, fieldset, null, tmm.getPgData());
        }

    }

    public void verifyMandatoryFields(Method[] methods, Set<String> fieldset, TransactionMessageModel tmm, TransactionMessageModel.PgData pgData) {
        for (Method method : methods) {
            if (fieldset.contains(method.getName())) {
                Object value;
                try {
                    value = (tmm == null ? method.invoke(pgData) : method.invoke(tmm));
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                    throw new FormatErrorException("Field : " + method.getName() + ", is not valid");
                }
                if (value == null) {
                    throw new FormatErrorException("Field : " + method.getName() + ", is null");
                }
            }
        }
    }

    public MapsInfoModel validateMerchant(RoutingContext routingContext, TransactionMessageModel tmm) {
    	MapsInfoModel mapsInfoModel = null;
    	if (routingContext.getSource().isMerchantValidation()) {
    		mapsInfoModel = cacheService.validateAndGetMerchant(tmm.getEntityId(), tmm.getCardAcceptorId(),
    				tmm.getCardAcceptorTerminalId(), tmm.getTxnCurrencyCode());

    		if (mapsInfoModel == null) {
    			throw new InvalidMerchantException("Merchant: " + tmm.getCardAcceptorId() + ", is not valid");
    		} else if (SourceProcessor.PG_SWITCH.name().equals(tmm.getSourceProcessor().name())
    				&& !mapsInfoModel.getTerminalCategoryCode().equals("T")) {
    			throw new InvalidMerchantException("Invalid Terminal Category Code : " + mapsInfoModel.getTerminalCategoryCode() + " For MID : " + mapsInfoModel.getMid());
    		}
    	}
    	return mapsInfoModel;
    }


    public void validateMerchantPan(TransactionMessageModel tmm) {

        MapsInfoModel mapsInfoModel = null;
        MerchantPanData merchantPanData = null;
        try {
            logger.info("Get Merchant info: EntityId: {}, MID: {}, TID: {}, TxnCurrencyCode: {}", tmm.getEntityId(), tmm.getCardAcceptorId(),
                    tmm.getCardAcceptorTerminalId(), tmm.getTxnCurrencyCode());

            mapsInfoModel = cacheService.validateAndGetMerchant(tmm.getEntityId(), tmm.getCardAcceptorId(),
                    tmm.getCardAcceptorTerminalId(), tmm.getTxnCurrencyCode());

            merchantPanData = mapsInfoModel.getMerchantPanData().stream().filter(m -> m.getMpan().equals(tmm.getPan())).findFirst().get();

            if (merchantPanData == null) {
                throw new InvalidBinException("Bin: " + MaskingUtility.maskCardNumber(tmm.getPan()) + ", is not matching with merchant pan");
            }
            tmm.setMaskedPan(MaskingUtility.maskCardNumber(tmm.getPan()));
            logger.info("Merchant PAN Validated: EntityId: {}, MID: {}, TID: {}, TxnCurrencyCode: {}", tmm.getEntityId(), tmm.getCardAcceptorId(), tmm.getCardAcceptorTerminalId(), tmm.getTxnCurrencyCode());
        } catch (Exception e) {
            throw new InvalidMerchantException("MerchantPan: " + MaskingUtility.maskCardNumber(tmm.getPan()) + ", is not valid");
        }

    }

    public MapsInfoModel validateMerchant(String entityId, String mid, String tid) {
        MapsInfoModel mapsInfoModel = null;
        mapsInfoModel = cacheService.validateAndGetMerchant(entityId, mid, tid, null);

        if (mapsInfoModel == null) {
            throw new InvalidMerchantException("Merchant: " + mid + ", is not valid");
        }
        return mapsInfoModel;
    }

    public MerchantMasterModel validateMerchantMaster(String entityId, String mid) {
        MerchantMasterModel merchantMasterModel = null;
        merchantMasterModel = cacheService.validateAndGetMerchantMaster(entityId, mid);

        if (merchantMasterModel == null) {
            throw new InvalidMerchantException("Merchant Master: " + mid + ", is not valid");
        }
        return merchantMasterModel;
    }

  
    public void validateBin(RoutingContext routingContext, TransactionMessageModel tmm) {
        try {
            if (StringUtils.isEmpty(tmm.getPan())) {
                throw new InvalidBinException("Bin: " + MaskingUtility.maskCardNumber(tmm.getPan()) + ", is empty!");
            }
            String pan = tmm.getPan();

            boolean binStatus = false;
            binStatus = cacheService.getRejectedBin(tmm.getPan());
            if(!binStatus) {
                AidSchemeModel aidSchemeModel = cacheService.getAID(tmm.getApplicationIdentifier());
                if (aidSchemeModel != null && aidSchemeModel.getTargetId() != null ) {
                    BinOnusModel binOnusModel = cacheService.getOnusBin(tmm.getPan());
                    if (null != binOnusModel) {
                        if( binOnusModel.getTargetId() != null) {
                            TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                                    .filter(t -> t.getId().equals(Long.valueOf(binOnusModel.getTargetId()))).findFirst().get();

                            tmm.setTarget(targetConfigModel.getName());
                            tmm.setForwardingInstIdCode(targetConfigModel.getAdditionalData().getFwdInstId());
                        }else{
                            TargetConfigModel targetConfigModel  = routingContext.getTargets().stream()
                                    .filter(t -> t.getTarget() == Target.Scheme)
                                    .filter(t -> t.getTargetType() == TargetType.valueOf(binOnusModel.getSchemeName()))
                                    .findFirst().get();
                        }
                    } else {
                        TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                                .filter(t -> t.getId().equals(Long.valueOf(aidSchemeModel.getTargetId()))).findFirst().get();

                        tmm.setTarget(targetConfigModel.getName());
                        tmm.setForwardingInstIdCode(targetConfigModel.getAdditionalData().getFwdInstId());
                    }
                } else {
                    BinOnusModel binOnusModel = cacheService.getOnusBin(tmm.getPan());
                    if (null != binOnusModel) {
                        TargetConfigModel targetConfigModel=new  TargetConfigModel();
                        if( binOnusModel.getTargetId() != null) {
                             targetConfigModel = routingContext.getTargets().stream()
                                    .filter(t -> t.getId().equals(Long.valueOf(binOnusModel.getTargetId()))).findFirst().get();
                        }else{
//                            targetConfigModel = routingContext.getTargets().stream()
//                                    .filter(t -> t.getTargetType().equals(binOnusModel.getSchemeName())).findFirst().get();

                            targetConfigModel = routingContext.getTargets().stream()
                                    .filter(t -> t.getTarget() == Target.Scheme)
                                    .filter(t -> t.getTargetType() == TargetType.valueOf(binOnusModel.getSchemeName()))
                                    .findFirst().get();
                        }
                        tmm.setTarget(targetConfigModel.getName());
                        tmm.setForwardingInstIdCode(targetConfigModel.getAdditionalData().getFwdInstId());
                    }else {
                        if (routingContext.getSource().isIssuerBinValidation()) {
                            BinInfoModel binInfoModel = cacheService.getSchemeBin(tmm.getPan());
                            if (binInfoModel == null) {
                                throw new InvalidBinException("Bin Model1: " + MaskingUtility.maskCardNumber(tmm.getPan()) + ", is not valid");
                            }
                            logger.info("BinInfoModel: {}", binInfoModel);
                            if (binInfoModel.getTargetId() != null) {
                            	logger.info("BinInfoModel with TargetId");
                                TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                                        .filter(t -> t.getId().equals(Long.valueOf(binInfoModel.getTargetId()))).findFirst().get();

                                tmm.setTarget(targetConfigModel.getName());
                                tmm.setForwardingInstIdCode(targetConfigModel.getAdditionalData().getFwdInstId());
                            } else {
                            	logger.info("BinInfoModel without TargetId");
                                TargetConfigModel targetConfigModel = routingContext.getTargets().stream()
                                        .filter(t -> t.getTarget() == Target.Scheme)
                                        .filter(t -> t.getTargetType() == TargetType.valueOf(binInfoModel.getSchemeName()))
                                        .findFirst().get();
                                tmm.setTarget(targetConfigModel.getName());
                                tmm.setForwardingInstIdCode(targetConfigModel.getAdditionalData().getFwdInstId());
                            }
                        }
                    }
                }
            } else {
                throw new InvalidBinException("Bin: " + MaskingUtility.maskCardNumber(tmm.getPan()) + ", is blacklisted");
            }
        } catch (NoSuchElementException e) {
            throw new SystemErrorException("Target is not Active");
        } catch (Exception e) {
            throw new InvalidBinException("Bin: " + MaskingUtility.maskCardNumber(tmm.getPan()) + ", is not valid");
        }
    }

    public String generateTransactionId() {
        return Long.toUnsignedString(TxnIdGenerator.INSTANCE.generate());
    }

    public void enrichMerchantData(TransactionMessageModel tmm, TargetConfigModel targetConfigModel) {

        String merchantName = null;
        String merchantCity = null;
        String merchantCountryCode = null;
        String merchantStateCode = null;
        String cardAcceptorInfo = null;
        String merchantCountryShortCode = null;

        MapsInfoModel merchantData = cacheService.validateAndGetMerchant(tmm.getEntityId(), tmm.getCardAcceptorId(),
                tmm.getCardAcceptorTerminalId(), tmm.getTxnCurrencyCode());

        tmm.setMerchantType(tmm.getMerchantType() == null ? merchantData.getMerchantType() : tmm.getMerchantType());
        tmm.setAquirerIdCode(
                tmm.getAquirerIdCode() == null ? targetConfigModel.getAdditionalData().getAcquirerId() : tmm.getAquirerIdCode());

        tmm.setForwardingInstIdCode(tmm.getForwardingInstIdCode() == null ? targetConfigModel.getAdditionalData().getFwdInstId()
                : tmm.getForwardingInstIdCode());
        tmm.setTxnCurrencyCode(
                tmm.getTxnCurrencyCode() == null ? merchantData.getAcquirerCurrencyCode() : tmm.getTxnCurrencyCode());
        tmm.setAquirerCountryCode(
                tmm.getAquirerCountryCode() == null ? merchantData.getAcquiringInstitutionCountryCode()
                        : tmm.getAquirerCountryCode());
        tmm.setSchemeStan(tmm.getSchemeStan() == null ? tmm.getStan() : tmm.getSchemeStan());
        tmm.setSettlementCurrenyCode(tmm.getSettlementCurrenyCode() == null ? merchantData.getAcquirerCurrencyCode()
                : tmm.getSettlementCurrenyCode());
        tmm.setCardHolderBillingCurrencyCode(tmm.getCardHolderBillingCurrencyCode() == null ? merchantData.getAcquirerCurrencyCode()
                : tmm.getCardHolderBillingCurrencyCode());

        if(!TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(targetConfigModel.getTargetType().name())) {
            String targetScheme = cacheService.getSchemeName(tmm.getPan());
            logger.trace("Target Scheme Type: {}", targetScheme);
            switch (TargetType.getTargetType(targetScheme)) {

                case Master:
                    merchantName = StringUtils.rightPad(merchantData.getMerchantName(), 23);
                    merchantCity = StringUtils.rightPad(merchantData.getMerchantCity(), 14);
                    merchantCountryCode = StringUtils.rightPad(merchantData.getMerchantCountryCode(), 3);

                    cardAcceptorInfo = merchantName.substring(0, 23) + merchantCity.substring(0, 14) + merchantCountryCode.substring(0, 3);
                    break;

                case Rupay:
                    merchantName = StringUtils.rightPad(merchantData.getMerchantName(), 23);
                    merchantCity = StringUtils.rightPad(merchantData.getMerchantCity(), 13);
                    merchantStateCode = StringUtils.rightPad(
                            merchantData.getMerchantStateCode() == null ? "" : merchantData.getMerchantStateCode(), 2);
                    merchantCountryCode = StringUtils.rightPad(merchantData.getMerchantShortCountryCode(), 2);

                    cardAcceptorInfo = merchantName.substring(0, 23) + merchantCity.substring(0, 13) + merchantStateCode.substring(0, 2)
                            + merchantCountryCode.substring(0, 2);
                    break;

                case Visa:
                    merchantName = StringUtils.rightPad(merchantData.getMerchantName(), 25);
                    merchantCity = StringUtils.rightPad(merchantData.getMerchantCity(), 13);
                    merchantCountryShortCode = StringUtils.rightPad(merchantData.getMerchantShortCountryCode(), 2); // e.g. IN

                    cardAcceptorInfo = merchantName.substring(0, 25) + merchantCity.substring(0, 13) + merchantCountryShortCode.substring(0, 2);
                    break;

                case Amex:
                    String payAggrName = "";
                    if ("Y".equals(merchantData.getAggregatorFlag())) {
                        payAggrName = (merchantData.getPaymentFacilitatorName() == null || merchantData.getPaymentFacilitatorName().isEmpty()) ? "" : merchantData.getPaymentFacilitatorName() + "=";
                    }
                    cardAcceptorInfo = payAggrName
                            + StringUtils.substring(merchantData.getMerchantName(), 0, 30) + "\\"
                            + StringUtils.substring(merchantData.getMerchantAddress(), 0, 30) + "\\"
                            + StringUtils.substring(merchantData.getMerchantCity(), 0, 15) + "\\"
                            + StringUtils.substring(StringUtils.rightPad(merchantData.getMerchantZipCode(), 10), 0, 10)
                            + StringUtils.substring(StringUtils.rightPad(merchantData.getMerchantStateCode(), 3), 0, 3)
                            + StringUtils.substring(StringUtils.rightPad(merchantData.getMerchantCountryCode(), 3), 0, 3) + "\\";
                default:
                    break;

            }
        }

        tmm.setCardAcceptorInfo(tmm.getCardAcceptorInfo() == null ? cardAcceptorInfo : tmm.getCardAcceptorInfo());
        logger.trace("Response card info: {}, card info after: {}", cardAcceptorInfo, tmm.getCardAcceptorInfo());
    }

    private void performRupayMacValidation(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSrcTmm,
                                           NettyEndpoint producerEndpoint) {
        boolean rupayMacFlag = Boolean.parseBoolean(MTMProperties.getProperty(RUPAY_MAC_ENABLE));

        if (resSrcTmm.getResCode().equals(TmmConstants.RES_CODE_SUCCESS) &&
                TargetType.Rupay.equals(resSrcTmm.getTargetType()) && rupayMacFlag && resSrcTmm.getPrivateAd() != null) {
            TlvDataList tlvData = new TlvDataList(resSrcTmm.getPrivateAd());
            String txnResMac = tlvData.getTagValue(MtmConstants.MAC_TAG_NAME);

            if (resSrcTmm.getMsgType().equals(AUTHORIZATION_RESPONSE_MTI)) {

                if (!(txnResMac != null && validateMac(reqSrcTmm, resSrcTmm, txnResMac))) {

                    logger.error(LogUtils.buildLogMessage(reqSrcTmm.getEntityId(), reqSrcTmm.getTarget(), resSrcTmm.getMsgType(),
                            reqSrcTmm.getTransactionId(), resSrcTmm.getTransactionName(), "Transaction could not be completed with target connection {}"), producerEndpoint.getEndpointUri());

                    String targetIpAndPort = RouteUtil.fetchIpAndPort(producerEndpoint.getEndpointUri());

                    resSrcTmm.setTargetIpAndPort(targetIpAndPort);
                    resSrcTmm.setResCode(TmmConstants.RES_CODE_INVALID_MAC);
                    resSrcTmm.setCardAcceptorId(reqSrcTmm.getCardAcceptorId());
                    resSrcTmm.setPostalCode(reqSrcTmm.getPostalCode());

                    RoutingInitializationContext.getKafkaReversalProducer().sendMessage(resSrcTmm, resSrcTmm.getTransactionId());

                }
            }
        }
    }

    public boolean validateMac(TransactionMessageModel reqTmm, TransactionMessageModel resTmm, String txnResMac) {
        boolean retVal = false;
        HsmVendor hsmVendor = hsmCommonService.getHsmVendorByEntityId(reqTmm.getEntityId());
        MacFields macFields = new MacFields();
        macFields.setMsgType(resTmm.getMsgType());
        macFields.setPan(resTmm.getPan());

        if (isCashAtPos(reqTmm.getMsgType(), resTmm.getProcessingCode()) && reqTmm.getTxnAmt().equals(reqTmm.getAdditionalAmounts())) {
            macFields.setMsgTypeId("01" + resTmm.getProcessingCode().substring(2, resTmm.getProcessingCode().length()));
        } else {
            macFields.setMsgTypeId(resTmm.getProcessingCode());
        }

        macFields.setTxnAmt(resTmm.getTxnAmt());
        macFields.setStan(resTmm.getSchemeStan());
        macFields.setLocalTxnTime(resTmm.getLocalTxnTime());
        macFields.setRrn(resTmm.getRetrievalRefNo());
        macFields.setAuthCode(resTmm.getAuthIdRes());
        macFields.setResCode(resTmm.getResCode());

        String hsmGenMac = SpringContextBridge.getHsmProcessorService(hsmVendor).generateMac(reqTmm.getEntityId(), reqTmm.getSource(), macFields, reqTmm.getTarget());

        switch (hsmVendor) {
            case THALES:
                hsmGenMac = hsmGenMac.substring(8, hsmGenMac.length());
                break;
            case SAFENET:
                hsmGenMac = hsmGenMac.substring(10, 26);
                break;

            default:
                break;

        }
        if (txnResMac.equals(hsmGenMac)) {
            retVal = true;
        }
        return retVal;
    }

    public void setSourceDataInResponse(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSrcTmm) {
        resSrcTmm.setPosEntryMode(reqSrcTmm.getPosEntryMode());
        TransactionMessageModel.PgData pgData = resSrcTmm.getPgData() == null ? new TransactionMessageModel.PgData() : resSrcTmm.getPgData();
        pgData.setCvv2(reqSrcTmm.getPgData().getCvv2());
        pgData.setAvv(reqSrcTmm.getPgData().getAvv());
        pgData.setCvvResult(reqSrcTmm.getPgData().getCvvResult());
        pgData.setPgTxnRefNo(reqSrcTmm.getPgData().getPgTxnRefNo());
        pgData.setEcommerceIndicator(reqSrcTmm.getPgData().getEcommerceIndicator());
        pgData.setOriginalTxnPgid(reqSrcTmm.getPgData().getOriginalTxnPgid());
        pgData.setFrmIpAddress(reqSrcTmm.getPgData().getFrmIpAddress());
        pgData.setPgId(reqSrcTmm.getPgData().getPgId());
        pgData.setDsVersion(reqSrcTmm.getPgData().getDsVersion());
        pgData.setBankName(reqSrcTmm.getPgData().getBankName());
        pgData.setCancelationId(reqSrcTmm.getPgData().getCancelationId());
        String privateAdTmp = resSrcTmm.getPrivateAd();
        String privateAd = (privateAdTmp == null ? privateAdTmp : privateAdTmp.substring(1, privateAdTmp.length()));

        String additionalResDataTmp = resSrcTmm.getAdditionalResData();

        String mac = null;
        String cvvResult = null;
        if (resSrcTmm.getPrivateAd() != null) {
            TlvDataList tlvDataList = new TlvDataList(privateAd, 2, 2);
            mac = tlvDataList.getTagValue("84");
            cvvResult = tlvDataList.getTagValue("87");

        } else {
            cvvResult = additionalResDataTmp;
        }
        pgData.setMac(mac);
        pgData.setCvvResult(cvvResult);
        pgData.setTavv(reqSrcTmm.getPgData().getTavv());
        pgData.setTokenRequestorId(reqSrcTmm.getPgData().getTokenRequestorId());
        pgData.setField41(reqSrcTmm.getPgData().getField41());
        pgData.setDsTransactionId(reqSrcTmm.getPgData().getDsTransactionId());
        pgData.setDsMsgCategory(reqSrcTmm.getPgData().getDsMsgCategory());
        pgData.setDsAddMatchIndicator(reqSrcTmm.getPgData().getDsAddMatchIndicator());
        pgData.setDsSecureIndicator(reqSrcTmm.getPgData().getDsSecureIndicator());
        pgData.setCofTxnOrigin(reqSrcTmm.getPgData().getCofTxnOrigin());
        pgData.setMastercardPosData(reqSrcTmm.getPgData().getMastercardPosData());
        pgData.setReversalMessageReasonCode(reqSrcTmm.getPgData().getReversalMessageReasonCode());
        resSrcTmm.setPgData(pgData);

        resSrcTmm.setCardAcceptorId(reqSrcTmm.getCardAcceptorId());
    }

    public void generateAutoReversalTxn(TransactionMessageModel ogReqSrcTmm, SourceProcessor srcProcessor, String txnName) {
        setLoggerContext(ogReqSrcTmm);

        final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
        CamelContext camelContext = RoutingInitializationContext.getMwProducer().getProducerTemplate().getCamelContext();

        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : targetEpEntries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> value = entry.getValue();
            RoutingInitializationContext.EndpointMetaData endpointMetaData = value.get(remoteAdd);
            if (endpointMetaData != null) {
                try {
                    TargetConfigModel targetConfigModel = endpointMetaData.getTargetConfigModel();
                    if (ogReqSrcTmm.getAquirerIdCode() != null) {
                        //getting the appropriate endpoint details based on Acquirer Id in case of multiple target with same IP
                        RoutingInitializationContext.EndpointMetaData epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, ogReqSrcTmm.getAquirerIdCode(), remoteAdd);
                        targetConfigModel = epByAcqId.getTargetConfigModel();
                    }
                    NettyEndpoint nettyEndpoint = NettyConfig.getProducerEndpoint(camelContext, remoteAdd, targetConfigModel);

                    logger.info("Initializing Reversal Transaction for target: {}", targetConfigModel);

                    TransactionMessageModel reqTmm = new TransactionMessageModel();
                    TransactionMessageModel originalTmm = null;

                    if (ogReqSrcTmm.getResCode() != null && ogReqSrcTmm.getAuthIdRes() != null) {
                        logger.info("Initializing Late Response Reversal Transaction for target: {}", targetConfigModel.getName());
                        /**
                         * Late Response received from Target.
                         * Fetching the response Data from TLM for construction of Reversal.
                         */
                        originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(ogReqSrcTmm);
                    } else {
                        logger.info("Initializing TimeOut Reversal Transaction for target: {}", targetConfigModel.getName());
                        /**
                         * No Response Received from Target (TimeOut).
                         */
                        originalTmm = ogReqSrcTmm;
                    }

                    prepareReversalReqTmm(ogReqSrcTmm, srcProcessor, txnName, targetConfigModel, reqTmm, originalTmm);
                    MessageContext targetMsgContext = constructMessage(reqTmm, targetConfigModel.getName());
                    TransactionMessageModel reqTargetTmm = targetMsgContext.getTransactionMessageModel();
                    reqTargetTmm.setAcpTraceId(ogReqSrcTmm.getAcpTraceId());

                    RouteUtil.logToTlmForAutoReversal(reqTargetTmm);
                    TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) targetMsgContext.getRawMsg(), reqTargetTmm);

                    logger.trace("Request Source Transaction message model: {}", reqTargetTmm);

                    sendReversalMsg(ogReqSrcTmm, nettyEndpoint, reqTmm, targetMsgContext, reqTargetTmm, null, null, false);

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    clearLoggerContext();
                }
                break;
            }
        }
        clearLoggerContext();
    }

    // Repeat reversal for EFTPOS

    public boolean generateEftposAutoReversalTxn(TransactionMessageModel ogReqSrcTmm, SourceProcessor srcProcessor, String txnName) {
        setLoggerContext(ogReqSrcTmm);
        boolean repeatReversalEnable = false;
        final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
        CamelContext camelContext = RoutingInitializationContext.getMwProducer().getProducerTemplate().getCamelContext();

        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : targetEpEntries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> value = entry.getValue();
            RoutingInitializationContext.EndpointMetaData endpointMetaData = value.get(remoteAdd);
            if (endpointMetaData != null) {
                try {
                    TargetConfigModel targetConfigModel = endpointMetaData.getTargetConfigModel();
                    if (ogReqSrcTmm.getAquirerIdCode() != null) {
                        //getting the appropriate endpoint details based on Acquirer Id in case of multiple target with same IP
                        RoutingInitializationContext.EndpointMetaData epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, ogReqSrcTmm.getAquirerIdCode(), remoteAdd);
                        targetConfigModel = epByAcqId.getTargetConfigModel();
                    }
                    NettyEndpoint nettyEndpoint = NettyConfig.getProducerEndpoint(camelContext, remoteAdd, targetConfigModel);

                    logger.info("Initializing Reversal Transaction for target: {}", targetConfigModel);

                    TransactionMessageModel reqTmm = new TransactionMessageModel();
                    TransactionMessageModel originalTmm = null;

                    if (ogReqSrcTmm.getResCode() != null && ogReqSrcTmm.getAuthIdRes() != null) {
                        /**
                         * Late Response received from Target.
                         * Fetching the response Data from TLM for construction of Reversal.
                         */
                        originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(ogReqSrcTmm);
                    } else {
                        /**
                         * No Response Received from Target (TimeOut).
                         */
                        originalTmm = ogReqSrcTmm;
                    }

                    prepareReversalReqTmm(ogReqSrcTmm, srcProcessor, txnName, targetConfigModel, reqTmm, originalTmm);
                    MessageContext targetMsgContext = constructMessage(reqTmm, targetConfigModel.getName());
                    TransactionMessageModel reqTargetTmm = targetMsgContext.getTransactionMessageModel();
                    reqTargetTmm.setAcpTraceId(ogReqSrcTmm.getAcpTraceId());

                    RouteUtil.logToTlmForAutoReversal(reqTargetTmm);
                    TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) targetMsgContext.getRawMsg(), reqTargetTmm);

                    logger.trace("Request Source Transaction message model: {}", reqTargetTmm);

                     repeatReversalEnable = sendEftposReversalMsg(ogReqSrcTmm, nettyEndpoint, reqTmm, targetMsgContext, reqTargetTmm);

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    clearLoggerContext();
                }
                break;
            }
        }
        clearLoggerContext();
        return repeatReversalEnable;
    }

    public boolean generateRepeatReversalTxn(TransactionMessageModel ogReqSrcTmm, SourceProcessor srcProcessor, String txnName) {
        setLoggerContext(ogReqSrcTmm);
        boolean repeatReversalEnable = false;
        final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
        CamelContext camelContext = RoutingInitializationContext.getMwProducer().getProducerTemplate().getCamelContext();

        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : targetEpEntries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> value = entry.getValue();
            RoutingInitializationContext.EndpointMetaData endpointMetaData = value.get(remoteAdd);
            if (endpointMetaData != null) {
                try {
                    TargetConfigModel targetConfigModel = endpointMetaData.getTargetConfigModel();
                    if (ogReqSrcTmm.getAquirerIdCode() != null) {
                        RoutingInitializationContext.EndpointMetaData epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, ogReqSrcTmm.getAquirerIdCode(), remoteAdd);
                        targetConfigModel = epByAcqId.getTargetConfigModel();
                    }
                    NettyEndpoint nettyEndpoint = NettyConfig.getProducerEndpoint(camelContext, remoteAdd, targetConfigModel);

                    logger.info("Initializing Reversal Transaction for target: {}", targetConfigModel);

                    TransactionMessageModel reqTmm = new TransactionMessageModel();
                    TransactionMessageModel originalTmm = null;

                    if (ogReqSrcTmm.getResCode() != null && ogReqSrcTmm.getAuthIdRes() != null) {
                        /**
                         * Late Response received from Target.
                         * Fetching the response Data from TLM for construction of Reversal.
                         */
                        originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(ogReqSrcTmm);
                    } else {
                        /**
                         * No Response Received from Target (TimeOut).
                         */
                        originalTmm = ogReqSrcTmm;
                    }

                    prepareReversalReqTmm(ogReqSrcTmm, srcProcessor, txnName, targetConfigModel, reqTmm, originalTmm);
                    reqTmm.setMsgType("0421");
                    MessageContext targetMsgContext = constructMessage(reqTmm, targetConfigModel.getName());
                    TransactionMessageModel reqTargetTmm = targetMsgContext.getTransactionMessageModel();
                    reqTargetTmm.setAcpTraceId(ogReqSrcTmm.getAcpTraceId());

                    //RouteUtil.logToTlmForAutoReversal(reqTargetTmm);
                    TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) targetMsgContext.getRawMsg(), reqTargetTmm);
                    logger.trace("Request Source Transaction message model: {}", reqTargetTmm);
                    repeatReversalEnable = sendEftposReversalMsg(ogReqSrcTmm, nettyEndpoint, reqTmm, targetMsgContext, reqTargetTmm);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    clearLoggerContext();
                }
                break;
            }
        }
        clearLoggerContext();
        return repeatReversalEnable;
    }

    public boolean generateRepeatAdviceTxn(TransactionMessageModel ogReqSrcTmm, SourceProcessor srcProcessor, String txnName) {
        setLoggerContext(ogReqSrcTmm);
        boolean repeatAdviceEnable = false;
        final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
        CamelContext camelContext = RoutingInitializationContext.getMwProducer().getProducerTemplate().getCamelContext();

        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : targetEpEntries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> value = entry.getValue();
            RoutingInitializationContext.EndpointMetaData endpointMetaData = value.get(remoteAdd);
            if (endpointMetaData != null) {
                try {
                    TargetConfigModel targetConfigModel = endpointMetaData.getTargetConfigModel();
                    if (ogReqSrcTmm.getAquirerIdCode() != null) {
                        RoutingInitializationContext.EndpointMetaData epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, ogReqSrcTmm.getAquirerIdCode(), remoteAdd);
                        targetConfigModel = epByAcqId.getTargetConfigModel();
                    }
                    NettyEndpoint nettyEndpoint = NettyConfig.getProducerEndpoint(camelContext, remoteAdd, targetConfigModel);

                    logger.info("Initializing Reversal Transaction for target: {}", targetConfigModel);

                    TransactionMessageModel reqTmm = new TransactionMessageModel();
                    TransactionMessageModel originalTmm = null;

                    if (ogReqSrcTmm.getResCode() != null && ogReqSrcTmm.getAuthIdRes() != null) {
                        /**
                         * Late Response received from Target.
                         * Fetching the response Data from TLM for construction of Reversal.
                         */
                        originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(ogReqSrcTmm);
                    } else {
                        /**
                         * No Response Received from Target (TimeOut).
                         */
                        originalTmm = ogReqSrcTmm;
                    }

                    prepareRepeatAdviceReqTmm(ogReqSrcTmm, srcProcessor, txnName, targetConfigModel, reqTmm, originalTmm);
                    reqTmm.setMsgType("0221");
                    MessageContext targetMsgContext = constructMessage(reqTmm, targetConfigModel.getName());
                    TransactionMessageModel reqTargetTmm = targetMsgContext.getTransactionMessageModel();
                    reqTargetTmm.setAcpTraceId(ogReqSrcTmm.getAcpTraceId());

                    //RouteUtil.logToTlmForAutoReversal(reqTargetTmm);
                    TxnLogger.logRawMsg(MsgFlow.OUTBOUND, (byte[]) targetMsgContext.getRawMsg(), reqTargetTmm);
                    logger.trace("Request Source Transaction message model: {}", reqTargetTmm);
                     repeatAdviceEnable = sendRepeateAdviceMsg(ogReqSrcTmm, nettyEndpoint, reqTmm, targetMsgContext, reqTargetTmm);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    clearLoggerContext();
                }
                break;
            }
        }
        clearLoggerContext();
        return repeatAdviceEnable;
    }

    private void sendReversalMsg(TransactionMessageModel ogReqSrcTmm, NettyEndpoint nettyEndpoint, TransactionMessageModel reqTmm,
                                 MessageContext targetMsgContext, TransactionMessageModel reqTargetTmm, Exchange exchange, String targetUrl,
                                 boolean isApiRequest) {
        Object resMessage;
        int reversalRetries = SwitchBaseMessageConstruction.fetchReversalTimeoutRetries;
        TransactionMessageModel resSrcTmm = null;
        while (reversalRetries > 0) {
            logger.trace("Auto reversal retry count: {}", reversalRetries);
            try {
                final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
                if (isApiRequest) {
                    String requestJsonStr = (String) targetMsgContext.getRawMsg();
                    TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(ogReqSrcTmm.getTarget());
                    if (TargetType.Amex.name().equals(targetType.name())) {
                    	resMessage = RoutingInitializationContext.getMwProducer()
                    			.callApi(requestJsonStr, remoteAdd + targetUrl, targetMsgContext.getApiHeaders());
                    } else {
                    	resMessage = RoutingInitializationContext.getMwProducer()
                    			.callApiUsingWebClient(requestJsonStr, remoteAdd + targetUrl, targetMsgContext.getApiHeaders());
                    }
                } else {
                    String correlationId = null;
                    if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(ogReqSrcTmm.getTargetType().name())){
                        correlationId = reqTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getStan();
                    } else {
                        correlationId = reqTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getRetrievalRefNo();
                    }

                    resMessage = RoutingInitializationContext.getMwProducer().sendMessage(targetMsgContext.getRawMsg(),
                            correlationId, nettyEndpoint);
                }
                if (resMessage != null) {
                    if (isApiRequest) {
                        Class<?> className = targetMsgContext.getMessageTransformationConfig().getBusinessRuleClass();
                        BaseMessageTransformation baseMsgTransformation = (BaseMessageTransformation) className.newInstance();
                        resSrcTmm = baseMsgTransformation.parseResponse((String) resMessage, reqTargetTmm, null, null, null);
                        String transactionName = resSrcTmm.getTransactionName();
                        resSrcTmm.setTransactionName(transactionName.replace("request", "response"));
                        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TIMEOUTE_REVERSAL_TMM, resSrcTmm);
                    } else {
                        resSrcTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, reqTargetTmm.getTransactionName());
                    }
                    resSrcTmm.setTransactionId(reqTmm.getTransactionId());
                    logger.trace("Response Target Transaction message model: {}", resSrcTmm);
                    RouteUtil.logToTlmForAutoReversal(resSrcTmm);
                    //1430 is amex reversal response msg type
                    if ("0410".equals(resSrcTmm.getMsgType()) || "0430".equals(resSrcTmm.getMsgType()) || "1430".equals(resSrcTmm.getMsgType())) {
                        break;
                    }
                }
            } catch (Exception e) {
                RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
                if (routingContext.getSource().getConnectionType() == ConnectionType.API) {
                    exchange.getIn().setBody(apiTransactionProcessor.getEncryptedApiResponse(ResponseMsgType.ERROR, TmmConstants.RES_CODE_ISSUER_UNAVAILABLE, null, null, exchange));
                }
                logger.error("Error while generating auto reversal", e);
            }
            --reversalRetries;
        }

        ogReqSrcTmm.setTlmMessageType(TlmMessageType.REQUEST);
        ogReqSrcTmm.setDrcrFlag("R");
        logToTlm(ogReqSrcTmm);

        // 400 response code is for Amex
        if (TmmConstants.RES_CODE_SUCCESS.equals(resSrcTmm.getResCode()) || "400".equals(resSrcTmm.getResCode()))
            logger.info("Reversal Transaction {} completed for target connection {}", reqTmm.getTransactionName(), nettyEndpoint.getEndpointUri());

    }

    private boolean sendEftposReversalMsg(TransactionMessageModel ogReqSrcTmm, NettyEndpoint nettyEndpoint, TransactionMessageModel reqTmm, MessageContext targetMsgContext,
                                          TransactionMessageModel reqTargetTmm) {
        Object resMessage;
        int reversalRetries =1;
        TransactionMessageModel resSrcTmm = null;
        boolean repeatReversalEnable = false;
        while (reversalRetries > 0) {
            logger.trace("Auto reversal retry count: {}", reversalRetries);
            try {
                final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
                String correlationId = null;
                if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(ogReqSrcTmm.getTargetType().name())){
                    correlationId = reqTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getStan();
                } else {
                    correlationId = reqTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getRetrievalRefNo();
                }
                resMessage = RoutingInitializationContext.getMwProducer().sendMessage(targetMsgContext.getRawMsg(),correlationId, nettyEndpoint);
                if (resMessage != null) {
                    resSrcTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, reqTargetTmm.getTransactionName());
                    resSrcTmm.setTransactionId(reqTmm.getTransactionId());
                    logger.trace("Response Target Transaction message model: {}", resSrcTmm);
                    RouteUtil.logToTlmForAutoReversal(resSrcTmm);
                }
            } catch (Exception e) {
                if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(ogReqSrcTmm.getTargetType().name()) && e.getClass().getSimpleName().equals("TargetNoResponseException")) {
                    repeatReversalEnable = true;
                }
                logger.error("Error while generating auto reversal", e);
            }
            --reversalRetries;
        }

        ogReqSrcTmm.setTlmMessageType(TlmMessageType.REQUEST);
        ogReqSrcTmm.setDrcrFlag("R");
        logToTlm(ogReqSrcTmm);

        return repeatReversalEnable;
    }

    private boolean sendRepeateAdviceMsg(TransactionMessageModel ogReqSrcTmm, NettyEndpoint nettyEndpoint, TransactionMessageModel reqTmm, MessageContext targetMsgContext, TransactionMessageModel reqTargetTmm) {
        Object resMessage;
        int repeatAdviceRetries =1;
        TransactionMessageModel resSrcTmm = null;
        boolean repeatadviceEnable = false;
        while (repeatAdviceRetries > 0) {
            logger.trace("Repeate Advice retry count: {}", repeatAdviceRetries);
            try {
                final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
                String correlationId = null;
                if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(ogReqSrcTmm.getTargetType().name())){
                    correlationId = reqTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getStan();
                }else {
                     correlationId = reqTargetTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqTargetTmm.getRetrievalRefNo();
                }
                resMessage = RoutingInitializationContext.getMwProducer().sendMessage(targetMsgContext.getRawMsg(),correlationId, nettyEndpoint);
                if (resMessage != null) {
                    resSrcTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, reqTargetTmm.getTransactionName());
                    resSrcTmm.setTransactionId(reqTmm.getTransactionId());
                    logger.trace("Response Target Transaction message model: {}", resSrcTmm);
                    RouteUtil.logToTlmForAutoReversal(resSrcTmm);
                }
            } catch (Exception e) {
                if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(ogReqSrcTmm.getTargetType().name())  && e.getClass().getSimpleName().equals("TargetNoResponseException")) {
                    repeatadviceEnable = true;
                }
                logger.error("Error while generating repeate Advice", e);
            }
            --repeatAdviceRetries;
        }

        ogReqSrcTmm.setTlmMessageType(TlmMessageType.REQUEST);
        ogReqSrcTmm.setDrcrFlag("R");
        logToTlm(ogReqSrcTmm);

        return repeatadviceEnable;
    }

    public void generateAutoReversalTxn(TransactionMessageModel ogReqSrcTmm, TransactionMessageModel ogReqTgtTmm, SourceProcessor srcProcessor, String txnName,
                                        Exchange exchange, boolean isApiRequest) {
        setLoggerContext(ogReqSrcTmm);

        final String remoteAdd = ogReqSrcTmm.getTargetIpAndPort();
        Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries =
                RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : targetEpEntries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> value = entry.getValue();
            RoutingInitializationContext.EndpointMetaData endpointMetaData = value.get(remoteAdd);
            if (endpointMetaData != null) {
                logger.trace("Target Remote Address: {}", remoteAdd);

                TargetConfigModel targetConfigModel = endpointMetaData.getTargetConfigModel();
                if (ogReqSrcTmm.getAquirerIdCode() != null) {
                    //getting the appropriate endpoint details based on Acquirer Id in case of multiple target with same IP
                    RoutingInitializationContext.EndpointMetaData epByAcqId = RouteUtil.getEndpointByAcquirerId(targetEpEntries, ogReqSrcTmm.getAquirerIdCode(), remoteAdd);
                    targetConfigModel = epByAcqId.getTargetConfigModel();
                }
                logger.info("Initializing Reversal Transaction for target: {}", targetConfigModel);
                TransactionMessageModel reqTmm = new TransactionMessageModel();
                TransactionMessageModel originalTmm = null;

                if (ogReqSrcTmm.getResCode() != null && ogReqSrcTmm.getAuthIdRes() != null) {
                    /**
                     * Late Response received from Target.
                     * Fetching the response Data from TLM for construction of Reversal.
                     */
                    originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(ogReqSrcTmm);
                } else {
                    /**
                     * No Response Received from Target (TimeOut).
                     */
                    originalTmm = SerializationUtils.clone(ogReqSrcTmm);
                    originalTmm.setPan(ogReqSrcTmm.getPan());
                    if (ogReqTgtTmm != null) {
                        //following fields has been set for Amex requirements
                        originalTmm.setLocalTxnTime(ogReqTgtTmm.getLocalTxnTime());
                        originalTmm.setMsgType(ogReqTgtTmm.getMsgType());
                        originalTmm.setStan(ogReqTgtTmm.getStan());
                        if (TargetType.Amex.name().equals(targetConfigModel.getTargetType().name())) {
                        	originalTmm.setPosEntryMode(ogReqTgtTmm.getPosEntryMode());
                        }
                    }
                }
                prepareReversalReqTmm(ogReqSrcTmm, srcProcessor, txnName, targetConfigModel, reqTmm, originalTmm);
                if (isApiRequest) {
                    reqTmm.setRetrievalRefNo(ogReqSrcTmm.getRetrievalRefNo());
                }

                MessageContext targetMsgContext = constructMessage(reqTmm, targetConfigModel.getName());
                TransactionMessageModel reqTargetTmm = targetMsgContext.getTransactionMessageModel();
                reqTargetTmm.setAcpTraceId(ogReqSrcTmm.getAcpTraceId());

                RouteUtil.logToTlmForAutoReversal(reqTargetTmm);
                String targetUrl = null;
                NettyEndpoint nettyEndpoint = null;
                CamelContext camelContext = RoutingInitializationContext.getMwProducer().getProducerTemplate().getCamelContext();
                String txnUrl = getTxnUrl(targetConfigModel);
                if (isApiRequest) {
                    targetUrl = txnUrl + (StringUtils.isBlank(targetMsgContext.getTxnApiPath()) ? "" : targetMsgContext.getTxnApiPath());
                } else {
                    nettyEndpoint = NettyConfig.getProducerEndpoint(camelContext, remoteAdd, targetConfigModel);
                }

                exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_SCHEME, remoteAdd);

                sendReversalMsg(ogReqSrcTmm, nettyEndpoint, reqTmm, targetMsgContext, reqTargetTmm, exchange, targetUrl, isApiRequest);
            }
        }
        clearLoggerContext();
    }

    private void prepareReversalReqTmm(TransactionMessageModel reversalTmm, SourceProcessor srcProcessor, String txnName,
                                       TargetConfigModel targetConfigModel, TransactionMessageModel reqTmm, TransactionMessageModel originalTmm) {
        reqTmm.setTransactionName(txnName);
        reqTmm.setTransactionId(generateTransactionId());
        reqTmm.setEntityId(reversalTmm.getEntityId());
        reqTmm.setTlmMessageType(TlmMessageType.REQUEST);
        if (TargetType.Amex.name().equals(targetConfigModel.getTargetType().name())) {
        	reqTmm.setMsgType(REVERSAL_REQUEST_MTI_AMEX);
        } else {
        	reqTmm.setMsgType(REVERSAL_REQUEST_MTI);
        }
        reqTmm.setBitMap(reversalTmm.getBitMap());
        reqTmm.setPan(originalTmm.getPan());
        reqTmm.setProcessingCode(reversalTmm.getProcessingCode());
        reqTmm.setTxnAmt(reversalTmm.getTxnAmt());
        reqTmm.setTransmissionTime(reversalTmm.getTransmissionTime());
        reqTmm.setStan(reversalTmm.getStan());
        reqTmm.setExpirationDate(originalTmm.getExpirationDate());

        // For Eftpos
        if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(reversalTmm.getTargetType().name())){
            reqTmm.setEncryptedExpirationDate(originalTmm.getEncryptedExpirationDate());
            reqTmm.setEncryptedPan(originalTmm.getEncryptedPan());
            reqTmm.setMaskedPan(originalTmm.getMaskedPan());
            reqTmm.setTransmissionTime(originalTmm.getTransmissionTime());
        }

        reqTmm.setMerchantType(reversalTmm.getMerchantType());
        if (TargetType.Amex.name().equals(targetConfigModel.getTargetType().name())) {
        	reqTmm.setPosEntryMode(originalTmm.getPosEntryMode());
        } else {
        	reqTmm.setPosEntryMode(reversalTmm.getPosEntryMode());
        }
        reqTmm.setAquirerIdCode(reversalTmm.getAquirerIdCode());
        reqTmm.setForwardingInstIdCode(reversalTmm.getForwardingInstIdCode() == null ? targetConfigModel.getAdditionalData().getFwdInstId() : reversalTmm.getForwardingInstIdCode());
        reqTmm.setAuthIdRes(reversalTmm.getAuthIdRes());
        reqTmm.setResCode(reversalTmm.getResCode());
        reqTmm.setPrivateAd(reversalTmm.getPrivateAd());
        reqTmm.setTxnCurrencyCode(reversalTmm.getTxnCurrencyCode());
        reqTmm.setCardAcceptorTerminalId(reversalTmm.getCardAcceptorTerminalId());
        reqTmm.setCardAcceptorId(reversalTmm.getCardAcceptorId());
        reqTmm.setAdditionalAmounts(reversalTmm.getAdditionalAmounts());
        reqTmm.setIccData(reversalTmm.getIccData());
        reqTmm.setCiad(reversalTmm.getCiad());
        reqTmm.setPostalCode(reversalTmm.getPostalCode());
        reqTmm.setAtmPinOffsetData(reversalTmm.getAtmPinOffsetData());
        reqTmm.setOriginalTmm(originalTmm);

        reqTmm.setSourceProcessor(srcProcessor);
        reqTmm.setTerminalStan(reversalTmm.getStan());
        reqTmm.setDrcrFlag(reversalTmm.getDrcrFlag());

        // FOR EFTPOS
        reqTmm.setTrack2Data(reversalTmm.getTrack2Data());
        reqTmm.setPosConditionCode(reversalTmm.getPosConditionCode());
        reqTmm.setMsgAuthCode(reversalTmm.getMsgAuthCode());
        reqTmm.setNationalAd(reversalTmm.getNationalAd());

        if(SourceProcessor.PG_SWITCH.equals(srcProcessor)) {
            TransactionMessageModel.PgData pgData = reversalTmm.getPgData();
            pgData.setReversalMessageReasonCode("T");
            reqTmm.setPgData(pgData);
        }
    }

    private void prepareRepeatAdviceReqTmm(TransactionMessageModel reversalTmm, SourceProcessor srcProcessor, String txnName,
                                       TargetConfigModel targetConfigModel, TransactionMessageModel reqTmm, TransactionMessageModel originalTmm) {
        reqTmm.setTransactionName(txnName);
        reqTmm.setTransactionId(generateTransactionId());
        reqTmm.setEntityId(reversalTmm.getEntityId());
        reqTmm.setTlmMessageType(TlmMessageType.REQUEST);
        reqTmm.setBitMap(reversalTmm.getBitMap());
        reqTmm.setPan(originalTmm.getPan());
        reqTmm.setProcessingCode(reversalTmm.getProcessingCode());
        reqTmm.setTxnAmt(reversalTmm.getTxnAmt());
        reqTmm.setTransmissionTime(reversalTmm.getTransmissionTime());
        reqTmm.setStan(reversalTmm.getStan());
        reqTmm.setExpirationDate(originalTmm.getExpirationDate());
        reqTmm.setMerchantType(reversalTmm.getMerchantType());
        reqTmm.setPosEntryMode(reversalTmm.getPosEntryMode());
        reqTmm.setAquirerIdCode(reversalTmm.getAquirerIdCode());
        reqTmm.setForwardingInstIdCode(reversalTmm.getForwardingInstIdCode() == null ? targetConfigModel.getAdditionalData().getFwdInstId() : reversalTmm.getForwardingInstIdCode());
        reqTmm.setAuthIdRes(reversalTmm.getAuthIdRes());
        reqTmm.setResCode(reversalTmm.getResCode());
        reqTmm.setPrivateAd(reversalTmm.getPrivateAd());
        reqTmm.setTxnCurrencyCode(reversalTmm.getTxnCurrencyCode());
        reqTmm.setCardAcceptorTerminalId(reversalTmm.getCardAcceptorTerminalId());
        reqTmm.setCardAcceptorId(reversalTmm.getCardAcceptorId());
        reqTmm.setAdditionalAmounts(reversalTmm.getAdditionalAmounts());
        reqTmm.setIccData(reversalTmm.getIccData());
        reqTmm.setCiad(reversalTmm.getCiad());
        reqTmm.setPostalCode(reversalTmm.getPostalCode());
        reqTmm.setAtmPinOffsetData(reversalTmm.getAtmPinOffsetData());
        reqTmm.setOriginalTmm(originalTmm);

        reqTmm.setSourceProcessor(srcProcessor);
        reqTmm.setTerminalStan(reversalTmm.getStan());
        reqTmm.setDrcrFlag(reversalTmm.getDrcrFlag());

        // FOR EFTPOS
        reqTmm.setTrack2Data(reversalTmm.getTrack2Data());
        reqTmm.setPosConditionCode(reversalTmm.getPosConditionCode());
        reqTmm.setMsgAuthCode(reversalTmm.getMsgAuthCode());
        reqTmm.setNationalAd(reversalTmm.getNationalAd());

        if(SourceProcessor.PG_SWITCH.equals(srcProcessor)) {
            TransactionMessageModel.PgData pgData = reversalTmm.getPgData();
            pgData.setReversalMessageReasonCode("T");
            reqTmm.setPgData(pgData);
        }
    }

    public void checkForDuplicateTxn(Exchange exchange) {
        Object duplicateRequestObj = exchange.getProperties().get(Exchange.DUPLICATE_MESSAGE);
        if (duplicateRequestObj != null) {
            boolean isDuplicateRequest = (boolean) duplicateRequestObj;
            if (isDuplicateRequest)
                throw new DuplicateTxnException("Duplicate transaction detected");
        }
    }

    public boolean isRequestDeclined(Object requestDeclined) {
        return requestDeclined != null && ((boolean) requestDeclined);
    }

    public void removeCustomHeaders(Exchange exchange) {
        exchange.getIn().removeHeader(EXCHANGE_HEADER_ROUTING_CTX);
        exchange.getIn().removeHeader(EXCHANGE_HEADER_TARGET_SCHEME);
        exchange.getIn().removeHeader("correlationId");
        exchange.getIn().removeHeader(EXCHANGE_HEADER_REQ_SRC_TMM);
        exchange.getIn().removeHeader(EXCHANGE_HEADER_API_TXN_MODEL);
        exchange.getIn().removeHeader(EXCHANGE_HEADER_REQ_TGT_TMM);
    }

    public String getHashedValue(String value) {
        String hashedValue = null;
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-256");

            hashedValue = DatatypeConverter.printHexBinary(md.digest(value.getBytes()));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hashedValue;
    }



    public static void setLoggerContext(TransactionMessageModel tmm) {
        ThreadContext.putIfNull(FilterConstants.threadContextAcpTraceId, tmm.getAcpTraceId());

        Optional.ofNullable(tmm.getRetrievalRefNo()).ifPresent(rrn ->
                ThreadContext.put(FilterConstants.threadContextRetrievalRefNo, rrn)
        );
    }

    public static void clearLoggerContext() {
        ThreadContext.clearAll();
    }

    public static String getTxnUrl(TargetConfigModel targetConfigModel) {
        TargetType targetType = targetConfigModel.getTargetType();
        String txnUrl = "";
        TargetApiInfo apiInfo = targetConfigModel.getAdditionalData().getApiInfo();
        switch (targetType) {
            case Amex:
                txnUrl = apiInfo.getAmex().getTxnUrl();
                break;
            case Cybs:
                txnUrl = apiInfo.getCybs().getTxnUrl();
                break;
        }
        return txnUrl;
    }

    public void generateAutoReversal(TransactionMessageModel reqTmm) {
        generateAutoReversalTxn(reqTmm, reqTmm.getSourceProcessor(), reqTmm.getTransactionName());
    }

    private void validateDependentTransaction(TransactionMessageModel dependentTxnTmm) {
        //Validating Original txn Date for refund - should not exceed by 180 days
        OffsetDateTime originalTxnDate = dependentTxnTmm.getOriginalTmm().getRequestReceivedTime();
        OffsetDateTime txnDate = dependentTxnTmm.getRequestReceivedTime();
        if (originalTxnDate != null && txnDate != null) {
            Duration duration = Duration.between(originalTxnDate, txnDate);
            long days = duration.toDays();
            System.out.println(days);
            if (days > 180L) {
                logger.info("Original Txn Date Expired");
                throw new TransactionDateExceededException("Original Transaction Date Exceeded By 180 Days");
            }
        }
        //Validating txn amount for refund - should not exceed by original txn amount
        BigDecimal originalTxnAmt = IsgCurrencyConversionUtils.convertPaisaToRupees(dependentTxnTmm.getOriginalTmm().getTxnAmt());
        String getDependentTotTxnAmt = new BigDecimal(dependentTxnTmm.getOriginalTmm().getDependentTotTxnAmt()).toString();
        BigDecimal dependentTotTxnAmt = IsgCurrencyConversionUtils.convertPaisaToRupees(getDependentTotTxnAmt);
        BigDecimal totDependentTxnAmt = (dependentTotTxnAmt == null ? new BigDecimal(0.00)
                : dependentTotTxnAmt).add(IsgCurrencyConversionUtils.convertPaisaToRupees(dependentTxnTmm.getTxnAmt()));
        if (totDependentTxnAmt.compareTo(originalTxnAmt) > 0) {
            if (SmartRouteMsgTypeHelper.isRefund(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode()))
                throw new RefundAmountExceededException(
                        ("Txn amount has been exceeded, Original Txn Amt: " + originalTxnAmt + ", Dependent Txn Total Amt: "
                                + totDependentTxnAmt));
        }
    }

    public String generatePaymentLinkId() {
        UUID uuid = Generators.timeBasedGenerator().generate();
        AtomicLong atomicLong = new AtomicLong(uuid.timestamp());
        return Long.toUnsignedString(atomicLong.get());
    }

    public void logPaymentLinksModelToTlm(PaymentLinksModel paymentLinksModel) {
        if (paymentLinksModel != null) {
            KafkaProducer kafkaProducer = RoutingInitializationContext.getPayLinkKafkaProducer();
            logger.debug("Logging Payment Link Model to TLM");
            kafkaProducer.sendMessage(paymentLinksModel);
            logger.debug("Logged Payment Link Model to TLM");
        }
    }

    public void sendNotificationMail(String bankId, String mobileNo, String emailId, DataElements dataElements) {
        logger.info("Mailing anomalies found");
        NotificationReqModel reqModel = notificationReqBody.toNotificationReqModel(bankId, mobileNo, emailId,dataElements);
        try {
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            ResponseEntity<NotificationResModel> result = restTemplate.exchange(
                    initProps.getNotificationServer() + initProps.getNotificationUri(), HttpMethod.POST, buildHeaders(reqModel),
                    NotificationResModel.class);

            if (result.getStatusCode() != HttpStatus.OK) {
                throw new RuntimeException();
            }
            logger.info("Mail or SMS sent successfully");
        } catch (Exception e) {
            logger.error("Error while sending notification: ", e);
        }
    }
    private HttpEntity<RequestBody> buildHeaders(NotificationReqModel body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return new HttpEntity(body, headers);
    }

    public static int generateMerchantTxnRefNo() {
        int MIN_VALUE = 100000;
        int MAX_VALUE = 999999999;
        Set<Integer> generatedNumbers = new HashSet<>();
        Random random = new Random();
        int randomNum = 0;
        int uniqueNumberCount = 0;
        while (uniqueNumberCount < (MAX_VALUE - MIN_VALUE + 1)) {
            randomNum = random.nextInt(MAX_VALUE - MIN_VALUE + 1) + MIN_VALUE;
            if (!generatedNumbers.contains(randomNum)) {
                generatedNumbers.add(randomNum);
                uniqueNumberCount++;
                break;
            }
        }
        return randomNum;
    }

    public String getBankAccountNoByPaymentMode(TransactionMessageModel originalTmm) {
        String accNo = null;
        TargetType targetType = originalTmm.getTargetType();
        TransactionMessageModel.SmartRouteData smartRouteData = originalTmm.getSmartRouteData();
        String payModeId = smartRouteData.getPayModeId();
        switch (targetType) {
            case Lyra:
                if ("3".equalsIgnoreCase(payModeId)) {
                    accNo = MTMProperties.getProperty("pg.sr.icici.fund.transfer.card.accno");
                }
            case Tpsl:
                if ("1".equalsIgnoreCase(payModeId)) {
                    accNo = MTMProperties.getProperty("pg.sr.icici.fund.transfer.netbanking.accno");
                } else if ("2".equalsIgnoreCase(payModeId)) {
                    accNo = MTMProperties.getProperty("pg.sr.icici.fund.transfer.wallet.accno");
                }
            case Icici:
                if ("4".equalsIgnoreCase(payModeId)) {
                    accNo = MTMProperties.getProperty("pg.sr.icici.fund.transfer.upi.accno");
                }else if("1".equalsIgnoreCase(payModeId) && (IciciMsgType.NbRetailPay.msgType.equalsIgnoreCase(originalTmm.getMsgType()))){
                    accNo = MTMProperties.getProperty("pg.sr.icici.retail.fund.transfer.netbanking.accno");
                } else if("1".equalsIgnoreCase(payModeId) && (IciciMsgType.NbCorpPay.msgType.equalsIgnoreCase(originalTmm.getMsgType()))) {
                    accNo = MTMProperties.getProperty("pg.sr.icici.corp.fund.transfer.netbanking.accno");
                }
        }
        return accNo;
    }

    public long calculateTimeDifference(OffsetDateTime oriTxnTime, OffsetDateTime resTime) {
        OffsetDateTime timeToGMT = convertTimeToGMT(resTime.toString());
        Duration duration = Duration.between(oriTxnTime, timeToGMT);
        return duration.toMinutes();
    }

    private static OffsetDateTime convertTimeToGMT(String requestReceivedTime) {
        ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(0, 0);
        OffsetDateTime dateTimeWithGMTOffset = OffsetDateTime.parse(requestReceivedTime).withOffsetSameInstant(gmtOffset);
        return dateTimeWithGMTOffset;
    }

    public CacheTargetMerchantMaster fetchCacheTargetMerchantMaster(String targetId, String mid, String tid) {
        CacheTargetMerchantMaster targetMerchantMaster = SpringContextBridge.services().getSrCacheService().getTargetMerchantMasterModel(targetId, mid, tid);
        if (targetMerchantMaster == null || (targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Inprogress.name()) ||
                targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Failed.name()))) {
            List<TargetMerchantMasterModel> targetMerchantMaster1 = SpringContextBridge.services().getInitRestClient().getTargetMerchantMaster(targetId, mid, tid, ActiveInactiveFlag.Active.name());
            if(targetMerchantMaster1 != null && !targetMerchantMaster1.isEmpty()){
                targetMerchantMaster = updateTargetMerchantMasterCache(targetMerchantMaster1.get(0));
            }else{
                return null;
            }
        }
        return targetMerchantMaster;
    }

    public CacheTargetMerchantMaster updateTargetMerchantMasterCache(TargetMerchantMasterModel targetMerchantMasterModel) {
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        CacheTargetMerchantMaster masterData = null;
        try {
            TargetMerchantMasterModel targetModel = null;
            if (targetMerchantMasterModel != null) {
                targetModel = SmartRouteConfigUtil.getTargetMerchantMasterModel(targetMerchantMasterModel);
                masterData = srCacheService.getTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(),targetModel.getTid());
                logger.info("Fetched Target Merchant Master From Redis For TargetId {} : and Status Is : {} " , targetModel.getTargetId(),masterData !=null ? masterData.getStatus() : null);
                CacheTargetMerchantMaster key;
                if (masterData != null && !masterData.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                    srCacheService.removeTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid());
                    masterData = new CacheTargetMerchantMaster();
                    masterData.setTargetMid(targetModel.getTargetMid());
                    masterData.setMerchantVpa(targetModel.getMerchantVpa());
                    masterData.setKey(targetModel.getKey());
                    masterData.setSalt(targetModel.getSalt());
                    masterData.setStatus(targetModel.getStatus());
                    masterData.setProdApiKey(targetModel.getProdApiKey());
                    masterData.setTestApiKey(targetModel.getTestApiKey());
                    masterData.setDpdId(targetModel.getDpaId());
                    srCacheService.putTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid(), masterData);
//                    cacheUtil.putTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getStatus(), masterData);

                } else if (masterData == null) {
                    masterData = new CacheTargetMerchantMaster();
                    masterData.setTargetMid(targetModel.getTargetMid());
                    masterData.setMerchantVpa(targetModel.getMerchantVpa());
                    masterData.setKey(targetModel.getKey());
                    masterData.setSalt(targetModel.getSalt());
                    masterData.setStatus(targetModel.getStatus());
                    masterData.setProdApiKey(targetModel.getProdApiKey());
                    masterData.setTestApiKey(targetModel.getTestApiKey());
                    masterData.setDpdId(targetModel.getDpaId());
                    srCacheService.putTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid(), masterData);
//                    cacheUtil.putTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getStatus(), masterData);
                }
            }
//            String targetMid = cacheUtil.getTargetMid(targetModel.getTargetId().toString(), targetModel.getMid(),targetModel.getTid());
//            masterData = cacheUtil.getTargetMerchantMaster(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid());
            logger.trace("Target Merchant Master Model for targetMID : {} and status : {}  Inserted/Updated Successfully...", masterData.getTargetMid() , masterData.getStatus());
        } catch (Exception e) {
            logger.error("An error occurred!", e);
            return masterData;
        }
        return masterData;
    }


    public void validateBinFromBillingCurrencies(RoutingContext routingContext, TransactionMessageModel tmm) {
    	String cardNumber = new String(DatatypeConverter.parseHexBinary(tmm.getPan()));
    	logger.info("Validate Bin for the Dcc transaction: {}", MaskingUtility.maskCardNumber(cardNumber));
    	try {
    		if (tmm.getDccTxnCurrCode() != null) {
    			BillingCurrencyModel billingCurrencyModel = mwRedisCacheUtil.getBillingCurrenciesData(Integer.parseInt(tmm.getDccTxnCurrCode()));
    			if (billingCurrencyModel == null) {
    				throw new InvalidBinException("Dcc Txn Currency Code: " + tmm.getDccTxnCurrCode() + ", is not valid");
    			}
    			if (billingCurrencyModel.getAccountLowRange() != null
    					&& billingCurrencyModel.getAccountHighRange() != null) {
    				BigInteger binNum = new BigInteger(cardNumber.substring(0, 9));
    				if (binNum.intValue() >= billingCurrencyModel.getAccountLowRange().intValue() 
    						&& binNum.intValue() <= billingCurrencyModel.getAccountHighRange().intValue()){
    					tmm.setDccIndicator(Integer.toString(billingCurrencyModel.getDccIndicator()));
    					logger.info("Bin for the Dcc transaction validated: {}", MaskingUtility.maskCardNumber(cardNumber));
    				} else {
    					throw new InvalidBinException("Bin: " + cardNumber + ", is not valid");
    				}
    			}
    		}
    	} catch (NoSuchElementException e) {
    		throw new SystemErrorException("Bin is not present");
    	} catch (Exception e) {
    		throw new InvalidBinException("Bin: " + tmm.getPan() + ", is not valid");
    	}
    }

    //Bms
    public String parseResponse(String resBody) {
        resBody = IsgJsonUtils.removeQuotesAndUnescape(resBody);
        String[] split = resBody.split(API_RESPONSE_SEPARATOR);
        int status = Integer.parseInt(split[0]);
        String response = split[1];
        return response;
    }

    public String generateTxnId() {

        long timestamp = System.currentTimeMillis();

        byte[] randomBytes = new byte[16];
        new SecureRandom().nextBytes(randomBytes);
        String randomComponent = bytesToHex(randomBytes);

        String uniqueString = timestamp + randomComponent;

        // Hash the combined string using SHA-256
        String uniqueHash = sha256(uniqueString);

        // Take the first 32 characters of the hash
        String uniqueNumber = uniqueHash.substring(0, 32);

        return uniqueNumber;
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }

    private String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
