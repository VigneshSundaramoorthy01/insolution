package com.isg.mw.routing.route.pgswitch;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.LyraMsgType;
import com.isg.mw.core.model.construct.cybs.CybsMsgTypeHelper;
import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.core.model.icici.UpiCallbackAck;
import com.isg.mw.core.model.icici.UpiCallbackRequest;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.pg.*;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.PaymentLinksModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.model.ResponseMsg;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.IsgXmlUtils;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.RSAUtil;
import com.isg.mw.mtm.config.DecryptService;
import com.isg.mw.mtm.config.EncryptService;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.MessageTransformationException;
import com.isg.mw.mtm.parser.ITmmParser;
import com.isg.mw.mtm.parser.factory.BaseTmmParser;
import com.isg.mw.mtm.parser.factory.ParserFactory;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.DeclineMessageTransformation;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.transform.pg.PgMessageTransformation;
import com.isg.mw.mtm.transform.pos.PosMessageTransformation;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.exception.ApiRequestValidationException;
import com.isg.mw.routing.exception.RequestProcessingException;
import com.isg.mw.routing.exception.RequestValidationException;
import com.isg.mw.routing.exception.ResponseProcessingException;
import com.isg.mw.routing.exception.TargetNoResponseException;
import com.isg.mw.routing.route.SwitchRouter;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isAllSchemeReversalRes;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isReversalRequest;
import static com.isg.mw.mtm.transform.MessageTransformer.identifyTargetTxnTypeConfig;
import static com.isg.mw.routing.config.RoutingConstants.*;

@Component
public class ApiTransactionProcessor {

    private final Logger logger = LogManager.getLogger(getClass());

    private final Logger rawlogger = LogManager.getLogger("rawLog");

    @Autowired
    private SwitchRouter switchRouterService;

    @Value("${target.timeout.auto.reversal:true}")
    private boolean timeOutAutoReversal;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    private static final List<String> cybsSuccessList = new ArrayList<>();

    static {
        cybsSuccessList.add("AUTHORIZED");
        cybsSuccessList.add("PENDING");
        cybsSuccessList.add("REVERSED");
    }

    public TransactionMessageModel toPojo(Exchange exchange) {
        TransactionMessageModel reqSrcTmm = null;
        try {
            ApiTxnModel apiTxnModel = decryptAndValidateRequest(exchange);

            reqSrcTmm = apiTxnModel.buildTmm();
            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            String entityId = routingContext.getEntityId();
            String epId = routingContext.getSource().getName();
            TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(epId);
            Set<String> txnNameList = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                    .get(targetType + "." + apiTxnModel.getMsgType() + "." + apiTxnModel.getProcessingCode());
            String txnTypeName = txnNameList.stream().findFirst().orElse(null);

            reqSrcTmm.setTransactionName(txnTypeName);
            reqSrcTmm.setTargetType(targetType);
            reqSrcTmm.setConnectionType(ConnectionType.API);
            updateDrCrFlag(reqSrcTmm);
            MessageTransformer.setAdditionalData(entityId, OffsetDateTime.now(), routingContext.getSource().getName(), TlmMessageType.REQUEST, reqSrcTmm);

        } catch (Exception e) {
            throw new RequestProcessingException("Error while processing the request message ", e);
        }
        return reqSrcTmm;
    }

    public ApiTxnModel decryptAndValidateRequest(Exchange exchange) {
        DecryptService decryptService = SpringContextBridge.services().getDecryptionService();
        byte[] decodedKey = Base64.getDecoder().decode(decryptService.decrypt((String) exchange.getIn().getHeader("secretkey")));
        SecretKey secretKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
        Cipher cipher = SpringContextBridge.getCipherInstance();

        ApiTxnModel apiTxnModel;
        try {
            cipher.init(Cipher.DECRYPT_MODE, secretKey);

            String body = exchange.getIn().getBody(String.class);
            ApiTxnModel encryptedReq = IsgJsonUtils.getObjectFromJsonString(body, ApiTxnModel.class);
            byte[] decode = Base64.getDecoder().decode(encryptedReq.getDval());
            byte[] bytes = cipher.doFinal(decode);
            String strApiTxnModel = new String(bytes, StandardCharsets.UTF_8);

            apiTxnModel = IsgJsonUtils.getObjectFromJsonString(strApiTxnModel, ApiTxnModel.class);
            apiTxnModel.setCval((String) exchange.getIn().getHeader("cval"));

            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            String epId = routingContext.getSource().getName();
            Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
            MessageFormatConfigModel msgFormatConfigModel = msgFormatMap.get(apiTxnModel.getMsgType());
            if (msgFormatConfigModel != null) {
                validateJson(msgFormatConfigModel, apiTxnModel);
            }
            validateChecksum(apiTxnModel);

        } catch (InvalidKeyException | IllegalBlockSizeException |
                BadPaddingException e) {
            throw new RuntimeException(e);
        }
        return apiTxnModel;
    }

    public MerchantEncDataRequest decryptMerchantEncryptedRequest(String reqBody, String secretKey, String merchantEncryptedKey) {
        Cipher cipher = SpringContextBridge.getCipherInstance();
        logger.trace("ENCRYPTED REQ BODY: {} WITH ENCRYPTION KEY: {}", reqBody, merchantEncryptedKey);
//        reqBody = reqBody.replace(" ", "+");
//        logger.trace("\n\n\nEncrypted Req Body: {}, Encryption Key: {}", reqBody, merchantEncryptedKey);
        MerchantEncDataRequest mercEncDataObj = null;
        try {
            byte[] keyByte = merchantEncryptedKey.getBytes();
            Key key = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedByteValue = Base64.getDecoder().decode(reqBody.getBytes());
            byte[] decValue = cipher.doFinal(decryptedByteValue);
            String decryptVal = new String(decValue);
            logger.trace("DECRYPTED JSON REQUEST BODY : {}", decryptVal);
            JSONObject jsonObject = getObjectFromRequestBody(decryptVal);
            String secureHash = generateMerchantSecureHash(jsonObject, secretKey);
            mercEncDataObj = IsgJsonUtils.getObjectFromJsonString(jsonObject.toString(), MerchantEncDataRequest.class);
            if (secureHash.toLowerCase().equals(mercEncDataObj.getSecureHash().toLowerCase())) {
                return mercEncDataObj;
            } else {
                return null;
            }
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            logger.error("ERROR WHILE DECRYPTING MERCHANT DETAILS : ", e);
            //throw new RuntimeException(e);
        }
        return mercEncDataObj;
    }

    public MerchantEncDataResponse decryptMerchantEncryptedResponse(String reqBody, String secretKey, String merchantEncryptedKey) {
        Cipher cipher = SpringContextBridge.getCipherInstance();
        logger.trace("Encrypted Req Body: {}, Encryption Key: {}", reqBody, merchantEncryptedKey);
//        reqBody = reqBody.replace(" ", "+");
//        logger.trace("\n\n\nEncrypted Req Body: {}, Encryption Key: {}", reqBody, merchantEncryptedKey);
        MerchantEncDataResponse mercEncDataObj = null;
        try {
            byte[] keyByte = merchantEncryptedKey.getBytes();
            Key key = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedByteValue = Base64.getDecoder().decode(reqBody.getBytes());
            byte[] decValue = cipher.doFinal(decryptedByteValue);
            String decryptVal = new String(decValue);

            JSONObject jsonObject = getObjectFromRequestBody(decryptVal);
            String secureHash = generateMerchantSecureHash(jsonObject, secretKey);
            mercEncDataObj = IsgJsonUtils.getObjectFromJsonString(jsonObject.toString(), MerchantEncDataResponse.class);
            if (secureHash.equals(mercEncDataObj.getSecureHash())) {
                return mercEncDataObj;
            }
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            logger.error("", e);
            throw new RuntimeException(e);
        }
        return mercEncDataObj;
    }

    public MerchantEncDataResponse getMerchantResWithSecureHash(MerchantEncDataResponse refundDataRes,String secretKey) {
        JSONObject jsonObject = new JSONObject(refundDataRes);
        String secureHash = generateMerchantSecureHash(jsonObject, secretKey);
        refundDataRes.setSecureHash(secureHash);
        return refundDataRes;
    }

    public MerchantPayAndRefundStatusRes getMerchantResWithSecureHash(MerchantPayAndRefundStatusRes refundDataRes, String secretKey) {
        JSONObject jsonObject = new JSONObject(refundDataRes);
        String secureHash = generateMerchantSecureHash(jsonObject, secretKey);
        refundDataRes.setSecureHash(secureHash);
        return refundDataRes;
    }

    public MerchantRefundRes getMerchantResWithSecureHash(MerchantRefundRes payAndRefundStatusRes, String secretKey) {
        JSONObject jsonObject = new JSONObject(payAndRefundStatusRes);
        String secureHash = generateMerchantSecureHash(jsonObject, secretKey);
        payAndRefundStatusRes.setSecureHash(secureHash);
        return payAndRefundStatusRes;
    }

    public PaymentLinksModel getMerchantPaymentLinkResWithSecureHash(PaymentLinksModel paymentLinksModel, String secretKey) {
        JSONObject jsonObject = new JSONObject(paymentLinksModel);
        String secureHash = generateMerchantSecureHashForPaymentLink(jsonObject, secretKey);
        paymentLinksModel.setSecureHash(secureHash);
        return paymentLinksModel;
    }


    public MerchantEncReqRes generateMerchantEncryptedData(RoutingContext routingContext
            , ApiTxnModel apiTxnModel,TransactionMessageModel resTargetTmm) {
        CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
        String merchantId = apiTxnModel.getMid();
        String entityId = routingContext.getEntityId();
        MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(entityId, merchantId);
        MerchOrdTxnData merchOrdTxnData = cacheUtil.getTxnData(entityId, merchantId, apiTxnModel.getMerchantTxnRefNo());
        String encData = merchOrdTxnData.getEncData();
        MerchantEncDataRequest merchantEncDataRequest = decryptMerchantEncryptedRequest(encData, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());

        MerchantEncDataResponse merchantEncDataRes = toMerchantEncDataRes(merchantEncDataRequest);
        merchantEncDataRes.setRetRefNo(resTargetTmm.getTransactionId());
        merchantEncDataRes.setRespDate(resTargetTmm.getResponseReceivedTime());
        merchantEncDataRes.setRespTime(resTargetTmm.getResponseReceivedTime());
        if(StringUtils.isBlank(apiTxnModel.getError()) && "00".equalsIgnoreCase(resTargetTmm.getResCode())){
            merchantEncDataRes.setResponseCode(resTargetTmm.getResCode());
            merchantEncDataRes.setMessage("Transaction Successful");
        }else{
            merchantEncDataRes.setResponseCode(resTargetTmm.getResCode());
            merchantEncDataRes.setMessage("Transaction failed");
        }
        String data = encryptMerchantData(merchantEncDataRes, merchantMaster.getSecretKey(), merchantMaster.getEncryptionKey());
        MerchantEncReqRes merchantEncReqRes = new MerchantEncReqRes();
        merchantEncReqRes.setMerchantId(merchantId);
        merchantEncReqRes.setTerminalId(merchOrdTxnData.getTerminalId());
        merchantEncReqRes.setBankId(entityId);
        merchantEncReqRes.setEncData(data);
        return merchantEncReqRes;
    }

    public MerchantEncDataResponse toMerchantEncDataRes(MerchantEncDataRequest merchantEncDataRequest) {
        MerchantEncDataResponse res = new MerchantEncDataResponse();
        res.setBankId(merchantEncDataRequest.getBankId());
        res.setMerchantId(merchantEncDataRequest.getMerchantId());
        res.setTerminalId(merchantEncDataRequest.getTerminalId());
        res.setTxnRefNo(merchantEncDataRequest.getTxnRefNo());
        res.setMcc(merchantEncDataRequest.getMcc());
        res.setPassCode(merchantEncDataRequest.getPassCode());
        res.setCurrency(merchantEncDataRequest.getCurrency());
        res.setAmount(merchantEncDataRequest.getAmount());
        res.setOrderInfo(merchantEncDataRequest.getOrderInfo());
        res.setPayOpt(merchantEncDataRequest.getPayOpt());
        res.setFirstName(merchantEncDataRequest.getFirstName());
        res.setLastName(merchantEncDataRequest.getLastName());
        res.setStreet(merchantEncDataRequest.getStreet());
        res.setCity(merchantEncDataRequest.getCity());
        res.setState(merchantEncDataRequest.getState());
        res.setZip(merchantEncDataRequest.getZip());
        res.setEmail(merchantEncDataRequest.getEmail());
        res.setPhone(merchantEncDataRequest.getPhone());
        res.setUdf01(merchantEncDataRequest.getUdf01());
        res.setUdf02(merchantEncDataRequest.getUdf02());
        res.setUdf03(merchantEncDataRequest.getUdf03());
        res.setUdf04(merchantEncDataRequest.getUdf04());
        res.setUdf05(merchantEncDataRequest.getUdf05());
        res.setUdf06(merchantEncDataRequest.getUdf06());
        res.setUdf07(merchantEncDataRequest.getUdf07());
        res.setUdf08(merchantEncDataRequest.getUdf08());
        res.setUdf09(merchantEncDataRequest.getUdf09());
        res.setUdf10(merchantEncDataRequest.getUdf10());
        res.setChUserID(merchantEncDataRequest.getChUserID());
        res.setCardTokenReferenceNo(merchantEncDataRequest.getCardTokenReferenceNo());
        res.setSecureHash(merchantEncDataRequest.getSecureHash());
        res.setVersion(merchantEncDataRequest.getVersion());
        return res;
    }

    public String encryptMerchantData(MerchantEncDataResponse merchantEncDataResponse, String secretKey, String merchantEncryptedKey) {
        String encryptedValue = null;
        Cipher cipher = SpringContextBridge.getCipherInstance();
        try {
            byte[] keyByte = merchantEncryptedKey.getBytes();
            Key key = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            JSONObject jsonObject = new JSONObject(IsgJsonUtils.getJsonString(merchantEncDataResponse));
            List<String> sortedKeys = getMerchantSortedKeyList(jsonObject);
            logger.trace("RESPONSE BODY BEFORE ENCRYPTION  :: {}", jsonObject);
            String secureHash = getSecureHash(jsonObject, sortedKeys, secretKey);
            jsonObject.put("SecureHash", secureHash);
            String encryptionValue = getStringForEncryption(jsonObject);
            logger.trace("ENCRYPTED RESPONSE BODY :: {}", encryptionValue);
            byte encVal[] = cipher.doFinal(encryptionValue.getBytes());
            byte encryptedByteValue[] = Base64.getEncoder().encode(encVal);
            encryptedValue = new String(encryptedByteValue);
        } catch (Exception ex) {
            System.out.println("EXCEPTION WHILE ENCRYPTING DATA -> [" + ex + "]");
            ex.printStackTrace();
        }
        return encryptedValue;
    }

    public String encryptMerchantData(MerchantEncDataRequest merchantEncDataRequest, String secretKey, String merchantEncryptedKey) {
        String encryptedValue = null;
        Cipher cipher = SpringContextBridge.getCipherInstance();
        try {
            byte[] keyByte = merchantEncryptedKey.getBytes();
            Key key = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            JSONObject jsonObject = new JSONObject(IsgJsonUtils.getJsonString(merchantEncDataRequest));
            List<String> sortedKeys = getMerchantSortedKeyList(jsonObject);
            String secureHash = getSecureHash(jsonObject, sortedKeys, secretKey);
            jsonObject.put("SecureHash", secureHash);
            String encryptionValue = getStringForEncryption(jsonObject);
            byte encVal[] = cipher.doFinal(encryptionValue.getBytes());
            byte encryptedByteValue[] = Base64.getEncoder().encode(encVal);
            encryptedValue = new String(encryptedByteValue);
        } catch (Exception ex) {
            System.out.println("Exception while encrypting Data -> [" + ex + "]");
            ex.printStackTrace();
        }
        return encryptedValue;
    }

    private String getSecureHash(JSONObject jsonObject, List<String> keys, String secretKey) throws NoSuchAlgorithmException {
        String secureHash = "";
        secureHash = secureHash + secretKey;
        for (String key : keys) {
            String value = jsonObject.getString(key);
            secureHash = secureHash + value;
        }
        logger.trace("\n DATA FOR HASHING : {}", secureHash);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        secureHash = DatatypeConverter.printHexBinary(md.digest(secureHash.getBytes()));
        logger.trace("\n SECURE HASH DATA : {}", secureHash);
        return secureHash;
    }

    private static String getStringForEncryption(JSONObject jsonObject) {
        String encryptionValue = "";
        Iterator<String> keys = jsonObject.keys();

        while (keys.hasNext()) {
            String key = keys.next();
            String value = jsonObject.getString(key);
            encryptionValue = encryptionValue + key + "||" + value + "::";
        }
        encryptionValue = encryptionValue.substring(0, encryptionValue.length() - 2);
        return encryptionValue;
    }


    public JSONObject getObjectFromRequestBody(String decryptVal) {
        String[] split = decryptVal.split("::");
        JSONObject jsonObject = new JSONObject();
        for (String keyVal : split) {
            String[] split1 = keyVal.split("\\|\\|");
            if (split1.length > 1) {
                jsonObject.put(split1[0], split1[1]);
            } else {
                jsonObject.put(split1[0], "");
            }
        }
        return jsonObject;
    }

    public String generateMerchantSecureHash(JSONObject jsonObject, String secretKey) {
        StringBuilder secureHash = new StringBuilder();
        secureHash.append(secretKey);
        List<String> sortedKeyList = getMerchantSortedKeyList(jsonObject);
        for (String sortedKey : sortedKeyList) {
            try{
                String value = jsonObject.getString(sortedKey);
                secureHash.append(value);
            } catch (Exception e){
                logger.info(e.getMessage());
                continue;
            }
        }
        logger.trace("\nDATA FOR HASHING : {}", secureHash);
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        String s = DatatypeConverter.printHexBinary(md.digest(secureHash.toString().getBytes()));
        logger.trace("\nSECURE HASH DATA : {}", s);
        return s;
    }

    public String generateMerchantSecureHashForPaymentLink(JSONObject jsonObject, String secretKey) {
        StringBuilder secureHash = new StringBuilder();
        secureHash.append(secretKey);
        List<String> sortedKeyList = getMerchantSortedKeyListForPaymentLink(jsonObject);
        for (String sortedKey : sortedKeyList) {
            try{
                String value = jsonObject.getString(sortedKey);
                secureHash.append(value);
            } catch (Exception e){
                logger.info(e.getMessage());
                continue;
            }
        }
        logger.trace("\nDATA FOR HASHING : {}", secureHash);
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        String s = DatatypeConverter.printHexBinary(md.digest(secureHash.toString().getBytes()));
        logger.trace("\nSECURE HASH DATA : {}", s);
        return s;
    }

    public List<String> getMerchantSortedKeyList(JSONObject jsonObject) {
        List<String> list = new ArrayList<>();
        Iterator<String> keys = jsonObject.keys();
        while (keys.hasNext()) {
            String currentKey = keys.next();
            if (!currentKey.equalsIgnoreCase("secureHash") && !currentKey.equalsIgnoreCase("linkHashId")){
                list.add(currentKey);
            }
        }
        Collections.sort(list);
        return list;
    }

    public List<String> getMerchantSortedKeyListForPaymentLink(JSONObject jsonObject) {
        List<String> list = new ArrayList<>();
        Iterator<String> keys = jsonObject.keys();
        while (keys.hasNext()) {
            String currentKey = keys.next();
            if (!currentKey.equalsIgnoreCase("secureHash") && !currentKey.equalsIgnoreCase("linkHashId") && !currentKey.equalsIgnoreCase("")){
                list.add(currentKey);
            }
        }
        Collections.sort(list);
        return list;
    }

    public TransactionMessageModel sendApiRequest(Exchange exchange, TransactionMessageModel reqSrcTmm, TargetConfigModel targetConfigModel) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        String mid = reqSrcTmm.getCardAcceptorId();
        if (TargetType.Amex.name().equals(targetConfigModel.getTargetType().name()) && SourceProcessor.POS_SWITCH.equals(reqSrcTmm.getSourceProcessor())) {
            CacheTargetMerchantMaster targetMerchantMaster = SpringContextBridge.services().getSrCacheService().getTargetMerchantMasterModel(targetConfigModel.getId().toString(), reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId());
            if (targetMerchantMaster != null && targetMerchantMaster.getTargetMid() != null ) {
                reqSrcTmm.setCardAcceptorId(targetMerchantMaster.getTargetMid());
            }
        }

        MessageContext messageContext = MessageTransformer.constructMessage(reqSrcTmm, targetConfigModel.getName());
        if (TargetType.Amex.name().equals(targetConfigModel.getTargetType().name())
        		&& SourceProcessor.POS_SWITCH.equals(reqSrcTmm.getSourceProcessor())) {
        	TransactionMessageModel reqTgtTmm = messageContext.getTransactionMessageModel();
        	reqTgtTmm.setCardAcceptorId(mid);
        	messageContext.setTransactionMessageModel(reqTgtTmm);
        }
        
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        processorHelper.prepareTgtMessageAndLogTlm(messageContext, routingContext);

        if (!StringUtils.isBlank(messageContext.getTransactionMessageModel().getSmartRouteData().getRedirectUrl())) {
            return messageContext.getTransactionMessageModel();
        }
        Object requestJsonStr = messageContext.getRawMsg();
        String targetUrl = "";
        String host = "";
        if (TmmConstants.isIciciCorpNBMsgType(messageContext.getTransactionMessageModel().getMsgType())) {
            targetUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getIciciNbCorporateUrl();
            host = targetConfigModel.getConnections().get(0).getUrlOrIp() + targetUrl;
        } else if (TmmConstants.isIciciRetailNBMsgType(messageContext.getTransactionMessageModel().getMsgType())) {
            targetUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getIciciNbRetailUrl();
            host = targetConfigModel.getConnections().get(0).getUrlOrIp() + targetUrl;
        } else {
            targetUrl = TransactionProcessorHelper.getTxnUrl(targetConfigModel) + (StringUtils.isBlank(messageContext.getTxnApiPath()) ? "" : messageContext.getTxnApiPath());
            if (IciciMsgType.Pay.msgType.equals(reqSrcTmm.getMsgType())) {
                host = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getTxnUrl();
            }else if (IciciMsgType.UpiQR.msgType.equals(reqSrcTmm.getMsgType())) {
                host = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getQrApiUrl();
            }else if ((IciciMsgType.UpiRefund.msgType.equals(reqSrcTmm.getMsgType()) || IciciMsgType.UpiReversal.msgType.equals(reqSrcTmm.getMsgType()))
                    && messageContext.getTransactionMessageModel().getTargetType() == TargetType.Icici) {
                host = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getRefundUrl();
            }else if ((LyraMsgType.Refund.msgType.equals(reqSrcTmm.getMsgType()) || LyraMsgType.Reversal.msgType.equals(reqSrcTmm.getMsgType()))
                    && messageContext.getTransactionMessageModel().getTargetType() == TargetType.Lyra){
                host = targetConfigModel.getAdditionalData().getApiInfo().getLyra().getRefundUrl();
            }else if((CommonConstants.REFUND_TXN.equalsIgnoreCase(reqSrcTmm.getMsgType()) || CommonConstants.REVERSAL_TXN.equalsIgnoreCase(reqSrcTmm.getMsgType()))
                    && messageContext.getTransactionMessageModel().getTargetType() == TargetType.Tpsl){
                host = targetConfigModel.getAdditionalData().getApiInfo().getTpsl().getRefundUrl();
            }else if(IciciMsgType.VerifyVPA.msgType.equals(reqSrcTmm.getMsgType())){
                host = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getVerifyVPAUrl();
            } else if(TargetType.Amex.name().equals(targetConfigModel.getTargetType().name())){
            	host = targetConfigModel.getConnections().get(0).getUrlOrIp();
            }
        }
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_TARGET_SCHEME, host);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_TGT_TMM, messageContext.getTransactionMessageModel());
        Class<?> businessRuleClass = messageContext.getMessageTransformationConfig().getBusinessRuleClass();
        Object res = null;
        try {
            if (TmmConstants.isIciciCorpNBMsgType(messageContext.getTransactionMessageModel().getMsgType()) ||
                    TmmConstants.isIciciRetailNBMsgType(messageContext.getTransactionMessageModel().getMsgType())) {
                res = RoutingInitializationContext.getMwProducer()
                        .callApiUsingWebClient("", host + requestJsonStr.toString(), messageContext.getApiHeaders());
            } else if (TargetType.Amex.name().equals(targetConfigModel.getTargetType().name())) {
            	 res = RoutingInitializationContext.getMwProducer()
                         .callApi(requestJsonStr.toString(), host + targetUrl, messageContext.getApiHeaders());
            } else {
                if (TargetType.Icici == targetConfigModel.getTargetType() && "Y".equalsIgnoreCase(MTMProperties.getProperty("icici.proxy.enable"))) {
                    res = RoutingInitializationContext.getMwProducer()
                            .callApiUsingProxyWebClient(requestJsonStr.toString(), host, messageContext.getApiHeaders());
                } else {
                    res = RoutingInitializationContext.getMwProducer()
                            .callApiUsingWebClient(requestJsonStr.toString(), host + targetUrl, messageContext.getApiHeaders());
                }
            }

        } catch (Exception e) {
            logger.info("Exception while calling target api :: {}",e.getMessage());
            e.printStackTrace();
            throw new TargetNoResponseException("No response from target");
//            res = "<XML><MessageType>1210</MessageType><ProcCode>334034</ProcCode><ActCode>92</ActCode><PayeeRevRespCode/><SeqNo>5964565798dd40dc91ad67520e5f83a6</SeqNo><BankRRN>322200220105</BankRRN><UserProfile>3263612</UserProfile><PayeeRespCode/><success>true</success><response>92</response><MobileAppData/><PayerRevRespCode/><PayerRespCode/><message>Transaction initiated</message><UpiTranlogId>88388926</UpiTranlogId></XML>";
//            if (targetConfigModel.getTargetType() == TargetType.Icici) {
//                res = "200##{\"success\":false,\"response\":401,\"message\":\"INVALID_APIKEY\",\"ValidationSummary\":{\"field-name\":\"The APIKey provided is not valid\"}}";
//            }
        }

        String resBody = null;
        TransactionMessageModel resSrcTmm=null;
        String targetTxnId = messageContext.getTransactionMessageModel().getTargetTxnId();
        if (TmmConstants.isIciciUpiMsgType(reqSrcTmm.getMsgType()) && messageContext.getTransactionMessageModel().getTargetType() == TargetType.Icici) {
//            String upiResFromFile = getUpiResFromFile(reqSrcTmm.getMsgType());
//            res = upiResFromFile.replace("#targetTxnId#", targetTxnId);
            if (res != null) {
                resSrcTmm = processTargetApiResponse(res.toString(), businessRuleClass, exchange);
                resSrcTmm.setRawResponse(res.toString());
            }
        } else {
            if (res != null) {
                resBody = IsgJsonUtils.getJsonString(res);
                resSrcTmm = processTargetApiResponse(resBody, businessRuleClass, exchange);
                resSrcTmm.setRawResponse(resBody);
            }
        }
        return resSrcTmm;
    }

    public String  getUpiResFromFile(String msgType){
        ObjectMapper parser = new ObjectMapper();
        String res;
        try {
            Object object = parser.readValue(new File(MTMProperties.getProperty("upi.txn.response")), Object.class);
            LinkedHashMap<String, String> map = (LinkedHashMap<String, String>) object;
            res = map.get(msgType);
        } catch (Exception e) {
            res = e.getMessage();
        }
        return res;
    }

    public Object getDecryptedMsg(String res) {
        String privateKeyPath = MTMProperties.getProperty("decryption.key.provider.path.isg.icici.upi");
        PrivateKey privateKeyFromJKS;
        String decrypt = null;
        try {
            UpiKeyModel upiKeyModel = RSAUtil.readProviders(new File(privateKeyPath));
            privateKeyFromJKS = RSAUtil.getPivateKeyFromJKS(upiKeyModel.getKeyStorePath(), upiKeyModel.getKeyStoreCred(), upiKeyModel.getKeyId(), upiKeyModel.getKeyStoreCred());
            decrypt = RSAUtil.decrypt(res, privateKeyFromJKS);

        } catch (Exception e) {
            logger.info("Exception while encrypting data : {} ", e.getMessage());
        }
        logger.info("Decrypted msg : {}", decrypt);
        return decrypt;
    }

    public MessageContext constructApiResponse(Exchange exchange) {
        MessageContext targetMsgContext = null;
        try {
            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            TransactionMessageModel resSourceTmm = exchange.getIn().getBody(TransactionMessageModel.class);
            //TransactionMessageModel reqSourceTmm = exchange.getIn().getHeader(EXCHANGE_HEADER_REQ_SRC_TMM, TransactionMessageModel.class);
            targetMsgContext = new MessageContext(routingContext.getEntityId(), routingContext.getSource().getName(), "");
            TransactionMessageModel resTargetTmm = null;
//            if (reqSourceTmm.getConnectionType() == ConnectionType.ISO) {
//                resTargetTmm = processTargetISOResponse(targetMsgContext, resSourceTmm, routingContext, exchange);
//            }
            resTargetTmm = SerializationUtils.clone(resSourceTmm);

            TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(resTargetTmm.getTransactionName(), resTargetTmm.getTargetType(), routingContext.getSource().getName());
            resTargetTmm.setMsgType(txnTypeConfig.getEpMsgType());
            resTargetTmm.setProcessingCode(txnTypeConfig.getProcessingCode());
            resTargetTmm.setTarget(routingContext.getSource().getName());
            resTargetTmm.setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(routingContext.getSource().getName()));
            String apiResponse = null;
            if (resTargetTmm.getCybsData() != null && resTargetTmm.getCybsData().getStatus() != null &&
                    !cybsSuccessList.contains(resTargetTmm.getCybsData().getStatus())) {
                apiResponse = getEncryptedApiResponse(ResponseMsgType.ERROR, resTargetTmm.getCybsData().getReason(), resTargetTmm, txnTypeConfig, exchange);
            } else {
                apiResponse = getEncryptedApiResponse(ResponseMsgType.SUCCESS, null, resTargetTmm, txnTypeConfig, exchange);
            }

            targetMsgContext.setRawMsg(apiResponse);
            targetMsgContext.setTransactionMessageModel(resTargetTmm);
        } catch (Exception e) {
            throw new ResponseProcessingException("Error while processing the request message ", e);
        }
        return targetMsgContext;
    }

    private TransactionMessageModel processTargetApiResponse(String resBody, Class businessClass, Exchange exchange) {
        TransactionMessageModel resSrcTmm;
        try {
            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            //TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_SRC_TMM);
            TransactionMessageModel reqTgtTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_TGT_TMM);
            //when we get a response from the target
            BaseMessageTransformation baseMsgTransformation = (BaseMessageTransformation) businessClass.newInstance();
            //TransactionMessageModel resSrcTmm = baseMsgTransformation.parseResponse(resBody, reqTgtTmm);

            resSrcTmm = baseMsgTransformation.parseResponse(resBody, reqTgtTmm, null, null, null);
            logger.trace("Response Source Transaction message model: {}", resSrcTmm);
            if((!(SourceProcessor.SMART_ROUTE == resSrcTmm.getSourceProcessor()
                    && (resSrcTmm.getMsgType().equalsIgnoreCase(LyraMsgType.Refund.msgType) ||
                    resSrcTmm.getMsgType().equalsIgnoreCase(IciciMsgType.UpiReversal.msgType) ||
                    resSrcTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN))
                    && (TargetType.Lyra == resSrcTmm.getTargetType()
                    || TargetType.Tpsl == resSrcTmm.getTargetType())
                    || (TargetType.Icici == resSrcTmm.getTargetType())))){
                processorHelper.logToTlm(resSrcTmm, routingContext);
            }
            //resTgtTmm = SerializationUtils.clone(resSrcTmm);


        } catch (InstantiationException | IllegalAccessException e1) {
            throw new MessageTransformationException(
                    "Error while creating instance of business rule class: " + businessClass, e1);
        }
        return resSrcTmm;
    }

    public TransactionMessageModel processTargetISOResponse(TransactionMessageModel resSrcTmm, RoutingContext routingContext, Exchange exchange) {
        TransactionMessageModel resTargetTmm = null;
        TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
                .get(EXCHANGE_HEADER_REQ_SRC_TMM);
        processorHelper.setSourceDataInResponse(reqSrcTmm, resSrcTmm);
        logger.info(LogUtils.buildLogMessage(resSrcTmm.getEntityId(), resSrcTmm.getTarget(),
                resSrcTmm.getMsgType(), resSrcTmm.getTransactionId(),
                resSrcTmm.getTransactionName(), "Transaction response received"));
        try {
            processorHelper.checkForMandatoryFields(resSrcTmm);
            logger.info(
                    LogUtils.buildLogMessage(resSrcTmm.getEntityId(), resSrcTmm.getTarget(),
                            resSrcTmm.getMsgType(), resSrcTmm.getTransactionId(),
                            resSrcTmm.getTransactionName(), "Constructing transaction response for target"),
                    reqSrcTmm.getSource());

            resSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
            resTargetTmm = SerializationUtils.clone(resSrcTmm);
        } catch (Exception e) {
            logger.error("", e);
        }
        return resTargetTmm;
    }

    private void validateChecksum(ApiTxnModel apiTxnModel) {
        if (!apiTxnModel.getCval().equals(apiTxnModel.getChecksum())) {
            throw new RequestValidationException("Invalid Request :" + System.lineSeparator() + "$.checksum: is mismatched or invalid");
        }
    }

    private void validateJson(MessageFormatConfigModel msgFormatConfigModel, ApiTxnModel apiTxnModel) {
        StringBuilder errorsCombined = new StringBuilder();
        ObjectMapper om = new ObjectMapper();
        InputStream schemaAsStream = new ByteArrayInputStream(msgFormatConfigModel.getMsgFormat().getBytes(StandardCharsets.UTF_8));
        JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7).getSchema(schemaAsStream);
        JsonNode jsonNode = om.convertValue(apiTxnModel, JsonNode.class);

        Set<ValidationMessage> errors = schema.validate(jsonNode);
        for (ValidationMessage error : errors) {
            errorsCombined.append(error.toString()).append(System.lineSeparator());
        }
        if (!errors.isEmpty()) {
            throw new ApiRequestValidationException("Invalid Request :" + System.lineSeparator() + errorsCombined);
        }
    }

    public String validateMerchantKitJson(Object object,String absoluteFilePath) {
        InputStream schemaAsStream = null;
        try {
            schemaAsStream = new BufferedInputStream(new FileInputStream(absoluteFilePath));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        StringBuilder errorsCombined = new StringBuilder();;
        ObjectMapper om = new ObjectMapper();
        om.registerModule(new JavaTimeModule());
        om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,true);
        JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7).getSchema(schemaAsStream);
        JsonNode jsonNode = om.convertValue(object, JsonNode.class);
        if (jsonNode.isObject()) {
            ObjectNode objectNode = (ObjectNode) jsonNode;
            objectNode.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                JsonNode value = entry.getValue();
                if (value.isTextual() && value.asText().trim().isEmpty()) {
                    objectNode.putNull(key);
                }
            });
        }
        Set<ValidationMessage> errors = schema.validate(jsonNode);
        for (ValidationMessage error : errors) {
            errorsCombined.append(error.toString()).append(System.lineSeparator());
        }
        return errorsCombined.length() == 0 ? null : errorsCombined.toString();
    }


    public String processTxnDecline(TransactionMessageModel declineModel, String resCode, String resDesc, Exchange exchange) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        declineModel.setDrcrFlag("N");
        declineModel.setResCode(resCode);
        declineModel.setTlmMessageType(TlmMessageType.RESPONSE);
        String transactionName = declineModel.getTransactionName();
        declineModel.setTransactionName(transactionName.replace("request", "response"));
        TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(declineModel.getTransactionName(), declineModel.getTargetType(), routingContext.getSource().getName());
        declineModel.setMsgType(txnTypeConfig.getEpMsgType());
        processorHelper.logToTlm(declineModel, routingContext);
        logger.trace("Decline Transaction message model: {}", declineModel);

        return getEncryptedApiResponse(ResponseMsgType.ERROR, resDesc, declineModel, txnTypeConfig, exchange);
    }
    
    public String getPosApiResponse(String errorReason, Object resObj, TransactionTypeConfig txnTypeConfig) {
        ResponseObj responseObj = new ResponseObj();
        responseObj.setMsg(errorReason);

        Map<String, Object> dataMap = null;
        if (resObj != null) {
            TransactionMessageModel resTgtTmm = (TransactionMessageModel) resObj;
            try {
                dataMap = setResponseData(resTgtTmm, txnTypeConfig);
                dataMap.put("msgType", resTgtTmm.getMsgType());
                //responseJsonStr = IsgJsonUtils.getJsonString(dataMap);
            } catch (NoSuchAlgorithmException e) {
                logger.error("Response data failure: ", e);
            }
            responseObj.setStatusCode(resTgtTmm.getResCode());
        }
        responseObj.setData(dataMap);
        return IsgJsonUtils.getJsonString(responseObj);
    }
    

    public String getApiResponse(ResponseMsgType respMsgType, String errorReason, Object resObj) {
        ResponseObj responseObj = new ResponseObj();
        responseObj.setStatusCode(StringUtils.leftPad(String.valueOf(respMsgType.ordinal()), 2, "0"));
        responseObj.setMsg(errorReason);
        if (resObj instanceof HashMap) {
            Map<String, Object> resDataMap = new HashMap<>();
            resDataMap = (Map<String, Object>) resObj;
            ResponseObj responseObj1 = (ResponseObj) resDataMap.get("responseObj");
            if (responseObj1 != null && !responseObj1.getStatusCode().equals("00")) {
                responseObj.setStatusCode(responseObj1.getStatusCode());
                responseObj.setMsg(responseObj1.getMsg());
                responseObj.setRetryEvent(responseObj1.getRetryEvent());
                responseObj.setRedirectEvent(responseObj1.getRedirectEvent());
                responseObj.setData(responseObj1.getData());
                return IsgJsonUtils.getJsonString(responseObj);
            }
        }
        responseObj.setData(resObj);
        return IsgJsonUtils.getJsonString(responseObj);
    }

    public String getEncryptedApiResponse(ResponseMsgType respMsgType, String errorReason, Object resObj,
                                          TransactionTypeConfig txnTypeConfig, Exchange exchange) {
        ResponseObj responseObj = new ResponseObj();
        responseObj.setStatusCode(StringUtils.leftPad(String.valueOf(respMsgType.ordinal()), 2, "0"));
        responseObj.setMsg(errorReason);

        try {
            String responseJsonStr = null;
            Map<String, Object> map = new HashMap<>();
            if (resObj != null && txnTypeConfig != null) {
                if (resObj instanceof TransactionMessageModel) {
                    TransactionMessageModel resTgtTmm = (TransactionMessageModel) resObj;
                    Map<String, Object> dataMap = setResponseData(resTgtTmm, txnTypeConfig);
                    exchange.getIn().getHeaders().put("cval", dataMap.get("checksum"));
                    responseJsonStr = IsgJsonUtils.getJsonString(dataMap);
                }
            } else if (resObj != null) {
                responseJsonStr = IsgJsonUtils.getJsonString(resObj);
                exchange.getIn().getHeaders().put("cval", generateChecksum(responseJsonStr));
            }
            map.put("dval", aesEncrypt(responseJsonStr));
            responseObj.setData(map);
        } catch (NoSuchAlgorithmException e) {
            logger.error("Response data failure: ", e);
        }
        return IsgJsonUtils.getJsonString(responseObj);
    }

    public String getSmartRouteApiResponse(ResponseMsgType respMsgType, String errorReason, Object resObj, Exchange exchange) {
        ResponseObj responseObj = new ResponseObj();
        responseObj.setStatusCode(StringUtils.leftPad(String.valueOf(respMsgType.ordinal()), 2, "0"));
        responseObj.setMsg(errorReason);
        Map<String, Object> map = new HashMap<>();
        map.put("dval", (String)resObj);
        responseObj.setData(map);
        return IsgJsonUtils.getJsonString(responseObj);
    }

    public ApiTxnModel decryptAndValidateSmartRouteRequest(String decryptReq, Exchange exchange) {
        ApiTxnModel apiTxnModel;
        try {
            apiTxnModel = IsgJsonUtils.getObjectFromJsonString(decryptReq, ApiTxnModel.class);
            apiTxnModel.setCval((String) exchange.getIn().getHeader("cval"));
//            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
//            String epId = routingContext.getSource().getName();
//            Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
//            MessageFormatConfigModel msgFormatConfigModel = msgFormatMap.get(apiTxnModel.getMsgType());
//            if (msgFormatConfigModel != null) {
//                validateJson(msgFormatConfigModel, apiTxnModel);
//            }
            String generateChecksum = generateChecksum(decryptReq);
            if (!apiTxnModel.getCval().equals(generateChecksum)) {
                throw new RequestValidationException("Invalid Request :" + System.lineSeparator() + "$.checksum: is mismatched or invalid");
            }
            apiTxnModel.setEncryptionEnable("Y");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return apiTxnModel;
    }

    public String decryptSmartRouteReq(Exchange exchange) {
        String encodedSecretkey = (String) exchange.getIn().getHeader("secretkey");
        String encApiRequest = exchange.getIn().getBody(String.class);
        ApiTxnModel encryptedReq = IsgJsonUtils.getObjectFromJsonString(encApiRequest, ApiTxnModel.class);
        String decryptedSecretKey = aesDecrypt(encodedSecretkey, "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=");
        String decryptReq = aesDecrypt(encryptedReq.getDval(), decryptedSecretKey);
        return decryptReq;
    }

    public String getSmartRouteEncApiResponse(Exchange exchange, String resJson) throws NoSuchAlgorithmException {
        SecretKey secretKey = generateSecretKey();
        String encodedSecretKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
        //logger.trace("Encoded Secret Key: {}", encodedSecretKey);

        String encApiResponse = aesEncrypt(resJson, encodedSecretKey);
        //logger.trace("Encrypted API Response: {}", encApiResponse);

        String encSecretKey = aesEncrypt(encodedSecretKey, "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=");
        //logger.trace("Encrypted Secret Key: {}", encSecretKey);

        String checksum = generateChecksum(resJson);
        exchange.getIn().getHeaders().put("cval", checksum);

        exchange.getIn().getHeaders().put("secretkey", encSecretKey);
        return encApiResponse;
    }

    public static Map<String, Object> setResponseData(TransactionMessageModel tmmModel, TransactionTypeConfig txnTypeConfig) throws NoSuchAlgorithmException {
        Map<Integer, String> integerStringMap;

        if (tmmModel.getTransactionName().startsWith("decline")) {
            DeclineMessageTransformation declineMsgTrans = new DeclineMessageTransformation();
            integerStringMap = declineMsgTrans.getTmmConfig().get(txnTypeConfig);
        } else if (tmmModel.getTransactionName().startsWith("pg")) {
            PgMessageTransformation pgMsgTransformation = new PgMessageTransformation();
            integerStringMap = pgMsgTransformation.getTmmConfig().get(txnTypeConfig);
        } else {
            PosMessageTransformation posMessageTransformation = new PosMessageTransformation();
            integerStringMap = posMessageTransformation.getTmmConfig().get(txnTypeConfig);

        }
        Map<String, Object> map = new HashMap<>();
        ITmmParser parser = ParserFactory.getParser(MessageFormat.PG_PIPE_STRING);

        integerStringMap.forEach((deNo, methodName) -> {
            String data = ((BaseTmmParser) parser).getData(tmmModel, methodName);
            String firstChar = String.valueOf(methodName.substring(3).charAt(0)).toLowerCase();
            map.put(firstChar + methodName.substring(4), data);
        });
        if (!SourceProcessor.POS_SWITCH.name().equals(tmmModel.getSourceProcessor().name())) {
            String checksum = generateChecksum(map.toString());
            map.put("checksum", checksum);
        }

        return map;
    }

    public static String generateChecksum(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return DatatypeConverter.printHexBinary(md.digest(data.getBytes()));
    }

    public void updateDrCrFlag(TransactionMessageModel tmm) {
        String msgTypeId = tmm.getProcessingCode();
        String msgType = tmm.getMsgType();
        if (isReversalRequest(msgType) || isAllSchemeReversalRes(msgType)
                || CybsMsgTypeHelper.isCybsReversal(msgType) || CybsMsgTypeHelper.isReversalTimeout(msgType)) {
            tmm.setDrcrFlag("R");
        } else if (PgMsgTypeHelper.isOnlineOfflineRefund(msgType, msgTypeId)) {
            tmm.setDrcrFlag("C");
        } else if (PgMsgTypeHelper.isPreAuth(msgType, msgTypeId)) {
            tmm.setDrcrFlag("N");
        } else {
            tmm.setDrcrFlag("D");
        }
    }

    public String aesEncrypt(String pgResponse) {
        Cipher cipher;
        String encryptedResponse = "";
        try {
            cipher = SpringContextBridge.getCipherInstance();

            //TODO: using hardcoded secret key for now
            String secretKey = "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=";

            byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
            GCMParameterSpec parameterSpec = new GCMParameterSpec(128, decodeKey, 0, decodeKey.length);
            SecretKey key1 = new SecretKeySpec(decodeKey, 0, decodeKey.length, "AES");

            cipher.init(Cipher.ENCRYPT_MODE, key1, parameterSpec);

            encryptedResponse = Base64.getEncoder().encodeToString(cipher.doFinal(pgResponse.getBytes()));

        } catch (InvalidKeyException | IllegalBlockSizeException |
                BadPaddingException | InvalidAlgorithmParameterException e) {
            logger.error("Error in encrypting data: ", e);
        }
        return encryptedResponse;
    }

    public String aesEncrypt(String data, String secretKey) {
        Cipher cipher;
        String encryptedResponse = "";
        try {
            cipher = Cipher.getInstance("AES");
            byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
            SecretKey key1 = new SecretKeySpec(decodeKey, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, key1);
            encryptedResponse = Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException |
                NoSuchAlgorithmException | NoSuchPaddingException e) {
            logger.error("Error in encrypting data: ", e);
        }
        return encryptedResponse;
    }

    public static String aesDecrypt(String data, String secretKey) {
        Cipher cipher;
        String decryptedResponse = "";
        try {
            cipher = Cipher.getInstance("AES");
            byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
            SecretKey key1 = new SecretKeySpec(decodeKey, "AES");
            cipher.init(Cipher.DECRYPT_MODE, key1);
            byte[] decode = Base64.getDecoder().decode(data.getBytes());
            decryptedResponse = new String(cipher.doFinal(decode));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException |
                NoSuchAlgorithmException | NoSuchPaddingException e) {
            System.out.println("Error in encrypting data: " + e);
        }
        return decryptedResponse;
    }

    public void setApiHeader(Exchange exchange) {
        EncryptService encryptService = SpringContextBridge.services().getEncryptionService();
        SecretKey key1 = getSecretKey();

        exchange.getIn().setHeader("secretkey", encryptService.encrypt(Base64.getEncoder().encodeToString(key1.getEncoded())));
    }

    private static SecretKey getSecretKey() {
        String secretKey = "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=";

        byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
//        GCMParameterSpec parameterSpec = new GCMParameterSpec(128, decodeKey, 0, decodeKey.length);
        SecretKey key1 = new SecretKeySpec(decodeKey, 0, decodeKey.length, "AES");
        return key1;
    }

    public SecretKey generateSecretKey() {
        KeyGenerator keyGenerator;
        SecretKey key = null;
        try {
            keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            key = keyGenerator.generateKey();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return key;
    }

//    public Boolean sendCallBackAck(UpiCallbackRequest upiCallbackRequest) throws JAXBException {
//        UpiCallbackAck upiCallbackAck = new UpiCallbackAck();
//        UpiCallbackAck.Notification notification = new UpiCallbackAck.Notification();
//        Object res = null;
//        try {
//            logger.info("Calling Callback ACK Api For Seq No : {} ", upiCallbackRequest.getOriginalTxnId());
//            upiCallbackAck.setActCode("00");
//            upiCallbackAck.setMessageType("1210");
//            notification.setNotificationId(upiCallbackRequest.getNotificationId());
//            upiCallbackAck.setNotification(notification);
//            upiCallbackAck.setProcCode(upiCallbackRequest.getProcCode());
//
//            String targetUrl = MTMProperties.getProperty("upi.callback.url");
//
//            Map<String, String> headers = new HashMap<>();
//            headers.put("Content-Type", "application/xml");
//
//            String payload = IsgXmlUtils.convertObjectToXml(upiCallbackAck, UpiCallbackAck.class);
//
//            IciciMessageTransformation iciciMessageTransformation = new IciciMessageTransformation();
//            res = iciciMessageTransformation.callApiUsingWebClient(payload, targetUrl, headers);
//        } catch (Exception e) {
//            logger.info("Exception while Calling Callback ACK Api : {} ", e.getMessage());
//        }
//        if (res != null) {
//            String[] split = res.toString().split(API_RESPONSE_SEPARATOR);
//            if (Integer.parseInt(split[0]) == HttpStatus.OK.value()) {
//                return true;
//            }
//        }
//        return false;
//    }


    public String sendCallBackAck(UpiCallbackRequest upiCallbackRequest) throws JAXBException {
        UpiCallbackAck upiCallbackAck = new UpiCallbackAck();
        UpiCallbackAck.Notification notification = new UpiCallbackAck.Notification();
        upiCallbackAck.setActCode("0");
        upiCallbackAck.setMessageType("1210");
        notification.setNotificationId(upiCallbackRequest.getNotificationId());
        upiCallbackAck.setNotification(notification);
        upiCallbackAck.setProcCode(upiCallbackRequest.getProcCode());
        String payload = IsgXmlUtils.convertObjectToXml(upiCallbackAck, UpiCallbackAck.class);
        return payload;
    }


    public  OffsetDateTime trimGmtDate(String input) {
        OffsetDateTime output = null;
        if (input != null && !input.equals("")) {
            try {
                ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(0, 0);
                OffsetDateTime parse = OffsetDateTime.parse(input.trim(), DateTimeFormatter.ISO_DATE_TIME);
                return parse.withOffsetSameInstant(gmtOffset);
            } catch (Exception ex) {
                logger.trace(ex.getMessage(), ex);
            }
        }
        return output;
    }

}