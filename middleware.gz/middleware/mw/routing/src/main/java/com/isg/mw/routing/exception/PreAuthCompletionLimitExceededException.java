package com.isg.mw.routing.exception;

/**
 * 
 * @author shital3986
 *
 */
public class PreAuthCompletionLimitExceededException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PreAuthCompletionLimitExceededException(String errorMsg) {
		super(errorMsg);
	}

	public PreAuthCompletionLimitExceededException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}

}
