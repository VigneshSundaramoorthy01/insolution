package com.isg.mw.routing.route;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.InvalidTxnAmtException;
import com.isg.mw.mtm.exception.InvalidTxnException;
import com.isg.mw.mtm.exception.SystemErrorException;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.context.RoutingInitializationContext;
import com.isg.mw.routing.exception.*;
import com.isg.mw.routing.route.pgswitch.ApiTransactionProcessor;
import com.isg.mw.routing.util.RouteUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import org.apache.camel.Exchange;
import org.apache.camel.component.netty.NettyConstants;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.component.netty.http.NettyHttpEndpoint;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isOfflineRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isPreAuthCompletionRequest;
import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchTerminalBatchDetails;
import static com.isg.mw.mtm.transform.MessageTransformer.constructMessage;
import static com.isg.mw.mtm.transform.TmmConstants.*;
import static com.isg.mw.routing.config.RoutingConstants.*;
import static com.isg.mw.mtm.transform.MessageTransformer.identifyTargetTxnTypeConfig;

@Component
@PropertySource("${spring.config.location}routing-config.properties")
public class PosSwitchTransactionProcessor implements ITransactionProcessor {

	private final Logger logger = LogManager.getLogger(getClass());

	@Value("${target.timeout.auto.reversal:true}")
	private boolean timeOutAutoReversal;


	@Autowired
	private SwitchRouter switchRouterService;

	@Autowired
	private CacheServices cacheService;

	@Autowired
	private TransactionProcessorHelper processorHelper;

	@Autowired
	private ApiTransactionProcessor apiTransactionProcessor;

	@Autowired
	private NetworkManagement networkManagement;

	@Override
	public void processTxnRequest(Exchange exchange) {
		try {
			RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
			String entityId = routingContext.getEntityId();
			String txnId = processorHelper.generateTransactionId();

			logger.info(LogUtils.buildLogMessage(entityId, routingContext.getSource().getName(), null, txnId, "Transaction received"));
			byte[] srcRawMsg = null;
			if (exchange.getFromEndpoint() instanceof NettyHttpEndpoint) {
				String body = exchange.getIn().getBody(String.class);

				srcRawMsg = MessageTransformer.parseAndCreateISO(body);
			} else {
				srcRawMsg = (byte[]) exchange.getIn().getBody();
			}

			TxnLogger.logRawMsg(MsgFlow.INBOUND, srcRawMsg);

			if (srcRawMsg.length == 0) {
				throw new InvalidMessageException("Request message is empty");
			}

			TransactionMessageModel reqSrcTmm = MessageTransformer.toPojo(entityId, OffsetDateTime.now(), routingContext.getSource().getName(),
					srcRawMsg, TlmMessageType.REQUEST, null);
			reqSrcTmm.setRawRequest(TxnLogger.encryptRawMsg(srcRawMsg));

			String acpTraceId = reqSrcTmm.getCardAcceptorId() + reqSrcTmm.getCardAcceptorTerminalId() + reqSrcTmm.getStan();
			reqSrcTmm.setAcpTraceId(acpTraceId);

			setLoggerContext(reqSrcTmm);

			reqSrcTmm.setEpType(EpType.SOURCE);
			reqSrcTmm.setTransactionId(txnId);
			reqSrcTmm.setRawRequest(TxnLogger.encryptRawMsg(srcRawMsg));
			reqSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
			reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
			reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
					"Transaction type: " + reqSrcTmm.getTransactionName()
							+ ", TStan: " + reqSrcTmm.getTerminalStan()
							+ ", MID: " + reqSrcTmm.getCardAcceptorId()
							+ ", TID: " + reqSrcTmm.getCardAcceptorTerminalId()));

			logger.debug("Request Source Transaction Message Model: {}", reqSrcTmm);
			exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);

			processorHelper.checkForDuplicateTxn(exchange);

			processorHelper.validTxnType(reqSrcTmm);

			processorHelper.checkForMandatoryFields(reqSrcTmm);

			boolean validateMerchant = true;
			if (SIGN_ON_REQUEST.equals(reqSrcTmm.getMsgType())
					&& (reqSrcTmm.getCardAcceptorId() == null
					|| reqSrcTmm.getCardAcceptorTerminalId() == null)) {
				validateMerchant = false;
			}
			MapsInfoModel mapsInfoModel = null;
			if (validateMerchant)
				mapsInfoModel = processorHelper.validateMerchant(routingContext, reqSrcTmm);
			reqSrcTmm.setFirstName(mapsInfoModel.getMerchantName());
			reqSrcTmm.setCity(mapsInfoModel.getMerchantCity());
			reqSrcTmm.setMerchantCountryCode(mapsInfoModel.getMerchantShortCountryCode());

			logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
					reqSrcTmm.getTransactionName(), "Merchant validated: " + reqSrcTmm.getCardAcceptorId()));

			if (DCC_RATE_LOOKUP_MSG_TYPE.equals(reqSrcTmm.getMsgType())) {
				processorHelper.validateBinFromBillingCurrencies(routingContext, reqSrcTmm);
			} else if (!(SIGN_ON_REQUEST.equals(reqSrcTmm.getMsgType())
					|| BATCH_SETTLEMENT_REQUEST.equals(reqSrcTmm.getMsgType()))) {

				MessageTransformer.decryptTrackData(reqSrcTmm);

				processorHelper.validateBin(routingContext, reqSrcTmm);
				logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
						reqSrcTmm.getTransactionName(), "Bin validated"));
			}

			if (MessageConstructionHelper.isCashAtPos(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {

				validateCashAtPosTransaction(mapsInfoModel, reqSrcTmm);
			}


			if (TmmConstants.isOriginalTxnRequired(reqSrcTmm.getTransactionName())) {
				reqSrcTmm.setOriginalTmm(fetchOriginalTransaction(reqSrcTmm));
				if (reqSrcTmm.getOriginalTmm() != null) {
					reqSrcTmm.setSchemeStan(reqSrcTmm.getOriginalTmm().getSchemeStan());
					reqSrcTmm.setHostBatchNo(reqSrcTmm.getOriginalTmm().getHostBatchNo());
					reqSrcTmm.setBatchStatus(reqSrcTmm.getOriginalTmm().getBatchStatus());
					reqSrcTmm.setAuthIdRes(reqSrcTmm.getOriginalTmm().getAuthIdRes());

					if (MessageConstructionHelper.isPreAuthCompletionRequest(reqSrcTmm.getMsgType(),
							reqSrcTmm.getProcessingCode())) {
						reqSrcTmm.setServiceRestrictionCode(reqSrcTmm.getOriginalTmm().getServiceRestrictionCode());
						reqSrcTmm.setCiad(reqSrcTmm.getOriginalTmm().getCiad());
						validatePreAuthCompletionTransaction(exchange, reqSrcTmm);
					}
				}
			}

			if (MessageConstructionHelper.isPosRefundReq(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode()) && mapsInfoModel != null  && ActiveInactiveFlag.Active.equals(mapsInfoModel.getPosRefundStatus())) {
				logger.info("Refund Validation :: {}, Message Type ::{}, ProcessingCode :: {}", mapsInfoModel.getPosRefundStatus(), reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode() );
				reqSrcTmm.setOriginalTmm(fetchOriginalTransaction(reqSrcTmm));
				validatePosRefundTransaction(mapsInfoModel, reqSrcTmm);
			}

			if (!(SIGN_ON_REQUEST.equals(reqSrcTmm.getMsgType())
					|| BATCH_SETTLEMENT_REQUEST.equals(reqSrcTmm.getMsgType())
					|| DCC_RATE_LOOKUP_MSG_TYPE.equals(reqSrcTmm.getMsgType()))) {
				TargetConfigModel targetConfigModel = switchRouterService.getTargetEndpoint(routingContext, exchange,
						reqSrcTmm);
				processorHelper.enrichMerchantData(reqSrcTmm, targetConfigModel);
				logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
						reqSrcTmm.getTransactionName(), "Merchant data enriched"));
			}
			processorHelper.logToTlm(reqSrcTmm, routingContext);

			//writeRawMsgToFile(srcRawMsg, reqSrcTmm, routingContext.isDebug());

			if (reqSrcTmm.getDrcrFlag() != null
					&& (reqSrcTmm.getDrcrFlag().equals("V") || reqSrcTmm.getDrcrFlag().equals("R"))) {
				processorHelper.processVoidOrReversal(exchange, reqSrcTmm);
			} else {
				if (TmmConstants.isPosSwitchTxn(reqSrcTmm.getTransactionName())) {
					/*
					 * The transactions are processed by Switch and its not being sent to Schemes
					 * Like: Pos Sign on, Batch, TIP Adjust Refer: TmmConstants.posSwitchTxns for
					 * full list of txns
					 */
					processPosSwitchTxn(exchange, reqSrcTmm);
				} else {
					processorHelper.processNormalTxn(exchange, reqSrcTmm);
				}
			}
		} catch (Exception e) {
			// TODO: use LogUtils.buildLogMsg (21/8 - To create seperate issue on loggers
			// and take it up)
			throw new RequestProcessingException("Error while processing the request message ", e);
		}
	}

	void processPosSwitchTxn(Exchange exchange, TransactionMessageModel reqSrcTmm) {
		RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_ROUTING_CTX);
		if (TmmConstants.isPosSwitchTipAdjustTxn(reqSrcTmm.getTransactionName())) {
			processTipAdjustTxn(reqSrcTmm, routingContext);
		} else if (TmmConstants.isPosSwitchDccRateLookupTxn(reqSrcTmm.getTransactionName())) {
			processDccRateLookupTxn(reqSrcTmm, routingContext);
		}

		if(SIGN_ON_REQUEST.equals(reqSrcTmm.getMsgType())
				&& reqSrcTmm.getNetworkLink() != null) {
			initiateNetworkMsgAndUpdateStatus(reqSrcTmm, routingContext);
		}
		if(MessageConstructionHelper.isPosTerminalInit(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
			TransactionMessageModel terminalBatchDetails = fetchTerminalBatchDetails(reqSrcTmm);
			if (terminalBatchDetails != null && terminalBatchDetails.getResCode().equals("00")) {
				if (terminalBatchDetails.getBatchStatus().equals("1")) {
					setTerminalInitialzaTionDetails(reqSrcTmm, terminalBatchDetails);
				} else {
					reqSrcTmm.setResCode(TmmConstants.RES_CODE_TERMINAL_BATCH_UNSETTLED);
				}
			} else {
				reqSrcTmm.setTerminalBatchNo("000000");
			}
		}

		exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
		TransactionMessageModel reqTmm = SerializationUtils.clone(reqSrcTmm);
		// pan is transient field, hence not getting copied while cloning.
		reqTmm.setPan(reqSrcTmm.getPan());
		exchange.getIn().setBody(reqTmm);
	}

	private void setTerminalInitialzaTionDetails (TransactionMessageModel reqSrcTmm, TransactionMessageModel terminalBatchDetails) {
		reqSrcTmm.setTerminalBatchNo(terminalBatchDetails.getTerminalBatchNo());
		reqSrcTmm.setBatchStatus(terminalBatchDetails.getBatchStatus());
		reqSrcTmm.setEntityId(terminalBatchDetails.getEntityId());
		reqSrcTmm.setHostBatchNo(terminalBatchDetails.getHostBatchNo());
		reqSrcTmm.setBatchSettlementDate(terminalBatchDetails.getBatchSettlementDate());
	}

	private void initiateNetworkMsgAndUpdateStatus(TransactionMessageModel reqSrcTmm, RoutingContext routingContext) {
		String[] networkIndicators = reqSrcTmm.getNetworkLink().split("--");
		Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext
				.getTargetEndpointInfoMap();
		Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap
				.get(routingContext.getEntityId());
		Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> targetEpEntries = RoutingInitializationContext.getTargetEndpointInfoMap().entrySet();
		endpointInfoMap.forEach((targetIp, endpointInfo) -> {
			if (endpointInfo.getEpName().equals(networkIndicators[0])) {
				if (networkIndicators[1].equals("SIGNOFF")) {
					networkManagement.initiateRequest(TransactionCategory.SIGNOFF, targetIp, endpointInfo, routingContext);
					SpringContextBridge.services().getCacheService().putSignOffStatus(true, endpointInfo.getEpName());
					RouteUtil.updateEndPointSignOnStatusByEpName(targetEpEntries, endpointInfo.getEpName().substring(0, endpointInfo.getEpName().length() -1), false);
				} else {
					networkManagement.initiateRequest(TransactionCategory.SIGNON, targetIp, endpointInfo, routingContext);
				}

			}
		});
	}

	private void processTipAdjustTxn(TransactionMessageModel reqSrcTmm, RoutingContext routingContext) {
		TransactionMessageModel originalTmm = reqSrcTmm.getOriginalTmm();
		if (originalTmm == null) {
			reqSrcTmm.setResCode(TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_PRESENT);
		} else if (!reqSrcTmm.getTerminalData().equals(originalTmm.getTxnAmt())) {
			reqSrcTmm.setResCode(TmmConstants.RES_CODE_INVALID_TXN_AMT);
		} else {
			/*
			 * If the originalTmm is not null and txnAmt of originalTmm matches the
			 * terminalData, then the check whether it is offlineRequest if it is
			 * offlineRequest then set the resCode as '00' in reqSrcTmm and also in
			 * originalTmm set the resCode as '00' And log the originalTmm to TLM. else
			 * directly log the originalTmm to TLM.
			 */
			if (isOfflineRequest(originalTmm.getMsgType(), originalTmm.getProcessingCode())
					&& originalTmm.getResCode().equals(TmmConstants.RES_CODE_OFFLINE_SALE)) {
				reqSrcTmm.setResCode(TmmConstants.RES_CODE_SUCCESS);
				originalTmm.setResCode(TmmConstants.RES_CODE_SUCCESS);
			}
			originalTmm.setTxnAmt(reqSrcTmm.getTxnAmt());
			originalTmm.setAdditionalAmounts(reqSrcTmm.getAdditionalAmounts());
			originalTmm.setTransactionName(reqSrcTmm.getTransactionName());
			processorHelper.synchronizedLogToTlm(originalTmm, routingContext, true);
		}
	}

	private void processDccRateLookupTxn(TransactionMessageModel reqSrcTmm, RoutingContext routingContext) {
		if (TmmConstants.DCC_INDICATOR_INACTIVE.equals(reqSrcTmm.getDccIndicator())) {
			reqSrcTmm.setResCode(TmmConstants.RES_CODE_INVALID_TXN);
		} else {
			reqSrcTmm.setResCode(TmmConstants.RES_CODE_SUCCESS);
		}
		processorHelper.synchronizedLogToTlm(reqSrcTmm, routingContext, true);
	}

	@Override
	public void processTxnResponse(Exchange exchange) {
		RoutingContext routingContext = null;
		Object requestDeclined = exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQUEST_DECLINED);
		if (processorHelper.isRequestDeclined(requestDeclined)) return;

		TransactionMessageModel responseSourceTmm = exchange.getIn().getBody(TransactionMessageModel.class);
		TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_SRC_TMM);

		logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(), responseSourceTmm.getMsgType(),
				responseSourceTmm.getTransactionId(), responseSourceTmm.getTransactionName(), "Transaction response received"));
		try {
			routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

			processorHelper.checkForMandatoryFields(responseSourceTmm);

			String targetScheme = null;

			if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(responseSourceTmm.getTargetType().name())){
				targetScheme = TmmConstants.EFTPOS_SCHEME_TYPE;
			} else if (!DCC_RATE_LOOKUP_MSG_TYPE.equals(reqSrcTmm.getMsgType())) {
				targetScheme = cacheService.getSchemeName(reqSrcTmm.getPan());
			}

			logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(), responseSourceTmm.getMsgType(),
					responseSourceTmm.getTransactionId(), responseSourceTmm.getTransactionName(), "Constructing transaction response for target"), reqSrcTmm.getSource());
			responseSourceTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());

			ConnectionType connectionType = routingContext.getSource().getConnectionType();

			MessageContext targetMsgContext = MessageTransformer.constructMessage(responseSourceTmm,
					routingContext.getSource().getName());
			byte[] targetRawMsg = (byte[]) targetMsgContext.getRawMsg();

			TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();

			//Eftpos changes for settlement logic
			if(responseSourceTmm.getTargetType().equals(TargetType.EftPos)){
				responseTargetTmm.setTargetType(TargetType.EftPos);
			}

			responseTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
			responseTargetTmm.setResponseSentTime(OffsetDateTime.now());
			responseTargetTmm.setAcpTraceId(reqSrcTmm.getAcpTraceId());

			logger.trace("Response Target Transaction message model: {}", responseTargetTmm);

			responseTargetTmm.setEpType(EpType.TARGET);

			if ((TmmConstants.RES_CODE_SUCCESS.equals(responseTargetTmm.getResCode())
					|| TmmConstants.RES_CODE_AMT_VERFICATION.equals(responseTargetTmm.getResCode()))
					&& TmmConstants.isOriginalTxnRequired(reqSrcTmm.getTransactionName())) {
				processorHelper.updateOriginalTxnAndLogTlm(reqSrcTmm.getOriginalTmm(), reqSrcTmm.getDrcrFlag(), routingContext);
				responseTargetTmm.setHostBatchNo(reqSrcTmm.getOriginalTmm().getHostBatchNo());
				responseTargetTmm.setBatchStatus(reqSrcTmm.getOriginalTmm().getBatchStatus());
			}

			if (isPreAuthCompletionRequest(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
					|| isOfflineRequest(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
					|| (reqSrcTmm.getOriginalTmm() != null
					&& (isPreAuthCompletionRequest(reqSrcTmm.getOriginalTmm().getMsgType(),
					reqSrcTmm.getOriginalTmm().getProcessingCode())
					|| isOfflineRequest(reqSrcTmm.getOriginalTmm().getMsgType(),
					reqSrcTmm.getOriginalTmm().getProcessingCode())))) {
				logger.trace("Response Scheme Type: {}", responseTargetTmm.getTargetType());
				responseTargetTmm.setTargetType(TargetType.getTargetType(targetScheme));
				logger.trace("Response Scheme Type: {}", responseTargetTmm.getTargetType());
			}

			if(!(responseTargetTmm.getMsgType().equalsIgnoreCase("0810") || responseTargetTmm.getMsgType().equalsIgnoreCase("0830"))) {
				processorHelper.logToTlm(responseTargetTmm, routingContext);
			}

			TxnLogger.logRawMsg(MsgFlow.OUTBOUND, targetRawMsg, responseTargetTmm);

			ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(targetRawMsg);

			if (connectionType == ConnectionType.ISO) {
				Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);
				openedChannel.writeAndFlush(rawMsgByteBuf);
			} else if (connectionType == ConnectionType.API) {
				// removing custom headers set during transaction flow while sending response
				TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(responseTargetTmm.getTransactionName(), responseTargetTmm.getTargetType(), routingContext.getSource().getName());
				String msg = "";
				if (RES_CODE_SUCCESS.equals(responseTargetTmm.getResCode())) {
					msg = "Success";
				} else {
					msg = "Failure";
				}
				String bitMap = ISOUtil.byte2hex(targetRawMsg).substring(18,34);
				targetMsgContext.getApiTmm().setBitMap(bitMap);
				String posResponse= apiTransactionProcessor.getPosApiResponse(msg, targetMsgContext.getApiTmm(), txnTypeConfig);
				processorHelper.removeCustomHeaders(exchange);
				exchange.getIn().setBody(posResponse);
			}

			logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(), responseSourceTmm.getMsgType(),
					responseSourceTmm.getTransactionId(), responseSourceTmm.getTransactionName(), "Transaction response sent to target"), reqSrcTmm.getSource());

			if ((TargetType.Master).toString().equals(targetScheme)
					&& (isPreAuthCompletionRequest(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode()))
					&& (Double.valueOf(reqSrcTmm.getTxnAmt())
					.compareTo(Double.valueOf(reqSrcTmm.getOriginalTmm().getTxnAmt())) < 0)) {

				reqSrcTmm.setTargetType(TargetType.getTargetType(targetScheme));
				initiateReversalTxn(reqSrcTmm, exchange);
			}
		} catch (Exception e) {
			throw new ResponseProcessingException("Error while processing the response message: ", e);
		} finally {
			reqSrcTmm.setPan(null);
			reqSrcTmm.setTrack2Data(null);
			responseSourceTmm = null;

			reqSrcTmm = null;
		}
	}

	@Override
	public void processTxnDecline(Exchange exchange) {

		Throwable exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class).getCause();
		TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_SRC_TMM);
		RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
		TransactionMessageModel declineModel = new TransactionMessageModel();
		declineModel.setAcpTraceId(reqSrcTmm.getAcpTraceId());

		logger.error("Exception :", exception);

		String resCode = null;
		String resDesc = null;

		if (exception.getClass().getSimpleName().equals("TargetNoResponseException") || exception.getClass().getSimpleName().equals("IllegalAccessException")) {
			if (timeOutAutoReversal && TmmConstants.getTxnEligibleForAutoReversal().contains(reqSrcTmm.getTransactionName())) {
				String targetScheme = exchange.getIn().getHeaders().get(EXCHANGE_HEADER_TARGET_SCHEME).toString();
				//Added for the POS Amex timeout reversal case
				TargetConfigModel tgtEndPoint = switchRouterService.getTargetEndpoint(routingContext, exchange, reqSrcTmm);
				ConnectionType targetConnectionType = tgtEndPoint.getConnections().get(0).getType();
				String txnName = TmmConstants.REVERSAL_REQUEST;

				ExecutorService executorService = RouteUtil.getExecutorService();
				TransactionMessageModel reqTgtTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_TGT_TMM);
				//Added to handle the POS Amex timeout reversal case
				executorService.submit(() -> {
					String targetIpAndPort = null;
					if (ConnectionType.API.name().equals(targetConnectionType.name())) {
						targetIpAndPort = tgtEndPoint.getConnections().get(0).getUrlOrIp();
						reqTgtTmm.setTargetIpAndPort(targetIpAndPort);
						reqSrcTmm.setTargetIpAndPort(targetIpAndPort);
						processorHelper.generateAutoReversalTxn(reqSrcTmm, reqTgtTmm, SourceProcessor.POS_SWITCH, txnName, exchange, true);
					} else if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(reqTgtTmm.getTargetType().name())) {
						targetIpAndPort = RouteUtil.fetchIpAndPort(targetScheme);
						reqTgtTmm.setTargetIpAndPort(targetIpAndPort);
						reqSrcTmm.setTargetIpAndPort(targetIpAndPort);

						boolean repeatReversalEnable = processorHelper.generateEftposAutoReversalTxn(reqTgtTmm, SourceProcessor.POS_SWITCH, txnName);
						/**
						 * No Response Received from Target (TimeOut).
						 */
						int count = 0;
						if (repeatReversalEnable == true) {
							do {
								targetIpAndPort = RouteUtil.fetchIpAndPort(targetScheme);
								reqTgtTmm.setTargetIpAndPort(targetIpAndPort);
								reqSrcTmm.setTargetIpAndPort(targetIpAndPort);
								repeatReversalEnable = processorHelper.generateRepeatReversalTxn(reqTgtTmm, SourceProcessor.POS_SWITCH, EFTPOS_REPEAT_REVERSAL_REQUEST);
								count ++;
							} while (repeatReversalEnable && count <3);
						}
					} else {
						targetIpAndPort = RouteUtil.fetchIpAndPort(targetScheme);
						reqTgtTmm.setTargetIpAndPort(targetIpAndPort);
						reqSrcTmm.setTargetIpAndPort(targetIpAndPort);
						processorHelper.generateAutoReversalTxn(reqTgtTmm, SourceProcessor.POS_SWITCH, txnName);
					}
				});
			} else {
				String targetScheme = exchange.getIn().getHeaders().get(EXCHANGE_HEADER_TARGET_SCHEME).toString();
				String txnName = TmmConstants.EFTPOS_REPEAT_ADVICE_REQUEST;
				ExecutorService executorService = RouteUtil.getExecutorService();
				TransactionMessageModel reqTgtTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_TGT_TMM);
				executorService.submit(() -> {
					if (TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(reqTgtTmm.getTargetType().name()) && reqTgtTmm.getMsgType().equals("0220")) {
						String targetIpAndPort = RouteUtil.fetchIpAndPort(targetScheme);
						reqTgtTmm.setTargetIpAndPort(targetIpAndPort);
						reqSrcTmm.setTargetIpAndPort(targetIpAndPort);

						boolean repeateAdviceEnable = processorHelper.generateRepeatAdviceTxn(reqTgtTmm, SourceProcessor.POS_SWITCH, txnName);
						// No Response Received from Target (TimeOut).

						int count = 0;
						if (repeateAdviceEnable == true) {
							do {
								targetIpAndPort = RouteUtil.fetchIpAndPort(targetScheme);
								reqTgtTmm.setTargetIpAndPort(targetIpAndPort);
								reqSrcTmm.setTargetIpAndPort(targetIpAndPort);
								repeateAdviceEnable = processorHelper.generateRepeatAdviceTxn(reqTgtTmm, SourceProcessor.POS_SWITCH, txnName);
								count++;
							} while (repeateAdviceEnable && count <3);
						}
					}
				});
			}
			return;
		}

		switch (exception.getClass().getSimpleName()) {
			case "InvalidMerchantException":
				resCode = TmmConstants.RES_CODE_INVALID_MERCHANT;
				resDesc = "Merchant is invalid";
				break;

			case "InvalidBinException":
			case "InvalidTxnException":
			case "PreAuthCompletionTimeExpiredException":
			case "PreAuthCompletionLimitExceededException":
				resCode = TmmConstants.RES_CODE_INVALID_TXN;
				resDesc = "Bin is not valid";
				break;

			case "FormatErrorException":
				resCode = TmmConstants.RES_CODE_MANDATORY_FIELD_NOT_PRESENT;
				resDesc = exception.getMessage();
				break;

			case "NullPointerException":
			case "InternalServerError":
			case "SystemErrorException":
			case "DuplicateTxnException":
				resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
				resDesc = exception.getMessage();
				break;

			case "InvalidCardNumberException":
				resCode = TmmConstants.RES_CODE_INVALID_CARD_NUMBER;
				resDesc = "Bin is not valid";
				break;

			case "ExecutionException":
			case "InterruptedException":
			case "IssuerUnavailableException":
				resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
				resDesc = exception.getMessage();
				changeSignOnStatus(exchange);
				break;

			case "InvalidVoidOrReversalDataException":
			case "NotFound":
				if ("R".equals(reqSrcTmm.getDrcrFlag())) {
					// Send success response to POS if original txn is not found.
					resCode = TmmConstants.RES_CODE_SUCCESS;
				} else {
					resCode = TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_PRESENT;
				}
				resDesc = "Transaction not found";
				break;

			case "InvalidTxnAmtException":
				resCode = TmmConstants.RES_CODE_INVALID_TXN_AMT;
				resDesc = "Amount is not valid";
				break;

			case "MacValidationException":
				resCode = TmmConstants.RES_CODE_INVALID_MAC;
				resDesc = "MAC is not valid";
				break;

			case "PosRefundTxnAmtException":
				resCode = TmmConstants.RES_CODE_INVALID_REFUND_AMT;
				resDesc = "Refund Amount not valid";
				break;

			case "PosRefundTxnCountException":
				resCode = TmmConstants.RES_CODE_INVALID_REFUND_COUNT;
				resDesc = "Refund Amount not valid";
				break;

			default:
				resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
				resDesc = exception.getMessage();
				break;
		}

		if (reqSrcTmm != null) {
			declineModel = reqSrcTmm;
			declineModel.setTransactionName("decline." + reqSrcTmm.getTransactionName());
		}

		declineModel.setResCode(resCode);
		declineModel.setTlmMessageType(TlmMessageType.RESPONSE);

		logger.trace("Decline Response Code: {}, Decline txn: {}", declineModel.getResCode(),
				declineModel.getTransactionName());

		declineModel.setSourceProcessor(routingContext.getSource().getSourceProcessor());
		MessageContext targetMsgContext = MessageTransformer.constructMessage(declineModel,
				reqSrcTmm.getSource());

		byte[] targetRawMsg = (byte[]) targetMsgContext.getRawMsg();

		TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();
		//setting drcr flag to N as txn is declined
		responseTargetTmm.setDrcrFlag("N");
		responseTargetTmm.setAcpTraceId(reqSrcTmm.getAcpTraceId());
		processorHelper.asyncLogToTlm(responseTargetTmm, routingContext);

		TxnLogger.logRawMsg(MsgFlow.OUTBOUND, targetRawMsg, responseTargetTmm);

		logger.trace("Decline Response Transaction message model: {}", responseTargetTmm);

		exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQUEST_DECLINED, true);

		ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(targetRawMsg);

		if (routingContext.getSource().getConnectionType() == ConnectionType.ISO) {
			Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);
			openedChannel.writeAndFlush(rawMsgByteBuf);
		} else if (routingContext.getSource().getConnectionType() == ConnectionType.API) {
			TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(responseTargetTmm.getTransactionName(), responseTargetTmm.getTargetType(), routingContext.getSource().getName());
			String resMsg= apiTransactionProcessor.getPosApiResponse(resDesc, targetMsgContext.getApiTmm(), txnTypeConfig);
			processorHelper.removeCustomHeaders(exchange);
			exchange.getIn().setBody(resMsg);
		}
	}

	private void changeSignOnStatus(Exchange exchange) {
		RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

		NettyEndpoint producerEndpoint = (NettyEndpoint) exchange.getIn().getHeaders()
				.get(EXCHANGE_HEADER_TARGET_SCHEME);
		Map<String, Map<String, RoutingInitializationContext.EndpointMetaData>> targetEndpointInfoMap = RoutingInitializationContext
				.getTargetEndpointInfoMap();
		Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = targetEndpointInfoMap
				.get(routingContext.getEntityId());
		endpointInfoMap.forEach((targetIp, endpointInfo) -> {
			if (producerEndpoint.getEndpointUri().contains(targetIp)) {
				endpointInfo.setSignedOn(false);
			}
		});
	}

	/*private void logRawMessageToTlm(byte[] sourceRawMsg, String txnId, RoutingContext routingContext) {
		if (routingContext.isTxnLoggingDebug()) {
			TransactionMessageModel rawTmm = new TransactionMessageModel();
			rawTmm.setTransactionId(txnId);
			rawTmm.setRawRequest(TxnLogger.encryptRawMsg(sourceRawMsg));
			processorHelper.logToTlm(rawTmm, routingContext);
		}
	}

	private void writeRawMsgToFile(byte[] tgtRawMsg, TransactionMessageModel tmm, boolean isDebug) {
		if (isDebug) {
			StringBuilder userDirectory = new StringBuilder();
			try {
				String tmpDir = "/tmp" + "/" + tmm.getEntityId() + "/" + tmm.getTargetType() + "/";
				userDirectory.append(tmpDir).append(tmm.getTlmMessageType()).append("_").append(tmm.getMsgType())
						.append("_").append(tmm.getProcessingCode()).append("_").append(tmm.getTransactionName())
						.append("_").append(tmm.getTransactionId());
				Files.createDirectories(Paths.get(tmpDir));
				Files.write(Paths.get(userDirectory.toString()), tgtRawMsg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}*/

	private void validatePreAuthCompletionTransaction(Exchange exchange, TransactionMessageModel preAuthComplTxnTmm) {
		RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
		OffsetDateTime requestReceivedTime = preAuthComplTxnTmm.getOriginalTmm().getRequestReceivedTime();
		OffsetDateTime now = OffsetDateTime.now();
		Integer currencyDecimals = preAuthComplTxnTmm.getOriginalTmm().getCurrencyDecimals();

		long days = ChronoUnit.DAYS.between(requestReceivedTime.toLocalDate(), now.toLocalDate());
		String preAuthTimePeriod = routingContext.getSource().getPreAuthTimePeriod();
		if (days > Long.parseLong(preAuthTimePeriod)) {
			throw new PreAuthCompletionTimeExpiredException(
					"PreAuthCompletion time period has been expired, Pre-Auth Date: " + requestReceivedTime
							+ ", Expected within " + preAuthTimePeriod + " days");
		} else {
			String preAuthPerLimit = routingContext.getSource().getPreAuthPerLimit();
			Double preAuthComplAmt = Double.valueOf(preAuthComplTxnTmm.getTxnAmt()) / currencyDecimals;
			Double originalTxnAmt = Double.valueOf(preAuthComplTxnTmm.getOriginalTmm().getTxnAmt()) / currencyDecimals;

			Double maxExpectedAmt = (originalTxnAmt * Double.valueOf(preAuthPerLimit) / 100);
			if (preAuthComplAmt.compareTo(maxExpectedAmt) > 0) {
				throw new PreAuthCompletionLimitExceededException(
						("PreAuthCompletion txn limit has been exceeded, expected: " + maxExpectedAmt + ", got: "
								+ preAuthComplAmt));
			}
		}

	}

	private void initiateReversalTxn(TransactionMessageModel preAuthComplTxnTmm, Exchange exchange) {
		RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
		TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQ_SRC_TMM);
		routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
		TargetConfigModel tgtEndPoint = switchRouterService.getTargetEndpoint(routingContext, exchange,
				reqSrcTmm.getPan());


		logger.info("Initializing Reversal Transaction for target: {}", tgtEndPoint);

		TransactionMessageModel reqTmm = new TransactionMessageModel();
		TransactionMessageModel originalTmm = preAuthComplTxnTmm.getOriginalTmm();
		reqTmm.setTransactionName(TmmConstants.REVERSAL_REQUEST);
		reqTmm.setTransactionId(processorHelper.generateTransactionId());
		reqTmm.setEntityId(reqSrcTmm.getEntityId());
		reqTmm.setTlmMessageType(TlmMessageType.REQUEST);
		reqTmm.setMsgType(REVERSAL_REQUEST_MTI);
		reqTmm.setBitMap(preAuthComplTxnTmm.getOriginalTmm().getBitMap());
		reqTmm.setPan(preAuthComplTxnTmm.getPan());
		reqTmm.setProcessingCode(preAuthComplTxnTmm.getOriginalTmm().getProcessingCode());
		reqTmm.setTransmissionTime(preAuthComplTxnTmm.getOriginalTmm().getTransmissionTime());
		reqTmm.setStan(preAuthComplTxnTmm.getOriginalTmm().getStan());
		reqTmm.setMerchantType(preAuthComplTxnTmm.getOriginalTmm().getMerchantType());
		reqTmm.setPosEntryMode(preAuthComplTxnTmm.getOriginalTmm().getPosEntryMode());
		reqTmm.setAquirerIdCode(preAuthComplTxnTmm.getOriginalTmm().getAquirerIdCode());
		reqTmm.setResCode(preAuthComplTxnTmm.getOriginalTmm().getResCode());
		reqTmm.setPrivateAd(preAuthComplTxnTmm.getOriginalTmm().getPrivateAd());
		reqTmm.setTxnCurrencyCode(preAuthComplTxnTmm.getOriginalTmm().getTxnCurrencyCode());
		reqTmm.setCiad(preAuthComplTxnTmm.getOriginalTmm().getCiad());
		reqTmm.setCardAcceptorId(preAuthComplTxnTmm.getOriginalTmm().getCardAcceptorId());
		reqTmm.setCardAcceptorTerminalId(preAuthComplTxnTmm.getOriginalTmm().getCardAcceptorTerminalId());
		reqTmm.setReserved127(preAuthComplTxnTmm.getOriginalTmm().getReserved127());
		Double calculatedTxnAmt = ((Double.valueOf(preAuthComplTxnTmm.getOriginalTmm().getTxnAmt()))
				- (Double.valueOf(preAuthComplTxnTmm.getTxnAmt())));
		reqTmm.setTxnAmt(MtmUtil.toISOAmt(calculatedTxnAmt));
		originalTmm.setTxnAmt(MtmUtil.toISOAmt(calculatedTxnAmt));
		reqTmm.setOriginalTmm(originalTmm);

		reqTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());
		MessageContext targetMsgContext = constructMessage(reqTmm, tgtEndPoint.getName());
		TransactionMessageModel reqTargetTmm = targetMsgContext.getTransactionMessageModel();
		NettyEndpoint producerEndpoint = (NettyEndpoint) exchange.getIn().getHeaders()
				.get(EXCHANGE_HEADER_TARGET_SCHEME);
		Object resMessage = null;

		//Co-Relation-ID- changes
		String correlationId = null;
		if(TmmConstants.EFTPOS_SCHEME_TYPE.equalsIgnoreCase(reqSrcTmm.getTargetType().name())){
			correlationId = reqSrcTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqSrcTmm.getCardAcceptorTerminalId()+TmmConstants.CORRELATION_ID_SEPARATOR + reqSrcTmm.getStan();
		} else {
			correlationId = reqSrcTmm.getAquirerIdCode() + TmmConstants.CORRELATION_ID_SEPARATOR + reqSrcTmm.getRetrievalRefNo();
		}

		reqTargetTmm.setAcpTraceId(preAuthComplTxnTmm.getAcpTraceId());

		processorHelper.logToTlm(reqTargetTmm, routingContext);
		logger.trace("Request Source Transaction message model: {}", reqTargetTmm);
		resMessage = RoutingInitializationContext.getMwProducer().sendMessage(targetMsgContext.getRawMsg(),
				correlationId, producerEndpoint);
		if (resMessage != null) {
			TransactionMessageModel resTmm = MessageTransformer.toResponsePojo(null, null, (byte[]) resMessage, reqTmm.getTransactionName());
			resTmm.setTransactionId(reqTmm.getTransactionId());
			resTmm.setAcpTraceId(preAuthComplTxnTmm.getAcpTraceId());

			logger.trace("Response Target Transaction message model: {}", resTmm);
			processorHelper.logToTlm(resTmm, routingContext);

			if (TmmConstants.RES_CODE_SUCCESS.equals(resTmm.getResCode()))
				logger.info("Reversal Transaction {} completed for target connection {}", reqTmm.getTransactionName(),
						producerEndpoint.getEndpointUri());
		}
	}


	private void validateCashAtPosTransaction(MapsInfoModel mapsInfoModel, TransactionMessageModel tmm) {

		if (ActiveInactiveFlag.Active.equals(mapsInfoModel.getCapStatus())) {
			Double capCityLimitAmt = Double.valueOf(mapsInfoModel.getCapCityLimit());
			Double capMerLimitAmt = Double.valueOf(mapsInfoModel.getCapMerLimit());
			Double cashBackAmt = null;
			if (MessageConstructionHelper.isSaleWithCashAtPosRequest(tmm.getMsgType(), tmm.getProcessingCode(), tmm.getTxnAmt(), tmm.getAdditionalAmounts())) {
				cashBackAmt = Double.valueOf(tmm.getAdditionalAmounts());
			} else {
				cashBackAmt = Double.valueOf(tmm.getTxnAmt());
			}

			logger.info("Cashback limit check TxnAmt: {} merLimitAmt: {} cityLimitAmt: {}", cashBackAmt, capMerLimitAmt,
					capCityLimitAmt);

			if (cashBackAmt.compareTo(capMerLimitAmt) > 0 || cashBackAmt.compareTo(capCityLimitAmt) > 0) {
				throw new InvalidTxnAmtException("Cashback limit has been exceeded");
			}
		} else {
			throw new InvalidTxnException("Invalid transaction for this City-Merchant entry.");
		}
	}


	private void validatePosRefundTransaction(MapsInfoModel mapsInfoModel, TransactionMessageModel tmm) {
		logger.info("Validating Pos Refund for the Entity: {}", tmm.getEntityId());

		Double defaultRefundAmtLimit = Double.valueOf(mapsInfoModel.getDefaultRefundAmountLimit());
		Long defaultRefundCountLimit = mapsInfoModel.getDefaultRefundCountLimit();
		Double tempRefundAmtLimit = Double.valueOf(mapsInfoModel.getTempRefundAmountLimit());
		Long tempRefundCountLimit = mapsInfoModel.getTempRefundCountLimit();

		Double refundAmt = null;
		refundAmt = Double.valueOf(tmm.getTxnAmt());

		OffsetDateTime requestReceivedTime = tmm.getRequestReceivedTime();
		String refundTimePeriod = mapsInfoModel.getTempRefundLimitExpiry();


		if (null != refundTimePeriod  && !refundTimePeriod.isEmpty() && isRefundWithinExpiryTimeLimit(refundTimePeriod, requestReceivedTime)) {
			logger.info("Refund limit check TxnAmt: {} tmpRefundAmtLimit: {} tmpRefundCountLimit: {}", refundAmt, tempRefundAmtLimit, tempRefundCountLimit);
			if (isTempRefundAmtLimit(tempRefundAmtLimit, tempRefundCountLimit)) {
				validateRefundAmtAndCountLimit(tmm, tempRefundAmtLimit, defaultRefundCountLimit);
			} else if (isTempRefundCountLimit(tempRefundAmtLimit, tempRefundCountLimit)) {
				validateRefundAmtAndCountLimit(tmm, defaultRefundAmtLimit, tempRefundCountLimit);
			} else if (isTempRefundCountLimit(tempRefundAmtLimit, tempRefundCountLimit)
					&& isTempRefundAmtLimit(tempRefundAmtLimit, tempRefundCountLimit)) {
				validateRefundAmtAndCountLimit(tmm, tempRefundAmtLimit, tempRefundCountLimit);
			}
		} else {
			logger.info("Refund limit check TxnAmt: {} defaultRefundAmtLimit: {} defaultRefundCountLimit: {}", refundAmt, defaultRefundAmtLimit, defaultRefundCountLimit);
			validateRefundAmtAndCountLimit(tmm, defaultRefundAmtLimit, defaultRefundCountLimit);
		}
	}

	private boolean isTempRefundCountLimit(Double tempRefundAmtLimit, Long tempRefundCountLimit) {
		return tempRefundAmtLimit == null || tempRefundAmtLimit.equals(0)
				&& (tempRefundCountLimit != null && !tempRefundCountLimit.equals(0));
	}

	private boolean isTempRefundAmtLimit(Double tempRefundAmtLimit, Long tempRefundCountLimit) {
		return tempRefundAmtLimit != null && !tempRefundAmtLimit.equals(0)
				&& tempRefundCountLimit == null || tempRefundCountLimit.equals(0);
	}

	private boolean isRefundWithinExpiryTimeLimit(String tmpRefundStartTime, OffsetDateTime requestReceivedTime) {
		boolean isRefundWithinExpiryLimit = false;
		try {
			Date start = null;
			SimpleDateFormat format = new  SimpleDateFormat("hh:mm");

			start = format.parse(tmpRefundStartTime);

			LocalTime startTime = convertToOffsetDateTime(start);

			LocalTime endTime = startTime.plusMinutes(15);
			System.out.println(endTime);
			if(requestReceivedTime.toLocalTime().isAfter(startTime)
					&& requestReceivedTime.toLocalTime().isBefore(endTime))
				isRefundWithinExpiryLimit = true;
		} catch (Exception e) {
			throw new SystemErrorException("Invalid Refund Expiry Limit format");
		}
		return isRefundWithinExpiryLimit;
	}

	private void validateRefundAmtAndCountLimit(TransactionMessageModel tmm, Double refundAmtLimit, Long refundCountLimit) {
		Double refundAmt = null;
		refundAmt = Double.valueOf(tmm.getTxnAmt());
		Long totalRefundCount = 0L;
		Double totalRefundAmount = 0.0;

		if (tmm.getOriginalTmm() != null && tmm.getOriginalTmm().getDependentTotTxnAmt() != null) {
			totalRefundCount = tmm.getOriginalTmm().getDependentTotTxnCount();
			totalRefundAmount = tmm.getOriginalTmm().getDependentTotTxnAmt();
		}
		logger.info("refund count ::{}, refund Amount ::{}", totalRefundCount, totalRefundAmount);
		if (totalRefundCount >= refundCountLimit) {
			throw new PosRefundTxnCountException("Refund count limit has been exceeded");
		} else if (refundAmt > refundAmtLimit) {
			throw new PosRefundTxnAmtException("Refund amount limit has been exceeded");
		}
	}

	private static LocalTime convertToOffsetDateTime(Date startTime) {
		Timestamp timestamp = new Timestamp(startTime.getTime());
		LocalDateTime dateTime = timestamp.toLocalDateTime();
		ZoneOffset offset = ZoneOffset.of("+00:00");
		OffsetDateTime dateTime2 = dateTime.atOffset(offset);
		LocalTime time = dateTime2.toLocalTime();
		System.out.println(time);
		return time;
	}

	@Override
	public SourceProcessor getSourceProcessor() {
		return SourceProcessor.POS_SWITCH;
	}
}