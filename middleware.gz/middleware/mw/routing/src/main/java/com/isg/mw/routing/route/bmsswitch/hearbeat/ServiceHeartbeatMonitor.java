package com.isg.mw.routing.route.bmsswitch.hearbeat;

import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import lombok.Getter;
import lombok.Setter;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.common.Node;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;

@Service
public class ServiceHeartbeatMonitor {

    private final RestTemplate restTemplate = new RestTemplate();

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    ServicesConfig serviceConfig;

    private AdminClient adminClient;

    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    public JSONObject isServicesUp (){
        JSONObject serviceStatus = new JSONObject();
        JSONArray downService = new JSONArray();
        boolean isServiceUp = true;
        for(services services : serviceConfig.getServices()){
            logger.info("Checking Health of "+services.getName()+" Service  ");
            boolean isUp = checkService(services.getIp(), services.getPort());
            if(!isUp ){
                isServiceUp = false;
                logger.info("{} Service is Down for IP : {} PORT : {} ",services.getName(),services.getIp(),services.getPort());
                downService.put(services.getName());
            }else{
                logger.info("{} Service is Up for IP : {} PORT : {} ",services.getName(),services.getIp(),services.getPort());
            }
        }

        logger.info("Checking Health of Kafka Broker {} flag set as {} .",cacheKafkaConfig.getBrokers(),serviceConfig.isKafkaCheck());
        if(serviceConfig.isKafkaCheck()){
         if(isKafkaBrokerHealthy()){
             logger.info("Kafka broker is healthy for {}.",cacheKafkaConfig.getBrokers());
         }else{
             isServiceUp = false;
             logger.info("Kafka broker is not healthy. for {}",cacheKafkaConfig.getBrokers());
             downService.put("Kafka");
         }
        }

        serviceStatus.put("STATUS",isServiceUp);
        serviceStatus.put("DOWN_SERVICE",downService);
        return serviceStatus;
    }

    private boolean isKafkaBrokerHealthy() {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, cacheKafkaConfig.getBrokers());
        props.put(AdminClientConfig.REQUEST_TIMEOUT_MS_CONFIG, "10000"); // 10 seconds
        props.put(AdminClientConfig.RETRIES_CONFIG, "3");

        try {
            if(adminClient == null){
                adminClient = AdminClient.create(props);
            }

            DescribeClusterResult clusterResult = adminClient.describeCluster();
            try {
                String clusterId = clusterResult.clusterId().get();
                Node controller = clusterResult.controller().get();
                Collection<Node> nodes = clusterResult.nodes().get();

                if (nodes.isEmpty()) {
                    logger.info("Kafka broker is not healthy: No brokers available in the cluster.");
                    return false;
                }

                logger.info("Cluster ID: " + clusterId);
                logger.info("Controller: " + controller);

            } catch (ExecutionException | InterruptedException e) {
                logger.info("Kafka broker is not healthy: " + e.getMessage());
                return false;
            }

            ListTopicsResult topicsResult = adminClient.listTopics();
            Set<String> topics;
            try {
                topics = topicsResult.names().get();
                if (topics.isEmpty()) {
                    logger.info("Kafka broker is not healthy: No topics found in the cluster.");
                    return false;
                }
                logger.info("Topics in the cluster: " + topics);
            } catch (ExecutionException | InterruptedException e) {
                logger.info("Kafka broker is not healthy: Failed to retrieve topics. " + e.getMessage());
                return false;
            }

            return true;
        } catch (Exception e) {
            logger.info("Kafka broker health check failed: " + e.getMessage());
            return false;
        }
    }

    private boolean checkService(String ip, String port){
        boolean isUp = false;
        String healthUrl = constructUrl(ip,port);
        try {
            ResponseEntity<String> serviceResponse = restTemplate.getForEntity(healthUrl, String.class);
            if (serviceResponse.getStatusCode().is2xxSuccessful()) {
                isUp = true;
            }
        }catch(Exception e){
            logger.error("Error Occur While Checking Health of Service ",e.getMessage());
        }
        return isUp;
    }

    private String constructUrl(String ip, String port){
        return String.format("http://%s:%s/actuator/health", ip, port);
    }



}
