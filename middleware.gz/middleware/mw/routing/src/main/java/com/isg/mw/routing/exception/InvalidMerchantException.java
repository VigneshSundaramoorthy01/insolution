package com.isg.mw.routing.exception;

public class InvalidMerchantException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidMerchantException(String errorMsg) {
		super(errorMsg);
	}

	public InvalidMerchantException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}
