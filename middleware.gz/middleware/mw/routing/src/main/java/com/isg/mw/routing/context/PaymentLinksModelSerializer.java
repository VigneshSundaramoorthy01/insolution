package com.isg.mw.routing.context;

import com.isg.mw.core.model.tlm.PaymentLinksModel;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class PaymentLinksModelSerializer implements Serializer<PaymentLinksModel> {


    private Logger logger = LogManager.getLogger(getClass());

    @Override
    public byte[] serialize(String topic, PaymentLinksModel data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(data);
            oos.flush();
        } catch (IOException e) {
            logger.error("Error while serializing Payment Links Model object: {}", e);
        }
        return bos.toByteArray();
    }
}
