package com.isg.mw.routing.exception;

public class TargetNoResponseException extends RuntimeException{

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public TargetNoResponseException(String errorMsg) {
        super(errorMsg);
    }

    public TargetNoResponseException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}
