package com.isg.mw.routing.route;

import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.ThreadContext;

import java.io.UnsupportedEncodingException;
import java.util.Optional;

public interface ITransactionProcessor {

    void processTxnRequest(Exchange exchange);

    void processTxnResponse(Exchange exchange);

    void processTxnDecline(Exchange exchange) throws UnsupportedEncodingException;

    SourceProcessor getSourceProcessor();

    default void setLoggerContext(TransactionMessageModel tmm) {

        ThreadContext.put(FilterConstants.threadContextAcpTraceId, tmm.getAcpTraceId());

        Optional.ofNullable(tmm.getRetrievalRefNo()).ifPresent(rrn ->
                ThreadContext.put(FilterConstants.threadContextRetrievalRefNo, rrn)
        );
    }

    default void clearLoggerContext() {
        ThreadContext.clearAll();
    }
}
