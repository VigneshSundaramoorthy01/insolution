package com.isg.mw.routing.smartroute.successratio;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

import java.time.OffsetDateTime;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import com.isg.mw.core.model.constants.StatsType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.routing.smartroute.AbstractSmartRoute;
import com.isg.mw.routing.smartroute.SmartRouteSchedulerService;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.constants.TargetPriority;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.sr.TargetInfo;
import com.isg.mw.core.model.sr.TargetKey;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.IssuerUnavailableException;

@Component
public class SuccessRatioStaticRoute extends AbstractSmartRoute implements ApplicationContextAware {

    private Logger logger = LogManager.getLogger();

    private ApplicationContext applicationContext;

    @Override
    synchronized public void calculateSuccessRatio(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, OffsetDateTime threadCacheLastCalculatedDate) {
        if (isThreadAllowedToCalculate(sourceConfigModel, threadCacheLastCalculatedDate))
            return;

        super.calculateSuccessRatio(sourceConfigModel, smartRouteConfigModel, threadCacheLastCalculatedDate);
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));

        Map<TargetKey, TargetInfo> primaryTargetMap = getTargetByPriority(targets, TargetPriority.PRIMARY);
        TargetKey primaryTargetKey = primaryTargetMap.keySet().iterator().next();
        TargetInfo primaryTargetInfo = primaryTargetMap.get(primaryTargetKey);
        /**
         * If success ratio of the primary target goes below the threshold then set the primary as
         * current target to false and secondary to true.
         */
        if (isTargetBelowThreshold(primaryTargetInfo, smartRouteConfigModel)) {
            cacheUtil.updateCurrentTarget(cacheHelper.getTargetMapKey(sourceConfigModel),
                    primaryTargetKey, false);

            Map<TargetKey, TargetInfo> secondaryTargetMap = getTargetByPriority(targets, TargetPriority.SECONDARY);
            TargetKey secondaryTargetKey = secondaryTargetMap.keySet().iterator().next();
            TargetInfo secondaryTargetInfo = secondaryTargetMap.get(secondaryTargetKey);

            cacheUtil.updateCurrentTarget(cacheHelper.getTargetMapKey(sourceConfigModel),
                    secondaryTargetKey, true);

            logger.info("Success ratio for the primary target {} is {}, and has fallen below threshold {} and " +
                            "hence switching to secondary target {}", primaryTargetInfo.getTargetName(),
                    primaryTargetInfo.getCurrentSuccessRatio(), smartRouteConfigModel.getSuccessThreshold(),
                    secondaryTargetInfo.getTargetName());

            setSwitchToPrimaryScheduler(sourceConfigModel, smartRouteConfigModel, primaryTargetKey, secondaryTargetKey);
        }
    }

    @Override
    public TargetConfigModel getTxnTarget(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        logger.info("Getting target for the source: {}", sourceConfigModel.getName());
        SmartRouteConfigModel smartRouteConfigModel = routingContext.getSmartRouteConfigModel();

        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));

        /**
         * Get the current target and if it is alive then then return it
         */
        AtomicReference<TargetConfigModel> targetConfigModel = new AtomicReference<>();

        Iterator<Map.Entry<TargetKey, TargetInfo>> targetsIterator = targets.entrySet().iterator();
        while (targetsIterator.hasNext()) {
            TargetKey targetKey = targetsIterator.next().getKey();
            TargetInfo targetInfo = targets.get(targetKey);

            TargetConfigModel targetConfigModel1 = getTargetConfigById(routingContext, targetKey.getTargetId());
            if (Boolean.TRUE.equals(targetInfo.getStaticTargetInfo().getCurrentTarget()) && targetInfo.isAlive()) {
                targetConfigModel.set(targetConfigModel1);
                break;
            }
        }

        /**
         * If previous current target is not alive, then specifically check for the secondary target and
         * also set the switch to primary scheduler
         */
        if (targetConfigModel.get() == null) {
            Iterator<Map.Entry<TargetKey, TargetInfo>> targetsIterator1 = targets.entrySet().iterator();
            while (targetsIterator1.hasNext()) {
                TargetKey targetKey = targetsIterator1.next().getKey();
                TargetInfo targetInfo = targets.get(targetKey);

                if (targetInfo.getStaticTargetInfo().getPriority() == TargetPriority.SECONDARY &&
                        targetInfo.isAlive()) {
                    targetConfigModel.set(getTargetConfigById(routingContext, targetKey.getTargetId()));
                    TargetKey primaryTargetKey = getTargetKeyByPriority(targets, TargetPriority.PRIMARY);
                    //following removes the previous scheduler of primary
                    SmartRouteSchedulerService existingSRSchedulerService = routingContext.getSmartRouteSchedulerService();
                    if (existingSRSchedulerService != null) {
                        existingSRSchedulerService.stopScheduledTask();
                        logger.info("Scheduler for target {} has been removed", targets.get(primaryTargetKey).getTargetName());
                    }
                    setSwitchToPrimaryScheduler(sourceConfigModel, smartRouteConfigModel, primaryTargetKey, targetKey);
                    break;
                }
            }
        }

        /**
         * If none of the targets are alive then throw an exception.
         */
        if (targetConfigModel.get() == null) {
            //TODO: throw an exception
            throw new IssuerUnavailableException("Target not available");
        }

        logger.info("Target identified for the source: {} is {}", sourceConfigModel.getName(), targetConfigModel.get().getName());
        return targetConfigModel.get();
    }

    private void setSwitchToPrimaryScheduler(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel,
                                             TargetKey primaryTargetKey, TargetKey secTargetKey) {
        SmartRouteTargetDefinition targetDefinition = getTargetDefinitionByPriority(smartRouteConfigModel,
                TargetPriority.SECONDARY);
        cacheUtil.updateCurrentTarget(cacheHelper.getTargetMapKey(sourceConfigModel), primaryTargetKey, false);
        cacheUtil.updateCurrentTarget(cacheHelper.getTargetMapKey(sourceConfigModel), secTargetKey, true);

        SmartRouteSchedulerService smartRouteSchedulerService =
                this.applicationContext.getBean(SmartRouteSchedulerService.class);
        smartRouteSchedulerService.scheduleTask(() -> {
            logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.PRIMARY_SWITCH_OVER);
            resetCache(sourceConfigModel, smartRouteConfigModel);
            cacheUtil.updateCurrentTarget(cacheHelper.getTargetMapKey(sourceConfigModel), secTargetKey, false);
            cacheUtil.updateCurrentTarget(cacheHelper.getTargetMapKey(sourceConfigModel), primaryTargetKey, true);
            logger.info("Target has been switched back to primary target {}", primaryTargetKey.getTargetId());
        }, targetDefinition.getSwitchToPrimaryInterval());

        logger.info("Switch to primary scheduler has been set on secondary target {} for {} millis",
                targetDefinition.getTargetId(), targetDefinition.getSwitchToPrimaryInterval());
    }

    private SmartRouteTargetDefinition getTargetDefinitionByPriority(SmartRouteConfigModel smartRouteConfigModel,
                                                                     TargetPriority targetPriority) {
        return smartRouteConfigModel.getTargetRouteConfig().stream()
                .filter(target1 -> target1.getTargetPriority() == targetPriority)
                .findFirst()
                .orElse(null);
    }

    private TargetKey getTargetKeyByPriority(Map<TargetKey, TargetInfo> targets, TargetPriority priority) {
        AtomicReference<TargetKey> targetId = new AtomicReference<>();
        targets.forEach((targetKey, targetInfo) -> {
            if (targetInfo.getStaticTargetInfo().getPriority() == priority) {
                targetId.set(targetKey);
            }
        });

        return targetId.get();
    }

    private TargetInfo getTargetInfoByPriority(Map<TargetKey, TargetInfo> targets, TargetPriority priority) {
        return targets.values().stream()
                .filter(targetInfo -> targetInfo.getStaticTargetInfo().getPriority() == priority)
                .findFirst()
                .orElse(null);
    }

    private Map<TargetKey, TargetInfo> getTargetByPriority(Map<TargetKey, TargetInfo> targets,
                                                           TargetPriority priority) {
        return targets.entrySet().stream()
                .filter(entry ->
                        entry.getValue().getStaticTargetInfo().getPriority() == priority)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public RouteType getRouteType() {
        return RouteType.SUCCESS_RATIO_STATIC;
    }
}
