package com.isg.mw.routing.exception;

/**
 * 
 * @author shital3986
 *
 */
public class LessReversalAmountException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public LessReversalAmountException(String errorMsg) {
		super(errorMsg);
	}

	public LessReversalAmountException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}

}
