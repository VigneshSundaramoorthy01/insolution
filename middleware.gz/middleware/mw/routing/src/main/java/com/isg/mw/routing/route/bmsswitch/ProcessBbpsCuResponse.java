package com.isg.mw.routing.route.bmsswitch;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.bms.commonModels.*;
import com.isg.bms.constant.BmsSwitchConstant;
import com.isg.bms.requestModels.*;
import com.isg.bms.responseModels.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TxnReconData;
import com.isg.mw.core.model.upi.TransactionExtensionMessageModelV2;
import com.isg.mw.core.model.upi.TransactionMessageModelV2;
import com.isg.mw.core.model.upi.UpiTransactionDetail;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.TargetNoResponseException;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import org.apache.camel.Exchange;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.*;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

@Component
public class ProcessBbpsCuResponse {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    ObjectMapper objectMapper;

    private SimpleDateFormat sdf = new SimpleDateFormat(BmsSwitchConstant.npciRespDateFormat);

    @Autowired
    TransactionProcessorHelper transactionProcessorHelper;


    public Object callNpci(String npciResponseXml, String url) {
        Object resAck = null;
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Type", "application/xml");
            resAck = callWebclientApi(npciResponseXml, url, headers);
        } catch (Exception e) {
            logger.info("Exception while calling NPCI Response API : {}", e.getMessage());
            resAck = "200" + TmmConstants.API_RESPONSE_SEPARATOR + "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                    "<ns2:Ack api=\"BillFetchRequest\" refId=\"HENSVVR4QOS7X1UGPY7JGUV444P10102202\" msgId=\"8ENSVVR4QOS7X1UGPY7JGUV444P10102202\" RspCd=\"Successful\" ts=\"2024-07-31T11:55:07.395+05:30\" xmlns:ns2=\"http://npci.org/upi/schema/\"/>";
        }
        return resAck;
    }

    public String prepareBillFetchResponse(Object bmsResp, BillFetchNpciRequest billFetchNpciRequest) throws JAXBException {
        String resBody = null;
        StringWriter respData = new StringWriter();
        resBody = transactionProcessorHelper.parseResponse(bmsResp.toString());
        BillFetchResponse billFetchResponse = IsgJsonUtils.getObjectFromJsonString(resBody, BillFetchResponse.class);

        //set response
        BillFetchNpciResponse billFetchNpciResponse = new BillFetchNpciResponse();
        Head head = new Head();
        head.setVer(billFetchNpciRequest.getHead().getVer());
        head.setTs(sdf.format(new Date()));
        head.setRefId(billFetchNpciRequest.getHead().getRefId());
        head.setOrigInst(billFetchNpciRequest.getHead().getOrigInst());

        Reason reason = new Reason();
        reason.setResponseReason(billFetchResponse.getBillFetchResponse().getReason().getResponseReason());
        reason.setComplianceReason("00");
        reason.setResponseCode(billFetchResponse.getBillFetchResponse().getReason().getResponseCode());
        reason.setApprovalRefNum(billFetchResponse.getBillFetchResponse().getHead().getRefId());
        reason.setComplianceRespCd("00");

        BillFetchNpciResponse.TxnType txn = new BillFetchNpciResponse.TxnType();
        txn.setTs(sdf.format(new Date()));
        txn.setMsgId(billFetchNpciRequest.getTxn().getMsgId());

        BillFetchNpciResponse.BillDetails billDetails = new BillFetchNpciResponse.BillDetails();
        BillFetchNpciResponse.BillDetails.CustomerParams customerParams = new BillFetchNpciResponse.BillDetails.CustomerParams();
        Tag tag = new Tag();
        List<Tag> tagList = new ArrayList<>();

        for (int i = 0; i < billFetchNpciRequest.getBillDetails().getCustomerParams().getTag().toArray().length; i++) {
            tag.setName(billFetchNpciRequest.getBillDetails().getCustomerParams().getTag().get(i).getName());
            tag.setValue(billFetchNpciRequest.getBillDetails().getCustomerParams().getTag().get(i).getValue());
            tagList.add(tag);
        }
        customerParams.setTag(tagList);
        billDetails.setCustomerParams(customerParams);

        BillerResponse billerResponse = new BillerResponse();
/*        Optional.ofNullable(billFetchResponse)
            .map(BillFetchResponse::getBillFetchResponse)
            .map(BillFetchResponse.BillFetchResponseBody::getBillerResponse)
            .map(BillFetchResponse.BillFetchResponseBody.BillerResponse::getCustomerName)
            .ifPresent(customerName -> billerResponse.setCustomerName(customerName));*/

        Optional.ofNullable(billFetchResponse)
                .map(BillFetchResponse::getBillFetchResponse)
                .map(BillFetchResponse.BillFetchResponseBody::getBillerResponse)
                .ifPresent(billerResponseBody -> {
                    // set each property using Optional
                    Optional.ofNullable(billerResponseBody.getCustomerName())
                            .ifPresent(billerResponse::setCustomerName);
                    Optional.ofNullable(billerResponseBody.getBillNumber())
                            .ifPresent(billerResponse::setBillNumber);
                    Optional.ofNullable(billerResponseBody.getAmount())
                            .ifPresent(billerResponse::setAmount);
                    Optional.ofNullable(billerResponseBody.getBillPeriod())
                            .ifPresent(billerResponse::setBillPeriod);
                    Optional.ofNullable(billerResponseBody.getBillDate())
                            .ifPresent(billerResponse::setBillDate);
                    Optional.ofNullable(billerResponseBody.getDueDate())
                            .ifPresent(billerResponse::setDueDate);
                });

        tag = new Tag();
        List<Tag> billerTagList = new ArrayList<Tag>();
        tag.setName("Amount 1");
        tag.setValue("5000");
        billerTagList.add(tag);
        billerResponse.setTag(billerTagList);


        AdditionalInfo additionalInfo = new AdditionalInfo();
        List<Tag> adInfoTagList = new ArrayList<Tag>();
        tag = new Tag();
        tag.setName("BlRspFld1");
        tag.setValue("");
        adInfoTagList.add(tag);
        additionalInfo.setTag(adInfoTagList);

        billFetchNpciResponse.setBillerResponse(billerResponse);
        billFetchNpciResponse.setBillDetails(billDetails);
        billFetchNpciResponse.setHead(head);
        billFetchNpciResponse.setTxn(txn);
        billFetchNpciResponse.setReason(reason);
        billFetchNpciResponse.setAdditionalInfo(additionalInfo);

        JAXBContext contextObj = JAXBContext.newInstance(BillFetchNpciResponse.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.marshal(billFetchNpciResponse, respData);
        return respData.toString();
    }

    public String prepareBillPaymentResponse(BillPayResponse billPaymentResponse, BillPayNpciRequest billPaymentNpciRequest) throws JAXBException {
        String resBody = null;
        StringWriter respData = new StringWriter();
        BillPayNpciResponse billPaymentNpciResponse = new BillPayNpciResponse();
        Head head = new Head();
        head.setVer(billPaymentNpciRequest.getHead().getVer());
        head.setTs(sdf.format(new Date()));
        head.setRefId(billPaymentNpciRequest.getHead().getRefId());
        head.setOrigInst(billPaymentNpciRequest.getHead().getOrigInst());

        Reason reason = new Reason();
        reason.setResponseReason(billPaymentResponse.getBillPayResponse().getReason().getResponseReason());
        reason.setComplianceReason(billPaymentResponse.getBillPayResponse().getReason().getComplianceReason());
        reason.setResponseCode(billPaymentResponse.getBillPayResponse().getReason().getResponseCode());
        reason.setApprovalRefNum(billPaymentResponse.getBillPayResponse().getReason().getApprovalRefNum());
        reason.setComplianceRespCd(billPaymentResponse.getBillPayResponse().getReason().getComplianceRespCd());

        BillPayNpciResponse.TxnType txn = new BillPayNpciResponse.TxnType();
        txn.setTs(sdf.format(new Date()));
        txn.setMsgId(billPaymentResponse.getBillPayResponse().getHead().getMsgId());
 /*       txn.setMsgId(billPaymentNpciRequest.getTxn().getMsgId());
        txn.setType(billPaymentNpciRequest.getTxn().getType());
        txn.setTxnReferenceId(billPaymentResponse.getCcTranId());*/

        BillPayNpciResponse.BillDetails billDetails = new BillPayNpciResponse.BillDetails();
        BillPayNpciResponse.BillDetails.CustomerParams customerParams = new BillPayNpciResponse.BillDetails.CustomerParams();

        List<Tag> tagList = new ArrayList<>();

        for (int i = 0; i < billPaymentNpciRequest.getBillDetails().getCustomerParams().getTag().toArray().length; i++) {
            Tag tag = new Tag();
            tag.setName(billPaymentNpciRequest.getBillDetails().getCustomerParams().getTag().get(i).getName());
            tag.setValue(billPaymentNpciRequest.getBillDetails().getCustomerParams().getTag().get(i).getValue());
            tagList.add(tag);
        }
        customerParams.setTag(tagList);
        billDetails.setCustomerParams(customerParams);

        BillerResponse billerResponse = new BillerResponse();
        billerResponse.setCustomerName(billPaymentResponse.getBillPayResponse().getBillerResponse().getCustomerName());
        billerResponse.setBillNumber(billPaymentResponse.getBillPayResponse().getBillerResponse().getBillNumber());
        billerResponse.setAmount(billPaymentResponse.getBillPayResponse().getBillerResponse().getAmount());
        billerResponse.setBillPeriod(billPaymentResponse.getBillPayResponse().getBillerResponse().getBillPeriod());
        billerResponse.setBillDate(billPaymentResponse.getBillPayResponse().getBillerResponse().getBillDate());
        billerResponse.setDueDate(billPaymentResponse.getBillPayResponse().getBillerResponse().getDueDate());
        billerResponse.setCustConvFee(billPaymentNpciRequest.getBillerResponse().getCustConvFee());

        AdditionalInfo additionalInfo = new AdditionalInfo();
        List<Tag> adInfoTagList = new ArrayList<Tag>();
        Tag tag = new Tag();
        tag.setName("PaymentBlRspFld1");
        tag.setValue("");
        adInfoTagList.add(tag);
        additionalInfo.setTag(adInfoTagList);

        billPaymentNpciResponse.setBillerResponse(billerResponse);
        billPaymentNpciResponse.setBillDetails(billDetails);
        billPaymentNpciResponse.setHead(head);
        billPaymentNpciResponse.setTxn(txn);
        billPaymentNpciResponse.setReason(reason);
        billPaymentNpciResponse.setAdditionalInfo(additionalInfo);

        JAXBContext contextObj = JAXBContext.newInstance(BillPayNpciResponse.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.marshal(billPaymentNpciResponse, respData);
        return respData.toString();
    }

    public String prepareReversalResponse(BillPayReversalNpciRequest payReversalNpciReq, String txnData, String dataOrigin) throws JAXBException {

        BillPayReversalNpciResponse billPayReversalNpciRes = new BillPayReversalNpciResponse();



        Head head = new Head();
        head.setVer(payReversalNpciReq.getHead().getVer());
        head.setTs(sdf.format(new Date()));
        head.setOrigInst(payReversalNpciReq.getHead().getOrigInst());
        head.setRefId(payReversalNpciReq.getHead().getRefId());

        BillPayReversalNpciRequest.Txn txn = new BillPayReversalNpciRequest.Txn();
        txn.setTxnReferenceId(payReversalNpciReq.getTxn().getTxnReferenceId());
        txn.setTs(sdf.format(new Date()));
        txn.setType(payReversalNpciReq.getTxn().getType());
        txn.setMsgId(payReversalNpciReq.getTxn().getMsgId());

        Reason reason = new Reason();
        if (dataOrigin.equalsIgnoreCase("REDIS")) {
            BillPayTransactionDetails transactionDetails = IsgJsonUtils.getObjectFromJsonString(txnData, BillPayTransactionDetails.class);
            reason.setApprovalRefNum("AB123456");
            reason.setResponseCode(transactionDetails.getStatusCode());
            reason.setResponseReason(transactionDetails.getStatus());
            reason.setComplianceRespCd("");
            reason.setComplianceReason("");

        } else if (dataOrigin.equalsIgnoreCase("DATABASE")) {
            TransactionMessageModelV2 tmmV2Model = IsgJsonUtils.getObjectFromJsonString(txnData, TransactionMessageModelV2.class);
            reason.setApprovalRefNum("AB123456");
            reason.setResponseCode(String.valueOf(tmmV2Model.getStatus()));
            reason.setResponseReason(String.valueOf(tmmV2Model.getTxnStatus()));
            reason.setComplianceRespCd("");
            reason.setComplianceReason("");
        }

        billPayReversalNpciRes.setHead(head);
        billPayReversalNpciRes.setTxn(txn);
        billPayReversalNpciRes.setReason(reason);

        StringWriter respData = new StringWriter();

        JAXBContext contextObj = JAXBContext.newInstance(BillPayReversalNpciResponse.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.marshal(billPayReversalNpciRes, respData);
        logger.info("BillPayReversalNpciResponse XML :::: {}", respData.toString());
        return respData.toString();
    }

    public Object callWebclientApi(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking NPCI API through Web Client To Send Response Back : {}", body);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new TargetNoResponseException("Target is not responding");
        }
        String res = httpStatus.value() + TmmConstants.API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public TransactionMessageModelV2 constructTmmv2(Exchange exchange, BillPayNpciRequest billPaymentNpciRequest, BillPayNpciResponse billPaymentNpciResponse,
                                                    String txnId, String traceId, int status, TargetConfigModel targetConfigModel, RoutingContext routingContext) {
        TransactionMessageModelV2 transactionMessageModelV2 = new TransactionMessageModelV2();
        TransactionExtensionMessageModelV2 transactionExtensionMessageModelV2 = new TransactionExtensionMessageModelV2();
        try {
            transactionMessageModelV2.setTxn_id(txnId);
            transactionMessageModelV2.setTxnType(BmsSwitchConstant.PAY_TXN_TYPE);

            transactionMessageModelV2.setSrc_txn_id(billPaymentNpciRequest.getTxn().getTxnReferenceId());
            transactionMessageModelV2.setTgt_txn_id(billPaymentNpciRequest.getTxn().getTxnReferenceId());
            transactionMessageModelV2.setTraceability_txn_id(traceId);
            transactionMessageModelV2.setSrc_req_arrival_time(new Date());
            transactionMessageModelV2.setPayer_id("");
            transactionMessageModelV2.setPayee_id("");
            transactionMessageModelV2.setEntity_id(routingContext.getEntityId());
            transactionMessageModelV2.setSrc_type(routingContext.getSource().getSourceType().name());
            transactionMessageModelV2.setTgt_type(targetConfigModel != null ? targetConfigModel.getTargetType().name() : null);
            if (billPaymentNpciRequest != null) {
                transactionMessageModelV2.setRrn(billPaymentNpciRequest.getHead().getRefId());
                transactionMessageModelV2.setSrc_currency_code(billPaymentNpciRequest.getAmount().getAmt().getCurrency());
                transactionMessageModelV2.setTgt_currency_code(billPaymentNpciRequest.getAmount().getAmt().getCurrency());
                transactionMessageModelV2.setAmount(billPaymentNpciRequest.getAmount().getAmt().getAmount());
            }
            if (billPaymentNpciResponse != null) {
                transactionMessageModelV2.setTxnStatus(billPaymentNpciResponse.getReason().getResponseReason().toUpperCase());
            }
            transactionMessageModelV2.setStatus(status);
            transactionExtensionMessageModelV2.setTxnId(txnId);
            transactionExtensionMessageModelV2.setSrcReqData(objectMapper.writeValueAsString(billPaymentNpciRequest));
            transactionMessageModelV2.setTransactionExtensionMessageModelV2(transactionExtensionMessageModelV2);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Error occurred while constructing tmm::::" + ExceptionUtils.getStackTrace(e));
        }
        logger.debug("Exit from construct TmmV2 with data:::" + transactionMessageModelV2);
        return transactionMessageModelV2;
    }


    public TransactionMessageModelV2 constructTmmv2ForReversal(Exchange exchange,BillPayReversalNpciRequest payReversalNpciReq, BillPayReversalNpciResponse payReversalNpciResponse,
                                                    String txnId, String traceId, int status, TargetConfigModel targetConfigModel) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        TransactionMessageModelV2 transactionMessageModelV2 = new TransactionMessageModelV2();
        TransactionExtensionMessageModelV2 transactionExtensionMessageModelV2 = new TransactionExtensionMessageModelV2();
        try {
            transactionMessageModelV2.setTxn_id(txnId);
            transactionMessageModelV2.setTxnType(BmsSwitchConstant.REVERSAL_TXN_TYPE);

            transactionMessageModelV2.setSrc_txn_id(payReversalNpciReq.getTxn().getTxnReferenceId());
            transactionMessageModelV2.setTgt_txn_id(payReversalNpciReq.getTxn().getTxnReferenceId());
            transactionMessageModelV2.setTraceability_txn_id(traceId);
            transactionMessageModelV2.setSrc_req_arrival_time(new Date());
            transactionMessageModelV2.setPayer_id("");
            transactionMessageModelV2.setPayee_id("");
            transactionMessageModelV2.setEntity_id(routingContext.getEntityId());
            transactionMessageModelV2.setSrc_type(routingContext.getSource().getSourceType().name());
            transactionMessageModelV2.setTgt_type(targetConfigModel != null ? targetConfigModel.getTargetType().name() : null);
            if (payReversalNpciReq != null) {
                transactionMessageModelV2.setRrn(payReversalNpciReq.getHead().getRefId());
            }
            if (payReversalNpciResponse != null) {
                transactionMessageModelV2.setTxnStatus(payReversalNpciResponse.getReason().getResponseReason().toUpperCase());
            }
            transactionMessageModelV2.setStatus(status);
            transactionExtensionMessageModelV2.setTxnId(txnId);
            transactionExtensionMessageModelV2.setSrcReqData(objectMapper.writeValueAsString(payReversalNpciReq));
            transactionMessageModelV2.setTransactionExtensionMessageModelV2(transactionExtensionMessageModelV2);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Error occurred while constructing tmm::::" + ExceptionUtils.getStackTrace(e));
        }
        logger.debug("Exit from construct TmmV2 with data:::" + transactionMessageModelV2);
        return transactionMessageModelV2;
    }

    public String prepareBillStatusResponse(BillPayEnquiryResponse response, BillPayEnquiryNpciRequest request) {
        StringWriter respData = new StringWriter();
        try {
            BillPayEnquiryNpciResponse txnStatusNpciResponse = new BillPayEnquiryNpciResponse();

            Head head = new Head();
            head.setVer("1.0");
            head.setTs(sdf.format(new Date()));
            head.setOrigInst(response.getTxnStatusResponse().getHead().getOrigInst());
            head.setRefId(response.getTxnStatusResponse().getHead().getRefId());

            Reason reason = new Reason();
            reason.setApprovalRefNum(response.getTxnStatusResponse().getReason().getApprovalRefNum());
            reason.setResponseCode(response.getTxnStatusResponse().getReason().getResponseCode());
            reason.setResponseReason(response.getTxnStatusResponse().getReason().getResponseReason());
            reason.setComplianceRespCd(response.getTxnStatusResponse().getReason().getComplianceRespCd());
            reason.setComplianceReason(response.getTxnStatusResponse().getReason().getComplianceReason());

            BillPayEnquiryNpciResponse.BillDetails billDetails = new BillPayEnquiryNpciResponse.BillDetails();
            BillPayEnquiryNpciResponse.BillDetails.CustomerParams customerParams = new BillPayEnquiryNpciResponse.BillDetails.CustomerParams();
            List<Tag> tagList = new ArrayList<>();

        /*for (Tag tagItem : ...getBillDetails().getCustomerParams().getTag()) {
            Tag tag = new Tag();  // Create a new Tag object for each iteration
            tag.setName(tagItem.getName());
            tag.setValue(tagItem.getValue());
            tagList.add(tag);
        }*/
            customerParams.setTag(tagList);
            billDetails.setCustomerParams(customerParams);

            BillPayEnquiryNpciResponse.Txn txn = new BillPayEnquiryNpciResponse.Txn();
            txn.setTxnReferenceId(response.getTxnStatusResponse().getTxn().getTxnReferenceId());
            txn.setTs(sdf.format(new Date()));
            txn.setType(response.getTxnStatusResponse().getTxn().getType());
            txn.setMsgId(response.getTxnStatusResponse().getHead().getMsgId());
            txn.setXchangeId("");

            BillPayEnquiryNpciResponse.BillerResponse billerResponse = new BillPayEnquiryNpciResponse.BillerResponse();
            billerResponse.setCustomerName(response.getTxnStatusResponse().getBillerResponse().getCustomerName());
            billerResponse.setAmount(response.getTxnStatusResponse().getBillerResponse().getAmount());
            billerResponse.setDueDate(response.getTxnStatusResponse().getBillerResponse().getDueDate());
            billerResponse.setCustConvFee("");
            billerResponse.setBillDate(response.getTxnStatusResponse().getBillerResponse().getBillDate());
            billerResponse.setBillNumber(response.getTxnStatusResponse().getBillerResponse().getBillNumber());
            billerResponse.setBillPeriod(response.getTxnStatusResponse().getBillerResponse().getBillPeriod());

            AdditionalInfo additionalInfo = new AdditionalInfo();
            additionalInfo.setTag(tagList);

            txnStatusNpciResponse.setHead(head);
            txnStatusNpciResponse.setReason(reason);
            txnStatusNpciResponse.setTxn(txn);
            txnStatusNpciResponse.setBillDetails(billDetails);
            txnStatusNpciResponse.setBillerResponse(billerResponse);
            txnStatusNpciResponse.setAdditionalInfo(additionalInfo);

            JAXBContext contextObj = JAXBContext.newInstance(BillPayEnquiryNpciResponse.class);
            Marshaller marshallerObj = contextObj.createMarshaller();
            marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshallerObj.marshal(txnStatusNpciResponse, respData);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return respData.toString();
    }

    public String prepareHeartBeatRequest() throws Exception {

        StringWriter respData = new StringWriter();
        DiagnosticNpciRequest reqDiag = new DiagnosticNpciRequest();
        DiagnosticNpciRequest.Head head = new DiagnosticNpciRequest.Head();

        head.setVer("1.0");
        head.setRefId("HENSVVR4QOS7X1UGPY7JGUV444P10102202");
        head.setOrigInst("OU01");
        head.setTs(sdf.format(new Date()));
        reqDiag.setHead(head);

        JAXBContext contextObj = JAXBContext.newInstance(DiagnosticNpciRequest.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.setProperty("com.sun.xml.bind.namespacePrefixMapper", new CustomNamespacePrefixMapper());
        marshallerObj.marshal(reqDiag, respData);

        return respData.toString();
    }

    public TxnReconData constructTmmVersionV2(Exchange exchange , BillPayNpciRequest billPaymentNpciRequest, BillPayNpciResponse billPaymentNpciResponse,
                                              String txnId, String traceId, int status,RoutingContext routingContext) throws JsonProcessingException {
        logger.debug("Entry in constructTmmVersionV2::::::::::::");
//        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        TxnReconData txnReconData = new TxnReconData();
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+05:30");
            UpiTransactionDetail upiTransactionDetail = null;

            txnReconData.setTransactionID(txnId);
            txnReconData.setCustomerReferenceNumber(billPaymentNpciRequest.getHead().getRefId());
            txnReconData.setTransactionDateAndTime(new Date());
            txnReconData.setDBCR(BmsSwitchConstant.PAY_TXN_TYPE);
            txnReconData.setBusinessDate(new Date());
            txnReconData.setMessageId(billPaymentNpciRequest.getTxn().getMsgId());
            txnReconData.setBillerId(billPaymentNpciRequest.getBillDetails().getBiller().getId());
            txnReconData.setTransactionAmount(billPaymentNpciRequest.getAmount().getAmt().getAmount());

            if (billPaymentNpciResponse != null) {
                if(billPaymentNpciResponse.getReason().getResponseCode().equalsIgnoreCase("000")){
                    txnReconData.setTransactionStatus("SUCCESS");
                }else{
                    txnReconData.setTransactionStatus("FAILED");
                }
                txnReconData.setAuthCode(billPaymentNpciResponse.getReason().getApprovalRefNum());
                txnReconData.setTransactionAmount(billPaymentNpciResponse.getBillerResponse().getAmount());

            }else{
                txnReconData.setTransactionStatus("IN PROGRESS");
            }


            txnReconData.setResponseCode(Integer.toString(status));
            txnReconData.setTranactionCurrency(billPaymentNpciRequest.getAmount().getAmt().getCurrency());
            txnReconData.setBillingCurrency(billPaymentNpciRequest.getAmount().getAmt().getCurrency());
            txnReconData.setSettlementCurrency(billPaymentNpciRequest.getAmount().getAmt().getCurrency());

            String ifscValue = billPaymentNpciRequest.getAgent().getDevice().getTag().stream()
                    .filter(tag -> "IFSC".equals(tag.getName()))
                    .map(Tag::getValue)
                    .findFirst()
                    .orElse(null);

            String terminalId = billPaymentNpciRequest.getAgent().getDevice().getTag().stream()
                    .filter(tag -> "TERMINAL_ID".equals(tag.getName()))
                    .map(Tag::getValue)
                    .findFirst()
                    .orElse(null);

            String paymentMode = billPaymentNpciRequest.getPaymentMethod().getPaymentMode();

            txnReconData.setTransactionDateAndTime(new Date());
            txnReconData.setInitiationMode(paymentMode);
            txnReconData.setBranchCode(ifscValue);
            txnReconData.setTID(terminalId);
            txnReconData.setIFSCCode(ifscValue);
            txnReconData.setRecordType(BmsSwitchConstant.PAY_TXN_TYPE);
            txnReconData.setLOFO("L");
            txnReconData.setEntityId(routingContext.getEntityId());
        }catch(Exception e){
            e.printStackTrace();
            logger.error("Error Occurred while constructing tmmversionV2 data::::"+ExceptionUtils.getStackTrace(e));
            return null;
        }
        logger.debug("Exit from constructTmmVersionV2:::::"+txnReconData);
        return txnReconData;
    }

    public String prepareBillFetchErrorCodeResponse(BillFetchNpciRequest billFetchNpciRequest, String error) throws JAXBException {
        StringWriter respData = new StringWriter();

        BillFetchNpciResponse billFetchNpciResponse = new BillFetchNpciResponse();
        Reason reason = new Reason();
        reason.setResponseReason("Failure");
        reason.setResponseCode("000");
        if (!StringUtils.isBlank(error)) {
            String[] split = error.split("##");
            reason.setComplianceReason(split[0]);
            reason.setComplianceRespCd(split[1]);
        }
        billFetchNpciResponse.setReason(reason);
        JAXBContext contextObj = JAXBContext.newInstance(BillFetchNpciResponse.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.marshal(billFetchNpciResponse, respData);
        return respData.toString();
    }

    public String prepareBillPayErrorCodeResponse(BillPayNpciRequest billFetchNpciRequest, String error) throws JAXBException {
        StringWriter respData = new StringWriter();

        BillPayNpciResponse billFetchNpciResponse = new BillPayNpciResponse();
        Reason reason = new Reason();
        reason.setResponseReason("Failure");
        reason.setResponseCode("000");
        if (!StringUtils.isBlank(error)) {
            String[] split = error.split("##");
            reason.setComplianceReason(split[0]);
            reason.setComplianceRespCd(split[1]);
        }
        billFetchNpciResponse.setReason(reason);
        JAXBContext contextObj = JAXBContext.newInstance(BillFetchNpciResponse.class);
        Marshaller marshallerObj = contextObj.createMarshaller();
        marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshallerObj.marshal(billFetchNpciResponse, respData);
        return respData.toString();
    }
}
