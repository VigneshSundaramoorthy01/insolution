package com.isg.mw.routing.exception;

public class RefundExistException extends RuntimeException{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Object[] args = null;

    public RefundExistException(String errorMsg) {
        super(errorMsg);
    }

    public RefundExistException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

    public RefundExistException(String msg, Object ... args) {
        super(msg);
        this.args = args;
    }

    public Object[] getArgs() {
        return args;
    }
}
