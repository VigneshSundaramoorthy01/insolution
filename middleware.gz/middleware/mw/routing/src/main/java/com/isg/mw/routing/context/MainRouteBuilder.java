package com.isg.mw.routing.context;

import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.Setter;

public class MainRouteBuilder extends RouteBuilder {

	private Logger logger = LogManager.getLogger(getClass());

	@Setter
	private List<RoutingContext> routingContextList;
	
	private CamelContext camelContext;

	@Autowired
	private RouteGenerator routeGenerator;

	public MainRouteBuilder(List<RoutingContext> routingContextList, CamelContext camelContext) {
		this.routingContextList = routingContextList;
		this.camelContext = camelContext;
	}

	@Override
	public void configure() throws Exception {
		
		this.routingContextList.forEach(routingContext -> 
			from("direct:mainRoute." + routingContext.getSource().getName())
			.to(routeGenerator.generateRoute(routingContext))
		);
		
		routeGenerator.getRouteBuilders().forEach(routeBuilder -> {
			try {
				camelContext.addRoutes(routeBuilder);
			} catch (Exception e) {
				logger.error("Error", e);
			}
		});
	}
}
