package com.isg.mw.routing.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.isg.mw.cache.mgmt.service.BinInfoService;
import com.isg.mw.cache.mgmt.service.HsmUtilityService;
import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.maps.MapsInfoModel;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.*;

@Tag(name = "Mw configuration APIs", description = "Mw Info Configuration API's")
@RestController
@RequestMapping(value = "/utility")
public class InitCacheController {
	private Logger logger = LogManager.getLogger();

	@Value("${init.config.rest.page.size:50000}")
	private int pageSize;

	@Value("${bin.fetch.flag}")
	private String binFetchFlag;

	@Autowired
	private MapsInfoService mapsInfoService;

	@Autowired
	private BinInfoService binInfoService;
	
	@Autowired
	private HsmUtilityService hsmUtilityService;


	@Operation(summary = "API To Get Maps Data from Cache", description = "In response will get model value<br> Note: The key format is 'entityId::mid::tid'", tags = {"Maps Info Model"})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "404", description = "Not Found !!"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "403", description = "Forbidden Error")
	})
	@CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = "/getMaps")
	public ResponseEntity<?> getMapsFromCache(
			@RequestParam(value = "key", required = false) String key) {

		ResponseEntity<?> responseEntity = null;
		MapsInfoModel mapsInfo = null;
		try {
			mapsInfo = mapsInfoService.getMapsInfoById(key);
			if (mapsInfo != null) {
				responseEntity = new ResponseEntity<>(mapsInfo, HttpStatus.OK);
			} else {
				String errMsg = "Data not found with given parameter";
				responseEntity = new ResponseEntity<>(errMsg, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("An error occurred!", e);
		}
		return responseEntity;
	}
	
	
	
	@Operation(summary = "API To Get Bins Data from Cache", description = "In response will get model value", tags = {"Bin Info Model"})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
			@ApiResponse(responseCode = "404", description = "Not Found !!"),
			@ApiResponse(responseCode = "500", description = "Internal Error"),
			@ApiResponse(responseCode = "403", description = "Forbidden Error")
	})
	@CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = "/getBins")
	public ResponseEntity<?> getBinFromCache(
			@RequestParam(value = "cardNumber", required = false) String cardNumber) {

		ResponseEntity<?> responseEntity = null;
		BinInfoModel binInfo = null;
		try {
			binInfo = binInfoService.getBinInfoByCardNumber(cardNumber);
			if (binInfo != null) {
				responseEntity = new ResponseEntity<>(binInfo, HttpStatus.OK);
			} else {
				String errMsg = "Data not found with given parameter";
				responseEntity = new ResponseEntity<>(errMsg, HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("An error occurred!", e);
		}
		return responseEntity;
	}
	
	@Operation(summary = "API To Send and Connect HSM server", description = "In response will get HSM Command response" ,tags= {"HSM Connect"})
	@ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not Found !!"),
            @ApiResponse(responseCode = "500", description = "Internal Error"),
            @ApiResponse(responseCode = "403", description = "Forbidden Error")
    })
	
	@CrossOrigin(methods = RequestMethod.POST)
	@PostMapping(path = "/sendAndConnect")
	public ResponseEntity<?> sendAndConnect(@RequestParam(value = "hsmCommand",required = true) String hsmCommand, @RequestParam(value = "encodedKey",required = true) String encodedKey) {
		return hsmUtilityService.sendAndConnect(hsmCommand, encodedKey);
	}

}
