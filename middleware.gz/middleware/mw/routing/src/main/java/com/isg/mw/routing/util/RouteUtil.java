package com.isg.mw.routing.util;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.routing.config.RoutingConstants;
import com.isg.mw.routing.context.RoutingInitializationContext;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.isg.mw.core.utils.LogUtils.buildLogMessage;


public class RouteUtil {

    private static final Logger logger = LogManager.getLogger("mw");

    @Getter
    private static final ExecutorService executorService = Executors.newCachedThreadPool();

    /**
     * Return ipAndPort if present in input Param
     *
     * @param targetScheme Eg. netty://tcp://192.168.83.117:1005
     * @return ipAndPort  Eg. 192.168.83.117:1005
     */
    public static String fetchIpAndPort(String targetScheme) {

        String ipAndPort = null;

        // Regex Pattern for IP and Port
        String pattern = "\\d{1,3}(?:\\.\\d{1,3}){3}(?::\\d{1,5})";

        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(targetScheme);
        if (matcher.find()) {
            ipAndPort = matcher.group();
        }
        return ipAndPort;
    }

    public static void logToTlmForAutoReversal(TransactionMessageModel tmm) {

        String epId = tmm.getSource() == null ? tmm.getTarget() : tmm.getSource();
        KafkaProducer kafkaProducer = RoutingInitializationContext.getKafkaProducer();
        logger.debug(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
                "Logging transaction to TLM"));
        kafkaProducer.sendMessage(tmm, tmm.getTransactionId());
        logger.info(buildLogMessage(tmm.getEntityId(), epId, tmm.getMsgType(), tmm.getTransactionId(),
                "Logged transaction to TLM"));
    }

    public static boolean validateRrn(String rrn) {
        boolean retVal = false;

        try {
            retVal = rrn.length() == 12 && StringUtils.isNumeric(rrn);

        } catch (Exception e) {
            logger.error("VALIDATION Failed for RRN {} in {}", rrn, RoutingConstants.APPLICATION_DATA_JSON);
            e.printStackTrace();
            System.exit(0);
        }

        return retVal;
    }

    public static RoutingInitializationContext.EndpointMetaData getEndpointByAcquirerId(Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> entries, String acquirerId, String remoteAdd) {
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : entries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> value = entry.getValue();
            RoutingInitializationContext.EndpointMetaData endpointMetaData = value.get(remoteAdd);

            if (endpointMetaData != null && endpointMetaData.getTargetConfigModel().getAdditionalData().getAcquirerId().equals(acquirerId)) {
                return endpointMetaData;
            } 
        }
        return null;
    }
    
    public static void updateEndPointSignOnStatusByEpName(Set<Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>>> entries, String epName, boolean status) {
        for (Map.Entry<String, Map<String, RoutingInitializationContext.EndpointMetaData>> entry : entries) {
            Map<String, RoutingInitializationContext.EndpointMetaData> endpointInfoMap = entry.getValue();
            endpointInfoMap.forEach((targetIp, endpointInfo) -> {
    			if (endpointInfo.getEpName().contains(epName)) {
    				endpointInfo.setSignedOn(status);
                    endpointInfo.setConnectionAlive(status);
    			}
    		});
        }
    }

    public static boolean isDateInBetweenEndPoints(OffsetDateTime min, OffsetDateTime max, OffsetDateTime date) {
        if (min == null || max == null)
            return true;
        return !(date.isBefore(min) || date.isAfter(max));
    }
}
