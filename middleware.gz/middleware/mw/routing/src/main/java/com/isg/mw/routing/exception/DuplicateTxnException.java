package com.isg.mw.routing.exception;

public class DuplicateTxnException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public DuplicateTxnException(String errorMsg) {
        super(errorMsg);
    }

    public DuplicateTxnException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }
}
