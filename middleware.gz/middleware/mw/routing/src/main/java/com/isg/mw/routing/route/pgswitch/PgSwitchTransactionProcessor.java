package com.isg.mw.routing.route.pgswitch;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.model.ResponseMsgType;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.InvalidTxnException;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import com.isg.mw.routing.config.RoutingConstants;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.*;
import com.isg.mw.routing.route.ITransactionProcessor;
import com.isg.mw.routing.route.SwitchRouter;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.util.RouteUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import org.apache.camel.Exchange;
import org.apache.camel.component.netty.NettyConstants;
import org.apache.camel.component.netty.http.NettyHttpEndpoint;
import org.apache.commons.lang.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.concurrent.ExecutorService;

import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchOriginalTransaction;
import static com.isg.mw.mtm.transform.TmmConstants.getTxnEligibleForAutoReversal;
import static com.isg.mw.routing.config.RoutingConstants.*;

@Component
@PropertySource("${spring.config.location}routing-config.properties")
public class PgSwitchTransactionProcessor implements ITransactionProcessor {


    private final Logger logger = LogManager.getLogger(getClass());

    private final Logger rawlogger = LogManager.getLogger("rawLog");

    @Value("${target.timeout.auto.reversal:true}")
    private boolean timeOutAutoReversal;

    @Autowired
    private SwitchRouter switchRouterService;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Autowired
    private ApiTransactionProcessor apiTransactionProcessor;
    
    //private boolean isEncrypt;

    //private boolean isEncrypt;

    //private boolean isEncrypt;

    @Override
    public void processTxnRequest(Exchange exchange) {
        try {
            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            String entityId = routingContext.getEntityId();
            String txnId = processorHelper.generateTransactionId();

            if (routingContext.isTxnLoggingDebug()) {
                rawlogger.info(LogUtils.buildLogMessage(routingContext.getEntityId(),
                                routingContext.getSource().getName(), null, txnId, "Txn Name : {}, {} : [{}]"), null,
                        RoutingConstants.REQUEST);
            }

            logger.info(LogUtils.buildLogMessage(entityId, routingContext.getSource().getName(), null, txnId,
                    "Transaction received"));

            TransactionMessageModel reqSrcTmm = null;
            if (exchange.getFromEndpoint() instanceof NettyHttpEndpoint) {
                reqSrcTmm = apiTransactionProcessor.toPojo(exchange);
            } else {
                byte[] srcRawMsgBytes = (byte[]) exchange.getIn().getBody();

                if (srcRawMsgBytes.length == 0) {
                    throw new InvalidMessageException("Request message is empty");
                }
                String srcRawMsg = new String(srcRawMsgBytes);
                TxnLogger.logPgRawMsg(MsgFlow.INBOUND, srcRawMsg);
                
                /*if (!srcRawMsg.contains("|")) {
                	DecryptService decryptionService = SpringContextBridge.services().getDecryptionService();
                	srcRawMsg = decryptionService.decrypt(srcRawMsg);
                	isEncrypt = true;
                }*/

                reqSrcTmm = MessageTransformer.toPojo(entityId, OffsetDateTime.now(),
                        routingContext.getSource().getName(), srcRawMsg, TlmMessageType.REQUEST, null);
                reqSrcTmm.setRawRequest(TxnLogger.encryptRawMsg(srcRawMsg));
            }

            String acpTraceId = reqSrcTmm.getCardAcceptorId() + reqSrcTmm.getCardAcceptorTerminalId() + reqSrcTmm.getPgData().getPgId();
            reqSrcTmm.setAcpTraceId(acpTraceId);

            setLoggerContext(reqSrcTmm);

            reqSrcTmm.setEntityId(entityId);
            reqSrcTmm.setEpType(EpType.SOURCE);
            reqSrcTmm.setTransactionId(txnId);
            reqSrcTmm.setMaskedTransactionId(MaskingUtility.maskCardNumber(txnId));
            reqSrcTmm.setHashedTransactionId(processorHelper.getHashedValue(txnId));

            reqSrcTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());

            logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
                    "Transaction type: " + reqSrcTmm.getTransactionName() + ", TStan: " + reqSrcTmm.getTerminalStan()
                            + ", MID: " + reqSrcTmm.getCardAcceptorId() + ", TID: "
                            + reqSrcTmm.getCardAcceptorTerminalId()));

            logger.debug("Request Source Transaction Message Model: {}", reqSrcTmm);
            exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);

            processorHelper.checkForDuplicateTxn(exchange);

            processorHelper.validPgTxnType(reqSrcTmm);

            processorHelper.checkForMandatoryFields(reqSrcTmm);

            MapsInfoModel mapsInfoModel = processorHelper.validateMerchant(routingContext, reqSrcTmm);
            logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
                    reqSrcTmm.getTransactionName(), "Merchant validated: " + reqSrcTmm.getCardAcceptorId()));
            reqSrcTmm.setFirstName(mapsInfoModel.getMerchantName());
            reqSrcTmm.setCity(mapsInfoModel.getMerchantCity());
            reqSrcTmm.setMerchantCountryCode(mapsInfoModel.getMerchantShortCountryCode());

            MessageTransformer.decryptTrackData(reqSrcTmm);

            processorHelper.validateBin(routingContext, reqSrcTmm);
            logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(),
                    reqSrcTmm.getMsgType(), txnId, reqSrcTmm.getTransactionName(),
                    "Bin validated"));

            if (TmmConstants.isOriginalTxnRequired(reqSrcTmm.getTransactionName())) {
                reqSrcTmm.setOriginalTmm(fetchOriginalTransaction(reqSrcTmm));
                reqSrcTmm.setSchemeStan(reqSrcTmm.getOriginalTmm().getSchemeStan());
                reqSrcTmm.setHostBatchNo(reqSrcTmm.getOriginalTmm().getHostBatchNo());
                reqSrcTmm.setBatchStatus(reqSrcTmm.getOriginalTmm().getBatchStatus());
                reqSrcTmm.setAuthIdRes(reqSrcTmm.getOriginalTmm().getAuthIdRes());
                reqSrcTmm.setTxnCurrencyCode(reqSrcTmm.getOriginalTmm().getTxnCurrencyCode());
                reqSrcTmm.setCardHolderBillingCurrencyCode(reqSrcTmm.getOriginalTmm().getCardHolderBillingCurrencyCode());
                reqSrcTmm.setEncryptedExpirationDate(reqSrcTmm.getOriginalTmm().getEncryptedExpirationDate());
            }

            TargetConfigModel targetConfigModel = switchRouterService.getTargetEndpoint(routingContext, exchange,
                    reqSrcTmm);
            processorHelper.enrichMerchantData(reqSrcTmm, targetConfigModel);

            if (TargetType.Master.name().equals(targetConfigModel.getTargetType().name())) {
                reqSrcTmm.setSourceMpgId(routingContext.getSource().getAdditionalData().getMpgid());
                logger.info("MPGID Value from Source Config: {}", reqSrcTmm.getSourceMpgId());
            }

            if (TargetType.Visa.name().equals(targetConfigModel.getTargetType().name())
                    && (PgMsgTypeHelper.isRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isOnlineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isRefundAav(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMoRefund(reqSrcTmm.getMsgType(),reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isToRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
            )) {
                TransactionMessageModel.PgData pgData = reqSrcTmm.getPgData();
                pgData.setRefundOriginalTxnPgid(reqSrcTmm.getOriginalTmm().getPgData().getPgId());
                reqSrcTmm.setPgData(pgData);
            }
            logger.info(LogUtils.buildLogMessage(entityId, reqSrcTmm.getSource(), reqSrcTmm.getMsgType(), txnId,
                    reqSrcTmm.getTransactionName(), "Merchant data enriched"));


            if (PgMsgTypeHelper.isCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
                TransactionMessageModel reqCaptureTmm = (TransactionMessageModel) SerializationUtils.clone(reqSrcTmm);
                reqCaptureTmm.setTargetType(reqSrcTmm.getOriginalTmm().getTargetType());
                if (targetConfigModel.getTargetType() == TargetType.Amex) {
                    String yy = MtmUtil.formatDate("YY") + reqSrcTmm.getLocalTxnDate() + reqSrcTmm.getLocalTxnTime();
                    reqCaptureTmm.setLocalTxnTime(yy);
                    reqCaptureTmm.setSecurityControlInfo(reqSrcTmm.getOriginalTmm().getSecurityControlInfo());
                } else {
                    reqCaptureTmm.setLocalTxnTime(reqSrcTmm.getLocalTxnTime());
                }
                reqCaptureTmm.setLocalTxnDate(reqSrcTmm.getLocalTxnDate());
                reqCaptureTmm.setTransmissionTime(reqSrcTmm.getLocalTxnDate() + reqSrcTmm.getLocalTxnTime());
                reqCaptureTmm.setPosEntryMode(reqSrcTmm.getOriginalTmm().getPosEntryMode());
                reqCaptureTmm.setPosConditionCode(reqSrcTmm.getOriginalTmm().getPosConditionCode());
                processorHelper.logToTlm(reqCaptureTmm, routingContext);
            } else {
                processorHelper.logToTlm(reqSrcTmm, routingContext);
            }

            ConnectionType targetConnectionType = targetConfigModel.getConnections().get(0).getType();
            reqSrcTmm.setConnectionType(targetConnectionType);

            if ((PgMsgTypeHelper.isCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isPreauthReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode()))
                    || PgMsgTypeHelper.isMotoCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
                validateDependentTransaction(reqSrcTmm);
                processorHelper.processVoidOrReversal(exchange, reqSrcTmm);
            } else {
                processorHelper.processNormalTxn(exchange, reqSrcTmm);
            }
        } catch (Exception e) {
            throw new RequestProcessingException("Error while processing the request message ", e);
        }
    }

    /*private void processPgSwitchTxn(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQ_SRC_TMM, reqSrcTmm);
        exchange.getIn().setBody(reqSrcTmm);
    }*/

    @Override
    public void processTxnResponse(Exchange exchange) {
        Object requestDeclined = exchange.getIn().getHeaders().get(EXCHANGE_HEADER_REQUEST_DECLINED);
        if (processorHelper.isRequestDeclined(requestDeclined)) return;

        TransactionMessageModel responseSourceTmm = exchange.getIn().getBody(TransactionMessageModel.class);
        try {
            TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
                    .get(EXCHANGE_HEADER_REQ_SRC_TMM);
            String onlineRefundTarget = reqSrcTmm.getTarget();

            MessageContext targetMsgContext = null;
            responseSourceTmm = exchange.getIn().getBody(TransactionMessageModel.class);
            processorHelper.setSourceDataInResponse(reqSrcTmm, responseSourceTmm);
            logger.info(LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(),
                    responseSourceTmm.getMsgType(), responseSourceTmm.getTransactionId(),
                    responseSourceTmm.getTransactionName(), "Transaction response received"));

            RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
            processorHelper.checkForMandatoryFields(responseSourceTmm);

            logger.info(
                    LogUtils.buildLogMessage(responseSourceTmm.getEntityId(), responseSourceTmm.getTarget(),
                            responseSourceTmm.getMsgType(), responseSourceTmm.getTransactionId(),
                            responseSourceTmm.getTransactionName(), "Constructing transaction response for target"),
                    reqSrcTmm.getSource());

            responseSourceTmm.setSourceProcessor(routingContext.getSource().getSourceProcessor());

            String pgResponse = null;
            ConnectionType connectionType = routingContext.getSource().getConnectionType();
            if (connectionType == ConnectionType.ISO) {
                targetMsgContext = MessageTransformer.constructMessage(responseSourceTmm,
                        routingContext.getSource().getName());
                pgResponse = MessageTransformer.getPgResponse(targetMsgContext);
                String reqMsgLength = pgResponse.split("\\|")[0];
                TxnLogger.logPgRawMsg(MsgFlow.OUTBOUND, pgResponse);
                TxnLogger.logPgTxnDetail(MsgFlow.OUTBOUND, pgResponse.substring(reqMsgLength.length() + 1), targetMsgContext.getTransactionMessageModel());
                /*if (isEncrypt) {
                	EncryptService encryprtionService = SpringContextBridge.services().getEncryptionService();
                	pgResponse = encryprtionService.encrypt(pgResponse);
                }*/
                logger.trace("Response to PG: {}", pgResponse);

            } else if (connectionType == ConnectionType.API) {
                targetMsgContext = apiTransactionProcessor.constructApiResponse(exchange);
                pgResponse = (String) targetMsgContext.getRawMsg();
            }

            TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();
            responseTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
            responseTargetTmm.setResponseSentTime(OffsetDateTime.now());
            responseTargetTmm.setAcpTraceId(responseSourceTmm.getAcpTraceId());

            if (PgMsgTypeHelper.isCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoCapture(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
                responseTargetTmm.setPostalCode(reqSrcTmm.getOriginalTmm().getPostalCode());
                responseTargetTmm.setAtmPinOffsetData(reqSrcTmm.getOriginalTmm().getAtmPinOffsetData());
                responseTargetTmm.setSettlementProcessingFee(reqSrcTmm.getOriginalTmm().getSettlementProcessingFee());
            }

            logger.trace("Response Target Transaction message model: {}", responseTargetTmm);
            processorHelper.logToTlm(responseTargetTmm, routingContext);

            if (responseTargetTmm.getResCode() != null && responseTargetTmm.getResCode().equals(TmmConstants.RES_CODE_SUCCESS)
                    && (PgMsgTypeHelper.isReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMoReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isPreauthReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isToReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMoReversal(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode()))) {
                processorHelper.updateOriginalTxnAndLogTlm(reqSrcTmm.getOriginalTmm(), "N", routingContext);
            }

            if (connectionType == ConnectionType.ISO) {
                ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(pgResponse.getBytes());
                Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);
                openedChannel.writeAndFlush(rawMsgByteBuf);
                openedChannel.close();
            } else if (connectionType == ConnectionType.API) {
                //apiTransactionProcessor.setEncryptedResponse(exchange, pgResponse);
                apiTransactionProcessor.setApiHeader(exchange);
                // removing custom headers set during transaction flow while sending response
                // as it causes issue in sending the response.
                processorHelper.removeCustomHeaders(exchange);
                exchange.getIn().setBody(pgResponse);
            }
            if (PgMsgTypeHelper.isOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoOnlineOfflineRefund(reqSrcTmm.getMsgType(), reqSrcTmm.getProcessingCode())) {
                ExecutorService executorService = RouteUtil.getExecutorService();
                executorService.submit(() -> {
                    reqSrcTmm.setTarget(onlineRefundTarget);
                    processorHelper.processNormalTxn(exchange, reqSrcTmm);
                });
            }
        } catch (Exception e) {
            logger.error("", e);
        } finally {
            responseSourceTmm = null;
        }
    }

    @Override
    public void processTxnDecline(Exchange exchange) {
        TransactionMessageModel declineModel = new TransactionMessageModel();
        Throwable exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class).getCause();
        TransactionMessageModel reqSrcTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
                .get(EXCHANGE_HEADER_REQ_SRC_TMM);
        TransactionMessageModel reqTargetTmm = (TransactionMessageModel) exchange.getIn().getHeaders()
                .get(EXCHANGE_HEADER_REQ_TGT_TMM);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);

        logger.error("Exception :", exception);

        String resCode = null;
        String resDesc = null;

        switch (exception.getClass().getSimpleName()) {

            case "InvalidMerchantException":
                resCode = TmmConstants.RES_CODE_INVALID_MERCHANT;
                resDesc = "Merchant is invalid";
                break;

            case "InvalidBinException":
                resCode = TmmConstants.RES_CODE_INVALID_BIN;
                resDesc = "Bin is not valid";
                break;

            case "RequestValidationException":
                resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
                resDesc = exception.getMessage();
                break;

            case "TargetNoResponseException":
            case "IllegalStateException":
                if (timeOutAutoReversal &&
                        getTxnEligibleForAutoReversal().contains(reqSrcTmm.getTransactionName())) {
                    doTimeOutReversal(exchange, reqSrcTmm, reqTargetTmm, routingContext);
                    if (routingContext.getSource().getConnectionType() == ConnectionType.API) {
                        TransactionTypeConfig transactionTypeConfig = MessageTransformer.identifyTargetTxnTypeConfig(TmmConstants.PG_REVERSAL_RESPONSE, TargetType.Pg, routingContext.getSource().getName());
                        String declineMsg = apiTransactionProcessor.getEncryptedApiResponse(ResponseMsgType.SUCCESS, "Target not available", reqSrcTmm, transactionTypeConfig, exchange);
                        processorHelper.removeCustomHeaders(exchange);
                        exchange.getIn().setBody(declineMsg);
                        return;
                    } else {
                        resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                        resDesc = "Target is Not Responding";
                    }
                } else {
                    resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                    resDesc = "Target is Not Responding";
                }
                break;

            case "ApiFailedResponseException":
                ApiFailedResponseException apiFailedResponseException = (ApiFailedResponseException) exception;
                resCode = TmmConstants.RES_CODE_INVALID_TXN;
                resDesc = apiFailedResponseException.getArgs()[1].toString();
                break;

//            case "InvalidTxnException":
            case "CaptureAmountExceededException":
                resCode = TmmConstants.RES_CODE_CAPTURE_EXCEEDED;
                resDesc = "Capture amount exceeded";
                break;

            case "FormatErrorException":
                resCode = TmmConstants.RES_CODE_FORMAT_ERROR;
                resDesc = "Format error";
                break;

            case "NullPointerException":
            case "InternalServerError":
            case "SystemErrorException":
                resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
                resDesc = "It will be internal , null or system error ";
                break;

            case "InvalidCardNumberException":
                resCode = TmmConstants.RES_CODE_INVALID_CARD_NUMBER;
                resDesc = "Invalid card number";
                break;

            case "ExecutionException":
            case "InterruptedException":
                resCode = TmmConstants.RES_CODE_ISSUER_UNAVAILABLE;
                resDesc = "Issuer unavailable";
                break;

            case "IssuerUnavailableException":
                resCode = TmmConstants.RES_CODE_ISSUER_NOT_AVAILABLE;
                resDesc = "Issuer unavailable";
                break;

            case "InvalidVoidOrReversalDataException":
            case "NotFound":
                resCode = TmmConstants.RES_CODE_ORIGINAL_TXN_NOT_FOUND;
                resDesc = "Original txn not found";
                break;

            case "InvalidTxnAmtException":
                resCode = TmmConstants.RES_CODE_INVALID_TXN_AMT;
                resDesc = "Invalid txn amount";
                break;

            case "MacValidationException":
                resCode = TmmConstants.RES_CODE_INVALID_MAC;
                resDesc = "Invalid mac";
                break;

            case "LessReversalAmountException":
                resCode = TmmConstants.RES_CODE_REVERSAL_EXCEEDED;
                resDesc = "Less reversal amount";
                break;

            case "ReversalAmountExceededException":
                resCode = TmmConstants.RES_CODE_REVERSAL_EXCEEDED;
                resDesc = "Reversal amount exceeded";
                break;

            case "RefundAmountExceededException":
                resCode = TmmConstants.RES_CODE_REFUND_EXCEEDED;
                resDesc = "Refund amount exceeded";
                break;

            case "ApiRequestValidationException":
                resDesc = exception.getMessage();
                String apiResponse = apiTransactionProcessor.getEncryptedApiResponse(ResponseMsgType.ERROR, resDesc, null, null, exchange);
                exchange.getIn().setBody(apiResponse);
                return;

            case "DuplicateTxnException":
                resCode = TmmConstants.RES_CODE_DATA_ERROR;
                break;
            default:
                resCode = TmmConstants.RES_CODE_SYSTEM_ERROR;
                resDesc = "System Error";
                break;
        }
        if (reqSrcTmm == null) {
            declineModel.setTransactionName("decline.pg.purchase.request");
            declineModel.setEntityId(routingContext.getEntityId());
        } else {
            declineModel = reqSrcTmm;
            declineModel.setTransactionName("decline." + reqSrcTmm.getTransactionName());
        }

        declineModel.setResCode(resCode);

        logger.trace("Decline Response Code: {}, Decline txn: {}", declineModel.getResCode(),
                declineModel.getTransactionName());

        declineModel.setSourceProcessor(routingContext.getSource().getSourceProcessor());

        if (routingContext.getSource().getConnectionType() == ConnectionType.ISO) {
            sendDeclineMessage(exchange, declineModel, reqSrcTmm, routingContext, resCode);
        } else if (routingContext.getSource().getConnectionType() == ConnectionType.API) {
            String resMsg = apiTransactionProcessor.processTxnDecline(declineModel, resCode, resDesc, exchange);
            processorHelper.removeCustomHeaders(exchange);
            exchange.getIn().setBody(resMsg);
        }
        declineModel = null;
    }

    private void sendDeclineMessage(Exchange exchange, TransactionMessageModel declineModel, TransactionMessageModel reqSrcTmm, RoutingContext routingContext, String resCode) {
        MessageContext targetMsgContext = MessageTransformer.constructMessage(declineModel,
                reqSrcTmm.getSource());

        TransactionMessageModel responseTargetTmm = targetMsgContext.getTransactionMessageModel();
        //setting drcr flag to N as txn is declined
        responseTargetTmm.setDrcrFlag("N");
        responseTargetTmm.setResCode(resCode);
        responseTargetTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        processorHelper.asyncLogToTlm(responseTargetTmm, routingContext);
        String pgResponse = MessageTransformer.getPgResponse(targetMsgContext);
        String reqMsgLength = pgResponse.split("\\|")[0];
        TxnLogger.logPgTxnDetail(MsgFlow.OUTBOUND, pgResponse.substring(reqMsgLength.length() + 1), responseTargetTmm);
        TxnLogger.logPgRawMsg(MsgFlow.OUTBOUND, pgResponse);
        /*if (isEncrypt) {
        	EncryptService encryprtionService = SpringContextBridge.services().getEncryptionService();
        	pgResponse = encryprtionService.encrypt(pgResponse);
        }*/

        logger.trace("Decline Transaction message model: {}", responseTargetTmm);
        logger.trace("Response to PG: {}", pgResponse);
        exchange.getIn().getHeaders().put(EXCHANGE_HEADER_REQUEST_DECLINED, true);

        ByteBuf rawMsgByteBuf = Unpooled.copiedBuffer(pgResponse.getBytes());
        Channel openedChannel = exchange.getProperty(NettyConstants.NETTY_CHANNEL, Channel.class);
        openedChannel.writeAndFlush(rawMsgByteBuf);
        openedChannel.close();
        reqSrcTmm = null;
        responseTargetTmm = null;

    }

    private void doTimeOutReversal(Exchange exchange, TransactionMessageModel reqSrcTmm, TransactionMessageModel reqTargetTmm, RoutingContext routingContext) {
        String targetScheme = exchange.getIn().getHeaders().get(EXCHANGE_HEADER_TARGET_SCHEME).toString();
        String txnName;
        boolean isApiRequest = Boolean.FALSE;
        if (targetScheme.startsWith("netty://tcp://")) {
            reqSrcTmm.setTargetIpAndPort(RouteUtil.fetchIpAndPort(targetScheme));
            txnName = TmmConstants.PG_REVERSAL_REQUEST;
        } else {
            reqSrcTmm.setTargetIpAndPort(targetScheme);
            txnName = TmmConstants.PG_CYBS_REVERSAL_REQUEST;
            isApiRequest = Boolean.TRUE;
            for (TargetConfigModel targetModel : routingContext.getTargets()) {
                if (targetModel.getName().equals(reqSrcTmm.getTarget()) && targetModel.getTargetType() == TargetType.Amex) {
                    txnName = TmmConstants.PG_REVERSAL_REQUEST;
                    reqSrcTmm.setPosCaptureCode(reqTargetTmm.getPosCaptureCode());
                    reqSrcTmm.setPosEntryMode(reqTargetTmm.getPosEntryMode());
                    reqSrcTmm.setAquirerIdCode(reqTargetTmm.getAquirerIdCode());
                    reqSrcTmm.setStan(reqTargetTmm.getStan());
                    reqSrcTmm.setTerminalStan(reqTargetTmm.getStan());
                    reqSrcTmm.setLocalTxnDate(reqTargetTmm.getLocalTxnDate());
                    reqSrcTmm.setSecurityControlInfo(reqTargetTmm.getSecurityControlInfo());
                    break;
                }
            }
        }
        ExecutorService executorService = RouteUtil.getExecutorService();
        String finalTxnName = txnName;
        boolean finalIsApiRequest = isApiRequest;
        // Asynchronously generating auto reversal
        executorService.submit(() -> {
            try {
                processorHelper.generateAutoReversalTxn(reqSrcTmm, reqTargetTmm, SourceProcessor.PG_SWITCH, finalTxnName, exchange, finalIsApiRequest);
            } catch (Exception e) {
                logger.error("Error while generating reversal", e);
            }
        });
    }

    /*private void logRawMessageToTlm(String sourceRawMsg, String txnId, RoutingContext routingContext) {
        if (routingContext.isTxnLoggingDebug()) {
            TransactionMessageModel rawTmm = new TransactionMessageModel();
            rawTmm.setTransactionId(txnId);
            rawTmm.setRawRequest(sourceRawMsg);
            processorHelper.logToTlm(rawTmm, routingContext);
        }
    }*/

    private void validateDependentTransaction(TransactionMessageModel dependentTxnTmm) {
        Integer currencyDecimal = dependentTxnTmm.getOriginalTmm().getCurrencyDecimals();
        Double originalTxnAmt = Double.parseDouble(dependentTxnTmm.getOriginalTmm().getTxnAmt()) / currencyDecimal;

        Double totDependentTxnAmt = (dependentTxnTmm.getOriginalTmm().getDependentTotTxnAmt()
                + (Double.parseDouble(dependentTxnTmm.getTxnAmt()))) / currencyDecimal;


        boolean isReversal = ((PgMsgTypeHelper.isReversal(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode())) ||
                (PgMsgTypeHelper.isMotoReversal(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode())));
        if (isReversal && (PgMsgTypeHelper.isCapture(dependentTxnTmm.getOriginalTmm().getMsgType(), dependentTxnTmm.getOriginalTmm().getProcessingCode())
                || PgMsgTypeHelper.isMotoCapture(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode()))) {
            throw new InvalidTxnException("Void/Reversal Not Applicable On Capture");
        }
        if (isReversal && totDependentTxnAmt.compareTo(originalTxnAmt) < 0) {
            throw new LessReversalAmountException(
                    ("Reversal Txn amount is less than original, Original Txn Amt: " + originalTxnAmt + ", Dependent Txn Total Amt: "
                            + totDependentTxnAmt));
        }

        if (totDependentTxnAmt.compareTo(originalTxnAmt) > 0) {
            if (isReversal)
                throw new ReversalAmountExceededException(
                        ("Reversal Txn amount is greater than original, Original Txn Amt: " + originalTxnAmt + ", Dependent Txn Total Amt: "
                                + totDependentTxnAmt));
            else if (PgMsgTypeHelper.isCapture(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode())
                    || PgMsgTypeHelper.isMotoCapture(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode()))
                throw new CaptureAmountExceededException(
                        ("Txn amount has been exceeded, Original Txn Amt: " + originalTxnAmt + ", Dependent Txn Total Amt: "
                                + totDependentTxnAmt));
            else if ((PgMsgTypeHelper.isRefund(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode()))
                    || (PgMsgTypeHelper.isOnlineOfflineRefund(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode()))
                    || (PgMsgTypeHelper.isMotoOnlineOfflineRefund(dependentTxnTmm.getMsgType(), dependentTxnTmm.getProcessingCode())))
                throw new RefundAmountExceededException(
                        ("Txn amount has been exceeded, Original Txn Amt: " + originalTxnAmt + ", Dependent Txn Total Amt: "
                                + totDependentTxnAmt));
        }

    }


    @Override
    public SourceProcessor getSourceProcessor() {
        return SourceProcessor.PG_SWITCH;
    }
}