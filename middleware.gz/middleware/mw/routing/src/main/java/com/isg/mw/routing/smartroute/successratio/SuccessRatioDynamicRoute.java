package com.isg.mw.routing.smartroute.successratio;

import com.isg.mw.cache.mgmt.config.CacheTargetPaymentModeAndOptions;
import com.isg.mw.cache.mgmt.config.MerchantPreferredTarget;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.LOFO;
import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.constants.StatsType;
import com.isg.mw.core.model.constants.Tokenize;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.InvalidBinException;
import com.isg.mw.routing.exception.PaymentOptionMismatchException;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import com.isg.mw.routing.smartroute.AbstractSmartRoute;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_API_TXN_MODEL;
import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_ROUTING_CTX;

@Component
public class SuccessRatioDynamicRoute extends AbstractSmartRoute {

    private final Logger logger = LogManager.getLogger();

    @Autowired
    private CacheServices cacheService;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    /**
     * Targets sorted in descending order of success ratio.
     */
    protected static final Map<String, List<TargetKey>> successRatioSortedList = new HashMap<>();

    @Override
    public synchronized void calculateSuccessRatio(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, OffsetDateTime threadCacheLastCalculatedDate) {
        if (isThreadAllowedToCalculate(sourceConfigModel, threadCacheLastCalculatedDate))
            return;

        super.calculateSuccessRatio(sourceConfigModel, smartRouteConfigModel, threadCacheLastCalculatedDate);
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        if (checkSuccessRatioForAllTargetsIsSame(targets)) {
            logger.info("All the targets for the source {} has same success ratio", sourceConfigModel.getName());
            return;
        }
        sortTargetsBySuccessRatio(sourceConfigModel.getId().toString(), targets);
        doSwitching(sourceConfigModel, smartRouteConfigModel, targets);
        //Scenario: if any target is not alive then after above calculation it will get minimum routing share
        //but we have to do fallback calculation again to make sure it still get 0 in current routing
        if (!allTargetsAreAlive(targets, null)) {
            targets.forEach((key, value) -> this.fallbackRoutingCalculation(sourceConfigModel, smartRouteConfigModel, key.getTargetId(), value.isAlive(), targets));
        }
    }

    private boolean checkSuccessRatioForAllTargetsIsSame(Map<TargetKey, TargetInfo> targets) {
        DoubleSummaryStatistics doubleSummaryStatistics = targets.values().stream().mapToDouble(TargetInfo::getCurrentSuccessRatio).summaryStatistics();
        return Double.compare(doubleSummaryStatistics.getMax(), doubleSummaryStatistics.getMin()) == 0;
    }

    @Override
    public TargetConfigModel getTxnTarget(Exchange exchange, TransactionMessageModel reqSrcTmm) {
        ApiTxnModel apiTxnModel = (ApiTxnModel) exchange.getIn().getHeader(EXCHANGE_HEADER_API_TXN_MODEL);
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        // Payment Mode Option Availability check
        if (apiTxnModel != null) {
            // validate the merchant
            MerchantMasterModel merchantMaster = processorHelper.validateMerchantMaster(sourceConfigModel.getEntityId(), apiTxnModel.getMid());
            if (merchantMaster != null && merchantMaster.getMcrEnabled().equalsIgnoreCase("Y")) {
                return validateMerchantChoiceRouting(apiTxnModel, routingContext, merchantMaster);
            } else {
                List<Long> targetIdList = validateTargetOptionAvailability(apiTxnModel, routingContext,reqSrcTmm);
                if (targetIdList.size() == 1) {
                    logger.debug("Target found based on success ratio : {} ", targetIdList.get(0));
                    Long targetId = targetIdList.get(0);
                    return getTargetConfigById(routingContext, targetId.toString());
                } else {
                    if (targetIdList != null && !targetIdList.isEmpty()) {
                        TargetConfigModel finalTxnTargetBaseOnSuccessRatio = getTxnTargetBaseOnSuccessRatio(exchange);;
                        Long targetId = targetIdList.stream().filter(tgtId -> tgtId.equals(finalTxnTargetBaseOnSuccessRatio.getId())).findFirst().orElse(0L);
                        logger.debug("Target found based on success ratio : {} and Target payment mode and option : {} ", finalTxnTargetBaseOnSuccessRatio.getId(), targetId);
                        if (targetId != 0L) {
                            return getTargetConfigById(routingContext, targetId.toString());
                        } else {
                            return getTargetBasedOnRoundRobinScheduling(routingContext, sourceConfigModel, targetIdList);
                        }
                    } else {
                        throw new PaymentOptionMismatchException("Payment option mismatch for given payment mode Id : " + apiTxnModel.getPayModeId() + " and payment mode option: " + apiTxnModel.getPayModeOptionId(),routingContext.getEntityId(),apiTxnModel.getMid(),apiTxnModel.getMerchantTxnRefNo());
                    }
                }
            }
        }else{
           return getTxnTargetBaseOnSuccessRatio(exchange);
        }
    }

    private TargetConfigModel getTargetBasedOnRoundRobinScheduling(RoutingContext routingContext, SourceConfigModel sourceConfigModel, List<Long> targetIdList) {
        Optional<TargetConfigModel> targetConfigModel1 = null;
        int srcTotalTxnCount = cacheUtil.getSourceTotalTxnCount(cacheHelper.getSourceMapKey(sourceConfigModel),
                sourceConfigModel.getId().toString());
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        for (Long tgtId : targetIdList) {
            TargetInfo targetInfo = targets.get(new TargetKey(tgtId.toString()));
            Double computedRoutingPercent = ((double) targetInfo.getTotalTxnCount() / (double) srcTotalTxnCount) * 100;
            double currentRoutingPercent = (double) 100 / (double) targetIdList.size();
            boolean isTargetEligible = computedRoutingPercent.compareTo(currentRoutingPercent) <= 0;
            if (isTargetEligible && targetInfo.isAlive()) {
                targetConfigModel1 = routingContext.getTargets().stream().filter(targetConfigModel -> targetConfigModel.getId().equals(tgtId)).findFirst();
            }
            if (targetConfigModel1 != null && targetConfigModel1.isPresent()) {
                break;
            }
        }
        return targetConfigModel1.get();
    }

    public List<Long> getTargetIdList(ApiTxnModel apiTxnModel, RoutingContext routingContext) {
        List<Long> targetIdList;
        Set<CacheTargetPaymentModeAndOptions> tgtPayModeAndOptData = getTargetPayModeAndOptionsData(routingContext, apiTxnModel);
        targetIdList = tgtPayModeAndOptData.stream().map(CacheTargetPaymentModeAndOptions::getTargetPaymentMode).map(TargetPaymentModesModel::getTargetId).collect(Collectors.toList());
        return targetIdList;
    }

    private Set<CacheTargetPaymentModeAndOptions> getTargetPayModeAndOptionsData(RoutingContext routingContext, ApiTxnModel apiTxnModel) {
        return srCacheService.getTargetPayModeAndOptionsDataList(routingContext.getEntityId(), apiTxnModel.getPayModeId(), apiTxnModel.getPayModeOptionId());
    }

    public TargetConfigModel getTxnTargetBaseOnSuccessRatio(Exchange exchange) {
        RoutingContext routingContext = (RoutingContext) exchange.getIn().getHeader(EXCHANGE_HEADER_ROUTING_CTX);
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        logger.info("Getting target for the source: {}", sourceConfigModel.getName());

        Map<String, SourceInfo> sourceData = cacheUtil.getSourceData(cacheHelper.getSourceMapKey(sourceConfigModel));
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
        AtomicReference<TargetConfigModel> targetConfigModel = new AtomicReference<>();
        Integer srcTotalTxnCount = sourceData.get(sourceConfigModel.getId().toString()).getTotalTxnCount();
        if (!allTargetsAreAlive(targets, null)) {
            srcTotalTxnCount = getAllAliveTargets(targets, null)
                    .values().stream().mapToInt(TargetInfo::getTotalTxnCount).sum();
        }

        if (successRatioSortedList.get(sourceConfigModel.getId().toString()) != null) {
            logger.info("Success ratio sorted list Data after success ratio calculation :: {}", successRatioSortedList);
            for (TargetKey targetKey : successRatioSortedList.get(sourceConfigModel.getId().toString())) {
                if (setTarget(routingContext, targets, targetConfigModel, srcTotalTxnCount, targetKey))
                    break;
            }
        } else {
            logger.info("Targets Data before success ratio calculation :: {}", targets);
            for (TargetKey targetKey : targets.keySet()) {
                if (setTarget(routingContext, targets, targetConfigModel, srcTotalTxnCount, targetKey))
                    break;
            }
        }

        logger.info("Target identified for the source: {} is {}", sourceConfigModel.getName(),
                targetConfigModel.get().getName());
        return targetConfigModel.get();
    }

    @Override
    public synchronized void setTargetIsAlive(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, String targetId, boolean isAlive) {
        fallbackRoutingCalculation(sourceConfigModel, smartRouteConfigModel, targetId, isAlive);
    }

    private void doSwitching(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, Map<TargetKey, TargetInfo> targets) {
        //Getting the first position target (which has highest success ratio)
        TargetKey highestSRTargetKey = successRatioSortedList.get(sourceConfigModel.getId().toString()).get(0);
        targets.forEach((targetKey, targetInfo) -> {
            if (!targetKey.getTargetId().equals(highestSRTargetKey.getTargetId())) {
                Double routingPercentForTarget = getSwitchingPercent(sourceConfigModel,
                        smartRouteConfigModel, targetKey, targets);
                String targetMapKey = cacheHelper.getTargetMapKey(sourceConfigModel);
                Double updatedRoutingPercent = cacheUtil.getTargetCurrentRoutingPer(targetMapKey,
                        highestSRTargetKey) + routingPercentForTarget;
                TargetInfo highestSrTgInfo = targets.get(highestSRTargetKey);

                compareAndSetRpTrendIndicator(highestSrTgInfo, updatedRoutingPercent);
                highestSrTgInfo.getDynamicTargetInfo().setCurrentRoutingPercent(updatedRoutingPercent);
                highestSrTgInfo.getDynamicTargetInfo().setInitialRoutingPercent(updatedRoutingPercent);
                cacheUtil.putTargetData(targetMapKey, highestSRTargetKey, highestSrTgInfo);

                logger.info("Current routing percent for the target {} is now {}",
                        highestSrTgInfo.getTargetName(), updatedRoutingPercent);
            }
        });
    }

    private Double getSwitchingPercent(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, TargetKey targetKey,
                                       Map<TargetKey, TargetInfo> targets) {
        TargetInfo targetInfo = targets.get(targetKey);
        SmartRouteTargetDefinition smartRouteTargetDefinition = getTargetDefinitionById(smartRouteConfigModel, targetKey.getTargetId());

        Double toReturnRoutingPercent;
        Double toUpdateInCurrentTargetRoutingPercent;

        /*
          $ If target's success ratio falls below threshold then it should maintain
          minimum routing percent and remaining (current routing percent - minimum) should be returned
          to the best performing target.

          $ If target's success ratio is not below threshold then it should deduct the
          switching percent from its current routing percent and return the switching percent
         */

        if (isTargetBelowThreshold(targetInfo, smartRouteConfigModel)) {
            toUpdateInCurrentTargetRoutingPercent = smartRouteTargetDefinition.getMinRouteShare();
            toReturnRoutingPercent = targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent() - smartRouteTargetDefinition.getMinRouteShare();
        } else {
            toUpdateInCurrentTargetRoutingPercent = targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent() - smartRouteConfigModel.getRouteSwitchingPercent();
            if (toUpdateInCurrentTargetRoutingPercent.compareTo(smartRouteTargetDefinition.getMinRouteShare()) < 0) {
                toUpdateInCurrentTargetRoutingPercent = smartRouteTargetDefinition.getMinRouteShare();
                toReturnRoutingPercent = targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent() - smartRouteTargetDefinition.getMinRouteShare();
            } else {
                toReturnRoutingPercent = smartRouteConfigModel.getRouteSwitchingPercent();
            }
        }

        compareAndSetRpTrendIndicator(targetInfo, toUpdateInCurrentTargetRoutingPercent);
        targetInfo.getDynamicTargetInfo().setCurrentRoutingPercent(toUpdateInCurrentTargetRoutingPercent);
        targetInfo.getDynamicTargetInfo().setInitialRoutingPercent(toUpdateInCurrentTargetRoutingPercent);

        cacheUtil.putTargetData(cacheHelper.getTargetMapKey(sourceConfigModel), targetKey, targetInfo);

        return toReturnRoutingPercent;
    }

    /**
     * Sorting the targets in descending order of their success ratio
     *
     * @param srcId
     * @param targets
     */
    private void sortTargetsBySuccessRatio(String srcId, Map<TargetKey, TargetInfo> targets) {
        successRatioSortedList.put(srcId, new ArrayList<>(targets.size()));
        List<Map.Entry<TargetKey, TargetInfo>> targetList = new ArrayList<>(targets.entrySet());

        targetList.sort((target1, target2) ->
                (target2.getValue().getCurrentSuccessRatio().compareTo(target1.getValue().getCurrentSuccessRatio())));

        for (Map.Entry<TargetKey, TargetInfo> targetEntry : targetList) {
            successRatioSortedList.get(srcId).add(targetEntry.getKey());
        }
        logger.info("Targets sorted by success ratio: {}", successRatioSortedList);
    }

    private boolean setTarget(RoutingContext routingContext, Map<TargetKey, TargetInfo> targets, AtomicReference<TargetConfigModel> targetConfigModel, Integer srcTotalTxnCount, TargetKey targetKey) {
        TargetInfo targetInfo = targets.get(targetKey);
        Double computedRoutingPercent = ((double) targetInfo.getTotalTxnCount() / (double) srcTotalTxnCount) * 100;
        if (computedRoutingPercent.compareTo(targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent()) < 0 && targetInfo.isAlive()) {
            logger.info("Selected TargetInfo: {}  with computedRoutingPercent : {} ", targetInfo,computedRoutingPercent);
            TargetConfigModel targetConfigById = getTargetConfigById(routingContext, targetKey.getTargetId());
            targetConfigModel.set(targetConfigById);
            return true;
        }
        return false;
    }

    public void fallbackRoutingCalculation(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, String targetId, boolean isAlive) {
        isAlive = getAliveFromTestFile(sourceConfigModel, targetId, isAlive);
        String targetMapKey = cacheHelper.getTargetMapKey(sourceConfigModel);
        Map<TargetKey, TargetInfo> targets = cacheUtil.getTargetData(targetMapKey);
        if (!fallbackCalNeeded(targets, targetId, isAlive))
            return;

        fallbackRoutingCalculation(sourceConfigModel, smartRouteConfigModel, targetId, isAlive, targets);
    }

    private void fallbackRoutingCalculation(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, String targetId, boolean isAlive, Map<TargetKey, TargetInfo> targets) {
        String targetMapKey = cacheHelper.getTargetMapKey(sourceConfigModel);

        if ((allTargetsAreAlive(targets, null) && isAlive) || (allTargetsAreAlive(targets, targetId) && isAlive)) {

            // All the targets are alive, they should get their initial routing percent
            for (Map.Entry<TargetKey, TargetInfo> allTargets : targets.entrySet()) {
                TargetInfo targetInfo = allTargets.getValue();
                Double initRoutePer = targetInfo.getDynamicTargetInfo().getInitialRoutingPercent();
                compareAndSetRpTrendIndicator(targetInfo, initRoutePer);
                targetInfo.getDynamicTargetInfo().setCurrentRoutingPercent(initRoutePer);
                targetInfo.setAlive(isAlive);
                cacheUtil.putTargetData(targetMapKey, allTargets.getKey(), targetInfo);
            }
            logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.FAIL_OVER);
            return;
        } else if ((allTargetsAreDead(targets, null) && isAlive) || (allTargetsAreDead(targets, targetId)) && isAlive) {
            // All the targets were previously dead, and now only 1 of the target is alive.
            // So, it should get 100%
            Map.Entry<TargetKey, TargetInfo> target = getTargetById(targets, targetId);
            TargetInfo targetInfo = target.getValue();
            compareAndSetRpTrendIndicator(targetInfo, 100d);
            targetInfo.getDynamicTargetInfo().setCurrentRoutingPercent(100d);
            targetInfo.setAlive(isAlive);
            cacheUtil.putTargetData(targetMapKey, target.getKey(), targetInfo);
            logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.FAIL_OVER);
            return;
        }

        fallbackRoutingDistribution(sourceConfigModel, smartRouteConfigModel, targetId, isAlive, targets);
    }

    private void fallbackRoutingDistribution(SourceConfigModel sourceConfigModel, SmartRouteConfigModel smartRouteConfigModel, String targetId, boolean isAlive, Map<TargetKey, TargetInfo> targets) {
        String targetMapKey = cacheHelper.getTargetMapKey(sourceConfigModel);
        for (Map.Entry<TargetKey, TargetInfo> allEntries : targets.entrySet()) {
            TargetKey currTarKey = allEntries.getKey();
            TargetInfo currTarInfo = allEntries.getValue();
            if (currTarKey.getTargetId().equals(targetId)) {
                Double percentToBeDistributed = 0d;
                TargetInfo targetInfo = allEntries.getValue();
                Map<TargetKey, TargetInfo> allAliveTargets = getAllAliveTargets(targets, targetId);
                if ((targetInfo.isAlive() && !isAlive) || (!targetInfo.isAlive() && !isAlive)) {
                    // target was alive before and dead now
                    // target was dead before and dead now (applicable when this method is called from calculateSuccessRatio
                    Double deadTarCurrRoutePer = targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent();
                    compareAndSetRpTrendIndicator(currTarInfo, 0d);
                    cacheUtil.updateTargetTrendIndicator(targetMapKey, currTarKey, currTarInfo.getDynamicTargetInfo().getRpTrendIndicator());
                    cacheUtil.updateTargetCurrentRoutingPer(targetMapKey, currTarKey, 0d);
                    percentToBeDistributed += deadTarCurrRoutePer;

                    if (allAliveTargets == null || allAliveTargets.isEmpty()) {
                        cacheUtil.updateTargetIsAlive(targetMapKey, currTarKey, isAlive);
                        logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.FAIL_OVER);
                        logger.error("All the targets are dead");
                        return;
                    }

                    percentToBeDistributed /= allAliveTargets.size();

                    for (Map.Entry<TargetKey, TargetInfo> entry : allAliveTargets.entrySet()) {
                        TargetKey targetKey1 = entry.getKey();
                        Double aliveTarCurrRoutePer = entry.getValue().getDynamicTargetInfo().getCurrentRoutingPercent();
                        aliveTarCurrRoutePer += percentToBeDistributed;
                        compareAndSetRpTrendIndicator(entry.getValue(), aliveTarCurrRoutePer);
                        cacheUtil.updateTargetTrendIndicator(targetMapKey, targetKey1, entry.getValue().getDynamicTargetInfo().getRpTrendIndicator());
                        cacheUtil.updateTargetCurrentRoutingPer(targetMapKey, targetKey1, aliveTarCurrRoutePer);
                    }
                    cacheUtil.updateTargetIsAlive(targetMapKey, currTarKey, isAlive);
                    logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.FAIL_OVER);
                } else if (!targetInfo.isAlive() && isAlive) {
                    //target was dead before and alive now
                    double totAliveRoutePer = allAliveTargets.values().stream().mapToDouble(value -> value.getDynamicTargetInfo().getCurrentRoutingPercent()).sum();
                    Double toDistribute = totAliveRoutePer / (allAliveTargets.size() + 1); // +1 is the newly alive target

                    for (Map.Entry<TargetKey, TargetInfo> entry : allAliveTargets.entrySet()) {
                        TargetKey targetKey1 = entry.getKey();
                        compareAndSetRpTrendIndicator(entry.getValue(), toDistribute);
                        cacheUtil.updateTargetTrendIndicator(targetMapKey, targetKey1, entry.getValue().getDynamicTargetInfo().getRpTrendIndicator());
                        cacheUtil.updateTargetCurrentRoutingPer(targetMapKey, targetKey1, toDistribute);
                    }
                    compareAndSetRpTrendIndicator(currTarInfo, toDistribute);
                    cacheUtil.updateTargetTrendIndicator(targetMapKey, currTarKey, currTarInfo.getDynamicTargetInfo().getRpTrendIndicator());
                    cacheUtil.updateTargetCurrentRoutingPer(targetMapKey, currTarKey, toDistribute);
                    cacheUtil.updateTargetIsAlive(targetMapKey, currTarKey, isAlive);
                    logSmartRouteStatisticsToTlm(sourceConfigModel, smartRouteConfigModel, StatsType.FAIL_OVER);
                }
                break;
            }
        }

        targets = cacheUtil.getTargetData(targetMapKey);
        targets.forEach((targetKey, targetInfo) ->
                logger.debug("Fallback:: curr route percent for target {} is {}",
                        targetInfo.getTargetName(), targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent()));
    }

    /**
     * Compare the alive status of the target with new status.
     * Do the fallback calculation only if both statuses are different.
     *
     * @param targets
     * @param targetId
     * @param isAlive
     * @return
     */
    private boolean fallbackCalNeeded(Map<TargetKey, TargetInfo> targets, String targetId, boolean isAlive) {
        Map.Entry<TargetKey, TargetInfo> target = getTargetById(targets, targetId);
        return target != null && target.getValue().isAlive() != isAlive;
    }

    /**
     * @param targets
     * @return
     */
    protected boolean allTargetsAreAlive(Map<TargetKey, TargetInfo> targets, String exceptTargetId) {
        boolean allAlive = true;
        if (exceptTargetId == null) {
            for (Map.Entry<TargetKey, TargetInfo> entry : targets.entrySet()) {
                if (!entry.getValue().isAlive()) {
                    allAlive = false;
                    break;
                }
            }
        } else {
            for (Map.Entry<TargetKey, TargetInfo> entry : targets.entrySet()) {
                if (!entry.getKey().getTargetId().equals(exceptTargetId) && !entry.getValue().isAlive()) {
                    allAlive = false;
                    break;
                }
            }
        }

        return allAlive;
    }

    private boolean allTargetsAreDead(Map<TargetKey, TargetInfo> targets, String exceptTargetId) {
        boolean allDead = true;
        if (exceptTargetId == null) {
            for (Map.Entry<TargetKey, TargetInfo> entry : targets.entrySet()) {
                if (entry.getValue().isAlive()) {
                    allDead = false;
                    break;
                }
            }
        } else {
            for (Map.Entry<TargetKey, TargetInfo> entry : targets.entrySet()) {
                if (!entry.getKey().getTargetId().equals(exceptTargetId) && entry.getValue().isAlive()) {
                    allDead = false;
                    break;
                }
            }
        }
        return allDead;
    }

    private Map<TargetKey, TargetInfo> getAllAliveTargets(Map<TargetKey, TargetInfo> targets, String
            exceptTargetId) {
        return targets.entrySet().stream().filter(entry ->
                !entry.getKey().getTargetId().equals(exceptTargetId) && entry.getValue().isAlive()
        ).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    private Map<TargetKey, TargetInfo> getAllDeadTargets(Map<TargetKey, TargetInfo> targets) {
        return targets.entrySet().stream().filter(entry -> {
            return !entry.getValue().isAlive();
        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    public void compareAndSetRpTrendIndicator(TargetInfo targetInfo, Double newRoutePer) {
        Double currentRoutingPercent = targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent();
        if (newRoutePer.compareTo(currentRoutingPercent) == 0)
            targetInfo.getDynamicTargetInfo().setRpTrendIndicator(TargetInfo.TrendIndicator.NO_CHANGE);
        else if (newRoutePer.compareTo(currentRoutingPercent) < 0)
            targetInfo.getDynamicTargetInfo().setRpTrendIndicator(TargetInfo.TrendIndicator.DOWN);
        else if (newRoutePer.compareTo(currentRoutingPercent) > 0)
            targetInfo.getDynamicTargetInfo().setRpTrendIndicator(TargetInfo.TrendIndicator.UP);
    }

    @Override
    public RouteType getRouteType() {
        return RouteType.SUCCESS_RATIO_DYNAMIC;
    }

    public List<Long> validateTargetOptionAvailability(ApiTxnModel apiTxnModel, RoutingContext routingContext,TransactionMessageModel reqSrcTmm) {
        /**
         *      Get the payment mode id from apiTxnModel
         *      get the payment mode name from payment mode id from cache
         *      If payment mode is "Card"
         *          get the card no from apiTxnModel
         *          get the scheme type from BIN cache
         *          get the payment mode option id from payment mode option cache by passing the scheme type
         *          targets = get the targets supporting payment mode id & option id
         *      else
         *          targets = get the targets supporting payment mode id & option id
         *
         *      targets = Filter the above targets with the success ratio targets
         *      targets = Filter the above targets with LCR
         */
        Long paymentModeId = Long.valueOf(apiTxnModel.getPayModeId());
        String paymentModeName = srCacheService.getPaymentMode(paymentModeId).getPaymentModeName();
        List<Long> targetIdList = new ArrayList<>();
        if (paymentModeName.toLowerCase().contains("Card".toLowerCase())) {
            BinInfoModel binInfoModel;
            try {
                binInfoModel = cacheService.getSchemeBin(apiTxnModel.getCardNo().replaceAll(" ", ""));
            }catch (Exception e){
                throw new InvalidBinException("Bin "+apiTxnModel.getCardNo().replaceAll(" ", "")+" is not valid ",routingContext.getEntityId(),apiTxnModel.getMid(),apiTxnModel.getMerchantTxnRefNo());
            }
            PaymentModeOptionsModel paymentModeOption = srCacheService.getPaymentModeOption(paymentModeId, binInfoModel.getSchemeName());
            if(reqSrcTmm != null) {
                if (binInfoModel.getLofo() != null) {
                    if (binInfoModel.getLofo().equals(LOFO.F)) {
                        reqSrcTmm.setInternational("International");
                    } else if (binInfoModel.getLofo().equals(LOFO.L)) {
                        reqSrcTmm.setInternational("Domestic");
                    }
                }
                reqSrcTmm.setDebitCreditFlag(binInfoModel.getCardProgram());
                reqSrcTmm.setCardType(binInfoModel.getSchemeName());
            }
            apiTxnModel.setPayModeOptionId(paymentModeOption.getPaymentModeOptionId().toString());
            targetIdList = getTargetIdList(apiTxnModel, routingContext);
        } else {
            targetIdList = getTargetIdList(apiTxnModel, routingContext);
        }
        return targetIdList;
    }

    public TargetConfigModel validateMerchantChoiceRouting(ApiTxnModel apiTxnModel, RoutingContext routingContext, MerchantMasterModel merchantMaster) {
        MerchantPreferredTarget merchantPreTargetData = cacheUtil.getMerchantPreferredTargetData(routingContext.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getPayModeId());
        if (merchantPreTargetData != null) {
            return getTargetConfigById(routingContext, merchantPreTargetData.getTargetId().toString());
        } else if (merchantMaster.getMcrDefaultTargetId() != null && !merchantMaster.getMcrDefaultTargetId().equals(0L)) {
            return getTargetConfigById(routingContext, merchantMaster.getMcrDefaultTargetId().toString());
        } else {
            throw new ValidationException("Target is not define for given merchant having MID : " + apiTxnModel.getMid() + " and PaymentModeId: " + apiTxnModel.getPayModeId());
        }
    }
}
