/**
 * 
 */
package com.isg.mw.routing.route;

import org.apache.camel.Exchange;

import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.routing.context.RoutingContext;

/**
 * @author vidyasagar
 *
 */
interface IRouter {
	static TargetConfigModel getTargetEndpoint(RoutingContext routingContext, Exchange exchange, Object routingParam) {
		return null;
	}
	
	TargetConfigModel getTargetEndpoint(RoutingContext routingContext, Exchange exchange, TransactionMessageModel tmm);

	TargetConfigModel getTargetEndpointNew(RoutingContext routingContext, Exchange exchange, TransactionMessageModel tmm);
}
