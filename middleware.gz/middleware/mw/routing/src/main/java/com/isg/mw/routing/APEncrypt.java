package com.isg.mw.routing;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.offline.SaveOfflineRequest;
import com.isg.mw.core.model.pg.MerchantEncDataRequest;
import com.isg.mw.core.model.pg.MerchantEncDataResponse;
import com.isg.mw.core.model.pg.MerchantEncReqRes;
import com.isg.mw.core.model.pg.MerchantPaymentLinkDataReq;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tlm.PaymentLinkRequestModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.core.utils.IsgCurrencyConversionUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.IsgXmlUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.security.algorithms.RSA;
import com.isg.mw.security.security.Decryptor;
import com.isg.mw.security.security.Encryptor;
import lombok.extern.flogger.Flogger;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.text.DecimalFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.poi.ss.usermodel.Cell.*;
import static org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK;

public class APEncrypt {

    public static void main(String args[]) {

        Encryptor<RSA, PublicKey> encryptor;
        try {
            /**
             * PART 1
             */
            //oldEncryption();

            /**
             * PART 2
             */

            MerchantPaymentLinkDataReq merchantPaymentLinkDataReq = getMerchantPaymentLinkDataReq();
            String secureHashForMerchantPaymentLink = getJsonDataForMerchantPaymentLink("5FF1003BD85EC13EDDE106AC235F58AD", merchantPaymentLinkDataReq);
            System.out.println("HERE");
            System.out.println(secureHashForMerchantPaymentLink);
            System.out.println("HERE");
















//            String encData = "VBVwjgUWAb0ijvRf6sNQLLk08N9JlYTKjFfGB/TX1lmPUGJQqxztYCWuF9E+/Q4Q56ZDsUh6I13ZnVZfsPepnCTKfMbcAYZDlfRWDfnEx2JYP+o5TrWpfX8alnmC9lWh1E5EZCINU+Jqf85SMF8yma8lNTs3DUrBXYFoxTYi/9opaoVykgQKNe6bjdqyxPFTuDz9bMnYZvSMcMyaWDRqauntRrzLVESYoxx0AHA6NW2Zvql6Lsu6ncS7PxrXOMEuyMut+SKDDwfF4A3jCdNIOJqWp+YTOfAHf7t9qzcRRSzAlm7tLDg6IrTEQIYjSlhL98l3mOnAmI4wsdNhR6sIYYOg+EzJ4piJnOyZVdMUfdJuUwzFiyJHr8PeKB5AxQYsQG3fIP4MGmvU3kg5eSTmU1oC4ZP97i+AqBmbYpeTDoTp0n3kKw+DrSVFJSvauRsZi8byERAY+nG/7LlN4toZXC7ZnJDI3j+KdE8uK6Mnw10rVk4caXVt0t8IeugMoCoXmk56bjSyC34bHbMUq+NKO5L/XTOO81gJcricEwL+l4uTzk37822eS8sR24GNzNhvK+e9sQqcFVdncvthRyaUcb5L/Db8muSJMA4B+dZXPhb+u8N8EN47F4jh7lO5WA7KQ2aOCYG20sA+QdbU1geFCkY9E+oY8hE1GcJKTOQGVCaMP/ax7/OtQk97fEY8E9VQg6x3YX1TUz9p5hyVSGD1GwiiycnERlGdgnn4lH+V1Ao=";
            String secretkey = "5FF1003BD85EC13EDDE106AC235F58AD";
//            String merchenckey = "1FF49170C8CCECFF1345B38F971CABBD";
//            JSONObject jsonObject = decryptMerchantEncryptedRequest(encData, secretkey, merchenckey);
//            MerchantEncDataRequest merchantEncDataResponse = IsgJsonUtils.getObjectFromJsonString(jsonObject.toString(), MerchantEncDataRequest.class);
////
//            MerchantEncDataResponse merchantEncDataResponse = IsgJsonUtils.getObjectFromJsonString(jsonObject.toString(), MerchantEncDataResponse.class);
//            System.out.println("merchantEncDataResponse:: "+merchantEncDataResponse);
//////            //MerchantEncDataRequest merchantEncDataResponse = IsgJsonUtils.getObjectFromJsonString(jsonObject, MerchantEncDataRequest.class);;
//            //MerchantEncDataResponse merchantEncDataResponse = toMerchantEncDataRes(merchantEncDataRequest);
//           // createEncData(secretkey, merchenckey);

//            String encryptedSecretKey="aZ3uuomI+yV9UeHncmm4HzZN08CHoUF93Lt0TUwLunur0e6pC2wVzpbVdcgpDnfs";
//            //String encryptedSecretKey="Cr3JhtgHGtvqAEUGZdeseVJQCY7wi0wy0Tm37LGXnJ2aHJsAzELiejtNJpz0K3WO";
//            String aesEncryptData="5cd/JUrQ50Uuz8kd99e/MW0Q4bR4v9lQtxTqacocDKkQcF72ftB1erEhd7W42W226sc7l9KqbvtRMw8+BnrMOlZjK57iY+4zvPo5Dtclv14VqN3Gczo9+Mzd08XR33aHi8nMg5i8knm35lnSfnXTCfVEsmgU6mMQGA0VaA2dlpGgMpdHSTx9OdA1UXLDaClw2QnQywLT6ZQOC4AOI6nDq32ScdUQJBVab3B96qQou+oGDXkvCzRDjZyTsMlNw39A9/z76njv+OG7uNh18xQBoUeeAOgA2O+589Ww7a/x+CkzfuBNT+VqRgqygrXt6tiEvg01jWfbeki5X3kS4+Fbl+H63P5QPBDMWz/NB+SsGejW5KjEg7eSRk88duQT6icoocvtJfGiZCWjpxLcZEYNW1iWXZvkf4WzSlNBZYsSEwH2SFsQVOudZ/cPOUrRL70XUq30W6Ei0CDte60lfpkmLKUOMr2hv2NbOOIkh2Iye5i1oRmf6H2TAIvS1kmCCgasVnNBVq5r5MSfj1dR7W3uqX0rERAdE5et/yuk04n3ABEF1NiL1dhAcWQwedrjKXsC6uu09nNTBxyIrz6F+qP6GP/fYaG4FlMryekZp/V7CTuWHMJe8wffytrzMbm2LJMrSV3GhmROFLkNUlmSxWyitioqz3B9/CEdk715NvdoSlVSA2N+h9uYV1ISDzjSLKSicRdtgDuMx0QWuMdQlJ4DO7YJlpECUnbUp+D4UswRY+hZB33dFVa0ay8/5z6ABYuIxKNgQRmnJwEhT4Tv71UDfxs2MWRwHbsZvt8wDNsx++Xd/v/ZB2DwdXajussEGwiMJM3CL4kRC1UaZE6VJd1vnY5umovnCZY50M0XIpOiL/fm3afdkxehImlwbKubD8qK521Hk6BGGZ+IDzuQEk3cdqiuADa5GKZSNq9R5NhNneHBt8+0ACaEXz9ObxN9LTp5uez8tIk156G7Zf8nln7mhjIWm0sGgw4p0LXpU92yJrpkfKq8DXR8mdHD9ElAf9qxofHnehunS6j4w2AiJc5xyuevUPH/g7zT4SxtIEkMsOTI/vRRkKiM7Nq+J8wt62Bgv9sCDPKdeMbbagge1l/36SYnpCbe4OSFvvhYoqxAdAQg2cPVllfaKo9O1s5/1ZWRZgTt2lNBtv7IZ51p2X3pWSlvyoY3au7DBmOHZkd2SMbwAW8baDjDG2l+rDnOz5D5OMEGBqUi3tj0RekbQx/vGYpDIBtBAQT3TiGjTJ9eBdVhMzWujA1X6Qdhx4oNFigzj7SPTLaAL6ZpeuQp+WjAHrXv1wuXTPXfzKlJpnWvFH3dcwrSIJEr9vlDLmss+FaoUacorXQHvfcKZbqmvIgvsKe1Mnp32x6bhIXguhY9tz3r9xl0T++cSQjXwANFHCpANJUMvpLCqQDVuhgzpcZUfCGWoShjOVmmWFoI3Fgh//n1I92e/wQBvGMpqWB8X+zaHOpCcAu13H14iFo5Lw3H9VQhUvwn8IJWd9wFCr/LpJUzdjtTR1qS7jocuX+IsXWQYSidX+SEJubgUez21vg1/scDEjjUsv1cQDxPtc8T+HaXe2qkhonxH3APIk8tGVzdvHeC0hBFXBuBgaSIiRNjHs1wH6m+upc4vc97oY1MysopXvLLu8L5s6rsV0/4iKV6Ve6FXtRqIh9EcR5ZGNsEsMut1JV/HBr/lvbpvP6GX6SZ/h1aWJVaGM6emZXBLdiObBcV+w8jbkH+96cZ0WKQ2rwpZNWukvGhhItaEAuRFWL1avVlfH6taTPukiTAuXyN7+NiEzkNzODJeBJFEjhSjcKpq+UxEU4osIcfHD5ylwRrR+u1GqyEm3Fa634XSWQwcyQV6CJrO6LLoLDOblBzeWItwGE7WhkqBqbxa3e8ppb7Bcdgq+eLXQM4oCgE8ajHXL+Xz7MixUpgbqgABu8fQEGk4mPRSxjwSfmw/IiSovb6GGx6zP4l3+LvOvlgw2wNFbDYmhn7Qdsa7Ef2aIvWRdTqwcSphAvbL4B4vqqGA/k0n3X9apbxDr5vjIaVOeuYQ6vquP3By9PcMxZ0XovYAxVncQjPUwqQIU5sm6LF38G4SfbYTbHWpYgzlJDzfU1aiZ24s+nhHemmJumES3eH2WAFbEM/gDogaxOlersIikWY6816e8NwM8y0NNJxcI6fafqWZeKyVdEEOLJtPdx/+78qfv96GLCWd8MYJHb1eF+MO5maA/ZdQwpZ8pX8ZLoVltzo4Fyf+0VSZ6EuvGxWYcLKLUXvhFdc+gXRWaXdb2+vbWhu+/ffKavr4klT6BLhgdWlmDXHaQ0VbgdDGcW+nqj7obNu5NyOuGYLBE/jk7OwAzr5opvVVyNlFzh1F2reKlZraUh5Ng158xWovIPhTCaFJ254eTJzjZgzb66YCtXQC2A7vwFf+R8FFSOfwfr5gN44V7G2JCearXq0y25o9w==";
//            String decryptedSecretKey = aesDecrypt(encryptedSecretKey, "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=");
//            System.out.println("\nDecoded secret key (secretKey) : "+ decryptedSecretKey);
//            String decryptDATA = aesDecrypt(aesEncryptData, decryptedSecretKey);
//            System.out.println("\nDecrypted Response: " + decryptDATA);
//            String checkSum = getSHA256CheckSum(decryptDATA);
//            //getCCSI();

            //System.out.println(OffsetDateTime.ofInstant(Instant.ofEpochMilli(1702039497), ZoneOffset.UTC));
//            testMerchantKitData(secretkey);

//            System.out.println("1::"+getTargetMerchantMaster("5008","10000012345","1000001",null));
//            System.out.println("2::"+getTargetMerchantMaster("5008","10000012345",null,"Active"));
//            System.out.println("4::"+getTargetMerchantMaster("5008","10000012344","1000001","Active"));
//
//            List<TargetMerchantMasterModel> targetMerchantMaster1 = getTargetMerchantMaster("5008", "10000012345", "1000001", "Active");
//            TargetMerchantMasterModel model = targetMerchantMaster1.stream().filter(t -> t.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())).findFirst().orElse(null);
//            System.out.println("4::"+model);

            TransactionMessageModel tlmm = new TransactionMessageModel();
            tlmm.setBitMap("123");
            //System.out.println(tlmm);
//            String encryptedSecretKey="Qq1TC49ZS/t0Pp9rJ4WYuK4H2WyJr9C11xVE/PrXd6Y9ljzz2o/VGF2tq5pevw8D";
            String encryptedSecretKey="Cr3JhtgHGtvqAEUGZdeseVJQCY7wi0wy0Tm37LGXnJ2aHJsAzELiejtNJpz0K3WO";
            String aesEncryptData="RB3WaxqRsXpOJ+takK+fzGMUPPAX5X6Rm0R6OT1NsTnbj8nUu7CuHntPendQWbu9v3tcgcl8hwH5xh/SLkn65QH8iySjAOchGMDtU1b7Opki2lR+KblT6nqBbR5NzJ+0dRzTj+67/wJICuCRiqW112bj5mxIoTC42y7Zz9lYKshfpNZIO5EiJl/n8vlNLUpX";
            String decryptedSecretKey = aesDecrypt(encryptedSecretKey, "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=");
            //System.out.println("\nDecoded secret key (secretKey) : "+ decryptedSecretKey);
            String decryptDATA = aesDecrypt(aesEncryptData, decryptedSecretKey);
            //System.out.println("\nDecrypted Response: " + decryptDATA);
            String checkSum = getSHA256CheckSum(decryptDATA);
//            //getCCSI();

            //System.out.println(OffsetDateTime.ofInstant(Instant.ofEpochMilli(1702039497), ZoneOffset.UTC));
//            testMerchantKitData(secretkey);

//            System.out.println("1::"+getTargetMerchantMaster("5008","10000012345","1000001",null));
//            System.out.println("2::"+getTargetMerchantMaster("5008","10000012345",null,"Active"));
//            System.out.println("4::"+getTargetMerchantMaster("5008","10000012344","1000001","Active"));
//
//            List<TargetMerchantMasterModel> targetMerchantMaster1 = getTargetMerchantMaster("5008", "10000012345", "1000001", "Active");
//            TargetMerchantMasterModel model = targetMerchantMaster1.stream().filter(t -> t.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())).findFirst().orElse(null);
//            System.out.println("4::"+model);
            //getCCSI();

            //System.out.println(OffsetDateTime.ofInstant(Instant.ofEpochMilli(1702039497), ZoneOffset.UTC));
            testMerchantKitData(secretkey);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static List<TargetMerchantMasterModel> getTargetMerchantMaster(String targetId, String mid, String tid, String status) {

        ResponseEntity<ResponseObj> result = new RestTemplate().exchange(
                "http://192.168.83.207:8091/accesspoint-config/sr/targetMerchantMaster/get" + "?targetId=" + targetId + "&mid=" + mid + "&tid=" + (!StringUtils.isBlank(tid)?tid:"") + "&status=" + (!StringUtils.isBlank(status)?status:""),
                HttpMethod.GET, buildHeaders(), ResponseObj.class);

        if (result.getStatusCode() != HttpStatus.OK) {
            return null;
        }
        TargetMerchantMasterModel[] targetMerchantMasterModels = new ObjectMapper()
                .registerModule(new JavaTimeModule()).configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false).convertValue(result.getBody().getData(), TargetMerchantMasterModel[].class);
        if(targetMerchantMasterModels != null && targetMerchantMasterModels.length != 0){
            return Arrays.asList(targetMerchantMasterModels);
        }
        return null;
    }



    public static HttpEntity<String> buildHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return new HttpEntity<>(headers);
    }

    private static void testMerchantKitData(String secretkey) throws NoSuchAlgorithmException {
        //ResponseEntity<String> exchange = checkRefund(secretkey);
        ResponseEntity<String> exchange = checkPayStatus(secretkey);
        //ResponseEntity<String> exchange = checkRefundStatus(secretkey);
        System.out.println("Response status:: "+exchange.getStatusCode() +" Body :: "+exchange.getBody());
    }

    private static ResponseEntity<String> checkRefund(String secretkey) throws NoSuchAlgorithmException {
        MerchantEncDataRequest merStatusDataReq = getRefundStatusMerchantEncDataRequest();
        String data = getJsonData(secretkey, merStatusDataReq);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> exchange = restTemplate.exchange("https://geniuscrm.insolutionsglobal.com:8011/accesspoint/v1/24520/createRefund"
                , HttpMethod.POST, buildHeaders(data),
                String.class);
        return exchange;
    }

    private static ResponseEntity<String> checkRefundStatus(String secretkey) throws NoSuchAlgorithmException {
        MerchantEncDataRequest merStatusDataReq = getRefundStatusMerchantEncDataRequest();
        String data = getJsonData(secretkey, merStatusDataReq);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> exchange = restTemplate.exchange("https://geniuscrm.insolutionsglobal.com:8011/accesspoint/v1/24520/checkStatusMerchantKit"
                , HttpMethod.POST, buildHeaders(data),
                String.class);
        return exchange;
    }

    private static ResponseEntity<String> checkPayStatus(String secretkey) throws NoSuchAlgorithmException {
        MerchantEncDataRequest merStatusDataReq = getPayStatusMerchantEncDataRequest();
        String data = getJsonData(secretkey, merStatusDataReq);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> exchange = restTemplate.exchange("https://geniuscrm.insolutionsglobal.com:8011/accesspoint/v1/24520/checkStatusMerchantKit"
                , HttpMethod.POST, buildHeaders(data),
                String.class);
        return exchange;
    }

    public static HttpEntity<String> buildHeaders(String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        return new HttpEntity<>(body,headers);
    }

    private static MerchantEncDataRequest getRefundStatusMerchantEncDataRequest() {
        MerchantEncDataRequest merDataReq = new MerchantEncDataRequest();
        merDataReq.setBankId("24520");
        merDataReq.setMerchantId("10000012345");
        merDataReq.setPassCode("TSFC9767");
        merDataReq.setTerminalId("1000001");
        merDataReq.setTxnRefNo("1699888114305");
        merDataReq.setRefCancelId("665672921");
        merDataReq.setTxnType("Refund");
        return merDataReq;
    }
    private static MerchantEncDataRequest getPayStatusMerchantEncDataRequest() {
        MerchantEncDataRequest merDataReq = new MerchantEncDataRequest();
        merDataReq.setBankId("24520");
        merDataReq.setMcc("5411");
        merDataReq.setMerchantId("10000012345");
        merDataReq.setPassCode("TSFC9767");
        merDataReq.setTerminalId("1000001");
        merDataReq.setTxnRefNo("2724335171");
        merDataReq.setTxnType("Pay");
        return merDataReq;
    }

    private static String getJsonData(String secretkey, Object merStatusDataReq) throws NoSuchAlgorithmException {
        JSONObject jsonObject = new JSONObject(IsgJsonUtils.getJsonString(merStatusDataReq));
        List<String> sortedKeys = getSortedKeyList(jsonObject);
        String secureHash = getSecureHash(jsonObject, sortedKeys, secretkey);
        jsonObject.put("SecureHash", secureHash);
        return jsonObject.toString();
    }

    private static MerchantEncDataRequest getRefundMerchantEncDataRequest() {
        MerchantEncDataRequest merDataReq = new MerchantEncDataRequest();
        merDataReq.setBankId("24520");
        merDataReq.setMerchantId("10000012345");
        merDataReq.setPassCode("TSFC9767");
        merDataReq.setRefCancelId("1699888114305");
        merDataReq.setRefundAmount("100");
        merDataReq.setRetRefNo("139186379439781421");
        merDataReq.setTerminalId("1000001");
        merDataReq.setTxnRefNo("1699888114305");
        merDataReq.setTxnType("Refund");
        return merDataReq;
    }


    private static void getCCSI() {
        TransactionMessageModel tmm =  new TransactionMessageModel();
        tmm.setTxnAmt("12300000000000");
        tmm.setCgst("9.00");
        tmm.setConvenienceFee("9.00");
        tmm.setIgst("9.00");
        tmm.setSgst("9.00");

        String txnAmt = tmm.getTxnAmt();

        BigDecimal toPaisa = getTotalAmountInPaisaIfCCSIinPaisa(tmm);
        BigDecimal toRupees = getTotalAmountInRupeesIfCCSIinPaisa(tmm);

        System.out.println("\n getTotalAmountInPaisaIfCCSIinPaisa: " + toPaisa);
        System.out.println("\n getTotalAmountInRupeesIfCCSIinPaisa: " + toRupees);
    }


    public static BigDecimal getTotalAmountInPaisaIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = new BigDecimal(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = new BigDecimal(tmmModel.getConvenienceFee());
        BigDecimal cgst = new BigDecimal(tmmModel.getCgst());
        BigDecimal sgst = new BigDecimal(tmmModel.getSgst());
        BigDecimal igst = new BigDecimal(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return amount.stripTrailingZeros();
    }

    public static BigDecimal getTotalAmountInRupeesIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getConvenienceFee());
        BigDecimal cgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getCgst());
        BigDecimal sgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getSgst());
        BigDecimal igst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return amount;
    }

    private static void createEncData(String secretkey, String merchenckey) {
        MerchantEncDataRequest merchantEncDataResponse = new MerchantEncDataRequest();
        merchantEncDataResponse.setAmount("2000");
        merchantEncDataResponse.setMcc("8521");
        merchantEncDataResponse.setMerchantId("10000012345");
        merchantEncDataResponse.setPassCode("TSFC9767");
        merchantEncDataResponse.setOrderInfo("test");
        merchantEncDataResponse.setReturnURL("https://geniuscrm.insolutionsglobal.com:8010/testMerchantStore/");
        merchantEncDataResponse.setTerminalId("1000001");
        merchantEncDataResponse.setTxnRefNo("124562");
        merchantEncDataResponse.setTxnType("Pay");
        merchantEncDataResponse.setUdf01("");
        merchantEncDataResponse.setUdf02("");
        merchantEncDataResponse.setUdf03("");
        merchantEncDataResponse.setUdf04("");
        merchantEncDataResponse.setBankCode("856");
        System.out.println("merchantEncDataResponse:: "+merchantEncDataResponse);
        MerchantEncReqRes merchantEncReqRes = new MerchantEncReqRes();
        merchantEncReqRes.setMerchantId(merchantEncDataResponse.getMerchantId());
        merchantEncReqRes.setTerminalId(merchantEncDataResponse.getTerminalId());
        merchantEncReqRes.setBankId(merchantEncDataResponse.getBankId());
        String data = encryptMerchantData(merchantEncDataResponse, secretkey, merchenckey);
        merchantEncReqRes.setEncData(data);
        System.out.println("merchantEncReqRes:: "+merchantEncReqRes);
    }

    private static String getFormatedAmt(String txnAmt) {
//        Double stringToDouble = NumberUtils.getStringToDouble(txnAmt);
//        stringToDouble = stringToDouble != null ? stringToDouble / 100 : null;
//        String tmp = String.format("%.2f", stringToDouble, 0);
//        String replace = tmp.replace(".", "");
//        String s = StringUtils.leftPad(tmp, 12, "0");
        String stringToDouble = txnAmt;
        if(txnAmt.contains(".")){
            stringToDouble = convertRupeesToPaisa(txnAmt);
        }
        return StringUtils.leftPad(stringToDouble, 12, "0");
    }


    private static MerchantEncDataResponse toMerchantEncDataRes(MerchantEncDataRequest merchantEncDataRequest) {
        MerchantEncDataResponse res = new MerchantEncDataResponse();
        res.setBankId(merchantEncDataRequest.getBankId());
        res.setMerchantId(merchantEncDataRequest.getMerchantId());
        res.setTerminalId(merchantEncDataRequest.getTerminalId());
        res.setTxnRefNo(merchantEncDataRequest.getTxnRefNo());
        res.setMcc(merchantEncDataRequest.getMcc());
        res.setPassCode(merchantEncDataRequest.getPassCode());
        res.setCurrency(merchantEncDataRequest.getCurrency());
        res.setAmount(merchantEncDataRequest.getAmount());
        res.setOrderInfo(merchantEncDataRequest.getOrderInfo());
        res.setPayOpt(merchantEncDataRequest.getPayOpt());
        res.setFirstName(merchantEncDataRequest.getFirstName());
        res.setLastName(merchantEncDataRequest.getLastName());
        res.setStreet(merchantEncDataRequest.getStreet());
        res.setCity(merchantEncDataRequest.getCity());
        res.setState(merchantEncDataRequest.getState());
        res.setZip(merchantEncDataRequest.getZip());
        res.setEmail(merchantEncDataRequest.getEmail());
        res.setPhone(merchantEncDataRequest.getPhone());
        res.setUdf01(merchantEncDataRequest.getUdf01());
        res.setUdf02(merchantEncDataRequest.getUdf02());
        res.setUdf03(merchantEncDataRequest.getUdf03());
        res.setUdf04(merchantEncDataRequest.getUdf04());
        res.setUdf05(merchantEncDataRequest.getUdf05());
        res.setUdf06(merchantEncDataRequest.getUdf06());
        res.setUdf07(merchantEncDataRequest.getUdf07());
        res.setUdf08(merchantEncDataRequest.getUdf08());
        res.setUdf09(merchantEncDataRequest.getUdf09());
        res.setUdf10(merchantEncDataRequest.getUdf10());
        res.setChUserID(merchantEncDataRequest.getChUserID());
        res.setCardTokenReferenceNo(merchantEncDataRequest.getCardTokenReferenceNo());
        res.setSecureHash(merchantEncDataRequest.getSecureHash());
        res.setVersion(merchantEncDataRequest.getVersion());
        return res;
    }

    public static String generateUniqueId() {
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String formattedDateTime = currentTime.format(formatter);

        UUID uuid = UUID.randomUUID();
        String uniqueId = formattedDateTime + uuid.toString();
        System.out.println(uniqueId);
        return uniqueId;
    }

    private static String getSecureHash(JSONObject jsonObject, List<String> keys, String secretKey) throws NoSuchAlgorithmException {
        String secureHash = "";
        secureHash = secureHash + secretKey;
        for (String key : keys) {
            String value = jsonObject.getString(key);
            secureHash = secureHash + value;
        }
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        secureHash = DatatypeConverter.printHexBinary(md.digest(secureHash.getBytes()));
        return secureHash;
    }


    public static String encryptMerchantData(Object merchantEncDataResponse, String secretKey, String merchantEncryptedKey) {
        String encryptedValue = null;
        Cipher cipher = SpringContextBridge.getCipherInstance();
        try {
            byte[] keyByte = merchantEncryptedKey.getBytes();
            Key key = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            JSONObject jsonObject = new JSONObject(IsgJsonUtils.getJsonString(merchantEncDataResponse));
            List<String> sortedKeys = getSortedKeyList(jsonObject);
            String secureHash = getSecureHash(jsonObject, sortedKeys, secretKey);
            jsonObject.put("SecureHash", secureHash);
            String encryptionValue = getStringForEncryption(jsonObject);
            byte encVal[] = cipher.doFinal(encryptionValue.getBytes());
            byte encryptedByteValue[] = Base64.getEncoder().encode(encVal);
            encryptedValue = new String(encryptedByteValue);
        } catch (Exception ex) {
            System.out.println("Exception while encrypting Data -> [" + ex + "]");
            ex.printStackTrace();
        }
        return encryptedValue;
    }

    private static String getStringForEncryption(JSONObject jsonObject) {
        String encryptionValue = "";
        Iterator<String> keys = jsonObject.keys();

        while (keys.hasNext()) {
            String key = keys.next();
            String value = jsonObject.getString(key);
            encryptionValue = encryptionValue + key + "||" + value + "::";
        }
        encryptionValue = encryptionValue.substring(0, encryptionValue.length() - 2);
        return encryptionValue;
    }

    public static JSONObject decryptMerchantEncryptedRequest(String reqBody, String secretKey, String merchantEncryptedKey) {
        Cipher cipher = SpringContextBridge.getCipherInstance();
        System.out.println("Encrypted Req Body: {}, Encryption Key: {}"+reqBody+" :: "+merchantEncryptedKey);
        JSONObject jsonObject = null;
        try {
            byte[] keyByte = merchantEncryptedKey.getBytes();
            Key key = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedByteValue = Base64.getDecoder().decode(reqBody.getBytes());
            byte[] decValue = cipher.doFinal(decryptedByteValue);
            String decryptVal = new String(decValue);
            System.out.println("Merchant Decrypt Data:: "+decryptVal);
            jsonObject = getObjectFromRequestBody(decryptVal);
            String secureHash = generateMerchantReqSecureHash(jsonObject, secretKey);
            if (secureHash.equalsIgnoreCase(jsonObject.getString("SecureHash"))) {
                return jsonObject;
            }
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

//    private static JSONObject getObjectFromRequestBody(String decryptVal) {
//        String[] split = decryptVal.split("::");
//        JSONObject jsonObject = new JSONObject();
//        for (String keyVal : split) {
//            String[] split1 = keyVal.split("\\|\\|");
//            jsonObject.put(split1[0], split1[1]);
//        }
//        return jsonObject;
//    }
    public static JSONObject getObjectFromRequestBody(String decryptVal) {
        String[] split = decryptVal.split("::");
        JSONObject jsonObject = new JSONObject();
        for (String keyVal : split) {
            String[] split1 = keyVal.split("\\|\\|");
            if (split1.length > 1) {
                jsonObject.put(split1[0], split1[1]);
            } else {
                jsonObject.put(split1[0], "");
            }
        }
        return jsonObject;
    }

    private static String generateMerchantReqSecureHash(JSONObject jsonObject, String secretKey) {
        StringBuilder secureHash = new StringBuilder();
        secureHash.append(secretKey);
        List<String> sortedKeyList = getSortedKeyList(jsonObject);
        for (String sortedKey : sortedKeyList) {
            String value = jsonObject.getString(sortedKey);
            secureHash.append(value);
        }
        System.out.println("\n\nData used for hashing: {}"+ secureHash);
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        String s = DatatypeConverter.printHexBinary(md.digest(secureHash.toString().getBytes()));
        System.out.println("\n\nSecure Hash: {}"+ s);
        return s;
    }

    private static List<String> getSortedKeyList(JSONObject jsonObject) {
        List<String> list = new ArrayList<>();
        Iterator<String> keys = jsonObject.keys();
        while (keys.hasNext()) {
            String currentKey = keys.next();
            if (!currentKey.equalsIgnoreCase("secureHash"))
                list.add(currentKey);
        }
        Collections.sort(list);
        return list;
    }

    private static void newEncryption() throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, JAXBException {
        String request = "";
        //request = getTargetLcrRequest();
        //request = getTransactionReq();
        //request = getValidateAndGetPaymentDataEncReq();
        //request = getTargetAndGenerateRequestEnc();
        //request=getSaveOfflineRequestRequestEnc();
        request=getConvenienceRequestEnc();
        //Step2: Generate secretKey
        SecretKey key = generateSecretKey();
        String encodSecretKey = Base64.getEncoder().encodeToString(key.getEncoded());
        System.out.println("\nEncoded Secret Key: "+ encodSecretKey);
        String aesEncryptData = aesEncrypt(request, encodSecretKey);
        System.out.println("\nEncrypted request body (dval) : "+ aesEncryptData);
        String encryptedSecretKey = aesEncrypt(encodSecretKey, "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=");
        System.out.println("\nEncrypted secret key (secretKey) : "+ encryptedSecretKey);
        String decryptedSecretKey = aesDecrypt(encryptedSecretKey, "yVbkC/Q2tkQTPS3JhWR0QNp0wKqV4cZzieFZsv+wxtI=");
        System.out.println("\nDecoded secret key (secretKey) : "+ decryptedSecretKey);
        String decryptDATA = aesDecrypt(aesEncryptData, decryptedSecretKey);
        System.out.println("\nDecrypted Response: " + decryptDATA);
    }

    private static String getConvenienceRequestEnc() throws NoSuchAlgorithmException {
        //REQUEST::https://geniuscrm.insolutionsglobal.com:8010/accesspoint/v1/9568/getConvenienceFeeEnc
        Map<String, Object> map = new HashMap<>();
        map.put("mid", "100000000000755");
        map.put("tid", "1000001");
        map.put("merchantTxnRefNo", "1234");
        map.put("txnAmt", "500");
        map.put("schemeType", "NB");
        map.put("payModeId", "1");
        map.put("payModeOptionId", "15");
        String requestMap = IsgJsonUtils.getJsonString(map);
        System.out.println("RequestMap : " + requestMap);
        String checkSum = getSHA256CheckSum(requestMap);
        // map.put("checksum", checkSum);
        String request = IsgJsonUtils.getJsonString(map);
        return request;
    }

    private static String getSaveOfflineRequestRequestEnc() throws NoSuchAlgorithmException, JAXBException {
        //REQUEST::https://geniuscrm.insolutionsglobal.com:8010/accesspoint/v1/9568/saveOfflineResponse
        /*<REQ_MIS>
	    <Client_Code>ICOL</Client_Code>
	    <Client_Validate_No>138977388962050335</Client_Validate_No>
	    <ICT_INSTRUMENT_TYPE>NA</ICT_INSTRUMENT_TYPE>
	    <ICT_TRAN_AMT>220</ICT_TRAN_AMT>
	    <Pay_Mode>5</Pay_Mode>
	    <User_Id>E455605</User_Id>
	    <Isure_Id>1030503646</Isure_Id>
	    <IBANK_Tran_Id>M364507</IBANK_Tran_Id>
        </REQ_MIS>*/
        SaveOfflineRequest map = new SaveOfflineRequest();
        map.setClientCode("ICOL");
        map.setClientValidateNo("138977388962050335");
        map.setPayMode("5");
        map.setUserId("E455605");
        String requestMap = IsgXmlUtils.convertObjectToXml(map,SaveOfflineRequest.class);;
        System.out.println("RequestMap : "+requestMap);
        String checkSum = getSHA256CheckSum(requestMap);
        // map.put("checksum", checkSum);
        //String request = IsgJsonUtils.getJsonString(map);
        return requestMap;
    }

    private static String getTransactionReq() throws NoSuchAlgorithmException {
        //REQUEST::https://geniuscrm.insolutionsglobal.com:8010/accesspoint/angularBackEnd/transactionReq
        Map<String, Object> map = new HashMap<>();
        map.put("Amount", "500.00");
        map.put("Currency", "IND");
        map.put("MerchantId", "10000012345");
        map.put("TerminalId", "test");
        map.put("OrderInfo", "Hotel");
        map.put("TxnRefNo", "1234");
        String requestMap = IsgJsonUtils.getJsonString(map);;
        System.out.println("RequestMap : "+requestMap);
        String checkSum = getSHA256CheckSum(requestMap);
       // map.put("checksum", checkSum);
        String request = IsgJsonUtils.getJsonString(map);
        return request;
    }
    private static String getValidateAndGetPaymentDataEncReq() throws NoSuchAlgorithmException {
        //REQUEST::https://geniuscrm.insolutionsglobal.com:8010/accesspoint/v1/24520/validateAndGetPaymentDataEnc
        Map<String, Object> map = new HashMap<>();
        map.put("MerchantId", "10000012345");
        map.put("TerminalId", "1000001");
        map.put("BankId", "24520");
        map.put("EncData", "wrSxjN9c0xGkFuYiYaD1xn8/ZVMvup/3YgMUcr6YcJ5OGevhmDlKXHSK4yOiR1ffxPorgyzFUXwZILidUHVsJvyPazgB8yCCqajd2H7x9krNo56mToIxQ48HAn4KllkZOUTjs5ouVE/KgPNAAPqFrDT1mz9WvTMf1GjGHYkOICVHBtd8sNjV6jPaEpHNz3OJyuusgXTy/hJifvCFqPIeVYoOoHGqoDlddIdFNXmEGWtKjSY3j5vbRCR/O31QQDEyfitSuFAhOut1IyPbPgGj2WM9G0DxKjCO1pwAkeH2Fdo=");
        String requestMap = IsgJsonUtils.getJsonString(map);;
        System.out.println("RequestMap : "+requestMap);
        String checkSum = getSHA256CheckSum(requestMap);
        // map.put("checksum", checkSum);
        String request = IsgJsonUtils.getJsonString(map);
        return request;
    }

    private static String getTargetAndGenerateRequestEnc() throws NoSuchAlgorithmException {
        //REQUEST::https://geniuscrm.insolutionsglobal.com:8010/accesspoint/angularBackEnd/transactionReq
        Map<String, Object> map = new HashMap<>();
        map.put("msgType", "Pay");
        map.put("cardNo", "");
        map.put("orderInfo", "test");
        map.put("txnAmt", "500.00");
        map.put("tid", "1000001");
        map.put("mid", "10000012345");
        map.put("payModeId", "1");
        map.put("payModeOptionId", "15");
        map.put("merchantTxnRefNo", "1234");
        map.put("mcc", "Hotel");
        map.put("merchantReturnUrl", "https://geniuscrm.insolutionsglobal.com:8010/testMerchantStore/");
        map.put("txnFailedReturnUrl", "https://geniuscrm.insolutionsglobal.com:8010/payment-capture/");
        map.put("returnUrl", "https://geniuscrm.insolutionsglobal.com:8010/accesspoint/response?eid=9568");
        String requestMap = IsgJsonUtils.getJsonString(map);
        System.out.println("RequestMap : " + requestMap);
        String checkSum = getSHA256CheckSum(requestMap);
        // map.put("checksum", checkSum);
        String request = IsgJsonUtils.getJsonString(map);
        return request;
    }

    private static void oldEncryption() throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
        //Step1: Generate Checksum and add in request.
        //String request = getRequestData();
        String request = getTargetLcrRequest();

        //Step2: Generate secretKey
        SecretKey key = generateSecretKey();

        //Step3: Encode request with secret key.
        String encryptData = encrypt2(request, key);

        //Step4: Encrypt the secret key.
        String encryptSecretKey = encryptSecretKey(key);

        //Step5: Decode the request using secret key.
        String abcd = "eelV6+aZrJyBdkXbj5q6NB96dNKQe9GfAS1SQMapyWpIIO0kZw6/atu3uhAfGLF8sdKeKoFXnx64IAR9CBLIW+knYtIvHzXrTYVPGNe5EsvDfLwI2YwbIHumrJfsDzZ1RayZ7iM8L28318UG/FM6Yy1HSK6gTIbnukTc6MgIC3E09l0QNj+9LoeGL6fqmFhckMyZa9bFxPn+/KqAYHv3zjdn82U91W8HusM/iL6vNoryBHPzkYKhdnZXoj+pBiLcE1kR053oVaL5jgU5UNKt5IF7eY/0t8HVf9dq1iwiQ==}";
        //data = "O2LqgjWp91XoX8bvPjyYsdVrJcShRfPp97DA2z3QNQ==";
        //encodeSecretKey = "01800378a57c2781dd4b698ddc0ba9b75c308bdf005f000100156177732d63727970746f2d7075626c69632d6b65790044412b4d46354a797151774a68744a4777375257387a443237476e694f6c7950726b53335779666462394f525264373251636b543448504a434f4268484a63715562673d3d00010003495347000c6d797365727665726365727400804db4e5eef3744b84790610be5e7b7b4056cfbed8467c2e23a3cc1d1f401d277fe7ebfbd019c52c91de53920e6aaad675e509e907ca3d20d189042275dab51914376701f28abfa952fc7e6c1d0418a5c7f99ebb4f9ca010494bfd6b9cd76ab622247bb9ffd8b4a77afb133996e7cac4a80ecbe6f7c2d593866c8e277ee6e949fd02000000000c0000100000000000000000000000000039323185f35799b2fec0ce2da9d51aadffffffff000000010000000000000000000000010000002ce261336f06e918523148b049e4f78e2e2e95389e3526def4577587220c29cb6d9f2b68af6712527213b76e1206caa26ce52dcd16545800bdf588b98200673065023100aa8a5574d8d3b4fb3f656ad169f4647320b205ce2b89038e294f5d624fbb76d0fb353d15c5f04390df82e4d1d3b84b2f023011750ba0cbd1f6b2080ad43d7aa2a52ec37afc4878e2524473360637bfb5fafc31d82be1758fe217a11711100667a5ad";
        String strApiTxnModel = decrypt2(encryptData, encryptSecretKey);
        System.out.println("\nDecrypted Response: " + strApiTxnModel);
    }

    private static String encryptSecretKey(SecretKey key) {
        Encryptor<RSA, PublicKey> encryptor;
        String encodedKey = Base64.getEncoder().encodeToString(key.getEncoded());
        encryptor = new Encryptor<>("/home/ISG/rahul3983/Softwares/MW_SERVER/mw/resources_3998/keyproviders/publickey.json");
        String keyStr = encryptor.encrypt(encodedKey);
        System.out.println("\nEncrypted secret key (secretKey): " + keyStr);
        return keyStr;
    }

    private static String encrypt1(String request, SecretKey key)  {
        Cipher cipher;
        String encryptedData = null;
        try {
            cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, key.getEncoded()));
            encryptedData = Base64.getEncoder().encodeToString(cipher.doFinal(request.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\nEncrypted request body (dval): " + encryptedData);
        return encryptedData;
    }

    private static String encrypt2(String request, SecretKey key)  {
        Cipher cipher;
        String encryptedData = null;
        try {
            cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            encryptedData = Base64.getEncoder().encodeToString(cipher.doFinal(request.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("\nEncrypted request body (dval): " + encryptedData);
        return encryptedData;
    }

    private static SecretKey generateSecretKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);
        SecretKey key = keyGenerator.generateKey();
        System.out.println("\nSecretkey: " + key);
        return key;
    }

    private static String getTargetLcrRequest() throws NoSuchAlgorithmException {
        Map<String, Object> map = new HashMap<>();
        map.put("cardAcceptorId", "HPYBIJALIP00007");
        map.put("payModeId", "1786");
        map.put("payModeOptionId", "1883");
        map.put("pan", "4197882028929274");
        map.put("mcc", "Hotel");
        map.put("txnAmt", "200.00");
        map.put("merchantTxnId", "123456");
        String requestMap = map.toString();
        String checkSum = getCheckSum(requestMap);
        map.put("checksum", checkSum);
        String request = IsgJsonUtils.getJsonString(map);
        return request;
    }

    public static String aesEncrypt(String data, String secretKey) {
        Cipher cipher;
        String encryptedResponse = "";
        try {
            cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
            SecretKey key1 = new SecretKeySpec(decodeKey, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, key1);
            encryptedResponse = Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException |
                NoSuchAlgorithmException | NoSuchPaddingException e) {
            System.out.println("Error in encrypting data: "+ e);
        }
        return encryptedResponse;
    }

    public static String aesEncrypt(String data, SecretKey secretKey) {
        Cipher cipher;
        String encryptedResponse = "";
        try {
            cipher = Cipher.getInstance("AES");
            /*byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
            SecretKey key1 = new SecretKeySpec(decodeKey, "AES");*/
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            encryptedResponse = Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException |
                NoSuchAlgorithmException | NoSuchPaddingException e) {
            System.out.println("Error in encrypting data: "+ e);
        }
        return encryptedResponse;
    }

    private static SecretKey getDecodedSecretKey(String secretKey) {
        byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
        return new SecretKeySpec(decodeKey, "AES");
    }

    public static String aesDecrypt(String data, String secretKey) {
        Cipher cipher;
        String decryptedResponse = "";
        try {
            cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
            SecretKey key1 = new SecretKeySpec(decodeKey, "AES");
            cipher.init(Cipher.DECRYPT_MODE,key1);
            byte[] decode = Base64.getDecoder().decode(data.getBytes());
            decryptedResponse = new String(cipher.doFinal(decode));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException |
                NoSuchAlgorithmException | NoSuchPaddingException e) {
            System.out.println("Error in encrypting data: "+ e);
        }
        return decryptedResponse;
    }

    public static String aesDecrypt(String data, SecretKey secretKey) {
        Cipher cipher;
        String decryptedResponse = "";
        try {
            cipher = Cipher.getInstance("AES");
//            byte[] decodeKey = Base64.getDecoder().decode(secretKey.getBytes());
//            SecretKey key1 = new SecretKeySpec(decodeKey, "AES");
            cipher.init(Cipher.DECRYPT_MODE,secretKey);
            byte[] decode = Base64.getDecoder().decode(data.getBytes());
            decryptedResponse = new String(cipher.doFinal(decode));
        } catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException |
                NoSuchAlgorithmException | NoSuchPaddingException e) {
            System.out.println("Error in encrypting data: "+ e);
        }
        return decryptedResponse;
    }

    private static String getSHA256CheckSum(String request) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        String checksum = DatatypeConverter.printHexBinary(md.digest(request.getBytes()));
        System.out.println("Checksum (cval): " + checksum);
        return checksum;
    }

    private static String getCheckSum(String request) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD");
        String checksum = DatatypeConverter.printHexBinary(md.digest(request.getBytes()));
        System.out.println("Checksum (cval): " + checksum);
        return checksum;
    }

    private static String getRequestData() throws NoSuchAlgorithmException {
        Map<String, Object> map = new HashMap<>();
        map.put("posEntryMode", "810");
        map.put("msgType", "0200");
        map.put("processingCode", "01");
        map.put("pan", "4364080078929274");
        map.put("txnAmt", "000000010000");
        map.put("expiryDate", "2204");
        map.put("cvv2", "1123");
        map.put("merchantType", "5111");
        map.put("cardAcceptorTerminalId", "HPYBL007");
        map.put("cardAcceptorId", "HPYBIJALIP00007");
        map.put("stan", "210422");
        map.put("avv", "jK2HDrZhBenBCBF0RllRA5cAAAA=");
        map.put("pgTxnRefNo", "test009");
        map.put("ecommerceIndicator", "02");
        map.put("originalTxnPgid", "212790123049");
        map.put("frmIpAddress", "192.168.83.26");
        map.put("pgId", "210889566591");
        map.put("dsVersion", "1");
        map.put("bankName", "KOTAK");
        map.put("tavv", "");
        map.put("tokenRequestorId", "");
        map.put("resCode", "");
        map.put("resMessage", "");
        map.put("txnCurrencyCode", "356");

        MessageDigest md = MessageDigest.getInstance("MD5");
        String checksum = DatatypeConverter.printHexBinary(md.digest(map.toString().getBytes()));
        System.out.println(checksum);

        map.put("checksum", checksum);
        String request = IsgJsonUtils.getJsonString(map);
        return request;
    }

    private static String decrypt1(String data, String encodeSecretKey)
            throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
            BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        Decryptor<RSA, PrivateKey> decryptor;
        decryptor = new Decryptor<>("/home/ISG/rahul3983/Softwares/MW_SERVER/mw/resources_3998/keyproviders/privatekey.json");
        byte[] key = decryptor.decrypt(encodeSecretKey).getBytes();
        byte[] decodeKey = Base64.getDecoder().decode(key);

        GCMParameterSpec parameterSpec = new GCMParameterSpec(128, decodeKey, 0, decodeKey.length);
        SecretKey key1 = new SecretKeySpec(decodeKey, 0, decodeKey.length, "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key1, parameterSpec);
        byte[] decode = Base64.getDecoder().decode(data);
        String strApiTxnModel = new String(cipher.doFinal(decode), StandardCharsets.UTF_8);
        return strApiTxnModel;
    }

    private static String decrypt2(String data, String encodeSecretKey)
            throws InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException,
            BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        Decryptor<RSA, PrivateKey> decryptor;
        decryptor = new Decryptor<>("/home/ISG/rahul3983/Softwares/MW_SERVER/mw/resources_3998/keyproviders/privatekey.json");
        byte[] key = decryptor.decrypt(encodeSecretKey).getBytes();
        byte[] decodeKey = Base64.getDecoder().decode(key);

        SecretKey key1 = new SecretKeySpec(decodeKey, 0, decodeKey.length, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key1);
        byte[] decode = Base64.getDecoder().decode(data);
        String strApiTxnModel = new String(cipher.doFinal(decode), StandardCharsets.UTF_8);
        return strApiTxnModel;
    }

    public static String convertPaisaToRupeesFormatted(String paisaString) {
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        BigDecimal rupees = convertPaisaToRupees(paisaString);
        return decimalFormat.format(rupees);
    }

    public static String convertRupeesToPaisa(String rupeesString) {
        BigDecimal rupeesAmount = new BigDecimal(rupeesString);
        BigDecimal paisaAmount = rupeesAmount.multiply(new BigDecimal("100"));
        return paisaAmount.toBigInteger().toString();
    }

    public static BigDecimal convertPaisaToRupees(String paisaString) {
        BigDecimal paisa = new BigDecimal(paisaString);
        BigDecimal rupees = paisa.divide(new BigDecimal("100"));
        return rupees;
    }

//    public static String convertPaisaToRupeesFormatted(String paisaString) {
//        DecimalFormat decimalFormat = new DecimalFormat("0.00");
//        double rupees = convertPaisaToRupees(paisaString);
//        return decimalFormat.format(rupees);
//    }
//
//    public static String convertRupeesToPaisa(String rupeesString) {
//        double rupees = Double.parseDouble(rupeesString);
//        int i = (int) (rupees * 100);
//        return String.valueOf(i);
//    }

    public static void uploadExcelFile() throws FileNotFoundException {
        String fpath = "/home/ISG/rahul3983/WFH_RAHUL3983/NEW-SMARTROUTE/ICICI-DEPLOYMENT-UPDATE-BUG-FIXING/Txn.xlsx";
        FileInputStream inputStream = new FileInputStream(new File(fpath));
        try {
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0); // Assuming the first sheet is the desired one

            List<List<Object>> rows = new ArrayList<>();
            List herders = new ArrayList<>();
            Iterator<Row> rowIterator = sheet.iterator();
            //Check Headers Value
            List<String> headers = extractedHeaderData(rowIterator);
            //Read Object Value
            List<PaymentLinkRequestModel> paymentLinkRequestModels = extractedRowData(rowIterator);
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<PaymentLinkRequestModel> extractedRowData(Iterator<Row> rowIterator) {
        List<PaymentLinkRequestModel> cells = new ArrayList<>();
        while (rowIterator.hasNext()) {
            int cellid = 0;
            PaymentLinkRequestModel requestModel = new PaymentLinkRequestModel();
            Row row = rowIterator.next();
            requestModel.setEntityId(getStringValue(row.getCell(cellid++)));
            requestModel.setRemark(getStringValue(row.getCell(cellid++)));
            requestModel.setTxnAmt(getStringValue(row.getCell(cellid++)));
            requestModel.setMerchantTxnRefNo(getStringValue(row.getCell(cellid++)));
            requestModel.setCustomerMobNo(getStringValue(row.getCell(cellid++)));
            requestModel.setLinkExpiryDate(getStringValue(row.getCell(cellid++)));
            requestModel.setCustomerEmail(getStringValue(row.getCell(cellid++)));
            cells.add(requestModel);
        }
        return cells;
    }

    private static String getStringValue(Cell cell) {
        switch (cell.getCellType()) {
            case CELL_TYPE_STRING:
                return cell.getStringCellValue();
            case CELL_TYPE_NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case CELL_TYPE_BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case CELL_TYPE_BLANK:
                return "";
        }
        return "";
    }

    private static List<String> extractedHeaderData(Iterator<Row> rowIterator) {
        List<String> cells = new ArrayList<>();
        if (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                switch (cell.getCellType()) {
                    case CELL_TYPE_STRING:
                        cells.add(cell.getStringCellValue());
                        break;
                }
            }
        }
        return cells;
    }

    //private static ResponseEntity<String> checkRefund(String secretkey) throws NoSuchAlgorithmException {
    //    MerchantEncDataRequest merStatusDataReq = getRefundStatusMerchantEncDataRequest();
    //    String data = getJsonData(secretkey, merStatusDataReq);
    //    RestTemplate restTemplate = new RestTemplate();
    //    ResponseEntity<String> exchange = restTemplate.exchange("https://geniuscrm.insolutionsglobal.com:8011/accesspoint/v1/24520/createRefund"
    //            , HttpMethod.POST, buildHeaders(data),
    //            String.class);
    //    return exchange;
    //}

    private static String getJsonDataForMerchantPaymentLink(String secretkey, Object merchantPaymentLinkDataReq) throws NoSuchAlgorithmException {
        if (secretkey.isEmpty()){
            secretkey = "5FF1003BD85EC13EDDE106AC235F58AD";
        }
        JSONObject jsonObject = new JSONObject(IsgJsonUtils.getJsonString(merchantPaymentLinkDataReq));
        List<String> sortedKeys = getSortedKeyList(jsonObject);
        String secureHash = getSecureHash(jsonObject, sortedKeys, secretkey);
        jsonObject.put("secureHash", secureHash);
        return jsonObject.toString();
    }

    //private static List<String> getSortedKeyList(JSONObject jsonObject) {
    //    List<String> list = new ArrayList<>();
    //    Iterator<String> keys = jsonObject.keys();
    //    while (keys.hasNext()) {
    //        String currentKey = keys.next();
    //        if (!currentKey.equalsIgnoreCase("secureHash"))
    //            list.add(currentKey);
    //    }
    //    Collections.sort(list);
    //    return list;
    //}

    //private static String getSecureHash(JSONObject jsonObject, List<String> keys, String secretKey) throws NoSuchAlgorithmException {
    //    String secureHash = "";
    //    secureHash = secureHash + secretKey;
    //    for (String key : keys) {
    //        String value = jsonObject.getString(key);
    //        secureHash = secureHash + value;
    //    }
    //    MessageDigest md = MessageDigest.getInstance("SHA-256");
    //    secureHash = DatatypeConverter.printHexBinary(md.digest(secureHash.getBytes()));
    //    return secureHash;
    //}
    //private static MerchantPaymentLinkDataReq getMerchantPaymentLinkDataReq(){
    //    MerchantPaymentLinkDataReq merchantPaymentLinkDataReq = new MerchantPaymentLinkDataReq();
    //    merchantPaymentLinkDataReq.setMid("100000000003216");
    //    merchantPaymentLinkDataReq.setTid("12866208");
    //    merchantPaymentLinkDataReq.setEntityId("24520");
    //    merchantPaymentLinkDataReq.setTxnAmt("100");
    //    merchantPaymentLinkDataReq.setMerchantTxnRefNo("ANK000009");
    //    merchantPaymentLinkDataReq.setCustomerMobNo("9768145197");
    //    merchantPaymentLinkDataReq.setLinkExpiryDate("2024-11-28T00:00:00.000000+00:00");
    //    merchantPaymentLinkDataReq.setSmsEnabled("Y");
    //    merchantPaymentLinkDataReq.setEmailEnabed("Y");
    //    return merchantPaymentLinkDataReq;
    //}

    private static MerchantPaymentLinkDataReq getMerchantPaymentLinkDataReq(){
        MerchantPaymentLinkDataReq merchantPaymentLinkDataReq = new MerchantPaymentLinkDataReq();
        merchantPaymentLinkDataReq.setMid("100000000003216");
        merchantPaymentLinkDataReq.setTid("12866208");
        merchantPaymentLinkDataReq.setEntityId("24520");
        merchantPaymentLinkDataReq.setTxnAmt("100");
        //merchantPaymentLinkDataReq.setMerchantTxnRefNo("PRK000253");
        //merchantPaymentLinkDataReq.setMerchantTxnRefNo("GYU000252");
        merchantPaymentLinkDataReq.setLinkExpiryDate("2024-11-28T00:00:00.000000+00:00");
        merchantPaymentLinkDataReq.setUdf01("1");
        merchantPaymentLinkDataReq.setUdf02("1");
        merchantPaymentLinkDataReq.setUdf03("1");
        merchantPaymentLinkDataReq.setUdf04("1");
        merchantPaymentLinkDataReq.setUdf05("1");
        merchantPaymentLinkDataReq.setUdf06("1");
        merchantPaymentLinkDataReq.setUdf07("1");
        merchantPaymentLinkDataReq.setUdf08("1");
        merchantPaymentLinkDataReq.setUdf09("1");
        merchantPaymentLinkDataReq.setUdf10("1");

        // TEST CASES

        //System.out.println("1");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");
        //merchantPaymentLinkDataReq.setCustomerEmail("");
        //merchantPaymentLinkDataReq.setSmsEnabled("Y");
        //merchantPaymentLinkDataReq.setCustomerMobNo("");

        //System.out.println("2");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");
        //merchantPaymentLinkDataReq.setSmsEnabled("Y");

        //System.out.println("3");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");
        //merchantPaymentLinkDataReq.setCustomerEmail("");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");
        //merchantPaymentLinkDataReq.setCustomerMobNo("");

        //System.out.println("4");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");

        //System.out.println("5");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");
        //merchantPaymentLinkDataReq.setCustomerEmail("gayatrim@insolutionsglobal.com");
        //merchantPaymentLinkDataReq.setSmsEnabled("Y");
        //merchantPaymentLinkDataReq.setCustomerMobNo("7045009564");

        //System.out.println("6");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");
        //merchantPaymentLinkDataReq.setCustomerEmail("gayatrim@insolutionsglobal.com");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");
        //merchantPaymentLinkDataReq.setCustomerMobNo("7045009564");

        //System.out.println("7");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");
        //merchantPaymentLinkDataReq.setCustomerEmail("");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");
        //merchantPaymentLinkDataReq.setCustomerMobNo("");

        //System.out.println("8");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");

        //System.out.println("9");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");
        //merchantPaymentLinkDataReq.setCustomerEmail("gayatrim@insolutionsglobal.com");

        //System.out.println("10");
        //merchantPaymentLinkDataReq.setSmsEnabled("Y");
        //merchantPaymentLinkDataReq.setCustomerMobNo("7045009564");

        //System.out.println("11");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");
        //merchantPaymentLinkDataReq.setCustomerEmail("");

        //System.out.println("12");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");

        //System.out.println("13");
        //merchantPaymentLinkDataReq.setSmsEnabled("Y");

        //System.out.println("14");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");

        //System.out.println("15");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");

        //System.out.println("16");
        //merchantPaymentLinkDataReq.setEmailEnabed("N");
        //merchantPaymentLinkDataReq.setCustomerEmail("");

        //System.out.println("17");
        //merchantPaymentLinkDataReq.setSmsEnabled("N");
        //merchantPaymentLinkDataReq.setCustomerMobNo("");

        //System.out.println("18");
        //merchantPaymentLinkDataReq.setEmailEnabed("Y");
        //merchantPaymentLinkDataReq.setCustomerEmail("7045009564");
        //merchantPaymentLinkDataReq.setSmsEnabled("Y");
        //merchantPaymentLinkDataReq.setCustomerMobNo("gayatrim@insolutionsglobal.com");

        merchantPaymentLinkDataReq.setMerchantTxnRefNo("PRK000490");
        System.out.println("19");
        merchantPaymentLinkDataReq.setEmailEnabled("y");
        merchantPaymentLinkDataReq.setCustomerEmail("gayatrim@insolutionsglobal.com");
        merchantPaymentLinkDataReq.setSmsEnabled("y");
        merchantPaymentLinkDataReq.setCustomerMobNo("7045009564");

        //System.out.println("20");
        //merchantPaymentLinkDataReq.setSmsEnabled("n");
        //merchantPaymentLinkDataReq.setCustomerEmail("");
        //merchantPaymentLinkDataReq.setEmailEnabed("n");
        //merchantPaymentLinkDataReq.setCustomerMobNo("");

        return merchantPaymentLinkDataReq;
    }


    //private static MerchantEncDataRequest getRefundStatusMerchantEncDataRequest() {
    //    MerchantEncDataRequest merDataReq = new MerchantEncDataRequest();
    //    merDataReq.setBankId("24520");
    //    merDataReq.setMerchantId("10000012345");
    //    merDataReq.setPassCode("TSFC9767");
    //    merDataReq.setTerminalId("1000001");
    //    merDataReq.setTxnRefNo("1699888114305");
    //    merDataReq.setRefCancelId("665672921");
    //    merDataReq.setTxnType("Refund");
    //    return merDataReq;
    //}
}

