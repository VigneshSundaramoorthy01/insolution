package com.isg.mw.routing.route.bmsswitch;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

class CustomNamespacePrefixMapper extends com.sun.xml.bind.marshaller.NamespacePrefixMapper {
    private static final String BBPS_PREFIX = "bbps";
    private static final String BBPS_URI = "http://bbps.org/schema";

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
        logger.info("namespace :{} suggestion :{} require :{}",namespaceUri,suggestion,requirePrefix);
        if (BBPS_URI.equals(namespaceUri)) {
            return BBPS_PREFIX;
        }
        return suggestion;
    }
}