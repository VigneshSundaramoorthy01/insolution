package com.isg.mw.routing.exception;

/**
 * @author shital3986
 */
public class CaptureAmountExceededException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public CaptureAmountExceededException(String errorMsg) {
        super(errorMsg);
    }

    public CaptureAmountExceededException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}
