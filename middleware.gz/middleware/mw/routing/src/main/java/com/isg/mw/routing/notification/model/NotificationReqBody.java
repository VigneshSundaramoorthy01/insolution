package com.isg.mw.routing.notification.model;

import com.isg.mw.core.notification.model.DataElements;
import com.isg.mw.core.notification.model.NotificationReqModel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import static com.isg.mw.core.notification.utils.NotificationUtility.getJsonString;
import static com.isg.mw.core.notification.utils.NotificationUtility.isDataBlank;

@PropertySource("${spring.config.location}init-sc.properties")
@Configuration
@Setter
@Getter
public class NotificationReqBody {
    @Value("${init.req.email.templateId}")
    private Integer emailTemplateId;

    @Value("${init.req.sms.templateId}")
    private Integer mobTemplateId;

    @Value("${init.req.email.comunicationMode}")
    private String emailComunicationMode;

    @Value("${init.req.sms.comunicationMode}")
    private String smsComunicationMode;

    @Value("${init.req.comunicationString}")
    private String comunicationString;

    @Value("${init.req.serviceRequestId}")
    private String serviceRequestId;

    @Value("${init.req.languageId}")
    private Integer languageId;

    @Value("${init.req.productCode}")
    private String productCode;

    @Value("${init.req.subjectLine}")
    private String subjectLine;

    @Value("${init.req.ccEmailIds}")
    private String ccEmailIds;

    @Value("${init.req.bccEmailIds}")
    private String bccEmailIds;

    @Value("${init.req.serviceRequestNo}")
    private String serviceRequestNo;

    @Value("${init.req.homePageLink}")
    private String homePageLink;

    public NotificationReqModel toNotificationReqModel(String bankId, String mobileNo, String emailId, DataElements dataElements){
        NotificationReqModel reqModel = new NotificationReqModel();
        if(!StringUtils.isEmpty(mobileNo)){
            reqModel.setTemplateId(this.mobTemplateId);
            reqModel.setComunicationMode(isDataBlank(this.smsComunicationMode));
        }if(!StringUtils.isEmpty(emailId)){
            reqModel.setComunicationMode(isDataBlank(this.emailComunicationMode));
            reqModel.setTemplateId(this.emailTemplateId);
        }
        reqModel.setComunicationString(isDataBlank(this.comunicationString));
        reqModel.setMobileNos(isDataBlank(mobileNo));
        reqModel.setToEmailIds(isDataBlank(emailId));
        reqModel.setCcEmailIds(isDataBlank(this.ccEmailIds));
        reqModel.setBccEmailIds(isDataBlank(this.bccEmailIds));
        reqModel.setServiceRequestId(isDataBlank(this.serviceRequestId));
        reqModel.setServiceRequestNo(isDataBlank(this.serviceRequestNo));
        reqModel.setLanguageId(this.languageId);
        reqModel.setBankId(Integer.parseInt(bankId));
        reqModel.setProductCode(isDataBlank(this.productCode));
        dataElements.setHomePageLink(isDataBlank(this.homePageLink));
        reqModel.setDataElements(getJsonString(dataElements));
        reqModel.setSubjectLine(isDataBlank(this.subjectLine));
        return reqModel;
    }
}
