package com.isg.mw.routing.route.codec;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.bytes.ByteArrayDecoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

@ChannelHandler.Sharable
public class BinaryFileDecoder extends ByteArrayDecoder {

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf msg, List<Object> out) {
        try {
            super.decode(ctx, msg, out);
        }
        catch (Exception e) {
            logger.error("BinaryFileDecoder: Error while decoding: {}", e.getMessage());
            logger.trace("BinaryFileDecoder: Message readableBytes: {}, Capacity: {}",
                    msg.readableBytes(), msg.capacity());
        }
    }
}