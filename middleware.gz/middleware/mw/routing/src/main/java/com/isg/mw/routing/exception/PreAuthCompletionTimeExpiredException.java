package com.isg.mw.routing.exception;

/**
 * 
 * @author shital3986
 *
 */
public class PreAuthCompletionTimeExpiredException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PreAuthCompletionTimeExpiredException(String errorMsg) {
		super(errorMsg);
	}

	public PreAuthCompletionTimeExpiredException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}
