package com.isg.mw.routing.config;

import com.isg.mw.routing.route.codec.CustomLengthFieldBasedFrameDecoder;
import com.isg.mw.routing.route.codec.VisaCustomLengthFieldBasedFrameDecoder;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class BeanConfiguration {

    @Bean
    @Scope(BeanDefinition.SCOPE_PROTOTYPE)
    public CustomLengthFieldBasedFrameDecoder decoder(int maxFrameLength,
                                                      int lengthFieldOffset, int lengthFieldLength,
                                                      int lengthAdjustment, int initialBytesToStrip) {
        return new CustomLengthFieldBasedFrameDecoder(maxFrameLength, lengthFieldOffset, lengthFieldLength,
                lengthAdjustment, initialBytesToStrip);
    }

    @Bean
    @Scope(BeanDefinition.SCOPE_PROTOTYPE)
    public VisaCustomLengthFieldBasedFrameDecoder visaDecoder(int maxFrameLength,
                                                              int lengthFieldOffset, int lengthFieldLength,
                                                              int lengthAdjustment, int initialBytesToStrip) {
        return new VisaCustomLengthFieldBasedFrameDecoder(maxFrameLength, lengthFieldOffset, lengthFieldLength,
                lengthAdjustment, initialBytesToStrip);
    }
}
