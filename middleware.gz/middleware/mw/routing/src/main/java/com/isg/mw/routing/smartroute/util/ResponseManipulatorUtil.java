package com.isg.mw.routing.smartroute.util;

import static com.isg.mw.routing.config.RoutingConstants.EXCHANGE_HEADER_TARGET_ID;

import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.isg.mw.cache.mgmt.config.CacheUtil;
import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.Target;
import com.isg.mw.core.model.sr.TargetInfo;
import com.isg.mw.core.model.sr.TargetKey;
import com.isg.mw.core.model.sr.Targets;
import com.isg.mw.routing.context.RoutingContext;
import com.isg.mw.routing.exception.IssuerUnavailableException;
import com.isg.mw.cache.mgmt.config.CacheHelper;

@Component
public class ResponseManipulatorUtil {

    private Logger logger = LogManager.getLogger();

    @Value("${smartroute.test.response.simulator}")
    private String simulatorTestFile;

    @Autowired
    private CacheHelper cacheHelper;

    @Autowired
    private CacheUtil cacheUtil;

    public void manipulateTxnResponse(Exchange exchange, RoutingContext routingContext) {
        if (simulatorTestFile == null) {
            logger.debug("Response simulator file for smart route testing not found");
            return;
        }
        SourceConfigModel sourceConfigModel = routingContext.getSource();
        Map<TargetKey, TargetInfo> targetData = cacheUtil.getTargetData(cacheHelper.getTargetMapKey(sourceConfigModel));
//        logger.trace("TargetData from cache util : {} ", targetData);
        Long id = (Long) exchange.getIn().getHeaders().get(EXCHANGE_HEADER_TARGET_ID);

        List<Target> targetJsonList = readSimulatorTestFile();
        logger.trace("Read data from json file : {} ", targetJsonList);

        Map<TargetKey, TargetInfo> targetMap = targetData.entrySet().stream()
                .filter(map -> map.getKey().getTargetId().equals(String.valueOf(id)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

//        logger.trace("Getting target map : {} ", targetMap);

        Iterator<TargetKey> iterator = targetMap.keySet().iterator();
        while (iterator.hasNext()) {
            TargetKey targetKey = iterator.next();
            TargetInfo targetInfo = targetMap.get(targetKey);
            for (Target target : targetJsonList) {
                if (targetInfo.getTargetName().equals(target.getTargetName())) {
                    Double calculatedFailPercent = calTargetFailPercent(targetInfo);
                    if (calculatedFailPercent.compareTo(target.getExpectedFailPercent()) < 0) {
                        throw new IssuerUnavailableException("Deliberately failed the transaction : ");
                    }
                }
            }
        }
    }

    private double calTargetFailPercent(TargetInfo value) {
        double i = (double) value.getTotalTxnFailed() / (double) value.getTotalTxnCount();
        return i * 100;
    }

    public List<Target> readSimulatorTestFile() {
        if (simulatorTestFile == null) {
            logger.debug("Response simulator file for smart route testing not found");
            return null;
        }
        try (FileReader reader = new FileReader(simulatorTestFile)) {
            ObjectMapper objectMapper = new ObjectMapper();
            Targets readValue = objectMapper.readValue(reader, Targets.class);

            if (!CollectionUtils.isEmpty(readValue.getTargets())) {
                return readValue.getTargets();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

}
