package com.isg.mw.routing.exception;

public class RequestProcessingException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RequestProcessingException(String errorMsg) {
		super(errorMsg);
	}

	public RequestProcessingException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}
}
