package com.isg.mw.routing.context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import org.apache.kafka.common.serialization.Serializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.tlm.TransactionMessageModel;

public class TransactionMessageModelSerializer implements Serializer<TransactionMessageModel> {

	private Logger logger = LogManager.getLogger(getClass());

	@Override
	public byte[] serialize(String topic, TransactionMessageModel data) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos;
		try {
			oos = new ObjectOutputStream(bos);
			oos.writeObject(data);
			oos.flush();
		} catch (IOException e) {
			logger.error("Error while serializing object: {}", e);
		}
		return bos.toByteArray();
	}

}
