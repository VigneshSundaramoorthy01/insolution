package com.isg.mw.routing.consumer;

import com.isg.kafka.config.KafkaConfig;
import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.routing.route.TransactionProcessorHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

@Component
@PropertySources({
        @PropertySource("${spring.config.location}kafka-config.properties"),
        @PropertySource("${spring.config.location}routing-config.properties")})
public class ConsumeKafkaReversalMsg implements ApplicationRunner {

    private static Logger logger = LogManager.getLogger();

    @Value("${kafka.topic.auto.reversal}")
    private String topicName;

    @Value("${kafka.brokers}")
    private String brokers;

    @Value("${kafka.consumer.failed.msg.redeliveries:3}")
    private Integer failedMsgRedeliveries;

    @Value("${kafka.consumer.failed.msg.redelivery.delay:3000}")
    private Integer failedMsgRedeliveryDelay;

    @Value("${kafka.topic.partitions:3}")
    private Integer topicPartitions;

    @Value("${kafka.consumer.auto.commit:false}")
    private Boolean autoCommit;

    @Value("${kafka.security.enabled:false}")
    private boolean kafkaSecurityEnabled;

    @Value("${kafka.truststore.location:}")
    private String trustStoreLocation;

    @Value("${kafka.truststore.password:}")
    private String trustStorePassword;

    @Value("${kafka.set.protocol:}")
    private String protocol;

    @Value("${kafka.set.sasl.mechanism:}")
    private String saslMechanism;

    @Value("${kafka.truststore.type:}")
    private String trustStoreType;

    @Value("${kafka.jaas.config:}")
    private String saslJaasConfig;

    @Value("${kafka.max.poll.records:100}")
    private int maxPollRecords;

    @Value("${kafka.max.poll.interval.ms:300000}")
    private long maxPollIntervalMs;

    @Autowired
    private TransactionProcessorHelper processorHelper;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        logger.info(PropertyUtils.getMessage("Kafka-com.isg.mw.routing.autoReversal.consumer-001"));

        try {
            KafkaConsumer consumer = new KafkaConsumer(setKafkaConfiguration(), processorHelper, "generateAutoReversal");
            consumer.init();
        } catch (Exception e) {
            logger.fatal(PropertyUtils.getMessage("Kafka-com.isg.mw.routing.autoReversal.consumer-002"));
            throw e;
        }
    }

    private KafkaConfig setKafkaConfiguration() {
        KafkaConfig config = new KafkaConfig();
        config.setTopicName(this.topicName);
        config.setBrokers(brokers);
        config.setMaxFailedMsgRedeliveries(failedMsgRedeliveries);
        config.setMaxFailedMsgRedeliveryDelay(failedMsgRedeliveryDelay);
        config.setConsumersCount(topicPartitions);
        config.setAutoCommitEnable(autoCommit);
        config.setValueDeserializer(TransactionMessageModelDeserializer.class);
        config.setMaxPollRecords(maxPollRecords);
        config.setMaxPollIntervalMs(maxPollIntervalMs);

        //Security configuration
        config.setKafkaSecurityEnabled(kafkaSecurityEnabled);
        config.setProtocol(protocol);
        config.setTrustStoreLocation(trustStoreLocation);
        config.setTrustStorePassword(trustStorePassword);
        config.setTrustStoreType(trustStoreType);
        config.setEndPointAlgorithm("");
        config.setSaslJaasConfig(saslJaasConfig);
        config.setSaslMechanism(saslMechanism);
        return config;
    }
}
