package com.isg.routing;

import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class TxnIdGeneratorTest {
    private static final ConcurrentHashMap<Long, Integer> x = new ConcurrentHashMap<Long, Integer>();
    public static void main(String[] args) {
        int nThreads = 20000;
        ExecutorService ex = Executors.newFixedThreadPool(nThreads/10);


        for (int i = 0; i < nThreads; ++i) {
            Runnable w = new Runnable() {
                @Override
                public void run() {
                    Long x1 = TxnIdGenerator.INSTANCE.generate(10,20);
                    Integer cnt = x.get(x1) ;
                    if (cnt != null) {
                        cnt++;
                        x.put(x1, cnt);
                    }
                    else
                        x.put(x1,1);
//System.out.println("TxnId: " + x1 + ", Count: " + cnt);
                }
            };
            ex.execute(w);
        }
        ex.shutdown();
        try {
            ex.awaitTermination(60, TimeUnit.SECONDS);
        } catch (Exception e ) {
            e.printStackTrace();
        }
        for (Long x1: Collections.list(x.keys())) {
            Integer cnt = x.get(x1);
            if (cnt > 1)
                System.out.println("Duplicate: TxnId: " + x1 + ", Count: " + cnt);
        }
    }
}