package com.isg.mw.cache.mgmt.config;

import static org.junit.Assert.assertNull;

import org.ehcache.event.CacheEvent;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CacheLoggerTest {

	@Mock
	private CacheEvent<?, ?> cacheEvent;

	@InjectMocks
	private CacheLogger cacheLogger;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void onEventTest() {
		String msg = null;
		try {
			cacheLogger.onEvent(cacheEvent);
		} catch (Exception e) {
			msg = e.getMessage();
		}
		assertNull(msg);
	}
}
