package com.isg.mw.cache.mgmt;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.isg.mw.core.utils.CardValidator;

/**
 * @author sudharshan
 */
public class CardValidatorTest {

	@Test
	public void testCheckLuhn() {
		assertEquals(true, CardValidator.checkLuhn("0000000000000000"));
		assertEquals(false, CardValidator.checkLuhn("0000000000000001"));

		assertEquals(true, CardValidator.checkLuhn("4000056655665556"));
		assertEquals(true, CardValidator.checkLuhn("4242424242424242"));
		assertEquals(false, CardValidator.checkLuhn("4242424242424243"));

		assertEquals(true, CardValidator.checkLuhn("5105105105105100"));
		assertEquals(true, CardValidator.checkLuhn("5200828282828210"));
		assertEquals(true, CardValidator.checkLuhn("5555555555554444"));
		assertEquals(false, CardValidator.checkLuhn("5555555555554445"));

		assertEquals(true, CardValidator.checkLuhn("371449635398431"));
		assertEquals(true, CardValidator.checkLuhn("378282246310005"));
		assertEquals(false, CardValidator.checkLuhn("378282246310006"));

		assertEquals(true, CardValidator.checkLuhn("6011000990139424"));
		assertEquals(true, CardValidator.checkLuhn("6011111111111117"));
		assertEquals(false, CardValidator.checkLuhn("6011111111111118"));

		assertEquals(true, CardValidator.checkLuhn("3530111333300000"));
		assertEquals(true, CardValidator.checkLuhn("3566002020360505"));
		assertEquals(false, CardValidator.checkLuhn("3566002020360506"));

		assertEquals(true, CardValidator.checkLuhn("30000000000004"));
		assertEquals(false, CardValidator.checkLuhn("30520000023237"));
	}

}
