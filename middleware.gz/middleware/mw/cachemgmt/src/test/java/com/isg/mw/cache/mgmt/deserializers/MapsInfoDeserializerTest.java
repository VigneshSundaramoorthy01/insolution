package com.isg.mw.cache.mgmt.deserializers;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.maps.MapsInfoModel;

public class MapsInfoDeserializerTest {

	@Mock
	private ObjectInputStream ois;
	@InjectMocks
	private MapsInfoDeserializer mapsInfoDeserializer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void deserialize() throws ClassNotFoundException, IOException {
		String str = null;
		MapsInfoModel mapsInfoModel = null;
		MapsInfoModel model = new MapsInfoModel();
		model.setAcquirerCurrencyCode("356");

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(model);
		oos.flush();
		try {
			mapsInfoModel = mapsInfoDeserializer.deserialize("countryInfo", bos.toByteArray());
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
		assertNotNull(mapsInfoModel);
	}

	@Test
	public void deserialize_Exception() throws ClassNotFoundException, IOException {
		String str = null;
		MapsInfoModel mapsInfoModel = null;
		MapsInfoModel model = new MapsInfoModel();
		model.setAcquirerCurrencyCode("356");
		ObjectMapper obj = new ObjectMapper();
		try {
			mapsInfoModel = mapsInfoDeserializer.deserialize("binInfo", obj.writeValueAsBytes(model));
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
		assertNull(mapsInfoModel);
	}

}
