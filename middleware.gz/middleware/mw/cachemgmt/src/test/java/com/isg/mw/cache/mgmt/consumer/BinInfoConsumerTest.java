package com.isg.mw.cache.mgmt.consumer;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.ApplicationArguments;

import com.isg.kafka.config.KafkaConfig;
import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.service.BinInfoService;
import com.isg.mw.core.model.bi.BinInfoModel;

import java.math.BigInteger;

/**
 * 
 * @author shital3986
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BinInfoConsumerTest {

	@Mock
	private CacheKafkaConfig cacheKafkaConfig;

	@Mock
	private BinInfoService binInfoService;

	@Mock
	private KafkaConsumer kafkaConsumer;

	@InjectMocks
	private BinInfoConsumer binInfoConsumer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void runTest() throws Exception {
		when(cacheKafkaConfig.getKafkaConfig(Mockito.any(), Mockito.any())).thenReturn(getKafkaConfig());
		ApplicationArguments args = null;
		String str = null;
		try {
			binInfoConsumer.run(args);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void runTest_Exception() throws Exception {
		when(cacheKafkaConfig.getKafkaConfig(Mockito.any(), Mockito.any())).thenThrow(NullPointerException.class);
		ApplicationArguments args = null;
		String str = null;
		try {
			binInfoConsumer.run(args);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	@Test
	public void cacheBinInfoConsumerTest() {
		String str = null;
		try {
			binInfoConsumer.cacheBinInfoConsumer(getBinInfoModel());
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	@Test
	public void cacheBinInfoConsumerTest_Exception() {
		String str = null;
		when(binInfoService.updateBinInfo(Mockito.any())).thenThrow(NullPointerException.class);
		try {
			binInfoConsumer.cacheBinInfoConsumer(null);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	private BinInfoModel getBinInfoModel() {
		BinInfoModel binInfo = new BinInfoModel();
		binInfo.setSchemeName("VISA");
		binInfo.setBinLow(new BigInteger("452811000"));
		binInfo.setBinHigh(new BigInteger("45281199"));
		return binInfo;
	}

	private KafkaConfig getKafkaConfig() {
		KafkaConfig kafkaConfig = new KafkaConfig();
		kafkaConfig.setTopicName("Txn");
		kafkaConfig.setBrokers("localhost:1234");
		return kafkaConfig;
	}
}
