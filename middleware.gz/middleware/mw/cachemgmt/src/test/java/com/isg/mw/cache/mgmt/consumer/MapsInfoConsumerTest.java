package com.isg.mw.cache.mgmt.consumer;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.ApplicationArguments;

import com.isg.kafka.config.KafkaConfig;
import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;

public class MapsInfoConsumerTest {

	@Mock
	private CacheKafkaConfig cacheKafkaConfig;

	@Mock
	private MapsInfoService mapsInfoService;

	@Mock
	private KafkaConsumer kafkaConsumer;

	@InjectMocks
	private MapsInfoConsumer mapsInfoConsumer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void runTest() throws Exception {
		when(cacheKafkaConfig.getKafkaConfig(Mockito.any(), Mockito.any())).thenReturn(getKafkaConfig());
		ApplicationArguments args = null;
		String str = null;
		try {
			mapsInfoConsumer.run(args);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void runTest_Exception() throws Exception {
		when(cacheKafkaConfig.getKafkaConfig(Mockito.any(), Mockito.any())).thenThrow(NullPointerException.class);
		ApplicationArguments args = null;
		String str = null;
		try {
			mapsInfoConsumer.run(args);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	@Test
	public void cacheMapsInfoConsumerTest() {
		String str = null;
		try {
			mapsInfoConsumer.cacheMapsInfoConsumer(getMapsInfoModel());
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	 
	@Test
	public void cacheMapsInfoConsumerTest_Exception() {
		String str = null;
		when(mapsInfoService.updateMapsInfo(Mockito.any())).thenThrow(NullPointerException.class);
		try {
			mapsInfoConsumer.cacheMapsInfoConsumer(null);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}
	
	private MapsInfoModel getMapsInfoModel() {
		MapsInfoModel merchantInfo = new MapsInfoModel();
		merchantInfo.setMid("145404453445300");
		merchantInfo.setTid("11004448");
		merchantInfo.setMerchantName("Gold super market");
		merchantInfo.setEntityId("2341231223131232");
		return merchantInfo;
	}

	private KafkaConfig getKafkaConfig() {
		KafkaConfig kafkaConfig = new KafkaConfig();
		kafkaConfig.setTopicName("Txn");
		kafkaConfig.setBrokers("localhost:1234");
		return kafkaConfig;
	}

}
