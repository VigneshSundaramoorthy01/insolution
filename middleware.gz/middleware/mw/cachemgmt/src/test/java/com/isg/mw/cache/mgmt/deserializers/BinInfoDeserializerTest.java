package com.isg.mw.cache.mgmt.deserializers;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;

public class BinInfoDeserializerTest {

	@Mock
	private ObjectInputStream ois;
	@InjectMocks
	private BinInfoDeserializer binInfoDeserializer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void deserialize() throws ClassNotFoundException, IOException {
		String str = null;
		BinInfoModel binInfoModel = null;
		BinInfoModel model = new BinInfoModel();
		model.setActiveFlag(ActiveFlag.N);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(model);
		oos.flush();
		try {
			binInfoModel = binInfoDeserializer.deserialize("binInfo", bos.toByteArray());
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
		assertNotNull(binInfoModel);
	}

	@Test
	public void deserialize_IoException() throws ClassNotFoundException, IOException {
		String str = null;
		BinInfoModel binInfoModel = null;
		BinInfoModel model = new BinInfoModel();
		model.setActiveFlag(ActiveFlag.N);
		ObjectMapper obj = new ObjectMapper();
		try {
			binInfoModel = binInfoDeserializer.deserialize("binInfo", obj.writeValueAsBytes(model));
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
		assertNull(binInfoModel);
	}

}
