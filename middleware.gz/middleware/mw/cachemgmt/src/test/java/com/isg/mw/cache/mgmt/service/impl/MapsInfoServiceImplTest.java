package com.isg.mw.cache.mgmt.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.cache.CacheException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.core.model.maps.MapsInfoModel;

/**
 * 
 * @author shital3986
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class MapsInfoServiceImplTest {

	@Mock
	private CacheManager cacheManager;

	@InjectMocks
	private MapsInfoServiceImpl merchantDataInfoImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void updateMapsInfoTest_mapInfoModel_Not_Null() {
		Cache cache = mock(Cache.class);
		when(cacheManager.getCache(Mockito.anyString())).thenReturn(cache);
		boolean response = merchantDataInfoImpl.updateMapsInfo(getMapsInfoModel());
		assertTrue(response);
	}

	@Test
	public void updateMapsInfoTest_mapInfoModel_Null() {
		Cache cache = mock(Cache.class);
		when(cacheManager.getCache(Mockito.anyString())).thenReturn(cache);
		boolean response = merchantDataInfoImpl.updateMapsInfo(null);
		assertFalse(response);
	}

	@Test
	public void updateMapsInfoTest_Exception() {
		when(cacheManager.getCache(Mockito.anyString())).thenThrow(NullPointerException.class);
		boolean response = merchantDataInfoImpl.updateMapsInfo(getMapsInfoModel());
		assertFalse(response);
	}

	@Test
	public void getMapsInfoByIdTest() {
		Cache cache = mock(Cache.class);
		String key = getMapsInfoModel().getEntityId() + CacheConstants.KEY_SEPERATE + getMapsInfoModel().getMid()
				+ CacheConstants.KEY_SEPERATE + getMapsInfoModel().getTid();
		cache.putIfAbsent(key, getMapsInfoModel());
		when(cacheManager.getCache(Mockito.anyString())).thenReturn(cache);
		// when(cache.get(Mockito.any())).thenReturn(MapsInfoModel);
		MapsInfoModel mapsInfoModel = merchantDataInfoImpl.getMapsInfoById(key);
		assertNull(mapsInfoModel);
	}

	@Test
	public void getMapsInfoByIdTest_CacheException() {
		Cache cache = mock(Cache.class);
		String key = getMapsInfoModel().getEntityId() + CacheConstants.KEY_SEPERATE + getMapsInfoModel().getMid()
				+ CacheConstants.KEY_SEPERATE + getMapsInfoModel().getTid();
		cache.putIfAbsent(key, getMapsInfoModel());
		when(cacheManager.getCache(Mockito.anyString())).thenReturn(cache);
		when(cache.get(Mockito.any())).thenThrow(CacheException.class);
		MapsInfoModel mapsInfoModel = merchantDataInfoImpl.getMapsInfoById(null);
		assertNull(mapsInfoModel);
	}

	private MapsInfoModel getMapsInfoModel() {
		MapsInfoModel merchantInfo = new MapsInfoModel();
		merchantInfo.setMid("145404453445300");
		merchantInfo.setTid("11004448");
		merchantInfo.setMerchantName("Gold super market");
		merchantInfo.setEntityId("2341231223131232");
		return merchantInfo;
	}
}
