package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.service.BinInfoService;
import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.SchemeDestinationInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.md.CountryInfoModel;
import com.isg.mw.core.model.md.CurrencyInfoModel;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * 
 * @author shital3986
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CacheServicesImplTest {

	@Mock
	private MapsInfoService mapsInfoService;

	@Mock
	private BinInfoService binInfoService;

	@InjectMocks
	private CacheServicesImpl cacheServicesImpl;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void initCacheTest() {
		List<MapsInfoModel> mapInfoModelList = new ArrayList<>();
		mapInfoModelList.add(getMapsInfoModel());
		List<BinInfoModel> binInfoModelList = new ArrayList<>();
		binInfoModelList.add(getBinInfoModel());
		List<SchemeDestinationInfoModel> schemeDestInfoModelList = new ArrayList<>();
		schemeDestInfoModelList.add(getSchemeDestinationInfoModel());
		List<CountryInfoModel> countryInfoModelList = new ArrayList<>();
		countryInfoModelList.add(getCountryInfoModel());
		List<CurrencyInfoModel> currencyInfoModelList = new ArrayList<>();
		currencyInfoModelList.add(getCurrencyInfoModel());
	}

	@Test
	public void initConfigurationsTest() {
		List<MapsInfoModel> mapInfoModelList = new ArrayList<>();
		mapInfoModelList.add(getMapsInfoModel());
		List<BinInfoModel> binInfoModelList = new ArrayList<>();
		binInfoModelList.add(getBinInfoModel());
		String str = null;
		try {
			cacheServicesImpl.initMapsConfigurations(mapInfoModelList);
		} catch (Exception e) {
			str = e.getMessage();
		}
		assertNull(str);
	}

	@Test
	public void validateAndGetMerchantTest_Model_Not_Null() {
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(getMapsInfoModel());
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_Model_Null() {
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(null);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_EntityId_Null() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setEntityId(null);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNotNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_Diff_Mid() {
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(getMapsInfoModel());
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP", "HPYBL007", "356");
		assertNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_ActiveStatus() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setMerchantStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_Same_Tid() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setMerchantStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_Diff_Tid() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setMerchantStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL00",
				"356");
		assertNull(mapsInfoModel);
	}

	@Test
	public void validateAndGetMerchantTest_ActiveTerminalStatus() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setTerminalStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNull(mapsInfoModel);
	}

	/*@Test
	public void validateAndGetMerchantTest_Diff_Currency() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setMerchantStatus(ActiveInactiveFlag.Active);
		mapsInfoModel2.setTerminalStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"355");
		assertNull(mapsInfoModel);
	}*/

	/*@Test
	public void validateAndGetMerchantTest_Same_Currency() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setMerchantStatus(ActiveInactiveFlag.Active);
		mapsInfoModel2.setTerminalStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				"356");
		assertNotNull(mapsInfoModel);
	}*/

	/*@Test
	public void validateAndGetMerchantTest_Null_Currency() {
		MapsInfoModel mapsInfoModel2 = getMapsInfoModel();
		mapsInfoModel2.setMerchantStatus(ActiveInactiveFlag.Active);
		mapsInfoModel2.setTerminalStatus(ActiveInactiveFlag.Active);
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenReturn(mapsInfoModel2);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				null);
		assertNotNull(mapsInfoModel);
	}*/

	@Test
	public void validateAndGetMerchantTest_Exception() {
		when(mapsInfoService.getMapsInfoById(Mockito.any())).thenThrow(NullPointerException.class);
		MapsInfoModel mapsInfoModel = cacheServicesImpl.validateAndGetMerchant("isg", "HPYBIJALIP00007", "HPYBL007",
				null);
		assertNull(mapsInfoModel);
	}

	@Test
	public void getTargetTest_BinInfoModel_Null() {
		when(binInfoService.getBinInfoByCardNumber(Mockito.any())).thenReturn(null);
	}

	@Test
	public void getSchemeNameTest_binInfoModel_Not_Null() {
		when(binInfoService.getBinInfoByCardNumber(Mockito.any())).thenReturn(getBinInfoModel());
		String schemeName = cacheServicesImpl.getSchemeName("1234567789");
		assertNotNull(schemeName);
		assertEquals("Master", schemeName);
	}

	@Test
	public void getSchemeNameTest_binInfoModel_Null() {
		when(binInfoService.getBinInfoByCardNumber(Mockito.any())).thenReturn(null);
		String schemeName = cacheServicesImpl.getSchemeName("1234567789");
		assertNull(schemeName);
	}

	private MapsInfoModel getMapsInfoModel() {
		MapsInfoModel mapsInfoModel = new MapsInfoModel();
		mapsInfoModel.setAcquirerCurrencyCode("356");
		mapsInfoModel.setTid("HPYBL007");
		mapsInfoModel.setMid("HPYBIJALIP00007");
		mapsInfoModel.setEntityId("isg");
		mapsInfoModel.setMerchantStatus(ActiveInactiveFlag.Inactive);
		return mapsInfoModel;
	}

	private BinInfoModel getBinInfoModel() {
		BinInfoModel binInfoModel = new BinInfoModel();
		binInfoModel.setActiveFlag(ActiveFlag.N);
		binInfoModel.setBinNumber(new BigInteger("12"));
		binInfoModel.setSchemeName("Master");
		return binInfoModel;
	}

	private SchemeDestinationInfoModel getSchemeDestinationInfoModel() {
		SchemeDestinationInfoModel schemeDestInfoModel = new SchemeDestinationInfoModel();
		schemeDestInfoModel.setEntityId("isg");
		schemeDestInfoModel.setDestinationId("1200");
		return schemeDestInfoModel;
	}

	private CountryInfoModel getCountryInfoModel() {
		CountryInfoModel countryInfoModel = new CountryInfoModel();
		countryInfoModel.setCountryName("India");
		countryInfoModel.setCountryCode("11");
		return countryInfoModel;
	}

	private CurrencyInfoModel getCurrencyInfoModel() {
		CurrencyInfoModel currencyInfoModel = new CurrencyInfoModel();
		currencyInfoModel.setCurrencyCode("356");
		currencyInfoModel.setCurrencyName("Rupees");
		return currencyInfoModel;
	}
}
