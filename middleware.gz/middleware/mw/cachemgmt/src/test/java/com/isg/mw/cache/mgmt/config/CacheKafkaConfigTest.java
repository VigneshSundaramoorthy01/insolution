package com.isg.mw.cache.mgmt.config;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.isg.kafka.config.KafkaConfig;
import com.isg.mw.cache.mgmt.deserializers.BinInfoDeserializer;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = CacheKafkaConfigTest.class)
@TestPropertySource(locations = "classpath:kafka-cache-test.properties")
public class CacheKafkaConfigTest {
	
	@Value("${kafka.cache.cs.brokers.test}")
    private String brokers;
	
	@Value("${kafka.cache.cs.clientid.test}")
    private String clientId;

    @Value("${kafka.cache.cs.auto.comit.enabled.test}")
    private boolean autoCommitEnable;
    
    @Value("${kafka.cache.cs.consumers.count.test}")
    private int consumersCount;

    @Value("${kafka.cache.cs.use.original.message.test}")
    private boolean useOriginalMessage;
    
    @Value("${kafka.cache.cs.max.failed.msg.redeliveries.test}")
    private int maxFailedMsgRedeliveries;

    @Value("${kafka.cache.cs.max.failed.msg.redelivery.delay.test}")
    private long maxFailedMsgRedeliveryDelay;
    
    @Value("${kafka.cache.cs.retries.test}")
    private int retries;

    @Value("${kafka.cache.cs.request.required.acks.test}")
    private String requestRequiredAcks;

    @Value("${kafka.cache.cs.record.metadata.test}")
    private boolean recordMetadata;
    
    @Value("${kafka.cache.cs.topicname.mapsinfo.test}")
    private String mapsInfoTopicName;

    @Value("${kafka.cache.cs.topicname.binInfo.test}")
    private String binInfoTopicName;

    @Value("${kafka.cache.cs.topicname.binonusinfo.test}")
    private String binOnusInfoTopicName;
    
    @Value("${kafka.cache.cs.topicname.schemedestinationinfo.test}")
    private String schemeDestinationInfoTopicName;

    @Value("${kafka.cache.cs.topicname.countryinfo.test}")
    private String countryInfoTopicName;

    @Value("${kafka.cache.cs.topicname.currencyinfo.test}")
    private String currencyInfoTopicName;
    
    @Value("${kafka.security.enabled:false}")
    private boolean kafkaSecurityEnabled;

    @Value("${kafka.truststore.location.test}")
    private String trustStoreLocation;

    @Value("${kafka.truststore.password.test}")
    private String trustStorePassword;
    
    @Value("${kafka.set.protocol.test}")
    private String protocol;

    @Value("${kafka.set.sasl.mechanism.test}")
    private String saslMechanism;

    @Value("${kafka.truststore.type.test}")
    private String trustStoreType;
    
    @Value("${kafka.jaas.config.test}")
    private String saslJaasConfig;



	@InjectMocks
	private CacheKafkaConfig cacheKafkaConfig;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		
		System.out.println(brokers);
		ReflectionTestUtils.setField(cacheKafkaConfig, "brokers", new String(brokers));
		ReflectionTestUtils.setField(cacheKafkaConfig, "clientId", new String(clientId));
		ReflectionTestUtils.setField(cacheKafkaConfig, "autoCommitEnable",new Boolean(autoCommitEnable));
		ReflectionTestUtils.setField(cacheKafkaConfig, "consumersCount",  new Integer(consumersCount));
		ReflectionTestUtils.setField(cacheKafkaConfig, "useOriginalMessage", new Boolean(useOriginalMessage));
		ReflectionTestUtils.setField(cacheKafkaConfig, "maxFailedMsgRedeliveries", new Integer(maxFailedMsgRedeliveries));
		ReflectionTestUtils.setField(cacheKafkaConfig, "maxFailedMsgRedeliveryDelay", new Long(maxFailedMsgRedeliveryDelay));
		ReflectionTestUtils.setField(cacheKafkaConfig, "retries", new Integer(retries));
		ReflectionTestUtils.setField(cacheKafkaConfig, "requestRequiredAcks", new String(requestRequiredAcks));
		ReflectionTestUtils.setField(cacheKafkaConfig, "recordMetadata", new Boolean(recordMetadata));
		ReflectionTestUtils.setField(cacheKafkaConfig, "mapsInfoTopicName", new String(mapsInfoTopicName));
		ReflectionTestUtils.setField(cacheKafkaConfig, "binInfoTopicName", new String(binInfoTopicName));
		ReflectionTestUtils.setField(cacheKafkaConfig, "binOnusInfoTopicName", new String(binOnusInfoTopicName));
		ReflectionTestUtils.setField(cacheKafkaConfig, "schemeDestinationInfoTopicName", new String(schemeDestinationInfoTopicName));
		ReflectionTestUtils.setField(cacheKafkaConfig, "countryInfoTopicName", new String(countryInfoTopicName));
		ReflectionTestUtils.setField(cacheKafkaConfig, "currencyInfoTopicName", new String(currencyInfoTopicName));
		ReflectionTestUtils.setField(cacheKafkaConfig, "kafkaSecurityEnabled", new Boolean(true));
		ReflectionTestUtils.setField(cacheKafkaConfig, "trustStoreLocation", new String(trustStoreLocation));
		ReflectionTestUtils.setField(cacheKafkaConfig, "trustStorePassword", new String(trustStorePassword));
		ReflectionTestUtils.setField(cacheKafkaConfig, "protocol", new String(protocol));
		ReflectionTestUtils.setField(cacheKafkaConfig, "saslMechanism", new String(saslJaasConfig));
		ReflectionTestUtils.setField(cacheKafkaConfig, "trustStoreType", new String(trustStoreType));
		ReflectionTestUtils.setField(cacheKafkaConfig, "saslJaasConfig", new String(saslJaasConfig));
	}

	@Test
	public void getKafkaConfigTest() {
		String msg = null;
		KafkaConfig kafkaConfig =null;
		try {
			 kafkaConfig = cacheKafkaConfig.getKafkaConfig("Txn", BinInfoDeserializer.class);
		} catch (Exception e) {
			msg = e.getMessage();
		}
		assertNotNull(kafkaConfig);
		assertEquals(brokers, kafkaConfig.getBrokers());
		assertEquals(autoCommitEnable, kafkaConfig.isAutoCommitEnable());
		assertEquals(consumersCount, kafkaConfig.getConsumersCount());
		assertEquals(maxFailedMsgRedeliveries, kafkaConfig.getMaxFailedMsgRedeliveries());
		assertEquals(maxFailedMsgRedeliveryDelay, kafkaConfig.getMaxFailedMsgRedeliveryDelay());
		assertEquals(retries, kafkaConfig.getRetries());
		assertEquals(requestRequiredAcks, kafkaConfig.getRequestRequiredAcks());
		assertEquals(recordMetadata, kafkaConfig.isRecordMetadata());
		assertEquals(true,kafkaConfig.isKafkaSecurityEnabled());
		assertEquals(trustStoreLocation, kafkaConfig.getTrustStoreLocation());
		assertEquals(trustStorePassword, kafkaConfig.getTrustStorePassword());
		assertEquals(protocol, kafkaConfig.getProtocol());
		assertEquals(trustStoreType, kafkaConfig.getTrustStoreType());
		assertEquals(saslJaasConfig, kafkaConfig.getSaslJaasConfig());
		assertEquals("Txn", kafkaConfig.getTopicName());
		assertNull(msg);
	}

	
}
