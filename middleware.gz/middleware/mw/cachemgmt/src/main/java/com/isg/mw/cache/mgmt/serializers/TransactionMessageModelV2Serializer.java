package com.isg.mw.cache.mgmt.serializers;

import com.isg.mw.core.model.upi.TransactionMessageModelV2;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TransactionMessageModelV2Serializer implements Serializer<TransactionMessageModelV2> {

    private final Logger LOG = LoggerFactory.getLogger(TransactionMessageModelV2Serializer.class);

    @Override
    public byte[] serialize(String topic, TransactionMessageModelV2 data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(data);
            oos.flush();
        } catch (IOException e) {
            LOG.error("Error while serializing object: {}", e);
        }
        return bos.toByteArray();

    }
    }

