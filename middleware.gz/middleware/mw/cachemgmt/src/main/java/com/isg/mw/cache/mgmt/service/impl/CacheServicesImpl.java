package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.service.*;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.SignOnSignOffModel;
import com.isg.mw.core.model.eftpos.TempKeyModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Cache service Implementation.
 *
 * @author akshay3978
 */
@Service
@EnableCaching
public class CacheServicesImpl implements CacheServices {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private MapsInfoService mapsInfoService;

    @Autowired
    private BinInfoService binInfoService;


    @Autowired
    private BinExceptionService binExceptionService;

    @Autowired
    private BinOnusMapService binOnusMapService;

    @Autowired
    private AidSchemeMapService aidSchemeMapService;

    @Autowired
    private MftrBdkService mftrBdkService;

    @Autowired
    EftPosKeyDetailsService eftPosKeyDetailsService;

    @Override
    public void initMerchantMasterConfigurations(List<MerchantMasterModel> merchMasterList) {
        logger.info("Loading {} merchant master data into memory...", merchMasterList.size());
        merchMasterList.forEach(merchMasterInfo -> mapsInfoService.updateMerchantMaster(merchMasterInfo));
        logger.info("{} Merchant master data loaded into memory successfully...", merchMasterList.size());
    }

    @Override
    public void initMapsConfigurations(List<MapsInfoModel> mapsInfoList) {
        logger.info("Loading {} merchant data into memory...", mapsInfoList.size());
        mapsInfoList.forEach(merchantInfo -> mapsInfoService.updateMapsInfo(merchantInfo));
        logger.info("{} Merchant data loaded into memory successfully...", mapsInfoList.size());
    }

    @Override
    public void initBinConfigurations(List<BinInfoModel> binInfoList) {
        logger.info("Loading {} BIN data into memory...", binInfoList.size());
        binInfoList.forEach(binInfo -> binInfoService.updateBinInfo(binInfo));
        logger.info("{} BIN data loaded into memory successfully...", BinInfoServiceImpl.getBinCacheMap().size());
    }

    /**
     * Validate Merchant Service Implementation.
     *
     * @param entityId,mid,tid,currency
     * @return Boolean
     */
    @Override
    public MapsInfoModel validateAndGetMerchant(String entityId, String mid, String tid, String currency) {
        MapsInfoModel mapsInfo = null;
        try {
            String key = entityId + CacheConstants.KEY_SEPERATE + mid + CacheConstants.KEY_SEPERATE + tid;
            mapsInfo = mapsInfoService.getMapsInfoById(key);
            if (mapsInfo == null || mapsInfo.getEntityId() == null) {
                logger.info("Invalid Merchant Aggregator {}", entityId);
            } else {
                if (!mapsInfo.getMid().equals(mid)) {
                    logger.info("Invalid Merchant {}", mid);
                    return null;
                } else if (mapsInfo.getMerchantStatus() != ActiveInactiveFlag.Active) {
                    logger.info("Merchant {} is Inactive", mid);
                    return null;
                } else if (!mapsInfo.getTid().equals(tid)) {
                    logger.info("Invalid Terminal {}", tid);
                    return null;
                } else if (mapsInfo.getTerminalStatus() != ActiveInactiveFlag.Active) {
                    logger.info("Terminal {} is Inactive", tid);
                    return null;
                }
//                else if (currency != null && !mapsInfo.getAcquirerCurrencyCode().equals(currency)) {
//                    logger.info("Invalid Currency {}", currency);
//                    return null;
//                }
            }
        } catch (Exception e) {
            logger.error("An error occurred!", e);
        }
        return mapsInfo;
    }

    @Override
    public String getSchemeName(String cardNumber) {

        String target = null;
        BinInfoModel targetBinInfo = binInfoService.getBinInfoByCardNumber(cardNumber);
        if (targetBinInfo != null) {
            target = targetBinInfo.getSchemeName();
        }
        return target;

    }

    @Override
    public BinInfoModel getSchemeBin(String cardNumber) {
        return binInfoService.getBinInfoByCardNumber(cardNumber);
    }

    @Override
    public MerchantMasterModel validateAndGetMerchantMaster(String entityId, String mid) {
        MerchantMasterModel masterModel = null;
        try {
            String key = entityId + CacheConstants.KEY_SEPERATE + mid;
            masterModel = mapsInfoService.getMerchantMasterById(key);
            if (masterModel == null || masterModel.getEntityId() == null) {
                logger.info("Invalid Merchant Master Record {}", entityId);
            } else {
                if (!masterModel.getMid().equals(mid)) {
                    logger.info("Invalid Merchant Master {}", mid);
                    return null;
                } /*else if (masterModel.getMerchantStatus() != ActiveInactiveFlag.Active) {
                    logger.info("Merchant {} is Inactive", mid);
                    return null;
                }*/
            }
        } catch (Exception e) {
            logger.error("An error occurred!", e.getMessage());
        }
        return masterModel;
        }

    @Override
	public void initMftrConfigurations(List<MftrBDKModel> mftrBDKList) {
		logger.info("Loading {} Mftr BDK data into memory...", mftrBDKList.size());
		mftrBDKList.forEach(mftrBdk -> mftrBdkService.updateBDK(mftrBdk));
        logger.info("{} BDK data loaded into memory successfully...", MftrBdkServiceImpl.getMftrBdkCacheMap().size());
	}

    @Override
    public void initBinExceptionConfigurations(List<BinExceptionsModel> binExceptionsModelList) {
        logger.info("Loading {} BIN EXCEPTION data into memory...", binExceptionsModelList.size());
        binExceptionsModelList.forEach(binInfo -> binExceptionService.updateBinException(binInfo));
        logger.info("{} BIN data loaded into memory successfully...", BinExceptionServiceImpl.getBinExceptionCacheMap().size());
    }

    @Override
    public void initBinOnusMapConfigurations(List<BinOnusModel> binOnusMapList) {
        logger.info("Loading {} BIN data into memory...", binOnusMapList.size());
        binOnusMapList.forEach(binInfo -> binOnusMapService.updateBinOnusModel(binInfo));
        logger.info("{} BIN data loaded into memory successfully...", BinOnusMapServiceImpl.getBinOnusCacheMap().size());
    }

    @Override
    public  void initAidConfigurations(List<AidSchemeModel> aidSchemeModelListList) {
        logger.info("Loading {} AID data into memory...", aidSchemeModelListList.size());
        aidSchemeModelListList.forEach(binInfo -> aidSchemeMapService.updateAidSchemeModel(binInfo));
        logger.info("{} AID data loaded into memory successfully...", AidSchemeMapServiceImpl.getAidCacheMap().size());
    }

    @Override
	public Map<HsmCommandArg, String> getMftrBDK(String mftrName) {

		Map<HsmCommandArg, String> mfrtBdkMap = mftrBdkService.getBDKMftrName(mftrName);

		return mfrtBdkMap;

	}

    @Override
    public AidSchemeModel getAID(String aid) {
        return aidSchemeMapService.getTargetIdByAid(aid);
    }

    @Override
    public boolean getRejectedBin(String cardNumber) {
        return binExceptionService.getBinInfoByCardNumber(cardNumber);
    }

    @Override
    public BinOnusModel getOnusBin(String cardNumber) {
        return binOnusMapService.getBinInfoByCardNumber(cardNumber);
    }

    @Override
    public EFTPOSKeyModel getEftposKeyDetails(String key) {
        return eftPosKeyDetailsService.getEftposKeyDetails(key);
    }

    @Override
    public void updateEftposKeyDetails(String key, EFTPOSKeyModel eftposKeyModel) {
        eftPosKeyDetailsService.updateEftposKeyDetails(key, eftposKeyModel);
    }

    @Override
    public TempKeyModel getTempEftposKeyDetails(String key) {
        return eftPosKeyDetailsService.getTempEftposKeyDetails(key);
    }

    @Override
    public void updateEftposTempKeyDetails(String targetName,TempKeyModel eftposKeyModel) {
        eftPosKeyDetailsService.updateEftposTempKeyDetails(targetName,eftposKeyModel);
    }

    @Override
    public boolean getSignOffStatus(String targetName) {
        return  eftPosKeyDetailsService.getSignOffStatus(targetName);
    }

    @Override
    public void putSignOffStatus(boolean status, String targetName) {
        eftPosKeyDetailsService.putSignOffStatus(status, targetName);
    }

    @Override
    public SignOnSignOffModel getEftposSignOnStatus() {
        return  eftPosKeyDetailsService.getEftposSignOnStatus();
    }

    @Override
    public void putEftposSignOnStatus(boolean status, String targetIp) {
        eftPosKeyDetailsService.putEftposSignOnStatus(status, targetIp);
    }

    @Override
    public String getActiveTargetId() {
        return eftPosKeyDetailsService.getActiveTargetId();
    }

    @Override
    public void deleteActiveTargetId(String activeTargetId) {
        eftPosKeyDetailsService.deleteActiveTargetId(activeTargetId);
    }

    @Override
    public void putActiveTargetId(String activeTargetId) {
        eftPosKeyDetailsService.putActiveTargetId(activeTargetId);
    }

	@Override
	public String getActiveTargetPort(String linkName) {
		return eftPosKeyDetailsService.getActiveTargetPort(linkName);
	}

	@Override
	public void deleteActiveTargetPort(String linkName, String activeTargetId) {
		eftPosKeyDetailsService.deleteActiveTargetPort(linkName, activeTargetId);
	}

	@Override
	public void putActiveTargetPort(String linkName, String activeTargetId) {
		eftPosKeyDetailsService.putActiveTargetPort(linkName, activeTargetId);
	}


}
