package com.isg.mw.cache.mgmt.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;

import java.io.*;

public class MerchantPreferredTargetSerializer implements RedisSerializer<MerchantPreferredTarget> {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public byte[] serialize(MerchantPreferredTarget merchantPreferredTarget) throws SerializationException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(merchantPreferredTarget);
            oos.flush();
        } catch (IOException e) {
            logger.error("Error while serializing object: {}", e);
        }
        return bos.toByteArray();
    }

    @Override
    public MerchantPreferredTarget deserialize(byte[] bytes) throws SerializationException {
        MerchantPreferredTarget merchantPreferredTarget = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            merchantPreferredTarget = (MerchantPreferredTarget) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing object", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class not found", e);
        }
        return merchantPreferredTarget;
    }
}
