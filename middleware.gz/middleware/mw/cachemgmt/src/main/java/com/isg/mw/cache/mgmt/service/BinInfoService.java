package com.isg.mw.cache.mgmt.service;

import org.springframework.stereotype.Service;

import com.isg.mw.core.model.bi.BinInfoModel;

/**
 * Bin Info services
 * 
 * @author akshay3978
 */
@Service
public interface BinInfoService {
	/**
	 * Update BinInfo in Cache
	 * 
	 * @param BinInfo
	 * @return boolean
	 */
	Boolean updateBinInfo(BinInfoModel binInfo);

	/**
	 * Get Bin Info from cache based on binNumber.
	 * 
	 * @param cardNumber
	 * @return BinInfoModel
	 */
	BinInfoModel getBinInfoByCardNumber(String cardNumber);

}
