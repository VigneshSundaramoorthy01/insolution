package com.isg.mw.cache.mgmt.service.impl;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.isg.mw.cache.mgmt.init.CacheMTMProperties;
import com.isg.mw.cache.mgmt.service.HsmUtilityService;

@Service
public class HsmUtilityServiceImpl implements HsmUtilityService {
	@Override
	public ResponseEntity<?> sendAndConnect(String encryptedCommand, String encodedKey) {
		ResponseEntity<?> response = null;
		Cipher cipher = null; 
		byte[] decryptedByte = null;
		String decryptedText = "";
		
		byte[] decodedKey = Base64.getDecoder().decode(encodedKey);
		SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");

		Base64.Decoder decoder = Base64.getDecoder();
		byte[] encryptedTextByte = decoder.decode(encryptedCommand);
		
		try(final Socket sc = new Socket(CacheMTMProperties.getProperty("hsmIp"), Integer.parseInt(CacheMTMProperties.getProperty("hsmPort")));
				final DataInputStream din = new DataInputStream(sc.getInputStream());
				final DataOutputStream dos = new DataOutputStream(sc.getOutputStream())) {
			
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, originalKey);
			decryptedByte = cipher.doFinal(encryptedTextByte);
			decryptedText = new String(decryptedByte);
			
			sc.setSoTimeout(5000);
			dos.writeUTF(decryptedText);
			dos.flush();
			response = new ResponseEntity<>(din.readUTF(), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return response;
	}
}
