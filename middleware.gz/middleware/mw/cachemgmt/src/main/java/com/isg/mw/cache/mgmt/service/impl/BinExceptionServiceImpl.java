package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.BinExceptionService;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.utils.MaskingUtility;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@EnableCaching
public class BinExceptionServiceImpl implements BinExceptionService {


    private final Logger LOG = LogManager.getLogger(getClass());

    @Getter
    private static final Map<BinExceptionsModel, BinExceptionsModel> binExceptionCacheMap = new ConcurrentHashMap<>();

    @Autowired
    private InitRestClient initRestClient;

    @Value("${bin.fetch.flag}")
    private String binFetchFlag;




    @Override
    public Boolean updateBinException(BinExceptionsModel binExceptionsModel) {
        try {
            if (binExceptionsModel != null) {
                BinExceptionsModel valueBin = getBinExceptionsModel(binExceptionsModel);
                BinExceptionsModel key = constructKey(binExceptionsModel);
                if (ActiveFlag.N.equals(valueBin.getActiveFlag())) {
                    LOG.trace("BIN {} is now inactive, hence can be evicted", valueBin);
                    BinExceptionsModel removedBin = binExceptionCacheMap.remove(key);
                    if (removedBin != null)
                        LOG.trace("BIN {} Evicted Successfully...", removedBin);
                    else
                        LOG.trace("BIN {} is inactive, hence not added in cache", binExceptionsModel);
                } else {
                    binExceptionCacheMap.put(key, valueBin);
                    LOG.trace("BIN {} Inserted/Updated Successfully...", binExceptionsModel);
                }
            } else {
                LOG.info("BinOnusModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }


    private BinExceptionsModel getBinExceptionsModel(BinExceptionsModel model) {
        BinExceptionsModel valueBinExceptionsModel = new BinExceptionsModel();
        valueBinExceptionsModel.setBinHigh(model.getBinHigh());
        valueBinExceptionsModel.setBinNumber(model.getBinNumber());
        valueBinExceptionsModel.setBinLow(model.getBinLow());
        valueBinExceptionsModel.setSchemeName(model.getSchemeName());
        valueBinExceptionsModel.setTargetId(model.getTargetId());
        valueBinExceptionsModel.setTargetName(model.getTargetName());
        valueBinExceptionsModel.setCardProgram(model.getCardProgram());
        valueBinExceptionsModel.setActiveFlag(model.getActiveFlag());
        valueBinExceptionsModel.setCardCategory(model.getCardCategory());
        valueBinExceptionsModel.setCardBrand(model.getCardBrand());
        return valueBinExceptionsModel;
    }

    @Override
    public boolean getBinInfoByCardNumber(String cardNumber) {
        LOG.info("Getting BinNumber in getBinInfoByCardNumber service {}", MaskingUtility.maskCardNumber(cardNumber));
        BinExceptionsModel binInfo = null;
        boolean cardStatus = false;

        if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            binInfo = fetchBinExceptionFromApi(cardNumber);
        } else if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            binInfo = fetchBinExceptionsFromCache(cardNumber);
        }
        if (binInfo != null) {
            cardStatus = true;
        }
        return cardStatus;
    }


    private BinExceptionsModel fetchBinExceptionFromApi(String cardNumber) {
        String binNum = cardNumber.substring(0, 9);
        LOG.trace("Fetching the BIN through API for card number {}", MaskingUtility.maskCardNumber(cardNumber));
        BinExceptionsModel bin = initRestClient.getBinException(binNum);
        if (bin == null) {
            binNum = StringUtils.rightPad(cardNumber, 19, '0');
            bin = initRestClient.getBinException(binNum);
        }
        return bin;
    }

    private BinExceptionsModel fetchBinExceptionsFromCache(String cardNumber) {
        BinExceptionsModel binInfo = null;
        try {
            BigInteger binNum = new BigInteger(cardNumber.substring(0, 9));
            BinExceptionsModel binModel = new BinExceptionsModel();
            binModel.setBinNumber(binNum);
            binModel.setBinLow(binNum);
            binInfo = binExceptionCacheMap.get(binModel);

            if (binInfo == null) {
                binNum = new BigInteger(StringUtils.rightPad(cardNumber, 19, '0'));
                binModel.setBinNumber(binNum);
                binModel.setBinLow(binNum);
                binInfo = binExceptionCacheMap.get(binModel);
            }

        } catch (Exception e) {
            LOG.error("An error occurred!", e);
        }
        return binInfo;
    }
    /**
     * This method constructs key.
     *
     * @param model BinOnusModel
     * @return key
     */
    private BinExceptionsModel constructKey(BinExceptionsModel model) {
        BinExceptionsModel keyBinExceptionsModel = new BinExceptionsModel();
        keyBinExceptionsModel.setBinHigh(model.getBinHigh());
        keyBinExceptionsModel.setBinLow(model.getBinLow());
        keyBinExceptionsModel.setBinNumber(model.getBinNumber());
        return keyBinExceptionsModel;
    }

}
