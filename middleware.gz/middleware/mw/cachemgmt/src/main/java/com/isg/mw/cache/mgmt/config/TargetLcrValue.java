package com.isg.mw.cache.mgmt.config;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.Objects;

@Getter
@Setter
@ToString
public class TargetLcrValue implements Serializable {

    private Long targetId;
    private Double pricePct;
    private Double priceFixed;
    private Double below2000PricePct;
    private Double below2000PriceFixed;
    private OffsetDateTime startDate;
    private OffsetDateTime endDate;
    private OffsetDateTime updatedDate;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TargetLcrValue that = (TargetLcrValue) o;
        return targetId.equals(that.targetId) && Objects.equals(pricePct, that.pricePct) && Objects.equals(priceFixed, that.priceFixed) && Objects.equals(below2000PricePct, that.below2000PricePct) && Objects.equals(below2000PriceFixed, that.below2000PriceFixed);
    }

    @Override
    public int hashCode() {
        return Objects.hash(targetId, startDate, endDate);
    }
}
