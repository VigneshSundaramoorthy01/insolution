package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.SignOnSignOffModel;
import com.isg.mw.core.model.eftpos.TempKeyModel;

public interface EftPosKeyDetailsService {

    EFTPOSKeyModel getEftposKeyDetails(String key);

    void updateEftposKeyDetails(String key, EFTPOSKeyModel eftposKeyModel);

    TempKeyModel getTempEftposKeyDetails(String key);

    void updateEftposTempKeyDetails(String targetName, TempKeyModel eftposKeyModel);

    boolean getSignOffStatus(String tagetName);
    void putSignOffStatus(boolean status, String tagetName);

    SignOnSignOffModel getEftposSignOnStatus();
    void putEftposSignOnStatus(boolean status, String targetIp);

    String getActiveTargetId();
    void deleteActiveTargetId(String activeTargetId);
    void putActiveTargetId(String activeTargetId);
    
    String getActiveTargetPort(String linkName);
    void deleteActiveTargetPort(String linkName, String activeTargetPort);
    void putActiveTargetPort(String linkName, String activeTargetPort);
}
