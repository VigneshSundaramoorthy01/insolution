package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import javax.cache.CacheException;
import java.util.List;

/**
 * Maps Info Services.
 *
 * @author akshay3978
 */
@Service
@EnableCaching
public class MapsInfoServiceImpl implements MapsInfoService {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private InitRestClient initRestClient;

    /**
     * Update Maps Info into Cache.
     *
     * @param model
     * @return boolean.
     */
    @Override
    public Boolean updateMapsInfo(MapsInfoModel model) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.MAPS_INFO_CACHE);
            if (model != null) {
                String key = constructKey(model);
                if (ActiveInactiveFlag.Inactive.equals(model.getMerchantStatus()) ||
                        ActiveInactiveFlag.Inactive.equals(model.getTerminalStatus())) {
                    cache.evictIfPresent(key);
                } else {
                    cache.put(key, model);
                }
            } else {
                logger.info("MapsInfoModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.error("An error occurred while push the MapsInfo into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    /**
     * Get Maps Info from cache, based on key.
     *
     * @param key
     * @return MapsInfoModel
     */
    @Cacheable(cacheNames = CacheConstants.MAPS_INFO_CACHE, unless = "#result==null")
    @Override
    public MapsInfoModel getMapsInfoById(String key) {
        logger.info("Getting maps info by key: {}", key);
        MapsInfoModel mapsInfo = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.MAPS_INFO_CACHE);
            mapsInfo = (MapsInfoModel) cache.get(key);
            logger.info("Maps data from cache: {}", mapsInfo);
            if (mapsInfo == null) {
                mapsInfo = getMapsInfo(key);
                updateMapsInfo(mapsInfo);
            }
        } catch (CacheException e) {
            logger.error("An error occurred while getting the maps info from cache", e);
        }
        return mapsInfo;
    }

    @Override
    public Boolean updateMerchantMaster(MerchantMasterModel merchantMasterModel) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.MERCHANT_MASTER_CACHE);
            if (merchantMasterModel != null) {
                String key = constructMerchantMasterKey(merchantMasterModel);
                if (ActiveInactiveFlag.Inactive.equals(merchantMasterModel.getStatus())) {
                    cache.evictIfPresent(key);
                } else {
                    cache.put(key, merchantMasterModel);
                }
            } else {
                logger.info("MerchantMasterModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.error("An error occurred while pushing the MerchantMaster into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Cacheable(cacheNames = CacheConstants.MERCHANT_MASTER_CACHE, unless = "#result==null")
    @Override
    public MerchantMasterModel getMerchantMasterById(String key) {
        logger.info("Getting merchant master by key: {}", key);
        MerchantMasterModel masterModel = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.MERCHANT_MASTER_CACHE);
            masterModel = (MerchantMasterModel) cache.get(key);
            logger.info("Merchant master data from cache: {}", masterModel);
            if (masterModel == null) {
                masterModel = getMerchantMasterModelInfo(key);
                updateMerchantMaster(masterModel);
            }
        } catch (CacheException e) {
            logger.error("An error occurred while getting the merchant master from cache", e);
        }
        return masterModel;
    }

    private String constructKey(MapsInfoModel model) {
        return model.getEntityId() + CacheConstants.KEY_SEPERATE + model.getMid() + CacheConstants.KEY_SEPERATE
                + model.getTid();
    }

    private String constructMerchantMasterKey(MerchantMasterModel model) {
        return model.getEntityId() + CacheConstants.KEY_SEPERATE + model.getMid();
    }


    /**
     * Get MapsInfoModel from Config Db through API
     *
     * @param key
     * @return
     */
    private MapsInfoModel getMapsInfo(String key) {
        logger.info("Getting getMapsInfoByEntityIdMidTid's Arguments:{}", key);
        MapsInfoModel mapsInfo = null;
        mapsInfo = initRestClient.getMapsInfo(key);
        return mapsInfo;
    }

    private MerchantMasterModel getMerchantMasterModelInfo(String key) {
        logger.info("Getting getMerchantMasterModel Arguments:{}", key);
        MerchantMasterModel mapsInfo = null;
        mapsInfo = initRestClient.getMerchantMasterModelInfo(key);
        return mapsInfo;
    }
}
