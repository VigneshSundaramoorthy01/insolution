//package com.isg.mw.cache.mgmt.producer;
//
//import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
//
//import java.util.List;
//
//public interface TargetMerchantMasterMessenger {
//
//    void send(TargetMerchantMasterModel resultModel);
//}
