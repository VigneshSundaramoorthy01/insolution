package com.isg.mw.cache.mgmt.producer;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.serializers.NotificationSerializer;
import com.isg.mw.core.model.upi.Notification;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationFeederProducerImpl implements NotificationFeederProducer , InitializingBean, DisposableBean {


    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    private KafkaProducer producer;

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(cacheKafkaConfig.getProducerKafkaConfig(cacheKafkaConfig.getNotificationTopicName(), NotificationSerializer.class));
        producer.init();
    }

    @Override
    public void send(Notification notification) {
        producer.sendMessage(notification);
    }

}
