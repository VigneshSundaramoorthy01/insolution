package com.isg.mw.cache.mgmt.producer;

import com.isg.mw.core.model.upi.TransactionMessageModelV2;
import org.springframework.stereotype.Service;

@Service
public interface UpiTlmMessenger {

    void send(TransactionMessageModelV2 resultModel);

}
