package com.isg.mw.cache.mgmt.config;

import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.MerchantPaymentModesModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Setter
@Getter
@ToString
public class CacheMerchantPaymentModeAndOptions implements Serializable {

    private MerchantPaymentModesModel merchantPaymentMode;
    private List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptions;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CacheMerchantPaymentModeAndOptions that = (CacheMerchantPaymentModeAndOptions) o;
        return merchantPaymentMode.getMerchantPaymentModeId().equals(that.merchantPaymentMode.getMerchantPaymentModeId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(merchantPaymentMode.getMerchantPaymentModeId());
    }
}
