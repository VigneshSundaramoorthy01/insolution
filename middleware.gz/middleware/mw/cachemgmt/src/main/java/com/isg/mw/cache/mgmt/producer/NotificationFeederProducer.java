package com.isg.mw.cache.mgmt.producer;

import com.isg.mw.core.model.upi.Notification;

public interface NotificationFeederProducer {

    void send(Notification notification);

}
