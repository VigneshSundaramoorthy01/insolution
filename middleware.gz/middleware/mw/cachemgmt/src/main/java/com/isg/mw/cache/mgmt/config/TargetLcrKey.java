package com.isg.mw.cache.mgmt.config;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@ToString
public class TargetLcrKey implements Serializable {

    private Long payModeId;
    private Long payModeOpId;
    private String mccCategory;
    private String cardType;

    public TargetLcrKey(Long payModeId, Long payModeOpId, String mccCategory, String cardType) {
        this.payModeId = payModeId;
        this.payModeOpId = payModeOpId;
        this.mccCategory = mccCategory;
        this.cardType = cardType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TargetLcrKey)) return false;
        TargetLcrKey that = (TargetLcrKey) o;
        return Objects.equals(getPayModeId(), that.getPayModeId())
                && Objects.equals(getPayModeOpId(), that.getPayModeOpId())
                && Objects.equals(getMccCategory(), that.getMccCategory())
                && Objects.equals(getCardType(), that.getCardType());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getPayModeId(), getPayModeOpId(), getMccCategory(), getCardType());
    }
}
