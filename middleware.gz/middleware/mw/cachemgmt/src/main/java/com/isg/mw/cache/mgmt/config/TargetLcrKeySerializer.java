package com.isg.mw.cache.mgmt.config;

import com.isg.mw.cache.mgmt.config.TargetLcrKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;

import java.io.*;

public class TargetLcrKeySerializer implements RedisSerializer<TargetLcrKey> {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public byte[] serialize(TargetLcrKey targetLcrKey) throws SerializationException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(targetLcrKey);
            oos.flush();
        } catch (IOException e) {
//            logger.error("Error while serializing object: {}", e);
        }
        return bos.toByteArray();
    }

    @Override
    public TargetLcrKey deserialize(byte[] bytes) throws SerializationException {
        TargetLcrKey targetLcrKey = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            targetLcrKey = (TargetLcrKey) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing object", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class not found", e);
        }
        return targetLcrKey;
    }
}
