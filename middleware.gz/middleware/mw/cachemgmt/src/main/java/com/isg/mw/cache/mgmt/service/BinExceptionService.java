package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinInfoModel;

public interface BinExceptionService {

    /**
     * Update BinInfo in Cache
     *
     * @param binExceptionsModel
     * @return boolean
     */
    Boolean updateBinException(BinExceptionsModel binExceptionsModel);

    /**
     * Get BinExceptionsModel Info from cache based on binNumber.
     *
     * @param cardNumber
     * @return BinExceptionsModel
     */
    boolean getBinInfoByCardNumber(String cardNumber);

}
