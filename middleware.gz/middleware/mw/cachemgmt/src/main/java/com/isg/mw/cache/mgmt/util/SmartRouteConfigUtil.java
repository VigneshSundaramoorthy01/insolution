package com.isg.mw.cache.mgmt.util;

import com.isg.mw.core.model.sr.*;

public class SmartRouteConfigUtil {
    public static TargetLCRConfigModel getTargetLCRConfigModel(TargetLCRConfigMessage targetLCRConfigMsgModel){
        return targetLCRConfigMsgModel.getModel();
    }

    public static TargetPaymentModesModel getTargetPaymentModesModel(TargetPaymentModesMessage targetPaymentModesMsgModel) {
        return targetPaymentModesMsgModel.getModel();
    }

    public static TargetPaymentModeOptionsModel getTargetPaymentModeOptionModel(TargetPaymentModeOptionsMessage targetPaymentModeOptionsMsgModel) {
        return targetPaymentModeOptionsMsgModel.getModel();
    }

    public static TargetPaymentModesModel getTargetPayModesModelFromTgtPayOptionMsgModel(TargetPaymentModeOptionsMessage targetPaymentModeOptionsMsgModel) {
        return targetPaymentModeOptionsMsgModel.getTargetPaymentModesModel();
    }

    public static MerchantPaymentModesModel getMerchantPaymentModesModel(MerchantPaymentModesMessage merchantPaymentModesMessageModel) {
        return merchantPaymentModesMessageModel.getModel();
    }

    public static MerchantMasterModel getMerchantMasterModelFromMerchantPayModeMsg(MerchantPaymentModesMessage merchantPaymentModesMessageModel) {
        return merchantPaymentModesMessageModel.getMerchantMasterModel();
    }

    public static MerchantPaymentModeOptionsModel getMerchantPaymentModeOptionModel(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        return merchantPaymentModeOptionsMessageModel.getModel();
    }

    public static MerchantPaymentModesModel getMerchantPayModesModelFromMerPayOptionMsgModel(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        return merchantPaymentModeOptionsMessageModel.getMerchantPaymentModesModel();
    }

    public static MerchantMasterModel getMerchantMasterModelFromMerchantPayModeOptionMsg(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        return merchantPaymentModeOptionsMessageModel.getMerchantMasterModel();
    }

    public static TargetMerchantMasterModel getTargetMerchantMasterModel(TargetMerchantMasterModel targetMerchantMasterModel) {
        TargetMerchantMasterModel model = new TargetMerchantMasterModel();
        model.setTargetId(targetMerchantMasterModel.getTargetId());
        model.setTargetMerchantMasterId(targetMerchantMasterModel.getTargetMerchantMasterId());
        model.setTargetMid(targetMerchantMasterModel.getTargetMid());
        model.setMid(targetMerchantMasterModel.getMid());
        model.setTid(targetMerchantMasterModel.getTid());
        model.setMerchantVpa(targetMerchantMasterModel.getMerchantVpa());
        model.setCreatedAt(targetMerchantMasterModel.getCreatedAt());
        model.setCreatedBy(targetMerchantMasterModel.getCreatedBy());
        model.setUpdatedAt(targetMerchantMasterModel.getUpdatedAt());
        model.setUpdatedBy(targetMerchantMasterModel.getUpdatedBy());
        model.setStatus(targetMerchantMasterModel.getStatus());
        model.setDpaId(targetMerchantMasterModel.getDpaId());
        model.setProdApiKey(targetMerchantMasterModel.getProdApiKey());
        model.setTestApiKey(targetMerchantMasterModel.getTestApiKey());
        model.setKey(targetMerchantMasterModel.getKey());
        model.setSalt(targetMerchantMasterModel.getSalt());
        return model;
    }

    public static MerchantTargetPreferencesModel getMerchantTargetPreferencesModel(MerchantTargetPreferencesMessage merchantTargetPreferencesModel) {
        return  merchantTargetPreferencesModel.getModel();
    }

    public static MerchantMasterModel getMerchantMasterFromMerchantTargetPrefMsg(MerchantTargetPreferencesMessage merchantTargetPreferencesMsg) {
        return merchantTargetPreferencesMsg.getMerchantMasterModel();
    }
}
