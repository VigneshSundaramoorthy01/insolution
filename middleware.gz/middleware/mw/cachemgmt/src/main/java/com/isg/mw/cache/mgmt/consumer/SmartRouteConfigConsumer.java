package com.isg.mw.cache.mgmt.consumer;

import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.deserializers.*;
import com.isg.mw.cache.mgmt.service.SmartRouteConfigService;
import com.isg.mw.core.model.sr.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class SmartRouteConfigConsumer implements ApplicationRunner {
    private static final Logger LOG = LogManager.getLogger(SmartRouteConfigConsumer.class);

    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    @Autowired
    private SmartRouteConfigService smartRouteConfigService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        LOG.info("Kafka Consumer Method Call");
        try {
            //Consumer For TargetPaymentModes
            KafkaConsumer targetPaymentModesConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getTargetPaymentModesTopicName(), TargetPaymentModesDeserializer.class),
                    this, "cacheTargetPaymentModesConsumer");
            targetPaymentModesConsumer.init();
            LOG.info("Target Payment Modes Kafka Consumer initialization done");


            //Consumer For TargetPaymentModesOptions
            KafkaConsumer targetPaymentModesOptionsConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getTargetPaymentModeOptionsTopicName(), TargetPaymentModeOptionsDeserializer.class),
                    this, "cacheTargetPaymentModeOptionsConsumer");
            targetPaymentModesOptionsConsumer.init();
            LOG.info("Target Payment Mode Options Kafka Consumer initialization done");


            //Consumer For Target LCR Config
            KafkaConsumer targetLcrConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getTargetLcrTopicName(), TargetLCRDeserializer.class),
                    this, "cacheTargetLcrConsumer");
            targetLcrConsumer.init();
            LOG.info("Target LCR Kafka Consumer initialization done");


            //Consumer For MerchantPaymentModes
            KafkaConsumer merchantPaymentModesConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getMerchantPaymentModesTopicName(), MerchantPaymentModeDeserializer.class,
                            "MPM_" + cacheKafkaConfig.getSrIndividualGroupId() + "_"+
                                    cacheKafkaConfig.getMerchantPaymentModesTopicName()),
                    this, "cacheMerchantPaymentModesConsumer");
            merchantPaymentModesConsumer.init();
            LOG.info("Merchant Payment Modes Kafka Consumer initialization done");


            //Consumer For MerchantPaymentModesOptions
            KafkaConsumer merchantPaymentModesOptionsConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getMerchantPaymentModeOptionsTopicName(), MerchantPaymentModeOptionsDeserializer.class,
                            "MPMO_" + cacheKafkaConfig.getSrIndividualGroupId() + "_"+
                                    cacheKafkaConfig.getMerchantPaymentModeOptionsTopicName()),
                    this, "cacheMerchantPaymentModeOptionsConsumer");
            merchantPaymentModesOptionsConsumer.init();
            LOG.info("Merchant Payment Mode Options Kafka Consumer initialization done");

            //Consumer For MerchantPaymentModesAndOptions
            KafkaConsumer merchantPaymentModesAndOptionsConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getMerchantPaymentModesAndOptionsTopicName(), MerchantPaymentModeOptionsDeserializer.class),
                    this, "cacheMerchantPaymentModesAndOptionsConsumer");
            merchantPaymentModesAndOptionsConsumer.init();
            LOG.info("Merchant Payment Mode And Options Kafka Consumer initialization done");

            //Consumer For TargetMerchantMaster
            KafkaConsumer targetMerchantMasterConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getTargetMerchantMasterTopicName(), TargetMerchantMasterDeserializer.class),
                    this, "cacheTargetMerchantMasterConsumer");
            targetMerchantMasterConsumer.init();
            LOG.info("Target Merchant Master Kafka Consumer initialization done");

            //Consumer For MerchantTargetPreferences
            KafkaConsumer merchantTgtPrefConsumer = new KafkaConsumer(
                    cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getMerchantTargetPrefrencesTopicName(), MerchantTargetPrefrencesDeserializer.class),
                    this, "cacheMerchantTargetPrefrencesConsumer");
            merchantTgtPrefConsumer.init();
            LOG.info("Merchant Target Preferences Kafka Consumer initialization done");


        } catch (Exception e) {
            LOG.error("Exception While Consumeing BinInfo: {} ", e);
        }
    }

    public void cacheTargetPaymentModesConsumer(TargetPaymentModesMessage targetPaymentModesMsgModel) {
        try {
            smartRouteConfigService.updateTargetPaymentModesInCache(targetPaymentModesMsgModel);
        } catch (Exception e) {
            LOG.error("Exception while TargetPaymentModes Service Call: {}", e);
        }
    }

    public void cacheTargetPaymentModeOptionsConsumer(TargetPaymentModeOptionsMessage targetPaymentModeOptionsMsgModel) {
        try {
            smartRouteConfigService.updateTargetPaymentModeOptionInCache(targetPaymentModeOptionsMsgModel);
        } catch (Exception e) {
            LOG.error("Exception while TargetPaymentModeOptions Service Call: {}", e);
        }
    }

    public void cacheTargetLcrConsumer(TargetLCRConfigMessage targetLCRConfigMsgModel) {
        try {
            smartRouteConfigService.updateTargetLcrInCache(targetLCRConfigMsgModel);
        } catch (Exception e) {
            LOG.error("Exception while Target LCR Service Call: {}", e);
        }
    }

    public void cacheMerchantPaymentModesConsumer(MerchantPaymentModesMessage merchantPaymentModesMessageModel) {
        try {
            smartRouteConfigService.updateMerchantPaymentModesInCache(merchantPaymentModesMessageModel);
        } catch (Exception e) {
            LOG.error("Exception while MerchantPaymentModes Service Call: {}", e);
        }
    }

    public void cacheMerchantPaymentModeOptionsConsumer(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        try {
            smartRouteConfigService.updateMerchantPaymentModeOptionInCache(merchantPaymentModeOptionsMessageModel);
        } catch (Exception e) {
            LOG.error("Exception while MerchantPaymentModesOptions Service Call: {}", e);
        }
    }

    public void cacheMerchantPaymentModesAndOptionsConsumer(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        try {
            smartRouteConfigService.updateMerchantPaymentModesAndOptionInCache(merchantPaymentModeOptionsMessageModel);
        } catch (Exception e) {
            LOG.error("Exception while MerchantPaymentModesOptions Service Call: {}", e);
        }
    }

    public void cacheTargetMerchantMasterConsumer(TargetMerchantMasterModel targetMerchantMasterModel) {
        try {
            smartRouteConfigService.updateTargetMerchantMasterCache(targetMerchantMasterModel);
        } catch (Exception e) {
            LOG.error("Exception while TargetMerchantMasterModel Service Call: {}", e);
        }
    }

    public void cacheMerchantTargetPrefrencesConsumer(MerchantTargetPreferencesMessage targetPreferencesMessage) {
        try {
            smartRouteConfigService.updateTargetMerchantTargetPreferencesInCache(targetPreferencesMessage);
        } catch (Exception e) {
            LOG.error("Exception while TargetMerchantMasterModel Service Call: {}", e);
        }
    }



}
