package com.isg.mw.cache.mgmt.producer;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.serializers.TxnReconModelSerializer;
import com.isg.mw.core.model.tlm.TxnReconData;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UpiFeederMessengerImpl implements  UpiFeederMessenger, InitializingBean, DisposableBean {


    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    private KafkaProducer producer;

    @Override
    public void send(TxnReconData resultModel) {
        producer.sendMessage(resultModel);
    }

    @Override
    public void destroy() throws Exception {

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(cacheKafkaConfig.getProducerKafkaConfig(cacheKafkaConfig.getUpiFeederTopicName(), TxnReconModelSerializer.class));
        producer.init();
    }


}
