package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;

import java.math.BigInteger;

public interface AidSchemeMapService {
    /**
     * Update BinInfo in Cache
     *
     * @param aidSchemeModel
     * @return boolean
     */
    Boolean updateAidSchemeModel(AidSchemeModel aidSchemeModel);

    /**
     * Get AidSchemeModel Info from cache based on aid.
     *
     * @param aid
     * @return AidSchemeModel
     */
    AidSchemeModel getTargetIdByAid(String aid);
}
