package com.isg.mw.cache.mgmt.deserializers;

import com.isg.mw.core.model.sr.MerchantPaymentModeOptionsMessage;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class MerchantPaymentModeOptionsDeserializer implements Deserializer<MerchantPaymentModeOptionsMessage> {
    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public MerchantPaymentModeOptionsMessage deserialize(String topic, byte[] data) {
        MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessage = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            merchantPaymentModeOptionsMessage = (MerchantPaymentModeOptionsMessage) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing MerchantPaymentModeOptionsMessage object: {}", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class in which the object to be deserialized not found: {}", e);
        }
        return merchantPaymentModeOptionsMessage;
    }
}
