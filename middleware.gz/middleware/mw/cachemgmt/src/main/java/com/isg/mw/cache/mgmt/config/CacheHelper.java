package com.isg.mw.cache.mgmt.config;

import com.isg.mw.cache.mgmt.init.CacheMTMProperties;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.TargetPriority;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.SmartRouteStatisticsModel;
import com.isg.mw.core.utils.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class CacheHelper {

    private final Logger logger = LogManager.getLogger(getClass());

    public static final String KEY_SEPARATOR = "::";

    @Autowired
    private CacheUtil cacheUtil;

    @Autowired
    private SmartRouteSpringCacheService srCacheService;

    @Autowired
    @Qualifier("plainTemplate")
    private RestTemplate restTemplate;

    public Map<Long, InitSmartRouteCacheValue> initCache(List<SourceConfigModel> sourceConfigModels, List<TargetConfigModel> targetConfigModels,
                                                         List<SmartRouteConfigModel> smartRouteConfigModels,
                                                         List<PaymentModesModel> paymentModesModels, List<PaymentModeOptionsModel> paymentModeOptionsModels,
                                                         List<TargetPaymentModesModel> targetPaymentModesModels, List<TargetPaymentModeOptionsModel> targetPaymentModeOptionsModels,
                                                         List<TargetLCRConfigModel> targetLCRConfigs,
                                                         List<MerchantPaymentModesModel> merchantPaymentModesModels, List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptionsModels,
                                                         List<MerchantTargetPreferencesModel> merchantTargetPreferencesModels, List<MerchantMasterModel> merchantMasterModels) {

        if (smartRouteConfigModels == null || smartRouteConfigModels.isEmpty())
            return null;

        Map<Long, InitSmartRouteCacheValue> initSmrtRtCacheValMap = new HashMap<>();
        for (SmartRouteConfigModel smartRouteConfigModel : smartRouteConfigModels) {
            SourceConfigModel sourceConfigModel = sourceConfigModels.stream()
                    .filter(sourceConfigModel1 ->
                            sourceConfigModel1.getId().equals(smartRouteConfigModel.getSourceId()))
                    .findFirst()
                    .orElse(null);

            if (sourceConfigModel == null) {
                logger.warn("Source config with id: {} is not active/present for the smart route config: {}", smartRouteConfigModel.getSourceId(), smartRouteConfigModel.getId());
                continue;
            }

            switch (smartRouteConfigModel.getRouteType()) {
                case SUCCESS_RATIO_DYNAMIC:
                case SUCCESS_RATIO_DYNAMIC_LCR:
                    initSuccessRatioCache(targetConfigModels, initSmrtRtCacheValMap, smartRouteConfigModel, sourceConfigModel);
                    // intentional fall-through
                case LEAST_COST:
                    initPaymentModeAndOptions(paymentModesModels, paymentModeOptionsModels);
                    initTargetPaymentModeAndOptions(sourceConfigModel.getEntityId(), targetPaymentModesModels, targetPaymentModeOptionsModels);
                    initTargetLcrCache(sourceConfigModel.getEntityId(), targetLCRConfigs);
                    initMerchantPaymentModeAndOptions(sourceConfigModel.getEntityId(), merchantMasterModels, merchantPaymentModesModels, merchantPaymentModeOptionsModels);
                    initMerchantTargetPreferences(sourceConfigModel.getEntityId(), merchantTargetPreferencesModels);
                    break;
                case SUCCESS_RATIO_STATIC:
                    initSuccessRatioCache(targetConfigModels, initSmrtRtCacheValMap, smartRouteConfigModel, sourceConfigModel);
                    break;
            }
        }
        targetPaymentModesModels.forEach(paymentModesModel ->
                logger.trace("Master Target Payment Mode And Options: {}, {}}", paymentModesModel.getEntityId(), srCacheService.getAllTargetPayModeAndOptionsData(paymentModesModel.getEntityId()))
        );

        return initSmrtRtCacheValMap;
    }

    /**
     * KEY: (entityId + mid + payModeId)
     * VALUE: MerchantPreferredTarget : (targetid, startDate, endDate)
     */
    private void initMerchantTargetPreferences(String entityId, List<MerchantTargetPreferencesModel> merchTgtPrefs) {
    	logger.trace("Starting Cache Initilization of Merchant target perferences {}",merchTgtPrefs.size());

    	for (MerchantTargetPreferencesModel merchTargetPref : merchTgtPrefs) {
            MerchantPreferredTarget targetData = cacheUtil.getMerchantPreferredTargetData(entityId, merchTargetPref.getMid(), merchTargetPref.getPaymentModeId().toString());
            if (targetData != null && (merchTargetPref.getStatus().compareTo(ActiveInactiveFlag.Inactive) == 0 || merchTargetPref.getUpdatedAt().isAfter(targetData.getUpdatedAt()))) {
                cacheUtil.removeMerchantPreferredTargetDataData(entityId, merchTargetPref.getMid(), merchTargetPref.getPaymentModeId().toString());
            }
            cacheUtil.putMerchantPreferredTargetData(entityId, merchTargetPref.getMid(), merchTargetPref.getPaymentModeId().toString(),
                    new MerchantPreferredTarget(merchTargetPref.getTargetId(), merchTargetPref.getStartDate(),
                            merchTargetPref.getEndDate(), merchTargetPref.getCreatedAt(), merchTargetPref.getUpdatedAt()));
        }
    	logger.trace("Finished Cache Initilization of Merchant target perferences",merchTgtPrefs.size());

    }

    private void initSuccessRatioCache(List<TargetConfigModel> targetConfigModels, Map<Long, InitSmartRouteCacheValue> initSmrtRtCacheValMap, SmartRouteConfigModel smartRouteConfigModel, SourceConfigModel sourceConfigModel) {
        List<SmartRouteTargetDefinition> smartRouteTargetDefinitions = smartRouteConfigModel.getTargetRouteConfig();
        long timeDiffInMillis = initializeCacheWithExistingStats(smartRouteConfigModel, sourceConfigModel);
        InitSmartRouteCacheValue initSmartRouteCacheValue = new InitSmartRouteCacheValue(smartRouteConfigModel, sourceConfigModel, timeDiffInMillis);
        initSmrtRtCacheValMap.put(smartRouteConfigModel.getId(), initSmartRouteCacheValue);

        //delete the existing data, before every initialization
        cacheUtil.deleteSourceCacheMap(getSourceMapKey(sourceConfigModel), smartRouteConfigModel.getSourceId().toString());
        cacheUtil.putSourceData(getSourceMapKey(sourceConfigModel), smartRouteConfigModel.getSourceId().toString(),
                new SourceInfo());

        smartRouteTargetDefinitions.forEach(smartRouteTargetDefinition -> {
            TargetConfigModel targetConfigModel = targetConfigModels.stream().filter(targetConfigModel1 -> smartRouteTargetDefinition.getTargetId().equals(targetConfigModel1.getId()))
                    .findFirst().orElse(null);
            TargetInfo targetInfo = new TargetInfo(targetConfigModel.getName());
            initStaticData(smartRouteTargetDefinition, targetInfo);
            initDynamicData(smartRouteTargetDefinition, targetInfo);

            //delete the existing data, before every initialization
            TargetKey targetKey = new TargetKey(targetConfigModel.getId().toString());
            cacheUtil.deleteTargetCacheMap(getTargetMapKey(sourceConfigModel), targetKey);
            cacheUtil.putTargetData(getTargetMapKey(sourceConfigModel), targetKey, targetInfo);

        });
        logger.info("Cache has been reset and initialized for the source {}", sourceConfigModel.getName());
    }

    private void initPaymentModeAndOptions(List<PaymentModesModel> paymentModesModels, List<PaymentModeOptionsModel> paymentModeOptionsModels) {
    	logger.trace("Starting Cache Initilization of Payment Mode {} and Payment Mode Options: {}", paymentModesModels.size(), paymentModeOptionsModels.size());
        srCacheService.putPaymentModes(paymentModesModels);
        srCacheService.putPaymentModeOptions(paymentModeOptionsModels);
        logger.trace("Finished Cache Initilization of Payment Mode {} and Payment Mode Options: {}", paymentModesModels.size(), paymentModeOptionsModels.size());
    }

    private void initMerchantPaymentModeAndOptions(String entityId, List<MerchantMasterModel> merchantMasterModels,
    		List<MerchantPaymentModesModel> entityMerchPayModeList, List<MerchantPaymentModeOptionsModel> entityMerchPayModeOpsList) {
    	logger.trace("Starting Cache Initilization of Merchant Payment Mode {} and options {}", entityMerchPayModeList.size(), entityMerchPayModeOpsList.size());
    	for (MerchantMasterModel merchantMasterModel : merchantMasterModels) {
            List<CacheMerchantPaymentModeAndOptions> cacheMerchPayModeOpsList = srCacheService.getMerchantPayModeAndOptionsData(entityId, merchantMasterModel.getMid());
            // Initializing the cache for the first time
            if (cacheMerchPayModeOpsList != null) {
                List<MerchantPaymentModesModel> merchPayModeList = entityMerchPayModeList.stream().filter(entityMerch ->
                        entityMerch.getMerchantMasterId().equals(merchantMasterModel.getMerchantMasterId())).collect(Collectors.toList());
                // go further only if merchant payment options are present for the merchant
                for (MerchantPaymentModesModel merchPayMode : merchPayModeList) {
                    CacheMerchantPaymentModeAndOptions cacheMerch = null;
                    for (CacheMerchantPaymentModeAndOptions cacheMerch1 : cacheMerchPayModeOpsList) {
                        if (cacheMerch1.getMerchantPaymentMode().getMerchantPaymentModeId().equals(merchPayMode.getMerchantPaymentModeId())) {
                            cacheMerch = cacheMerch1;
                            break;
                        }
                    }
                    // If payment mode updated date in the cache and fetched from the config service is different then clearing the cache
                    if (cacheMerch != null && merchPayMode.getUpdatedAt().isAfter(cacheMerch.getMerchantPaymentMode().getUpdatedAt())) {
                        srCacheService.removeMerchantPayModeAndOptionsData(entityId, merchantMasterModel.getMid());
                        break;
                    }
                    // If payment mode options updated date in the cache and fetched from the config service is different then clearing the cache
                    else if (cacheMerch != null) {
                        List<MerchantPaymentModeOptionsModel> configMerchPayOps = entityMerchPayModeOpsList.stream().filter(merchPayModeOps ->
                                merchPayModeOps.getMerchantPaymentModeId() != null && merchPayModeOps.getMerchantPaymentModeId().equals(merchPayMode.getMerchantPaymentModeId())
                        ).sorted(Comparator.comparing(MerchantPaymentModeOptionsModel::getUpdatedAt)).collect(Collectors.toList());

                        List<MerchantPaymentModeOptionsModel> cacheMerchPayModeOps = cacheMerch.getMerchantPaymentModeOptions();
                        cacheMerchPayModeOps.sort(Comparator.comparing(MerchantPaymentModeOptionsModel::getUpdatedAt));

                        if ((configMerchPayOps.size() != cacheMerchPayModeOps.size()) ||
                                (!configMerchPayOps.isEmpty() && configMerchPayOps.get(configMerchPayOps.size() - 1).getUpdatedAt()
                                        .isAfter(cacheMerchPayModeOps.get(cacheMerchPayModeOps.size() - 1).getUpdatedAt()))) {
                            srCacheService.removeMerchantPayModeAndOptionsData(entityId, merchantMasterModel.getMid());
                        }
                    }
                }
            }
            List<CacheMerchantPaymentModeAndOptions> cacheMerchPayModeOps = new ArrayList<>();
            long count = entityMerchPayModeList.stream()
                    .filter(entityMechPayMode -> entityMechPayMode.getMerchantMasterId().equals(merchantMasterModel.getMerchantMasterId()))
                    .count();
            if (count > 0) {
                for (MerchantPaymentModesModel merchantPaymentMode : entityMerchPayModeList) {
                    if (merchantPaymentMode.getMerchantMasterId().equals(merchantMasterModel.getMerchantMasterId())) {
                        CacheMerchantPaymentModeAndOptions cacheTgtPayModeAndOps = new CacheMerchantPaymentModeAndOptions();
                        cacheTgtPayModeAndOps.setMerchantPaymentMode(merchantPaymentMode);

                        List<MerchantPaymentModeOptionsModel> collect = entityMerchPayModeOpsList.stream().filter(
                                merchPayModeOpsModel -> merchantPaymentMode.getMerchantPaymentModeId()
                                        .equals(merchPayModeOpsModel.getMerchantPaymentModeId())).collect(Collectors.toList());
                        cacheTgtPayModeAndOps.setMerchantPaymentModeOptions(collect);
                        cacheMerchPayModeOps.add(cacheTgtPayModeAndOps);
                    }
                }
                srCacheService.putMerchantPayModeAndOptionsData(entityId, merchantMasterModel.getMid(), cacheMerchPayModeOps);
            }
        }
    	logger.trace("Finished Cache Initilization of Merchant Payment Mode {} and options {}",entityMerchPayModeList.size(), entityMerchPayModeOpsList.size());
    }

    private void initTargetPaymentModeAndOptions(String entityId, List<TargetPaymentModesModel> entityTargetPaymentModeModels, List<TargetPaymentModeOptionsModel> entityTgtPayModeOpsModels) {
    	Set<CacheTargetPaymentModeAndOptions> cacheTargetPaymentModeAndOptionsList = srCacheService.getAllTargetPayModeAndOptionsData(entityId);
        // If payment mode count in the cache and fetched from the config service is different then clearing the cache
        if ((cacheTargetPaymentModeAndOptionsList != null && !cacheTargetPaymentModeAndOptionsList.isEmpty())) {
        	logger.trace("Removing Cache Initilization of Target Payment Options: {}", cacheTargetPaymentModeAndOptionsList.size());
            if (cacheTargetPaymentModeAndOptionsList.size() != entityTargetPaymentModeModels.size()) {
                srCacheService.removeTargetPayModeAndOptionsData(entityId);
                cacheTargetPaymentModeAndOptionsList = new HashSet<>();
            } else {
                // If payment mode options count in the cache and fetched from the config service is different then clearing the cache
                long count = cacheTargetPaymentModeAndOptionsList.stream().mapToInt(a -> a.getTargetPaymentModeOptions().size()).sum();
                if ((entityTgtPayModeOpsModels.size() != count)) {
                    srCacheService.removeTargetPayModeAndOptionsData(entityId);
                    cacheTargetPaymentModeAndOptionsList = new HashSet<>();
                }
            }
        }
        if (cacheTargetPaymentModeAndOptionsList != null && !cacheTargetPaymentModeAndOptionsList.isEmpty()) {
        	logger.trace("Starting Cache Initilization of Target Payment Mode: {}", entityTargetPaymentModeModels.size());
            for (TargetPaymentModesModel targetPayMode : entityTargetPaymentModeModels) {
                CacheTargetPaymentModeAndOptions cacheTarget = null;
                for (CacheTargetPaymentModeAndOptions cacheTarget1 : cacheTargetPaymentModeAndOptionsList) {
                    if (cacheTarget1.getTargetPaymentMode().getTargetPaymentModeId().equals(targetPayMode.getTargetPaymentModeId())) {
                        cacheTarget = cacheTarget1;
                        break;
                    }
                }
                // If payment mode updated date in the cache and fetched from the config service is different then clearing the cache
                if (cacheTarget != null && targetPayMode.getUpdatedAt().isAfter(cacheTarget.getTargetPaymentMode().getUpdatedAt())) {
                    srCacheService.removeTargetPayModeAndOptionsData(entityId);
                    cacheTargetPaymentModeAndOptionsList = new HashSet<>();
                    break;
                }
                // If payment mode options updated date in the cache and fetched from the config service is different then clearing the cache
                else if (cacheTarget != null) {
                    List<TargetPaymentModeOptionsModel> configTargetPayOps = entityTgtPayModeOpsModels.stream().filter(tgtPayModeOps ->
                                    tgtPayModeOps.getTargetPaymentModeId().equals(targetPayMode.getTargetPaymentModeId()))
                            .sorted(Comparator.comparing(TargetPaymentModeOptionsModel::getUpdatedAt)).collect(Collectors.toList());

                    List<TargetPaymentModeOptionsModel> cacheMerchPayModeOps = cacheTarget.getTargetPaymentModeOptions();
                    cacheMerchPayModeOps.sort(Comparator.comparing(TargetPaymentModeOptionsModel::getUpdatedAt));

                    if ((configTargetPayOps.size() != cacheMerchPayModeOps.size()) ||
                            (!configTargetPayOps.isEmpty() && configTargetPayOps.get(configTargetPayOps.size() - 1).getUpdatedAt().isAfter(cacheMerchPayModeOps.get(cacheMerchPayModeOps.size() - 1).getUpdatedAt()))) {
                        srCacheService.removeTargetPayModeAndOptionsData(entityId);
                        cacheTargetPaymentModeAndOptionsList = new HashSet<>();
                        break;
                    }
                }
            }
        	logger.trace("Finished Cache Initilization of Target Payment Mode: {}", entityTargetPaymentModeModels.size());
        }

        if (cacheTargetPaymentModeAndOptionsList == null || cacheTargetPaymentModeAndOptionsList.isEmpty()) {
        	logger.trace("Starting Cache Initilization of Target Payment Options: {}", entityTgtPayModeOpsModels.size());
            cacheTargetPaymentModeAndOptionsList = new HashSet<>();
            for (TargetPaymentModesModel targetPaymentMode : entityTargetPaymentModeModels) {
                CacheTargetPaymentModeAndOptions cacheTgtPayModeAndOps = new CacheTargetPaymentModeAndOptions();
                cacheTgtPayModeAndOps.setTargetPaymentMode(targetPaymentMode);
                List<TargetPaymentModeOptionsModel> collect = entityTgtPayModeOpsModels.stream().filter(
                        tgtPayModeOpsModel -> targetPaymentMode.getTargetPaymentModeId().equals(tgtPayModeOpsModel.getTargetPaymentModeId())).collect(Collectors.toList());
                cacheTgtPayModeAndOps.setTargetPaymentModeOptions(collect);

                cacheTargetPaymentModeAndOptionsList.add(cacheTgtPayModeAndOps);
                srCacheService.setTargetPayModeAndOptionsData(targetPaymentMode.getEntityId(), cacheTargetPaymentModeAndOptionsList);
            }
            logger.trace("Finished Cache Initilization of Target Payment Options: {}", entityTgtPayModeOpsModels.size());
        }
    }

    private void initTargetLcrCache(String entityId, List<TargetLCRConfigModel> targetLCRConfigs) {
        /*
        Following is done to make sure the current fetched data from config service is what
        we keep in the cache.
         */
    	logger.trace("Starting Cache Initilization of Target LCR {}",targetLCRConfigs.size());
        Map<String, OffsetDateTime> entityConfigLastUpdatedDateMap = new HashMap<>();
        List<TargetLCRConfigModel> collect = targetLCRConfigs.stream().filter(
                        targetLCRConfigModel1 -> targetLCRConfigModel1.getEntityId().equalsIgnoreCase(entityId))
                .sorted(Comparator.comparing(TargetLCRConfigModel::getUpdatedAt))
                .collect(Collectors.toList());

        entityConfigLastUpdatedDateMap.put(entityId, collect.get(collect.size() - 1).getUpdatedAt());

        Map<TargetLcrKey, Set<TargetLcrValue>> targetLCRData = cacheUtil.getTargetLCRData(entityId);
        List<TargetLcrValue> allTargets = new ArrayList<>();
        targetLCRData.values().forEach(allTargets::addAll);

        allTargets.sort(Comparator.comparing(TargetLcrValue::getUpdatedDate));

        // if targets updated date value from DB config is > target updated value stored in cache
        // then clear the cache and put fresh data
        if (!allTargets.isEmpty() && entityConfigLastUpdatedDateMap.get(entityId).isAfter(allTargets.get(allTargets.size() - 1).getUpdatedDate()))
            cacheUtil.clearTargetLcrData(entityId);

        for (TargetLCRConfigModel targetLCRConfigModel : targetLCRConfigs) {
            TargetLcrKey targetLcrKey = getTargetLCRKeyObj(targetLCRConfigModel);
            TargetLcrValue targetLcrValue = getTargetLCRValueObj(targetLCRConfigModel);
            Set<TargetLcrValue> targetLcrValues = cacheUtil.getTargetLCRData(entityId).get(targetLcrKey);
            if (targetLcrValues == null) {
                targetLcrValues = new HashSet<>();
            }
            targetLcrValues.add(targetLcrValue);
            cacheUtil.putTargetLcrData(targetLCRConfigModel.getEntityId(), targetLcrKey, targetLcrValues);
        }
        logger.trace("Finished Cache Initilization Target LCR {}",targetLCRConfigs.size());
    }

    public TargetLcrKey getTargetLCRKeyObj(TargetLCRConfigModel targetLCRConfigModel) {
        return new TargetLcrKey(targetLCRConfigModel.getPaymentModeId(), targetLCRConfigModel.getPaymentModeOptionId(), targetLCRConfigModel.getMccCategory(), targetLCRConfigModel.getCardType());
    }

    public TargetLcrValue getTargetLCRValueObj(TargetLCRConfigModel targetLCRConfigModel) {
        TargetLcrValue targetLcrValue = new TargetLcrValue();
        targetLcrValue.setTargetId(targetLCRConfigModel.getTargetId());
        targetLcrValue.setBelow2000PricePct(targetLCRConfigModel.getBelow2000PricePct());
        targetLcrValue.setBelow2000PriceFixed(targetLCRConfigModel.getBelow2000PriceFixed());
        targetLcrValue.setPricePct(targetLCRConfigModel.getPricePct());
        targetLcrValue.setPriceFixed(targetLCRConfigModel.getPriceFixed());
        targetLcrValue.setStartDate(targetLCRConfigModel.getStartDate());
        targetLcrValue.setEndDate(targetLCRConfigModel.getEndDate());
        targetLcrValue.setUpdatedDate(targetLCRConfigModel.getUpdatedAt());
        return targetLcrValue;
    }

    public void initTargetMerchantMasterCache(List<TargetMerchantMasterModel> targetMerchantMasterModels) {
        if (targetMerchantMasterModels == null || targetMerchantMasterModels.isEmpty()) {
            logger.info("Target merchant master data not present");
            return;
        }
        for (TargetMerchantMasterModel masterModel : targetMerchantMasterModels) {
            if (!StringUtils.isBlank(masterModel.getTargetMid()) || !StringUtils.isBlank(masterModel.getMerchantVpa())) {
                CacheTargetMerchantMaster merchantMaster = new CacheTargetMerchantMaster();
                merchantMaster.setTargetMid(masterModel.getTargetMid());
                merchantMaster.setMerchantVpa(masterModel.getMerchantVpa());
                merchantMaster.setKey(masterModel.getKey());
                merchantMaster.setSalt(masterModel.getSalt());
                merchantMaster.setStatus(masterModel.getStatus());
                merchantMaster.setProdApiKey(masterModel.getProdApiKey());
                merchantMaster.setTestApiKey(masterModel.getTestApiKey());
                merchantMaster.setDpdId(masterModel.getDpaId());
                srCacheService.putTargetMerchantMasterModel(masterModel.getTargetId().toString(), masterModel.getMid(),masterModel.getTid(), merchantMaster);
            }
        }
    }

    private long initializeCacheWithExistingStats(SmartRouteConfigModel smrRtCfgModel, SourceConfigModel
            srcCfgModel) {
        long timeDiffInMillis = 0;
        SmartRouteStatisticsModel srPreStatistics = fetchSmartRouteStatistics(smrRtCfgModel
                , srcCfgModel);
        logger.info("Smart Route Statistics Model: {} ", srPreStatistics);
        Set<Long> smrRtCfgModelTargets = smrRtCfgModel.getTargetRouteConfig().stream().map(SmartRouteTargetDefinition::getTargetId).collect(Collectors.toSet());
        if (srPreStatistics != null && srPreStatistics.getCalculationDate() != null) {
            ZonedDateTime lastCalDate = srPreStatistics.getCalculationDate().atZoneSameInstant(ZoneId.systemDefault());
            OffsetDateTime now = OffsetDateTime.now();
            timeDiffInMillis = lastCalDate.until(now, ChronoUnit.MILLIS);
            long toMinutes = lastCalDate.until(now, ChronoUnit.MINUTES);
            logger.info("Last known stats for the source {} is dated {}, approx {} minutes before",
                    srcCfgModel.getName(), lastCalDate, toMinutes);

            if (timeDiffInMillis < smrRtCfgModel.getSuccessRatioInterval()) {
                SourceInfo sourceInfo = new SourceInfo();
                sourceInfo.setLastCalculatedDate(lastCalDate.toOffsetDateTime());
                cacheUtil.getLocalSourceCalculationTime().put(srcCfgModel.getId().toString(), lastCalDate.toOffsetDateTime());
                cacheUtil.putSourceData(getSourceMapKey(srcCfgModel), srPreStatistics.getSourceId().toString(),
                        sourceInfo);
                List<TargetInfoStatistics> srPreStatisticsTargets = srPreStatistics.getTargets().stream().filter(targetInfoStatistics -> smrRtCfgModelTargets.contains(Long.valueOf(targetInfoStatistics.getTargetId()))).collect(Collectors.toList());
                for (TargetInfoStatistics tgtInfoStats : srPreStatisticsTargets) {
                    TargetInfo targetInfo = new TargetInfo(tgtInfoStats.getTargetInfo().getTargetName());
                    targetInfo.setAlive(tgtInfoStats.getTargetInfo().isAlive());
                    targetInfo.setDynamicTargetInfo(tgtInfoStats.getTargetInfo().getDynamicTargetInfo());

                    TargetKey targetKey = new TargetKey(tgtInfoStats.getTargetId());
                    cacheUtil.putTargetData(getTargetMapKey(srcCfgModel), targetKey, targetInfo);
                }
                logger.info("Cache initialized from last known stats dated {} for source {}", lastCalDate, srcCfgModel.getName());
            }
        }
        return timeDiffInMillis;
    }

    private void initDynamicData(SmartRouteTargetDefinition smartRouteTargetDefinition, TargetInfo targetInfo) {
        targetInfo.setAlive(true);
        targetInfo.getDynamicTargetInfo().setCurrentRoutingPercent(smartRouteTargetDefinition.getDefaultRouteShare());
        targetInfo.getDynamicTargetInfo().setInitialRoutingPercent(smartRouteTargetDefinition.getDefaultRouteShare());
    }

    private void initStaticData(SmartRouteTargetDefinition smartRouteTargetDefinition, TargetInfo targetInfo) {
        targetInfo.getStaticTargetInfo().setPriority(smartRouteTargetDefinition.getTargetPriority());
        targetInfo.getStaticTargetInfo().setCurrentTarget(smartRouteTargetDefinition.getTargetPriority() == TargetPriority.PRIMARY);
    }

    public String getSourceMapKey(SourceConfigModel sourceConfigModel) {
        return sourceConfigModel.getEntityId() + KEY_SEPARATOR + sourceConfigModel.getId() + KEY_SEPARATOR + "info";
    }

    public String getTargetMapKey(SourceConfigModel sourceConfigModel) {
        return sourceConfigModel.getEntityId() + KEY_SEPARATOR + sourceConfigModel.getId() + KEY_SEPARATOR + "targets";
    }

    public String getTargetMapKey(String entityId, String sourceId) {
        return entityId + KEY_SEPARATOR + sourceId + KEY_SEPARATOR + "targets";
    }

    private SmartRouteStatisticsModel fetchSmartRouteStatistics(SmartRouteConfigModel
                                                                        srcModel, SourceConfigModel sourceModl) {

        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", CacheMTMProperties.getProperty("jwt.tlm.token"));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

        String smartRouteUrl = CacheMTMProperties.getProperty("smart.route.tlm.api");

        logger.trace("TLM JWT Authorization: {}", CacheMTMProperties.getProperty("jwt.tlm.token"));
        logger.trace("Fetch Smart Route Statistics url: {}", smartRouteUrl);
        try {

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(smartRouteUrl)
                    .queryParam("entityId", sourceModl.getEntityId()).queryParam("sourceId", srcModel.getSourceId());
            HttpEntity<String> request = new HttpEntity<>(headers);

            ResponseEntity<SmartRouteStatisticsModel> exchange = restTemplate.exchange(builder.toUriString(),
                    HttpMethod.GET, request, SmartRouteStatisticsModel.class);
            return exchange.getBody();
        } catch (Exception e) {
            logger.info("Error while fetching Smart route API by source : ");
        }
        return null;
    }
}