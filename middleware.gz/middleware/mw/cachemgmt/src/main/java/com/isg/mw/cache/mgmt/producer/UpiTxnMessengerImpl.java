package com.isg.mw.cache.mgmt.producer;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.serializers.UpiTxnRequestModelSerializer;
import com.isg.mw.core.model.upi.UpiTxnRequestData;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UpiTxnMessengerImpl implements UpiTxnMessenger , InitializingBean, DisposableBean {

    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    private KafkaProducer producer;

    public UpiTxnMessengerImpl() {
    }

    @Override
    public void send(UpiTxnRequestData upiTxnRequestData) {
        producer.sendMessage(upiTxnRequestData);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        producer = new KafkaProducer(cacheKafkaConfig.getProducerKafkaConfig(cacheKafkaConfig.getUpiTxnReqDataTopicName(), UpiTxnRequestModelSerializer.class));
        producer.init();
    }

    @Override
    public void destroy() throws Exception {

    }
}
