package com.isg.mw.cache.mgmt.init;

import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetConfigModel;

import java.util.List;
import java.util.Map;

/**
 * @author prasad_t026
 */
public interface InitRestClient {

    List<SourceConfigModel> getSourceConfigs();

    List<TargetConfigModel> getTargetConfigs();

    List<MessageTransformationConfigModel> getMessageTransformationConfigs();

    List<HsmConfigModel> getDstmConfigs();

    Long getBinCount();

    List<BinInfoModel> getBinInfos(int pageNo, int pageSize);

    BinInfoModel getBin(String binNumber);

    Long getBinExceptionCount();

    List<BinExceptionsModel> getBinExceptionList(int pageNo, int pageSize);

    BinExceptionsModel getBinException(String binNumber);

    Long getBinOnusCount();

    List<BinOnusModel> getBinOnusMapList(int pageNo, int pageSize);

    BinOnusModel getBinOnusMap(String binNumber);

    Long getAidCount();

    List<AidSchemeModel> getAidList(int pageNo, int pageSize);

    AidSchemeModel getAid(String aid);

    AidSchemeModel getTargetByAid(String aid);


    Long getMapsCount();

    Long getMerchantsCount();

    List<MapsInfoModel> getMapsInfos(int pageNo, int pageSize);

    List<SmartRouteConfigModel> getSmartRouteConfigs();

    List<PaymentModesModel> getPaymentModes();

    List<PaymentModeOptionsModel> getPaymentModeOptions();

    List<TargetPaymentModesModel> getTargetPaymentModes();

    List<TargetPaymentModeOptionsModel> getTargetPaymentModeOptions();

    List<TargetLCRConfigModel> getTargetLCRConfigs();

    List<MerchantPaymentModesModel> getMerchantPaymentModes();

    List<MerchantPaymentModeOptionsModel> getMerchantPaymentModeOptions();

    List<MerchantTargetPreferencesModel> getMerchantTargetPreferences();

    List<MerchantMasterModel> getMerchantMaster(int pageNo, int pageSize);

    List<TargetMerchantMasterModel> getTargetMerchantMaster(int pageNo, int pageSize);

    List<MftrBDKModel> getMftrBdks();

    MapsInfoModel getMapsInfo(String binNumber);

    List<TargetMerchantMasterModel> getTargetMerchantMaster(String targetId,String mid,String tid,String status);

    Long getTargetMerchantMasterCount();

    TargetMerchantMasterModel getTargetMerchantMaster(String targetId,String mid,String tid);

    List<RateLookupModel> getRateLookups();
    
    List<BillingCurrencyModel> getBillingCurrencies();

    MerchantMasterModel getMerchantMasterModelInfo(String binNumber);
}
