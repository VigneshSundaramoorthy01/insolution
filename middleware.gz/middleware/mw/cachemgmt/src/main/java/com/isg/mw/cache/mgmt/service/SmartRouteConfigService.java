package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.sr.*;

public interface SmartRouteConfigService {
    Boolean updateTargetPaymentModesInCache(TargetPaymentModesMessage targetPaymentModesMsgModel);

    Boolean updateTargetPaymentModeOptionInCache(TargetPaymentModeOptionsMessage targetInfo);

    Boolean updateTargetLcrInCache(TargetLCRConfigMessage targetLCRConfigMsgModel);

    Boolean updateMerchantPaymentModesInCache(MerchantPaymentModesMessage merchantPaymentModesMessageModel);

    Boolean updateMerchantPaymentModeOptionInCache(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel);

    Boolean updateMerchantPaymentModesAndOptionInCache(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel);

    Boolean updateTargetMerchantMasterCache(TargetMerchantMasterModel targetMerchantMasterModel);

    Boolean updateTargetMerchantTargetPreferencesInCache(MerchantTargetPreferencesMessage targetPreferencesModel);
}
