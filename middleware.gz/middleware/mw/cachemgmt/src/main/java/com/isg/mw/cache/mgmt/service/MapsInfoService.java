package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;

/**
 * Maps Info Services.
 *
 * @author sudharshan
 */
public interface MapsInfoService {

    /**
     * Update Maps Info into Cache.
     *
     * @param model
     * @return boolean.
     */
    Boolean updateMapsInfo(MapsInfoModel model);

    /**
     * Get MapsInfoModel from cache based on entityId,mid,tid.
     *
     * @param key
     * @return MapsInfoModel
     */
    MapsInfoModel getMapsInfoById(String key);

    Boolean updateMerchantMaster(MerchantMasterModel merchantMasterModel);

    MerchantMasterModel getMerchantMasterById(String key);
}
