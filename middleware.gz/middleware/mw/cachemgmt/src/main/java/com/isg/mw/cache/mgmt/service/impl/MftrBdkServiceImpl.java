package com.isg.mw.cache.mgmt.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import com.isg.mw.cache.mgmt.service.MftrBdkService;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.dstm.MftrBDKModel;

import lombok.Getter;

@Service
@EnableCaching
public class MftrBdkServiceImpl implements MftrBdkService{



    private final Logger LOG = LogManager.getLogger(getClass());

    @Getter
    private static final Map<String, Map<HsmCommandArg, String>> mftrBdkCacheMap = new ConcurrentHashMap<String, Map<HsmCommandArg, String>>();

    /**
     * Update Mftr BDK Object in Cache.
     *
     * @return boolean
     */
    
    @Override
	public Boolean updateBDK(MftrBDKModel model) {
        try {
            if (model != null) {
                Map<HsmCommandArg, String> keyMap = new HashMap<>();
                keyMap.put(HsmCommandArg.Bdk1, model.getBdk1());
                keyMap.put(HsmCommandArg.Bdk2, model.getBdk2());

                mftrBdkCacheMap.put(model.getMftrName(), keyMap);
                    
                LOG.trace("BDk {} Inserted/Updated Successfully...", model);

            } else {
                LOG.info("MftrBdkModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    
	}

    
    /**
     * Get BDK from cache, based on manufacturer.
     *
     * @return MftrBDKModel
     */
	@Override
	public Map<HsmCommandArg, String> getBDKMftrName(String manufacturerName) {
		LOG.info("Getting Mftr Name in getBDKMftrName service {}", manufacturerName);
        Map<HsmCommandArg, String> model = null;

        if (StringUtils.isEmpty(manufacturerName)) {
            return model;
        }
        	
        model = fetchBinFromCache(manufacturerName);
        return model;
	}
    
    private MftrBDKModel getMftrBdkModel(MftrBDKModel model) {
    	MftrBDKModel valueMftrBdkModel = new MftrBDKModel();
    	valueMftrBdkModel.setMftrName(model.getMftrName());
    	valueMftrBdkModel.setEntityId(model.getEntityId());
    	valueMftrBdkModel.setBdk1(model.getBdk1());
    	valueMftrBdkModel.setBdk2(model.getBdk2());
        return valueMftrBdkModel;
    }


    private Map<HsmCommandArg, String> fetchBinFromCache(String mftrName) {
    	Map<HsmCommandArg, String> mftrModelMap = null;
        try {
            mftrModelMap = mftrBdkCacheMap.get(mftrName);
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
        }
        return mftrModelMap;
    }


}
