package com.isg.mw.cache.mgmt.config;

import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Setter
@Getter
@ToString
public class CacheTargetPaymentModeAndOptions implements Serializable {

    private TargetPaymentModesModel targetPaymentMode;
    private List<TargetPaymentModeOptionsModel> targetPaymentModeOptions;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CacheTargetPaymentModeAndOptions that = (CacheTargetPaymentModeAndOptions) o;
        return targetPaymentMode.getTargetPaymentModeId().equals(that.targetPaymentMode.getTargetPaymentModeId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(targetPaymentMode.getTargetPaymentModeId());
    }
}
