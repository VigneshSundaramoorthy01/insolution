package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import org.springframework.stereotype.Service;


import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;

import java.util.List;

@Service
public interface TargetPaymentModeOptionService {

    void init(List<TargetPaymentModeOptionsModel> tpmom);

    Boolean updateTargetPaymentModesInfo(TargetPaymentModeOptionsModel targetInfo);

}
