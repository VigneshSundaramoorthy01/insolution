//package com.isg.mw.cache.mgmt.producer;
//
//import com.isg.kafka.producer.KafkaProducer;
//import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
//import com.isg.mw.cache.mgmt.serializers.TargetMerchantMasterSerializer;
//import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.DisposableBean;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//
//@Service("targetMerchantMasterMessenger")
//public class TargetMerchantMasterMessengerImpl implements TargetMerchantMasterMessenger, InitializingBean, DisposableBean {
//    private final Logger LOG = LogManager.getLogger(getClass());
//    @Autowired
//    private CacheKafkaConfig cacheKafkaConfig;
//
//    private KafkaProducer producer;
//
//    public TargetMerchantMasterMessengerImpl() {
//    }
//
//
//    @Override
//    public void destroy() throws Exception {
//
//    }
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        producer = new KafkaProducer(cacheKafkaConfig.getProducerKafkaConfig(cacheKafkaConfig.getTargetMerchantMasterProducerTopicName(), TargetMerchantMasterSerializer.class));
//        producer.init();
//    }
//
//    @Override
//    public void send(TargetMerchantMasterModel model) {
//        LOG.info("Sending Target Merchant Master to Kafka : {}",model);
//            producer.sendMessage(model);
//    }
//}
