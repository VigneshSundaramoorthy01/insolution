package com.isg.mw.cache.mgmt.init;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author prasad_t026
 */
@PropertySource("${spring.config.location}init-sc.properties")
@Configuration
@Setter
@Getter
public class InitProps {

    @Value("${init.config.rest.server}")
    private String configServer;

    @Value("${init.config.rest.src.uri}")
    private String configSourceUri;

    @Value("${init.config.rest.trt.uri}")
    private String configTargetUri;

    @Value("${init.config.rest.rds.uri}")
    private String configRouteDefUri;

    @Value("${init.config.rest.dstm.uri}")
    private String configDstmUri;

    @Value("${init.config.rest.bin.count.uri}")
    private String configBinCountUri;

    @Value("${init.config.rest.bins.uri}")
    private String configBinsUri;

    @Value("${init.config.rest.get.bin.uri}")
    private String configGetBinUri;

    @Value("${init.config.rest.bin.exception.count.uri}")
    private String configBinExceptionCountUri;

    @Value("${init.config.rest.bin.exceptions.uri}")
    private String configBinExceptionsUri;

    @Value("${init.config.rest.get.bin.exception.uri}")
    private String configGetBinExceptionUri;

    @Value("${init.config.rest.bin.onus.map.count.uri}")
    private String configBinOnusMapCountUri;

    @Value("${init.config.rest.bin.onus.maps.uri}")
    private String configBinOnusMapsUri;

    @Value("${init.config.rest.get.bin.onus.map.uri}")
    private String configGetBinOnusMapUri;

    @Value("${init.config.rest.aid.count.uri}")
    private String configAidCountUri;

    @Value("${init.config.rest.aids.uri}")
    private String configAidsUri;

    @Value("${init.config.rest.get.aid.uri}")
    private String configGetAidUri;

    @Value("${init.config.rest.get.target.by.aid.uri}")
    private String configGetTargetByAidUri;

    @Value("${init.config.rest.maps.count.uri}")
    private String configMapsCountUri;

    @Value("${init.config.rest.merchant.master.count.uri}")
    private String configMerchantsCountUri;

    @Value("${init.config.rest.maps.uri}")
    private String configMapsUri;

    @Value("${init.rest.connection.timeout}")
    private String restConnectionTimeout;

    @Value("${init.rest.read.timeout}")
    private String restReadTimeout;

    @Value("${application.instance.name}")
    private String applicstionInstnce;

    @Value("${init.jwt.cm.token}")
    private String cmToken;

    @Value("${init.config.rest.smartroute.uri}")
    private String configSmartRouteUri;

    @Value("${init.config.rest.targetlcr.uri}")
    private String configTargetLCRUri;

    @Value("${init.rbac.rest.serviceKey}")
    private String serviceKey;

    @Value("${init.rbac.rest.expirationTime}")
    private int expirationTime;

    @Value("${init.rbac.rest.userName}")
    private String userName;

    @Value("${init.rbac.rest.server}")
    private String rbacServer;

    @Value("${init.rbac.rest.login.uri}")
    private String rbacLoginUri;

    @Value("${init.config.rest.paymentmode.uri}")
    private String paymentModesUri;

    @Value("${init.config.rest.paymentmode.options.uri}")
    private String paymentModeOptionsUri;

    @Value("${init.config.rest.target.paymentmode.uri}")
    private String targetPaymentModesUri;

    @Value("${init.config.rest.target.paymentmode.options.uri}")
    private String targetPaymentModeOptionsUri;

    @Value("${init.config.rest.merchant.paymentmode.uri}")
    private String merchantPaymentModesUri;

    @Value("${init.config.rest.merchant.paymentmode.options.uri}")
    private String merchantPaymentModeOptionsUri;

    @Value("${init.config.rest.merchant.target.preferences.uri}")
    private String merchantTargetPreferencesUri;

    @Value("${init.config.rest.merchant.master.uri}")
    private String merchantMasterUri;

    @Value("${init.config.rest.target.merchant.master.uri}")
    private String targetMerchantMasterUri;

	@Value("${init.config.rest.mftr.uri}")
	private String mftrBdkUri;
	
	@Value("${init.config.rest.get.map.uri}")
	private String configGetMapUri;

    @Value("${init.config.rest.get.merchant.master.uri}")
    private String configGetMerchantUri;

    @Value("${init.config.rest.convenience.api.clientId}")
    private String clientId;

    @Value("${init.config.rest.convenience.api.clientSecret}")
    private String clientSecret;

    @Value("${init.config.rest.convenience.api.requestorId}")
    private String requestorId;

    @Value("${init.config.rest.convenience.api.inputterId}")
    private String inputterId;

    @Value("${init.config.rest.convenience.api.approverId}")
    private String approverId;

    @Value("${init.config.rest.convenience.api.ticketId}")
    private String ticketId;

    @Value("${init.rest.notification.server}")
    private String notificationServer;

    @Value("${init.rest.notification.uri}")
    private String notificationUri;

    @Value("${init.config.rest.business.type.uri}")
    private String configBusinessTypeUri;

    @Value("${init.config.rest.lyra.ownership.type.uri}")
    private String configLyraOwnershipTypeUri;

    @Value("${init.config.rest.upi.ownership.type.uri}")
    private String configUpiOwnershipTypeUri;

    @Value("${init.config.rest.get.target.merchant.master.uri}")
    private String configTargetMerMasterUri;

    @Value("${init.rate.lookup.uri}")
    private String rateLookupUri;
    
    @Value("${init.billing.currencies.uri}")
    private String billingCurrenciesUri;

    @Value("${init.config.rest.tpsl.entity.type.uri}")
    private String configTpslEntityTypeUri;

    @Value("${init.config.rest.target.merchant.master.count.uri}")
    private String configTargetMerMasterCountUri;

    //BMS

    @Value("${init.bill.fetch.npci.mock.url}")
    private String billFetchNpciResponseUrl;

    @Value("${init.bill.pay.npci.mock.url}")
    private String billPayNpciResponseUrl;

    @Value("${init.bill.pay.status.npci.mock.url}")
    private String billPayStatusNpciResponseUrl;

    @Value("${init.npci.heart.beat.mock.url}")
    private String npciHeartBeatUrl;

    @Value("${init.reversal.pay.npci.mock.url}")
    private String npciReversalPayNpciResponseUrl;


    @Value("${init.bill.fetch.npci.error.mock.url}")
    private String billFetchNpciErrorResponseUrl;
}
