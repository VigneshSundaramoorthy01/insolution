package com.isg.mw.cache.mgmt.config;

import com.isg.bms.commonModels.BillPayTransactionDetails;
import com.isg.bms.commonModels.BmsTxnDataModel;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.PaymentModeOptionsModel;
import com.isg.mw.core.model.sr.PaymentModesModel;
import com.isg.mw.core.model.sr.SourceInfo;
import com.isg.mw.core.model.sr.TargetInfo;
import com.isg.mw.core.model.sr.TargetKey;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfiguration {

    private final Logger logger = LogManager.getLogger(getClass());

    @Value("${spring.redis.sentinel.nodes:}")
    private String[] redisSentinelNodes;

    @Value("${spring.redis.sentinel.master:}")
    private String redisSentinelMaster;

    @Value("${spring.redis.host:}")
    private String redisHostName;

    @Value("${spring.redis.port:0}")
    private int redisPort;

    @Value("${spring.redis.password:}")
    private String redisPassword;

    @Value("${redis.ssl.enabled:false}")
    private boolean isSslEnabled;

    @Bean
    protected RedisConnectionFactory jedisConnectionFactory() {
        JedisConnectionFactory factory;
        if (!(Arrays.asList(redisSentinelNodes).isEmpty())) {
            factory = jedisSentinelConnectionFactory();
        } else {
            RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration(redisHostName, redisPort);
            configuration.setPassword(redisPassword);
            JedisClientConfiguration.JedisClientConfigurationBuilder jedisClientConfiguration = JedisClientConfiguration.builder();
            jedisClientConfiguration.connectTimeout(Duration.ofSeconds(60));
            jedisClientConfiguration.usePooling();

            if (isSslEnabled) {
                logger.info("Redis SSL CONNECTION: {}", redisPort);
                jedisClientConfiguration.useSsl();
            } else {
                logger.info("Redis NON-SSL CONNECTION: {}", redisPort);
            }

            factory = new JedisConnectionFactory(configuration, jedisClientConfiguration.build());
            factory.afterPropertiesSet();
        }
        return factory;
    }

    public JedisConnectionFactory jedisSentinelConnectionFactory() {
        RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration().master(redisSentinelMaster);
        logger.info("Redis sentinel nodes: {}", redisSentinelNodes);
        for (String sentinalNode : redisSentinelNodes) {
            String str = sentinalNode.trim();
            int beginIndex = str.indexOf(":");
            int endIndex = str.length();
            sentinelConfig.sentinel(str.substring(0, beginIndex),
                    Integer.parseInt(str.substring(beginIndex + 1, endIndex)));
        }
        return new JedisConnectionFactory(sentinelConfig);
    }

    @Bean
    public RedisTemplate<String, Map<TargetKey, TargetInfo>> targetInfoRedisTemplate(
            RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, Map<TargetKey, TargetInfo>> redisTemplate = new RedisTemplate<>();
        redisTemplate.setHashKeySerializer(new TargetKeySerializer());
        redisTemplate.setHashValueSerializer(new TargetInfoSerializer());
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, Map<TargetLcrKey, Set<TargetLcrValue>>> targetLcrRedisTemplate(
            RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, Map<TargetLcrKey, Set<TargetLcrValue>>> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, SourceInfo> sourceInfoRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, SourceInfo> redisTemplate = new RedisTemplate<>();
        redisTemplate.setHashValueSerializer(new SourceInfoSerializer());
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, Map<HsmCommandArg, String>> hsmRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, Map<HsmCommandArg, String>> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, Map<TargetType, String>> targetDynamicKeyTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, Map<TargetType, String>> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, Integer> atomicIntegerTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, Integer> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }


    @Bean
    public RedisTemplate<String, MerchOrdTxnData> txnDataRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, MerchOrdTxnData> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, MerchantPreferredTarget> merchantPreferredTargetRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, MerchantPreferredTarget> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }


    @Bean
    public RedisTemplate<String, RateLookupModel> dccRateLookUpTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, RateLookupModel> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }
    
    @Bean
    public RedisTemplate<Integer, BillingCurrencyModel> billingCurrenciesTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<Integer, BillingCurrencyModel> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, EFTPOSKeyModel> eftposRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, EFTPOSKeyModel> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
        
    }

    @Bean
    @Primary
    public RedisTemplate<String, String> seqNoRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, String> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }


    @Bean
    public RedisTemplate<String, TransactionMessageModel> txnMsgModelRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, TransactionMessageModel> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, BillPayTransactionDetails> billPayTransactionDetailsRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, BillPayTransactionDetails> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, BmsTxnDataModel> bmsTxnDataModelRedisTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, BmsTxnDataModel> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, List<BmsTxnDataModel>> bmsTxnDataListTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, List<BmsTxnDataModel>> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, Object> bmsTempAllRecords(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(connectionFactory);
        template.setKeySerializer(new StringRedisSerializer());
        return template;

    }

    @Bean
    public RedisTemplate<String, List<String>> billNoListOpsTemplate(RedisConnectionFactory connectionFactory) {
        final RedisTemplate<String, List<String>> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(connectionFactory);
        return redisTemplate;
    }

    @Bean
    public RedisTemplate<String, String> billNoRedisTemp(RedisConnectionFactory connectionFactory) {
        RedisTemplate<String, String> template = new RedisTemplate<>();
        template.setConnectionFactory(connectionFactory);
        template.setKeySerializer(new StringRedisSerializer());
        return template;
    }
}
