package com.isg.mw.cache.mgmt.config;

import com.isg.mw.cache.mgmt.config.TargetLcrValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;

import java.io.*;
import java.util.List;


public class TargetLcrValueSerializer implements RedisSerializer<List<TargetLcrValue>> {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public byte[] serialize(List<TargetLcrValue> targetLcrValue) throws SerializationException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(targetLcrValue);
            oos.flush();
        } catch (IOException e) {
//            logger.error("Error while serializing object: {}", e);
        }
        return bos.toByteArray();
    }

    @Override
    public List<TargetLcrValue> deserialize(byte[] bytes) throws SerializationException {
        List<TargetLcrValue> targetLcrValue = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            targetLcrValue = (List<TargetLcrValue>) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing object", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class not found", e);
        }
        return targetLcrValue;
    }
}

