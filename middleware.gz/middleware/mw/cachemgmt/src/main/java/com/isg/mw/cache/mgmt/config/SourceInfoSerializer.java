package com.isg.mw.cache.mgmt.config;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.SerializationException;

import com.isg.mw.core.model.sr.SourceInfo;

public class SourceInfoSerializer implements RedisSerializer<SourceInfo> {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public byte[] serialize(SourceInfo o) throws SerializationException {

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(o);
            oos.flush();
        } catch (IOException e) {
            logger.error("Error while serializing object", e);
        }
        return bos.toByteArray();
    }

    @Override
    public SourceInfo deserialize(byte[] bytes) throws SerializationException {
        SourceInfo sourceInfo = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            sourceInfo = (SourceInfo) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing object", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class not found", e);
        }
        return sourceInfo;
    }
}
