package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.service.EftPosKeyDetailsService;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.SignOnSignOffModel;
import com.isg.mw.core.model.eftpos.TempKeyModel;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
@EnableCaching
public class EftPosKeyDetailsServiceImpl implements EftPosKeyDetailsService {

    private final Logger logger = LogManager.getLogger(getClass());

    @Getter
    private static final Map<String, EFTPOSKeyModel> eftposKeyCacheMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<String, TempKeyModel> eftposTempKeyCacheMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<String, Boolean> signOffCacheMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<String, SignOnSignOffModel> reSignonCacheMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<String, String> activeTargetCacheMap = new ConcurrentHashMap<>();
    
    @Getter
    private static final Map<String, String> activeTargetPortCacheMap = new ConcurrentHashMap<>();


    @Override
    public EFTPOSKeyModel getEftposKeyDetails(String key) {
        logger.info("Key Target Name :: {}", key);
        EFTPOSKeyModel eftposKeyModel = eftposKeyCacheMap.get(key);
        if(eftposKeyModel == null){
            return new  EFTPOSKeyModel();
        }else {
            return eftposKeyModel;
        }

    }

    @Override
    public void updateEftposKeyDetails(String key, EFTPOSKeyModel eftposKeyModelrequest) {
        EFTPOSKeyModel eftposKeyModel = eftposKeyCacheMap.get(key);
        if(eftposKeyModel == null){
            eftposKeyModel = new  EFTPOSKeyModel();
        }
        eftposKeyModel.setKeySetId(eftposKeyModelrequest.getKeySetId());
        eftposKeyModel.setTargetKey(eftposKeyModelrequest.getTargetKey());
        eftposKeyModel.setSignonKey(eftposKeyModelrequest.isSignonKey());
        eftposKeyModel.setTargetName(eftposKeyModelrequest.getTargetName());

        eftposKeyCacheMap.put(key,eftposKeyModel );
    }

    @Override
    public TempKeyModel getTempEftposKeyDetails(String key) {
        TempKeyModel eftposKeyModel = eftposTempKeyCacheMap.get(key);
        if(eftposKeyModel == null){
            return new  TempKeyModel();
        }else {
            return eftposKeyModel;
        }

    }

    @Override
    public void updateEftposTempKeyDetails(String targetName, TempKeyModel eftposKeyModel) {

        TempKeyModel tempKeyModel = eftposTempKeyCacheMap.get(targetName);
        if(tempKeyModel == null){
            tempKeyModel = new  TempKeyModel();
        }

        tempKeyModel.setZpkUnderLMK(eftposKeyModel.getZpkUnderLMK());
        tempKeyModel.setZpkUnderZMK(eftposKeyModel.getZpkUnderZMK());
        tempKeyModel.setZpkKCV(eftposKeyModel.getZpkKCV());

        tempKeyModel.setZakUnderLMK(eftposKeyModel.getZakUnderLMK());
        tempKeyModel.setZakUnderZMK(eftposKeyModel.getZakUnderZMK());
        tempKeyModel.setZakKCV(eftposKeyModel.getZakKCV());

        tempKeyModel.setZekUnderLMK(eftposKeyModel.getZekUnderLMK());
        tempKeyModel.setZekUnderZMK(eftposKeyModel.getZekUnderZMK());
        tempKeyModel.setZekKCV(eftposKeyModel.getZekKCV());

        eftposTempKeyCacheMap.put(targetName,tempKeyModel);

    }

    @Override
    public boolean getSignOffStatus(String targetName) {
        boolean singnoffStatus = false;
        if(signOffCacheMap.size() >0){
            try {
                singnoffStatus = signOffCacheMap.get(targetName);
            }catch (NullPointerException e) {
                singnoffStatus = false;
            }
        }else{
            try {
                singnoffStatus = signOffCacheMap.get(targetName);
            }catch (NullPointerException e) {
                singnoffStatus = false;
            }
        }
        return singnoffStatus;
    }

    @Override
    public void putSignOffStatus(boolean status, String targetName) {
        signOffCacheMap.put(targetName ,status);

    }

    @Override
    public SignOnSignOffModel getEftposSignOnStatus() {
        SignOnSignOffModel signOnSignOffModel = reSignonCacheMap.get("signOnStatus");
        if(signOnSignOffModel == null){
            return new  SignOnSignOffModel();
        }else {
            return  signOnSignOffModel;
        }
    }

    @Override
    public void putEftposSignOnStatus(boolean status, String targetIp) {
        SignOnSignOffModel signOnSignOffModel = new SignOnSignOffModel();
        signOnSignOffModel.setReSignOn(status);
        signOnSignOffModel.setTargetIp(targetIp);
        reSignonCacheMap.put("signOnStatus",signOnSignOffModel);
    }

    @Override
    public String getActiveTargetId() {
        return activeTargetCacheMap.get("activeTargetNameCacheMap");
    }

    @Override
    public void deleteActiveTargetId(String activeTargetName) {
        activeTargetCacheMap.remove("activeTargetNameCacheMap",activeTargetName);
    }

    @Override
    public void putActiveTargetId(String activeTargetName) {
        activeTargetCacheMap.put("activeTargetNameCacheMap",activeTargetName);
    }
    
    
    @Override
    public String getActiveTargetPort(String linkName) {
        return activeTargetPortCacheMap.get(linkName);
    }

    @Override
    public void deleteActiveTargetPort(String linkName, String activeTargetPort) {
    	activeTargetPortCacheMap.remove(linkName ,activeTargetPort);
    }

    @Override
    public void putActiveTargetPort(String linkName, String activeTargetPort) {
    	activeTargetPortCacheMap.put(linkName ,activeTargetPort);
    }
}
