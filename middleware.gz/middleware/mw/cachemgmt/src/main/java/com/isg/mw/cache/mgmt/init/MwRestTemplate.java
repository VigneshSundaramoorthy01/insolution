package com.isg.mw.cache.mgmt.init;

import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;

/**
 * @author prasad_t026
 *
 */
@Configuration
public class MwRestTemplate {

	@Value("${init.rest.connection.timeout}")
	private int connectionTimeout;

	@Value("${init.rest.read.timeout}")
	private int readTimeout;

	@Autowired
	Environment environment;


	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		RestTemplate restTemplate = builder
				.setConnectTimeout(Duration.ofMillis(connectionTimeout))
				.setReadTimeout(Duration.ofMillis(readTimeout))
				.build();
		restTemplate.setRequestFactory(disableSsl());
		return  restTemplate;
	}

	@Bean
	@Qualifier("plainTemplate")
	public RestTemplate plainRestTemplate(RestTemplateBuilder builder) {
		RestTemplate restTemplate = builder
				.setConnectTimeout(Duration.ofMillis(connectionTimeout))
				.setReadTimeout(Duration.ofMillis(readTimeout))
				.build();
		return restTemplate;
	}


	@Bean
	public HttpComponentsClientHttpRequestFactory disableSsl() {
		TrustStrategy acceptingTrustStatergy = new TrustStrategy() {

			@Override
			public boolean isTrusted(X509Certificate[] x509Certificate, String s) throws CertificateException {
				return true;
			}
		};
		SSLContext sslContext = null;
		try {
			SSLContext.getInstance("TLSv1.2");
			sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStatergy).build();
		} catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
			e.printStackTrace();
		}
		HttpHost httpHost = new HttpHost("192.168.84.28",//84.28
				Integer.parseInt("9021"));//443
		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).setProxy(httpHost).build();
		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(
				httpClient);
		httpComponentsClientHttpRequestFactory.setReadTimeout(120000);
		httpComponentsClientHttpRequestFactory.setConnectTimeout(120000);
		return httpComponentsClientHttpRequestFactory;

	}

}