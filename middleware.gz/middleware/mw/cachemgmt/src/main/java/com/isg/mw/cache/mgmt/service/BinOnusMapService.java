package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinOnusModel;

public interface BinOnusMapService {

    /**
     * Update BinInfo in Cache
     *
     * @param binOnusModel
     * @return boolean
     */
    Boolean updateBinOnusModel(BinOnusModel binOnusModel);

    /**
     * Get BinOnusModel Info from cache based on binNumber.
     *
     * @param cardNumber
     * @return BinOnusModel
     */
    BinOnusModel getBinInfoByCardNumber(String cardNumber);

}
