package com.isg.mw.cache.mgmt.producer;

import com.isg.kafka.producer.KafkaProducer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.serializers.TransactionMessageModelV2Serializer;
import com.isg.mw.core.model.upi.TransactionMessageModelV2;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UpiTlmMessengerImpl implements  UpiTlmMessenger, InitializingBean, DisposableBean {


    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    private KafkaProducer producer;

    public UpiTlmMessengerImpl() {
    }

    @Override
    public void send(TransactionMessageModelV2 resultModel) {
        System.out.println("In send method of tmm"+cacheKafkaConfig.getUpiTopicName());
        producer.sendMessage(resultModel);
    }


    @Override
    public void afterPropertiesSet() throws Exception {

        System.out.println("@@@@@@@@@@@@@@@@@@@@");
        producer = new KafkaProducer(cacheKafkaConfig.getProducerKafkaConfig(cacheKafkaConfig.getUpiTopicName(), TransactionMessageModelV2Serializer.class));
        producer.init();
    }

    @Override
    public void destroy() throws Exception {

    }

}
