package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.AidSchemeMapService;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@EnableCaching
public class AidSchemeMapServiceImpl implements AidSchemeMapService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Getter
    private static final Map<AidSchemeModel, AidSchemeModel> aidCacheMap = new ConcurrentHashMap<>();

    @Autowired
    private InitRestClient initRestClient;

    @Value("${bin.fetch.flag}")
    private String binFetchFlag;



    @Override
    public Boolean updateAidSchemeModel(AidSchemeModel aidSchemeModel) {
        try {
            if (aidSchemeModel != null) {
                AidSchemeModel valueBin = getAidSchemeModel(aidSchemeModel);
                AidSchemeModel key = constructKey(aidSchemeModel);
                if (ActiveFlag.N.equals(valueBin.getActiveFlag())) {
                    LOG.trace("BIN {} is now inactive, hence can be evicted", valueBin);
                    AidSchemeModel removedAid = aidCacheMap.remove(key);
                    if (removedAid != null)
                        LOG.trace("BIN {} Evicted Successfully...", removedAid);
                    else
                        LOG.trace("BIN {} is inactive, hence not added in cache", aidSchemeModel);
                } else {
                    aidCacheMap.put(key, valueBin);
                    LOG.trace("BIN {} Inserted/Updated Successfully...", aidSchemeModel);
                }
            } else {
                LOG.info("BinInfoModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    private AidSchemeModel getAidSchemeModel(AidSchemeModel model) {
        AidSchemeModel valueAidSchemeModel = new AidSchemeModel();
        valueAidSchemeModel.setAid(model.getAid());
        valueAidSchemeModel.setEntityId(model.getEntityId());
        valueAidSchemeModel.setTargetId(model.getTargetId());
        valueAidSchemeModel.setRemark(model.getRemark());
        valueAidSchemeModel.setActiveFlag(model.getActiveFlag());

        return valueAidSchemeModel;
    }

    @Override
    public AidSchemeModel getTargetIdByAid(String aid) {
        AidSchemeModel binInfo = null;

        if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
           binInfo = fetchAidFromApi(aid);
       } else if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            binInfo = fetchAidFromCache(aid);
        }
        return binInfo;
    }

    private AidSchemeModel fetchAidFromApi(String aid) {
        return initRestClient.getTargetByAid(aid);
    }

    private AidSchemeModel fetchAidFromCache(String aid) {
        AidSchemeModel aidSchemeModel = new AidSchemeModel();
        try {
            aidSchemeModel.setAid(aid);
            aidSchemeModel = aidCacheMap.get(aidSchemeModel);
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
        }
        return aidSchemeModel;
    }
    /**
     * This method constructs key.
     *
     * @param model BinOnusModel
     * @return key
     */
    private AidSchemeModel constructKey(AidSchemeModel model) {
        AidSchemeModel keyAidSchemeModel = new AidSchemeModel();
        keyAidSchemeModel.setAid(model.getAid());
        keyAidSchemeModel.setTargetId(model.getTargetId());
        keyAidSchemeModel.setEntityId(model.getEntityId());
        return keyAidSchemeModel;
    }

}
