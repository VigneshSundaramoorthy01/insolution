package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.config.CacheMerchantPaymentModeAndOptions;
import com.isg.mw.cache.mgmt.config.CacheTargetPaymentModeAndOptions;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.sr.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.cache.CacheException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.isg.mw.cache.mgmt.config.CacheConstants.*;

@Service
@EnableCaching
public class SmartRouteSpringCacheServiceImpl implements SmartRouteSpringCacheService {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private InitRestClient initRestClient;


    /**
     * PAYMENT MODES
     */
    @Override
    public Boolean putPaymentModes(List<PaymentModesModel> paymentModesModels) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.PAYMENT_MODES_CACHE);
            if (!CollectionUtils.isEmpty(paymentModesModels)) {
                cache.put(PAYMENT_MODES, paymentModesModels);
            } else {
                logger.info("Payment modes models is Null or Empty");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.error("An error occurred while push the payment modes models into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public PaymentModesModel getPaymentMode(Long key) {
        logger.info("Getting payment modes model info by key: {}", key);
        PaymentModesModel paymentModesModel = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.PAYMENT_MODES_CACHE);
            List<PaymentModesModel> paymentModesModelList = cache.get(PAYMENT_MODES) != null ? (List)cache.get(PAYMENT_MODES).get() : null;
            if(!CollectionUtils.isEmpty(paymentModesModelList)) {
                paymentModesModel = paymentModesModelList.stream().filter(list -> list.getPaymentModeId().equals(key)).findAny().orElse(null);
            }
            logger.info("payment modes model data from cache: {}", paymentModesModel != null ? paymentModesModel.getPaymentModeId() : null);
        } catch (CacheException e) {
            logger.error("An error occurred while getting the payment modes model from cache", e);
        }
        return paymentModesModel;
    }

    /**
     * PAYMENT MODE OPTIONS
     *
     */
    @Override
    public Boolean putPaymentModeOptions(List<PaymentModeOptionsModel> paymentModeOptionsModels) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.PAYMENT_MODE_OPTIONS_CACHE);
            if (!CollectionUtils.isEmpty(paymentModeOptionsModels)) {
                cache.put(PAYMENT_MODE_OPTIONS, paymentModeOptionsModels);
            } else {
                logger.info("Payment mode options models is Null or Empty");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.error("An error occurred while push the payment mode options models into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public PaymentModeOptionsModel getPaymentModeOption(Long key) {
        logger.info("Getting payment mode options model info by key: {}", key);
        PaymentModeOptionsModel paymentModeOptionsModel = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.PAYMENT_MODE_OPTIONS_CACHE);
            List<PaymentModeOptionsModel> paymentModesOptionList = cache.get(PAYMENT_MODE_OPTIONS) != null ? (List)cache.get(PAYMENT_MODE_OPTIONS).get() : null;
            if(!CollectionUtils.isEmpty(paymentModesOptionList)) {
                paymentModeOptionsModel = paymentModesOptionList.stream().filter(list -> list.getPaymentModeOptionId().equals(key)).findAny().orElse(null);
            }
            logger.info("payment mode options model data from cache: {}",  paymentModeOptionsModel != null ? paymentModeOptionsModel.getPaymentModeOptionId() : null);
        } catch (CacheException e) {
            logger.error("An error occurred while getting the payment mode options model from cache", e);
        }
        return paymentModeOptionsModel;
    }

    @Override
    public List<PaymentModeOptionsModel> getAllPaymentModeOption() {
        logger.info("Getting payment mode options model info by key: {}");
        List<PaymentModeOptionsModel> paymentModeOptionsModelList = new ArrayList<>();
        try {
            Cache cache = cacheManager.getCache(CacheConstants.PAYMENT_MODE_OPTIONS_CACHE);
            paymentModeOptionsModelList = cache.get(PAYMENT_MODE_OPTIONS) != null ? (List)cache.get(PAYMENT_MODE_OPTIONS).get() : null;
            logger.info("payment mode options model data from cache: {}", paymentModeOptionsModelList != null ? paymentModeOptionsModelList.size() : null);
        } catch (Exception e) {
            logger.info("An error occurred while getting the payment mode options model from cache", e);
        }
        return paymentModeOptionsModelList;
    }

    @Override
    public PaymentModeOptionsModel getPaymentModeOption(Long paymentModeId, String schemeType) {
        List<PaymentModeOptionsModel> entries = getAllPaymentModeOption();
        return entries.stream()
                .filter(list ->
                        list.getPaymentModeId().equals(paymentModeId) && list.getModeOptionName().equals(schemeType)
                ).findAny().orElse(null);
    }

    /**
     * TARGET PAYMENT MODES AND OPTIONS
     */
    @Override
    public Boolean setTargetPayModeAndOptionsData(String entityId, Set<CacheTargetPaymentModeAndOptions> cacheTgtPayModeAndOpsList) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS_CACHE);
            if (cacheTgtPayModeAndOpsList != null) {
                cache.put(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId, cacheTgtPayModeAndOpsList);
            } else {
                logger.info("Target Payment Mode And Options are Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.info("An error occurred while push the Target Payment Mode And Options model into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public void removeTargetPayModeAndOptionsData(String entityId) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS_CACHE);
            if (entityId != null) {
                cache.evict(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId);
            } else {
                logger.info("Target Payment Mode And Options are Null");
            }
        } catch (Exception e) {
            logger.info("An error occurred while delete the Target Payment Mode And Options model into cache", e);
        }
    }

    @Override
    public Set<CacheTargetPaymentModeAndOptions> getAllTargetPayModeAndOptionsData(String entityId) {
        logger.info("Getting Target Payment Mode And Options model info by key: {}", CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId);
        Set<CacheTargetPaymentModeAndOptions> targetPaymentModeAndOptions = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS_CACHE);
            targetPaymentModeAndOptions = cache.get(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId) != null ?
                    (HashSet) cache.get(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId).get() : null;
            logger.info("Target Payment Mode And Options model data from cache: {}", targetPaymentModeAndOptions != null ? targetPaymentModeAndOptions.size() : null);
        } catch (Exception e) {
            logger.info("An error occurred while getting the Target Payment Mode And Options model from cache", e);
            return null;
        }
        return targetPaymentModeAndOptions;
    }

    @Override
    public CacheTargetPaymentModeAndOptions getTargetPayModeAndOptionsData(String entityId, String targetId, String payModeId) {
        CacheTargetPaymentModeAndOptions cacheTargetPayModeAndOptions1 = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS_CACHE);
            Set<CacheTargetPaymentModeAndOptions> cacheTargetPaymentModeAndOptions = cache.get(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId) != null ?
                    (HashSet) cache.get(CacheConstants.TARGET_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId).get() : null;
            if (cacheTargetPaymentModeAndOptions != null)
                for (CacheTargetPaymentModeAndOptions cacheTarget : cacheTargetPaymentModeAndOptions) {
                    if (cacheTarget.getTargetPaymentMode().getTargetId().toString().equals(targetId) && cacheTarget.getTargetPaymentMode().getPaymentModeId().toString().equals(payModeId)) {
                        if (cacheTarget.getTargetPaymentMode() != null) {
                            cacheTarget.setTargetPaymentModeOptions(cacheTarget.getTargetPaymentModeOptions());
                            cacheTargetPayModeAndOptions1 = cacheTarget;
                            break;
                        }
                        break;
                    }
                }
        }catch (Exception e){
            logger.info("An error occurred while getting the Target Payment Mode And Options model from cache", e);
            return null;
        }
        return cacheTargetPayModeAndOptions1;
    }

    @Override
    public CacheTargetPaymentModeAndOptions getTargetPayModeAndOptionsData(String entityId, String targetId, String payModeId, String payModeOptionId) {
        Set<CacheTargetPaymentModeAndOptions> cacheTargetPaymentModeAndOptions = getAllTargetPayModeAndOptionsData(entityId);
        cacheTargetPaymentModeAndOptions = cacheTargetPaymentModeAndOptions.stream().filter(cacheTargetPay->cacheTargetPay.getTargetPaymentMode().getEntityId().equals(entityId)).collect(Collectors.toSet());
        CacheTargetPaymentModeAndOptions cacheTargetPayModeAndOptions1 = new CacheTargetPaymentModeAndOptions();
        if (cacheTargetPaymentModeAndOptions != null)
            for (CacheTargetPaymentModeAndOptions cacheTarget : cacheTargetPaymentModeAndOptions) {
                if (cacheTarget.getTargetPaymentMode().getTargetId().toString().equals(targetId)) {
                    if (cacheTarget.getTargetPaymentMode().getPaymentModeId().toString().equals(payModeId)) {
                        if (isDateInBetweenEndPoints(cacheTarget.getTargetPaymentMode().getStartDate(),
                                cacheTarget.getTargetPaymentMode().getEndDate(), OffsetDateTime.now())) {
                            List<TargetPaymentModeOptionsModel> filteredPayOps = cacheTarget.getTargetPaymentModeOptions().stream()
                                    .filter(cacheTargetOps -> isDateInBetweenEndPoints(cacheTargetOps.getStartDate(), cacheTargetOps.getEndDate(), OffsetDateTime.now()))
                                    .collect(Collectors.toList());
                            filteredPayOps = filteredPayOps.stream().filter(targetPayModeOption -> targetPayModeOption.getPaymentModeOptionId().toString().equals(payModeOptionId)).collect(Collectors.toList());
                            if (!filteredPayOps.isEmpty()) {
                                cacheTarget.setTargetPaymentModeOptions(filteredPayOps);
                                cacheTargetPayModeAndOptions1 = cacheTarget;
                                break;
                            }
                        } else {
                            logger.warn("Payment mode: {}, has ELAPSED... Hence skipping", cacheTarget.getTargetPaymentMode());
                        }
                    }
                }
            }
        return cacheTargetPayModeAndOptions1;
    }

    @Override
    public Set<CacheTargetPaymentModeAndOptions> getTargetPayModeAndOptionsDataList(String entityId, String payModeId, String payModeOptionId) {
        Set<CacheTargetPaymentModeAndOptions> cacheTargetPaymentModeAndOptions = getAllTargetPayModeAndOptionsData(entityId);
        cacheTargetPaymentModeAndOptions = cacheTargetPaymentModeAndOptions.stream().filter(cacheTargetPay->cacheTargetPay.getTargetPaymentMode().getEntityId().equals(entityId)).collect(Collectors.toSet());
        Set<CacheTargetPaymentModeAndOptions> cacheTgtPayModeAndOptions = new HashSet<>();
        if (cacheTargetPaymentModeAndOptions != null)
            for (CacheTargetPaymentModeAndOptions cacheTarget : cacheTargetPaymentModeAndOptions) {
                if (cacheTarget.getTargetPaymentMode().getPaymentModeId().toString().equals(payModeId)) {
                    if (isDateInBetweenEndPoints(cacheTarget.getTargetPaymentMode().getStartDate(),
                            cacheTarget.getTargetPaymentMode().getEndDate(), OffsetDateTime.now())) {
                        List<TargetPaymentModeOptionsModel> filteredPayOps = cacheTarget.getTargetPaymentModeOptions().stream()
                                .filter(cacheTargetOps -> isDateInBetweenEndPoints(cacheTargetOps.getStartDate(), cacheTargetOps.getEndDate(), OffsetDateTime.now()))
                                .collect(Collectors.toList());
                        filteredPayOps = filteredPayOps.stream().filter(targetPayModeOption -> targetPayModeOption.getPaymentModeOptionId().toString().equals(payModeOptionId)).collect(Collectors.toList());
                        if (!filteredPayOps.isEmpty()) {
                            cacheTarget.setTargetPaymentModeOptions(filteredPayOps);
                            cacheTgtPayModeAndOptions.add(cacheTarget);
                        }else if(StringUtils.isBlank(payModeOptionId)){
                            cacheTgtPayModeAndOptions.add(cacheTarget);
                        }
                    } else {
                        logger.warn("Payment mode: {}, has ELAPSED... Hence skipping", cacheTarget.getTargetPaymentMode());
                    }
                }
            }
        return cacheTgtPayModeAndOptions;
    }


    @Override
    public int removeTargetPayMode(String entityId, String targetId, String payModeId) {
        int flag = 0;
        Set<CacheTargetPaymentModeAndOptions> cacheTargetPaymentModeAndOptions = getAllTargetPayModeAndOptionsData(entityId);
        CacheTargetPaymentModeAndOptions cacheTargetPayModeAndOptions1 = null;
        if (!cacheTargetPaymentModeAndOptions.isEmpty())
            for (CacheTargetPaymentModeAndOptions cacheTarget : cacheTargetPaymentModeAndOptions) {
                if (cacheTarget.getTargetPaymentMode().getTargetId().toString().equals(targetId) && cacheTarget.getTargetPaymentMode().getPaymentModeId().toString().equals(payModeId)) {
                    cacheTargetPaymentModeAndOptions.remove(cacheTarget);
                    setTargetPayModeAndOptionsData(entityId, cacheTargetPaymentModeAndOptions);
                    flag = 1;
                    break;
                }
            }
        return flag;
    }

    @Override
    public int removeTargetPayModeOption(String entityId, String targetId, String payModeId) {
        int flag = 0;
        Set<CacheTargetPaymentModeAndOptions> cacheTargetPaymentModeAndOptions = getAllTargetPayModeAndOptionsData(entityId);
        CacheTargetPaymentModeAndOptions cacheTargetPayModeAndOptions1 = null;
        if (!cacheTargetPaymentModeAndOptions.isEmpty())
            for (CacheTargetPaymentModeAndOptions cacheTarget : cacheTargetPaymentModeAndOptions) {
                if (cacheTarget.getTargetPaymentMode().getTargetId().toString().equals(targetId) && cacheTarget.getTargetPaymentMode().getPaymentModeId().toString().equals(payModeId)) {
                    List<TargetPaymentModeOptionsModel> targetPaymentModeOptionsList = cacheTarget.getTargetPaymentModeOptions();
                    for (TargetPaymentModeOptionsModel model : targetPaymentModeOptionsList) {
                        if (model.getTargetPaymentModeId().toString().equals(payModeId)) {
                            targetPaymentModeOptionsList.remove(model);
                            flag = 1;
                            break;
                        }
                    }
                    break;
                }
            }
        return flag;
    }

    /**
     * MERCHANT PAYMENT MODES AND OPTIONS
     */

    @Override
    public List<CacheMerchantPaymentModeAndOptions> getMerchantPayModeAndOptionsData(String entityId, String mid) {
        logger.info("Getting Merchant Payment Mode And Options model info by key: {}", MERCHANT_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId);
        List<CacheMerchantPaymentModeAndOptions> merchantPaymentModeAndOptions = null;
        try {
            Cache cache = cacheManager.getCache(CacheConstants.MERCHANT_PAY_MODE_AND_OPTIONS_CACHE);
            merchantPaymentModeAndOptions = cache.get(MERCHANT_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId + KEY_SEPERATE + mid) != null ?
                    (ArrayList) cache.get(MERCHANT_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId + KEY_SEPERATE + mid).get() : null;
            logger.info("Merchant Payment Mode And Options model data from cache: {}", merchantPaymentModeAndOptions != null ? merchantPaymentModeAndOptions.size() : null);
        } catch (Exception e) {
            logger.info("An error occurred while getting the Merchant Payment Mode And Options model from cache", e);
            return null;
        }
        return merchantPaymentModeAndOptions;
    }

    @Override
    public Boolean putMerchantPayModeAndOptionsData(String entityId, String mid, List<CacheMerchantPaymentModeAndOptions> cacheMerPayModeAndOpsList) {
        try {
            Cache cache = cacheManager.getCache(CacheConstants.MERCHANT_PAY_MODE_AND_OPTIONS_CACHE);
            if (cacheMerPayModeAndOpsList != null) {
                cache.put(MERCHANT_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId + KEY_SEPERATE + mid, cacheMerPayModeAndOpsList);
            } else {
                logger.info("Merchant Payment Mode And Options are Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.info("An error occurred while push the Merchant Payment Mode And Options model into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public void removeMerchantPayModeAndOptionsData(String entityId,String mid) {
        try {
            Cache cache = cacheManager.getCache(MERCHANT_PAY_MODE_AND_OPTIONS_CACHE);
            if (entityId != null) {
                cache.evict(MERCHANT_PAY_MODE_AND_OPTIONS + KEY_SEPERATE + entityId + KEY_SEPERATE + mid);
            } else {
                logger.info("Target Payment Mode And Options are Null");
            }
        } catch (Exception e) {
            logger.info("An error occurred while delete the Target Payment Mode And Options model into cache", e);
        }
    }

    @Override
    public int removeMerchantPayMode(MerchantPaymentModesModel merchantPaymentModesModel, MerchantMasterModel merchantMasterModel) {
        int flag = 0;
        List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDataList = getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
        for (CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOption : merchantPayModeAndOptionsDataList) {
            MerchantPaymentModesModel merchantPaymentMode = cacheMerchantPaymentModeAndOption.getMerchantPaymentMode();
            if (merchantPaymentMode.getMerchantMasterId().toString().equals(merchantPaymentModesModel.getMerchantMasterId().toString())
                    && merchantPaymentMode.getPaymentModeId().toString().equals(merchantPaymentModesModel.getPaymentModeId().toString())) {
                cacheMerchantPaymentModeAndOption.getMerchantPaymentMode().setStatus(ActiveInactiveFlag.Inactive.name());
                merchantPayModeAndOptionsDataList.remove(cacheMerchantPaymentModeAndOption);
                putMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid(), merchantPayModeAndOptionsDataList);
                flag = 1;
                break;
            }
        }
        return flag;
    }

    @Override
    public int removeMerchantPayModeOption(String entityId, String mid, MerchantPaymentModesModel merchantPaymentModesModel, MerchantPaymentModeOptionsModel merchantPaymentModeOptionsModel) {
        int flag = 0;
        List<CacheMerchantPaymentModeAndOptions> paymentModeAndOptions = getMerchantPayModeAndOptionsData(entityId,mid);
        CacheMerchantPaymentModeAndOptions cacheTargetPaymentModeAndOptions = null;
        if (!paymentModeAndOptions.isEmpty())
            for (CacheMerchantPaymentModeAndOptions cacheMerchant : paymentModeAndOptions) {
                if (cacheMerchant.getMerchantPaymentMode().getPaymentModeId().toString().equals(merchantPaymentModesModel.getPaymentModeId().toString())
                        && cacheMerchant.getMerchantPaymentMode().getMerchantMasterId().toString().equals(merchantPaymentModesModel.getMerchantMasterId().toString())
                ) {
                    List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptions = cacheMerchant.getMerchantPaymentModeOptions();
                    for (MerchantPaymentModeOptionsModel model : merchantPaymentModeOptions) {
                        if (model.getPaymentModeOptionId().toString().equals(merchantPaymentModeOptionsModel.getPaymentModeOptionId().toString())) {
                            merchantPaymentModeOptions.remove(model);
                            flag = 1;
                            break;
                        }
                    }
                    break;
                }
            }
        return flag;
    }

    /**
     *TARGET MERCHANT MASTER
     */

    @Override
    public Boolean putTargetMerchantMasterModel(String targetId,String mid ,String tid, CacheTargetMerchantMaster cacheTargetMerchantMaster) {
        try {
            String key = constructTargetMerMasterKey(targetId, mid, tid);
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_MERCHANT_MASTER_CACHE);
            if (cacheTargetMerchantMaster != null && key != null) {
                cache.put(key, cacheTargetMerchantMaster);
            } else {
                logger.info("Cache Target Merchant Master is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            logger.error("An error occurred while push the Target Merchant Master into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }


    @Override
    public CacheTargetMerchantMaster getTargetMerchantMasterModel(String targetId,String mid ,String tid) {
        CacheTargetMerchantMaster cacheTargetMerchantMaster = null;
        try {
            String key = constructTargetMerMasterKey(targetId, mid, tid);
            logger.info("Getting Cache target merchant master model info by key: {}", key);
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_MERCHANT_MASTER_CACHE);
            cacheTargetMerchantMaster =  cache.get(key) != null ? (CacheTargetMerchantMaster)cache.get(key).get() : null;
            logger.info("Cache target merchant master data from cache: {}", cacheTargetMerchantMaster);
        } catch (CacheException e) {
            logger.error("An error occurred while getting the target merchant master from cache", e);
        }
        return cacheTargetMerchantMaster;
    }

    @Override
    public Boolean removeTargetMerchantMasterData(String targetId, String mid, String tid) {
        try {
            String key = constructTargetMerMasterKey(targetId, mid, tid);
            Cache cache = cacheManager.getCache(CacheConstants.TARGET_MERCHANT_MASTER_CACHE);
            if (key != null) {
                boolean isEvict = cache.evictIfPresent(key);
                if (isEvict) {
                    return Boolean.TRUE;
                } else {
                    return Boolean.FALSE;
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred while push the Target Merchant Master into cache", e);
            return Boolean.FALSE;
        }
        return Boolean.FALSE;
    }


    private String constructTargetMerMasterKey(String targetId,String mid ,String tid){
        return targetId + KEY_SEPERATE + mid + KEY_SEPERATE + tid;
    }

    public static boolean isDateInBetweenEndPoints(OffsetDateTime min, OffsetDateTime max, OffsetDateTime date) {
        if (min == null || max == null)
            return true;
        return !(date.isBefore(min) || date.isAfter(max));
    }
}
