package com.isg.mw.cache.mgmt.config;

import com.isg.bms.commonModels.BillPayTransactionDetails;
import com.isg.bms.commonModels.BmsTxnDataModel;
import com.isg.bms.constant.BmsSwitchConstant;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.constants.DbMessageType;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.scheduling.annotation.Async;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import static com.isg.mw.cache.mgmt.config.CacheConstants.*;

@Configuration
public class CacheUtil {

    private final Logger logger = LogManager.getLogger();

    /**
     * Key - enid::srcid::info
     * Value - SourceInfo
     */

    private final HashOperations<String, String, SourceInfo> sourceInfoHashOps;

    /**
     * Key - enid::srcid::targets
     * Value - Map
     * Key -> pg1, Value -> {60%, 50%, 0.1}
     * Key -> pg2, Value -> 70, DistributingPer, least cost
     * <p>
     * Key - enid:srcid2::targets
     * Value - Map
     * Key -> pg1, Value -> {60%, 50%, 0.1}
     * Key -> pg2, Value -> 70, DistributingPer, least cost
     */

    private final HashOperations<String, TargetKey, TargetInfo> targetDataHashOps;

    private final HashOperations<String, TargetLcrKey, Set<TargetLcrValue>> targetLcrHashOps;

    private final RedisTemplate<String, Map<TargetLcrKey, Set<TargetLcrValue>>> targetLcrInfoCache;

    private final ValueOperations<String, MerchOrdTxnData> txnDataMap;

    private final ValueOperations<String, MerchantPreferredTarget> merchantPreferredTarget;

    private final RedisTemplate<String, MerchantPreferredTarget> merchantPrefTarget;


    private final RedisTemplate<String, String> seqNoRedisTemp;

    private final ValueOperations<String, String> seqNoValueOps;

    private final ValueOperations<String, TransactionMessageModel> txnMsgModelValueOps;

    private final HashOperations<String, String, EFTPOSKeyModel> eftposkeys;

    private final RedisTemplate<String, String> activeTargetId;

    private final ValueOperations<String, String> activeTargetIdValueOps;

    /**
     * Key - Target Id, Value - (True/False) i.e. Current Target  for Static route
     */
    @Setter
    @Getter
    private Map<String, OffsetDateTime> localSourceCalculationTime;

    @Autowired
    private CacheHelper cacheHelper;

    private final ValueOperations<String, BillPayTransactionDetails> billPayTransaction;

    private final RedisTemplate<String, BillPayTransactionDetails> billPayTransactionTemp;

    private final ValueOperations<String, BmsTxnDataModel> bmsTxnDataModelValueOperations;

    private final RedisTemplate<String, BmsTxnDataModel> txnDataModelRedisTemplate;

    private final RedisTemplate<String, Object> bmsTxnModelStrRedisTemplate;

    private final RedisTemplate<String, String> billNoRedisTemplate;

    private ValueOperations<String, List<String>> billNoRedisTemplateOps;

    @Autowired
    public CacheUtil(RedisTemplate<String, SourceInfo> sourceInfoCache,
                     RedisTemplate<String, Map<TargetKey, TargetInfo>> targetDataCache,
                     RedisTemplate<String, Map<TargetLcrKey, Set<TargetLcrValue>>> targetLcrInfoCache,
                     RedisTemplate<String, MerchOrdTxnData> txnData,
                     RedisTemplate<String, MerchantPreferredTarget> merchantPrefTarget,
                     RedisTemplate<String, EFTPOSKeyModel>  eftPosKeyModel,
                     RedisTemplate<String,String> seqNoRedisTemp,
                     RedisTemplate<String, TransactionMessageModel> txnMsgModelRedisTemp,
                     RedisTemplate<String,String> activeTargetId,
                     RedisTemplate<String, BillPayTransactionDetails> billPayTransactionTemp,
                     RedisTemplate<String, BmsTxnDataModel> txnDataModelRedisTemplate,
                     RedisTemplate<String, Object> bmsTxnModelStrRedisTemplate,
                     RedisTemplate<String, String> billNoRedisTemplate,
                     RedisTemplate<String, List<String>> billNoOpsRedisTemplate) {
        this.sourceInfoHashOps = sourceInfoCache.opsForHash();
        this.targetDataHashOps = targetDataCache.opsForHash();
        //this.targetMerchantMasterList = targetMerchantMasterList;
        this.localSourceCalculationTime = new ConcurrentHashMap<>();
        this.targetLcrHashOps = targetLcrInfoCache.opsForHash();
        this.targetLcrInfoCache = targetLcrInfoCache;
        this.txnDataMap = txnData.opsForValue();
        this.merchantPrefTarget = merchantPrefTarget;
        this.merchantPreferredTarget = merchantPrefTarget.opsForValue();
        this.eftposkeys = eftPosKeyModel.opsForHash();
        this.seqNoRedisTemp = seqNoRedisTemp;
        this.seqNoValueOps = seqNoRedisTemp.opsForValue();
        this.txnMsgModelValueOps = txnMsgModelRedisTemp.opsForValue();
        this.activeTargetId = activeTargetId;
        this.activeTargetIdValueOps = activeTargetId.opsForValue();
        this.billPayTransactionTemp = billPayTransactionTemp;
        this.billPayTransaction = billPayTransactionTemp.opsForValue();
        this.txnDataModelRedisTemplate = txnDataModelRedisTemplate;
        this.bmsTxnDataModelValueOperations = txnDataModelRedisTemplate.opsForValue();
        this.bmsTxnModelStrRedisTemplate = bmsTxnModelStrRedisTemplate;
        this.billNoRedisTemplate = billNoRedisTemplate;
        this.billNoRedisTemplateOps = billNoOpsRedisTemplate.opsForValue();
    }

    public void putSourceData(String sourceCacheMapKey, String sourceKey, SourceInfo sourceInfo) {
        sourceInfoHashOps.put(sourceCacheMapKey, sourceKey, sourceInfo);
    }

    public Map<String, SourceInfo> getSourceData(String key) {
        return sourceInfoHashOps.entries(key);
    }

    @Async
    public void putTargetData(String targetCacheMapKey, TargetKey targetKey, TargetInfo targetInfo) {
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Updated target {}, Info: {}", targetInfo.getTargetName(), targetInfo);
    }

    public Map<TargetKey, TargetInfo> getTargetData(String key) {
        return targetDataHashOps.entries(key);
    }

    public void deleteSourceCacheMap(String sourceCacheMapKey, String sourceKey) {
        sourceInfoHashOps.delete(sourceCacheMapKey, sourceKey);
    }

    public void deleteTargetCacheMap(String targetCacheMapKey, TargetKey targetKey) {
        targetDataHashOps.delete(targetCacheMapKey, targetKey);
    }

    @Async
    public void incrementSourceTotalTxnCount(String sourceCacheMapKey, String sourceKey) {
        SourceInfo sourceInfo = sourceInfoHashOps.get(sourceCacheMapKey, sourceKey);
        sourceInfo.setTotalTxnCount(sourceInfo.getTotalTxnCount() + 1);
        sourceInfoHashOps.put(sourceCacheMapKey, sourceKey, sourceInfo);
        logger.trace("Incremented Source Total Txn Count {}, Info: {}", sourceKey, sourceInfo);
    }

    public int getSourceTotalTxnCount(String sourceCacheMapKey, String sourceKey) {
        SourceInfo sourceInfo = sourceInfoHashOps.get(sourceCacheMapKey, sourceKey);
        return sourceInfo.getTotalTxnCount();
    }

    @Async
    public void updateSourceLastCalculationDate(String sourceMapKey, String srcId, OffsetDateTime calculationDate) {
        Map<String, SourceInfo> sourceData = getSourceData(sourceMapKey);
        SourceInfo sourceInfo = sourceData.get(srcId);
        sourceInfo.setLastCalculatedDate(calculationDate);
        sourceInfoHashOps.put(sourceMapKey, srcId, sourceInfo);
        logger.trace("Updated last calculated date for source: {}, Info: {}", srcId,
                sourceInfo.getLastCalculatedDate());
    }

    public OffsetDateTime getSourceLastCalculationDate(SourceConfigModel sourceConfigModel) {
        Map<String, SourceInfo> sourceData = getSourceData(cacheHelper.getSourceMapKey(sourceConfigModel));
        SourceInfo sourceInfo = sourceData.get(sourceConfigModel.getId().toString());
        logger.trace("Fetching last calculated date for source: {}, Info: {}", sourceConfigModel.getName(),
                sourceInfo.getLastCalculatedDate());
        return sourceInfo.getLastCalculatedDate();
    }

    @Async
    public void incrementTargetTotalTxnCount(String targetCacheMapKey, TargetKey targetKey) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.setTotalTxnCount(targetInfo.getTotalTxnCount() + 1);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Incremented Target Total Txn Count: {}, Info: {}", targetInfo.getTargetName(), targetInfo.getTotalTxnCount());
    }

    @Async
    public void incrementTargetTotalFailedTxnCount(String targetCacheMapKey, TargetKey targetKey) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.setTotalTxnFailed(targetInfo.getTotalTxnFailed() + 1);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Incremented Target Total Failed Txn Count: {}, Info: {}", targetInfo.getTargetName(), targetInfo.getTotalTxnFailed());
    }

    @Async
    public void updateCurrentTarget(String targetCacheMapKey, TargetKey targetKey, Boolean currentTarget) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.getStaticTargetInfo().setCurrentTarget(currentTarget);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Updated Current Target: {}, Info: {}", targetInfo.getTargetName(), currentTarget);
    }

    @Async
    public void updateTargetIsAlive(String targetCacheMapKey, TargetKey targetKey, Boolean isAlive) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.setAlive(isAlive);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Updated Target Is Alive: {}, Info: {}", targetInfo.getTargetName(), isAlive);
    }

    @Async
    public void updateTargetCurrentRoutingPer(String targetCacheMapKey, TargetKey targetKey, Double curRoutePer) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.getDynamicTargetInfo().setCurrentRoutingPercent(curRoutePer);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Updated Target Current Routing Percent: {}, Info: {}", targetInfo.getTargetName(), curRoutePer);
    }

    public Double getTargetCurrentRoutingPer(String targetCacheMapKey, TargetKey targetKey) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        Double currentRoutingPercent = targetInfo.getDynamicTargetInfo().getCurrentRoutingPercent();
        logger.trace("Fetching Current Routing Percent: {}, Info: {}", targetInfo.getTargetName(), currentRoutingPercent);
        return currentRoutingPercent;
    }

    @Async
    public void updateTargetInitialRoutingPer(String targetCacheMapKey, TargetKey targetKey, Double prevRoutePer) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.getDynamicTargetInfo().setInitialRoutingPercent(prevRoutePer);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Updated Target Previous Routing Percent: {}, Info: {}", targetInfo.getTargetName(), prevRoutePer);
    }

    @Async
    public void updateTargetTrendIndicator(String targetCacheMapKey, TargetKey targetKey, TargetInfo.TrendIndicator trendIndicator) {
        TargetInfo targetInfo = targetDataHashOps.get(targetCacheMapKey, targetKey);
        targetInfo.getDynamicTargetInfo().setRpTrendIndicator(trendIndicator);
        targetDataHashOps.put(targetCacheMapKey, targetKey, targetInfo);
        logger.trace("Updated Target Trend Indicator: {}, Info: {}", targetInfo.getTargetName(), trendIndicator);
    }

    //Target LCR methods start
    public void putTargetLcrData(String entityId, TargetLcrKey targetLcrKey, Set<TargetLcrValue> targetLcrValue) {
        targetLcrHashOps.put(TARGET_LCR + KEY_SEPERATE + entityId, targetLcrKey, targetLcrValue);
    }

    public Map<TargetLcrKey, Set<TargetLcrValue>> getTargetLCRData(String entityId) {
        return targetLcrHashOps.entries(TARGET_LCR + KEY_SEPERATE + entityId);
    }

    public Long removeTargetLCRData(String entityId, TargetLcrKey targetLcrKey) {
        return targetLcrHashOps.delete(TARGET_LCR + KEY_SEPERATE + entityId, targetLcrKey);
    }

    public void clearTargetLcrData(String entityId) {
        targetLcrInfoCache.delete(TARGET_LCR + KEY_SEPERATE + entityId);
    }


    public void putTxnData(String entityId, String mid, String orderId, MerchOrdTxnData merchOrdTxnData) {
        this.txnDataMap.set(SM_ENTITYID + entityId + KEY_SEPERATE + mid + KEY_SEPERATE + orderId, merchOrdTxnData);
    }

    public MerchOrdTxnData getTxnData(String entityId, String mid, String orderId) {
        return this.txnDataMap.get(SM_ENTITYID + entityId + KEY_SEPERATE + mid + KEY_SEPERATE + orderId);
    }

    public static boolean isDateInBetweenEndPoints(OffsetDateTime min, OffsetDateTime max, OffsetDateTime date) {
        if (min == null || max == null)
            return true;
        return !(date.isBefore(min) || date.isAfter(max));
    }

    /**
     * Merchant Target Preferences
     * KEY: (entityId + mid + payModeId)
     * VALUE: MerchantPreferredTarget : (targetid, startDate, endDate)
     */
    public void putMerchantPreferredTargetData(String entityId, String mid, String paymentModeId, MerchantPreferredTarget merchantPreferredTarget) {
        this.merchantPreferredTarget.set(entityId + KEY_SEPERATE + mid + KEY_SEPERATE + paymentModeId, merchantPreferredTarget);
    }

    public MerchantPreferredTarget getMerchantPreferredTargetData(String entityId, String mid, String paymentModeId) {
        MerchantPreferredTarget merchantPreTargetData = this.merchantPreferredTarget.get(entityId + KEY_SEPERATE + mid + KEY_SEPERATE + paymentModeId);
        if (merchantPreTargetData != null && isDateInBetweenEndPoints(merchantPreTargetData.getStartDate(), merchantPreTargetData.getEndDate(), OffsetDateTime.now())) {
            return merchantPreTargetData;
        }
        return null;
    }

    public boolean removeMerchantPreferredTargetDataData(String entityId, String mid, String paymentModeId) {
        return this.merchantPrefTarget.delete(entityId + KEY_SEPERATE + mid + KEY_SEPERATE + paymentModeId);
    }




    public MerchantPreferredTarget getMerchantPreferredTarget(String entityId, String mid, String paymentModeId) {
        MerchantPreferredTarget merchantPreTargetData = this.merchantPreferredTarget.get(entityId + KEY_SEPERATE + mid + KEY_SEPERATE + paymentModeId);
        if (merchantPreTargetData != null) {
            return merchantPreTargetData;
        }
        return null;
    }


    //EFT POS Key methods start
    public void putEftposKeys(String key, String keySetId, EFTPOSKeyModel eftposKeyModel) {
        this.eftposkeys.put(key, keySetId, eftposKeyModel);
    }

    public Map<String, EFTPOSKeyModel> getEftposKeys(String key) {
        return this.eftposkeys.entries(key);
    }
    //EFT POS Key methods end

    public void putEftposTrxnCount(String keyName, String targetName, EFTPOSKeyModel eftposKeyModel) {
        this.eftposkeys.put(keyName, targetName, eftposKeyModel);
    }
    //EFT POS Key methods end

    public void putSeqNo(String key, String value) {
        this.seqNoValueOps.set(key, value);
    }

    public String getSeqNo(String key) {
        return this.seqNoValueOps.get(key);
    }

    public void putTxnMsgModel(DbMessageType dbMessageType, DbMessageType dbMessageTypeId, TransactionMessageModel value) {
        if (dbMessageType != null && dbMessageTypeId != null && !txnLogNotRequired.contains(value.getTransactionName())) {
            value.setDbMessageType(dbMessageType);
            value.setDbMessageTypeId(dbMessageTypeId);
            this.txnMsgModelValueOps.set(SM_ENTITYID + dbMessageTypeId.name() + KEY_SEPERATE + value.getTransactionId(), value);
        }
    }

    public TransactionMessageModel getTxnMsgModel(DbMessageType dbMessageTypeId, String transactionId) {
        return this.txnMsgModelValueOps.get(SM_ENTITYID + dbMessageTypeId.name() + KEY_SEPERATE + transactionId);
    }
    public TransactionMessageModel deleteTxnMsgModel(DbMessageType dbMessageTypeId,String transactionId) {
        return this.txnMsgModelValueOps.getAndDelete(SM_ENTITYID + dbMessageTypeId.name() + KEY_SEPERATE + transactionId);
    }

    private static final Set<String> txnLogNotRequired = new HashSet<String>() {{
        add("verify.vpa.request");
        add("verify.vpa.response");
    }};

    public void putActiveTargetId(String key, String value) {
        this.activeTargetIdValueOps.set(key, value);
    }

    public String getActiveTargetId(String key) {
        return this.activeTargetIdValueOps.get(key);
    }

    public void deleteActiveTargetId(String value) {
        activeTargetId.delete(value);
    }



    //BMS

    public void saveBillPayTransaction(String txnId, BillPayTransactionDetails billPayTxnDetails) {
        logger.trace("Entry in saveBillPayTransaction for txn id::::{} with data::::{}", txnId, billPayTxnDetails.toString());
        this.billPayTransaction.set(txnId, billPayTxnDetails, Duration.ofMillis((long) 15*60*1000));
    }

    public BillPayTransactionDetails getBillPayTransaction(String txnId) {
        logger.trace("Entry in getBillPayTransaction for txnId:::"+txnId);
        BillPayTransactionDetails details = this.billPayTransaction.get(txnId);
        logger.trace("Exit from getBillPayTransaction for txnId:::"+txnId);
        return details;
    }

    public boolean updateBillPayTransaction(String txnId, BillPayTransactionDetails billPayTransactionDetails) {
        logger.trace("Entry in updateBillPayTransaction for txn id:::"+txnId+" with data::"+billPayTransactionDetails.toString());
        Long expiry = this.billPayTransactionTemp.getExpire(txnId, TimeUnit.MILLISECONDS);
        boolean result = this.billPayTransaction.setIfPresent(txnId,billPayTransactionDetails,Duration.ofMillis(expiry));
        logger.trace("Exit from updateBillPayTransaction for txn id:::"+txnId);
        return result;
    }

    public void deleteBillPayTransaction(String txnId) {
        this.billPayTransactionTemp.delete(txnId);
    }


    public void putBmsTxnData(String key, BmsTxnDataModel bmsTxnDataModel) {
        this.bmsTxnDataModelValueOperations.set(key, bmsTxnDataModel);
    }

    public BmsTxnDataModel getBmsTxnData(String key) {
        BmsTxnDataModel data = this.bmsTxnDataModelValueOperations.get(key);
        return data;
    }

    public String getBmsTxnDataKey(String refId,String billerId) {
        return "BBPS" + BmsSwitchConstant.KEY_SEPARATOR +billerId + BmsSwitchConstant.KEY_SEPARATOR + refId;
    }

    public List<BmsTxnDataModel> getAllBmsTxnModelData(String billerId) {
        List<BmsTxnDataModel> transactionModels = new ArrayList<>();
        try {
            String key = "*" + "BBPS" + BmsSwitchConstant.KEY_SEPARATOR + billerId + BmsSwitchConstant.KEY_SEPARATOR + "*";
            Set<String> txnKeys = bmsTxnModelStrRedisTemplate.keys(key);
            for (String keyIs : txnKeys) {
                int index = keyIs.indexOf("BBPS");
                String id = null;
                if (index != -1) {
                    id = keyIs.substring(index);
                }
                BmsTxnDataModel bmsTxnDataModel = bmsTxnDataModelValueOperations.get(id);
                if (bmsTxnDataModel != null) {
                    transactionModels.add(bmsTxnDataModel);
                }
            }
        } catch (Exception e) {
            logger.info("Exception while fetching redis data by partial key : {}", e.getMessage());
        }
        return  transactionModels;
    }

    public void putByBillNoData(String key, List<String> listOfRefId) {
        this.billNoRedisTemplateOps.set(key, listOfRefId, Duration.ofMillis((long) 15*60*1000));
    }

    public List<String> getByBillNoData(String key) {
        List<String> data = this.billNoRedisTemplateOps.get(key);
        return data;
    }

    public String getByBillNoKey(String billNo,String billerId) {
        return "BMS" + BmsSwitchConstant.KEY_SEPARATOR +billerId + BmsSwitchConstant.KEY_SEPARATOR + billNo;
    }
}
