package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.BinInfoService;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.utils.MaskingUtility;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Bin Info Service Implementation.
 *
 * @author akshay3978
 */
@Service
@EnableCaching
public class BinInfoServiceImpl implements BinInfoService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Getter
    private static final Map<BinInfoModel, BinInfoModel> binCacheMap = new ConcurrentHashMap<>();

    @Autowired
    private InitRestClient initRestClient;

    @Value("${bin.fetch.flag}")
    private String binFetchFlag;

    /**
     * Update BinInfo Object in Cache.
     *
     * @return boolean
     */
    @Override
    public Boolean updateBinInfo(BinInfoModel model) {
        try {
            if (model != null) {
                BinInfoModel valueBin = getBinInfoModel(model);
                BinInfoModel key = constructKey(model);
                if (ActiveFlag.N.equals(valueBin.getActiveFlag())) {
                    LOG.trace("BIN {} is now inactive, hence can be evicted", valueBin);
                    BinInfoModel removedBin = binCacheMap.remove(key);
                    if (removedBin != null)
                        LOG.trace("BIN {} Evicted Successfully...", removedBin);
                    else
                        LOG.trace("BIN {} is inactive, hence not added in cache", model);
                } else {
                    binCacheMap.put(key, valueBin);
                    LOG.trace("BIN {} Inserted/Updated Successfully...", model);
                }
            } else {
                LOG.info("BinInfoModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    private BinInfoModel getBinInfoModel(BinInfoModel model) {
        BinInfoModel valueBinInfoModel = new BinInfoModel();
        valueBinInfoModel.setBinHigh(model.getBinHigh());
        valueBinInfoModel.setBinNumber(model.getBinNumber());
        valueBinInfoModel.setBinLow(model.getBinLow());
        valueBinInfoModel.setSchemeName(model.getSchemeName());
        valueBinInfoModel.setTargetId(model.getTargetId());
        valueBinInfoModel.setTargetName(model.getTargetName());
        valueBinInfoModel.setCardProgram(model.getCardProgram());
        valueBinInfoModel.setActiveFlag(model.getActiveFlag());
        valueBinInfoModel.setCardCategory(model.getCardCategory());
        valueBinInfoModel.setCardBrand(model.getCardBrand());
        valueBinInfoModel.setCountryCodeA(model.getCountryCodeA());
        valueBinInfoModel.setCountryCodeN(model.getCountryCodeN());
        
        return valueBinInfoModel;
    }

    /**
     * Get Bin Info from cache, based on cardNumber.
     *
     * @return BinInfoModel
     */
    @Override
    public BinInfoModel getBinInfoByCardNumber(String cardNumber) {
        LOG.info("Getting BinNumber in getBinInfoByCardNumber service {}", MaskingUtility.maskCardNumber(cardNumber));
        BinInfoModel binInfo = null;

        if (StringUtils.isEmpty(cardNumber)) {
            return binInfo;
        }

        if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            binInfo = fetchBinFromApi(cardNumber);
        } else if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            binInfo = fetchBinFromCache(cardNumber);
        }
        return binInfo;
    }

    private BinInfoModel fetchBinFromApi(String cardNumber) {
    	String binNum = cardNumber.substring(0, 9);
        LOG.trace("Fetching the BIN through API for card number {}", MaskingUtility.maskCardNumber(cardNumber));
        BinInfoModel bin = initRestClient.getBin(binNum);
        if (bin == null) {
            binNum = StringUtils.rightPad(cardNumber, 19, '0');
            bin = initRestClient.getBin(binNum);
        }
        return bin;
    }

    private BinInfoModel fetchBinFromCache(String cardNumber) {
        BinInfoModel binInfo = null;
        try {
            BigInteger binNum = new BigInteger(cardNumber.substring(0, 9));
            BinInfoModel binModel = new BinInfoModel();
            binModel.setBinNumber(binNum);
            binModel.setBinLow(binNum);
            binInfo = binCacheMap.get(binModel);

            if (binInfo == null) {
                binNum = new BigInteger(StringUtils.rightPad(cardNumber, 19, '0'));
                binModel.setBinNumber(binNum);
                binModel.setBinLow(binNum);
                binInfo = binCacheMap.get(binModel);
                if (binInfo == null) {
                	binInfo = fetchBinFromApi(cardNumber);
                	updateBinInfo(binInfo);
                }
            }

        } catch (Exception e) {
            LOG.error("An error occurred!", e);
        }
        return binInfo;
    }

    /**
     * This method constructs key.
     *
     * @param model BinInfoModel
     * @return key
     */
    private BinInfoModel constructKey(BinInfoModel model) {
        BinInfoModel keyBinInfoModel = new BinInfoModel();
        keyBinInfoModel.setBinHigh(model.getBinHigh());
        keyBinInfoModel.setBinLow(model.getBinLow());
        keyBinInfoModel.setBinNumber(model.getBinNumber());
        return keyBinInfoModel;
    }

}
