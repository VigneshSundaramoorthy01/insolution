package com.isg.mw.cache.mgmt.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Objects;
import java.util.Set;

@Setter
@Getter
@AllArgsConstructor
@ToString
public class UnifiedPaymentMode {
    private Long payModeId;
    private String payModeName;
    private Set<UnifiedPaymentModeOptions> payModeOptions;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UnifiedPaymentMode that = (UnifiedPaymentMode) o;
        return Objects.equals(payModeId, that.payModeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(payModeId);
    }
}
