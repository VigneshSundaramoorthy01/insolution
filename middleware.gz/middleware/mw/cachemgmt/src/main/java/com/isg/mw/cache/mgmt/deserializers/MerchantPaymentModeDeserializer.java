package com.isg.mw.cache.mgmt.deserializers;

import com.isg.mw.core.model.sr.MerchantPaymentModesMessage;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class MerchantPaymentModeDeserializer implements Deserializer<MerchantPaymentModesMessage> {




        private final Logger logger = LogManager.getLogger(getClass());

        @Override
        public MerchantPaymentModesMessage deserialize(String topic, byte[] data) {
            MerchantPaymentModesMessage merchantPaymentModesMessage = null;
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            ObjectInputStream ois;
            try {
                ois = new ObjectInputStream(bis);
                merchantPaymentModesMessage = (MerchantPaymentModesMessage) ois.readObject();
                ois.close();
            } catch (IOException e) {
                logger.error("Error while deserializing MerchantPaymentModesMessage object: {}", e);
            } catch (ClassNotFoundException e) {
                logger.error("Class in which the object to be deserialized not found: {}", e);
            }
            return merchantPaymentModesMessage;
        }



}
