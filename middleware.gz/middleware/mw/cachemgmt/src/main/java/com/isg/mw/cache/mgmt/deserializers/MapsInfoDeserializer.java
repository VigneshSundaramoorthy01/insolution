package com.isg.mw.cache.mgmt.deserializers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.maps.MapsInfoModel;

/**
 * Deserializer of MapsInfoModel.
 * 
 * @author akshay3978
 *
 */
public class MapsInfoDeserializer implements Deserializer<MapsInfoModel> {
	private final Logger logger = LogManager.getLogger(getClass());

	@Override
	public MapsInfoModel deserialize(String topic, byte[] data) {
		MapsInfoModel mapsInfoModel = null;
		ByteArrayInputStream bis = new ByteArrayInputStream(data);
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(bis);
			mapsInfoModel = (MapsInfoModel) ois.readObject();
			ois.close();
		} catch (IOException e) {
			logger.error("Error while deserializing MapsInfoModel object: {}", e);
		} catch (ClassNotFoundException e) {
			logger.error("Class in which the object to be deserialized not found: {}", e);
		}
		return mapsInfoModel;

	}

}
