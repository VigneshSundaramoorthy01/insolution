package com.isg.mw.cache.mgmt.service;

import org.springframework.http.ResponseEntity;

public interface HsmUtilityService {
	
	ResponseEntity<?> sendAndConnect(String encryptedCommand, String encodedKey);

}
