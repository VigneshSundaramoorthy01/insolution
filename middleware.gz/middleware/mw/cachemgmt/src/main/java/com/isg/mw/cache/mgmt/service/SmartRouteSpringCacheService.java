package com.isg.mw.cache.mgmt.service;

import com.isg.mw.cache.mgmt.config.CacheMerchantPaymentModeAndOptions;
import com.isg.mw.cache.mgmt.config.CacheTargetPaymentModeAndOptions;
import com.isg.mw.core.model.sr.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface SmartRouteSpringCacheService {

    /**
     * PAYMENT MODES
     */
    Boolean putPaymentModes(List<PaymentModesModel> paymentModesModels);

    PaymentModesModel getPaymentMode(Long key);


    /**
     * PAYMENT MODE OPTIONS
     *
     */
    Boolean putPaymentModeOptions(List<PaymentModeOptionsModel> paymentModeOptionsModels);

    PaymentModeOptionsModel getPaymentModeOption(Long key);

    List<PaymentModeOptionsModel> getAllPaymentModeOption();

    PaymentModeOptionsModel getPaymentModeOption(Long paymentModeId, String schemeType);

    /**
     * TARGET PAYMENT MODES AND OPTIONS
     */
    Boolean setTargetPayModeAndOptionsData(String entityId, Set<CacheTargetPaymentModeAndOptions> cacheTgtPayModeAndOpsList);

    Set<CacheTargetPaymentModeAndOptions> getAllTargetPayModeAndOptionsData(String entityId);

    Set<CacheTargetPaymentModeAndOptions> getTargetPayModeAndOptionsDataList(String entityId, String payModeId, String payModeOptionId);

    CacheTargetPaymentModeAndOptions getTargetPayModeAndOptionsData(String entityId, String targetId, String payModeId, String payModeOptionId);

    void removeTargetPayModeAndOptionsData(String entityId);

    CacheTargetPaymentModeAndOptions getTargetPayModeAndOptionsData(String entityId, String targetId, String payModeId);

    int removeTargetPayMode(String entityId, String targetId, String payModeId);

    int removeTargetPayModeOption(String entityId, String targetId, String payModeId);


    /**
     * MERCHANT PAYMENT MODES AND OPTIONS
     */
    List<CacheMerchantPaymentModeAndOptions> getMerchantPayModeAndOptionsData(String entityId, String mid);

    Boolean putMerchantPayModeAndOptionsData(String entityId, String mid, List<CacheMerchantPaymentModeAndOptions> cacheMerPayModeAndOpsList);

    void removeMerchantPayModeAndOptionsData(String entityId,String mid);

    int removeMerchantPayMode(MerchantPaymentModesModel merchantPaymentModesModel, MerchantMasterModel merchantMasterModel);

    int removeMerchantPayModeOption(String entityId, String mid, MerchantPaymentModesModel merchantPaymentModesModel, MerchantPaymentModeOptionsModel merchantPaymentModeOptionsModel);


    /**
     * TARGET MERCHANT MASTER
     */
    Boolean putTargetMerchantMasterModel(String targetId,String mid ,String tid, CacheTargetMerchantMaster cacheTargetMerchantMasterModel);

    CacheTargetMerchantMaster getTargetMerchantMasterModel(String targetId,String mid ,String tid);

    Boolean removeTargetMerchantMasterData(String targetId,String mid ,String tid);

}
