package com.isg.mw.cache.mgmt.config;

/**
 * All Cache constants defined here
 *
 * @author sudharshan
 */
public interface CacheConstants {

    String KEY_SEPERATE = "::";
    String MAPS_INFO_CACHE = "mapsInfoCache";
    String BIN_INFO_CACHE = "binInfoCache";

    String BIN_FETCH_CACHE = "cache";
    String BIN_FETCH_API = "api";

    String PAYMENT_MODES = "PAYMENT_MODES";

    String TARGET_LCR = "TARGET_LCR";

    String PAYMENT_MODE_OPTIONS = "PAYMENT_MODE_OPTIONS";

    String TARGET_PAY_MODE_AND_OPTIONS = "TARGET_PAY_MODE_AND_OPTIONS";

    String MERCHANT_PAY_MODE_AND_OPTIONS = "MERCHANT_PAY_MODE_AND_OPTIONS";

    String MERCHANT_MASTER_CACHE = "merchantMasterCache";

    String SM_ENTITYID = "SM_";

    String EFTPOS_HSM_KEY = "EFTPOS_HSM_KEY";

    String PAYMENT_MODES_CACHE = "paymentModesCache";

    String PAYMENT_MODE_OPTIONS_CACHE = "paymentModeOptionsCache";

    String TARGET_MERCHANT_MASTER_CACHE = "targetMerchantMasterCache";

    String TARGET_PAY_MODE_AND_OPTIONS_CACHE = "targetPaymentModeAndOptionsCache";

    String MERCHANT_PAY_MODE_AND_OPTIONS_CACHE = "merchantPaymentModeAndOptionsCache";
}
