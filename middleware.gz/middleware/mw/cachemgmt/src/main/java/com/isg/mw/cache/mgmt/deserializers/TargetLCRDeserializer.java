package com.isg.mw.cache.mgmt.deserializers;

import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.sr.TargetLCRConfigMessage;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TargetLCRDeserializer implements Deserializer<TargetLCRConfigMessage> {

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public TargetLCRConfigMessage deserialize(String topic, byte[] data) {
        TargetLCRConfigMessage targetLCRConfigMessage = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            targetLCRConfigMessage = (TargetLCRConfigMessage) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing TargetLCRConfigMessage object: {}", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class in which the object to be deserialized not found: {}", e);
        }
        return targetLCRConfigMessage;

    }
}
