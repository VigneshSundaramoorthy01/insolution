package com.isg.mw.cache.mgmt.serializers;

import com.isg.mw.core.model.upi.Notification;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class NotificationSerializer implements Serializer<Notification> {

    private final Logger LOG = LoggerFactory.getLogger(NotificationSerializer.class);
    @Override
    public byte[] serialize(String topic, Notification data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos;
        try {
            oos = new ObjectOutputStream(bos);
            oos.writeObject(data);
            oos.flush();
        } catch (IOException e) {
            LOG.error("Error while serializing object: {}", e);
        }
        return bos.toByteArray();
    }
}
