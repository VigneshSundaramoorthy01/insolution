package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.service.TargetPaymentModeOptionService;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@EnableCaching
public class TargetPaymentModeOptionServiceImpl implements TargetPaymentModeOptionService {

    private final Logger LOG = LogManager.getLogger(getClass());

    private TargetPaymentModeOptionsModel getTargetPaymentModeOptionsInfoModel(TargetPaymentModeOptionsModel model) {
        TargetPaymentModeOptionsModel valueTargetPaymentModeOptionsInfoModel = new TargetPaymentModeOptionsModel();
        valueTargetPaymentModeOptionsInfoModel.setTargetPaymentModeId(model.getTargetPaymentModeId());
        valueTargetPaymentModeOptionsInfoModel.setPaymentModeOptionId(model.getPaymentModeOptionId());
        valueTargetPaymentModeOptionsInfoModel.setTargetPayModeOptionId(model.getTargetPayModeOptionId());
        valueTargetPaymentModeOptionsInfoModel.setStatus(model.getStatus());
        valueTargetPaymentModeOptionsInfoModel.setStartDate(model.getStartDate());
        valueTargetPaymentModeOptionsInfoModel.setEndDate(model.getEndDate());
        return valueTargetPaymentModeOptionsInfoModel;
    }


    @Override
    public void init(List<TargetPaymentModeOptionsModel> tpmom) {

    }

    @Override
    public Boolean updateTargetPaymentModesInfo(TargetPaymentModeOptionsModel targetInfo) {
        return null;
    }

}
