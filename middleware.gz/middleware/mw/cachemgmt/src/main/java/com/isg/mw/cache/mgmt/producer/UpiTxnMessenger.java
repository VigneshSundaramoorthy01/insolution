package com.isg.mw.cache.mgmt.producer;

import com.isg.mw.core.model.upi.UpiTxnRequestData;

public interface UpiTxnMessenger {

    void send(UpiTxnRequestData upiTxnRequestData);

}
