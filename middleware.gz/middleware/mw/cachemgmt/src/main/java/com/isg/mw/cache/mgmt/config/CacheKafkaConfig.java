package com.isg.mw.cache.mgmt.config;

import com.isg.kafka.config.KafkaConfig;
import lombok.Data;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * Cache Management Kafka Configuration
 *
 * @author akshay3978
 */
@Data
@Configuration
@PropertySource("${spring.config.location}kafka-config.properties")
public class CacheKafkaConfig {

    @Value("${kafka.brokers}")
    private String brokers;

    @Value("${kafka.clientid}")
    private String clientId;

    @Value("${kafka.auto.comit.enabled}")
    private boolean autoCommitEnable;

    @Value("${kafka.consumers.count}")
    private int consumersCount;

    @Value("${kafka.use.original.message}")
    private boolean useOriginalMessage;

    @Value("${kafka.max.failed.msg.redeliveries}")
    private int maxFailedMsgRedeliveries;

    @Value("${kafka.max.failed.msg.redelivery.delay}")
    private long maxFailedMsgRedeliveryDelay;

    @Value("${kafka.retries}")
    private int retries;

    @Value("${kafka.request.required.acks}")
    private String requestRequiredAcks;

    @Value("${kafka.record.metadata}")
    private boolean recordMetadata;

    @Value("${kafka.cache.topic.mapsinfo}")
    private String mapsInfoTopicName;

    @Value("${kafka.cache.topic.binInfo}")
    private String binInfoTopicName;

    @Value("${kafka.cache.target.lcr.config.topic}")
    private String targetLcrTopicName;

    @Value("${kafka.cache.topic.paymentModesInfo}")
    private String paymentModesTopicName;

    @Value("${kafka.cache.topic.paymentModeOptionsInfo}")
    private String paymentModeOptionsTopicName;

    @Value("${kafka.cache.topic.targetPaymentModesInfo}")
    private String targetPaymentModesTopicName;

    @Value("${kafka.cache.topic.targetPaymentModeOptionsInfo}")
    private String targetPaymentModeOptionsTopicName;

    @Value("${kafka.cache.topic.merchant.master}")
    private String merchantMasterTopicName;

    @Value("${kafka.cache.merchant.payment.modes.topic}")
    private String merchantPaymentModesTopicName;

    @Value("${kafka.cache.merchant.payment.mode.options.topic}")
    private String merchantPaymentModeOptionsTopicName;

    @Value("${kafka.merchant.payment.modes.and.options.topic}")
    private String merchantPaymentModesAndOptionsTopicName;

    @Value("${kafka.cache.target.merchant.master.topic}")
    private String targetMerchantMasterTopicName;

    @Value("${kafka.produce.target.merchant.master.topic}")
    private String targetMerchantMasterProducerTopicName;

    @Value("${kafka.cache.merchant.target.preference.topic}")
    private String merchantTargetPrefrencesTopicName;

    @Value("${kafka.security.enabled:false}")
    private boolean kafkaSecurityEnabled;

    @Value("${kafka.truststore.location:}")
    private String trustStoreLocation;

    @Value("${kafka.truststore.password:}")
    private String trustStorePassword;

    @Value("${kafka.set.protocol:}")
    private String protocol;

    @Value("${kafka.set.sasl.mechanism:}")
    private String saslMechanism;

    @Value("${kafka.truststore.type:}")
    private String trustStoreType;

    @Value("${kafka.jaas.config:}")
    private String saslJaasConfig;
    
    @Value("${kafka.max.poll.records:100}")
    private int maxPollRecords;

    @Value("${kafka.max.poll.interval.ms:300000}")
    private long maxPollIntervalMs;

    @Value("${kafka.onboard.merchant.master.topic}")
    private String onboardMerchantMasterTopicName;

    @Value("${kafka.common.group.id}")
    private String srCommonGroupId;

    @Value("${kafka.individual.group.id}")
    private String srIndividualGroupId;

    @Value("${kafka.cache.topic.upi:}")
    private String upiTopicName;

    @Value("${kafka.cache.topic.customerdata.upi}")
    private String upiCustomerDataTopicName;

    @Value("${kafka.cache.topic.upitxnreq.upi:}")
    private String upiTxnReqDataTopicName;

    @Value("${kafka.cache.topic.mandatedata.upi:}")
    private String upiMandateDataTopicName;


    @Value("${kafka.cache.topic.feeder.upi:}")
    private String upiFeederTopicName;

    @Value("${kafka.cache.topic.notification.upi:}")
    private String notificationTopicName;


    public KafkaConfig getKafkaConfig(String topicName) {
        KafkaConfig kafkaConfig = new KafkaConfig();
        kafkaConfig.setTopicName(topicName);
        kafkaConfig.setBrokers(brokers);
        kafkaConfig.setAutoCommitEnable(autoCommitEnable);
        kafkaConfig.setConsumersCount(consumersCount);
        kafkaConfig.setMaxFailedMsgRedeliveries(maxFailedMsgRedeliveries);
        kafkaConfig.setMaxFailedMsgRedeliveryDelay(maxFailedMsgRedeliveryDelay);
        kafkaConfig.setRetries(retries);
        kafkaConfig.setRequestRequiredAcks(requestRequiredAcks);
        kafkaConfig.setRecordMetadata(recordMetadata);
//        kafkaConfig.setValueDeserializer(deserializer);
        kafkaConfig.setKafkaSecurityEnabled(kafkaSecurityEnabled);
        kafkaConfig.setMaxPollRecords(maxPollRecords);
        kafkaConfig.setMaxPollIntervalMs(maxPollIntervalMs);
        kafkaConfig.setProtocol(protocol);
        kafkaConfig.setTrustStoreLocation(trustStoreLocation);
        kafkaConfig.setTrustStorePassword(trustStorePassword);
        kafkaConfig.setTrustStoreType(trustStoreType);
        kafkaConfig.setSaslJaasConfig(saslJaasConfig);
        kafkaConfig.setSaslMechanism(saslMechanism);
        return kafkaConfig;
    }

    public KafkaConfig getKafkaConfig(String topicName, Class<?> deserializer, String groupId) {
        KafkaConfig kafkaConfig = getKafkaConfig(topicName);
        kafkaConfig.setValueDeserializer(deserializer);
        kafkaConfig.setGroupId(groupId);
        return kafkaConfig;
    }

    public KafkaConfig getProducerKafkaConfig(String topicName, Class<?> serializer) {
        KafkaConfig kafkaConfig = getKafkaConfig(topicName);
        kafkaConfig.setValueSerializer(serializer);
        return kafkaConfig;
    }

    public KafkaConfig getKafkaConfig(String topicName,Class<?> deserializer) {
        KafkaConfig kafkaConfig = getKafkaConfig(topicName);
        kafkaConfig.setValueDeserializer(deserializer);;
        return kafkaConfig;
    }

}