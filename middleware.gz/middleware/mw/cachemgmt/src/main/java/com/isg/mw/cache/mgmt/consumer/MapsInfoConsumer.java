package com.isg.mw.cache.mgmt.consumer;

import com.isg.mw.cache.mgmt.deserializers.MerchantMasterDeserializer;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.deserializers.MapsInfoDeserializer;
import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;

/**
 * Consume the MapsInfo & MerchantMaster from kafka topic and push it to cache.
 */
@Component
public class MapsInfoConsumer implements ApplicationRunner {
    private static final Logger logger = LogManager.getLogger(MapsInfoConsumer.class);

    @Autowired
    private CacheKafkaConfig cacheKafkaConfig;

    @Autowired
    private MapsInfoService mapsInfoService;

    /**
     * This method consume maps info model from kafka topic using reusable kafka
     * component.
     */

    @Override
    public void run(ApplicationArguments args) throws Exception {
        logger.info("Maps info & Merchant Master Kafka Consumer Method Call");
        try {
//            KafkaConsumer consumer = new KafkaConsumer(cacheKafkaConfig
//                    .getKafkaConfig(cacheKafkaConfig.getMapsInfoTopicName(), MapsInfoDeserializer.class),
//                    this, "cacheMapsInfoConsumer");

            KafkaConsumer consumer = new KafkaConsumer(cacheKafkaConfig
                    .getKafkaConfig(cacheKafkaConfig.getMapsInfoTopicName(), MapsInfoDeserializer.class,
                            "MAPS_" + cacheKafkaConfig.getSrIndividualGroupId() + "_"+
                                    cacheKafkaConfig.getMapsInfoTopicName()),
                    this, "cacheMapsInfoConsumer");
            consumer.init();

//            KafkaConsumer consumer1 = new KafkaConsumer(cacheKafkaConfig
//                    .getKafkaConfig(cacheKafkaConfig.getMerchantMasterTopicName(), MerchantMasterDeserializer.class),
//                    this, "cacheMerchantMasterConsumer");
            KafkaConsumer consumer1 = new KafkaConsumer(cacheKafkaConfig
                    .getKafkaConfig(cacheKafkaConfig.getMerchantMasterTopicName(), MerchantMasterDeserializer.class,
                            "MERCHANT_MASTER_" + cacheKafkaConfig.getSrIndividualGroupId() + "_"+
                                    cacheKafkaConfig.getMerchantMasterTopicName()),
                    this, "cacheMerchantMasterConsumer");
            consumer1.init();
            logger.info("Maps Info & Merchant Master Kafka Consumer Initialization Done...");
        } catch (Exception e) {
            logger.error("Exception While Consuming MapsInfo & Merchant Master: ", e);
        }
    }

    /**
     * This method store data into mapsInfocache
     *
     * @param maps
     */
    public void cacheMapsInfoConsumer(MapsInfoModel maps) {
        try {
            mapsInfoService.updateMapsInfo(maps);
        } catch (Exception e) {
            logger.error("Exception while updating maps info cache: ", e);
        }
    }

    public void cacheMerchantMasterConsumer(MerchantMasterModel merchantMasterModel) {
        try {
            mapsInfoService.updateMerchantMaster(merchantMasterModel);
        } catch (Exception e) {
            logger.error("Exception while updating merchant master cache: ", e);
        }
    }

}
