package com.isg.mw.cache.mgmt.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.dstm.MftrBDKModel;

@Service
public interface MftrBdkService {
		/**
		 * Update MftrBdk in Cache
		 * 
		 * @param BinInfo
		 * @return boolean
		 */
		Boolean updateBDK(MftrBDKModel binInfo);

		/**
		 * Get Bdk Info from cache based on manufacturer name.
		 * 
		 * @param cardNumber
		 * @return BinInfoModel
		 */
		Map<HsmCommandArg, String> getBDKMftrName(String manufacturerName);



}
