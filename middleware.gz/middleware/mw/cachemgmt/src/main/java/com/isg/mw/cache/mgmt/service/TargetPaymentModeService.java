package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TargetPaymentModeService {
    /**
     * Update TargetPaymentModesInfo in Cache
     *
     * @param
     * @return boolean
     */

    void init(List<TargetPaymentModesModel> tpmm);


    Boolean updateTargetPaymentModesInCache(TargetPaymentModesModel targetInfo);

}
