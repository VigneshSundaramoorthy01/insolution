package com.isg.mw.cache.mgmt.deserializers;

import com.isg.mw.core.model.sr.MerchantMasterModel;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * Deserializer of MerchantMasterModel.
 */
public class MerchantMasterDeserializer implements Deserializer<MerchantMasterModel> {
    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public MerchantMasterModel deserialize(String topic, byte[] data) {
        MerchantMasterModel merchantMasterModel = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            merchantMasterModel = (MerchantMasterModel) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing MerchantMasterModel object: ", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class in which the object to be deserialized not found: ", e);
        }
        return merchantMasterModel;

    }

}
