package com.isg.mw.cache.mgmt.deserializers;

import com.isg.mw.core.model.sr.MerchantTargetPreferencesMessage;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class MerchantTargetPrefrencesDeserializer implements Deserializer<MerchantTargetPreferencesMessage> {
    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public MerchantTargetPreferencesMessage deserialize(String topic, byte[] data) {
        MerchantTargetPreferencesMessage merchantTargetPreferencesMsgModel = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            merchantTargetPreferencesMsgModel = (MerchantTargetPreferencesMessage) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing MerchantTargetPreferencesModel object: {}", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class in which the object to be deserialized not found: {}", e);
        }
        return merchantTargetPreferencesMsgModel;

    }
}
