package com.isg.mw.cache.mgmt.deserializers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.bi.BinInfoModel;

/**
 * Deserializer of BinInfoModel
 * 
 * @author akshay3978
 *
 */
public class BinInfoDeserializer implements Deserializer<BinInfoModel> {

	private final Logger logger = LogManager.getLogger(getClass());

	@Override
	public BinInfoModel deserialize(String topic, byte[] data) {
		BinInfoModel binInfoModel = null;
		ByteArrayInputStream bis = new ByteArrayInputStream(data);
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(bis);
			binInfoModel = (BinInfoModel) ois.readObject();
			ois.close();
		} catch (IOException e) {
			logger.error("Error while deserializing BinInfoModel object: {}", e);
		} catch (ClassNotFoundException e) {
			logger.error("Class in which the object to be deserialized not found: {}", e);
		}
		return binInfoModel;

	}
}
