package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.*;
import com.isg.mw.cache.mgmt.service.SmartRouteConfigService;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.utils.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service("smartRouteConfigService")
public class SmartRouteConfigServiceImpl implements SmartRouteConfigService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Autowired
    private CacheUtil cacheUtil;

    @Autowired
    private CacheHelper cacheHelper;

    @Autowired
    private SmartRouteSpringCacheService srCacheService;

    @Override
    public Boolean updateTargetPaymentModesInCache(TargetPaymentModesMessage targetPaymentModesMsgModel) {
        try {
            if (targetPaymentModesMsgModel != null) {
                TargetPaymentModesModel targetPaymentModesModel = SmartRouteConfigUtil.getTargetPaymentModesModel(targetPaymentModesMsgModel);

                if (targetPaymentModesMsgModel.getAction() == ConfigAction.INACTIVE) {
                    LOG.trace("Target Payment Mode model {} is now inactive, hence can be evicted", targetPaymentModesModel);
                    int removed = srCacheService.removeTargetPayMode(targetPaymentModesModel.getEntityId(), targetPaymentModesModel.getTargetId().toString()
                            , targetPaymentModesModel.getPaymentModeId().toString());
                    if (removed != 0)
                        LOG.trace("Target Payment Mode model {} Evicted Successfully...", removed);
                    else
                        LOG.trace("Target Payment Mode model {} is inactive, hence not added in cache", targetPaymentModesMsgModel);
                } else if (targetPaymentModesMsgModel.getAction() == ConfigAction.ADD || targetPaymentModesMsgModel.getAction() == ConfigAction.MODIFY || targetPaymentModesMsgModel.getAction() == ConfigAction.ACTIVATE) {
                    CacheTargetPaymentModeAndOptions cacheTgtPayModeAndOps = srCacheService.
                            getTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId(), targetPaymentModesModel.getTargetId().toString(),
                                    targetPaymentModesModel.getPaymentModeId().toString());
                    Set<CacheTargetPaymentModeAndOptions> cacheTgtPayModeAndOpsSet = srCacheService.
                            getAllTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId());
                    if (cacheTgtPayModeAndOps == null) {
                        cacheTgtPayModeAndOps = new CacheTargetPaymentModeAndOptions();
                        cacheTgtPayModeAndOps.setTargetPaymentMode(targetPaymentModesModel);
                        cacheTgtPayModeAndOps.setTargetPaymentModeOptions(new ArrayList<>());
                        cacheTgtPayModeAndOpsSet.add(cacheTgtPayModeAndOps);
                    } else {
                        Set<CacheTargetPaymentModeAndOptions> collect = cacheTgtPayModeAndOpsSet.stream().filter(model -> model.getTargetPaymentMode().getPaymentModeId().toString().equals(targetPaymentModesModel.getPaymentModeId().toString()))
                                .filter(model -> model.getTargetPaymentMode().getTargetId().toString().equals(targetPaymentModesModel.getTargetId().toString())).collect(Collectors.toSet());
                        if (!collect.isEmpty()) {
                            for (CacheTargetPaymentModeAndOptions cacheTargetPaymentModeAndOption : collect) {
                                TargetPaymentModesModel targetPaymentMode = cacheTargetPaymentModeAndOption.getTargetPaymentMode();
                                if (targetPaymentMode.getTargetId().toString().equals(targetPaymentModesModel.getTargetId().toString()) && targetPaymentMode.getPaymentModeId().toString().equals(targetPaymentModesModel.getPaymentModeId().toString())) {
                                    cacheTgtPayModeAndOps.setTargetPaymentMode(targetPaymentModesModel);
                                    cacheTgtPayModeAndOps.setTargetPaymentModeOptions(cacheTargetPaymentModeAndOption.getTargetPaymentModeOptions());
                                    cacheTgtPayModeAndOpsSet.remove(cacheTargetPaymentModeAndOption);
                                    break;
                                }
                            }
                        }
                        cacheTgtPayModeAndOpsSet.add(cacheTgtPayModeAndOps);
                    }
                    srCacheService.setTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId(), cacheTgtPayModeAndOpsSet);
                    CacheTargetPaymentModeAndOptions targetPayModeAndOptionsData = srCacheService.getTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId(),
                            targetPaymentModesModel.getTargetId().toString(), targetPaymentModesModel.getPaymentModeId().toString());
                    LOG.trace("Target Payment Mode model {} Inserted/Updated Successfully...", targetPayModeAndOptionsData.getTargetPaymentMode());
                }
            } else {
                LOG.info("Target Payment Mode model is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean updateTargetPaymentModeOptionInCache(TargetPaymentModeOptionsMessage targetPaymentModeOptionsMsgModel) {
        try {
            if (targetPaymentModeOptionsMsgModel != null) {
                TargetPaymentModeOptionsModel targetPaymentModeOptionModel = SmartRouteConfigUtil.getTargetPaymentModeOptionModel(targetPaymentModeOptionsMsgModel);
                TargetPaymentModesModel targetPaymentModesModel = SmartRouteConfigUtil.getTargetPayModesModelFromTgtPayOptionMsgModel(targetPaymentModeOptionsMsgModel);

                if (targetPaymentModeOptionsMsgModel.getAction() == ConfigAction.INACTIVE) {
                    LOG.trace("Target Payment Mode Option model {} is now inactive, hence can be evicted", targetPaymentModeOptionModel);
                    int removed = srCacheService.removeTargetPayModeOption(targetPaymentModesModel.getEntityId(), targetPaymentModesModel.getTargetId().toString()
                            , targetPaymentModesModel.getPaymentModeId().toString());
                    if (removed != 0)
                        LOG.trace("Target Payment Mode Option model {} Evicted Successfully...", removed);
                    else
                        LOG.trace("Target Payment Mode Option model {} is inactive, hence not added in cache", targetPaymentModeOptionModel);
                } else if (targetPaymentModeOptionsMsgModel.getAction() == ConfigAction.ADD || targetPaymentModeOptionsMsgModel.getAction() == ConfigAction.MODIFY || targetPaymentModeOptionsMsgModel.getAction() == ConfigAction.ACTIVATE) {
                    CacheTargetPaymentModeAndOptions cacheTgtPayModeAndOps = srCacheService.
                            getTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId(), targetPaymentModesModel.getTargetId().toString(),
                                    targetPaymentModesModel.getPaymentModeId().toString());

                    Set<CacheTargetPaymentModeAndOptions> cacheTgtPayModeAndOpsSet = srCacheService.
                            getAllTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId());

                    if (cacheTgtPayModeAndOps != null) {
                        //Add data when TargetPaymentModeOptions list is empty
                        List<TargetPaymentModeOptionsModel> targetPaymentModeOptions = cacheTgtPayModeAndOps.getTargetPaymentModeOptions();
                        if (targetPaymentModeOptions.isEmpty() && targetPaymentModeOptions == null) {
                            targetPaymentModeOptions = new ArrayList();
                            targetPaymentModeOptions.add(targetPaymentModeOptionModel);
                            cacheTgtPayModeAndOps.setTargetPaymentModeOptions(targetPaymentModeOptions);
                            cacheTgtPayModeAndOpsSet.add(cacheTgtPayModeAndOps);
                        //Add data when TargetPaymentModeOptions list is not empty but the new added configuration is not present in list
                        } else if (!isTargetPaymentModeOptionExist(targetPaymentModeOptions, targetPaymentModeOptionModel)) {
                            targetPaymentModeOptions.add(targetPaymentModeOptionModel);
                            cacheTgtPayModeAndOps.setTargetPaymentModeOptions(targetPaymentModeOptions);
                            cacheTgtPayModeAndOpsSet.add(cacheTgtPayModeAndOps);
                        //Condition for update TargetPaymentModeOptions list data
                        } else if (isTargetPaymentModeOptionExist(cacheTgtPayModeAndOps.getTargetPaymentModeOptions(), targetPaymentModeOptionModel)) {
                            Set<CacheTargetPaymentModeAndOptions> collect = cacheTgtPayModeAndOpsSet.stream().filter(model -> model.getTargetPaymentMode().getPaymentModeId().toString().equals(targetPaymentModesModel.getPaymentModeId().toString()))
                                    .filter(model -> model.getTargetPaymentMode().getTargetId().toString().equals(targetPaymentModesModel.getTargetId().toString())).collect(Collectors.toSet());
                            if (!collect.isEmpty()) {
                                for (CacheTargetPaymentModeAndOptions cacheTargetPaymentModeAndOption : collect) {
                                    TargetPaymentModesModel targetPaymentMode = cacheTargetPaymentModeAndOption.getTargetPaymentMode();
                                    if (targetPaymentMode.getTargetId().toString().equals(targetPaymentModesModel.getTargetId().toString()) && targetPaymentMode.getPaymentModeId().toString().equals(targetPaymentModesModel.getPaymentModeId().toString())) {
                                        List<TargetPaymentModeOptionsModel> targetPaymentModeOptionsList = cacheTargetPaymentModeAndOption.getTargetPaymentModeOptions();
                                        for (TargetPaymentModeOptionsModel model : targetPaymentModeOptionsList) {
                                            if (model.getTargetPaymentModeId().toString().equals(targetPaymentModeOptionModel.getTargetPaymentModeId().toString())) {
                                                targetPaymentModeOptionsList.add(targetPaymentModeOptionModel);
                                                targetPaymentModeOptionsList.remove(model);
                                                break;
                                            }
                                        }
                                        cacheTgtPayModeAndOps.setTargetPaymentModeOptions(targetPaymentModeOptionsList);
                                        break;
                                    }
                                }
                            }
                            cacheTgtPayModeAndOpsSet.add(cacheTgtPayModeAndOps);
                        }
                    }
                    srCacheService.setTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId(), cacheTgtPayModeAndOpsSet);
                    CacheTargetPaymentModeAndOptions targetPayModeAndOptionsData = srCacheService.getTargetPayModeAndOptionsData(targetPaymentModesModel.getEntityId(),
                            targetPaymentModesModel.getTargetId().toString(), targetPaymentModesModel.getPaymentModeId().toString());
                    LOG.trace("Target Payment Mode model :: {} And Target Payment Mode Option model :: {}  Inserted/Updated Successfully...", targetPayModeAndOptionsData.getTargetPaymentMode(),
                            targetPayModeAndOptionsData.getTargetPaymentModeOptions());
                }
            } else {
                LOG.info("Target Payment Mode Option model");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return null;
    }

    private boolean isTargetPaymentModeOptionExist(List<TargetPaymentModeOptionsModel> targetPaymentModeOptions, TargetPaymentModeOptionsModel targetPaymentModeOptionsModel) {
        for (TargetPaymentModeOptionsModel targetPaymentModeOption : targetPaymentModeOptions) {
            if (targetPaymentModeOption.getPaymentModeOptionId().toString().equals(targetPaymentModeOptionsModel.getPaymentModeOptionId().toString())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean updateTargetLcrInCache(TargetLCRConfigMessage targetLCRConfigMsgModel) {
        try {
            if (targetLCRConfigMsgModel != null) {
                TargetLCRConfigModel targetLCRConfigModel = SmartRouteConfigUtil.getTargetLCRConfigModel(targetLCRConfigMsgModel);
                TargetLcrKey targetLcrKey = cacheHelper.getTargetLCRKeyObj(targetLCRConfigModel);
                TargetLcrValue targetLcrValue = cacheHelper.getTargetLCRValueObj(targetLCRConfigModel);

                if (targetLCRConfigMsgModel.getAction() == ConfigAction.INACTIVE) {
                    LOG.trace("Target LCR model {} is now inactive, hence can be evicted", targetLCRConfigModel);
                    Long removed = cacheUtil.removeTargetLCRData(targetLCRConfigModel.getEntityId(), targetLcrKey);
                    if (removed != 0)
                        LOG.trace("Target LCR model {} Evicted Successfully...", removed);
                    else
                        LOG.trace("Target LCR model {} is inactive, hence not added in cache", targetLCRConfigMsgModel);
                } else if (targetLCRConfigMsgModel.getAction() == ConfigAction.ADD || targetLCRConfigMsgModel.getAction() == ConfigAction.MODIFY || targetLCRConfigMsgModel.getAction() == ConfigAction.ACTIVATE) {
                    Map<TargetLcrKey, Set<TargetLcrValue>> targetLCRData = cacheUtil.getTargetLCRData(targetLCRConfigModel.getEntityId());
                    Set<TargetLcrValue> targetLcrValues = targetLCRData.get(targetLcrKey);
                    LOG.info("Target LCR current set Value In Cache : {}", targetLcrValues);
                    if (targetLcrValues == null) {
                        targetLcrValues = new HashSet<>();
                    }
                    for (TargetLcrValue lcrValue : targetLcrValues) {
                        if(lcrValue.getTargetId().toString().equals(targetLcrValue.getTargetId().toString())){
                            targetLcrValues.remove(lcrValue);
                            break;
                        }
                    }
                    targetLcrValues.add(targetLcrValue);
                    cacheUtil.putTargetLcrData(targetLCRConfigModel.getEntityId(), targetLcrKey, targetLcrValues);
                    LOG.info("Target LCR Updated set Value In Cache : {}", targetLcrValues);
                    LOG.trace("Target LCR model {} Inserted/Updated Successfully...", targetLCRConfigMsgModel);
                }
            } else {
                LOG.info("TargetLcrModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean updateMerchantPaymentModesInCache(MerchantPaymentModesMessage merchantPaymentModesMessageModel) {
        try {
            if (merchantPaymentModesMessageModel != null) {
                MerchantPaymentModesModel merchantPaymentModesModel = SmartRouteConfigUtil.getMerchantPaymentModesModel(merchantPaymentModesMessageModel);
                MerchantMasterModel merchantMasterModel = SmartRouteConfigUtil.getMerchantMasterModelFromMerchantPayModeMsg(merchantPaymentModesMessageModel);

                if (merchantPaymentModesMessageModel.getAction() == ConfigAction.INACTIVE) {
                    LOG.trace("Merchant Payment Mode model {} is now inactive, hence can be evicted", merchantPaymentModesModel);
                    int removed = srCacheService.removeMerchantPayMode(merchantPaymentModesModel, merchantMasterModel);
                    if (removed != 0)
                        LOG.trace("Merchant Payment Mode model {} Evicted Successfully...", removed);
                    else
                        LOG.trace("Merchant Payment Mode model {} is inactive, hence not added in cache", merchantPaymentModesMessageModel);
                } else if (merchantPaymentModesMessageModel.getAction() == ConfigAction.ADD || merchantPaymentModesMessageModel.getAction() == ConfigAction.MODIFY || merchantPaymentModesMessageModel.getAction() == ConfigAction.ACTIVATE) {
                    List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDatas = srCacheService.getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());

                    CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOptions = null;
                    if (merchantPayModeAndOptionsDatas == null || merchantPayModeAndOptionsDatas.isEmpty()) {
                        merchantPayModeAndOptionsDatas = new ArrayList<>();
                        cacheMerchantPaymentModeAndOptions = new CacheMerchantPaymentModeAndOptions();
                        cacheMerchantPaymentModeAndOptions.setMerchantPaymentMode(merchantPaymentModesModel);
                        cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(new ArrayList<>());
                        merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
                    } else if (!isMerchantPayModeExist(merchantPayModeAndOptionsDatas, merchantPaymentModesModel)) {
                        cacheMerchantPaymentModeAndOptions = new CacheMerchantPaymentModeAndOptions();
                        cacheMerchantPaymentModeAndOptions.setMerchantPaymentMode(merchantPaymentModesModel);
                        cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(new ArrayList<>());
                        merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
                    } else {
                        if (merchantPayModeAndOptionsDatas != null || !merchantPayModeAndOptionsDatas.isEmpty()) {
                            for (CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOption : merchantPayModeAndOptionsDatas) {
                                MerchantPaymentModesModel merchantPaymentMode = cacheMerchantPaymentModeAndOption.getMerchantPaymentMode();
                                if (merchantPaymentMode.getMerchantMasterId().toString().equals(merchantPaymentModesModel.getMerchantMasterId().toString())
                                        && merchantPaymentMode.getPaymentModeId().toString().equals(merchantPaymentModesModel.getPaymentModeId().toString())) {
                                    cacheMerchantPaymentModeAndOption.setMerchantPaymentMode(merchantPaymentModesModel);
                                    cacheMerchantPaymentModeAndOption.setMerchantPaymentModeOptions(cacheMerchantPaymentModeAndOption.getMerchantPaymentModeOptions());
                                    merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOption);
                                    merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOption);
                                    break;
                                }
                            }
                        }
                    }
                    srCacheService.putMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid(), merchantPayModeAndOptionsDatas);
                    List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsData1 = srCacheService.getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
                    Optional<CacheMerchantPaymentModeAndOptions> isOptional = merchantPayModeAndOptionsData1.stream().filter(model -> model.getMerchantPaymentMode().getMerchantMasterId().toString().equals(merchantMasterModel.getMerchantMasterId().toString())).findFirst();
                    if (isOptional.isPresent())
                        LOG.trace("Merchant Payment Mode model {} Inserted/Updated Successfully...", isOptional.get());
                }
            } else {
                LOG.info("Merchant Payment Mode model is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    private boolean isMerchantPayModeExist(List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDatas, MerchantPaymentModesModel merchantPaymentModesModel) {
        for (CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOps : merchantPayModeAndOptionsDatas) {
            if (cacheMerchantPaymentModeAndOps.getMerchantPaymentMode().getMerchantMasterId().equals(merchantPaymentModesModel.getMerchantMasterId())
                    && cacheMerchantPaymentModeAndOps.getMerchantPaymentMode().getMerchantPaymentModeId().equals(merchantPaymentModesModel.getMerchantPaymentModeId())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean updateMerchantPaymentModeOptionInCache(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        try {
            if (merchantPaymentModeOptionsMessageModel != null) {
                MerchantPaymentModeOptionsModel merchantPaymentModeOptionModel = SmartRouteConfigUtil.getMerchantPaymentModeOptionModel(merchantPaymentModeOptionsMessageModel);
                MerchantPaymentModesModel merchantPaymentModesModel = SmartRouteConfigUtil.getMerchantPayModesModelFromMerPayOptionMsgModel(merchantPaymentModeOptionsMessageModel);
                MerchantMasterModel merchantMasterModel = SmartRouteConfigUtil.getMerchantMasterModelFromMerchantPayModeOptionMsg(merchantPaymentModeOptionsMessageModel);
                if (merchantPaymentModeOptionsMessageModel.getAction() == ConfigAction.INACTIVE) {
                    LOG.trace("Merchant Payment Mode Option model {} is now inactive, hence can be evicted", merchantPaymentModeOptionModel);
                    int removed = srCacheService.removeMerchantPayModeOption(merchantMasterModel.getEntityId(), merchantMasterModel.getMid(), merchantPaymentModesModel, merchantPaymentModeOptionModel);
                    if (removed != 0)
                        LOG.trace("Merchant Payment Mode Option model {} Evicted Successfully...", removed);
                    else
                        LOG.trace("Merchant Payment Mode Option model {} is inactive, hence not added in cache", merchantPaymentModeOptionsMessageModel);
                } else if (merchantPaymentModeOptionsMessageModel.getAction() == ConfigAction.ADD || merchantPaymentModeOptionsMessageModel.getAction() == ConfigAction.MODIFY || merchantPaymentModeOptionsMessageModel.getAction() == ConfigAction.ACTIVATE) {
                    List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDatas = srCacheService.
                            getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
                    CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOptions = merchantPayModeAndOptionsDatas.stream().filter(model -> model.getMerchantPaymentMode().getPaymentModeId() != null && model.getMerchantPaymentMode().getPaymentModeId().toString()
                            .equals(merchantPaymentModesModel.getPaymentModeId().toString())).filter(model -> model.getMerchantPaymentMode().getMerchantMasterId() != null && model.getMerchantPaymentMode().getMerchantMasterId().toString()
                            .equals(merchantPaymentModesModel.getMerchantMasterId().toString())).findFirst().get();
                    List<MerchantPaymentModeOptionsModel> merchantPayModeOpsDataList = cacheMerchantPaymentModeAndOptions.getMerchantPaymentModeOptions();
                    if (merchantPayModeAndOptionsDatas != null) {
                        if (merchantPayModeOpsDataList == null || merchantPayModeOpsDataList.isEmpty()) {
                            merchantPayModeOpsDataList = new ArrayList();
                            merchantPayModeOpsDataList.add(merchantPaymentModeOptionModel);
                            cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(merchantPayModeOpsDataList);
                            if (merchantPayModeAndOptionsDatas.contains(cacheMerchantPaymentModeAndOptions)) {
                                merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOptions);
                            }
                            merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
                        } else if (!isMerchantPayModeOptionExist(merchantPayModeOpsDataList, merchantPaymentModeOptionModel)) {
                            merchantPayModeOpsDataList.add(merchantPaymentModeOptionModel);
                            cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(merchantPayModeOpsDataList);
                            if (merchantPayModeAndOptionsDatas.contains(cacheMerchantPaymentModeAndOptions)) {
                                merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOptions);
                            }
                            merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
                        } else if (isMerchantPayModeOptionExist(merchantPayModeOpsDataList, merchantPaymentModeOptionModel)) {
                            if (!merchantPayModeAndOptionsDatas.isEmpty()) {
                                for (MerchantPaymentModeOptionsModel merchantPaymentModeOptionsModel1 : merchantPayModeOpsDataList) {
                                    if (merchantPaymentModeOptionsModel1.getPaymentModeOptionId().toString().equals(merchantPaymentModeOptionModel.getPaymentModeOptionId().toString())) {
                                        if (merchantPayModeOpsDataList.contains(merchantPaymentModeOptionsModel1)) {
                                            merchantPayModeOpsDataList.remove(merchantPaymentModeOptionsModel1);
                                            merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOptions);
                                        }
                                        merchantPayModeOpsDataList.add(merchantPaymentModeOptionModel);
                                        cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(merchantPayModeOpsDataList);
                                        break;
                                    }
                                }
                                merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
                            }
                        }
                    }
                    srCacheService.putMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid(), merchantPayModeAndOptionsDatas);
                    List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsData1 = srCacheService.getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
                    Optional<CacheMerchantPaymentModeAndOptions> isOptional = merchantPayModeAndOptionsData1.stream().filter(model -> model.getMerchantPaymentMode().getMerchantMasterId().toString().equals(merchantMasterModel.getMerchantMasterId().toString())).findFirst();
                    if (isOptional.isPresent())
                        LOG.trace("Merchant Payment Mode model Option :: {} And Target Payment Mode Option model :: {}  Inserted/Updated Successfully...", isOptional.get());
                }
            } else {
                LOG.info("Merchant Payment Mode model is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean updateMerchantPaymentModesAndOptionInCache(MerchantPaymentModeOptionsMessage merchantPaymentModeOptionsMessageModel) {
        try {
            if (merchantPaymentModeOptionsMessageModel != null) {
                MerchantPaymentModeOptionsModel merchantPaymentModeOptionModel = SmartRouteConfigUtil.getMerchantPaymentModeOptionModel(merchantPaymentModeOptionsMessageModel);
                MerchantPaymentModesModel merchantPaymentModesModel = SmartRouteConfigUtil.getMerchantPayModesModelFromMerPayOptionMsgModel(merchantPaymentModeOptionsMessageModel);
                MerchantMasterModel merchantMasterModel = SmartRouteConfigUtil.getMerchantMasterModelFromMerchantPayModeOptionMsg(merchantPaymentModeOptionsMessageModel);
               if (merchantPaymentModeOptionsMessageModel.getAction() == ConfigAction.ADD) {
                   //Code to add merchant payment modes in cache
                   List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDatas = srCacheService.getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
                   setMerchantPaymentModesInCache(merchantPaymentModesModel, merchantMasterModel, merchantPayModeAndOptionsDatas);

                   //Code to add merchant payment mode options in cache
                   setMerchantPaymentModeOptionsInCache(merchantPaymentModeOptionModel, merchantPaymentModesModel, merchantMasterModel);
               }
            } else {
                LOG.info("Merchant Payment Mode model is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    private void setMerchantPaymentModeOptionsInCache(MerchantPaymentModeOptionsModel merchantPaymentModeOptionModel, MerchantPaymentModesModel merchantPaymentModesModel, MerchantMasterModel merchantMasterModel) {
        CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOptions = null;
        List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsData1;
        Optional<CacheMerchantPaymentModeAndOptions> isOptional;
        List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDatas;
        merchantPayModeAndOptionsDatas = srCacheService.
                 getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
        cacheMerchantPaymentModeAndOptions = merchantPayModeAndOptionsDatas.stream().filter(model -> model.getMerchantPaymentMode().getPaymentModeId() != null && model.getMerchantPaymentMode().getPaymentModeId().toString()
                 .equals(merchantPaymentModesModel.getPaymentModeId().toString())).filter(model -> model.getMerchantPaymentMode().getMerchantMasterId() != null && model.getMerchantPaymentMode().getMerchantMasterId().toString()
                 .equals(merchantPaymentModesModel.getMerchantMasterId().toString())).findFirst().get();
        List<MerchantPaymentModeOptionsModel> merchantPayModeOpsDataList = cacheMerchantPaymentModeAndOptions.getMerchantPaymentModeOptions();
        if (merchantPayModeAndOptionsDatas != null) {
            if (merchantPayModeOpsDataList == null || merchantPayModeOpsDataList.isEmpty()) {
                merchantPayModeOpsDataList = new ArrayList();
                merchantPayModeOpsDataList.add(merchantPaymentModeOptionModel);
                cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(merchantPayModeOpsDataList);
                if (merchantPayModeAndOptionsDatas.contains(cacheMerchantPaymentModeAndOptions)) {
                    merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOptions);
                }
                merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
            } else if (!isMerchantPayModeOptionExist(merchantPayModeOpsDataList, merchantPaymentModeOptionModel)) {
                merchantPayModeOpsDataList.add(merchantPaymentModeOptionModel);
                cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(merchantPayModeOpsDataList);
                if (merchantPayModeAndOptionsDatas.contains(cacheMerchantPaymentModeAndOptions)) {
                    merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOptions);
                }
                merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
            } else if (isMerchantPayModeOptionExist(merchantPayModeOpsDataList, merchantPaymentModeOptionModel)) {
                if (!merchantPayModeAndOptionsDatas.isEmpty()) {
                    for (MerchantPaymentModeOptionsModel merchantPaymentModeOptionsModel1 : merchantPayModeOpsDataList) {
                        if (merchantPaymentModeOptionsModel1.getPaymentModeOptionId().toString().equals(merchantPaymentModeOptionModel.getPaymentModeOptionId().toString())) {
                            if (merchantPayModeOpsDataList.contains(merchantPaymentModeOptionsModel1)) {
                                merchantPayModeOpsDataList.remove(merchantPaymentModeOptionsModel1);
                                merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOptions);
                            }
                            merchantPayModeOpsDataList.add(merchantPaymentModeOptionModel);
                            cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(merchantPayModeOpsDataList);
                            break;
                        }
                    }
                    merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
                }
            }
        }
        srCacheService.putMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid(), merchantPayModeAndOptionsDatas);
        merchantPayModeAndOptionsData1 = srCacheService.getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
        isOptional = merchantPayModeAndOptionsData1.stream().filter(model -> model.getMerchantPaymentMode().getMerchantMasterId().toString().equals(merchantMasterModel.getMerchantMasterId().toString())).findFirst();
//        if (isOptional.isPresent()) {
//            LOG.trace("Merchant Payment Mode model Option :: And Target Payment Mode Option model :: Inserted/Updated Successfully... with size :: {}", isOptional.get().getMerchantPaymentModeOptions().size());
//
//        }
    }

    private void setMerchantPaymentModesInCache(MerchantPaymentModesModel merchantPaymentModesModel, MerchantMasterModel merchantMasterModel, List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsDatas) {
        CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOptions = null;
        if (merchantPayModeAndOptionsDatas == null || merchantPayModeAndOptionsDatas.isEmpty()) {
            merchantPayModeAndOptionsDatas = new ArrayList<>();
            cacheMerchantPaymentModeAndOptions = new CacheMerchantPaymentModeAndOptions();
            cacheMerchantPaymentModeAndOptions.setMerchantPaymentMode(merchantPaymentModesModel);
            cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(new ArrayList<>());
            merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
        } else if (!isMerchantPayModeExist(merchantPayModeAndOptionsDatas, merchantPaymentModesModel)) {
            cacheMerchantPaymentModeAndOptions = new CacheMerchantPaymentModeAndOptions();
            cacheMerchantPaymentModeAndOptions.setMerchantPaymentMode(merchantPaymentModesModel);
            cacheMerchantPaymentModeAndOptions.setMerchantPaymentModeOptions(new ArrayList<>());
            merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOptions);
        } else {
            if (merchantPayModeAndOptionsDatas != null || !merchantPayModeAndOptionsDatas.isEmpty()) {
                for (CacheMerchantPaymentModeAndOptions cacheMerchantPaymentModeAndOption : merchantPayModeAndOptionsDatas) {
                    MerchantPaymentModesModel merchantPaymentMode = cacheMerchantPaymentModeAndOption.getMerchantPaymentMode();
                    if (merchantPaymentMode.getMerchantMasterId().toString().equals(merchantPaymentModesModel.getMerchantMasterId().toString())
                            && merchantPaymentMode.getPaymentModeId().toString().equals(merchantPaymentModesModel.getPaymentModeId().toString())) {
                        cacheMerchantPaymentModeAndOption.setMerchantPaymentMode(merchantPaymentModesModel);
                        cacheMerchantPaymentModeAndOption.setMerchantPaymentModeOptions(cacheMerchantPaymentModeAndOption.getMerchantPaymentModeOptions());
                        merchantPayModeAndOptionsDatas.remove(cacheMerchantPaymentModeAndOption);
                        merchantPayModeAndOptionsDatas.add(cacheMerchantPaymentModeAndOption);
                        break;
                    }
                }
            }
        }
        srCacheService.putMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid(), merchantPayModeAndOptionsDatas);
        List<CacheMerchantPaymentModeAndOptions> merchantPayModeAndOptionsData1 = srCacheService.getMerchantPayModeAndOptionsData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid());
        Optional<CacheMerchantPaymentModeAndOptions> isOptional = merchantPayModeAndOptionsData1.stream().filter(model -> model.getMerchantPaymentMode().getMerchantMasterId().toString().equals(merchantMasterModel.getMerchantMasterId().toString())).findFirst();
      /*  if (isOptional.isPresent()) {
            LOG.trace("Merchant Payment Mode model {} Inserted/Updated Successfully...", isOptional.get().getMerchantPaymentMode());
        }*/
    }

    private boolean isMerchantPayModeOptionExist(List<MerchantPaymentModeOptionsModel> merchantPaymentModeOptionsModelList, MerchantPaymentModeOptionsModel merchantPaymentModeOptionModel) {
        for (MerchantPaymentModeOptionsModel model : merchantPaymentModeOptionsModelList)
            if (model.getPaymentModeOptionId().toString().equals(merchantPaymentModeOptionModel.getPaymentModeOptionId().toString())) {
                return true;
            }
        return false;
    }

    @Override
    public Boolean updateTargetMerchantMasterCache(TargetMerchantMasterModel targetMerchantMasterModel) {
        try {
            TargetMerchantMasterModel targetModel = null;
            if (targetMerchantMasterModel != null) {
                targetModel = SmartRouteConfigUtil.getTargetMerchantMasterModel(targetMerchantMasterModel);
                CacheTargetMerchantMaster masterData = srCacheService.getTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(),targetModel.getTid());
               LOG.info("Fetched Target Merchant Master From Redis For TargetId {} : and Status Is : {} " , targetModel.getTargetId(),masterData !=null ? masterData.getStatus() : null);
                CacheTargetMerchantMaster key;
                if (masterData != null && !masterData.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                    srCacheService.removeTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid());
                    key = new CacheTargetMerchantMaster();
                    key.setTargetMid(targetModel.getTargetMid());
                    key.setMerchantVpa(targetModel.getMerchantVpa());
                    key.setKey(targetModel.getKey());
                    key.setSalt(targetModel.getSalt());
                    key.setStatus(targetModel.getStatus());
                    key.setProdApiKey(targetModel.getProdApiKey());
                    key.setTestApiKey(targetModel.getTestApiKey());
                    key.setDpdId(targetModel.getDpaId());
                    srCacheService.putTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid(), key);
                }else {
                    key = new CacheTargetMerchantMaster();
                    key.setTargetMid(targetModel.getTargetMid());
                    key.setMerchantVpa(targetModel.getMerchantVpa());
                    key.setKey(targetModel.getKey());
                    key.setSalt(targetModel.getSalt());
                    key.setStatus(targetModel.getStatus());
                    key.setProdApiKey(targetModel.getProdApiKey());
                    key.setTestApiKey(targetModel.getTestApiKey());
                    key.setDpdId(targetModel.getDpaId());
                    srCacheService.putTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid(), key);
                }
            }
//            String targetMid = cacheUtil.getTargetMid(targetModel.getTargetId().toString(), targetModel.getMid(),targetModel.getTid());
            CacheTargetMerchantMaster targetMerchantMaster = srCacheService.getTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid());
            LOG.trace("Target Merchant Master Model for targetMID : {} and status : {}  Inserted/Updated Successfully...", targetMerchantMaster.getTargetMid() , targetMerchantMaster.getStatus());
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean updateTargetMerchantTargetPreferencesInCache(MerchantTargetPreferencesMessage merchantTargetPreferencesMsg) {
        try {
            MerchantTargetPreferencesModel targetPreferencesModel = null;
            MerchantMasterModel merchantMasterModel = null;
            if (merchantTargetPreferencesMsg != null) {
                targetPreferencesModel = SmartRouteConfigUtil.getMerchantTargetPreferencesModel(merchantTargetPreferencesMsg);
                merchantMasterModel = SmartRouteConfigUtil.getMerchantMasterFromMerchantTargetPrefMsg(merchantTargetPreferencesMsg);
                if (targetPreferencesModel.getStatus() == ActiveInactiveFlag.Inactive) {
                    LOG.trace("Merchant Target Preferences Model {} is now inactive, hence can be evicted", targetPreferencesModel);
                    boolean flag = cacheUtil.removeMerchantPreferredTargetDataData(merchantMasterModel.getEntityId(), merchantMasterModel.getMid()
                            , targetPreferencesModel.getPaymentModeId().toString());
                    if (flag != false)
                        LOG.trace("Merchant Target Preferences Model {} Evicted Successfully...", flag);
                    else
                        LOG.trace("Merchant Target Preferences Model {} is inactive, hence not added in cache", merchantTargetPreferencesMsg);
                } else {
                    MerchantPreferredTarget merchantPreferredTargetData = cacheUtil.getMerchantPreferredTarget(merchantMasterModel.getEntityId(),
                            merchantMasterModel.getMid(), targetPreferencesModel.getPaymentModeId().toString());
                    MerchantPreferredTarget merchantPrefTarget = getMerchantPrefTarget(targetPreferencesModel);
                    if (merchantPreferredTargetData == null) {
                        cacheUtil.putMerchantPreferredTargetData(merchantMasterModel.getEntityId()
                                , merchantMasterModel.getMid(), targetPreferencesModel.getPaymentModeId().toString(), merchantPrefTarget);
                    } else {
                        cacheUtil.putMerchantPreferredTargetData(merchantMasterModel.getEntityId()
                                , merchantMasterModel.getMid(), targetPreferencesModel.getPaymentModeId().toString(), merchantPrefTarget);
                    }
                }
            }
            MerchantPreferredTarget merchantPrefModel = cacheUtil.getMerchantPreferredTarget(merchantMasterModel.getEntityId(),
                    merchantMasterModel.getMid(), targetPreferencesModel.getPaymentModeId().toString());
            LOG.trace("Merchant Target Preferences Model {}  Inserted/Updated Successfully...", merchantPrefModel);
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    private MerchantPreferredTarget getMerchantPrefTarget(MerchantTargetPreferencesModel targetPreferencesModel) {
        MerchantPreferredTarget merchantPreferredTarget = new MerchantPreferredTarget(targetPreferencesModel.getTargetId(), targetPreferencesModel.getStartDate(),
                targetPreferencesModel.getEndDate(), targetPreferencesModel.getCreatedAt(), targetPreferencesModel.getUpdatedAt());
        return merchantPreferredTarget;
    }

}
