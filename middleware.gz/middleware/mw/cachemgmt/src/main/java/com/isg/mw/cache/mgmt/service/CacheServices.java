package com.isg.mw.cache.mgmt.service;

import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.SignOnSignOffModel;
import com.isg.mw.core.model.eftpos.TempKeyModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;

import java.util.List;
import java.util.Map;

/**
 * Cache Services.
 *
 * @author akshay3978
 */
public interface CacheServices {

    /**
     * Initialize Configurations Cache Service
     *
     * @param mapsInfoList
     */
    void initMapsConfigurations(List<MapsInfoModel> mapsInfoList);

    void initBinConfigurations(List<BinInfoModel> binInfoList);

	void initMftrConfigurations(List<MftrBDKModel> mftrBDKList);

    void initBinExceptionConfigurations(List<BinExceptionsModel> binExceptionsModelList);

    void initBinOnusMapConfigurations(List<BinOnusModel> binOnusMapList);

    void initAidConfigurations(List<AidSchemeModel> aidSchemeModelListList);

    /**
     * Validate the Merchant and terminal information based on
     * entityId,mid,tid,currency.
     *
     * @param entityId
     * @param mid
     * @param tid
     * @param currency
     * @return boolean
     */
    MapsInfoModel validateAndGetMerchant(String entityId, String mid, String tid, String currency);

    /**
     * get scheme name based on card number
     *
     * @param cardNumber
     * @return
     */
    String getSchemeName(String cardNumber);

    /**
     * Balance Enquiry transaction applicable to MasterCard Debit and Maestro cards.
     *
     * @param cardNumber
     * @return
     */
    BinInfoModel getSchemeBin(String cardNumber);

    void initMerchantMasterConfigurations(List<MerchantMasterModel> merchMasterList);

    MerchantMasterModel validateAndGetMerchantMaster(String entityId, String mid);

	/**
	 * Get Mftr BDK Map service.
	 *
	 * @param mftrName
	 * @return
	 */

	Map<HsmCommandArg, String> getMftrBDK(String mftrName);

    AidSchemeModel getAID(String aid);

    boolean getRejectedBin(String cardNumber);

    BinOnusModel getOnusBin(String cardNumber);

    EFTPOSKeyModel getEftposKeyDetails(String key);

    void updateEftposKeyDetails(String key, EFTPOSKeyModel eftposKeyModel);

    TempKeyModel getTempEftposKeyDetails(String key);

    void updateEftposTempKeyDetails(String targetName, TempKeyModel eftposKeyModel);

    boolean getSignOffStatus(String tagetName);
    void putSignOffStatus(boolean status, String tagetName);

    SignOnSignOffModel getEftposSignOnStatus();
    void putEftposSignOnStatus(boolean status, String targetIp);

    String getActiveTargetId();
    void deleteActiveTargetId(String activeTargetId);
    void putActiveTargetId(String activeTargetId);
    
    
    String getActiveTargetPort(String linkName);
    void deleteActiveTargetPort(String linkName, String activeTargetId);
    void putActiveTargetPort(String linkName, String activeTargetId);


}
