package com.isg.mw.cache.mgmt.init;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.annotation.PostConstruct;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

@Configuration
@Setter
@Getter
@PropertySource("${spring.config.location}appconfig.properties")
public class CacheMTMProperties {

	@Value("${resource.path}")
	private String path;

	private static ResourceBundle messagesBundle;

	@PostConstruct
	public void postConstruct() throws MalformedURLException {
		File file = new File(path);
		URL[] urls = { file.toURI().toURL() };
		ClassLoader loader = new URLClassLoader(urls);
		if (!(path.isEmpty()) || path != null) {
			CacheMTMProperties.messagesBundle = ResourceBundle.getBundle("mtm-config", new Locale("en"), loader);
		} else {
			CacheMTMProperties.messagesBundle = ResourceBundle.getBundle("mtm-config", new Locale("en"));
		}
	}

	public static String getProperty(String msgKey) {
		String msg = null;
		try {
			msg = (String) messagesBundle.getObject(msgKey);
		} catch (NullPointerException | MissingResourceException ex) {
			msg = "Unknown message";
		}
		return msg;
	}
}
