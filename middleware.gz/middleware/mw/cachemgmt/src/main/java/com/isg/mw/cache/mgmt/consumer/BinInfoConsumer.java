package com.isg.mw.cache.mgmt.consumer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.cache.mgmt.config.CacheKafkaConfig;
import com.isg.mw.cache.mgmt.deserializers.BinInfoDeserializer;
import com.isg.mw.cache.mgmt.service.BinInfoService;
import com.isg.mw.core.model.bi.BinInfoModel;

/**
 * Consume the BinInfo from kafka topic and push it to cache.
 * 
 * @author akshay3978
 *
 */
@Component
public class BinInfoConsumer implements ApplicationRunner {
	private static final Logger LOG = LogManager.getLogger(BinInfoConsumer.class);

	@Autowired
	private CacheKafkaConfig cacheKafkaConfig;

	@Autowired
	private BinInfoService binInfoService;

	/**
	 * This method consume bin info model from kafka topic using reusable kafka
	 * component.
	 */
	@Override
	public void run(ApplicationArguments args) throws Exception {
		LOG.info("Bin info Kafka Consumer Method Call");
		try {
			KafkaConsumer consumer = new KafkaConsumer(
					cacheKafkaConfig.getKafkaConfig(cacheKafkaConfig.getBinInfoTopicName(), BinInfoDeserializer.class),
					this, "cacheBinInfoConsumer");
			consumer.init();
			LOG.info("Bin info Kafka Consumer intialization done");
		} catch (Exception e) {
			LOG.error("Exception While Consumeing BinInfo: {} ", e);
		}
	}

	/**
	 * This method store data into binInfocache
	 * 
	 * @param model
	 */
	public void cacheBinInfoConsumer(BinInfoModel model) {
		try {
			binInfoService.updateBinInfo(model);
		} catch (Exception e) {
			LOG.error("Exception while BinInfo Service Call: {}", e);
		}
	}

}
