package com.isg.mw.cache.mgmt.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.event.CacheEvent;
import org.ehcache.event.CacheEventListener;

/**
 * Get all Cache Event by listener.
 * 
 * @author sudharshan
 */
public class CacheLogger implements CacheEventListener<Object, Object> {

	private final Logger LOG = LogManager.getLogger(getClass());

	/**
	 * Get all Cache Event by listener.
	 * 
	 * @param cacheEvent
	 */
	@Override
	public void onEvent(CacheEvent<?, ?> cacheEvent) {
		LOG.info("Key: {} | EventType: {} | Old value: {} | New value: {}", cacheEvent.getKey(), cacheEvent.getType(),
				cacheEvent.getOldValue(), cacheEvent.getNewValue());
	}

}
