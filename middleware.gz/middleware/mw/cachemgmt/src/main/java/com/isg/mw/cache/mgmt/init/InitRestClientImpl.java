package com.isg.mw.cache.mgmt.init;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.mw.core.model.bi.AidSchemeModel;
import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.BinExceptionsModel;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.dstm.MftrBDKModel;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import com.isg.mw.core.model.sr.TargetLCRConfigModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.sr.TargetPaymentModesModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.rbac.model.Auth;
import com.isg.mw.core.rbac.model.ResponseObj;
import com.isg.mw.core.rbac.utils.RbacUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component("initRestClient")
public class InitRestClientImpl implements InitRestClient {

    protected static Logger logger = LogManager.getLogger();

    @Autowired
    private InitProps initProps;

    @Autowired
    @Qualifier("plainTemplate")
    private RestTemplate restTemplate;

    private static final String JWT_KEY = "JWT-TOKEN";

    private static final String USER_NAME_HEADER = "User-Name";

    @Autowired
    private WebClient.Builder webClient;

    @Override
    public List<SourceConfigModel> getSourceConfigs() {

        ResponseEntity<SourceConfigModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigSourceUri(), HttpMethod.GET, buildHeaders(),
                SourceConfigModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());

    }

    @Override
    public List<TargetConfigModel> getTargetConfigs() {

        ResponseEntity<TargetConfigModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigTargetUri(), HttpMethod.GET, buildHeaders(),
                TargetConfigModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());

    }

    @Override
    public List<MessageTransformationConfigModel> getMessageTransformationConfigs() {

        ResponseEntity<MessageTransformationConfigModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigRouteDefUri(), HttpMethod.GET, buildHeaders(),
                MessageTransformationConfigModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());

    }

    @Override
    public List<HsmConfigModel> getDstmConfigs() {

        ResponseEntity<HsmConfigModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigDstmUri(), HttpMethod.GET, buildHeaders(),
                HsmConfigModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            return null;
        }
        return Arrays.asList(result.getBody());

    }
    @Override
    public Long getBinCount() {
        ResponseEntity<Long> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigBinCountUri() + "?activeFlag=Y", HttpMethod.POST, buildHeaders(),
                Long.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Long.parseLong(String.valueOf(result.getBody()));
    }

    @Override
    public List<BinInfoModel> getBinInfos(int pageNo, int pageSize) {
        ResponseEntity<BinInfoModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigBinsUri() + "?activeFlag=Y&pageNo=" +
                        pageNo + "&pageSize=" + pageSize, HttpMethod.POST, buildHeaders(),
                BinInfoModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());

    }

    @Override
    public BinInfoModel getBin(String binNumber) {
    	ResponseEntity<BinInfoModel> result = null;
    	try {
    		result = restTemplate.exchange(
    				initProps.getConfigServer() + initProps.getConfigGetBinUri() + "?binNumber=" + binNumber,
    				HttpMethod.GET, buildHeaders(), BinInfoModel.class);
    		if (result.getStatusCode() != HttpStatus.OK) {
    			return null;
    			//throw new RuntimeException();
    		}
    	} catch (Exception e) {
    		return null;
    	}
    	return result.getBody();
    }

    @Override
    public Long getBinExceptionCount() {
        ResponseEntity<Long> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigBinExceptionCountUri() + "?activeFlag=Y", HttpMethod.POST, buildHeaders(),
                Long.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Long.parseLong(String.valueOf(result.getBody()));
    }

    @Override
    public List<BinExceptionsModel> getBinExceptionList(int pageNo, int pageSize) {
        ResponseEntity<BinExceptionsModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigBinExceptionsUri() + "?activeFlag=Y&pageNo=" +
                        pageNo + "&pageSize=" + pageSize, HttpMethod.POST, buildHeaders(),
                BinExceptionsModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());
    }

    @Override
    public BinExceptionsModel getBinException(String binNumber) {

        ResponseEntity<BinExceptionsModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigGetBinExceptionUri() + "?binNumber=" + binNumber,
                HttpMethod.GET, buildHeaders(), BinExceptionsModel.class);
        return result.getBody();
    }

    @Override
    public Long getBinOnusCount() {
        ResponseEntity<Long> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigBinOnusMapCountUri() + "?activeFlag=Y", HttpMethod.POST, buildHeaders(),
                Long.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }

        return Long.parseLong(String.valueOf(result.getBody()));
    }

    @Override
    public List<BinOnusModel> getBinOnusMapList(int pageNo, int pageSize) {
        ResponseEntity<BinOnusModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigBinOnusMapsUri() + "?activeFlag=Y&pageNo=" +
                        pageNo + "&pageSize=" + pageSize, HttpMethod.POST, buildHeaders(),
                BinOnusModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());
    }

    @Override
    public BinOnusModel getBinOnusMap(String binNumber) {
        ResponseEntity<BinOnusModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigGetBinOnusMapUri() + "?binNumber=" + binNumber,
                HttpMethod.GET, buildHeaders(), BinOnusModel.class);
           /*if (result.getStatusCode() != HttpStatus.OK ) {
              throw new RuntimeException();
           }*/
        return result.getBody();
    }

    @Override
    public Long getAidCount() {
        ResponseEntity<Long> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigAidCountUri() + "?activeFlag=Y", HttpMethod.POST, buildHeaders(),
                Long.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }

        return Long.parseLong(String.valueOf(result.getBody()));
    }

    @Override
    public List<AidSchemeModel> getAidList(int pageNo, int pageSize) {
        ResponseEntity<AidSchemeModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigAidsUri() + "?activeFlag=Y&pageNo=" +
                        pageNo + "&pageSize=" + pageSize, HttpMethod.POST, buildHeaders(),
                AidSchemeModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());
    }

    @Override
    public AidSchemeModel getAid(String targetId) {
        ResponseEntity<AidSchemeModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigGetAidUri() + "?targetId=" + targetId,
                HttpMethod.GET, buildHeaders(), AidSchemeModel.class);

        return result.getBody();
    }

    @Override
    public AidSchemeModel getTargetByAid(String aid) {
        ResponseEntity<AidSchemeModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigGetTargetByAidUri() + "?aid=" + aid,
                HttpMethod.POST, buildHeaders(), AidSchemeModel.class);

        return result.getBody();
    }

    @Override
    public Long getMapsCount() {
        ResponseEntity<Long> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigMapsCountUri() + "?merchantStatus="+ActiveInactiveFlag.Active, HttpMethod.POST, buildHeaders(),
                Long.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Long.parseLong(String.valueOf(result.getBody()));
    }

    @Override
    public Long getMerchantsCount() {
        ResponseEntity<ResponseObj> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigMerchantsCountUri() + "?status=Active", HttpMethod.POST, buildHeaders(),
                ResponseObj.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Long.parseLong(String.valueOf(result.getBody().getData()));
    }

    @Override
    public List<MapsInfoModel> getMapsInfos(int pageNo, int pageSize) {

        ResponseEntity<MapsInfoModel[]> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigMapsUri() + "?activeFlag=Y&pageNo=" +
                        pageNo + "&pageSize=" + pageSize, HttpMethod.POST, buildHeaders(),
                MapsInfoModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());

    }

    public HttpEntity<String> buildHeaders() {
        HttpHeaders headers = new HttpHeaders();
        if (CollectionUtils.isEmpty(RbacUtil.getJwtTokenMap())) {
        	String token = initProps.getCmToken();
            RbacUtil.getJwtTokenMap().put(JWT_KEY, token);
            RbacUtil.getJwtTokenMap().put(USER_NAME_HEADER, initProps.getUserName());
            headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            logger.trace("Successfully initialized JWT Token Map");
        } else {
            headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        }
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add("instancename", initProps.getApplicstionInstnce());
        headers.add(USER_NAME_HEADER, initProps.getUserName());
        return new HttpEntity<>(headers);
    }

    public ResponseObj getResponseObj(String serviceKey, int expirationTime, String userName, String loginUri, String server) {
        HttpHeaders headers = new HttpHeaders();
        try {
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            String loginUrl = new StringBuilder().append(server).append(loginUri).toString();
            Auth authParams = new Auth();
            authParams.setServiceKey(serviceKey);
            authParams.setExpirationTime(expirationTime);
            authParams.setUserName(userName);
            Mono<ResponseObj> response = webClient.build().post().uri(loginUrl, headers)
                    .body(Mono.just(authParams), Auth.class).retrieve().bodyToMono(ResponseObj.class);
            return response.block();
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public String getToken(ResponseObj res) {
    	String token = null;
    	try {
    		if (res.getErrors() != null && !StringUtils.isBlank(res.getErrors())) {
    			throw new ValidationException(res.getErrors());
    		}
    		if (res.getStatusCode() != null && !res.getStatusCode().equalsIgnoreCase("R002")) {
    			throw new ValidationException(res.getStatusCode());
    		}
    		token = (String) res.getData();
    	} catch (ValidationException e) {
    		logger.error("Error : {} ", e.getMessage());
    		throw new ValidationException(res.getErrors());
    	} catch (Exception e) {
    		logger.error("Error : {} ", e.getMessage());
    		throw new ValidationException(res.getErrors());
    	}
    	return token;
    }

    @Override
    public List<SmartRouteConfigModel> getSmartRouteConfigs() {
        SmartRouteConfigModel[] models = fetchDataFromAPI(initProps.getConfigSmartRouteUri(), SmartRouteConfigModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<PaymentModesModel> getPaymentModes() {
        PaymentModesModel[] models = fetchDataFromAPI(initProps.getPaymentModesUri(), PaymentModesModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<PaymentModeOptionsModel> getPaymentModeOptions() {
        PaymentModeOptionsModel[] models = fetchDataFromAPI(initProps.getPaymentModeOptionsUri(), PaymentModeOptionsModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<TargetPaymentModesModel> getTargetPaymentModes() {
        TargetPaymentModesModel[] models = fetchDataFromAPI(initProps.getTargetPaymentModesUri(), TargetPaymentModesModel[].class);
        return Arrays.asList(models);
    }

    @Override
	public List<MftrBDKModel> getMftrBdks() {
		ResponseEntity<MftrBDKModel[]> result = restTemplate.exchange(
				initProps.getConfigServer() + initProps.getMftrBdkUri() , HttpMethod.GET, buildHeaders(),
				MftrBDKModel[].class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Arrays.asList(result.getBody());
	}


    @Override
    public List<TargetPaymentModeOptionsModel> getTargetPaymentModeOptions() {
        TargetPaymentModeOptionsModel[] models = fetchDataFromAPI(initProps.getTargetPaymentModeOptionsUri(), TargetPaymentModeOptionsModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<TargetLCRConfigModel> getTargetLCRConfigs() {
        TargetLCRConfigModel[] models = fetchDataFromAPI(initProps.getConfigTargetLCRUri(), TargetLCRConfigModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<MerchantPaymentModesModel> getMerchantPaymentModes() {
        MerchantPaymentModesModel[] models = fetchDataFromAPI(initProps.getMerchantPaymentModesUri(), MerchantPaymentModesModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<MerchantPaymentModeOptionsModel> getMerchantPaymentModeOptions() {
        MerchantPaymentModeOptionsModel[] models = fetchDataFromAPI(initProps.getMerchantPaymentModeOptionsUri(), MerchantPaymentModeOptionsModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<MerchantTargetPreferencesModel> getMerchantTargetPreferences() {
        MerchantTargetPreferencesModel[] models = fetchDataFromAPI(initProps.getMerchantTargetPreferencesUri(), MerchantTargetPreferencesModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<MerchantMasterModel> getMerchantMaster(int pageNo, int pageSize) {
        MerchantMasterModel[] models = fetchDataFromAPI(initProps.getMerchantMasterUri() + "status=Active&pageNo=" +
                pageNo + "&pageSize=" + pageSize, MerchantMasterModel[].class);
        return Arrays.asList(models);
    }

    @Override
    public List<TargetMerchantMasterModel> getTargetMerchantMaster(int pageNo, int pageSize) {
        TargetMerchantMasterModel[] models = fetchDataFromAPI(initProps.getTargetMerchantMasterUri() +"?status=Active&integrationType=PG&pageNo=" +
                pageNo + "&pageSize=" + pageSize, TargetMerchantMasterModel[].class);
        return Arrays.asList(models);
    }

    private <T> T fetchDataFromAPI(String uri, Class<T> className) {
        ResponseEntity<T> result = restTemplate.exchange(initProps.getConfigServer() + uri, HttpMethod.GET, buildHeaders(), className);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return result.getBody();
    }

    @Override
	public MapsInfoModel getMapsInfo(String key) {
        ResponseEntity<MapsInfoModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigGetMapUri() + "?merchantStatus=" +ActiveInactiveFlag.Active+"&key=" + key,
                HttpMethod.POST, buildHeaders(), MapsInfoModel.class);
        return result.getBody();
    }

    @Override
    public MerchantMasterModel getMerchantMasterModelInfo(String key) {
        ResponseEntity<MerchantMasterModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigGetMerchantUri() + "?status=" +ActiveInactiveFlag.Active+"&key=" + key,
                HttpMethod.POST, buildHeaders(), MerchantMasterModel.class);
        return result.getBody();
    }

    @Override
    public Long getTargetMerchantMasterCount() {
        ResponseEntity<ResponseObj> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigTargetMerMasterCountUri() + "?status=Active&integrationType=PG", HttpMethod.GET, buildHeaders(),
                ResponseObj.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return Long.parseLong(String.valueOf(result.getBody().getData()));
    }

    @Override
    public List<TargetMerchantMasterModel> getTargetMerchantMaster(String targetId, String mid, String tid,String status) {

        ResponseEntity<ResponseObj> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigTargetMerMasterUri() + "?targetId=" + targetId + "&mid=" + mid + "&tid=" + (!StringUtils.isBlank(tid)?tid:"") + "&status=" + (!StringUtils.isBlank(status)?status:""),
                HttpMethod.GET, buildHeaders(), ResponseObj.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            return null;
        }
        TargetMerchantMasterModel[] targetMerchantMasterModels = new ObjectMapper()
                .registerModule(new JavaTimeModule()).configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false).convertValue(result.getBody().getData(), TargetMerchantMasterModel[].class);
        if(targetMerchantMasterModels != null && targetMerchantMasterModels.length != 0){
            return Arrays.asList(targetMerchantMasterModels);
        }
        return null;
    }

    public TargetMerchantMasterModel getTargetMerchantMaster(String targetId, String mid, String tid) {

        ResponseEntity<TargetMerchantMasterModel> result = restTemplate.exchange(
                initProps.getConfigServer() + initProps.getConfigTargetMerMasterUri() + "?targetId=" + targetId + "&mid=" + mid + "&tid=" + tid,
                HttpMethod.GET, buildHeaders(), TargetMerchantMasterModel.class);
        if (result.getStatusCode() != HttpStatus.OK) {
            throw new RuntimeException();
        }
        return result.getBody();
    }

	@Override
	public List<RateLookupModel> getRateLookups() {
		RateLookupModel[] result = fetchDataFromAPI( initProps.getRateLookupUri() + "?activeFlag=" +ActiveFlag.Y, RateLookupModel[].class);
		return Arrays.asList(result);
	}
	
	@Override
	public List<BillingCurrencyModel> getBillingCurrencies() {
		BillingCurrencyModel[] result = fetchDataFromAPI(initProps.getBillingCurrenciesUri(), BillingCurrencyModel[].class);
		return Arrays.asList(result);
	}
}
