package com.isg.mw.cache.mgmt.service.impl;

import com.isg.mw.cache.mgmt.config.CacheConstants;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.BinOnusMapService;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.bi.BinOnusModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.utils.MaskingUtility;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


@Service
@EnableCaching
public class BinOnusMapServiceImpl implements BinOnusMapService {

    private final Logger LOG = LogManager.getLogger(getClass());

    @Getter
    private static final Map<BinOnusModel, BinOnusModel> binOnusCacheMap = new ConcurrentHashMap<>();

    @Autowired
    private InitRestClient initRestClient;

    @Value("${bin.fetch.flag}")
    private String binFetchFlag;


    @Override
    public Boolean updateBinOnusModel(BinOnusModel binOnusModel) {
        try {
            if (binOnusModel != null) {
                BinOnusModel valueBin = getBinOnusModel(binOnusModel);
                BinOnusModel key = constructKey(binOnusModel);
                if (ActiveFlag.N.equals(valueBin.getActiveFlag())) {
                    LOG.trace("BIN {} is now inactive, hence can be evicted", valueBin);
                    BinOnusModel removedBin = binOnusCacheMap.remove(key);
                    if (removedBin != null)
                        LOG.trace("BIN {} Evicted Successfully...", removedBin);
                    else
                        LOG.trace("BIN {} is inactive, hence not added in cache", binOnusModel);
                } else {
                    binOnusCacheMap.put(key, valueBin);
                    LOG.trace("BIN {} Inserted/Updated Successfully...", binOnusModel);
                }
            } else {
                LOG.info("BinOnusModel is Null");
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOG.error("An error occurred!", e);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }


    private BinOnusModel getBinOnusModel(BinOnusModel model) {
        BinOnusModel valueBinOnusModel = new BinOnusModel();
        valueBinOnusModel.setBinHigh(model.getBinHigh());
        valueBinOnusModel.setBinNumber(model.getBinNumber());
        valueBinOnusModel.setBinLow(model.getBinLow());
        valueBinOnusModel.setSchemeName(model.getSchemeName());
        valueBinOnusModel.setTargetId(model.getTargetId());
        valueBinOnusModel.setTargetName(model.getTargetName());
        valueBinOnusModel.setCardProgram(model.getCardProgram());
        valueBinOnusModel.setActiveFlag(model.getActiveFlag());
        valueBinOnusModel.setCardCategory(model.getCardCategory());
        valueBinOnusModel.setCardBrand(model.getCardBrand());
        return valueBinOnusModel;
    }


    @Override
    public BinOnusModel getBinInfoByCardNumber(String cardNumber) {
        LOG.info("Getting BinNumber in getBinInfoByCardNumber service {}", MaskingUtility.maskCardNumber(cardNumber));

        BinOnusModel binOnusModel = null;

        if (CacheConstants.BIN_FETCH_API.equals(binFetchFlag)) {
            binOnusModel = fetchBinOnusFromApi(cardNumber);
        } else if (CacheConstants.BIN_FETCH_CACHE.equals(binFetchFlag)) {
            binOnusModel = fetchBinOnusFromCache(cardNumber);
        }
        return binOnusModel;
    }

    private BinOnusModel fetchBinOnusFromApi(String cardNumber) {
        String binNum = cardNumber.substring(0, 9);
        LOG.trace("Fetching the BIN through API for card number {}", MaskingUtility.maskCardNumber(cardNumber));
        BinOnusModel bin = initRestClient.getBinOnusMap(binNum);
        if (bin == null) {
            binNum = StringUtils.rightPad(cardNumber, 19, '0');
            bin = initRestClient.getBinOnusMap(binNum);
        }
        return bin;
    }

    private BinOnusModel fetchBinOnusFromCache(String cardNumber) {
        BinOnusModel binInfo = null;
        try {
            BigInteger binNum = new BigInteger(cardNumber.substring(0, 9));
            BinOnusModel binModel = new BinOnusModel();
            binModel.setBinNumber(binNum);
            binModel.setBinLow(binNum);
            binInfo = binOnusCacheMap.get(binModel);

            if (binInfo == null) {
                binNum = new BigInteger(StringUtils.rightPad(cardNumber, 19, '0'));
                binModel.setBinNumber(binNum);
                binModel.setBinLow(binNum);
                binInfo = binOnusCacheMap.get(binModel);
            }

        } catch (Exception e) {
            LOG.error("An error occurred!", e);
        }
        return binInfo;
    }
    /**
     * This method constructs key.
     *
     * @param model BinOnusModel
     * @return key
     */
    private BinOnusModel constructKey(BinOnusModel model) {
        BinOnusModel keyBinOnusModel = new BinOnusModel();
        keyBinOnusModel.setBinHigh(model.getBinHigh());
        keyBinOnusModel.setBinLow(model.getBinLow());
        keyBinOnusModel.setBinNumber(model.getBinNumber());
        return keyBinOnusModel;
    }
}
