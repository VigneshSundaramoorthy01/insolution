package com.isg.mw.cache.mgmt.config;

import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.sr.SmartRouteConfigModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class InitSmartRouteCacheValue {
    private SmartRouteConfigModel smartRouteConfigModel;
    private SourceConfigModel sourceConfigModel;
    private long timeDiffInMillis;
}
