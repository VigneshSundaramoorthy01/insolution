package com.isg.mw.cache.mgmt.producer;

import com.isg.mw.core.model.tlm.TxnReconData;
import org.springframework.stereotype.Service;

@Service
public interface UpiFeederMessenger {

    void send(TxnReconData resultModel);

}
