package com.isg.mw.cache.mgmt.deserializers;

import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.sr.TargetPaymentModesMessage;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TargetPaymentModesDeserializer implements Deserializer<TargetPaymentModesMessage> {

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public TargetPaymentModesMessage deserialize(String topic, byte[] data) {
        TargetPaymentModesMessage targetPaymentModesMessage = null;
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois;
        try {
            ois = new ObjectInputStream(bis);
            targetPaymentModesMessage = (TargetPaymentModesMessage) ois.readObject();
            ois.close();
        } catch (IOException e) {
            logger.error("Error while deserializing TargetPaymentModesMessage object: {}", e);
        } catch (ClassNotFoundException e) {
            logger.error("Class in which the object to be deserialized not found: {}", e);
        }
        return targetPaymentModesMessage;
    }


}
