package com.isg.mtm.context;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Test;

import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.MTMInitializationException;
import com.isg.mw.mtm.transform.mastercard.MasterCardMessageTransformation;
import com.isg.mw.mtm.transform.pos.PosMessageTransformation;
import com.isg.mw.mtm.transform.rupay.RupayMessageTransformation;
import com.isg.mw.mtm.transform.visa.VisaMessageTransformation;

public class MessageTransformationContextTest {

	/*
	 * private String entityId = "Kotak"; private String epId = "Visa.Kotak";
	 * private String epMsgType = "0110"; private String msgFormat = "125"; private
	 * Class<VisaMessageTransformation> classNameVisa =
	 * VisaMessageTransformation.class; private
	 * Class<MasterCardMessageTransformation> classNameMaster =
	 * MasterCardMessageTransformation.class; private
	 * Class<RupayMessageTransformation> classNameRupay =
	 * RupayMessageTransformation.class; private Class<PosMessageTransformation>
	 * classNamePos = PosMessageTransformation.class; private String methodName =
	 * "setMti"; private String processingCode = "000000"; private String
	 * txnTypeName = "cashPOS.response";
	 * 
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Test public void initMTMVisaTest() { TransactionTypeConfig
	 * transactionTypeConfig = new TransactionTypeConfig(epMsgType, processingCode,
	 * txnTypeName); MessageTransformationConfig transformationConfig =
	 * getMessageTransformationConfigForVisa();
	 * 
	 * Map<Integer, String> tmmConfig = transformationConfig.getTmmConfig();
	 * 
	 * Map<Integer, String> innMap1 = (Map<Integer, String>)
	 * tmmConfig.values().toArray()[0];
	 * 
	 * MessageTransformationContext.initMTM(getsourceConfigList(),
	 * getTargetConfigModel(), getMessageTransformationConfigModel());
	 * MessageTransformationConfig config =
	 * MessageTransformationContext.getMessageTransformationConfig(entityId, epId,
	 * transactionTypeConfig);
	 * 
	 * Map<Integer, String> innMap2 = (Map<Integer, String>)
	 * config.getTmmConfig().values().toArray()[0];
	 * 
	 * assertEquals(transformationConfig.getMethodName(), config.getMethodName());
	 * assertEquals(transformationConfig.getClass(), config.getClass());
	 * assertEquals(transformationConfig.getBusinessRuleClass(),
	 * config.getBusinessRuleClass());
	 * assertEquals(transformationConfig.getMsgFormat(), config.getMsgFormat());
	 * assertEquals(innMap1.get(1), innMap2.get(1));
	 * 
	 * }
	 * 
	 * private List<MessageTransformationConfigModel>
	 * getMessageTransformationConfigModel() {
	 * List<MessageTransformationConfigModel> scModels = new ArrayList<>(); return
	 * scModels; }
	 * 
	 * private List<SourceConfigModel> getsourceConfigList() {
	 * List<SourceConfigModel> scModels = new ArrayList<>(); return scModels; }
	 * 
	 * private List<TargetConfigModel> getTargetConfigModel() {
	 * List<TargetConfigModel> trModels = new ArrayList<>(); return trModels; }
	 * 
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Test public void initMTMMasterCardTest() throws MTMInitializationException {
	 * TransactionTypeConfig trConfig = new TransactionTypeConfig(epMsgType,
	 * processingCode, txnTypeName); MessageTransformationConfig
	 * transformationConfig = getMessageTransformationConfigForMaster();
	 * 
	 * Map<Integer, String> tmmConfig = transformationConfig.getTmmConfig();
	 * 
	 * Map<Integer, String> innMap1 = (Map<Integer, String>)
	 * tmmConfig.values().toArray()[0];
	 * 
	 * MessageTransformationContext.initMTM(getsourceConfigList(),
	 * getTargetConfigModel(), getMessageTransformationConfigModel());
	 * MessageTransformationConfig config =
	 * MessageTransformationContext.getMessageTransformationConfig(entityId, epId,
	 * trConfig);
	 * 
	 * Map<Integer, String> innMap2 = (Map<Integer, String>)
	 * config.getTmmConfig().values().toArray()[0];
	 * 
	 * assertEquals(transformationConfig.getMethodName(), config.getMethodName());
	 * assertEquals(transformationConfig.getClass(), config.getClass());
	 * assertEquals(transformationConfig.getBusinessRuleClass(),
	 * config.getBusinessRuleClass());
	 * assertEquals(transformationConfig.getMsgFormat(), config.getMsgFormat());
	 * assertEquals(innMap1.get(1), innMap2.get(1)); }
	 * 
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Test public void initMTMRupayTest() throws MTMInitializationException {
	 * TransactionTypeConfig trConfig = new TransactionTypeConfig(epMsgType,
	 * processingCode, txnTypeName); MessageTransformationConfig
	 * transformationConfig = getMessageTransformationConfigForMaster();
	 * 
	 * Map<Integer, String> tmmConfig = transformationConfig.getTmmConfig();
	 * 
	 * Map<Integer, String> innMap1 = (Map<Integer, String>)
	 * tmmConfig.values().toArray()[0];
	 * 
	 * MessageTransformationContext.initMTM(getsourceConfigList(),
	 * getTargetConfigModel(), getMessageTransformationConfigModel());
	 * MessageTransformationConfig config =
	 * MessageTransformationContext.getMessageTransformationConfig(entityId, epId,
	 * trConfig);
	 * 
	 * Map<Integer, String> innMap2 = (Map<Integer, String>)
	 * config.getTmmConfig().values().toArray()[0];
	 * 
	 * assertEquals(transformationConfig.getMethodName(), config.getMethodName());
	 * assertEquals(transformationConfig.getClass(), config.getClass());
	 * assertEquals(transformationConfig.getBusinessRuleClass(),
	 * config.getBusinessRuleClass());
	 * assertEquals(transformationConfig.getMsgFormat(), config.getMsgFormat());
	 * assertEquals(innMap1.get(1), innMap2.get(1)); }
	 * 
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Test public void initMTMPosTest() throws MTMInitializationException {
	 * TransactionTypeConfig trConfig = new TransactionTypeConfig(epMsgType,
	 * processingCode, txnTypeName); MessageTransformationConfig
	 * transformationConfig = getMessageTransformationConfigForMaster();
	 * 
	 * Map<Integer, String> tmmConfig = transformationConfig.getTmmConfig();
	 * 
	 * Map<Integer, String> innMap1 = (Map<Integer, String>)
	 * tmmConfig.values().toArray()[0];
	 * 
	 * MessageTransformationContext.initMTM(getsourceConfigList(),
	 * getTargetConfigModel(), getMessageTransformationConfigModel());
	 * MessageTransformationConfig config =
	 * MessageTransformationContext.getMessageTransformationConfig(entityId, epId,
	 * trConfig);
	 * 
	 * Map<Integer, String> innMap2 = (Map<Integer, String>)
	 * config.getTmmConfig().values().toArray()[0];
	 * 
	 * assertEquals(transformationConfig.getMethodName(), config.getMethodName());
	 * assertEquals(transformationConfig.getClass(), config.getClass());
	 * assertEquals(transformationConfig.getBusinessRuleClass(),
	 * config.getBusinessRuleClass());
	 * assertEquals(transformationConfig.getMsgFormat(), config.getMsgFormat());
	 * assertEquals(innMap1.get(1), innMap2.get(1)); }
	 * 
	 * @Test public void initMTMTestNull() throws MTMInitializationException {
	 * String errMsg =
	 * "Errow while invoking getTmmConfig() on class: class com.isg.mtm.context.MessageContext"
	 * ; String message = null;
	 * MessageTransformationContext.initMTM(getsourceConfigList(),
	 * getTargetConfigModel(), getMessageTransformationConfigModel());
	 * 
	 * assertEquals(errMsg, message); }
	 * 
	 * public MessageTransformationConfig getMessageTransformationConfigForPos() {
	 * MessageTransformationConfig msgConfig = new MessageTransformationConfig();
	 * msgConfig.setBusinessRuleClass(classNamePos);
	 * msgConfig.setMethodName(methodName); msgConfig.setMsgFormat(msgFormat);
	 * msgConfig.setTmmConfig(getTmmMap1());
	 * 
	 * Map<String, MessageTransformationConfig> msgTypeMTConfigMap = new
	 * HashMap<>(); msgTypeMTConfigMap.put(epMsgType, msgConfig);
	 * 
	 * Map<String, Map<String, MessageTransformationConfig>> epIdMsgTypeMap = new
	 * HashMap<>(); epIdMsgTypeMap.put(epId, msgTypeMTConfigMap);
	 * 
	 * MsgConfig.put(entityId + "." + epId, epIdMsgTypeMap);
	 * 
	 * return MsgConfig.get(entityId + "." + epId).get(epId).get(epMsgType);
	 * 
	 * }
	 * 
	 * public MessageTransformationConfig getMessageTransformationConfigForVisa() {
	 * MessageTransformationConfig msgConfig = new MessageTransformationConfig();
	 * msgConfig.setBusinessRuleClass(classNameVisa);
	 * msgConfig.setMethodName(methodName); msgConfig.setMsgFormat(msgFormat);
	 * msgConfig.setTmmConfig(getTmmMap1());
	 * 
	 * Map<String, MessageTransformationConfig> msgTypeMTConfigMap = new
	 * HashMap<>(); msgTypeMTConfigMap.put(epMsgType, msgConfig);
	 * 
	 * Map<String, Map<String, MessageTransformationConfig>> epIdMsgTypeMap = new
	 * HashMap<>(); epIdMsgTypeMap.put(epId, msgTypeMTConfigMap);
	 * 
	 * MsgConfig.put(entityId + "." + epId, epIdMsgTypeMap);
	 * 
	 * return MsgConfig.get(entityId + "." + epId).get(epId).get(epMsgType);
	 * 
	 * }
	 * 
	 * // maps for mastercard public MessageTransformationConfig
	 * getMessageTransformationConfigForMaster() { MessageTransformationConfig
	 * msgConfig = new MessageTransformationConfig();
	 * msgConfig.setBusinessRuleClass(classNameMaster);
	 * msgConfig.setMethodName(methodName); msgConfig.setMsgFormat(msgFormat);
	 * msgConfig.setTmmConfig(getTmmMap());
	 * 
	 * Map<String, MessageTransformationConfig> msgTypeMTConfigMap = new
	 * HashMap<>(); msgTypeMTConfigMap.put(epMsgType, msgConfig);
	 * 
	 * Map<String, Map<String, MessageTransformationConfig>> epIdMsgTypeMap = new
	 * HashMap<>(); epIdMsgTypeMap.put(epId, msgTypeMTConfigMap);
	 * 
	 * MsgConfig.put(entityId + "." + epId, epIdMsgTypeMap);
	 * 
	 * return MsgConfig.get(entityId + "." + epId).get(epId).get(epMsgType);
	 * 
	 * }
	 * 
	 * // maps for rupay public MessageTransformationConfig
	 * getMessageTransformationConfigForRupay() { MessageTransformationConfig
	 * msgConfig = new MessageTransformationConfig();
	 * msgConfig.setBusinessRuleClass(classNameRupay);
	 * msgConfig.setMethodName(methodName); msgConfig.setMsgFormat(msgFormat);
	 * msgConfig.setTmmConfig(getTmmMapRupay());
	 * 
	 * Map<String, MessageTransformationConfig> msgTypeMTConfigMap = new
	 * HashMap<>(); msgTypeMTConfigMap.put(epMsgType, msgConfig);
	 * 
	 * Map<String, Map<String, MessageTransformationConfig>> epIdMsgTypeMap = new
	 * HashMap<>(); epIdMsgTypeMap.put(epId, msgTypeMTConfigMap);
	 * 
	 * MsgConfig.put(entityId + "." + epId, epIdMsgTypeMap);
	 * 
	 * return MsgConfig.get(entityId + "." + epId).get(epId).get(epMsgType);
	 * 
	 * }
	 * 
	 * // tmmCongif for Rupay public Map<Integer, String> getTmmMapRupay() {
	 * Map<Integer, String> map = new HashMap<>(); map.put(1, "setBitMap");
	 * map.put(2, "setPan"); map.put(3, "setProcessingCode3"); map.put(4,
	 * "setTxnAmt");
	 * 
	 * return map; }
	 * 
	 * private static final Map<String, Map<String, Map<String,
	 * MessageTransformationConfig>>> MsgConfig = new ConcurrentHashMap<>();
	 * 
	 * public Map<Integer, String> getTmmMap() { Map<Integer, String> map = new
	 * HashMap<>(); map.put(1, "setBitMap"); map.put(2, "setPan"); map.put(3,
	 * "setProcessingCode"); map.put(4, "setTxnAmt");
	 * 
	 * return map; }
	 * 
	 * public Map<Integer, String> getTmmMap1() { Map<Integer, String> map = new
	 * HashMap<>(); map.put(1, "setBitMap"); map.put(2, "setPan"); map.put(3,
	 * "setProcessingCode"); map.put(4, "setTxnAmt");
	 * 
	 * return map; }
	 */

}
