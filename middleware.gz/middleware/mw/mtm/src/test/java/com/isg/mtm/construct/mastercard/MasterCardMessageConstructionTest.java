package com.isg.mtm.construct.mastercard;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.mastercard.MasterCardMessageConstruction;

//@RunWith(MockitoJUnitRunner.class)
//@TestPropertySource(locations = "classpath:mtm-config_en.properties")
public class MasterCardMessageConstructionTest {

	// // DE 52
//	
//	@Value ("${fetch.original.txn.retries}")
//	private static int fetchOriginalTransactionRetries;
//
//	@Mock
//	private SwitchBaseMessageConstruction switchBaseMessageConstruction;
//
//	@InjectMocks
//	private MasterCardMessageConstruction masterConstruction;
//
//	@Mock
//	private MapsInfoService mapsService;
//
//	@Mock
//	private HsmProcessorService hsmService;
//
//	@Mock
//	private MapsInfoModel maps;
//
//	@Before
//	public void init() {
//		MockitoAnnotations.initMocks(this);
////		ReflectionTestUtils.setField(switchBaseMessageConstruction, fetchOriginalTransactionRetries, 3);
//		ReflectionTestUtils.setField(switchBaseMessageConstruction, "fetch.original.txn.timeout", 1000L);
//		ReflectionTestUtils.setField(switchBaseMessageConstruction, "fetch.original.txn.retry.delay", 500L);
//	}
//
//	private TransactionMessageModel getSourceTmm() {
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setTransmissionTime("100");
//		return sourceTmm;
//	}
//
//	public MapsInfoModel getMerchantDataInfo() {
//		MapsInfoModel mar = new MapsInfoModel();
//		mar.setMerchantName("xyz");
//		mar.setMerchantCity("mumbai");
//		mar.setMerchantZipCode("10000");
//		mar.setAcquirerCurrencyCode("1234");
//		mar.setForwardingInstitutionId("123456");
//		return mar;
//	}
//
//	// // DE 1
//
//	@Test
//	public void setBitMapTest() {
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setBitMap("20002000");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		assertEquals("20002000", masterConstruction.getSourceTmm().getBitMap());
//	}
//
//	// // DE 2
//
//	@Test
//	public void setPanTest() {
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//
//		Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
//				.thenReturn("0005391699020177742D22022261000067799999");
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPan("ABCD1234");
//		sourceTmm.setTrack1Data("1234");
//		sourceTmm.setTrack2Data(null);
//		sourceTmm.setEntityId("500");
//		sourceTmm.setSecurityControlInfo("xyz");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setPan(20);
//
//		assertEquals("0005391699020177742", masterConstruction.getTargetTmm().getPan());
//	}
//
//	@Test
//	public void setPanTestException() {
//		String errMsg = "Error while constructing data element: 20, name: PAN";
//		String message = null;
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//
//		Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("000");
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPan("ABCD1234");
//		sourceTmm.setTrack1Data("1234");
//		sourceTmm.setTrack2Data("308");
//		sourceTmm.setEntityId("500");
//		sourceTmm.setSecurityControlInfo("xyz");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		try {
//			masterConstruction.setPan(20);
//		} catch (Exception e) {
//			message = e.getMessage();
//		}
//		assertEquals(errMsg, message);
//	}
//
//	// // DE 3
//
//	@Test
//	public void setProcessingCodeTest() {
//		masterConstruction.setTargetMsgTypeId("000000");
//		masterConstruction.setProcessingCode(20);
//		assertEquals("000000", masterConstruction.getTargetTmm().getProcessingCode());
//	}
//
//	// // DE 4
//
//	@Test
//	public void setTxnAmtTest() {
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setTxnAmt("000000000100");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setTxnAmt(20);
//
//		assertEquals("000000000100", masterConstruction.getTargetTmm().getTxnAmt());
//	}
//
//	// // DE 5
//
//	@Test
//	public void setSettlementAmt() { // input  
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setSettlementAmt("000000000200");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setSettlementAmt(5);
//
//		assertEquals("000000000200", masterConstruction.getSourceTmm().getSettlementAmt());
//	}
//
//	// // DE 6
//
//	@Test
//	public void setCardHolderBillingAmtTest() { // input
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCardHolderBillingAmt("000000000300");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setCardHolderBillingAmt(20);
//
//		assertEquals("000000000300", masterConstruction.getSourceTmm().getCardHolderBillingAmt());
//	}
//
//	// // DE 7
//
//	@Test
//	public void setTransmissionTimeTest() {
//		String regex = "(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
//
//		masterConstruction.setTransmissionTime(5);
//
//		assertTrue("Not in expected pattern MMddhhmmss",
//				Pattern.matches(regex, masterConstruction.getTargetTmm().getTransmissionTime()));
//
//	}
//
//	// // DE 8
//
//	@Test
//	public void setCardHolderBillingTest() { // input
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCardHolderBillingFee("4000");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setCardHolderBillingFee(20);
//
//		assertEquals("4000", masterConstruction.getSourceTmm().getCardHolderBillingFee());
//	}
//
//	// // DE 9
//
//	@Test
//	public void setSettlementConversionRateTest() { // input
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setSettlementConversionRate("500");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setSettlementConversionRate(20);
//
//		assertEquals("500", masterConstruction.getSourceTmm().getSettlementConversionRate());
//	}
//
//	// // DE 10
//
//	@Test
//	public void setCardHolderBillingConversionRateTest() { // input
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCardHolderBillingConversionRate("600");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setCardHolderBillingConversionRate(10);
//
//		assertEquals("600", masterConstruction.getSourceTmm().getCardHolderBillingConversionRate());
//	}
//
//	// // DE 11
//
//	@Test
//	public void setStanTest() {
//		masterConstruction.setStan(11);
//
//		assertEquals(6, masterConstruction.getTargetTmm().getStan().length());
//	}
//
//	// // DE 12
//
//	@Test public void setLocalTxnTimeTest() { // input 
//		String regex = "^(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
//	  masterConstruction.setLocalTxnTime(13);
//	 
//	  assertTrue("Not in expected pattern hhmmss", Pattern.matches(regex,
//	  masterConstruction.getTargetTmm().getLocalTxnTime())); }
//
//	// // DE 13
//
//	@Test public void setLocalTxnDateTest() { // input 
//		String regex = "^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
//	  masterConstruction.setLocalTxnDate(13);
//	 
//	  assertTrue("Not in expected pattern MMdd", Pattern.matches(regex,
//	  masterConstruction.getTargetTmm().getLocalTxnDate())); }
//
//	// // DE 14
//
//	@Test
//	public void setExpirationDateTest() { // input 
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setExpirationDate("05052020");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setExpirationDate(14);
//
//		assertEquals("05052020", masterConstruction.getTargetTmm().getExpirationDate());
//	}
//
//	// // DE 15
//
//	@Test
//	public void setSettlementDateTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementDate("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementDate(15);
//		assertEquals("1234", masterConstruction.getSourceTmm().getSettlementDate());
//	}
//
//	// // DE 16
//
//	@Test
//	public void setConversionDateTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setConversionDate("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setConversionDate(16);
//		assertEquals("1234", masterConstruction.getSourceTmm().getConversionDate());
//	}
//
//	// // DE 17
//
//	@Test
//	public void setCaptureDateTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setCaptureDate("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCaptureDate(16);
//		assertEquals("1234", masterConstruction.getSourceTmm().getCaptureDate());
//	}
//
//	// // DE 18
//
//	@Test
//	public void setMerchantTypeTest() { // input
//		masterConstruction.setTargetMsgType("0200");
//		masterConstruction.setTargetMsgTypeId("010000");
//
//		masterConstruction.setMerchantType(18);
//
//		assertEquals("6010", masterConstruction.getTargetTmm().getMerchantType());
//	}
//
//	// // DE 19
//
//	@Test
//	public void setAquirerCountryCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAquirerCountryCode("356");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAquirerCountryCode(19);
//		assertEquals("356", masterConstruction.getSourceTmm().getAquirerCountryCode());
//
//	}
//
//	// // DE 20
//
//	@Test
//	public void setPanExtendedCountryCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPanExtendedCountryCode("356");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPanExtendedCountryCode(20);
//		assertEquals("356", masterConstruction.getSourceTmm().getPanExtendedCountryCode());
//
//	}
//
//	// // DE 21
//
//	@Test
//	public void setPanForwardingCountryCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPanForwardingCountryCode("840");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPanForwardingCountryCode(21);
//		assertEquals("840", masterConstruction.getSourceTmm().getPanForwardingCountryCode());
//	}
//
//	// // DE 22
//
//	@Test
//	public void setPosEntryModeTest() {
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setPosEntryMode("901");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setPosEntryMode(22);
//		assertEquals("901", masterConstruction.getTargetTmm().getPosEntryMode());
//
//		// input 2 sourceTmm.setPosEntryMode("011");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPosEntryMode(22);
//		assertEquals("011", masterConstruction.getTargetTmm().getPosEntryMode());
//
//		// input 3 sourceTmm.setPosEntryMode("021");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPosEntryMode(22);
//		assertEquals("901", masterConstruction.getTargetTmm().getPosEntryMode());
//
//		// input 4 sourceTmm.setPosEntryMode("051");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPosEntryMode(22);
//		assertEquals("051", masterConstruction.getTargetTmm().getPosEntryMode());
//
//		// input 5 sourceTmm.setPosEntryMode("071");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPosEntryMode(22);
//		assertEquals("071", masterConstruction.getTargetTmm().getPosEntryMode());
//
//		// input 6 sourceTmm.setPosEntryMode("801");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPosEntryMode(22);
//		assertEquals("801", masterConstruction.getTargetTmm().getPosEntryMode());
//
//	}
//
//	// // DE 23
//
//	@Test
//	public void setCardSeqNoTest() { // input
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setIccData(
//				"9F02060000000030009F03060000000000008407A000000003101082023C009F360201F79F0702FF009F26080F380F214766ADF89F2701809F34034203009F1E0830313031353734349F100706010A03A0A8049F0902008C9F3303E0F0C89F1A0203569F350122950508800400005F2A0203565F3401019A031912109C01009F3704B1F0394E9F4104000000319F530152");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setTargetMsgType("0280");
//		masterConstruction.setTargetMsgTypeId("510090");
//
//		masterConstruction.setCardSeqNo(20);
//
//		assertEquals("001", masterConstruction.getTargetTmm().getCardSeqNo());
//	}
//
//	// // DE 24
//
//	@Test
//	public void setNetworkInternationalIdTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNiiId("12345");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNiiId(24);
//
//		assertEquals("12345", masterConstruction.getSourceTmm().getNiiId());
//
//	}
//
//	// // DE 25
//
//	@Test
//	public void setPosConditionCodeTest() {
//		masterConstruction.setPosConditionCode(25);
//		assertNull(masterConstruction.getTargetTmm().getPosConditionCode());
//	}
//
//	// // DE 26
//
//	@Test
//	public void setPosCaptureCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPosCaptureCode("123");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPosCaptureCode(26);
//		assertEquals("123", masterConstruction.getSourceTmm().getPosCaptureCode());
//	}
//
//	// // DE 27
//
//	@Test
//	public void setAuthIdResLengthTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAuthIdResLength("3");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAuthIdResLength(27);
//		assertEquals("3", masterConstruction.getSourceTmm().getAuthIdResLength());
//	}
//
//	// // DE 28
//
//	@Test
//	public void setTxnFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTxnFee("100");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTxnFee(28);
//		assertEquals("100", masterConstruction.getSourceTmm().getTxnFee());
//	}
//
//	// // DE 29
//
//	@Test
//	public void setSettlementFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementFee("500");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementFee(29);
//		assertEquals("500", masterConstruction.getSourceTmm().getSettlementFee());
//
//	}
//
//	// // DE 30
//
//	@Test
//	public void setTxnProcessingFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTxnProcessingFee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTxnProcessingFee(30);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTxnProcessingFee());
//	}
//
//	// // DE 31
//
//	@Test
//	public void setSettlementProcessingFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementProcessingFee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementProcessingFee(31);
//		assertEquals("1234", masterConstruction.getSourceTmm().getSettlementProcessingFee());
//	}
//
//	// // DE 32
//
//	@Test
//	public void setAquirerIdCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//		sourceTmm.setAquirerIdCode("700");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAquirerIdCode(20);
//		assertEquals("123456", masterConstruction.getTargetTmm().getAquirerIdCode());
//	}
//
//	// // DE 33
//
//	@Test
//	public void setForwardingInstIdCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//		sourceTmm.setForwardingInstIdCode("200");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setForwardingInstIdCode(33);
//		assertEquals("123456", masterConstruction.getTargetTmm().getForwardingInstIdCode());
//	}
//
//	// // DE 34
//
//	@Test
//	public void setPanExtendedTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPanExtended("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPanExtended(40);
//		assertEquals("1234", masterConstruction.getSourceTmm().getPanExtended());
//
//	}
//
//	// // DE 35
//
//	@Test
//	public void setTrack2DataTest() { // input
//		Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("1234");
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTrack2Data("333");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setTrack2Data(35);
//
//		assertEquals("1234", masterConstruction.getTargetTmm().getTrack2Data());
//	}
//
//	// // DE 36
//
//	@Test
//	public void setTrack3DataTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTrack3Data("123456D1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTrack3Data(40);
//		assertEquals("123456D1234", masterConstruction.getSourceTmm().getTrack3Data());
//	}
//
//	// // DE 37
//
//	@Test
//	public void setRetrievalRefNoTest() {
//		masterConstruction.setStan(30);
//		masterConstruction.setRetrievalRefNo(20);
//
//		assertEquals(12, masterConstruction.getTargetTmm().getRetrievalRefNo().length());
//	}
//
//	// // DE 38
//
//	@Test
//	public void setAuthIdResTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAuthIdRes("123456");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAuthIdRes(40);
//		assertEquals("123456", masterConstruction.getSourceTmm().getAuthIdRes());
//	}
//
//	// // DE 39
//
//	@Test
//	public void setResCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setResCode("00");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setResCode(40);
//		assertEquals("00", masterConstruction.getSourceTmm().getResCode());
//	}
//
//	// // DE 40
//
//	@Test
//	public void setServiceRestrictionCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setServiceRestrictionCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setServiceRestrictionCode(40);
//		assertEquals("1234", masterConstruction.getSourceTmm().getServiceRestrictionCode());
//	}
//
//	// // DE 41
//
//	@Test
//	public void setCardAcceptorTerminalIdTest() { // input
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCardAcceptorTerminalId("1432");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setCardAcceptorTerminalId(20);
//
//		assertEquals("1432", masterConstruction.getSourceTmm().getCardAcceptorTerminalId());
//	}
//
//	// // DE 42
//
//	@Test
//	public void setCardAcceptorIdTest() { // input 
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCardAcceptorId("14");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setCardAcceptorId(20);
//
//		assertEquals("14", masterConstruction.getSourceTmm().getCardAcceptorId());
//	}
//
//	// // DE 43
//
//	@Test
//	public void setCardAcceptorInfoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCardAcceptorInfo(43);
//		assertEquals("xyz                    mumbai        null",
//				masterConstruction.getTargetTmm().getCardAcceptorInfo());
//	}
//
//	// // DE 44
//
//	@Test
//	public void setAdditionalResDataTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAdditionalResData("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAdditionalResData(44);
//		assertEquals("1234", masterConstruction.getSourceTmm().getAdditionalResData());
//	}
//
//	// // DE 45
//
//	@Test
//	public void setTrack1DataTest() {
//
//		Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
//				.thenReturn("12345");
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTrack1Data("123");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTrack1Data(20);
//
//		assertEquals("12345", masterConstruction.getTargetTmm().getTrack1Data());
//	}
//
//	// // DE 46
//
//	@Test
//	public void setIsoAdTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setIsoAd("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setIsoAd(46);
//		assertEquals("1234", masterConstruction.getSourceTmm().getIsoAd());
//	}
//
//	// // DE 47
//
//	@Test
//	public void setNationalAdTest() {
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNationalAd("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNationalAd(47);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNationalAd());
//	}
//
//	// // DE 49
//
//	@Test
//	public void setTxnCurrencyCodeTest() {
//
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTxnCurrencyCode("3333");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setTxnCurrencyCode(20);
//
//		assertEquals("1234", masterConstruction.getTargetTmm().getTxnCurrencyCode());
//	}
//
//	// // DE 50
//
//	@Test
//	public void setSettlementCurrenyCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementCurrenyCode("356");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementCurrenyCode(54);
//		assertEquals("356", masterConstruction.getSourceTmm().getSettlementCurrenyCode());
//	}
//
//	// // DE 51
//
//	@Test
//	public void setCardHolderBillingCurrencyCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setCardHolderBillingCurrencyCode("356");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCardHolderBillingCurrencyCode(54);
//		assertEquals("356", masterConstruction.getSourceTmm().getCardHolderBillingCurrencyCode());
//	}
//
//	// /*// DE 52
//
////	@Test
////	public void setPinTest() {
////
////		Mockito.when(hsmService.pinTranslation(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
////				Mockito.any(), Mockito.any())).thenReturn("280595");
////
////		masterConstruction.setPin(20);
////
////		assertEquals("280595", masterConstruction.getTargetTmm().getPin());
////	}
//
//	// DE 53
//	@Test
//	public void setSecurityControlInfoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSecurityControlInfo("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSecurityControlInfo(54);
//		assertEquals("1234", masterConstruction.getSourceTmm().getSecurityControlInfo());
//	}
//
//	// DE 54
//	@Test
//	public void setAdditionalAmountsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAdditionalAmounts("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAdditionalAmounts(54);
//		assertEquals("1234", masterConstruction.getSourceTmm().getAdditionalAmounts());
//	}
//
//	// DE 55
//	@Test
//	public void setIccDataTest() {
//		// input
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setIccData("123");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setIccData(20);
//
//		assertEquals("123", masterConstruction.getSourceTmm().getIccData());
//	}
//
//	// DE 57
//	@Test
//	public void setReserverd57Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved57("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved57(57);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved57());
//	}
//
//	// DE 58
//	@Test
//	public void setReserved58Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved58("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved58(58);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved58());
//	}
//
//	// DE 59
//	@Test
//	public void setReserverd59Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved59("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved59(59);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved59());
//	}
//
//	// DE 60
//	@Test
//	public void setTerminalDataTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTerminalData("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTerminalData(60);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTerminalData());
//
//	}
//
//	// DE 61
//	@Test
//	public void setCiadTest() {
//		// input
//
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCiad("2032102000800356");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		// input 1
//		masterConstruction.setTargetMsgType("0200");
//		masterConstruction.setTargetMsgTypeId("510000");
//
//		// calling the business method to test
//		masterConstruction.setCiad(61);
//
//		assertEquals("203210200080035610000", masterConstruction.getTargetTmm().getCiad());
//
//	}
//
//	@Test
//	public void setCiadTest2() {
//
//		// input 2
//		Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(getMerchantDataInfo());
//
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setCiad("2032102000800356");
//		masterConstruction.setSourceTmm(sourceTmm);
//
//		masterConstruction.setTargetMsgType("9878");
//		masterConstruction.setTargetMsgTypeId("888888");
//
//		// calling the business method to test
//		masterConstruction.setCiad(61);
//
//		assertEquals("000000000080035610000", masterConstruction.getTargetTmm().getCiad());
//	}
//
//	// DE 62
//	@Test
//	public void setPostalCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPostalCode("123456");
//		;
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPostalCode(63);
//		assertEquals("123456", masterConstruction.getSourceTmm().getPostalCode());
//	}
//
//	// DE 63
//	@Test
//	public void setAtmPinOffsetDataTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAtmPinOffsetData("123");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAtmPinOffsetData(63);
//		assertEquals("123", masterConstruction.getSourceTmm().getAtmPinOffsetData());
//	}
//
//	// DE 64
//	@Test
//	public void setMsgAuthCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setMsgAuthCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setMsgAuthCode(64);
//		assertEquals("1234", masterConstruction.getSourceTmm().getMsgAuthCode());
//	}
//
//	// DE 65
//	@Test
//	public void setExtendedBitmapIndicatorTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setExtendedBitmapIndicator("1");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setExtendedBitmapIndicator(65);
//		assertEquals("1", masterConstruction.getSourceTmm().getExtendedBitmapIndicator());
//	}
//
//	// DE 66
//	@Test
//	public void setSettlementCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementCode("1234");
//
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementCode(66);
//		assertEquals("1234", masterConstruction.getSourceTmm().getSettlementCode());
//	}
//
//	// DE 67
//	@Test
//	public void setExtendedPaymentCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setExtendedPaymentCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setExtendedPaymentCode(67);
//		assertEquals("1234", masterConstruction.getSourceTmm().getExtendedPaymentCode());
//	}
//
//	// DE 68
//	@Test
//	public void setReceiverCountryCode() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReceiverCountryCode("356");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReceiverCountryCode(69);
//		assertEquals("356", masterConstruction.getSourceTmm().getReceiverCountryCode());
//
//	}
//
//	// DE 69
//	@Test
//	public void setSettlementCountryCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementCountryCode("356");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementCountryCode(69);
//		assertEquals("356", masterConstruction.getSourceTmm().getSettlementCountryCode());
//	}
//
//	// DE 70
//	@Test
//	public void setNetworkMgmtInfoCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNetworkMgmtInfoCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNetworkMgmtInfoCode(70);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNetworkMgmtInfoCode());
//	}
//
//	// DE 71
//	@Test
//	public void setMsgNoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setMsgNo("123");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setMsgNo(71);
//		assertEquals("123", masterConstruction.getSourceTmm().getMsgNo());
//	}
//
//	// DE 72
//	@Test
//	public void setLastMsgNoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setLastMsgNo("123");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setLastMsgNo(72);
//		assertEquals("123", masterConstruction.getSourceTmm().getLastMsgNo());
//	}
//
//	// DE 73
//	@Test
//	public void setActionDateTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setActionDate("30062020");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setActionDate(73);
//		assertEquals("30062020", masterConstruction.getSourceTmm().getActionDate());
//	}
//
//	// DE 74
//	@Test
//	public void setNoOfCreditsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNoOfCredits("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNoOfCredits(74);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNoOfCredits());
//	}
//
//	// DE 75
//	@Test
//	public void setCreditsReversalNoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setCreditsReversalNo("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCreditsReversalNo(75);
//		assertEquals("1234", masterConstruction.getSourceTmm().getCreditsReversalNo());
//	}
//
//	// DE 76
//	@Test
//	public void setNoOfDebitsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNoOfDebits("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNoOfDebits(76);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNoOfDebits());
//	}
//
//	// DE 77
//	@Test
//	public void setDebitsReversalNoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setDebitsReversalNo("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setDebitsReversalNo(77);
//		assertEquals("1234", masterConstruction.getSourceTmm().getDebitsReversalNo());
//	}
//
//	// DE 78
//	@Test
//	public void setTransferNoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTransferNo("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTransferNo(78);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTransferNo());
//	}
//
//	// DE 79
//	@Test
//	public void setTransferReversalNoTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTransferReversalNo("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTransferReversalNo(79);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTransferReversalNo());
//	}
//
//	// DE 80
//	@Test
//	public void setNoOfInquiriesTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNoOfInquiries("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNoOfInquiries(80);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNoOfInquiries());
//	}
//
//	// DE 81
//	@Test
//	public void setNoOfAuthsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNoOfAuths("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNoOfAuths(81);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNoOfAuths());
//	}
//
//	// DE 82
//	@Test
//	public void setCreditsProcessingFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setCreditsProcessingFee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCreditsProcessingFee(82);
//		assertEquals("1234", masterConstruction.getSourceTmm().getCreditsProcessingFee());
//	}
//
//	// DE 83
//	@Test
//	public void setCreditsTxnFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setCreditsTxnFee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCreditsProcessingFee(83);
//		assertEquals("1234", masterConstruction.getSourceTmm().getCreditsTxnFee());
//	}
//
//	// DE 84
//	@Test
//	public void setDebitsProcessingFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setDebitsProcessingFee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setDebitsProcessingFee(84);
//		assertEquals("1234", masterConstruction.getSourceTmm().getDebitsProcessingFee());
//
//	}
//
//	// DE 85
//	@Test
//	public void setDebitsTxnFeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setDebitsTxnFee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setDebitsTxnFee(85);
//		assertEquals("1234", masterConstruction.getSourceTmm().getDebitsTxnFee());
//
//	}
//
//	// DE 86
//	@Test
//	public void setTotalCreditsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTotalCredits("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTotalCredits(86);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTotalCredits());
//
//	}
//
//	// DE 87
//	@Test
//	public void setCreditsReversalTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setCreditsReversal("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setCreditsReversal(87);
//		assertEquals("1234", masterConstruction.getSourceTmm().getCreditsReversal());
//
//	}
//
//	// DE 88
//	@Test
//	public void setTotalDebitsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTotalDebits("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTotalDebits(88);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTotalDebits());
//	}
//
//	// DE 89
//	@Test
//	public void setDebitsReversalTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setDebitsReversal("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setDebitsReversal(89);
//		assertEquals("1234", masterConstruction.getSourceTmm().getDebitsReversal());
//	}
//
//	// DE 90
//	@Test
//	public void setOriginalDataElementsTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setOriginalDataElements("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setOriginalDataElements(90);
//		assertEquals("1234", masterConstruction.getSourceTmm().getOriginalDataElements());
//	}
//
//	// DE 91
//	@Test
//	public void setFileUpdateCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setFileUpdateCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setFileUpdateCode(91);
//		assertEquals("1234", masterConstruction.getSourceTmm().getFileUpdateCode());
//
//	}
//
//	// DE 92
//	@Test
//	public void setFileSecurityCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setFileSecurityCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setFileSecurityCode(92);
//		assertEquals("1234", masterConstruction.getSourceTmm().getFileSecurityCode());
//
//	}
//
//	// DE 93
//	@Test
//	public void setResIndicatorTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setResIndicator("1");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setResIndicator(93);
//		assertEquals("1", masterConstruction.getSourceTmm().getResIndicator());
//
//	}
//
//	// DE 94
//	@Test
//	public void setServiceIndicatorTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setServiceIndicator("1");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setServiceIndicator(94);
//		assertEquals("1", masterConstruction.getSourceTmm().getServiceIndicator());
//	}
//
//	// DE 95
//	@Test
//	public void setReplacementAmtsTest() {
//		TransactionMessageModel sourceTmm = new TransactionMessageModel();
//		sourceTmm.setReplacementAmts("000000000000000000000000000000000000000000");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReplacementAmts(5);
//		assertEquals("000000000000000000000000000000000000000000",
//				masterConstruction.getTargetTmm().getReplacementAmts());
//
//	}
//
//	// DE 96
//	@Test
//	public void setMsgSecuirtyCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setMsgSecuirtyCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setMsgSecuirtyCode(96);
//		assertEquals("1234", masterConstruction.getSourceTmm().getMsgSecuirtyCode());
//	}
//
//	// DE 97
//	@Test
//	public void setNetSettlementTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setNetSettlement("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setNetSettlement(98);
//		assertEquals("1234", masterConstruction.getSourceTmm().getNetSettlement());
//
//	}
//
//	// DE 98
//	@Test
//	public void setPayeeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setPayee("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setPayee(98);
//		assertEquals("1234", masterConstruction.getSourceTmm().getPayee());
//
//	}
//
//	// DE 99
//	@Test
//	public void setSettlementIdCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setSettlementIdCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setSettlementIdCode(99);
//		assertEquals("1234", masterConstruction.getSourceTmm().getSettlementIdCode());
//	}
//
//	// DE 100
//	@Test
//	public void setReceiverIdCodeTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReceiverIdCode("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReceiverIdCode(100);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReceiverIdCode());
//
//	}
//
//	// DE 101
//	@Test
//	public void setFileNameTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setFileName("abcd");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setFileName(101);
//		assertEquals("abcd", masterConstruction.getSourceTmm().getFileName());
//	}
//
//	// DE 102
//	@Test
//	public void setAccountIdentification1Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAccId1("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAccId1(102);
//		assertEquals("1234", masterConstruction.getSourceTmm().getAccId1());
//
//	}
//
//	// DE 103
//	@Test
//	public void setAccountIdentification2() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setAccId2("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setAccId2(103);
//		assertEquals("1234", masterConstruction.getSourceTmm().getAccId2());
//	}
//
//	// DE 104
//	@Test
//	public void setTxnDescTest() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setTxnDesc("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setTxnDesc(104);
//		assertEquals("1234", masterConstruction.getSourceTmm().getTxnDesc());
//	}
//
//	// DE 105
//	@Test
//	public void setReserved105Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved105("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved105(105);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved105());
//	}
//
//	// DE 106
//	@Test
//	public void setReserved106Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved106("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved106(106);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved106());
//	}
//
//	// DE 107
//	@Test
//	public void setReserved107Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved107("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved107(107);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved107());
//	}
//
//	// DE 108
//	@Test
//	public void setReserved108Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved108("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved108(108);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved108());
//	}
//
//	// DE 109
//	@Test
//	public void setReserved109Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved109("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved109(109);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved109());
//	}
//
//	// DE 110
//	@Test
//	public void setReserved110Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved110("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved110(110);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved110());
//	}
//
//	// DE 111
//	@Test
//	public void setReserved111Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved111("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved111(111);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved111());
//	}
//
//	// DE 112
//	@Test
//	public void setReserved112Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved112("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved112(112);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved112());
//	}
//
//	// DE 113
//	@Test
//	public void setReserved113Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved113("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved113(113);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved113());
//	}
//
//	// DE 114
//	@Test
//	public void setReserved114Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved114("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved114(114);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved114());
//	}
//
//	// DE 115
//	@Test
//	public void setReserved115Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved115("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved115(115);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved115());
//	}
//
//	// DE 116
//	@Test
//	public void setReserved116Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved116("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved116(116);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved116());
//	}
//
//	// DE 117
//	@Test
//	public void setReserved117Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved117("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved117(117);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved117());
//	}
//
//	// DE 118
//	@Test
//	public void setReserved118Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved118("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved118(118);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved118());
//	}
//
//	// DE 119
//	@Test
//	public void setReserved119Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved119("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved119(119);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved119());
//	}
//
//	// DE 120
//	@Test
//	public void setReserved120Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved120("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved120(120);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved120());
//	}
//
//	// DE 121
//	@Test
//	public void setReserved121Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved121("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved121(121);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved121());
//	}
//
//	// DE 122
//	@Test
//	public void setReserved122Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved122("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved122(122);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved122());
//	}
//
//	// DE 123
//	@Test
//	public void setReserved123Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved123("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved123(123);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved123());
//
//	}
//
//	// DE 124
//	@Test
//	public void setReserved124Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved124("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved124(124);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved124());
//	}
//
//	// DE 125
//	@Test
//	public void setReserved125Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved125("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved125(125);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved125());
//	}
//
//	// DE 126
//	@Test
//	public void setReserved126Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved126("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved126(126);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved126());
//
//	}
//
//	// DE 127
//	@Test
//	public void setReserved127Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved127("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved127(127);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved127());
//
//	}
//
//	// DE 128
//	@Test
//	public void setReserved128Test() {
//		TransactionMessageModel sourceTmm = getSourceTmm();
//		sourceTmm.setReserved128("1234");
//		masterConstruction.setSourceTmm(sourceTmm);
//		masterConstruction.setReserved128(128);
//		assertEquals("1234", masterConstruction.getSourceTmm().getReserved128());
//	}

}
