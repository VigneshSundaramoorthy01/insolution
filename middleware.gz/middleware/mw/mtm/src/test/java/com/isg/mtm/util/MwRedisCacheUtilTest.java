package com.isg.mtm.util;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.mtm.util.MwRedisCacheUtil;

//import redis.embedded.RedisServer;



@RunWith(SpringRunner.class)
@ContextConfiguration(classes = MwRedisCacheUtilTest.class)
public class MwRedisCacheUtilTest {
	
	private MwRedisCacheUtil mwRedisCacheUtil;
	
	
	RedisTemplate<String, Map<HsmCommandArg, String>> hsmRedisTemplate;
	
	
	RedisTemplate<String, Map<TargetType, String>> targetDynamicKeyTemplate;
	
	
	RedisTemplate<String, Integer> atomicIntegerTemplate;
	
	RedisTemplate<String, RateLookupModel> dccRateLookUpTemplate;
	
	RedisTemplate<Integer, BillingCurrencyModel> billingCurrenciesTemplate;

	
	
	//private RedisServer redisServer;
	
	@Mock
	private RedisConnection redisConnectionMock;
	
	@Mock
	private RedisConnectionFactory redisConnectionFactoryMock;
	
	
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		when(redisConnectionFactoryMock.getConnection()).thenReturn(redisConnectionMock);
		
	}
	/*
	 * @Before public void setUp() { try { redisServer =
	 * RedisServer.builder().port(6370).build(); redisServer.start(); } catch
	 * (Exception e) { //do nothing } }
	 * 
	 * @After public void tearDown() { redisServer.stop(); }
	 */
	
	@Test
    public void constructorTest(){
		
		atomicIntegerTemplate = new RedisTemplate<String, Integer>();
		atomicIntegerTemplate.setConnectionFactory(redisConnectionFactoryMock);
		atomicIntegerTemplate.afterPropertiesSet();
		
		targetDynamicKeyTemplate = new RedisTemplate<String, Map<TargetType, String>> ();
		targetDynamicKeyTemplate.setConnectionFactory(redisConnectionFactoryMock);
		targetDynamicKeyTemplate.afterPropertiesSet();

		hsmRedisTemplate = new RedisTemplate<String, Map<HsmCommandArg, String>>();
		hsmRedisTemplate.setConnectionFactory(redisConnectionFactoryMock);
		hsmRedisTemplate.afterPropertiesSet();
		
		dccRateLookUpTemplate = new RedisTemplate<String, RateLookupModel>();
		dccRateLookUpTemplate.setConnectionFactory(redisConnectionFactoryMock);
		dccRateLookUpTemplate.afterPropertiesSet();
		
		billingCurrenciesTemplate = new RedisTemplate<Integer, BillingCurrencyModel>();
		billingCurrenciesTemplate.setConnectionFactory(redisConnectionFactoryMock);
		billingCurrenciesTemplate.afterPropertiesSet();


		mwRedisCacheUtil = new MwRedisCacheUtil(hsmRedisTemplate,targetDynamicKeyTemplate, dccRateLookUpTemplate, billingCurrenciesTemplate, atomicIntegerTemplate);
        
	}
	
	@Test
	public void putTerminalBdkKeyDataTest() {
		constructorTest();
		Map<HsmCommandArg, String> keyMap = new HashMap<>();
		keyMap.put(HsmCommandArg.Bdk, "12346");
        keyMap.put(HsmCommandArg.Ipek, "i4p4e4k");
		mwRedisCacheUtil.putTerminalBdkKeyData("terminal_key", "124563", keyMap);
	}
	
	@Test
	public void getTerminalBdkKeyDataTest() {
		constructorTest();
		Map<HsmCommandArg, String> keyMap = new HashMap<>();
		keyMap.put(HsmCommandArg.Bdk, "12346");
        keyMap.put(HsmCommandArg.Ipek, "i4p4e4k");
		mwRedisCacheUtil.getTerminalBdkKeyData("terminal_key", "124563");
	}
	
	@Test
	public void putTargetDynamicKeyDataTest() {
		constructorTest();
		mwRedisCacheUtil.putTargetDynamicKeyData("DynamicKey", TargetType.Master, "12345789");
	}
	
	@Test
	public void getTargetDynamicKeyDataTest() {
		constructorTest();
		mwRedisCacheUtil.getTargetDynamicKeyData("DynamicKey", TargetType.Master);
	}
	
	@Test
	public void getAtomicIntegerTest() {
		constructorTest();
		mwRedisCacheUtil.getAtomicInteger();
	}

}
