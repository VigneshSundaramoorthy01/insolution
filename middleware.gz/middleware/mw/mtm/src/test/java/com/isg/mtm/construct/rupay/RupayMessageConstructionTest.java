package com.isg.mtm.construct.rupay;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.rupay.RupayMessageConstruction;

public class RupayMessageConstructionTest {

	/*
	 * @Mock public HsmProcessorService hsmService;
	 *
	 * @Mock protected MapsInfoService merchantService;
	 *
	 * @Mock private PosSwitchBaseMessageConstruction baseConstruction;
	 *
	 * @InjectMocks private RupayMessageConstruction rupayConstruction;
	 *
	 * @Before public void init() {
	 *
	 * MockitoAnnotations.initMocks(this); }
	 *
	 * private TransactionMessageModel getSourceTmm() { TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel(); sourceTmm.setTxnAmt("2000");
	 * sourceTmm.setTransmissionTime("100"); sourceTmm.setPosConditionCode("08");
	 * sourceTmm.setEntityId("121"); sourceTmm.setCardAcceptorId("123");
	 * sourceTmm.setCardAcceptorTerminalId("141"); return sourceTmm; }
	 *
	 * private MapsInfoModel getMapsInfoModel() { MapsInfoModel merchantInfo = new
	 * MapsInfoModel(); merchantInfo.setMid("145404453445300");
	 * merchantInfo.setTid("11004448");
	 * merchantInfo.setEntityId("2341231223131232");
	 * merchantInfo.setForwardingInstitutionId("4000");
	 * merchantInfo.setAcquirerInstitutionId("12345");
	 * merchantInfo.setAcquiringInstitutionCountryCode("666666");
	 * merchantInfo.setMerchantType("7777"); merchantInfo.setMerchantName("Toyoto");
	 * merchantInfo.setMerchantCity("Airoli");
	 * merchantInfo.setMerchantCountryCode("405421");
	 * merchantInfo.setMerchantAddress("maladOfficeInsolutionsGlobal");
	 * merchantInfo.setMerchantZipCode("1000"); return merchantInfo; }
	 *
	 * DE 1
	 *
	 * @Test public void setBitMapTest() {
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setBitMap("20002000"); rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * assertEquals("20002000", rupayConstruction.getSourceTmm().getBitMap()); }
	 *
	 * DE 2
	 *
	 * @Test public void setPanTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())) .thenReturn("0005391699020177742D22022261000067799999");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPan("ABCD1234"); sourceTmm.setTrack1Data("1234");
	 * sourceTmm.setTrack2Data(null); sourceTmm.setEntityId("500");
	 * sourceTmm.setSecurityControlInfo("xyz");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setPan(20);
	 *
	 * assertEquals("0005391699020177742",
	 * rupayConstruction.getTargetTmm().getPan()); }
	 *
	 * @Test public void setPanTestException() { String errMsg =
	 * "Error while constructing data element: 20, name: PAN"; String message =
	 * null;
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("000");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPan("ABCD1234"); sourceTmm.setTrack1Data("1234");
	 * sourceTmm.setTrack2Data("308"); sourceTmm.setEntityId("500");
	 * sourceTmm.setSecurityControlInfo("xyz");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * try { rupayConstruction.setPan(20); } catch (Exception e) { message =
	 * e.getMessage(); } assertEquals(errMsg, message); }
	 *
	 * DE 3
	 *
	 * @Test public void setProcessingCodeTest() {
	 * rupayConstruction.setTargetMsgTypeId("000000");
	 * rupayConstruction.setProcessingCode(20); assertEquals("000000",
	 * rupayConstruction.getTargetTmm().getProcessingCode()); }
	 *
	 * DE 4
	 *
	 * @Test public void setTxnAmtTest() { TransactionMessageModel sourceTmm = new
	 * TransactionMessageModel(); sourceTmm.setTxnAmt("2000");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setTxnAmt(20);
	 *
	 * assertEquals("2000", rupayConstruction.getSourceTmm().getTxnAmt()); }
	 *
	 * DE 5
	 *
	 * @Test public void setSettlementAmt() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementAmt("2000");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setSettlementAmt(20);
	 *
	 * assertEquals("2000", rupayConstruction.getSourceTmm().getSettlementAmt()); }
	 *
	 * DE 6
	 *
	 * @Test public void setCardHolderBillingAmtTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardHolderBillingAmt("3000");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setCardHolderBillingAmt(20);
	 *
	 * assertEquals("3000",
	 * rupayConstruction.getSourceTmm().getCardHolderBillingAmt()); }
	 *
	 * DE 7
	 *
	 * @Test public void setTransmissionTimeTest() { // input
	 *
	 * String regex =
	 * "(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
	 * rupayConstruction.setTransmissionTime(5);
	 * rupayConstruction.getTargetTmm().getTransmissionTime();
	 *
	 * assertTrue("Not in expected pattern MMddhhmmss", Pattern.matches(regex,
	 * rupayConstruction.getTargetTmm().getTransmissionTime()));
	 *
	 * }
	 *
	 * DE 8
	 *
	 * @Test public void setCardHolderBillingTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardHolderBillingFee("4000");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setCardHolderBillingFee(20);
	 *
	 * assertEquals("4000",
	 * rupayConstruction.getSourceTmm().getCardHolderBillingFee()); }
	 *
	 * DE 9
	 *
	 * @Test public void setSettlementConversionRateTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setSettlementConversionRate("500");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setSettlementConversionRate(20);
	 *
	 * assertEquals("500",
	 * rupayConstruction.getSourceTmm().getSettlementConversionRate()); }
	 *
	 * DE 10
	 *
	 * @Test public void setCardHolderBillingConversionRateTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardHolderBillingConversionRate("600");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setCardHolderBillingConversionRate(20);
	 *
	 * assertEquals("600",
	 * rupayConstruction.getSourceTmm().getCardHolderBillingConversionRate()); }
	 *
	 * DE 11
	 *
	 * @Test public void setStanTest() { rupayConstruction.setStan(20);
	 *
	 * assertEquals(6, rupayConstruction.getTargetTmm().getStan().length()); }
	 *
	 * DE 12
	 *
	 * @Test public void setLocalTxnTimeTest() { // input String regex =
	 * "^(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
	 * rupayConstruction.setLocalTxnTime(20);
	 *
	 * assertTrue("Not in expected pattern hhmmss", Pattern.matches(regex,
	 * rupayConstruction.getTargetTmm().getLocalTxnTime())); }
	 *
	 * DE 13
	 *
	 * @Test public void setLocalTxnDateTest() { // input String regex =
	 * "^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
	 * rupayConstruction.setLocalTxnDate(20);
	 *
	 * assertTrue("Not in expected pattern MMdd", Pattern.matches(regex,
	 * rupayConstruction.getTargetTmm().getLocalTxnDate())); }
	 *
	 * DE 14
	 *
	 * @Test public void setExpirationDateTest() { // input TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setExpirationDate("05052020");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setExpirationDate(20);
	 *
	 * assertEquals("05052020",
	 * rupayConstruction.getTargetTmm().getExpirationDate()); }
	 *
	 * DE 15
	 *
	 * @Test public void setSettlementDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementDate("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementDate(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementDate()); }
	 *
	 * DE 16
	 *
	 * @Test public void setConversionDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setConversionDate("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setConversionDate(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getConversionDate()); }
	 *
	 * DE 17
	 *
	 * @Test public void setCaptureDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setCaptureDate("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setCaptureDate(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getCaptureDate()); }
	 *
	 * DE 18
	 *
	 * @Test public void setMerchantTypeTest() { // input
	 * rupayConstruction.setTargetMsgType("0200");
	 * rupayConstruction.setTargetMsgTypeId("010000");
	 *
	 * rupayConstruction.setMerchantType(20);
	 *
	 * assertEquals("6010", rupayConstruction.getTargetTmm().getMerchantType()); }
	 *
	 * DE 19
	 *
	 * @Test public void setAquireCountryCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setAquirerCountryCode("7878");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setAquirerCountryCode(20);
	 *
	 * assertEquals("666666",
	 * rupayConstruction.getTargetTmm().getAquirerCountryCode()); }
	 *
	 * DE 20
	 *
	 * @Test public void setPanExtendedCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanExtendedCountryCode("12345");
	 *
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setPanExtendedCountryCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getPanExtendedCountryCode()); }
	 *
	 * DE 21
	 *
	 * @Test public void setPanForwardingCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanForwardingCountryCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setPanForwardingCountryCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getPanForwardingCountryCode()); }
	 *
	 * DE 22
	 *
	 * @Test public void setPosEntryModeTest() {
	 *
	 * // input TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setPosEntryMode("901"); rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * // case 901 rupayConstruction.setPosEntryMode(22); assertEquals("901",
	 * rupayConstruction.getTargetTmm().getPosEntryMode());
	 *
	 * // case 011 rupayConstruction.getSourceTmm().setPosEntryMode("011");
	 * rupayConstruction.setPosEntryMode(22); assertEquals("011",
	 * rupayConstruction.getTargetTmm().getPosEntryMode());
	 *
	 * // case 051 rupayConstruction.getSourceTmm().setPosEntryMode("051");
	 * rupayConstruction.setPosEntryMode(22); assertEquals("051",
	 * rupayConstruction.getTargetTmm().getPosEntryMode());
	 *
	 * // case 071 rupayConstruction.getSourceTmm().setPosEntryMode("071");
	 * rupayConstruction.setPosEntryMode(22); assertEquals("071",
	 * rupayConstruction.getTargetTmm().getPosEntryMode());
	 *
	 * // case 801 rupayConstruction.getSourceTmm().setPosEntryMode("801");
	 * rupayConstruction.setPosEntryMode(22); assertEquals("801",
	 * rupayConstruction.getTargetTmm().getPosEntryMode()); }
	 *
	 * DE 23
	 *
	 * @Test public void setCardSeqNoTest() { // input
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm(); sourceTmm.setIccData(
	 * "9F02060000000030009F03060000000000008407A000000003101082023C009F360201F79F0702FF009F26080F380F214766ADF89F2701809F34034203009F1E0830313031353734349F100706010A03A0A8049F0902008C9F3303E0F0C89F1A0203569F350122950508800400005F2A0203565F3401019A031912109C01009F3704B1F0394E9F4104000000319F530152"
	 * ); rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setTargetMsgType("0280");
	 * rupayConstruction.setTargetMsgTypeId("510090");
	 *
	 * rupayConstruction.setCardSeqNo(20); assertEquals("001",
	 * rupayConstruction.getTargetTmm().getCardSeqNo()); }
	 *
	 * DE 24
	 *
	 * @Test public void setNetworkInternationalIdTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNiiId("200");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setNiiId(20);
	 *
	 * assertEquals("200", rupayConstruction.getSourceTmm().getNiiId()); }
	 *
	 * DE 25
	 *
	 * @Test public void setPosConditionCodeTest() {
	 * rupayConstruction.setTargetMsgType("0200");
	 * rupayConstruction.setTargetMsgTypeId("510000");
	 * rupayConstruction.setPosConditionCode(25); String result =
	 * rupayConstruction.getTargetTmm().getPosConditionCode(); assertEquals("08",
	 * result); // else rupayConstruction.setTargetMsgType("1234");
	 * rupayConstruction.setPosConditionCode(25); assertEquals("00",
	 * rupayConstruction.getTargetTmm().getPosConditionCode()); }
	 *
	 * DE 26
	 *
	 * @Test public void setPosCaptureCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setPosCaptureCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setPosCaptureCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getPosCaptureCode()); }
	 *
	 * DE 27
	 *
	 * @Test public void setAuthIdResLengthTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAuthIdResLength("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setAuthIdResLength(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getAuthIdResLength()); }
	 *
	 * DE 28
	 *
	 * @Test public void setTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setTxnFee(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getTxnFee()); }
	 *
	 * DE 29
	 *
	 * @Test public void setSettlementFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementFee()); }
	 *
	 * DE 30
	 *
	 * @Test public void setTxnProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTxnProcessingFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTxnProcessingFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTxnProcessingFee()); }
	 *
	 * DE 31
	 *
	 * @Test public void setSettlementProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementProcessingFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementProcessingFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementProcessingFee()); }
	 *
	 * DE 32
	 *
	 * @Test public void setAquirerIdCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setAquirerIdCode("5000");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setAquirerIdCode(20);
	 *
	 * assertEquals("12345", rupayConstruction.getTargetTmm().getAquirerIdCode()); }
	 *
	 * DE 33
	 *
	 * @Test public void setForwardingInstIdCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setForwardingInstIdCode("5000");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setForwardingInstIdCode(20);
	 *
	 * assertEquals("4000",
	 * rupayConstruction.getTargetTmm().getForwardingInstIdCode()); }
	 *
	 * DE 34
	 *
	 * @Test public void setPanExtendedTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPanExtended("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setPanExtended(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getPanExtended()); }
	 *
	 * DE 35
	 *
	 * @Test public void setTrack2DataTest() {
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("1234");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTrack2Data("333"); rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setTrack2Data(20);
	 *
	 * assertEquals("1234", rupayConstruction.getTargetTmm().getTrack2Data()); }
	 *
	 * DE 36
	 *
	 * @Test public void setTrack3DataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack3Data("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTrack3Data(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTrack3Data()); }
	 *
	 * DE 37
	 *
	 * @Test public void setRetrievalRefNoTest() { rupayConstruction.setStan(30);
	 * rupayConstruction.setRetrievalRefNo(20);
	 *
	 * assertEquals(12,
	 * rupayConstruction.getTargetTmm().getRetrievalRefNo().length()); }
	 *
	 * DE 38
	 *
	 * @Test public void setAuthIdResTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setAuthIdRes("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setAuthIdRes(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getAuthIdRes()); }
	 *
	 * DE 39
	 *
	 * @Test public void setResCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setResCode(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getResCode()); }
	 *
	 * DE 40
	 *
	 * @Test public void setServiceRestrictionCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceRestrictionCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setServiceRestrictionCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getServiceRestrictionCode()); }
	 *
	 * DE 41
	 *
	 * @Test public void setCardAcceptorTerminalIdTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardAcceptorTerminalId("1432");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setCardAcceptorTerminalId(20);
	 *
	 * assertEquals("1432",
	 * rupayConstruction.getTargetTmm().getCardAcceptorTerminalId()); }
	 *
	 * DE 42
	 *
	 * @Test public void setCardAcceptorIdTest() { // input TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel(); sourceTmm.setCardAcceptorId("14");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setCardAcceptorId(20);
	 *
	 * assertEquals("14", rupayConstruction.getTargetTmm().getCardAcceptorId()); }
	 *
	 * DE 43
	 *
	 * @Test public void setCardAcceptorInfoTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardAcceptorId("1425");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setCardAcceptorInfo(43); String result =
	 * rupayConstruction.getTargetTmm().getCardAcceptorInfo();
	 * assertEquals("Toyoto                 Airoli       null405421", result);
	 *
	 * }
	 *
	 * DE 44
	 *
	 * @Test public void setAdditionalResDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalResData("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setAdditionalResData(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getAdditionalResData()); }
	 *
	 * DE 45
	 *
	 * @Test public void setTrack1DataTest() {
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())) .thenReturn("12345"); TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack1Data("30");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setTrack1Data(20);
	 *
	 * assertEquals("12345", rupayConstruction.getTargetTmm().getTrack1Data()); }
	 *
	 * DE 46
	 *
	 * @Test public void setIsoAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setIsoAd("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setIsoAd(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getIsoAd()); }
	 *
	 * DE 47
	 *
	 * @Test public void setNationalAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNationalAd("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNationalAd(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNationalAd()); }
	 *
	 * DE 48
	 *
	 * @Test public void setPrivateAd() { rupayConstruction.setPrivateAd(48);
	 * assertEquals("051005POS0107800203",
	 * rupayConstruction.getTargetTmm().getPrivateAd()); }
	 *
	 * DE 49
	 *
	 * @Test public void setTxnCurrencyCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setTxnCurrencyCode("1001");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setTxnCurrencyCode(20);
	 *
	 * assertEquals("1111", rupayConstruction.getTargetTmm().getTxnCurrencyCode());
	 *
	 * }
	 *
	 * DE 50
	 *
	 * @Test public void setSettlementCurrenyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCurrenyCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementCurrenyCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementCurrenyCode()); }
	 *
	 * DE 51
	 *
	 * @Test public void setCardHolderBillingCurrencyCodeTest() {
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingCurrencyCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setCardHolderBillingCurrencyCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getCardHolderBillingCurrencyCode()); }
	 *
	 * DE 52
	 *
	 * @Test public void setPinTest() {
	 *
	 * Mockito.when(hsmService.pinTranslation(Mockito.any(), Mockito.any(),
	 * Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("280595");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnCurrencyCode("645");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * setPanTest();
	 *
	 * rupayConstruction.setPin(20);
	 *
	 * assertEquals("280595", rupayConstruction.getTargetTmm().getPin()); }
	 *
	 * DE 53
	 *
	 * @Test public void setSecurityControlInfoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSecurityControlInfo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSecurityControlInfo(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSecurityControlInfo()); }
	 *
	 * DE 54
	 *
	 * @Test public void setAdditionalAmountsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalAmounts("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setAdditionalAmounts(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getAdditionalAmounts()); }
	 *
	 * DE 55
	 *
	 * @Test public void setIccDataTest() { // input TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel(); sourceTmm.setIccData("123");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setIccData(20);
	 *
	 * assertEquals("123", rupayConstruction.getSourceTmm().getIccData()); }
	 *
	 * DE 57
	 *
	 * @Test public void setReserverd57Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved57("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved57(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved57()); }
	 *
	 * DE 58
	 *
	 * @Test public void setReserved58Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved58("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved58(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved58()); }
	 *
	 * DE 59
	 *
	 * @Test public void setReserverd59Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved59("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved59(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved59()); }
	 *
	 * DE 60
	 *
	 * @Test public void setTerminalDataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTerminalData("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTerminalData(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTerminalData()); }
	 *
	 * DE 61
	 *
	 * @Test public void setCiadTest() { // input 1
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCiad("1234"); rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * MapsInfoModel maps = getMapsInfoModel(); maps.setMerchantAddress(null);
	 *
	 * rupayConstruction.setTargetMsgType("0200");
	 * rupayConstruction.setTargetMsgTypeId("000000");
	 *
	 * rupayConstruction.setCiad(20);
	 *
	 * assertEquals("6000410000000001000maladOfficeInsolutio",
	 * rupayConstruction.getTargetTmm().getCiad()); }
	 *
	 * @Test public void setCiadTest2() { // input 1
	 *
	 * MapsInfoModel maps = getMapsInfoModel(); maps.setMerchantAddress("bombay");
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(maps)
	 * ;
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCiad("1234"); rupayConstruction.setSourceTmm(sourceTmm);
	 *
	 * rupayConstruction.setTargetMsgType("02001");
	 * rupayConstruction.setTargetMsgTypeId("0000080");
	 *
	 * rupayConstruction.setCiad(20);
	 *
	 * assertEquals("8200123210390001000bombay              ",
	 * rupayConstruction.getTargetTmm().getCiad()); }
	 *
	 * DE 62
	 *
	 * @Test public void setPostalCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPostalCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setPostalCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getPostalCode()); }
	 *
	 * DE 63
	 *
	 * @Test public void setAtmPinOffsetDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAtmPinOffsetData("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setAtmPinOffsetData(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getAtmPinOffsetData()); }
	 *
	 * DE 64
	 *
	 * @Test public void setMsgAuthCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgAuthCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setMsgAuthCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getMsgAuthCode()); }
	 *
	 * DE 65
	 *
	 * @Test public void setExtendedBitmapIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedBitmapIndicator("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setExtendedBitmapIndicator(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getExtendedBitmapIndicator()); }
	 *
	 * DE 66
	 *
	 * @Test public void setSettlementCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementCode()); }
	 *
	 * DE 67
	 *
	 * @Test public void setExtendedPaymentCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedPaymentCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setExtendedPaymentCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getExtendedPaymentCode()); }
	 *
	 * DE 68
	 *
	 * @Test public void setReceiverCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReceiverCountryCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReceiverCountryCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReceiverCountryCode()); }
	 *
	 * DE 69
	 *
	 * @Test public void setSettlementCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCountryCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementCountryCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementCountryCode()); }
	 *
	 * DE 70
	 *
	 * @Test public void setNetworkMgmtInfoCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNetworkMgmtInfoCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNetworkMgmtInfoCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNetworkMgmtInfoCode()); }
	 *
	 * DE 71
	 *
	 * @Test public void setMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgNo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setMsgNo(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getMsgNo()); }
	 *
	 * DE 72
	 *
	 * @Test public void setLastMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setLastMsgNo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setLastMsgNo(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getLastMsgNo()); }
	 *
	 * DE 73
	 *
	 * @Test public void setActionDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setActionDate("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setActionDate(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getActionDate()); }
	 *
	 * DE 74
	 *
	 * @Test public void setNoOfCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfCredits("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNoOfCredits(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNoOfCredits()); }
	 *
	 * DE 75
	 *
	 * @Test public void setCreditsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversalNo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setCreditsReversalNo(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getCreditsReversalNo()); }
	 *
	 * DE 76
	 *
	 * @Test public void setNoOfDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfDebits("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNoOfDebits(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNoOfDebits()); }
	 *
	 * DE 77
	 *
	 * @Test public void setDebitsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsReversalNo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setDebitsReversalNo(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getDebitsReversalNo()); }
	 *
	 * DE 78
	 *
	 * @Test public void setTransferNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTransferNo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTransferNo(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTransferNo()); }
	 *
	 * DE 79
	 *
	 * @Test public void setTransferReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTransferReversalNo("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTransferReversalNo(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTransferReversalNo()); }
	 *
	 * DE 80
	 *
	 * @Test public void setNoOfInquiriesTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNoOfInquiries("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNoOfInquiries(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNoOfInquiries()); }
	 *
	 * DE 81
	 *
	 * @Test public void setNoOfAuthsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfAuths("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNoOfAuths(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNoOfAuths()); }
	 *
	 * DE 82
	 *
	 * @Test public void setCreditsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsProcessingFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setCreditsProcessingFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getCreditsProcessingFee()); }
	 *
	 * DE 83
	 *
	 * @Test public void setCreditsTxnFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setCreditsTxnFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setCreditsTxnFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getCreditsTxnFee()); }
	 *
	 * DE 84
	 *
	 * @Test public void setDebitsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsProcessingFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setDebitsProcessingFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getDebitsProcessingFee()); }
	 *
	 * DE 85
	 *
	 * @Test public void setDebitsTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setDebitsTxnFee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setDebitsTxnFee(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getDebitsTxnFee()); }
	 *
	 * DE 86
	 *
	 * @Test public void setTotalCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalCredits("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTotalCredits(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTotalCredits()); }
	 *
	 * DE 87
	 *
	 * @Test public void setCreditsReversalTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversal("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setCreditsReversal(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getCreditsReversal()); }
	 *
	 * DE 88
	 *
	 * @Test public void setTotalDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalDebits("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setTotalDebits(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getTotalDebits()); }
	 *
	 * DE 89
	 *
	 * @Test public void setDebitsReversalTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setDebitsReversal("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setDebitsReversal(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getDebitsReversal()); }
	 *
	 * DE 90
	 *
	 * @Test public void setOriginalDataElementsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setOriginalDataElements("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setOriginalDataElements(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getOriginalDataElements()); }
	 *
	 * DE 91
	 *
	 * @Test public void setFileUpdateCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setFileUpdateCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setFileUpdateCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getFileUpdateCode()); }
	 *
	 * DE 92
	 *
	 * @Test public void setFileSecurityCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setFileSecurityCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setFileSecurityCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getFileSecurityCode()); }
	 *
	 * DE 93
	 *
	 * @Test public void setResIndicatorTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResIndicator("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setResIndicator(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getResIndicator()); }
	 *
	 * DE 94
	 *
	 * @Test public void setServiceIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceIndicator("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setServiceIndicator(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getServiceIndicator()); }
	 *
	 * DE 95
	 *
	 * @Test public void setReplacementAmtsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReplacementAmts("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReplacementAmts(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReplacementAmts()); }
	 *
	 * DE 96
	 *
	 * @Test public void setMsgSecuirtyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setMsgSecuirtyCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setMsgSecuirtyCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getMsgSecuirtyCode()); }
	 *
	 * DE 97
	 *
	 * @Test public void setNetSettlementTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNetSettlement("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setNetSettlement(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getNetSettlement()); }
	 *
	 * DE 98
	 *
	 * @Test public void setPayeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPayee("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setPayee(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getPayee()); }
	 *
	 * DE 99
	 *
	 * @Test public void setSettlementIdCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementIdCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setSettlementIdCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getSettlementIdCode()); }
	 *
	 * DE 100
	 *
	 * @Test public void setReceiverIdCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setReceiverIdCode("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReceiverIdCode(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReceiverIdCode()); }
	 *
	 * DE 101
	 *
	 * @Test public void setFileNameTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setFileName("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setFileName(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getFileName()); }
	 *
	 * DE 102
	 *
	 * @Test public void setAccountIdentification1Test() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId1("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setTxnDesc(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getAccId1()); }
	 *
	 * DE 103
	 *
	 * @Test public void setAccountIdentification2() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId2("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setTxnDesc(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getAccId2()); }
	 *
	 * DE 104
	 *
	 * @Test public void setTxnDescTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnDesc("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm); rupayConstruction.setTxnDesc(20);
	 * assertEquals("12345", rupayConstruction.getSourceTmm().getTxnDesc()); }
	 *
	 * DE 105
	 *
	 * @Test public void setReserved105Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved105("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved105(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved105()); }
	 *
	 * DE 106
	 *
	 * @Test public void setReserved106Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved106("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved106(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved106()); }
	 *
	 * DE 107
	 *
	 * @Test public void setReserved107Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved107("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved107(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved107()); }
	 *
	 * DE 108
	 *
	 * @Test public void setReserved108Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved108("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved108(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved108()); }
	 *
	 * DE 109
	 *
	 * @Test public void setReserved109Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved109("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved109(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved109()); }
	 *
	 * DE 110
	 *
	 * @Test public void setReserved110Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved110("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved110(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved110()); }
	 *
	 * DE 111
	 *
	 * @Test public void setReserved111Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved111("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved111(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved111()); }
	 *
	 * DE 112
	 *
	 * @Test public void setReserved112Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved112("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved112(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved112()); }
	 *
	 * DE 113
	 *
	 * @Test public void setReserved113Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved113("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved113(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved113()); }
	 *
	 * DE 114
	 *
	 * @Test public void setReserved114Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved114("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved114(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved114()); }
	 *
	 * DE 115
	 *
	 * @Test public void setReserved115Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved115("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved115(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved115()); }
	 *
	 * DE 116
	 *
	 * @Test public void setReserved116Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved116("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved116(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved116()); }
	 *
	 * DE 117
	 *
	 * @Test public void setReserved117Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved117("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved117(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved117()); }
	 *
	 * DE 118
	 *
	 * @Test public void setReserved118Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved118("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved118(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved118()); }
	 *
	 * DE 119
	 *
	 * @Test public void setReserved119Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved119("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved119(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved119()); }
	 *
	 * DE 120
	 *
	 * @Test public void setReserved120Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved120("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved120(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved120()); }
	 *
	 * DE 121
	 *
	 * @Test public void setReserved121Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved121("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved121(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved121()); }
	 *
	 * DE 122
	 *
	 * @Test public void setReserved122Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved122("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved122(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved122()); }
	 *
	 * DE 123
	 *
	 * @Test public void setReserved123Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved123("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved123(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved123()); }
	 *
	 * DE 124
	 *
	 * @Test public void setReserved124Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved124("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved124(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved124()); }
	 *
	 * DE 125
	 *
	 * @Test public void setReserved125Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved125("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved125(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved125()); }
	 *
	 * DE 126
	 *
	 * @Test public void setReserved126Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved126("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved126(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved126()); }
	 *
	 * DE 127
	 *
	 * @Test public void setReserved127Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved127("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved127(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved127()); }
	 *
	 * DE 128
	 *
	 * @Test public void setReserved128Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved128("12345");
	 * rupayConstruction.setSourceTmm(sourceTmm);
	 * rupayConstruction.setReserved128(20); assertEquals("12345",
	 * rupayConstruction.getSourceTmm().getReserved128());
	 *
	 * }
	 */
}
