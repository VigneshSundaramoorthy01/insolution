package com.isg.mtm.construct.visa;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.visa.VisaMessageConstruction;
import com.isg.mw.mtm.exception.MessageConstructionException;

public class VisaMessageConstructionTest {

	/*
	 * @Mock private PosSwitchBaseMessageConstruction
	 * posSwitchBaseMessageConstruction;
	 *
	 * @InjectMocks private VisaMessageConstruction visaConstruction;
	 *
	 * @Mock private MapsInfoService merchantService;
	 *
	 * @Mock private HsmProcessorService hsmService;
	 *
	 * @Mock private MapsInfoModel maps;
	 *
	 * @Before public void init() { MockitoAnnotations.initMocks(this); }
	 *
	 * private TransactionMessageModel getSourceTmm() { TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel(); sourceTmm.setTxnAmt("2000");
	 * sourceTmm.setTransmissionTime("100"); sourceTmm.setPosConditionCode("08");
	 * sourceTmm.setEntityId("121"); sourceTmm.setCardAcceptorId("123");
	 * sourceTmm.setCardAcceptorTerminalId("141"); return sourceTmm; }
	 *
	 * private MapsInfoModel getMapsInfoModel() { MapsInfoModel merchantInfo = new
	 * MapsInfoModel(); merchantInfo.setMid("145404453445300");
	 * merchantInfo.setTid("11004448");
	 * merchantInfo.setEntityId("2341231223131232");
	 * merchantInfo.setForwardingInstitutionId("1234");
	 * merchantInfo.setAcquirerInstitutionId("12345");
	 * merchantInfo.setAcquiringInstitutionCountryCode("666666");
	 * merchantInfo.setMerchantType("7777"); merchantInfo.setMerchantName("Toyoto");
	 * merchantInfo.setMerchantCity("Airoli");
	 * merchantInfo.setMerchantCountryCode("405421"); return merchantInfo; }
	 *
	 * DE 1
	 *
	 * @Test public void setBitMapTest() {
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setBitMap("20002000"); visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * assertEquals("20002000", visaConstruction.getSourceTmm().getBitMap()); }
	 *
	 * DE 2
	 *
	 * @Test public void setPanTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())) .thenReturn("0005391699020177742D22022261000067799999");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPan("ABCD1234"); sourceTmm.setTrack1Data("1234");
	 * sourceTmm.setTrack2Data(null); sourceTmm.setEntityId("500");
	 * sourceTmm.setSecurityControlInfo("xyz");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPan(20);
	 *
	 * assertEquals("0005391699020177742",
	 * visaConstruction.getTargetTmm().getPan()); }
	 *
	 * @Test public void setPanTestException() { String errMsg =
	 * "Error while constructing data element: 20, name: PAN"; String message =
	 * null;
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("000");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPan("ABCD1234"); sourceTmm.setTrack1Data("1234");
	 * sourceTmm.setTrack2Data("308"); sourceTmm.setEntityId("500");
	 * sourceTmm.setSecurityControlInfo("xyz");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * try { visaConstruction.setPan(20); } catch (Exception e) { message =
	 * e.getMessage(); } assertEquals(errMsg, message); }
	 *
	 * DE 3
	 *
	 * @Test public void setProcessingCodeTest() {
	 * visaConstruction.setTargetMsgTypeId("000000");
	 * visaConstruction.setProcessingCode(20); assertEquals("000000",
	 * visaConstruction.getTargetTmm().getProcessingCode()); }
	 *
	 * DE 4
	 *
	 * @Test public void setTxnAmtTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel()); visaConstruction.setSourceTmm(getSourceTmm());
	 * visaConstruction.setTxnAmt(20); assertEquals("2000",
	 * visaConstruction.getSourceTmm().getTxnAmt()); }
	 *
	 * DE 5
	 *
	 * @Test public void setSettlementAmt() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setSettlementAmt("2000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementAmt(5);
	 *
	 * assertEquals("2000", visaConstruction.getSourceTmm().getSettlementAmt()); }
	 *
	 * DE 6
	 *
	 * @Test public void setCardHolderBillingAmtTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel()); TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingAmt("2000");
	 *
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardHolderBillingAmt(6);
	 *
	 * assertEquals("2000",
	 * visaConstruction.getSourceTmm().getCardHolderBillingAmt()); }
	 *
	 * DE 7
	 *
	 * @Test public void setTransmissionTimeTest() {
	 *
	 * String regex =
	 * "(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
	 * visaConstruction.setTransmissionTime(5);
	 * visaConstruction.getTargetTmm().getTransmissionTime();
	 *
	 * assertTrue("Not in expected pattern MMddhhmmss", Pattern.matches(regex,
	 * visaConstruction.getTargetTmm().getTransmissionTime()));
	 *
	 * }
	 *
	 * DE 8
	 *
	 * @Test public void setCardHolderBillingFeeTest() {
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingFee("2000");
	 *
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardHolderBillingFee(8);
	 *
	 * assertEquals("2000",
	 * visaConstruction.getSourceTmm().getCardHolderBillingFee()); }
	 *
	 * DE 9
	 *
	 * @Test public void setSettlementConversionRateTest() { // input
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel()); TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setSettlementConversionRate("2000");
	 *
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementConversionRate(8);
	 *
	 * assertEquals("2000",
	 * visaConstruction.getSourceTmm().getSettlementConversionRate()); }
	 *
	 * DE 10
	 *
	 * @Test public void setCardHolderBillingConversionRateTest() { // input
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingConversionRate("2000");
	 *
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardHolderBillingConversionRate(8);
	 *
	 * assertEquals("2000",
	 * visaConstruction.getSourceTmm().getCardHolderBillingConversionRate());
	 *
	 * }
	 *
	 * DE 11
	 *
	 * @Test public void setStanTest() { visaConstruction.setStan(20);
	 *
	 * assertEquals(6, visaConstruction.getTargetTmm().getStan().length()); }
	 *
	 * DE 12
	 *
	 * @Test public void setLocalTxnTimeTest() { // input String regex =
	 * "^(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
	 * visaConstruction.setLocalTxnTime(20);
	 *
	 * assertTrue("Not in expected pattern hhmmss", Pattern.matches(regex,
	 * visaConstruction.getTargetTmm().getLocalTxnTime())); }
	 *
	 * DE 13
	 *
	 * @Test public void setLocalTxnDateTest() { // input String regex =
	 * "^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
	 * visaConstruction.setLocalTxnDate(20);
	 *
	 * assertTrue("Not in expected pattern MMdd", Pattern.matches(regex,
	 * visaConstruction.getTargetTmm().getLocalTxnDate())); }
	 *
	 * DE 14
	 *
	 * @Test public void setExpirationDateTest() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExpirationDate("05052020");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setExpirationDate(20);
	 *
	 * assertEquals("05052020",
	 * visaConstruction.getTargetTmm().getExpirationDate()); }
	 *
	 * DE 15
	 *
	 * @Test public void setSettlementDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementDate("1234");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementDate(20);
	 *
	 * assertEquals("1234", visaConstruction.getSourceTmm().getSettlementDate()); }
	 *
	 * DE 16
	 *
	 * @Test public void setConversionDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setConversionDate("1234");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setConversionDate(20);
	 *
	 * assertEquals("1234", visaConstruction.getSourceTmm().getConversionDate()); }
	 *
	 * DE 17
	 *
	 * @Test public void setCaptureDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setCaptureDate("1234");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCaptureDate(20);
	 *
	 * assertEquals("1234", visaConstruction.getSourceTmm().getCaptureDate()); }
	 *
	 * DE 18
	 *
	 * @Test public void setMerchantTypeTest() { // input
	 * visaConstruction.setTargetMsgType("0200");
	 * visaConstruction.setTargetMsgTypeId("010000");
	 *
	 * visaConstruction.setMerchantType(20);
	 *
	 * assertEquals("6010", visaConstruction.getTargetTmm().getMerchantType());
	 *
	 * // input 2 visaConstruction.setTargetMsgType("0210");
	 * visaConstruction.setTargetMsgTypeId("011000");
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setMerchantType("1234"); visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setMerchantType(20);
	 *
	 * assertEquals("7777", visaConstruction.getTargetTmm().getMerchantType()); }
	 *
	 * DE 19
	 *
	 * @Test public void setAquirerCountryCodeTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setAquirerCountryCode("7878");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAquirerCountryCode(20);
	 *
	 * assertEquals("666666",
	 * visaConstruction.getTargetTmm().getAquirerCountryCode()); }
	 *
	 * DE 20
	 *
	 * @Test public void setPanExtendedCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanExtendedCountryCode("50000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPanExtendedCountryCode(20); assertEquals("50000",
	 * visaConstruction.getSourceTmm().getPanExtendedCountryCode()); }
	 *
	 * DE 21
	 *
	 * @Test public void setPanForwardingCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanForwardingCountryCode("50000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPanForwardingCountryCode(20); assertEquals("50000",
	 * visaConstruction.getSourceTmm().getPanForwardingCountryCode()); }
	 *
	 * DE 22
	 *
	 * @Test public void setPosEntryModeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPosEntryMode("021");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPosEntryMode(22);
	 *
	 * assertEquals("9010", visaConstruction.getTargetTmm().getPosEntryMode());
	 *
	 * // for else condition TransactionMessageModel sourceTmm1 = getSourceTmm();
	 * sourceTmm1.setPosEntryMode("100"); visaConstruction.setSourceTmm(sourceTmm1);
	 *
	 * visaConstruction.setPosEntryMode(22);
	 *
	 * assertEquals("1000", visaConstruction.getTargetTmm().getPosEntryMode());
	 *
	 * // for Exception
	 *
	 * TransactionMessageModel sourceTmm2 = getSourceTmm();
	 * sourceTmm2.setPosEntryMode(null); visaConstruction.setSourceTmm(sourceTmm2);
	 *
	 * String errMsg =
	 * "Could not validate POS Entry Mode against master data available"; String
	 * message = null; try { visaConstruction.setPosEntryMode(22); } catch
	 * (MessageConstructionException e) { message = e.getMessage(); }
	 * assertEquals(errMsg, message); }
	 *
	 * DE 23
	 *
	 * @Test public void setCardSeqNoTest() { // input
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm(); sourceTmm.setIccData(
	 * "9F02060000000030009F03060000000000008407A000000003101082023C009F360201F79F0702FF009F26080F380F214766ADF89F2701809F34034203009F1E0830313031353734349F100706010A03A0A8049F0902008C9F3303E0F0C89F1A0203569F350122950508800400005F2A0203565F3401019A031912109C01009F3704B1F0394E9F4104000000319F530152"
	 * ); visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTargetMsgType("0280");
	 * visaConstruction.setTargetMsgTypeId("510090");
	 *
	 * visaConstruction.setCardSeqNo(20); assertEquals("001",
	 * visaConstruction.getTargetTmm().getCardSeqNo()); }
	 *
	 * DE 24
	 *
	 * @Test public void setNetworkInternationalIdTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNiiId("12");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNiiId(20);
	 *
	 * assertEquals("12", visaConstruction.getSourceTmm().getNiiId());
	 *
	 * }
	 *
	 * DE 25
	 *
	 * @Test public void setPosConditionCodeTest() { // input 1
	 * visaConstruction.setTargetMsgType("0200");
	 * visaConstruction.setTargetMsgTypeId("510000");
	 * visaConstruction.setPosConditionCode(25); assertEquals("08",
	 * visaConstruction.getTargetTmm().getPosConditionCode());
	 *
	 * // input 1 for else visaConstruction.setTargetMsgType("0241");
	 * visaConstruction.setTargetMsgTypeId("501111");
	 * visaConstruction.setPosConditionCode(25); assertEquals("00",
	 * visaConstruction.getTargetTmm().getPosConditionCode());
	 *
	 * }
	 *
	 * DE 26
	 *
	 * @Test public void setPosCaptureCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setPosCaptureCode("100");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPosCaptureCode(20); assertEquals("100",
	 * visaConstruction.getSourceTmm().getPosCaptureCode()); }
	 *
	 * DE 27
	 *
	 * @Test public void setAuthIdResLengthTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAuthIdResLength("100");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAuthIdResLength(20); assertEquals("100",
	 * visaConstruction.getSourceTmm().getAuthIdResLength()); }
	 *
	 * DE 28
	 *
	 * @Test public void setTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnFee("100");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTxnFee(20); assertEquals("100",
	 * visaConstruction.getSourceTmm().getTxnFee()); }
	 *
	 * DE 29
	 *
	 * @Test public void setSettlementFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementFee("100");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementFee(20); assertEquals("100",
	 * visaConstruction.getSourceTmm().getSettlementFee()); }
	 *
	 * DE 30
	 *
	 * @Test public void setTxnProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTxnProcessingFee("100");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTxnProcessingFee(20); assertEquals("100",
	 * visaConstruction.getSourceTmm().getTxnProcessingFee()); }
	 *
	 * DE 31
	 *
	 * @Test public void setSettlementProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementProcessingFee("100");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementProcessingFee(20); assertEquals("100",
	 * visaConstruction.getSourceTmm().getSettlementProcessingFee()); }
	 *
	 * DE 32
	 *
	 * @Test public void setAquirerIdCodeTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setAquirerIdCode("10"); visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAquirerIdCode(20);
	 *
	 * assertEquals("12345", visaConstruction.getTargetTmm().getAquirerIdCode()); }
	 *
	 * DE 33
	 *
	 * @Test public void setForwardingInstIdCodeTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setForwardingInstIdCode("1432");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setForwardingInstIdCode(20); assertEquals("1234",
	 * visaConstruction.getTargetTmm().getForwardingInstIdCode()); }
	 *
	 * DE 34
	 *
	 * @Test public void setPanExtendedTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPanExtended("10");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPanExtended(20); assertEquals("10",
	 * visaConstruction.getSourceTmm().getPanExtended()); }
	 *
	 * DE 35
	 *
	 * @Test public void setTrack2DataTest() { // input
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("1234");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTrack2Data("333"); visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTrack2Data(20);
	 *
	 * assertEquals("1234", visaConstruction.getTargetTmm().getTrack2Data()); }
	 *
	 * DE 36
	 *
	 * @Test public void setTrack3DataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack3Data("10");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTrack3Data(20); assertEquals("10",
	 * visaConstruction.getSourceTmm().getTrack3Data()); }
	 *
	 * DE 37
	 *
	 * @Test public void setRetrievalRefNoTest() { visaConstruction.setStan(30);
	 * visaConstruction.setRetrievalRefNo(20);
	 *
	 * assertEquals(12,
	 * visaConstruction.getTargetTmm().getRetrievalRefNo().length()); }
	 *
	 * DE 38
	 *
	 * @Test public void setAuthIdResTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setAuthIdRes("10");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAuthIdRes(20); assertEquals("10",
	 * visaConstruction.getSourceTmm().getAuthIdRes()); }
	 *
	 * DE 39
	 *
	 * @Test public void setResCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResCode("10");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setResCode(20); assertEquals("10",
	 * visaConstruction.getSourceTmm().getResCode()); }
	 *
	 * DE 40
	 *
	 * @Test public void setServiceRestrictionCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceRestrictionCode("10");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setServiceRestrictionCode(20); assertEquals("10",
	 * visaConstruction.getSourceTmm().getServiceRestrictionCode()); }
	 *
	 * DE 41
	 *
	 * @Test public void setCardAcceptorTerminalIdTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardAcceptorTerminalId("1432");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardAcceptorTerminalId(20);
	 *
	 * assertEquals("1432",
	 * visaConstruction.getTargetTmm().getCardAcceptorTerminalId()); }
	 *
	 * DE 42
	 *
	 * @Test public void setCardAcceptorIdTest() { // input TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel(); sourceTmm.setCardAcceptorId("14");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardAcceptorId(20);
	 *
	 * assertEquals("14", visaConstruction.getTargetTmm().getCardAcceptorId()); }
	 *
	 * DE 43
	 *
	 * @Test public void setCardAcceptorInfoTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardAcceptorInfo("1000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardAcceptorInfo(43);
	 * assertEquals("Toyoto                   Airoli       405421",
	 * visaConstruction.getTargetTmm().getCardAcceptorInfo()); }
	 *
	 * DE 44
	 *
	 * @Test public void setAdditionalResDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalResData("2000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAdditionalResData(20);
	 *
	 * assertEquals("2000", visaConstruction.getSourceTmm().getAdditionalResData());
	 * }
	 *
	 * DE 45
	 *
	 * @Test public void setTrack1DataTest() {
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())) .thenReturn("12345"); TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack1Data("30");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTrack1Data(20);
	 *
	 * assertEquals("12345", visaConstruction.getTargetTmm().getTrack1Data()); }
	 *
	 * DE 46
	 *
	 * @Test public void setIsoAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setIsoAd("2000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setIsoAd(20);
	 *
	 * assertEquals("2000", visaConstruction.getSourceTmm().getIsoAd()); }
	 *
	 * DE 47
	 *
	 * @Test public void setNationalAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNationalAd("2000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNationalAd(20);
	 *
	 * assertEquals("2000", visaConstruction.getSourceTmm().getNationalAd()); }
	 *
	 * DE 48 // blank
	 *
	 * DE 49
	 *
	 * @Test public void setTxnCurrencyCodeTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setTxnCurrencyCode("1001");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTxnCurrencyCode(20);
	 *
	 * assertEquals("1111", visaConstruction.getTargetTmm().getTxnCurrencyCode()); }
	 *
	 * DE 50
	 *
	 * @Test public void setSettlementCurrenyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCurrenyCode("2000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementCurrenyCode(20);
	 *
	 * assertEquals("2000",
	 * visaConstruction.getSourceTmm().getSettlementCurrenyCode()); }
	 *
	 * DE 51
	 *
	 * @Test public void setCardHolderBillingCurrencyCodeTest() {
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingCurrencyCode("2000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCardHolderBillingCurrencyCode(20);
	 *
	 * assertEquals("2000",
	 * visaConstruction.getSourceTmm().getCardHolderBillingCurrencyCode()); }
	 *
	 * DE 52
	 *
	 * @Test public void setPinTest() {
	 *
	 * Mockito.when(hsmService.pinTranslation(Mockito.any(), Mockito.any(),
	 * Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("280595");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnCurrencyCode("645");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * setPanTest();
	 *
	 * visaConstruction.setPin(20);
	 *
	 * assertEquals("280595", visaConstruction.getTargetTmm().getPin()); }
	 *
	 * DE 53
	 *
	 * @Test public void setSecurityControlInfoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm();
	 * sourceTmm.setSecurityControlInfo("2001010100000000");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSecurityControlInfo(53); assertEquals("2001010100000000",
	 * visaConstruction.getTargetTmm().getSecurityControlInfo());
	 *
	 * }
	 *
	 * DE 54
	 *
	 * @Test public void setAdditionalAmountsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalAmounts("2001");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAdditionalAmounts(53); assertEquals("2001",
	 * visaConstruction.getSourceTmm().getAdditionalAmounts()); }
	 *
	 * DE 55
	 *
	 * @Test public void setIccDataTest() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setIccData("123");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setIccData(20);
	 *
	 * assertEquals("123", visaConstruction.getTargetTmm().getIccData()); }
	 *
	 * DE 56
	 *
	 * @Test public void setReserved56Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved56("123");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved56(20);
	 *
	 * assertEquals("123", visaConstruction.getSourceTmm().getReserved56()); }
	 *
	 * DE 57
	 *
	 * @Test public void setReserverd57Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved57("123");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved57(20);
	 *
	 * assertEquals("123", visaConstruction.getSourceTmm().getReserved57()); }
	 *
	 * DE 58
	 *
	 * @Test public void setReserved58Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved58("123");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved58(20);
	 *
	 * assertEquals("123", visaConstruction.getSourceTmm().getReserved58()); }
	 *
	 * DE 59
	 *
	 * @Test public void setReserverd59Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved59("123");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved59(20);
	 *
	 * assertEquals("123", visaConstruction.getSourceTmm().getReserved59()); }
	 *
	 * DE 60
	 *
	 * @Test public void setTerminalDataTest() { // input 1 TransactionMessageModel
	 * sourceTmm1 = getSourceTmm(); sourceTmm1.setPosEntryMode("021");
	 * visaConstruction.setSourceTmm(sourceTmm1);
	 *
	 * visaConstruction.setTerminalData(60);
	 *
	 * assertEquals("020000000020",
	 * visaConstruction.getTargetTmm().getTerminalData()); }
	 *
	 * @Test public void setTerminalDataTestFor051() { // input 1
	 * TransactionMessageModel sourceTmm2 = getSourceTmm();
	 * sourceTmm2.setPosEntryMode("051"); visaConstruction.setSourceTmm(sourceTmm2);
	 *
	 * visaConstruction.setTerminalData(60);
	 *
	 * assertEquals("050000100020",
	 * visaConstruction.getTargetTmm().getTerminalData());
	 *
	 * }
	 *
	 * @Test public void setTerminalDataTestFor081() {
	 *
	 * // input 1 TransactionMessageModel sourceTmm3 = getSourceTmm();
	 * sourceTmm3.setPosEntryMode("081"); visaConstruction.setSourceTmm(sourceTmm3);
	 *
	 * visaConstruction.setTerminalData(60);
	 *
	 * assertEquals("051000000020",
	 * visaConstruction.getTargetTmm().getTerminalData()); }
	 *
	 * @Test public void setTerminalDataTestElse() { // input 4
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTerminalData("123"); sourceTmm.setPosEntryMode("12345");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTargetMsgType("0200");
	 * visaConstruction.setTargetMsgTypeId("510000");
	 *
	 * visaConstruction.setTerminalData(20);
	 *
	 * assertEquals("000000000140",
	 * visaConstruction.getTargetTmm().getTerminalData()); }
	 *
	 * DE 61
	 *
	 * @Test public void setCiadTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setCiad("600");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCiad(20);
	 *
	 * assertEquals("600", visaConstruction.getSourceTmm().getCiad());
	 *
	 * }
	 *
	 * DE 62
	 *
	 * @Test public void setPostalCodeTest() { String expected =
	 * "09 8000 0000 0000 0000 E8"; visaConstruction.setSourceTmm(getSourceTmm());
	 * visaConstruction.setTargetMsgType("0200");
	 * visaConstruction.setTargetMsgTypeId("200000");
	 * visaConstruction.setPostalCode(62); assertEquals(expected,
	 * visaConstruction.getTargetTmm().getPostalCode());
	 *
	 * }
	 *
	 * DE 63
	 *
	 * @Test public void setAtmPinOffsetDataTest() { // input
	 * visaConstruction.setTargetMsgType("0220");
	 * visaConstruction.setTargetMsgTypeId("220000");
	 *
	 * visaConstruction.setAtmPinOffsetData(20);
	 *
	 * assertEquals("07 A0 00 00 00 00 25 02",
	 * visaConstruction.getTargetTmm().getAtmPinOffsetData());
	 *
	 * // input for else
	 *
	 * visaConstruction.setTargetMsgType("0221");
	 * visaConstruction.setTargetMsgTypeId("222000");
	 *
	 * visaConstruction.setAtmPinOffsetData(20);
	 *
	 * assertEquals("05 80 00 00 00 00",
	 * visaConstruction.getTargetTmm().getAtmPinOffsetData());
	 *
	 * }
	 *
	 * DE 64
	 *
	 * @Test public void setMsgAuthCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgAuthCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setMsgAuthCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getMsgAuthCode()); }
	 *
	 * DE 65
	 *
	 * @Test public void setExtendedBitmapIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedBitmapIndicator("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setExtendedBitmapIndicator(20);
	 *
	 * assertEquals("50",
	 * visaConstruction.getSourceTmm().getExtendedBitmapIndicator()); }
	 *
	 * DE 66
	 *
	 * @Test public void setSettlementCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getSettlementCode()); }
	 *
	 * DE 67
	 *
	 * @Test public void setExtendedPaymentCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedPaymentCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setExtendedPaymentCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getExtendedPaymentCode());
	 * }
	 *
	 * DE 68
	 *
	 * @Test public void setReceiverCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReceiverCountryCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReceiverCountryCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReceiverCountryCode());
	 * }
	 *
	 * DE 69
	 *
	 * @Test public void setSettlementCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCountryCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementCountryCode(20);
	 *
	 * assertEquals("50",
	 * visaConstruction.getSourceTmm().getSettlementCountryCode()); }
	 *
	 * DE 70
	 *
	 * @Test public void setNetworkMgmtInfoCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNetworkMgmtInfoCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNetworkMgmtInfoCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getNetworkMgmtInfoCode());
	 * }
	 *
	 * DE 71
	 *
	 * @Test public void setMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgNo("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setMsgNo(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getMsgNo()); }
	 *
	 * DE 72
	 *
	 * @Test public void setLastMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setLastMsgNo("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setLastMsgNo(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getLastMsgNo()); }
	 *
	 * DE 73
	 *
	 * @Test public void setActionDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setActionDate("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setActionDate(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getActionDate()); }
	 *
	 * DE 74
	 *
	 * @Test public void setNoOfCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfCredits("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNoOfCredits(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getNoOfCredits()); }
	 *
	 * DE 75
	 *
	 * @Test public void setCreditsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversalNo("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCreditsReversalNo(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getCreditsReversalNo()); }
	 *
	 * DE 76
	 *
	 * @Test public void setNoOfDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfDebits("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNoOfDebits(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getNoOfDebits()); }
	 *
	 * DE 77
	 *
	 * @Test public void setDebitsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsReversalNo("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setDebitsReversalNo(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getDebitsReversalNo()); }
	 *
	 * DE 78
	 *
	 * @Test public void setTransferNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTransferNo("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTransferNo(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getTransferNo()); }
	 *
	 * DE 79
	 *
	 * @Test public void setTransferReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTransferReversalNo("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTransferReversalNo(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getTransferReversalNo());
	 * }
	 *
	 * DE 80
	 *
	 * @Test public void setNoOfInquiriesTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNoOfInquiries("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNoOfInquiries(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getNoOfInquiries()); }
	 *
	 * DE 81
	 *
	 * @Test public void setNoOfAuthsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfAuths("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNoOfAuths(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getNoOfAuths()); }
	 *
	 * DE 82
	 *
	 * @Test public void setCreditsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsProcessingFee("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCreditsProcessingFee(20);
	 *
	 * assertEquals("50",
	 * visaConstruction.getSourceTmm().getCreditsProcessingFee()); }
	 *
	 * DE 83
	 *
	 * @Test public void setCreditsTxnFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setCreditsTxnFee("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCreditsTxnFee(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getCreditsTxnFee()); }
	 *
	 * DE 84
	 *
	 * @Test public void setDebitsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsProcessingFee("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setDebitsProcessingFee(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getDebitsProcessingFee());
	 * }
	 *
	 * DE 85
	 *
	 * @Test public void setDebitsTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setDebitsTxnFee("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setDebitsTxnFee(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getDebitsTxnFee()); }
	 *
	 * DE 86
	 *
	 * @Test public void setTotalCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalCredits("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTotalCredits(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getTotalCredits()); }
	 *
	 * DE 87
	 *
	 * @Test public void setCreditsReversalTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversal("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setCreditsReversal(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getCreditsReversal()); }
	 *
	 * DE 88
	 *
	 * @Test public void setTotalDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalDebits("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTotalDebits(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getTotalDebits()); }
	 *
	 * DE 89
	 *
	 * @Test public void setDebitsReversalTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setDebitsReversal("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setDebitsReversal(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getDebitsReversal()); }
	 *
	 * DE 90
	 *
	 * @Test public void setOriginalDataElementsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setOriginalDataElements("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setOriginalDataElements(20);
	 *
	 * assertEquals("50",
	 * visaConstruction.getSourceTmm().getOriginalDataElements()); }
	 *
	 * DE 91
	 *
	 * @Test public void setFileUpdateCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setFileUpdateCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setFileUpdateCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getFileUpdateCode()); }
	 *
	 * DE 92
	 *
	 * @Test public void setFileSecurityCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setFileSecurityCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setFileSecurityCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getFileSecurityCode()); }
	 *
	 * DE 93
	 *
	 * @Test public void setResIndicatorTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResIndicator("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setResIndicator(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getResIndicator()); }
	 *
	 * DE 94
	 *
	 * @Test public void setServiceIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceIndicator("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setServiceIndicator(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getServiceIndicator()); }
	 *
	 * DE 95
	 *
	 * @Test public void setReplacementAmtsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReplacementAmts("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReplacementAmts(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReplacementAmts()); }
	 *
	 * DE 96
	 *
	 * @Test public void setMsgSecuirtyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setMsgSecuirtyCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setMsgSecuirtyCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getMsgSecuirtyCode()); }
	 *
	 * DE 97
	 *
	 * @Test public void setNetSettlementTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNetSettlement("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setNetSettlement(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getNetSettlement()); }
	 *
	 * DE 98
	 *
	 * @Test public void setPayeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPayee("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setPayee(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getPayee()); }
	 *
	 * DE 99
	 *
	 * @Test public void setSettlementIdCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementIdCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setSettlementIdCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getSettlementIdCode()); }
	 *
	 * DE 100
	 *
	 * @Test public void setReceiverIdCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setReceiverIdCode("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReceiverIdCode(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReceiverIdCode()); }
	 *
	 * DE 101
	 *
	 * @Test public void setFileNameTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setFileName("xyz");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setFileName(20);
	 *
	 * assertEquals("xyz", visaConstruction.getSourceTmm().getFileName()); }
	 *
	 * DE 102
	 *
	 * @Test public void setAccountIdentification1Test() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId1("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAccId1(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getAccId1()); }
	 *
	 * DE 103
	 *
	 * @Test public void setAccountIdentification2() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId2("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setAccId2(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getAccId2()); }
	 *
	 * DE 104
	 *
	 * @Test public void setTxnDescTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnDesc("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setTxnDesc(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getTxnDesc()); }
	 *
	 * DE 105
	 *
	 * @Test public void setReserved105Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved105("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved105(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved105()); }
	 *
	 * DE 106
	 *
	 * @Test public void setReserved106Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved106("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved106(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved106()); }
	 *
	 * DE 107
	 *
	 * @Test public void setReserved107Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved107("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved107(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved107()); }
	 *
	 * DE 108
	 *
	 * @Test public void setReserved108Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved108("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved108(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved108()); }
	 *
	 * DE 109
	 *
	 * @Test public void setReserved109Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved109("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved109(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved109()); }
	 *
	 * DE 110
	 *
	 * @Test public void setReserved110Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved110("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved110(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved110()); }
	 *
	 * DE 111
	 *
	 * @Test public void setReserved111Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved111("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved111(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved111()); }
	 *
	 * DE 112
	 *
	 * @Test public void setReserved112Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved112("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved112(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved112()); }
	 *
	 * DE 113
	 *
	 * @Test public void setReserved113Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved113("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved113(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved113()); }
	 *
	 * DE 114
	 *
	 * @Test public void setReserved114Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved114("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved114(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved114()); }
	 *
	 * DE 115
	 *
	 * @Test public void setReserved115Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved115("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved115(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved115()); }
	 *
	 * DE 116
	 *
	 * @Test public void setReserved116Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved116("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved116(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved116()); }
	 *
	 * DE 117
	 *
	 * @Test public void setReserved117Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved117("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved117(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved117()); }
	 *
	 * DE 118
	 *
	 * @Test public void setReserved118Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved118("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved118(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved118()); }
	 *
	 * DE 119
	 *
	 * @Test public void setReserved119Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved119("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved119(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved119()); }
	 *
	 * DE 120
	 *
	 * @Test public void setReserved120Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved120("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved120(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved120()); }
	 *
	 * DE 121
	 *
	 * @Test public void setReserved121Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved121("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved121(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved121()); }
	 *
	 * DE 122
	 *
	 * @Test public void setReserved122Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved122("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved122(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved122()); }
	 *
	 * DE 123
	 *
	 * @Test public void setReserved123Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved123("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved123(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved123()); }
	 *
	 * DE 124
	 *
	 * @Test public void setReserved124Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved124("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved124(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved124()); }
	 *
	 * DE 125
	 *
	 * @Test public void setReserved125Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved125("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved125(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved125()); }
	 *
	 * DE 126
	 *
	 * @Test public void setReserved126Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved126("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved126(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved126()); }
	 *
	 * DE 127
	 *
	 * @Test public void setReserved127Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved127("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved127(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved127()); }
	 *
	 * DE 128
	 *
	 * @Test public void setReserved128Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved128("50");
	 * visaConstruction.setSourceTmm(sourceTmm);
	 *
	 * visaConstruction.setReserved128(20);
	 *
	 * assertEquals("50", visaConstruction.getSourceTmm().getReserved128()); }
	 */

}
