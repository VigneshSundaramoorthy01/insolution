package com.isg.mtm.construct;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.isg.mw.mtm.construct.MessageConstructionHelper;

public class MessageConstructionHelperTest {

	/*
	 * @Test public void isMotoTestTrue() { boolean moto =
	 * MessageConstructionHelper.isMoto("0200", "000000"); assertTrue(moto);
	 * 
	 * boolean moto2 = MessageConstructionHelper.isMoto("0110", "510000");
	 * assertTrue(moto2);
	 * 
	 * boolean moto3 = MessageConstructionHelper.isMoto("0210", "510000");
	 * assertTrue(moto3);
	 * 
	 * boolean moto4 = MessageConstructionHelper.isMoto("0100", "510000");
	 * assertTrue(moto4);
	 * 
	 * }
	 * 
	 * @Test public void isMotoTestFalse() { boolean moto =
	 * MessageConstructionHelper.isMoto("0290", "050000"); assertFalse(moto);
	 * 
	 * }
	 * 
	 * @Test public void isRequestPurchaseTest() { boolean moto =
	 * MessageConstructionHelper.isPurchase("0200", "000000"); assertTrue(moto);
	 * 
	 * boolean moto2 = MessageConstructionHelper.isPurchase("0110", "510000");
	 * assertTrue(moto2);
	 * 
	 * boolean moto3 = MessageConstructionHelper.isPurchase("0210", "510000");
	 * assertTrue(moto3);
	 * 
	 * boolean moto4 = MessageConstructionHelper.isPurchase("0100", "510000");
	 * assertTrue(moto4);
	 * 
	 * }
	 * 
	 * @Test public void isRequestPurchaseFalse() { boolean moto =
	 * MessageConstructionHelper.isPurchase("0290", "050000"); assertFalse(moto);
	 * 
	 * }
	 * 
	 * @Test public void isCashWithdrawalTest() { boolean moto =
	 * MessageConstructionHelper.isCashWithdrawal("0200", "010000");
	 * assertTrue(moto);
	 * 
	 * boolean moto2 = MessageConstructionHelper.isCashWithdrawal("0110", "010000");
	 * assertTrue(moto2);
	 * 
	 * boolean moto3 = MessageConstructionHelper.isCashWithdrawal("0210", "010000");
	 * assertTrue(moto3);
	 * 
	 * boolean moto4 = MessageConstructionHelper.isCashWithdrawal("0100", "010000");
	 * assertTrue(moto4); }
	 * 
	 * @Test public void isCashWithdrawalFalse() { boolean moto =
	 * MessageConstructionHelper.isCashWithdrawal("0290", "050000");
	 * assertFalse(moto);
	 * 
	 * }
	 * 
	 * @Test public void isRequestCashAtPosTest() { boolean moto =
	 * MessageConstructionHelper.isCashAtPos("0200", "090000"); assertTrue(moto); }
	 * 
	 * @Test public void isRequestCashAtPosFalse() { boolean moto =
	 * MessageConstructionHelper.isCashAtPos("0200", "097000"); assertFalse(moto); }
	 * 
	 * @Test public void isRequestPreAuthTest() { boolean moto =
	 * MessageConstructionHelper.isCashAtPos("0100", "000000"); assertTrue(moto); }
	 * 
	 * @Test public void isRequestPreAuthFalse() { boolean moto =
	 * MessageConstructionHelper.isPreAuth("0200", "097000"); assertFalse(moto); }
	 * 
	 * @Test public void isRequestRefundReqTest() { boolean moto =
	 * MessageConstructionHelper.isPosRefundReq("0200", "200000"); assertTrue(moto);
	 * }
	 * 
	 * @Test public void isRequestRefundReqFalse() { boolean moto =
	 * MessageConstructionHelper.isPosRefundReq("0200", "097000");
	 * assertFalse(moto); }
	 * 
	 * @Test public void isRequestbalanceInqTest() { boolean moto =
	 * MessageConstructionHelper.isBalanceEnquiry("0100", "310000");
	 * assertTrue(moto); }
	 * 
	 * @Test public void isRequestbalanceInqFalse() { boolean moto =
	 * MessageConstructionHelper.isBalanceEnquiry("0200", "097000");
	 * assertFalse(moto); }
	 * 
	 * @Test public void isRequestVoidReqTest() { boolean moto =
	 * MessageConstructionHelper.isPosVoidRequest("0220", ""); assertTrue(moto); }
	 * 
	 * @Test public void isRequestVoidReqFalse() { boolean moto =
	 * MessageConstructionHelper.isPosVoidRequest("0400", ""); assertFalse(moto); }
	 */
}
