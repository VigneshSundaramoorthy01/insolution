package com.isg.mtm.parser;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.jpos.iso.ISOException;
import org.junit.Test;

import com.isg.mw.mtm.exception.MessageBuildException;
import com.isg.mw.mtm.parser.MwIsoPackager;
import com.isg.mw.mtm.parser.msg.BaseMessage;
import com.isg.mw.mtm.parser.msg.MwMessage;

public class MwIsoPackagerTest {

	/*
	 * private String rawMsg =
	 * "01 36 60 00 56 00 00 02 00 30 20 05 80 20 c0 1a 06 00 00 00 00 00 00 01 00 00 00 09 68 00 51 00 56 00 80 5e cc df 7d 2e 8e b4 08 af 62 20 8e 82 59 1d 19 86 9a b7 c9 fa b4 35 c7 25 54 67 84 2f b7 34 18 d6 7b af cb c6 a9 ec 02 48 50 59 42 4c 30 30 37 48 50 59 42 49 4a 41 4c 49 50 30 30 30 30 37 3e 07 ad bb c2 60 f6 05 09 87 65 43 21 00 00 01 01 45 9f 02 06 00 00 00 01 00 00 9f 03 06 00 00 00 00 00 00 84 07 a0 00 00 00 03 10 10 82 02 18 00 9f 36 02 02 dd 9f 07 02 ff 80 9f 26 08 b7 ca 31 23 3d 5d ef 06 9f 27 01 80 9f 34 03 42 03 00 9f 1e 08 31 33 30 32 39 37 37 34 9f 10 07 06 01 0a 03 a0 a8 01 9f 09 02 00 8c 9f 33 03 e0 f0 c8 9f 1a 02 03 56 9f 35 01 22 95 05 80 80 04 00 00 5f 2a 02 03 56 5f 34 01 01 9a 03 20 04 17 9c 01 00 9f 37 04 0f f5 70 ad 9f 41 04 00 00 09 68 9f 53 01 52 00 12 30 30 30 34 30 36 30 30 30 32 31 35 00 35 30 30 30 36 30 38 31 33 30 32 39 37 37 34 30 30 30 35 30 36 30 30 30 31 36 30 30 30 30 31 30 33 33 35 36"
	 * ;
	 * 
	 * private String msgFormat;
	 * 
	 * @Test public void parseTest() throws IOException {
	 * 
	 * msgFormat = new String(Files.readAllBytes(Paths.get(
	 * "/home/ISG/shital3986/git_project/SHITAL_WFH3_MTM/mtm_new_branch/mw/smartcontroller/src/main/resources/fields.xml"
	 * ))); InputStream msgFormatStream = new
	 * ByteArrayInputStream(msgFormat.getBytes());
	 * 
	 * MwMessage parse = MwIsoPackager.parse(rawMsg.getBytes(), msgFormatStream);
	 * 
	 * assertNotNull(parse); }
	 * 
	 * @Test public void parseTestMsgEmpty() throws IOException { String errMsg =
	 * "Message is empty"; String message = null; msgFormat = new
	 * String(Files.readAllBytes(Paths.get(
	 * "/home/ISG/shital3986/git_project/SHITAL_WFH3_MTM/mtm_new_branch/mw/smartcontroller/src/main/resources/fields.xml"
	 * ))); InputStream msgFormatStream = new
	 * ByteArrayInputStream(msgFormat.getBytes()); try { MwIsoPackager.parse(null,
	 * msgFormatStream); } catch (MessageBuildException e) { message =
	 * e.getMessage(); } assertEquals(errMsg, message); }
	 * 
	 * @Test public void parseTestMsgParsingExcepton() throws IOException { String
	 * errMsg = "Error while parsing a message to POJO"; String message = null;
	 * msgFormat = new String(Files.readAllBytes(Paths.get(
	 * "/home/ISG/shital3986/git_project/SHITAL_WFH3_MTM/mtm_new_branch/mw/smartcontroller/src/main/resources/fields.xml"
	 * ))); InputStream msgFormatStream = new
	 * ByteArrayInputStream(msgFormat.getBytes()); try {
	 * MwIsoPackager.parse("11111111111111111111111111111111111111".getBytes(),
	 * msgFormatStream); } catch (MessageBuildException e) { message =
	 * e.getMessage(); } assertEquals(errMsg, message); }
	 * 
	 * @Test public void buildMessageTest() throws ISOException, IOException {
	 * msgFormat = new String(Files.readAllBytes(Paths.get(
	 * "/home/ISG/shital3986/git_project/SHITAL_WFH3_MTM/mtm_new_branch/mw/smartcontroller/src/main/resources/fields.xml"
	 * ))); InputStream msgFormatStream = new
	 * ByteArrayInputStream(msgFormat.getBytes());
	 * 
	 * BaseMessage baseMessage = new BaseMessage(); baseMessage.setMTI("0200");
	 * 
	 * MwIsoPackager.buildMessage("0200", baseMessage, msgFormatStream); //
	 * assertNotNull(buildMessage); }
	 * 
	 * @Test public void buildMessageException() throws IOException, ISOException {
	 * BaseMessage baseMessage = new BaseMessage(); baseMessage.setMTI("0200");
	 * 
	 * String errMsg = "Error while building a message"; String message = null;
	 * msgFormat = new String(Files.readAllBytes(Paths.get(
	 * "/home/ISG/shital3986/git_project/SHITAL_WFH3_MTM/mtm_new_branch/mw/smartcontroller/src/main/resources/fields.xml"
	 * ))); try { MwIsoPackager.buildMessage("0200", baseMessage, null); } catch
	 * (MessageBuildException e) { message = e.getMessage(); } assertEquals(errMsg,
	 * message); }
	 */

}
