package com.isg.mtm.transform;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.isg.mw.core.model.constants.TlmMessageType;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.MessageParsingException;
import com.isg.mw.mtm.parser.MwIsoPackager;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.transform.visa.VisaMessageTransformation;

//@RunWith(PowerMockRunner.class)
//@PrepareForTest({ MessageTransformationContext.class, MwIsoPackager.class })
public class MessageTransformerTest {

	/*
	 * @Rule public final ExpectedException exception = ExpectedException.none();
	 * 
	 * private String rawMsg =
	 * "01 36 60 00 56 00 00 02 00 30 20 05 80 20 c0 1a 06 00 00 00 00 00 00 01 00 00 00 09 68 00 51 00 56 00 80 5e cc df 7d 2e 8e b4 08 af 62 20 8e 82 59 1d 19 86 9a b7 c9 fa b4 35 c7 25 54 67 84 2f b7 34 18 d6 7b af cb c6 a9 ec 02 48 50 59 42 4c 30 30 37 48 50 59 42 49 4a 41 4c 49 50 30 30 30 30 37 3e 07 ad bb c2 60 f6 05 09 87 65 43 21 00 00 01 01 45 9f 02 06 00 00 00 01 00 00 9f 03 06 00 00 00 00 00 00 84 07 a0 00 00 00 03 10 10 82 02 18 00 9f 36 02 02 dd 9f 07 02 ff 80 9f 26 08 b7 ca 31 23 3d 5d ef 06 9f 27 01 80 9f 34 03 42 03 00 9f 1e 08 31 33 30 32 39 37 37 34 9f 10 07 06 01 0a 03 a0 a8 01 9f 09 02 00 8c 9f 33 03 e0 f0 c8 9f 1a 02 03 56 9f 35 01 22 95 05 80 80 04 00 00 5f 2a 02 03 56 5f 34 01 01 9a 03 20 04 17 9c 01 00 9f 37 04 0f f5 70 ad 9f 41 04 00 00 09 68 9f 53 01 52 00 12 30 30 30 34 30 36 30 30 30 32 31 35 00 35 30 30 30 36 30 38 31 33 30 32 39 37 37 34 30 30 30 35 30 36 30 30 30 31 36 30 30 30 30 31 30 33 33 35 36"
	 * ; private OffsetDateTime arrivalTime = OffsetDateTime.now(); private String
	 * entityId = "Kotak"; private String epId = "Visa.Kotak"; private String
	 * epMsgType = "0200"; private String msgFormat; private
	 * Class<VisaMessageTransformation> className = VisaMessageTransformation.class;
	 * private String methodName = "setMti"; private String processingCode =
	 * "000000"; private String txnTypeName = "purchase.request";
	 * 
	 * private static final Map<String, Map<String, Map<String,
	 * MessageTransformationConfig>>> MsgConfig = new ConcurrentHashMap<>();
	 * 
	 * @Test public void toPojoTest() throws IOException { TransactionTypeConfig
	 * trConfig = new TransactionTypeConfig(epMsgType, processingCode, txnTypeName);
	 * 
	 * PowerMockito.mockStatic(MessageTransformationContext.class);
	 * PowerMockito.when(MessageTransformationContext.getMessageTransformationConfig
	 * (Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn(getMessageTransformationConfig());
	 * 
	 * MessageTransformationContext.getMessageTransformationConfig(entityId, epId,
	 * trConfig); TransactionMessageModel model =
	 * MessageTransformer.toPojo(entityId, OffsetDateTime.now(), epId,
	 * rawMsg.getBytes(), TlmMessageType.REQUEST); assertEquals("000000",
	 * model.getProcessingCode()); assertEquals("000000010000", model.getTxnAmt());
	 * assertEquals("0200", model.getTransactionName()); }
	 * 
	 * @Test public void toPojoTestBuildException() throws IOException {
	 * PowerMockito.mockStatic(MessageTransformationContext.class);
	 * PowerMockito.when(MessageTransformationContext.getMessageTransformationConfig
	 * (Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn(getMessageTransformationConfigException());
	 * 
	 * TransactionMessageModel model = MessageTransformer.toPojo(entityId,
	 * OffsetDateTime.now(), epId, rawMsg.getBytes(), TlmMessageType.REQUEST);
	 * assertNull(model); }
	 * 
	 * @Test public void toPojoTestParsingException() throws IOException {
	 * 
	 * PowerMockito.mockStatic(MessageTransformationContext.class);
	 * PowerMockito.when(MessageTransformationContext.getMessageTransformationConfig
	 * (Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn(getMessageTransformationConfig());
	 * 
	 * PowerMockito.mockStatic(MwIsoPackager.class);
	 * PowerMockito.when(MwIsoPackager.parse(Mockito.any(),
	 * Mockito.any())).thenThrow(MessageParsingException.class);
	 * 
	 * MessageTransformer.toPojo(entityId, OffsetDateTime.now(), epId,
	 * rawMsg.getBytes(), TlmMessageType.REQUEST); }
	 * 
	 * public MessageTransformationConfig getMessageTransformationConfig() throws
	 * IOException {
	 * 
	 * msgFormat = new String(Files.readAllBytes(Paths.get(
	 * "/home/ISG/shital3986/git_project/SHITAL_WFH3_MTM/mtm_new_branch/mw/smartcontroller/src/main/resources/fields.xml"
	 * ))); MessageTransformationConfig msgConfig = new
	 * MessageTransformationConfig(); msgConfig.setBusinessRuleClass(className);
	 * msgConfig.setMethodName(methodName); msgConfig.setMsgFormat(msgFormat);
	 * msgConfig.setTmmConfig(getTmmMap());
	 * 
	 * Map<String, MessageTransformationConfig> msgTypeMTConfigMap = new
	 * HashMap<>(); msgTypeMTConfigMap.put(epMsgType, msgConfig);
	 * 
	 * Map<String, Map<String, MessageTransformationConfig>> epIdMsgTypeMap = new
	 * HashMap<>(); epIdMsgTypeMap.put(epId, msgTypeMTConfigMap);
	 * 
	 * MsgConfig.put(entityId + "." + epId, epIdMsgTypeMap);
	 * 
	 * return MsgConfig.get(entityId + "." + epId).get(epId).get(epMsgType);
	 * 
	 * }
	 * 
	 * public Map<Integer, String> getTmmMap() { Map<Integer, String> fieldsMap =
	 * new HashMap<>(); fieldsMap.put(1, TmmConstants.BITMAP); fieldsMap.put(2,
	 * TmmConstants.PAN); fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
	 * fieldsMap.put(4, TmmConstants.TXN_AMT); fieldsMap.put(11, TmmConstants.STAN);
	 * fieldsMap.put(14, TmmConstants.EXPIRATION_DATE); fieldsMap.put(22,
	 * TmmConstants.POS_ENTRY_MODE); fieldsMap.put(24, TmmConstants.NIIID);
	 * fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE); fieldsMap.put(35,
	 * TmmConstants.TRACK2_DATA); fieldsMap.put(41,
	 * TmmConstants.CARD_ACCEPTOR_TERMINAL_ID); fieldsMap.put(42,
	 * TmmConstants.CARD_ACCEPTOR_ID); fieldsMap.put(45, TmmConstants.TRACK1_DATA);
	 * fieldsMap.put(52, TmmConstants.PIN); fieldsMap.put(53,
	 * TmmConstants.SECURITY_CONTROL_INFO); fieldsMap.put(55,
	 * TmmConstants.ICC_DATA); fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
	 * fieldsMap.put(61, TmmConstants.CIAD); fieldsMap.put(62,
	 * TmmConstants.POSTAL_CODE); fieldsMap.put(63,
	 * TmmConstants.ATM_PIN_OFFSET_DATA);
	 * 
	 * return fieldsMap; }
	 * 
	 * public MessageTransformationConfig getMessageTransformationConfigException()
	 * throws IOException {
	 * 
	 * MessageTransformationConfig msgConfig = new MessageTransformationConfig();
	 * msgConfig.setBusinessRuleClass(className);
	 * msgConfig.setMethodName(methodName); msgConfig.setMsgFormat("123");
	 * msgConfig.setTmmConfig(getTmmMap());
	 * 
	 * Map<String, MessageTransformationConfig> msgTypeMTConfigMap = new
	 * HashMap<>(); msgTypeMTConfigMap.put(epMsgType, msgConfig);
	 * 
	 * Map<String, Map<String, MessageTransformationConfig>> epIdMsgTypeMap = new
	 * HashMap<>(); epIdMsgTypeMap.put(epId, msgTypeMTConfigMap);
	 * 
	 * MsgConfig.put(entityId + "." + epId, epIdMsgTypeMap);
	 * 
	 * return MsgConfig.get(entityId + "." + epId).get(epId).get(epMsgType);
	 * 
	 * }
	 */

}
