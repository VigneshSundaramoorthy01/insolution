package com.isg.mtm.construct.mastercard;

import org.junit.Test;
import org.mockito.InjectMocks;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.mastercard.VoidReversalMasterCardMessageConstruction;
import com.isg.mw.mtm.parser.msg.BaseMessage;
public class VoidReversalMasterCardMessageConstructionTest {
	
	@InjectMocks
	private static VoidReversalMasterCardMessageConstruction voidReversalMasterCardMessageConstructionMock;

	private static final BaseMessage baseMessageMock = new BaseMessage();

	private static final TransactionMessageModel messageModelMock = new TransactionMessageModel();

	private static final SwitchBaseMessageConstruction iMessageConstructionMock = null;
	
	private TransactionMessageModel getSourceTmm() {
		TransactionMessageModel sourceTmm = new TransactionMessageModel();
		sourceTmm.setTxnAmt("2000");
		sourceTmm.setTransmissionTime("100");
		sourceTmm.setPosConditionCode("08");
		sourceTmm.setEntityId("121");
		sourceTmm.setCardAcceptorId("123");
		sourceTmm.setCardAcceptorTerminalId("141");
		return sourceTmm;
	}
	
	@Test(expected = NullPointerException.class)
	public void setExpirationDate_acceptsFieldNo() {

		TransactionMessageModel sourceTmm = getSourceTmm();
		sourceTmm.setExpirationDate("2204");
		baseMessageMock.set(14, "2204");
		voidReversalMasterCardMessageConstructionMock.setExpirationDate(14);
		

	}

}
