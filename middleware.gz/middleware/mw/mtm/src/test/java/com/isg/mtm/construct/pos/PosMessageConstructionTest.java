package com.isg.mtm.construct.pos;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.pos.PosMessageConstruction;
import com.isg.mw.mtm.parser.msg.BaseMessage;

public class PosMessageConstructionTest {

	/*
	 * @Mock protected BaseMessage baseMessage;
	 * 
	 * @Mock public HsmProcessorService hsmService;
	 * 
	 * @Mock protected MapsInfoService mapsService;
	 * 
	 * @Mock private SwitchBaseMessageConstruction switchBaseMessageConstruction;
	 * 
	 * @InjectMocks private PosMessageConstruction posConstruction;
	 * 
	 * @Before public void init() {
	 * 
	 * MockitoAnnotations.initMocks(this); }
	 * 
	 * private TransactionMessageModel getSourceTmm() { TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel(); sourceTmm.setTxnAmt("2000");
	 * sourceTmm.setTransmissionTime("100"); sourceTmm.setPosConditionCode("08");
	 * sourceTmm.setEntityId("121"); sourceTmm.setCardAcceptorId("123");
	 * sourceTmm.setCardAcceptorTerminalId("141"); return sourceTmm; }
	 * 
	 * private MapsInfoModel getMapsInfoModel() { MapsInfoModel merchantInfo = new
	 * MapsInfoModel(); merchantInfo.setMid("145404453445300");
	 * merchantInfo.setTid("11004448");
	 * merchantInfo.setEntityId("2341231223131232");
	 * merchantInfo.setForwardingInstitutionId("1234"); //
	 * merchantInfo.setAcquirerInstitutionId("12345");
	 * merchantInfo.setAcquiringInstitutionCountryCode("666666");
	 * merchantInfo.setMerchantType("7777"); merchantInfo.setMerchantName("Toyoto");
	 * merchantInfo.setMerchantCity("Airoli");
	 * merchantInfo.setMerchantCountryCode("405421"); return merchantInfo; }
	 * 
	 *//**
		 * 1.<br>
		 * ISO8583 -1987, AS2805 - Secondary bitmap <br>
		 * Base24, ISG, XML - Bit map
		 */
	/*
	 * 
	 * @Test public void setBitMapTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setBitMap("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setBitMap(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getBitMap()); }
	 * 
	 *//**
		 * 2.<br>
		 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
		 * Account Number
		 */
	/*
	 * 
	 * @Test public void setPanTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPan("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setPan(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getPan()); }
	 * 
	 *//**
		 * 3. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
		 * <br>
		 * mPOS - Transaction Type
		 */
	/*
	 * 
	 * @Test public void setProcessingCode() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setProcessingCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setProcessingCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getProcessingCode()); }
	 * 
	 *//**
		 * 4. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
		 * CyberSource API - AuthorizedAmount
		 */
	/*
	 * 
	 * @Test public void setTxnAmt() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setAdditionalAmounts("2000");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setTargetMsgType("0100");
	 * posConstruction.setTargetMsgTypeId("310000");
	 * 
	 * posConstruction.setTxnAmt(20);
	 * 
	 * assertEquals("2000", posConstruction.getTargetTmm().getTxnAmt());
	 * 
	 * }
	 * 
	 * @Test public void setTxnAmtElse() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTxnAmt("1000");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setTargetMsgType("0140");
	 * posConstruction.setTargetMsgTypeId("317000");
	 * 
	 * posConstruction.setTxnAmt(20);
	 * 
	 * assertEquals("1000", posConstruction.getTargetTmm().getTxnAmt()); }
	 * 
	 *//**
		 * 5.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
		 */
	/*
	 * 
	 * @Test public void setSettlementAmtTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementAmt("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementAmt(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementAmt()); }
	 * 
	 *//**
		 * 6.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
		 */
	/*
	 * 
	 * @Test public void setCardHolderBillingAmtTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCardHolderBillingAmt("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardHolderBillingAmt(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardHolderBillingAmt());
	 * 
	 * }
	 * 
	 *//**
		 * 7. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
		 */
	/*
	 * 
	 * @Test public void setTransmissionTimeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTransmissionTime("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setTransmissionTime(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getTransmissionTime()); }
	 * 
	 *//**
		 * 8. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
		 */
	/*
	 * 
	 * @Test public void setCardHolderBillingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCardHolderBillingFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardHolderBillingFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardHolderBillingFee()); }
	 * 
	 *//**
		 * 9. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
		 */
	/*
	 * 
	 * @Test public void setSettlementConversionRateTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementConversionRate("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementConversionRate(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementConversionRate()); }
	 * 
	 *//**
		 * 10. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
		 */
	/*
	 * 
	 * @Test public void setCardHolderBillingConversionRateTest() {
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingConversionRate("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardHolderBillingConversionRate(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardHolderBillingConversionRate()); }
	 * 
	 *//**
		 * 11. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
		 * <br>
		 * CyberSource API - T id
		 */
	/*
	 * 
	 * @Test public void setStanTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setStan("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setStan(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getStan()); }
	 * 
	 *//**
		 * 12. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
		 * CyberSource API - Transaction Local Date Time
		 */
	/*
	 * 
	 * @Test public void setLocalTxnTimeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setLocalTxnTime("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setLocalTxnTime(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getLocalTxnTime()); }
	 * 
	 *//**
		 * 13. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
		 */
	/*
	 * 
	 * @Test public void setLocalTxnDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setLocalTxnDate("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setLocalTxnDate(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getLocalTxnDate()); }
	 * 
	 *//**
		 * 14. <br>
		 * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
		 * Date
		 */
	/*
	 * 
	 * @Test public void setExpirationDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setExpirationDate("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setExpirationDate(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getExpirationDate()); }
	 * 
	 *//**
		 * 15. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
		 */
	/*
	 * 
	 * @Test public void setSettlementDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementDate("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementDate(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementDate()); }
	 * 
	 *//**
		 * 16. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
		 */
	/*
	 * 
	 * @Test public void setConversionDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setConversionDate("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setConversionDate(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getConversionDate()); }
	 * 
	 *//**
		 * 17. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
		 */
	/*
	 * 
	 * @Test public void setCaptureDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setCaptureDate("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setCaptureDate(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getCaptureDate()); }
	 * 
	 *//**
		 * 18.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
		 * ISO8583 -1987, CyberSource API - Category Code
		 */
	/*
	 * 
	 * @Test public void setMerchantTypeTest() { // input
	 * posConstruction.setTargetMsgType("0200");
	 * posConstruction.setTargetMsgTypeId("010000");
	 * 
	 * posConstruction.setMerchantType(20);
	 * 
	 * assertEquals("6010", posConstruction.getTargetTmm().getMerchantType()); }
	 * 
	 * @Test public void setMerchantTypeTestElse() { // input
	 * 
	 * Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setMerchantType("visa"); posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setTargetMsgType("0150");
	 * posConstruction.setTargetMsgTypeId("010010");
	 * 
	 * posConstruction.setMerchantType(20);
	 * 
	 * assertEquals("7777", posConstruction.getTargetTmm().getMerchantType());
	 * 
	 * }
	 * 
	 *//**
		 * 19. <br>
		 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
		 * Country Code <br>
		 * mPOS - terminalCountryCode
		 */
	/*
	
	*//**
		 * 20. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
		 * code
		 */
	/*
	 * 
	 * @Test public void setPanExtendedCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanExtendedCountryCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setPanExtendedCountryCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getPanExtendedCountryCode()); }
	 * 
	 *//**
		 * 21. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
		 */
	/*
	 * 
	 * @Test public void setPanForwardingCountryCodeTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPanForwardingCountryCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setPanForwardingCountryCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getPanForwardingCountryCode()); }
	 * 
	 *//**
		 * 22. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
		 * Entry Mode <br>
		 * mPOS - NFC Enabled
		 */
	/*
	 * 
	 * @Test public void setPosEntryModeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPosEntryMode("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setPosEntryMode(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getPosEntryMode()); }
	 * 
	 *//**
		 * 23. <br>
		 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
		 */
	/*
	 * 
	 * @Test public void setCardSeqNoTest() { // input
	 * Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm(); sourceTmm.setIccData(
	 * "9F02060000000030009F03060000000000008407A000000003101082023C009F360201F79F0702FF009F26080F380F214766ADF89F2701809F34034203009F1E0830313031353734349F100706010A03A0A8049F0902008C9F3303E0F0C89F1A0203569F350122950508800400005F2A0203565F3401019A031912109C01009F3704B1F0394E9F4104000000319F530152"
	 * ); posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setTargetMsgType("0280");
	 * posConstruction.setTargetMsgTypeId("510090");
	 * 
	 * posConstruction.setCardSeqNo(20); assertEquals("001",
	 * posConstruction.getTargetTmm().getCardSeqNo()); }
	 * 
	 *//**
		 * 24. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
		 * CyberSource API - Type
		 */
	/*
	 * 
	 * @Test public void setNetworkInternationalIdTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNiiId("2000");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setNiiId(20);
	 * 
	 * assertEquals("2000", posConstruction.getSourceTmm().getNiiId()); }
	 * 
	 *//**
		 * 25. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
		 */
	/*
	 * 
	 * @Test public void setPosConditionCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPosConditionCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setPosConditionCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getPosConditionCode()); }
	 * 
	 *//**
		 * 26. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
		 */
	/*
	 * 
	 * @Test public void setPosCaptureCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setPosCaptureCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setPosCaptureCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getPosCaptureCode()); }
	 * 
	 *//**
		 * 27. <br>
		 * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
		 * length
		 */
	/*
	 * 
	 * @Test public void setAuthIdResLengthTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAuthIdResLength("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setAuthIdResLength(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getAuthIdResLength()); }
	 * 
	 *//**
		 * 28. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
		 */
	/*
	 * 
	 * @Test public void setTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTxnFee(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTxnFee());
	 * 
	 * }
	 * 
	 *//**
		 * 29. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
		 */
	/*
	 * 
	 * @Test public void setSettlementFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementFee());
	 * 
	 * }
	 * 
	 *//**
		 * 30. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
		 */
	/*
	 * 
	 * @Test public void setTxnProcessingFeeTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnProcessingFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setTxnProcessingFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getTxnProcessingFee()); }
	 * 
	 *//**
		 * 31.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
		 * 
		 */
	/*
	 * 
	 * @Test public void setSettlementProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementProcessingFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementProcessingFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementProcessingFee());
	 * 
	 * }
	 * 
	 *//**
		 * 32. <br>
		 * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
		 * Code
		 */
	/*
	 * 
	 * @Test public void setAquirerIdCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setAquirerIdCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setAquirerIdCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getAquirerIdCode()); }
	 * 
	 *//**
		 * 33.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
		 * Code
		 */
	/*
	 * 
	 * @Test public void setForwardingInstIdCodeTest() {
	 * 
	 * Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setForwardingInstIdCode("5000");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setForwardingInstIdCode(20);
	 * 
	 * assertEquals("1234",
	 * posConstruction.getTargetTmm().getForwardingInstIdCode()); }
	 * 
	 *//**
		 * 34.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
		 */
	/*
	 * 
	 * @Test public void setPanExtendedTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPanExtended("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setPanExtended(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getPanExtended());
	 * 
	 * }
	 * 
	 *//**
		 * 35.<br>
		 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
		 * 
		 */
	/*
	 * 
	 * @Test public void setTrack2DataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack2Data("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTrack2Data(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTrack2Data());
	 * 
	 * }
	 * 
	 *//**
		 * 36.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
		 */
	/*
	 * 
	 * @Test public void setTrack3DataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack3Data("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTrack3Data(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTrack3Data());
	 * 
	 * }
	 * 
	 *//**
		 * 37.<br>
		 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
		 * Number<br>
		 * CyberSource API - TransactionId
		 */
	/*
	 * 
	 * @Test public void setRetrievalRefNoTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setRetrievalRefNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setRetrievalRefNo(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getRetrievalRefNo());
	 * 
	 * }
	 * 
	 *//**
		 * 38.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
		 * Response<br>
		 * mPOS - AuthCode
		 */
	/*
	 * 
	 * @Test public void setAuthIdResTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setAuthIdRes("200");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setAuthIdRes(30);
	 * 
	 * assertEquals("200", posConstruction.getTargetTmm().getAuthIdRes()); }
	 * 
	 *//**
		 * 39.<br>
		 * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
		 * mPOS - Status Code
		 */
	/*
	 * 
	 * @Test public void setResCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResCode("200");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setResCode(30);
	 * 
	 * assertEquals("200", posConstruction.getTargetTmm().getResCode()); }
	 * 
	 *//**
		 * 40.<br>
		 * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
		 */
	/*
	 * 
	 * @Test public void setServiceRestrictionCodeTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setServiceRestrictionCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setServiceRestrictionCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getServiceRestrictionCode()); }
	 * 
	 *//**
		 * 41.<br>
		 * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
		 * Identification
		 * 
		 */
	/*
	 * 
	 * @Test public void setCardAcceptorTerminalIdTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardAcceptorTerminalId("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardAcceptorTerminalId(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardAcceptorTerminalId()); }
	 * 
	 *//**
		 * 42. <br>
		 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
		 * Identification code<br>
		 * mPOS - TxnId
		 */
	/*
	 * 
	 * @Test public void setCardAcceptorIdTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setCardAcceptorId("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardAcceptorId(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardAcceptorId()); }
	 * 
	 *//**
		 * 43.<br>
		 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
		 * Name/Location
		 */
	/*
	 * 
	 * @Test public void setCardAcceptorInfoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCardAcceptorInfo("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardAcceptorInfo(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardAcceptorInfo()); }
	 * 
	 *//**
		 * 44.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
		 */
	/*
	 * 
	 * @Test public void setAdditionalResDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalResData("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setAdditionalResData(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getAdditionalResData()); }
	 * 
	 *//**
		 * 45.<br>
		 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
		 */
	/*
	 * 
	 * @Test public void setTrack1DataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack1Data("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTrack1Data(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTrack1Data()); }
	 * 
	 *//**
		 * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
		 */
	/*
	 * 
	 * @Test public void setIsoAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setIsoAd("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setIsoAd(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getIsoAd()); }
	 * 
	 *//**
		 * 47.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Additional Data National
		 */
	/*
	 * 
	 * @Test public void setNationalAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNationalAd("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setNationalAd(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getNationalAd()); }
	 * 
	 *//**
		 * 48.<br>
		 * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
		 */
	/*
	 * 
	 * @Test public void setPrivateAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPrivateAd("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setPrivateAd(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getPrivateAd()); }
	 * 
	 *//**
		 * 49.<br>
		 * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
		 * Code
		 */
	/*
	 * 
	 * @Test public void setTxnCurrencyCodeTest() {
	 * 
	 * Mockito.when(mapsService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnCurrencyCode("645"); posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setTxnCurrencyCode(20);
	 * 
	 * assertEquals("1111", posConstruction.getTargetTmm().getTxnCurrencyCode()); }
	 * 
	 *//**
		 * 50.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
		 */
	/*
	 * 
	 * @Test public void setSettlementCurrenyCodeTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setSettlementCurrenyCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementCurrenyCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementCurrenyCode()); }
	 * 
	 *//**
		 * 51.<br>
		 * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
		 */
	/*
	 * 
	 * @Test public void setCardHolderBillingCurrencyCode() {
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingCurrencyCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCardHolderBillingCurrencyCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCardHolderBillingCurrencyCode());
	 * 
	 * }
	 * 
	 *//**
		 * 52.<br>
		 * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
		 * (PIN) Data<br>
		 * CyberSource API - Encrypted Pin
		 */
	/*
	 * 
	 * @Test public void setPinTest() {
	 * 
	 * Mockito.when(hsmService.pinTranslation(Mockito.any(), Mockito.any(),
	 * Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("280595");
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnCurrencyCode("645"); posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * setPanTest();
	 * 
	 * posConstruction.setPin(20);
	 * 
	 * assertEquals("280595", posConstruction.getTargetTmm().getPin()); }
	 * 
	 *//**
		 * 53.<br>
		 * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
		 * Information<br>
		 * CyberSource API - Encrypted Key Serial Number
		 */
	/*
	 * 
	 * @Test public void setSecurityControlInfo() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSecurityControlInfo("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSecurityControlInfo(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSecurityControlInfo()); }
	 * 
	 *//**
		 * 54.<br>
		 * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
		 */
	/*
	 * 
	 * @Test public void setAdditionalAmounts() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setAdditionalAmounts("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setAdditionalAmounts(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getAdditionalAmounts()); }
	 * 
	 *//**
		 * 55.<br>
		 * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
		 * Base24 - ISO Reserved<br>
		 * CyberSource API- EMV
		 */
	/*
	 * 
	 * @Test public void setIccData() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setIccData("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setIccData(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getIccData()); }
	 * 
	 *//**
		 * 56.<br>
		 * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
		 */
	/*
	 * 
	 * @Test public void setReserved56() { // intentionally left blank }
	 * 
	 * 
	 *//**
		 * 57.<br>
		 * ISO8583-1987,Base24, XML - Reserved for national use<br>
		 * AS2805 - Amount cash
		 */
	/*
	 * 
	 * @Test public void setReserverd57() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved57("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved57(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved57());
	 * 
	 * }
	 * 
	 *//**
		 * 58.<br>
		 * ISO8583-1987,Base24, XML - Reserved for national use<br>
		 * AS2805 - Ledger balance
		 */
	/*
	 * 
	 * @Test public void setReserved58() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved58("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved58(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved58());
	 * 
	 * }
	 * 
	 *//**
		 * 59.<br>
		 * ISO8583-1987,Base24, XML - Reserved for national use<br>
		 * AS2805 - Account balance, Cleared funds
		 */
	/*
	 * 
	 * @Test public void setReserved59Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved59("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved59(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved59()); }
	 * 
	 *//**
		 * 60.<br>
		 * ISO8583-1987 - Reserved for national use<br>
		 * AS2805,ISG, XML - Reserved private<br>
		 * Base24 - Terminal Data
		 */
	/*
	 * 
	 * @Test public void setTerminalData() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTerminalData("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTerminalData(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTerminalData()); }
	 * 
	 *//**
		 * 61.<br>
		 * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
		 * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
		 * Data
		 */
	/*
	 * 
	 * @Test public void setCiadTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCiad("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCiad(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCiad()); }
	 * 
	 *//**
		 * 62.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
		 * Base24 - Postal Code
		 */
	/*
	 * 
	 * @Test public void setPostalCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPostalCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setPostalCode(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getPostalCode()); }
	 * 
	 *//**
		 * 63.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
		 * Base24 - ATM PIN Offset POS Additional Data
		 */
	/*
	 * 
	 * @Test public void setAtmPinOffsetDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAtmPinOffsetData("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setAtmPinOffsetData(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getAtmPinOffsetData()); }
	 * 
	 *//**
		 * 64.<br>
		 * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
		 * Base24 -Primary Message Authentication Code
		 */
	/*
	 * 
	 * @Test public void setMsgAuthCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgAuthCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setMsgAuthCode(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getMsgAuthCode());
	 * 
	 * }
	 * 
	 *//**
		 * 65.<br>
		 * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
		 * Base24 -Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setExtendedBitmapIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedBitmapIndicator("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setExtendedBitmapIndicator(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getExtendedBitmapIndicator()); }
	 * 
	 *//**
		 * 66.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Settlement Code
		 */
	/*
	 * 
	 * @Test public void setSettlementCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementCode()); }
	 * 
	 *//**
		 * 67.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Extended payment code
		 */
	/*
	 * 
	 * @Test public void setExtendedPaymentCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedPaymentCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setExtendedPaymentCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getExtendedPaymentCode());
	 * 
	 * }
	 * 
	 *//**
		 * 68.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
		 * mPOS - Transaction Country Code
		 */
	/*
	 * 
	 * @Test public void setReceiverCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReceiverCountryCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReceiverCountryCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReceiverCountryCode());
	 * 
	 * }
	 * 
	 *//**
		 * 69.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
		 * 
		 */
	/*
	 * 
	 * @Test public void setSettlementCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCountryCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementCountryCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementCountryCode()); }
	 * 
	 *//**
		 * 70.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
		 */
	/*
	 * 
	 * @Test public void setNetworkMgmtInfoCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNetworkMgmtInfoCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setNetworkMgmtInfoCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getNetworkMgmtInfoCode()); }
	 * 
	 *//**
		 * 71.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Message Number
		 */
	/*
	 * 
	 * @Test public void setMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setMsgNo(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getMsgNo());
	 * 
	 * }
	 * 
	 *//**
		 * 72.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Message Number Last
		 */
	/*
	 * 
	 * @Test public void setLastMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setLastMsgNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setLastMsgNo(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getLastMsgNo());
	 * 
	 * }
	 * 
	 *//**
		 * 73.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Action Date
		 */
	/*
	 * 
	 * @Test public void setActionDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setActionDate("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setActionDate(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getActionDate());
	 * 
	 * }
	 * 
	 *//**
		 * 74.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Number Credits
		 */
	/*
	 * 
	 * @Test public void setNoOfCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfCredits("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setNoOfCredits(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getNoOfCredits()); }
	 * 
	 *//**
		 * 75.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
		 */
	/*
	 * 
	 * @Test public void setCreditsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversalNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCreditsReversalNo(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCreditsReversalNo());
	 * 
	 * }
	 * 
	 *//**
		 * 76.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Number Debits
		 */
	/*
	 * 
	 * @Test public void setNoOfDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfDebits("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setNoOfDebits(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getNoOfDebits());
	 * 
	 * }
	 * 
	 *//**
		 * 77.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
		 */
	/*
	 * 
	 * @Test public void setDebitsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsReversalNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setDebitsReversalNo(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getDebitsReversalNo()); }
	 * 
	 *//**
		 * 78.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Number Transfer
		 */
	/*
	 * 
	 * @Test public void setTransferNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTransferNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTransferNo(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTransferNo()); }
	 * 
	 *//**
		 * 79.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
		 */
	/*
	 * 
	 * @Test public void setTransferReversalNoTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTransferReversalNo("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setTransferReversalNo(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getTransferReversalNo()); }
	 * 
	 *//**
		 * 80.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
		 */
	/*
	 * 
	 * @Test public void setNoOfInquiriesTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNoOfInquiries("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setNoOfInquiries(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getNoOfInquiries());
	 * 
	 * }
	 * 
	 *//**
		 * 81.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
		 */
	/*
	 * 
	 * @Test public void setNoOfAuthsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfAuths("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setNoOfAuths(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getNoOfAuths());
	 * 
	 * }
	 * 
	 *//**
		 * 82.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
		 */
	/*
	 * 
	 * @Test public void setCreditsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsProcessingFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCreditsProcessingFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCreditsProcessingFee());
	 * 
	 * }
	 * 
	 *//**
		 * 83.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
		 */
	/*
	 * 
	 * @Test public void setCreditsTxnFeeTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCreditsTxnFee("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCreditsTxnFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCreditsTxnFee()); }
	 * 
	 *//**
		 * 84.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
		 */
	/*
	 * 
	 * @Test public void setDebitsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsProcessingFee("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setDebitsProcessingFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getDebitsProcessingFee()); }
	 * 
	 *//**
		 * 85.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
		 */
	/*
	 * 
	 * @Test public void setDebitsTxnFeeTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setDebitsTxnFee("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setDebitsTxnFee(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getDebitsTxnFee()); }
	 * 
	 *//**
		 * 86.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Amount Credits
		 */
	/*
	 * 
	 * @Test public void setTotalCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalCredits("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setTotalCredits(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getTotalCredits()); }
	 * 
	 *//**
		 * 87.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
		 */
	/*
	 * 
	 * @Test public void setCreditsReversalTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversal("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setCreditsReversal(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getCreditsReversal());
	 * 
	 * }
	 * 
	 *//**
		 * 88.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Amount Debits
		 */
	/*
	 * 
	 * @Test public void setTotalDebitsTest() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTotalDebits("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setTotalDebits(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getTotalDebits()); }
	 * 
	 *//**
		 * 89.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
		 */
	/*
	 * 
	 * @Test public void setDebitsReversalTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setDebitsReversal("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setDebitsReversal(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getDebitsReversal()); }
	 * 
	 *//**
		 * 90.<br>
		 * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
		 */
	/*
	 * 
	 * @Test public void setOriginalDataElements() { // intentionally left blank }
	 * 
	 *//**
		 * 91.<br>
		 * ISO8583-1987, AS2805, Base24, XML - File Update Code
		 */
	/*
	 * 
	 * @Test public void setFileUpdateCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setFileUpdateCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setFileUpdateCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getFileUpdateCode()); }
	 * 
	 *//**
		 * 92.<br>
		 * ISO8583-1987, AS2805, Base24, XML - File Security Code
		 */
	/*
	 * 
	 * @Test public void setFileSecurityCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setFileSecurityCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setFileSecurityCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getFileSecurityCode()); }
	 * 
	 *//**
		 * 93.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Response Indicator
		 */
	/*
	 * 
	 * @Test public void setResIndicatorTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResIndicator("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setResIndicator(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getResIndicator());
	 * 
	 * }
	 * 
	 *//**
		 * 94.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Service Indicator
		 */
	/*
	 * 
	 * @Test public void setServiceIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceIndicator("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setServiceIndicator(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getServiceIndicator());
	 * 
	 * }
	 * 
	 *//**
		 * 95.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
		 */
	/*
	 * 
	 * @Test public void setReplacementAmtsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReplacementAmts("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReplacementAmts(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReplacementAmts()); }
	 * 
	 *//**
		 * 96.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Message Security Code
		 */
	/*
	 * 
	 * @Test public void setMsgSecuirtyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setMsgSecuirtyCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setMsgSecuirtyCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getMsgSecuirtyCode());
	 * 
	 * }
	 * 
	 *//**
		 * 97.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
		 */
	/*
	 * 
	 * @Test public void setNetSettlementTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNetSettlement("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setNetSettlement(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getNetSettlement());
	 * 
	 * }
	 * 
	 *//**
		 * 98.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Payee
		 */
	/*
	 * 
	 * @Test public void setPayeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPayee("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setPayee(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getPayee()); }
	 * 
	 *//**
		 * 99.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
		 * Code
		 */
	/*
	 * 
	 * @Test public void setSettlementIdCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementIdCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setSettlementIdCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getSettlementIdCode()); }
	 * 
	 *//**
		 * 100.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
		 */
	/*
	 * 
	 * @Test public void setReceiverIdCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setReceiverIdCode("12345");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReceiverIdCode(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReceiverIdCode());
	 * 
	 * }
	 * 
	 *//**
		 * 101.ISO8583-1987, AS2805, Base24, XML - File Name
		 */
	/*
	 * 
	 * @Test public void setFileNameTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setFileName("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setFileName(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getFileName());
	 * 
	 * }
	 * 
	 *//**
		 * 102.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
		 */
	/*
	 * 
	 * @Test public void setAccountIdentification1() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId1("2000");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setAccId1(20);
	 * 
	 * assertEquals("2000", posConstruction.getSourceTmm().getAccId1()); }
	 * 
	 *//**
		 * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
		 */
	/*
	 * 
	 * @Test public void setAccountIdentification2() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId2("2000");
	 * posConstruction.setSourceTmm(sourceTmm);
	 * 
	 * posConstruction.setAccId2(20);
	 * 
	 * assertEquals("2000", posConstruction.getSourceTmm().getAccId2()); }
	 * 
	 *//**
		 * 104.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
		 * mPOS - transaction_type
		 */
	/*
	 * 
	 * @Test public void setTxnDesc() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnDesc("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setTxnDesc(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getTxnDesc()); }
	 * 
	 *//**
		 * 105.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setReserved105Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved105("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved105(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved105()); }
	 * 
	 *//**
		 * 106.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setReserved106Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved106("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved106(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved106()); }
	 * 
	 *//**
		 * 107.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setReserved107Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved107("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved107(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved107()); }
	 * 
	 *//**
		 * 108.<br>
		 * ISO8583-1987, XML - Reserved For National Use<br>
		 * AS2805 - Card Status Update Code
		 */
	/*
	 * 
	 * @Test public void setReserved108Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved108("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved108(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved108()); }
	 * 
	 *//**
		 * 109.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setReserved109Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved109("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved109(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved109()); }
	 * 
	 *//**
		 * 110.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setReserved110Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved110("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved110(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved110()); }
	 * 
	 *//**
		 * 111.<br>
		 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
		 */
	/*
	 * 
	 * @Test public void setReserved111Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved111("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved111(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved111()); }
	 * 
	 *//**
		 * 112.<br>
		 * ISO8583-1987, Base24, XML - Reserved For National Use<br>
		 * AS2805 - Key Management data
		 */
	/*
	 * 
	 * @Test public void setReserved112Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved112("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved112(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved112()); }
	 * 
	 *//**
		 * 113.<br>
		 * ISO8583-1987, Base24, XML - Reserved For National Use
		 */
	/*
	 * 
	 * @Test public void setReserved113Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved113("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved113(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved113());
	 * 
	 * }
	 * 
	 *//**
		 * 114.<br>
		 * ISO8583-1987, Base24, XML - Reserved For National Use
		 */
	/*
	 * 
	 * @Test public void setReserved114Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved114("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved114(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved114()); }
	 * 
	 *//**
		 * 115.<br>
		 * ISO8583-1987, Base24, XML - Reserved For National Use
		 */
	/*
	 * 
	 * @Test public void setReserved115Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved115("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved115(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved115()); }
	 * 
	 *//**
		 * 116.<br>
		 * ISO8583-1987, Base24, XML - Reserved For National Use
		 */
	/*
	 * 
	 * @Test public void setReserved116Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved116("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved116(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved116()); }
	 * 
	 *//**
		 * 117. <br>
		 * ISO8583-1987, XML - Reserved For National Use<br>
		 * AS2805 - Card Status Update Code
		 */
	/*
	 * 
	 * @Test public void setReserved117Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved117("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved117(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved117()); }
	 * 
	 *//**
		 * 118.<br>
		 * ISO8583-1987, XML - Reserved For National Use<br>
		 * AS2805 - Cash Total number
		 */
	/*
	 * 
	 * @Test public void setReserved118() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved118("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved118(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved118()); }
	 * 
	 *//**
		 * 119.<br>
		 * ISO8583-1987, XML - Reserved For National Use<br>
		 * AS2805 - Cash Total number
		 */
	/*
	 * 
	 * @Test public void setReserved119Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved119("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved119(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved119());
	 * 
	 * }
	 * 
	 *//**
		 * 120.<br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
		 */
	/*
	 * 
	 * @Test public void setReserved120Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved120("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved120(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved120()); }
	 * 
	 *//**
		 * 121. <br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 - POS Authorization Indicators
		 */
	/*
	 * 
	 * @Test public void setReserved121Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved121("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved121(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved121()); }
	 * 
	 *//**
		 * 122.<br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 -Card Issuer Identification Code
		 */
	/*
	 * 
	 * @Test public void setReserved122Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved122("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved122(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved122()); }
	 * 
	 *//**
		 * 123.<br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
		 * Invoice Data/Settlement Record
		 */
	/*
	 * 
	 * @Test public void setReserved123Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved123("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved123(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved123()); }
	 * 
	 *//**
		 * 124.<br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
		 */
	/*
	 * 
	 * @Test public void setReserved124Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved124("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved124(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved124());
	 * 
	 * }
	 * 
	 *//**
		 * 125.<br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
		 */
	/*
	 * 
	 * @Test public void setReserved125Test() {
	 * 
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setReserved125("12345"); posConstruction.setSourceTmm(sourceTmm);
	 * posConstruction.setReserved125(20); assertEquals("12345",
	 * posConstruction.getSourceTmm().getReserved125()); }
	 * 
	 *//**
		 * 126. <br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
		 */
	/*
	 * 
	 * @Test public void setReserved126() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved126("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved126(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved126()); }
	 * 
	 *//**
		 * 127.<br>
		 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
		 * Base24 - POS User Data
		 */
	/*
	 * 
	 * @Test public void setReserved127() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved127("12345");
	 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved127(20);
	 * assertEquals("12345", posConstruction.getSourceTmm().getReserved127()); }
	 * 
	 *//**
		 * 128.<br>
		 * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
		 * Base24 - Secondary Message Authentication Code
		 *//*
			 * @Test public void setReserved128Test() { TransactionMessageModel sourceTmm =
			 * getSourceTmm(); sourceTmm.setReserved128("12345");
			 * posConstruction.setSourceTmm(sourceTmm); posConstruction.setReserved128(20);
			 * assertEquals("12345", posConstruction.getSourceTmm().getReserved128()); }
			 */

}