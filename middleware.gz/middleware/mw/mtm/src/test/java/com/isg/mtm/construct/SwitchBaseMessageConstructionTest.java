package com.isg.mtm.construct;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.regex.Pattern;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.service.MapsInfoService;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.parser.msg.BaseMessage;

public class SwitchBaseMessageConstructionTest {
	/*
	 * @Mock private MapsInfoService merchantService;
	 *
	 * @Mock protected HsmProcessorService hsmService;
	 *
	 * @Mock private CacheServices cacheServices;
	 *
	 * @Mock protected BaseMessage baseMessage;
	 *
	 * @Mock private PosSwitchBaseMessageConstruction base;
	 *
	 * @InjectMocks private Base baseConstruction;
	 *
	 * @Before public void init() { MockitoAnnotations.initMocks(this); }
	 *
	 * public TransactionMessageModel getSourceTmm() { TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setTransmissionTime("100"); return sourceTmm; }
	 *
	 * public MapsInfoModel getMapsInfoModel() { MapsInfoModel maps = new
	 * MapsInfoModel(); maps.setEntityId("2000"); maps.setMerchantType("kotak");
	 * maps.setAcquirerInstitutionId("123"); maps.setAcquirerCurrencyCode("8000");
	 * maps.setForwardingInstitutionId("4000"); return maps; }
	 *
	 * // MTI // @Test // public void setMtiTest() throws ISOException { // // input
	 * // Mockito.when(merchantService.getMapsInfoByEntityIdMidTid(Mockito.any(),
	 * Mockito.any(), Mockito.any())) // .thenReturn(getMapsInfoModel()); // //
	 * TransactionMessageModel sourceTmm = getSourceTmm(); //
	 * sourceTmm.setTrack1Data("2000"); // baseConstruction.setSourceTmm(sourceTmm);
	 * // // baseConstruction.setMsgTypeData("200"); // //
	 * baseConstruction.setMti(); // assertEquals("200",
	 * baseConstruction.baseMessage.getMTI()); // }
	 *
	 * // @Test // public void testMtiException() throws ISOException { // //
	 * baseConstruction.setMsgTypeData(""); // // baseConstruction.setMti(); // }
	 *
	 * DE 1
	 *
	 * @Test public void setBitMapTest() {
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setBitMap("20002000"); baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * assertEquals("20002000", baseConstruction.getSourceTmm().getBitMap()); }
	 *
	 * DE 2
	 *
	 * @Test public void setPanTest() {
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())) .thenReturn("0005391699020177742D22022261000067799999");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPan("ABCD1234"); sourceTmm.setTrack1Data("1234");
	 * sourceTmm.setTrack2Data(null); sourceTmm.setEntityId("500");
	 * sourceTmm.setSecurityControlInfo("xyz");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPan(20);
	 *
	 * assertEquals("0005391699020177742",
	 * baseConstruction.getTargetTmm().getPan()); }
	 *
	 * @Test public void setPanTestException() { String errMsg =
	 * "Error while constructing data element: 20, name: PAN"; String message =
	 * null;
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("000");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setPan("ABCD1234"); sourceTmm.setTrack1Data("1234");
	 * sourceTmm.setTrack2Data("308"); sourceTmm.setEntityId("500");
	 * sourceTmm.setSecurityControlInfo("xyz");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * try { baseConstruction.setPan(20); } catch (Exception e) { message =
	 * e.getMessage(); } assertEquals(errMsg, message); }
	 *
	 * DE 3
	 *
	 * @Test public void SetProcessingCodeTest() { // input
	 * baseConstruction.setTargetMsgTypeId("200");
	 *
	 * baseConstruction.setProcessingCode(22); assertEquals("200",
	 * baseConstruction.getTargetTmm().getProcessingCode()); }
	 *
	 * DE 4
	 *
	 * @Test public void testSetTxnAmtTest() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTxnAmt("1000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTxnAmt(20);
	 *
	 * assertEquals("1000", baseConstruction.getTargetTmm().getTxnAmt()); }
	 *
	 * DE 5
	 *
	 * @Test public void setSettlementAmtTest() { // input TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setSettlementAmt("2000"); baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementAmt(20);
	 *
	 * assertEquals("2000", baseConstruction.getSourceTmm().getSettlementAmt()); }
	 *
	 * DE 6
	 *
	 * @Test public void setCardHolderBillingAmtTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardHolderBillingAmt("3000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardHolderBillingAmt(20);
	 *
	 * assertEquals("3000",
	 * baseConstruction.getSourceTmm().getCardHolderBillingAmt()); }
	 *
	 * DE 8
	 *
	 * @Test public void setCardHolderBillingTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardHolderBillingFee("4000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardHolderBillingFee(20);
	 *
	 * assertEquals("4000",
	 * baseConstruction.getSourceTmm().getCardHolderBillingFee()); }
	 *
	 * DE 9
	 *
	 * @Test public void setSettlementConversionRateTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setSettlementConversionRate("500");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementConversionRate(20);
	 *
	 * assertEquals("500",
	 * baseConstruction.getSourceTmm().getSettlementConversionRate()); }
	 *
	 * DE 10
	 *
	 * @Test public void setCardHolderBillingConversionRateTest() { // input
	 * TransactionMessageModel sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setCardHolderBillingConversionRate("600");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardHolderBillingConversionRate(20);
	 *
	 * assertEquals("600",
	 * baseConstruction.getSourceTmm().getCardHolderBillingConversionRate()); }
	 *
	 * DE 11
	 *
	 * @Test public void setStanTest() { baseConstruction.setStan(20);
	 *
	 * assertEquals(6, baseConstruction.getTargetTmm().getStan().length()); }
	 *
	 * DE 12
	 *
	 * @Test public void setLocalTxnTimeTest() { // input String regex =
	 * "^(?:[01]\\d|2[0-3])(?:[0-5]\\d)(?:[0-5]\\d)$";
	 * baseConstruction.setLocalTxnTime(20);
	 *
	 * assertTrue("Not in expected pattern hhmmss", Pattern.matches(regex,
	 * baseConstruction.getTargetTmm().getLocalTxnTime())); }
	 *
	 * DE 13
	 *
	 * @Test public void setLocalTxnDateTest() { // input String regex =
	 * "^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
	 * baseConstruction.setLocalTxnDate(20);
	 *
	 * assertTrue("Not in expected pattern MMdd", Pattern.matches(regex,
	 * baseConstruction.getTargetTmm().getLocalTxnDate())); }
	 *
	 * DE 14
	 *
	 * @Test public void setExpirationDateTest() { // input TransactionMessageModel
	 * sourceTmm = new TransactionMessageModel();
	 * sourceTmm.setExpirationDate("05052020");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setExpirationDate(20);
	 *
	 * assertEquals("05052020",
	 * baseConstruction.getTargetTmm().getExpirationDate()); }
	 *
	 * @Test public void setExpirationDateTestNull() { // input setPanTest();
	 *
	 * baseConstruction.setExpirationDate(20);
	 *
	 * assertEquals("2202", baseConstruction.getTargetTmm().getExpirationDate()); }
	 *
	 * DE 15
	 *
	 * @Test public void setSettlementDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementDate("1234");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementDate(20);
	 *
	 * assertEquals("1234", baseConstruction.getSourceTmm().getSettlementDate()); }
	 *
	 * DE 16
	 *
	 * @Test public void setConversionDateTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setConversionDate("1234");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setConversionDate(20);
	 *
	 * assertEquals("1234", baseConstruction.getSourceTmm().getConversionDate()); }
	 *
	 * DE 17
	 *
	 * @Test public void setCaptureDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setCaptureDate("1234");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCaptureDate(20);
	 *
	 * assertEquals("1234", baseConstruction.getSourceTmm().getCaptureDate()); }
	 *
	 * DE 18
	 *
	 * @Test public void setMerchantTypeTest() { // input
	 * baseConstruction.setTargetMsgType("0200");
	 * baseConstruction.setTargetMsgTypeId("010000");
	 *
	 * baseConstruction.setMerchantType(20);
	 *
	 * assertEquals("6010", baseConstruction.getTargetTmm().getMerchantType()); }
	 *
	 * @Test public void setMerchantTypeTestElse() { // input
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setMerchantType("visa"); baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTargetMsgType("0150");
	 * baseConstruction.setTargetMsgTypeId("010010");
	 *
	 * baseConstruction.setMerchantType(20);
	 *
	 * assertEquals("kotak", baseConstruction.getTargetTmm().getMerchantType());
	 *
	 * }
	 *
	 * DE 19
	 *
	 * @Test public void setAquirerCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAquirerCountryCode("50000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAquirerCountryCode(20); assertEquals("50000",
	 * baseConstruction.getSourceTmm().getAquirerCountryCode()); }
	 *
	 * DE 20
	 *
	 * @Test public void setPanExtendedCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanExtendedCountryCode("50000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPanExtendedCountryCode(20); assertEquals("50000",
	 * baseConstruction.getSourceTmm().getPanExtendedCountryCode()); }
	 *
	 * DE 21
	 *
	 * @Test public void setPanForwardingCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPanForwardingCountryCode("50000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPanForwardingCountryCode(20); assertEquals("50000",
	 * baseConstruction.getSourceTmm().getPanForwardingCountryCode()); }
	 *
	 * DE 22
	 *
	 * @Test public void setPosEntryModeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPosEntryMode("50000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPosEntryMode(20); assertEquals("50000",
	 * baseConstruction.getSourceTmm().getPosEntryMode()); }
	 *
	 * DE 23
	 *
	 * @Test public void setCardSeqNoTest() { // input
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm(); sourceTmm.setIccData(
	 * "9F02060000000030009F03060000000000008407A000000003101082023C009F360201F79F0702FF009F26080F380F214766ADF89F2701809F34034203009F1E0830313031353734349F100706010A03A0A8049F0902008C9F3303E0F0C89F1A0203569F350122950508800400005F2A0203565F3401019A031912109C01009F3704B1F0394E9F4104000000319F530152"
	 * ); baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTargetMsgType("0280");
	 * baseConstruction.setTargetMsgTypeId("510090");
	 *
	 * baseConstruction.setCardSeqNo(20); assertEquals("001",
	 * baseConstruction.getTargetTmm().getCardSeqNo()); }
	 *
	 * DE 24
	 *
	 * @Test public void setNetworkInternationalIdTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNiiId("12");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNiiId(20);
	 *
	 * assertEquals("12", baseConstruction.getSourceTmm().getNiiId());
	 *
	 * }
	 *
	 * DE 25
	 *
	 * @Test public void setPosConditionCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setPosConditionCode("12");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNiiId(20);
	 *
	 * assertEquals("12", baseConstruction.getSourceTmm().getPosConditionCode());
	 *
	 * }
	 *
	 * DE 26
	 *
	 * @Test public void setPosCaptureCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setPosCaptureCode("100");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPosCaptureCode(20); assertEquals("100",
	 * baseConstruction.getSourceTmm().getPosCaptureCode()); }
	 *
	 * DE 27
	 *
	 * @Test public void setAuthIdResLengthTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAuthIdResLength("100");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAuthIdResLength(20); assertEquals("100",
	 * baseConstruction.getSourceTmm().getAuthIdResLength()); }
	 *
	 * DE 28
	 *
	 * @Test public void setTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnFee("100");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTxnFee(20); assertEquals("100",
	 * baseConstruction.getSourceTmm().getTxnFee()); }
	 *
	 * DE 29
	 *
	 * @Test public void setSettlementFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementFee("100");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementFee(20); assertEquals("100",
	 * baseConstruction.getSourceTmm().getSettlementFee()); }
	 *
	 * DE 30
	 *
	 * @Test public void setTxnProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTxnProcessingFee("100");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTxnProcessingFee(20); assertEquals("100",
	 * baseConstruction.getSourceTmm().getTxnProcessingFee()); }
	 *
	 * DE 31
	 *
	 * @Test public void setSettlementProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementProcessingFee("100");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementProcessingFee(20); assertEquals("100",
	 * baseConstruction.getSourceTmm().getSettlementProcessingFee()); }
	 *
	 * DE 32
	 *
	 * @Test public void setAquirerIdCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setAquirerIdCode("5000"); baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAquirerIdCode(20);
	 *
	 * assertEquals("123", baseConstruction.getTargetTmm().getAquirerIdCode()); }
	 *
	 * DE 33
	 *
	 * @Test public void setForwardingInstIdCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setForwardingInstIdCode("5000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setForwardingInstIdCode(20);
	 *
	 * assertEquals("4000",
	 * baseConstruction.getTargetTmm().getForwardingInstIdCode()); }
	 *
	 * DE 34
	 *
	 * @Test public void setPanExtendedTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPanExtended("10");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPanExtended(20); assertEquals("10",
	 * baseConstruction.getSourceTmm().getPanExtended()); }
	 *
	 * DE 35
	 *
	 * @Test public void setTrack2DataTest() { // input
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("1234");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTrack2Data("600"); baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTrack2Data(20);
	 *
	 * assertEquals("1234", baseConstruction.getTargetTmm().getTrack2Data()); }
	 *
	 * DE 36
	 *
	 * @Test public void setTrack3DataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack3Data("10");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTrack3Data(20); assertEquals("10",
	 * baseConstruction.getSourceTmm().getTrack3Data()); }
	 *
	 * DE 37
	 *
	 * @Test public void setRetrievalRefNoTest() { baseConstruction.setStan(30);
	 * baseConstruction.setRetrievalRefNo(20);
	 *
	 * assertEquals(12,
	 * baseConstruction.getTargetTmm().getRetrievalRefNo().length()); }
	 *
	 * DE 38
	 *
	 * @Test public void setAuthIdResTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setAuthIdRes("10");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAuthIdRes(20); assertEquals("10",
	 * baseConstruction.getSourceTmm().getAuthIdRes()); }
	 *
	 * DE 39
	 *
	 * @Test public void setResCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResCode("10");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setResCode(20); assertEquals("10",
	 * baseConstruction.getSourceTmm().getResCode()); }
	 *
	 * DE 40
	 *
	 * @Test public void setServiceRestrictionCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceRestrictionCode("10");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setServiceRestrictionCode(20); assertEquals("10",
	 * baseConstruction.getSourceTmm().getServiceRestrictionCode()); }
	 *
	 * DE 41
	 *
	 * @Test public void setCardAcceptorTerminalIdTest() { // input
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardAcceptorTerminalId("1432");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardAcceptorTerminalId(20);
	 *
	 * assertEquals("1432",
	 * baseConstruction.getTargetTmm().getCardAcceptorTerminalId()); }
	 *
	 * DE 42
	 *
	 * @Test public void setCardAcceptorIdTest() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCardAcceptorId("14");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardAcceptorId(20);
	 *
	 * assertEquals("14", baseConstruction.getTargetTmm().getCardAcceptorId()); }
	 *
	 * DE 43
	 *
	 * @Test public void setCardAcceptorInfoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCardAcceptorInfo("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardAcceptorInfo(20);
	 *
	 * assertEquals("2000", baseConstruction.getSourceTmm().getCardAcceptorInfo());
	 * }
	 *
	 * DE 44
	 *
	 * @Test public void setAdditionalResDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalResData("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAdditionalResData(20);
	 *
	 * assertEquals("2000", baseConstruction.getSourceTmm().getAdditionalResData());
	 * }
	 *
	 * DE 45
	 *
	 * @Test public void setTrack1DataTest() {
	 *
	 * Mockito.when(hsmService.decrypt(Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())) .thenReturn("12345"); TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTrack1Data("645");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTrack1Data(20);
	 *
	 * assertEquals("12345", baseConstruction.getTargetTmm().getTrack1Data()); }
	 *
	 * DE 46
	 *
	 * @Test public void setIsoAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setIsoAd("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setIsoAd(20);
	 *
	 * assertEquals("2000", baseConstruction.getSourceTmm().getIsoAd()); }
	 *
	 * DE 47
	 *
	 * @Test public void setNationalAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNationalAd("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNationalAd(20);
	 *
	 * assertEquals("2000", baseConstruction.getSourceTmm().getNationalAd()); }
	 *
	 * DE 48
	 *
	 * @Test public void setPrivateAdTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPrivateAd("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPrivateAd(20);
	 *
	 * assertEquals("2000", baseConstruction.getSourceTmm().getPrivateAd()); }
	 *
	 * DE 49
	 *
	 * @Test public void setTxnCurrencyCodeTest() {
	 *
	 * Mockito.when(merchantService.getMapsInfoById(Mockito.any())).thenReturn(
	 * getMapsInfoModel());
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnCurrencyCode("645");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTxnCurrencyCode(20);
	 *
	 * assertEquals("8000", baseConstruction.getTargetTmm().getTxnCurrencyCode()); }
	 *
	 * DE 50
	 *
	 * @Test public void setSettlementCurrenyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCurrenyCode("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementCurrenyCode(20);
	 *
	 * assertEquals("2000",
	 * baseConstruction.getSourceTmm().getSettlementCurrenyCode()); }
	 *
	 * DE 51
	 *
	 * @Test public void setCardHolderBillingCurrencyCodeTest() {
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setCardHolderBillingCurrencyCode("2000");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCardHolderBillingCurrencyCode(20);
	 *
	 * assertEquals("2000",
	 * baseConstruction.getSourceTmm().getCardHolderBillingCurrencyCode()); }
	 *
	 * DE 52
	 *
	 * @Test public void setPinTest() {
	 *
	 * Mockito.when(hsmService.pinTranslation(Mockito.any(), Mockito.any(),
	 * Mockito.any(), Mockito.any(), Mockito.any(),
	 * Mockito.any())).thenReturn("280595");
	 *
	 * TransactionMessageModel sourceTmm = getSourceTmm();
	 * sourceTmm.setTxnCurrencyCode("645");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * setPanTest();
	 *
	 * baseConstruction.setPin(20);
	 *
	 * assertEquals("280595", baseConstruction.getTargetTmm().getPin()); }
	 *
	 * DE 53
	 *
	 * @Test public void setSecurityControlInfoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSecurityControlInfo("2001");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSecurityControlInfo(53); assertEquals("2001",
	 * baseConstruction.getSourceTmm().getSecurityControlInfo()); }
	 *
	 * DE 54
	 *
	 * @Test public void setAdditionalAmountsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAdditionalAmounts("2001");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAdditionalAmounts(53); assertEquals("2001",
	 * baseConstruction.getSourceTmm().getAdditionalAmounts()); }
	 *
	 * DE 55
	 *
	 * @Test public void setIccDataTest() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setIccData("123");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setIccData(20);
	 *
	 * assertEquals("123", baseConstruction.getTargetTmm().getIccData()); }
	 *
	 * DE 56
	 *
	 * @Test public void setReserved56Test() { // input TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReserved56("123");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved56(20);
	 *
	 * assertEquals("123", baseConstruction.getSourceTmm().getReserved56());
	 *
	 * }
	 *
	 * DE 57
	 *
	 * @Test public void setReserverd57Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved57("123");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved57(20);
	 *
	 * assertEquals("123", baseConstruction.getSourceTmm().getReserved57()); }
	 *
	 * DE 58
	 *
	 * @Test public void setReserved58Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved58("123");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved58(20);
	 *
	 * assertEquals("123", baseConstruction.getSourceTmm().getReserved58()); }
	 *
	 * DE 59
	 *
	 * @Test public void setReserverd59Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved59("123");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved59(20);
	 *
	 * assertEquals("123", baseConstruction.getSourceTmm().getReserved59()); }
	 *
	 * DE 60
	 *
	 * @Test public void setTerminalDataTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTerminalData("123");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTerminalData(20);
	 *
	 * assertEquals("123", baseConstruction.getSourceTmm().getTerminalData()); }
	 *
	 * DE 61
	 *
	 * @Test public void setCiadTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setCiad("600");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCiad(20);
	 *
	 * assertEquals("600", baseConstruction.getSourceTmm().getCiad());
	 *
	 * }
	 *
	 * DE 62
	 *
	 * @Test public void setPostalCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPostalCode("600");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPostalCode(20);
	 *
	 * assertEquals("600", baseConstruction.getSourceTmm().getPostalCode());
	 *
	 * }
	 *
	 * DE 63
	 *
	 * @Test public void setAtmPinOffsetDataTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAtmPinOffsetData("600");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAtmPinOffsetData(20);
	 *
	 * assertEquals("600", baseConstruction.getSourceTmm().getAtmPinOffsetData());
	 *
	 * }
	 *
	 * DE 64
	 *
	 * @Test public void setMsgAuthCodeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgAuthCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setMsgAuthCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getMsgAuthCode()); }
	 *
	 * DE 65
	 *
	 * @Test public void setExtendedBitmapIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedBitmapIndicator("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setExtendedBitmapIndicator(20);
	 *
	 * assertEquals("50",
	 * baseConstruction.getSourceTmm().getExtendedBitmapIndicator()); }
	 *
	 * DE 66
	 *
	 * @Test public void setSettlementCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setSettlementCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getSettlementCode()); }
	 *
	 * DE 67
	 *
	 * @Test public void setExtendedPaymentCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setExtendedPaymentCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setExtendedPaymentCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getExtendedPaymentCode());
	 * }
	 *
	 * DE 68
	 *
	 * @Test public void setReceiverCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReceiverCountryCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReceiverCountryCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReceiverCountryCode());
	 * }
	 *
	 * DE 69
	 *
	 * @Test public void setSettlementCountryCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementCountryCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementCountryCode(20);
	 *
	 * assertEquals("50",
	 * baseConstruction.getSourceTmm().getSettlementCountryCode()); }
	 *
	 * DE 70
	 *
	 * @Test public void setNetworkMgmtInfoCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setNetworkMgmtInfoCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNetworkMgmtInfoCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getNetworkMgmtInfoCode());
	 * }
	 *
	 * DE 71
	 *
	 * @Test public void setMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setMsgNo("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setMsgNo(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getMsgNo()); }
	 *
	 * DE 72
	 *
	 * @Test public void setLastMsgNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setLastMsgNo("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setLastMsgNo(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getLastMsgNo()); }
	 *
	 * DE 73
	 *
	 * @Test public void setActionDateTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setActionDate("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setActionDate(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getActionDate()); }
	 *
	 * DE 74
	 *
	 * @Test public void setNoOfCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfCredits("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNoOfCredits(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getNoOfCredits()); }
	 *
	 * DE 75
	 *
	 * @Test public void setCreditsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversalNo("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCreditsReversalNo(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getCreditsReversalNo()); }
	 *
	 * DE 76
	 *
	 * @Test public void setNoOfDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfDebits("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNoOfDebits(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getNoOfDebits()); }
	 *
	 * DE 77
	 *
	 * @Test public void setDebitsReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsReversalNo("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setDebitsReversalNo(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getDebitsReversalNo()); }
	 *
	 * DE 78
	 *
	 * @Test public void setTransferNoTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTransferNo("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTransferNo(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getTransferNo()); }
	 *
	 * DE 79
	 *
	 * @Test public void setTransferReversalNoTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setTransferReversalNo("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getTransferReversalNo());
	 * }
	 *
	 * DE 80
	 *
	 * @Test public void setNoOfInquiriesTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNoOfInquiries("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNoOfInquiries(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getNoOfInquiries()); }
	 *
	 * DE 81
	 *
	 * @Test public void setNoOfAuthsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setNoOfAuths("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNoOfAuths(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getNoOfAuths()); }
	 *
	 * DE 82
	 *
	 * @Test public void setCreditsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsProcessingFee("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCreditsProcessingFee(20);
	 *
	 * assertEquals("50",
	 * baseConstruction.getSourceTmm().getCreditsProcessingFee()); }
	 *
	 * DE 83
	 *
	 * @Test public void setCreditsTxnFeeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setCreditsTxnFee("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCreditsTxnFee(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getCreditsTxnFee()); }
	 *
	 * DE 84
	 *
	 * @Test public void setDebitsProcessingFeeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setDebitsProcessingFee("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setDebitsProcessingFee(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getDebitsProcessingFee());
	 * }
	 *
	 * DE 85
	 *
	 * @Test public void setDebitsTxnFeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setDebitsTxnFee("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setDebitsTxnFee(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getDebitsTxnFee()); }
	 *
	 * DE 86
	 *
	 * @Test public void setTotalCreditsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalCredits("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTotalCredits(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getTotalCredits()); }
	 *
	 * DE 87
	 *
	 * @Test public void setCreditsReversalTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setCreditsReversal("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setCreditsReversal(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getCreditsReversal()); }
	 *
	 * DE 88
	 *
	 * @Test public void setTotalDebitsTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTotalDebits("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTotalDebits(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getTotalDebits()); }
	 *
	 * DE 89
	 *
	 * @Test public void setDebitsReversalTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setDebitsReversal("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setDebitsReversal(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getDebitsReversal()); }
	 *
	 * DE 90
	 *
	 * @Test public void setOriginalDataElementsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setOriginalDataElements("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setOriginalDataElements(20);
	 *
	 * assertEquals("50",
	 * baseConstruction.getSourceTmm().getOriginalDataElements()); }
	 *
	 * DE 91
	 *
	 * @Test public void setFileUpdateCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setFileUpdateCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setFileUpdateCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getFileUpdateCode()); }
	 *
	 * DE 92
	 *
	 * @Test public void setFileSecurityCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setFileSecurityCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setFileSecurityCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getFileSecurityCode()); }
	 *
	 * DE 93
	 *
	 * @Test public void setResIndicatorTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setResIndicator("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setResIndicator(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getResIndicator()); }
	 *
	 * DE 94
	 *
	 * @Test public void setServiceIndicatorTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setServiceIndicator("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setServiceIndicator(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getServiceIndicator()); }
	 *
	 * DE 95
	 *
	 * @Test public void setReplacementAmtsTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setReplacementAmts("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReplacementAmts(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReplacementAmts()); }
	 *
	 * DE 96
	 *
	 * @Test public void setMsgSecuirtyCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setMsgSecuirtyCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setMsgSecuirtyCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getMsgSecuirtyCode()); }
	 *
	 * DE 97
	 *
	 * @Test public void setNetSettlementTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setNetSettlement("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setNetSettlement(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getNetSettlement()); }
	 *
	 * DE 98
	 *
	 * @Test public void setPayeeTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setPayee("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setPayee(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getPayee()); }
	 *
	 * DE 99
	 *
	 * @Test public void setSettlementIdCodeTest() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setSettlementIdCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setSettlementIdCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getSettlementIdCode()); }
	 *
	 * DE 100
	 *
	 * @Test public void setReceiverIdCodeTest() { TransactionMessageModel sourceTmm
	 * = getSourceTmm(); sourceTmm.setReceiverIdCode("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReceiverIdCode(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReceiverIdCode()); }
	 *
	 * DE 101
	 *
	 * @Test public void setFileNameTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setFileName("xyz");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setFileName(20);
	 *
	 * assertEquals("xyz", baseConstruction.getSourceTmm().getFileName()); }
	 *
	 * DE 102
	 *
	 * @Test public void setAccountIdentification1Test() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId1("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAccId1(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getAccId1()); }
	 *
	 * DE 103
	 *
	 * @Test public void setAccountIdentification2() { TransactionMessageModel
	 * sourceTmm = getSourceTmm(); sourceTmm.setAccId2("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setAccId2(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getAccId2()); }
	 *
	 * DE 104
	 *
	 * @Test public void setTxnDescTest() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setTxnDesc("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setTxnDesc(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getTxnDesc()); }
	 *
	 * DE 105
	 *
	 * @Test public void setReserved105Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved105("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved105(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved105()); }
	 *
	 * DE 106
	 *
	 * @Test public void setReserved106Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved106("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved106(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved106()); }
	 *
	 * DE 107
	 *
	 * @Test public void setReserved107Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved107("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved107(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved107()); }
	 *
	 * DE 108
	 *
	 * @Test public void setReserved108Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved108("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved108(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved108()); }
	 *
	 * DE 109
	 *
	 * @Test public void setReserved109Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved109("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved109(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved109()); }
	 *
	 * DE 110
	 *
	 * @Test public void setReserved110Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved110("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved110(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved110()); }
	 *
	 * DE 111
	 *
	 * @Test public void setReserved111Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved111("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved111(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved111()); }
	 *
	 * DE 112
	 *
	 * @Test public void setReserved112Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved112("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved112(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved112()); }
	 *
	 * DE 113
	 *
	 * @Test public void setReserved113Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved113("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved113(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved113()); }
	 *
	 * DE 114
	 *
	 * @Test public void setReserved114Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved114("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved114(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved114()); }
	 *
	 * DE 115
	 *
	 * @Test public void setReserved115Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved115("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved115(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved115()); }
	 *
	 * DE 116
	 *
	 * @Test public void setReserved116Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved116("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved116(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved116()); }
	 *
	 * DE 117
	 *
	 * @Test public void setReserved117Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved117("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved117(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved117()); }
	 *
	 * DE 118
	 *
	 * @Test public void setReserved118Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved118("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved118(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved118()); }
	 *
	 * DE 119
	 *
	 * @Test public void setReserved119Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved119("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved119(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved119()); }
	 *
	 * DE 120
	 *
	 * @Test public void setReserved120Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved120("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved120(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved120()); }
	 *
	 * DE 121
	 *
	 * @Test public void setReserved121Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved121("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved121(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved121()); }
	 *
	 * DE 122
	 *
	 * @Test public void setReserved122Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved122("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved122(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved122()); }
	 *
	 * DE 123
	 *
	 * @Test public void setReserved123Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved123("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved123(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved123()); }
	 *
	 * DE 124
	 *
	 * @Test public void setReserved124Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved124("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved124(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved124()); }
	 *
	 * DE 125
	 *
	 * @Test public void setReserved125Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved125("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved125(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved125()); }
	 *
	 * DE 126
	 *
	 * @Test public void setReserved126Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved126("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved126(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved126()); }
	 *
	 * DE 127
	 *
	 * @Test public void setReserved127Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved127("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved127(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved127()); }
	 *
	 * DE 128
	 *
	 * @Test public void setReserved128Test() { TransactionMessageModel sourceTmm =
	 * getSourceTmm(); sourceTmm.setReserved128("50");
	 * baseConstruction.setSourceTmm(sourceTmm);
	 *
	 * baseConstruction.setReserved128(20);
	 *
	 * assertEquals("50", baseConstruction.getSourceTmm().getReserved128()); }
	 *
	 * }
	 *
	 * class Base extends PosSwitchBaseMessageConstruction {
	 *
	 * @Override public void setTransmissionTime(int fieldNo) { // TODO
	 * Auto-generated method stub
	 *
	 * }
	 *
	 * @Override public void setIccData(int fieldNo) {
	 *
	 * }
	 */
}
