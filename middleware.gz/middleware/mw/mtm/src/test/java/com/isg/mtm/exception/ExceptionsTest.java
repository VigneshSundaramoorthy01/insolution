package com.isg.mtm.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.isg.mw.mtm.exception.MTMInitializationException;
import com.isg.mw.mtm.exception.MessageParsingException;
import com.isg.mw.mtm.parser.exception.ISO8583ParsingException;
import com.isg.mw.mtm.parser.exception.JSONParsingException;

public class ExceptionsTest {

	@Test
	public void parsingExceptionTest() {
		String expected = "error";
		ISO8583ParsingException beanException = new ISO8583ParsingException(expected);
		assertEquals(expected, beanException.getMessage());
	}

	@Test
	public void parsingExceptionTest2() {
		String expected = "error";
		ISO8583ParsingException exception = new ISO8583ParsingException(expected);
		Throwable e = new Throwable("error");
		ISO8583ParsingException except = new ISO8583ParsingException(expected, e);
		String message = except.getMessage();
		assertEquals(expected, exception.getMessage());
		assertEquals(message, except.getMessage());
	}

	@Test
	public void JSONParsingExceptionTest() {
		String expected = "error";
		JSONParsingException beanException = new JSONParsingException(expected);
		assertEquals(expected, beanException.getMessage());
	}

	@Test
	public void JSONParsingExceptionTest2() {
		String expected = "error";
		JSONParsingException exception = new JSONParsingException(expected);
		Throwable e = new Throwable("error");
		JSONParsingException except = new JSONParsingException(expected, e);
		String message = except.getMessage();
		assertEquals(expected, exception.getMessage());
		assertEquals(message, except.getMessage());

	}
	
	@Test
	public void MessageParsingExceptionTest() {
		String expected = "error";
		MessageParsingException beanException = new MessageParsingException(expected);
		assertEquals(expected, beanException.getMessage());
	}

	@Test
	public void MessageParsingExceptionTest2() {
		String expected = "error";
		MessageParsingException exception = new MessageParsingException(expected);
		Throwable e = new Throwable("error");
		MessageParsingException except = new MessageParsingException(expected, e);
		String message = except.getMessage();
		assertEquals(expected, exception.getMessage());
		assertEquals(message, except.getMessage());

	}
	
	@Test
	public void MTMInitalizationExceptionTest() {
		String expected = "error";
		MTMInitializationException beanException = new MTMInitializationException(expected);
		assertEquals(expected, beanException.getMessage());
	}

	@Test
	public void MTMInitalizationExceptionTest2() {
		String expected = "error";
		MTMInitializationException exception = new MTMInitializationException(expected);
		Throwable e = new Throwable("error");
		MTMInitializationException except = new MTMInitializationException(expected, e);
		String message = except.getMessage();
		assertEquals(expected, exception.getMessage());
		assertEquals(message, except.getMessage());
	}
}