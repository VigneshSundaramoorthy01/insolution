package com.isg.mw.mtm.exception;

public class UndefinedBusinessRuleClassMethodException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    
    public UndefinedBusinessRuleClassMethodException(String expMsg) {
        super("Undefined implementation for data element no: " + expMsg);
    }

    public UndefinedBusinessRuleClassMethodException(int expMsg) {
        super("Undefined implementation for data element no: " + expMsg);
    }

    public UndefinedBusinessRuleClassMethodException(String expMsg, Throwable e) {
        super(expMsg, e);
    }
}