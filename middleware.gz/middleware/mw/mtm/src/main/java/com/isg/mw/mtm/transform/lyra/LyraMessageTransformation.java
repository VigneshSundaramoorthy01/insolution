package com.isg.mw.mtm.transform.lyra;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.model.bi.BinInfoModel;
import com.isg.mw.core.model.common.MerchOrdTxnData;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.LyraMsgType;
import com.isg.mw.core.model.lyra.LyraMerchantRequestModel;
import com.isg.mw.core.model.lyra.LyraWibmoMerchantRequestModel;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.Target;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.FormData;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.*;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.lyra.LyraMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.BankServerException;
import com.isg.mw.mtm.exception.DataAuthenticationException;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.IMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.ApiUtil;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.SignatureException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.isg.mw.core.utils.IsgJsonUtils.removeQuotesAndUnescape;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;

public class
LyraMessageTransformation extends BaseMessageTransformation implements IMessageTransformation {

    private Logger logger = LogManager.getLogger(LyraMessageTransformation.class);
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {
        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }
        /**
         -  * Lyra Submit card details Request and Response
         -   */

        getSubmitCardDetailsRequest(tmmConfig);

        getRefundCardRequest(tmmConfig);

        return tmmConfig;
    }

    private void getSubmitCardDetailsRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("Pay", "3", TmmConstants.LYRA_SUBMIT_CARD_REQUEST), fieldsMap);
    }

    private void getRefundCardRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("Refund", "3", TmmConstants.LYRA_REFUND_CARD_REQUEST), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig("Reversal", null, TmmConstants.LYRA_REVERSAL_CARD_REQUEST), fieldsMap);
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel reqSourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {

        MessageContext msgContext = new MessageContext(reqSourceTmm.getEntityId(), epId, txnTypeConfig.getEpMsgType());
        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
        MessageFormatConfigModel msgFormatModel = msgFormatMap.get(txnTypeConfig.getEpMsgType());
        TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
        //once "get" tokens are replaced, we have to set specific construction based tokens
        SwitchBaseMessageConstruction baseMsgConstruction = getMessageConstruction();
        baseMsgConstruction.setSourceTmm(reqSourceTmm);

        TransactionMessageModel reqTargetTmm = SerializationUtils.clone(reqSourceTmm);
        reqTargetTmm.setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(epId));
        reqTargetTmm.setMsgType(txnTypeConfig.getEpMsgType());
        if (!StringUtils.isBlank(reqSourceTmm.getSmartRouteData().getEncryptionEnable()) && reqSourceTmm.getSmartRouteData().getEncryptionEnable().equalsIgnoreCase("Y")) {
            reqTargetTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getLyra().getEncReturnUrl());
        } else {
            reqTargetTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getLyra().getReturnUrl());
        }
        HttpHeaders headers = buildHeader(targetAdditionalData, reqTargetTmm);

        String chargeUuid;

        String iv;
        if (!reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REFUND_TXN)
                && !reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN)) {
            CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
            MerchOrdTxnData merOrdTxnData = cacheUtil.getTxnData(reqTargetTmm.getEntityId(), reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getMerchantTxnRefNo());
            MerchOrdTxnData.TxnData txnData = merOrdTxnData.getTxnDataMapModel().get(reqTargetTmm.getTransactionId());
            chargeUuid = createCharge(reqTargetTmm, targetAdditionalData, headers);
            txnData.setUuid(chargeUuid);
            cacheUtil.putTxnData(reqTargetTmm.getEntityId(), reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getMerchantTxnRefNo(),merOrdTxnData);
            reqTargetTmm.getSmartRouteData().getLyraData().setUuid(chargeUuid);
        }
        baseMsgConstruction.setTargetTmm(reqTargetTmm);
        baseMsgConstruction.setSourceMsgType(reqSourceTmm.getMsgType());
        baseMsgConstruction.setSourceMsgTypeId(reqSourceTmm.getProcessingCode());
        baseMsgConstruction.setTargetMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetMsgTypeId(txnTypeConfig.getProcessingCode());

        baseMsgConstruction.updateDrCrFlag();

        String msgFormat = msgFormatModel.getMsgFormat();

        TransactionMessageModel.LyraData reqTxnModel = IsgJsonUtils.getObjectFromJsonString(msgFormat, TransactionMessageModel.LyraData.class);
        ApiUtil.replaceTokens(reqTxnModel, reqSourceTmm, baseMsgConstruction);

        //tokenization Request
        String tokenCryptogram = null;
        boolean tokenizationApplicable = false;
        if (!(reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REFUND_TXN) ||
                reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN))) {
            String panNumber = reqSourceTmm.getPan().replaceAll(" ", "");
            BinInfoModel binInfoModel = SpringContextBridge.services().getCacheService().getSchemeBin(panNumber);
            tokenizationApplicable = isTokenizationApplicable(binInfoModel);

            if (tokenizationApplicable && (!reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REFUND_TXN)
                    && !reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN))) {
                List<TargetConfigModel> targetConfigs = SpringContextBridge.services().getInitRestClient().getTargetConfigs();
                TargetConfigModel wibmoConfigMasters = targetConfigs.stream().filter(tmodel -> tmodel.getEntityId().equals(reqSourceTmm.getEntityId())).
                        filter(tmodel -> tmodel.getTargetType().toString().equals(TargetType.Wibmo.name())).findFirst().orElse(null);
                logger.info("Wibmo Target Fetched  : {}", wibmoConfigMasters.getId());
                CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(wibmoConfigMasters.getId().toString(), reqSourceTmm.getCardAcceptorId(), reqSourceTmm.getCardAcceptorTerminalId());
                if (targetMerchantMaster != null) {
                    String generatedAccessToken = generatedAccessToken(wibmoConfigMasters.getAdditionalData(), false);
                    if (StringUtils.isBlank(generatedAccessToken)) {
                        throw new DataAuthenticationException("Authentication Failed");
                    }
                    HttpHeaders wibmoHeaders = buildWibmoApiHeader(wibmoConfigMasters.getAdditionalData(), generatedAccessToken);
                    JSONObject tokenizationResponse = tokenizationTxnRequest(reqSourceTmm, reqTargetTmm, wibmoConfigMasters, wibmoHeaders, binInfoModel);
                    if (tokenizationResponse != null && tokenizationResponse.get("status").equals("Success")) {
                        String altId = (String) tokenizationResponse.get("encTokenInfo");
                        iv = (String) tokenizationResponse.get("iv");
                        tokenCryptogram = (String) tokenizationResponse.get("var2");
                        String tokenExpiryDate = (String) tokenizationResponse.get("tokenExpiryDate");
                        String secretKey = wibmoConfigMasters.getAdditionalData().getApiInfo().getWibmoUrls().getTokenizationSecretKey();
                        String decryptedAltId = null;
                        try {
                            decryptedAltId = WibmoEncryptionDecryptionUtil.decrypt(altId,
                                    WibmoEncryptionDecryptionUtil.generateSecretKey(secretKey),
                                    iv.getBytes());
                            String maskCardNumber = MaskingUtility.maskCardNumber(decryptedAltId);
                            reqTargetTmm.getSmartRouteData().getLyraData().setCardNumber(maskCardNumber);
                            reqTargetTmm.getSmartRouteData().getLyraData().setExpMonth(tokenExpiryDate.substring(0,2));
                            reqTargetTmm.getSmartRouteData().getLyraData().setExpMonth(tokenExpiryDate.substring(2,4));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        reqTxnModel.setCardNumber(decryptedAltId);
                        reqTxnModel.setExpMonth(tokenExpiryDate.substring(0,2));
                        reqTxnModel.setExpYear(tokenExpiryDate.substring(2,4));
                        reqTargetTmm.setEncryptedExpirationDate(SpringContextBridge.services().getEncryptionService().encrypt(tokenExpiryDate));
                        reqTargetTmm.setEncryptedPan(SpringContextBridge.services().getEncryptionService().encrypt(decryptedAltId));
                    } else {
                        throw new DataAuthenticationException("Tokenization Failed");
                    }
                }
            }
        }
        try {
            JSONObject jsonObject = new JSONObject(IsgJsonUtils.getJsonString(reqTxnModel));
            String url;
            if (reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REFUND_TXN) ||
                    reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN)) {
                logger.info("Refund request Json: {}", jsonObject.toString());
                headers.add("uuid", reqTargetTmm.getSmartRouteData().getLyraData().getUuid());
//				url = targetAdditionalData.getApiInfo().getLyra().getRefundUrl();
                jsonObject.put("amount", new BigDecimal(reqTxnModel.getAmount()));
                reqTargetTmm.setDrcrFlag("C");
                if (reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN)) {
                    reqTargetTmm.setDrcrFlag("R");
                }
                msgContext.setRawMsg(jsonObject);
                msgContext.setApiHeaders(headers.toSingleValueMap());
                reqTargetTmm.getSmartRouteData().setRedirectUrl(null);
                reqTargetTmm.setTargetType(TargetType.Lyra);
            } else {
                logger.info("Submit Card request Created");
                headers.add("uuid", reqTargetTmm.getSmartRouteData().getLyraData().getUuid());
                url = targetAdditionalData.getApiInfo().getLyra().getSubmitCardUrl();
                jsonObject.put("uuid", reqTargetTmm.getSmartRouteData().getLyraData().getUuid());
                SpringContextBridge.services().getCacheUtil().putSeqNo(reqTargetTmm.getTransactionId(),reqTargetTmm.getSmartRouteData().getLyraData().getUuid());
                if(tokenizationApplicable) {
                    jsonObject.put("tokenCryptogram", tokenCryptogram);
                }

                String body = callApiByWebClient(url, headers, jsonObject);

                body = removeQuotesAndUnescape(body);
                String[] split = body.split(API_RESPONSE_SEPARATOR);
                int status = Integer.parseInt(split[0]);
                JSONObject submitCardRes = new JSONObject(split[1]);
                submitCardRes.put("uuid", reqTargetTmm.getSmartRouteData().getLyraData().getUuid());
                List<FormData> formDataList = setResponseInFormData(submitCardRes);
                msgContext.setRawMsg(formDataList);
                reqTargetTmm.getSmartRouteData().setRedirectData(formDataList);
                reqTargetTmm.setResCode("-1");
                reqTargetTmm.getSmartRouteData().setRedirectUrl(reqTargetTmm.getSmartRouteData().getReturnUrl());
            }
            msgContext.setTransactionMessageModel(reqTargetTmm);
            msgContext.setMessageTransformationConfig(msgTransConfig);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return msgContext;
    }

    private boolean isTokenizationApplicable(BinInfoModel binInfoModel) {
        boolean flag = false;
        switch (binInfoModel.getSchemeName()) {
            case "Visa":
                if (CacheSrConfigProperties.getProperty("visa.tokenization.flag").equalsIgnoreCase("Y"))
                    flag = true;
                break;
            case "Master":
                if (CacheSrConfigProperties.getProperty("master.tokenization.flag").equalsIgnoreCase("Y"))
                    flag = true;
                break;
            case "Rupay":
                if (CacheSrConfigProperties.getProperty("rupay.tokenization.flag").equalsIgnoreCase("Y"))
                    flag = true;
                break;
            case "Amex":
                if (CacheSrConfigProperties.getProperty("amex.tokenization.flag").equalsIgnoreCase("Y"))
                    flag = true;
                break;
            default:
                break;
        }
        return flag;
    }


    public List<FormData> setResponseInFormData(JSONObject submitCardRes) {
        TransactionMessageModel.LyraResData lyraResData = new Gson().fromJson(submitCardRes.toString(), TransactionMessageModel.LyraResData.class);

        ObjectMapper objectMapper = new ObjectMapper();

        Map<String, Object> map = objectMapper.convertValue(lyraResData, Map.class);
        List<FormData> formDataList = new ArrayList<>();

        for (String parameter : map.keySet()) {

            Object value = map.get(parameter);
            if (value != null) {
                if (value instanceof LinkedHashMap) {
                    for (Object params : ((LinkedHashMap) value).keySet()) {
                        FormData formData = new FormData();
                        Object paramValue = (String) ((LinkedHashMap) value).get(params);
                        formData.setKey(params.toString());
                        formData.setValue(paramValue != null ? paramValue.toString() : null);
                        formDataList.add(formData);
                    }
                } else {
                    FormData formData = new FormData();
                    formData.setKey(parameter);
                    formData.setValue(value != null ? value.toString() : null);
                    formDataList.add(formData);
                }
            }
        }
        return formDataList;
    }

    public String generatedAccessToken(TargetAdditionalData targetAdditionalData, boolean isOnboard) {
        String generatedAccessTokenApiUrl = targetAdditionalData.getApiInfo().getWibmoUrls().getGenAccessTokenApiUrl();
        HttpHeaders generatedAccessTokenHeaders = buildGenerateAccessTokenApiHeaders(targetAdditionalData);
        String res = null;
        try {
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("grant_type", "client_credentials");
            res = callApiUsingWebClient(map, null, generatedAccessTokenApiUrl, null, generatedAccessTokenHeaders);
            if (res != null) {
                res = new JSONObject(res).getString("access_token");
            }
        } catch (Exception e) {
            if (isOnboard) {
                res = "Error ::" + e.getMessage();
            }
            logger.info("Exception while calling Generate Access Token API Request : {} ", e.getMessage());
        }
        return res;
    }

    public JSONObject tokenizationTxnRequest(TransactionMessageModel reqSrcTmm, TransactionMessageModel reqTargetTmm, TargetConfigModel wibmoTargetMerchantMaster, HttpHeaders headers, BinInfoModel binInfoModel) {
        String tokenizationUrl = wibmoTargetMerchantMaster.getAdditionalData().getApiInfo().getWibmoUrls().getTokenizationUrl();
        String tokenSecretKey = wibmoTargetMerchantMaster.getAdditionalData().getApiInfo().getWibmoUrls().getTokenizationSecretKey();
        MapsInfoModel mapsInfoModel = SpringContextBridge.services().getCacheService().validateAndGetMerchant(reqSrcTmm.getEntityId(), reqSrcTmm.getCardAcceptorId(),
                reqSrcTmm.getCardAcceptorTerminalId(), null);
        String body = "";
        JSONObject tokenizationResponse;
        try {
            String iv = getRandomUuid();
            String panNumber = reqSrcTmm.getPan().replaceAll(" ", "");
            String dt = reqSrcTmm.getExpirationDate().replaceAll("\\s+", "");
            String expYr = reqSrcTmm.getExpirationDate().replaceAll("\\s+", "").replaceAll("\u2002", "");
            int currentYear = Year.now().getValue();
            int firstTwoDigits = currentYear / 100;
            String name = keepSpecificSpecialCharactersWithAlphaNumeric(mapsInfoModel.getMerchantName(), " ", " ");
            String encryptedData = WibmoEncryptionDecryptionUtil.generateEncPayload(name,
                    panNumber,
                    reqSrcTmm.getCvv(), dt.substring(0, 2),
                    firstTwoDigits + expYr.substring(3),
                    mapsInfoModel.getMerchantEmail(),
                    mapsInfoModel.getMerchantShortCountryCode(), iv, WibmoEncryptionDecryptionUtil.generateSecretKey(tokenSecretKey));
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("encryptedData", encryptedData);
            String cardType = null;
            String tokenRequestorId = null;
//            String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqTargetTmm.getTarget());
//            CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId());
//            String dpaId = targetMerchantMaster.getDpdId();
            CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(wibmoTargetMerchantMaster.getId().toString(), reqSrcTmm.getCardAcceptorId(), reqSrcTmm.getCardAcceptorTerminalId());
            String dpaId = targetMerchantMaster.getDpdId();
            switch (binInfoModel.getSchemeName()) {
                case "Visa":
                    cardType = "V";
                    tokenRequestorId = CacheSrConfigProperties.getProperty("wibmo.visa.token.requestor.id");
                    jsonObject.put("acquirerInstanceId",CacheSrConfigProperties.getProperty("wibmo.acquirer.ica"));
                    break;
                case "Master":
                    cardType = "M";
                    tokenRequestorId = CacheSrConfigProperties.getProperty("wibmo.master.token.requestor.id");
                    jsonObject.put("acquirerInstanceId",dpaId);
                    break;
                case "Rupay":
                    cardType = "R";
                    tokenRequestorId = CacheSrConfigProperties.getProperty("wibmo.rupay.token.requestor.id");
                    jsonObject.put("acquirerInstanceId",CacheSrConfigProperties.getProperty("wibmo.acquirer.ica"));
                    break;
                default:
                    break;
            }
            jsonObject.put("cardType",cardType);
            jsonObject.put("provider", "GC");
            jsonObject.put("tokenRequestorId",tokenRequestorId);
            jsonObject.put("userConsent","N");
            jsonObject.put("merchantId", CacheSrConfigProperties.getProperty("wibmo.merchant.id"));
            jsonObject.put("clientReferenceId", reqSrcTmm.getTransactionId());
            jsonObject.put("iv", iv);
            jsonObject.put("acquirerMerchantId", reqSrcTmm.getCardAcceptorId());
            jsonObject.put("amount", getTotalAmountInPaisaIfCCSIinPaisa(reqSrcTmm).toString());
            jsonObject.put("currency", mapsInfoModel.getAcquirerCurrencyCode());
            String merchantName = keepSpecificSpecialCharactersWithAlphaNumeric(mapsInfoModel.getMerchantName().length() > 30 ?
                    mapsInfoModel.getMerchantName().substring(0, 30) : mapsInfoModel.getMerchantName() + mapsInfoModel.getMid(), " ", " ");

            jsonObject.put("merchantName", merchantName);

            logger.info("Wimbo Tokenization API URL : {} And Request : {} ",tokenizationUrl,jsonObject.toString());
            body = callApiByWebClient(tokenizationUrl, headers, jsonObject);
            body = removeQuotesAndUnescape(body);
            String[] split = body.split(API_RESPONSE_SEPARATOR);
            int status = Integer.parseInt(split[0]);
            String response = split[1];
            tokenizationResponse = new JSONObject(response);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return tokenizationResponse;
    }

    private static String getRandomUuid() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().replace("-", "");
    }

    public HttpHeaders buildWibmoApiHeader(TargetAdditionalData targetAdditionalData, String generatedAccessToken) {
        HttpHeaders headers = new HttpHeaders();
        String clientId = targetAdditionalData.getApiInfo().getWibmoUrls().getClientId();
        String clientApiUser = targetAdditionalData.getApiInfo().getWibmoUrls().getClientApiUser();
        String clientApiKey = targetAdditionalData.getApiInfo().getWibmoUrls().getClientApiKey();
        String salt =  targetAdditionalData.getApiInfo().getWibmoUrls().getSalt();
        String wibmoApiKey = targetAdditionalData.getApiInfo().getWibmoUrls().getWibmoApiKey();
        String vaultId = CacheSrConfigProperties.getProperty("wibmo.api.header.vault.id");
        headers.setContentType(MediaType.APPLICATION_JSON);

        //Creation of WIBMO X-Auth-Token : String digest = timestamp+"|"+vaultId+"|"+clientId+"|"+apiUser+"|"+apiKey
        long timestamp = System.currentTimeMillis() / 1000;
        String xAuthToken = generateAuthTokenHashWithTimestamp(vaultId, clientId, clientApiUser, clientApiKey, salt, timestamp);
        headers.add("X-Auth-Token",xAuthToken);
        headers.add("clientId",clientId);
        headers.add("clientApiUser",clientApiUser);
        headers.add("clientApiKey",clientApiKey);
        headers.setBearerAuth(generatedAccessToken);
        headers.add("apikey",wibmoApiKey);
        logger.info("Wibmo Headers : {}" , headers.toString());
        return headers;
    }

    public HttpHeaders buildGenerateAccessTokenApiHeaders(TargetAdditionalData targetAdditionalData) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add("apikey",targetAdditionalData.getApiInfo().getWibmoUrls().getGenAccessTokenApiKey());
        headers.setBasicAuth(targetAdditionalData.getApiInfo().getWibmoUrls().getGenAccessTokenAuthUserName(), targetAdditionalData.getApiInfo().getWibmoUrls().getGenAccessTokenAuthPassword());
        return headers;
    }

    public String generateAuthTokenHashWithTimestamp(String vaultId,String clientId, String apiUser, String
            apiKey, String salt,long timestamp){
        String digest = null;
        try {String data = timestamp+"|"+vaultId+"|"+clientId +"|"+apiUser+"|"+apiKey;
            digest = getDigest("HmacSHA256", salt, data , false);
            digest="wtv1:"+timestamp+":"+digest;
            logger.info("Created Digest For Request Header : {}" ,digest);
        } catch (Exception e){
            e.printStackTrace();
        }
        return digest;
    }

    private String getDigest(String algorithm, String sharedSecret, String data, boolean
            toLower) throws SignatureException {
        try {
            Mac sha256HMAC = Mac.getInstance(algorithm);
            SecretKeySpec secretKey = new
                    SecretKeySpec(sharedSecret.getBytes(StandardCharsets.UTF_8), algorithm);
            sha256HMAC.init(secretKey);
            byte[] hashByte = sha256HMAC.doFinal(data.getBytes(StandardCharsets.UTF_8));
            String hashString = toHex(hashByte);
            return toLower ? hashString.toLowerCase() : hashString;
        } catch (Exception e) {
            throw new SignatureException(e);}
    }

    private String toHex(byte[] bytes) {
        BigInteger bi = new BigInteger(1, bytes);
        return String.format("%0" + (bytes.length << 1) + "X", bi);
    }

    public String createCharge(TransactionMessageModel reqSrcTmm, TargetAdditionalData targetAdditionalData, HttpHeaders headers) {
        String createChargeUrl = targetAdditionalData.getApiInfo().getLyra().getChargeUrl();
        MapsInfoModel mapsInfoModel = SpringContextBridge.services().getCacheService().validateAndGetMerchant(reqSrcTmm.getEntityId(), reqSrcTmm.getCardAcceptorId(),
                reqSrcTmm.getCardAcceptorTerminalId(), null);
        String body = "";
        String uuid = "";
        try {
            JSONObject jsonObject = new JSONObject();
            JSONObject customerjsonObject = new JSONObject();
            JSONObject webHookjsonObject = new JSONObject();

            jsonObject.put("orderId", reqSrcTmm.getSmartRouteData().getMerchantTxnRefNo());
            jsonObject.put("orderInfo", reqSrcTmm.getSmartRouteData().getOrderInfo());
            jsonObject.put("currency", mapsInfoModel.getMerchantCurrencyCode());
//			jsonObject.put("amount", Long.valueOf(reqSrcTmm.getTxnAmt()));
            jsonObject.put("amount", getTotalAmountInPaisaIfCCSIinPaisa(reqSrcTmm));
            customerjsonObject.put("name", reqSrcTmm.getSmartRouteData().getLyraData().getCustomerName());
            customerjsonObject.put("emailId", mapsInfoModel.getMerchantEmail());
            customerjsonObject.put("phone", mapsInfoModel.getMerchantPhoneNo());
            jsonObject.put("customer", customerjsonObject);

            String reqQueryParam = "&mid=" + reqSrcTmm.getCardAcceptorId()
                    + "&tid=" + reqSrcTmm.getCardAcceptorTerminalId()
                    + "&linkHashId=" + (!StringUtils.isBlank(reqSrcTmm.getLinkHashId()) ? reqSrcTmm.getLinkHashId() : "")
                    + "&origTxnAmt=" + reqSrcTmm.getTxnAmt()
                    + "&transactionId=" + reqSrcTmm.getTransactionId()
                    + "&payOpt=" + reqSrcTmm.getSmartRouteData().getPayOpt();
            String webhookUrl = SerializationUtils.clone(targetAdditionalData.getApiInfo().getLyra().getWebHookUrl());
            webHookjsonObject.put("url", webhookUrl + reqQueryParam);
            jsonObject.put("webhook", webHookjsonObject);
            ObjectMapper mapper = new ObjectMapper();
            TargetApiInfo.Lyra.Return returnCloneData = SerializationUtils.clone(targetAdditionalData.getApiInfo().getLyra().getReturnData());
            String returnUrl = returnCloneData.getUrl() + reqQueryParam;
            returnCloneData.setUrl(returnUrl);
            Map<String, Object> returnData = mapper.readValue(IsgJsonUtils.getJsonString(returnCloneData), new TypeReference<Map<String, Object>>() {
            });
            jsonObject.put("url", returnUrl);
            jsonObject.put("return", returnData);
            logger.info("header: {}", headers);
            logger.info("request: {}", jsonObject.toString());

            body = callApiByWebClient(createChargeUrl, headers, jsonObject);

            body = removeQuotesAndUnescape(body);
            String[] split = body.split(API_RESPONSE_SEPARATOR);
            int status = Integer.parseInt(split[0]);
            String response = split[1];
            JSONObject chargeResponse = new JSONObject(response);

            uuid = (String) chargeResponse.get("uuid");

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return uuid;

    }

    public Map<String, Object> checkTrxnStatusRequest(TransactionMessageModel reqSrcTmm, TargetConfigModel targetConfigModel) {
        reqSrcTmm.setTarget(targetConfigModel.getTargetType().name());
        HttpHeaders headers = buildHeader(targetConfigModel.getAdditionalData(), reqSrcTmm);
        logger.info("header: {}", headers);

        JSONObject jsonObject = new JSONObject();
        String uuid = reqSrcTmm.getSmartRouteData().getLyraData().getUuid();
        if (StringUtils.isBlank(uuid)) {
            uuid = SpringContextBridge.services().getCacheUtil().getSeqNo(reqSrcTmm.getTransactionId());
        }
        jsonObject.put("uuid", uuid);
        String body = "";
        String response = "";
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> nodeMap = null;
        try {
            body = callApiByWebClient(targetConfigModel.getAdditionalData().getApiInfo().getLyra().getTxnStatusUrl(), headers, jsonObject);
            body = removeQuotesAndUnescape(body);
            String[] split = body.split(API_RESPONSE_SEPARATOR);
            int status = Integer.parseInt(split[0]);
            nodeMap = mapper.readValue(split[1], new TypeReference<Map<String, Object>>() {
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        logger.info("checkTrxnStatusRequest Response: {}", nodeMap);
        return nodeMap;
    }

    public String generateOtpRequest(TransactionMessageModel reqSrcTmm, TargetConfigModel targetConfigModel) {
        reqSrcTmm.setTarget(targetConfigModel.getTargetType().name());
        HttpHeaders headers = buildHeader(targetConfigModel.getAdditionalData(), reqSrcTmm);
        logger.info("header: {} and Url:{} ", headers, reqSrcTmm.getSmartRouteData().getLyraData().getUuid());

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("transaction_uuid", reqSrcTmm.getSmartRouteData().getLyraData().getUuid());

        String body = "";
        String responseMessage = "";
        try {
            body = callApiByWebClient(targetConfigModel.getAdditionalData().getApiInfo().getLyra().getGenerateOtpUrl(), headers, jsonObject);
            body = removeQuotesAndUnescape(body);
            String[] split = body.split(API_RESPONSE_SEPARATOR);
            int status = Integer.parseInt(split[0]);
            responseMessage = split[1];
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        logger.info("generateOtpRequest Response: {}", responseMessage);
        return responseMessage;
    }

    public String verifyOtpRequest(TransactionMessageModel reqSrcTmm, TargetConfigModel targetConfigModel) {
        reqSrcTmm.setTarget(targetConfigModel.getTargetType().name());
        HttpHeaders headers = buildHeader(targetConfigModel.getAdditionalData(), reqSrcTmm);
        String txnUUId = reqSrcTmm.getSmartRouteData().getLyraData().getTransactionUuid();
        headers.add("transaction_uuid", txnUUId);
        logger.info("header: {}", headers);

        String verifyOtpUrl = targetConfigModel.getAdditionalData().getApiInfo().getLyra().getVerifyOtpUrl();
        String body = "";
        String verifyOtpResponse;
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("otp", reqSrcTmm.getSmartRouteData().getLyraData().getOtp());
            jsonObject.put("ipAddress", reqSrcTmm.getSmartRouteData().getLyraData().getIpAddress());

            body = callApiByWebClient(verifyOtpUrl, headers, jsonObject);

            body = removeQuotesAndUnescape(body);
            String[] split = body.split(API_RESPONSE_SEPARATOR);
            int status = Integer.parseInt(split[0]);
            verifyOtpResponse = split[1];

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        logger.info("verifyOtpRequest Response: {}", verifyOtpResponse);
        return verifyOtpResponse;
    }

    public HttpHeaders buildHeader(TargetAdditionalData targetAdditionalData, TransactionMessageModel reqTargetTmm) {
        HttpHeaders headers = new HttpHeaders();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqTargetTmm.getTarget());
        CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getCardAcceptorTerminalId());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("apikey", targetAdditionalData.getApiInfo().getLyra().getApikey());
        String userName = targetMerchantMaster.getTargetMid();
        String password = targetMerchantMaster.getTestApiKey();
        if ("Y".equalsIgnoreCase(CacheSrConfigProperties.getProperty("set.lyra.api.prod.key"))) {
            password = targetMerchantMaster.getProdApiKey();
        }
        headers.setBasicAuth(userName, password);
        return headers;
    }

    public String callApiByWebClient(String createChargeUrl, HttpHeaders headers, JSONObject jsonObject) {
        String body;
        String encrypt = SpringContextBridge.services().getEncryptionService().encrypt(jsonObject.toString());
        logger.info("Api Calling with Url : {} , Headers : {} and Request body: {}", createChargeUrl, headers, encrypt);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.build()
                .post()
                .uri(createChargeUrl)
                .headers(httpHeaders -> {
                    httpHeaders.addAll(headers);
                })
                .body(Mono.just(jsonObject.toString()), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new RuntimeException("Target is not responding");
        }
        body = block.bodyToMono(String.class).block();
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + body;

        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public String keepSpecificSpecialCharactersWithAlphabates(String inputString, String allowedCharacters, String replaceChar) {
        String regex = "[^a-zA-Z" + Pattern.quote(allowedCharacters) + "]";
        // Use regular expression to remove unwanted characters
        if (!StringUtils.isBlank(inputString)) {
            return inputString.replaceAll(regex, replaceChar);
        }
        return null;
    }

    public String keepSpecificSpecialCharactersWithAlphaNumeric(String inputString, String allowedCharacters, String replaceChar) {
        String regex = "[^a-zA-Z0-9" + Pattern.quote(allowedCharacters) + "]";
        // Use regular expression to remove unwanted characters
        if (!StringUtils.isBlank(inputString)) {
            return inputString.replaceAll(regex, replaceChar);
        }
        return null;
    }

    public LyraWibmoMerchantRequestModel createWibmoMerchantRequest(MerchantMasterModel masterModel) {

        LyraWibmoMerchantRequestModel requestModel = new LyraWibmoMerchantRequestModel();
        requestModel.setTrTsp(CacheSrConfigProperties.getProperty("wibmo.tr.tsp.value"));
        requestModel.setMerchantId(CacheSrConfigProperties.getProperty("wibmo.merchant.id"));
        String name = keepSpecificSpecialCharactersWithAlphaNumeric(masterModel.getMerchantName().length() > 30 ?
                masterModel.getMerchantName().substring(0, 30) : masterModel.getMerchantName() + masterModel.getMid(), " ", " ");
        requestModel.setMerchantLegalName(name);
        requestModel.setMerchantTradeName(name);
        requestModel.setCompanyCity(masterModel.getMerchantCity());
        requestModel.setCompanyCountryCode(masterModel.getMerchantShortCountryCode());
        requestModel.setDpaUri(!StringUtils.isBlank(masterModel.getWebsiteURL()) ? masterModel.getWebsiteURL()
                : CacheSrConfigProperties.getProperty("wibmo.default.dpa.url"));

        List<String> originDomains = new ArrayList<>();
        if(!StringUtils.isBlank(masterModel.getWebsiteURL())) {
            originDomains.add(masterModel.getWebsiteURL());
        }
        originDomains.add(CacheSrConfigProperties.getProperty("wibmo.origin.domain.url"));
        requestModel.setOriginDomains(originDomains);

        List<LyraWibmoMerchantRequestModel.AcquirerData> acquirerDataList = new ArrayList<>();
        LyraWibmoMerchantRequestModel.AcquirerData acquirerData = new LyraWibmoMerchantRequestModel.AcquirerData();
        acquirerData.setAcquirerMerchantId(masterModel.getMid());
        acquirerData.setAcquirerIca(CacheSrConfigProperties.getProperty("wibmo.acquirer.ica"));
        acquirerData.setAcquiredBin(CacheSrConfigProperties.getProperty("wibmo.acquirer.bin"));
        acquirerDataList.add(acquirerData);
        requestModel.setAcquirerData(acquirerDataList);

        requestModel.setClientReferenceId("EasyPayPlus" + masterModel.getMid());
        return requestModel;
    }

    public LyraMerchantRequestModel createMerchant(MerchantMasterModel masterModel) {

        LyraMerchantRequestModel requestModel = new LyraMerchantRequestModel();
        LyraMerchantRequestModel.Business business = new LyraMerchantRequestModel.Business();
        String merchantName = keepSpecificSpecialCharactersWithAlphaNumeric(masterModel.getMerchantName(), " ", " ");
        String dbaName = keepSpecificSpecialCharactersWithAlphaNumeric(masterModel.getTradingName(), " ", " ");
        business.setName(merchantName);
        business.setDbaName(!StringUtils.isBlank(dbaName) ? dbaName : merchantName);
        business.setIntegrationType(masterModel.getIntegrationType().equalsIgnoreCase("PG") ? "ECOM" : masterModel.getIntegrationType());
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String format = myFormatObj.format(myDateObj);
        business.setDateOfEstablishment(format);
        business.setAddress(keepSpecificSpecialCharactersWithAlphaNumeric(masterModel.getMerchantAddress(), ",.&-/)(:;‘# ", " "));
        business.setCity(masterModel.getMerchantCity());
        business.setState(masterModel.getMerchantStateCode());
        business.setZipcode(String.valueOf(masterModel.getMerchantPincode()));
        business.setCountry(masterModel.getCountryName());
        String ownershipType = getOwnershipTypeByConsCode(masterModel.getOwnershipType(), "lyra");
        business.setOwnership(ownershipType);
        if (masterModel.getOwnershipType().startsWith("G") || StringUtils.isBlank(masterModel.getPanNumber())) {
            business.setPanNo("ABCDE1234P");
        } else {
            business.setPanNo(masterModel.getPanNumber());
        }
        business.setMcc(masterModel.getMccCode());
        LyraMerchantRequestModel.Contact contact = new LyraMerchantRequestModel.Contact();
//		contact.setDesignation("");
        contact.setName(merchantName);
        List<String> phone = new ArrayList<>();
        phone.add(masterModel.getMerchantMobNo());
        phone.add(masterModel.getMerchantMobNo());
        contact.setPhone(phone);
        contact.setEmail(masterModel.getMerchantEmail().toLowerCase());
        business.setContact(contact);
        business.setMasterMerchant("false");
//		mer.setRemarks("");
        if ("PG".equalsIgnoreCase(masterModel.getIntegrationType())) {
            business.setWebsiteUrl(!StringUtils.isBlank(masterModel.getWebsiteURL()) ? keepSpecificSpecialCharactersWithAlphabates(masterModel.getWebsiteURL(), ".&-/:;?%#_=+", "") : "https://icici.ms");
            business.setMid(masterModel.getMid());
            business.setTid(masterModel.getTid());
            business.setUpdatedBy("");
        } else if ("POS".equalsIgnoreCase(masterModel.getIntegrationType())) {
            business.setWebsiteUrl(!StringUtils.isBlank(masterModel.getWebsiteURL()) ? keepSpecificSpecialCharactersWithAlphabates(masterModel.getWebsiteURL(), ".&-/:;?%#_=+", "") : "");
            business.setSalesPerson("");
            business.setGstNo(keepSpecificSpecialCharactersWithAlphaNumeric(masterModel.getGstNumber(), "", ""));
            business.setCreatedBy("");
        }
        requestModel.setBusiness(business);

        LyraMerchantRequestModel.BankDetails bankModel = new LyraMerchantRequestModel.BankDetails();
        if ("PG".equalsIgnoreCase(masterModel.getIntegrationType())) {
            bankModel.setAccountName(CacheSrConfigProperties.getProperty("pg.account.name").trim());
            bankModel.setIfsc(CacheSrConfigProperties.getProperty("pg.lyra.ifsc").trim());
            bankModel.setBankName(CacheSrConfigProperties.getProperty("pg.lyra.bank.name").trim());
            bankModel.setAccountNo(CacheSrConfigProperties.getProperty("pg.lyra.account.no").trim());
            bankModel.setAccountType(CacheSrConfigProperties.getProperty("pg.lyra.account.type").trim());
        } else if ("POS".equalsIgnoreCase(masterModel.getIntegrationType())) {
            bankModel.setAccountName(CacheSrConfigProperties.getProperty("pos.account.name").trim());
            bankModel.setIfsc(CacheSrConfigProperties.getProperty("pos.lyra.ifsc").trim());
            bankModel.setBankName(CacheSrConfigProperties.getProperty("pos.lyra.bank.name").trim());
            bankModel.setAccountNo(CacheSrConfigProperties.getProperty("pos.lyra.account.no").trim());
            bankModel.setAccountType(CacheSrConfigProperties.getProperty("pos.lyra.account.type").trim());
        }
        requestModel.setBankDetails(bankModel);

        LyraMerchantRequestModel.Risk risk = new LyraMerchantRequestModel.Risk();
        risk.setAvgTicketSize("50000.00");
        risk.setTxCap("200000.00");
        risk.setDailyCap("2500000.00");
        risk.setDailyCount("9999");
        requestModel.setRisk(risk);

        if ("POS".equalsIgnoreCase(masterModel.getIntegrationType())) {
            LyraMerchantRequestModel.Pos posModel = new LyraMerchantRequestModel.Pos();
            List<LyraMerchantRequestModel.Pos> list = new ArrayList<>();
            posModel.setTerminalType(masterModel.getTerminalType());
            posModel.setTerminalModel(masterModel.getTerminalModel());
            posModel.setDeviceSerialNo(masterModel.getDeviceSerialNo());
            posModel.setValueAddedService(masterModel.getValueAddedService());
            posModel.setMid(masterModel.getMid());
            posModel.setTid(masterModel.getTid());
            posModel.setVpa(masterModel.getMerchantVpa());
            list.add(posModel);
            requestModel.setPos(list);
        }

        if (!StringUtils.isBlank(masterModel.getSeNumber()) && !StringUtils.isBlank(masterModel.getAuthorizedSignerDateOfBirth())) {
            LyraMerchantRequestModel.Amex amex = new LyraMerchantRequestModel.Amex();
            amex.setSellerId(masterModel.getMid());
            amex.setSeNumber(masterModel.getSeNumber());
            if(!StringUtils.isBlank(masterModel.getContactPerson())){
                String contactPerson = masterModel.getContactPerson().trim();
                amex.setAuthorizedSignerFirstName(contactPerson.contains(" ") ? contactPerson.substring(0, contactPerson.indexOf(" ")) : contactPerson);
                amex.setAuthorizedSignerLastName(contactPerson.contains(" ") ? contactPerson.substring(contactPerson.lastIndexOf(" ") + 1, contactPerson.length()) : contactPerson.substring(0, 1).toUpperCase());
            }else{
                throw new RuntimeException("Lyra onboarding failed due to contact person details are blank");
            }
            amex.setAuthorizedSignerDateOfBirth(masterModel.getAuthorizedSignerDateOfBirth());
            requestModel.setAmex(amex);
        }
        return requestModel;
    }

    private String setUuidInUrl(String url, TransactionMessageModel tmm) {
        String urlWithUuid = null;
        if (url != null && !url.isEmpty()) {
            urlWithUuid = url.replace("${uuid}", tmm.getSmartRouteData().getLyraData().getUuid());
        }
        return urlWithUuid;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType,
                                                                SourceProcessor srcProcessor) {
        return new LyraMessageConstruction();
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new LyraMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public TransactionMessageModel parseResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TransactionMessageModel resSrcTmm = apiTxnModel.buildTmm();
        apiTxnModel.setMerchantTxnRefNo(resSrcTmm.getSmartRouteData().getLyraData().getOrderId());
        resSrcTmm.setMerchantTxnRefNo(apiTxnModel.getMerchantTxnRefNo());
        TransactionMessageModel resTgtTmm = SerializationUtils.clone(resSrcTmm);
        SwitchBaseMessageConstruction baseMsgConstruction = getMessageConstruction();
        baseMsgConstruction.setSourceTmm(resSrcTmm);
        resSrcTmm.setTarget(targetConfigModel.getName());
        if (apiTxnModel.getStatus().equalsIgnoreCase("PAID")) {
            resTgtTmm.setResCode("00");
        } else {
            resTgtTmm.setResCode("96");
            apiTxnModel.setError("01");
        }
        resTgtTmm.setTransactionName("lyra.submit.card.response");
        resTgtTmm.setMsgType("Pay");
        resTgtTmm.setDrcrFlag("D");
//		resTgtTmm.setTxnAmt(apiTxnModel.getLyraAmount());
        resTgtTmm.setTxnAmt(apiTxnModel.getOrigTxnAmt());
        resTgtTmm.setTargetTxnId(apiTxnModel.getExternalId());
        resTgtTmm.setResponseReceivedTime(OffsetDateTime.now());
        return resTgtTmm;
    }

    @Override
    public TransactionMessageModel parseResponse(String responseBody, TransactionMessageModel tmm, String epId,
                                                 TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        logger.info("Lyra Transaction Response : {}", responseBody);
//		int status = Integer.parseInt(split[0]);
//		String response = split[1];
        int status = 200;
        String response = null;
        if (!StringUtils.isBlank(responseBody)) {
            responseBody = removeQuotesAndUnescape(responseBody);
            String[] split = responseBody.split(API_RESPONSE_SEPARATOR);
            status = Integer.parseInt(split[0]);
            response = split[1];
        }
        TransactionMessageModel.LyraResData lyraResData = null;
        //PtsV2PaymentsPost400Response cybsFailureResponse;
        TransactionMessageModel resSrcTmm = null;
        try {
            switch (status) {
                case 200:
                    if (LyraMsgType.Refund.msgType.equals(tmm.getMsgType()) || LyraMsgType.Reversal.msgType.equals(tmm.getMsgType())) {
                        lyraResData = IsgJsonUtils.getObjectFromJsonString(response, TransactionMessageModel.LyraResData.class);
                        resSrcTmm = getSuccessResSourceTmm(lyraResData, tmm);
                        if (lyraResData != null) {
                            resSrcTmm.setResCode("00");
                            resSrcTmm.setDrcrFlag("C");
                            if (LyraMsgType.Reversal.msgType.equals(tmm.getMsgType())) {
                                resSrcTmm.setDrcrFlag("R");
                            }
                        } else {
                            resSrcTmm.setResCode("96");
                            resSrcTmm.setDrcrFlag("N");
                        }
                    }
                    break;
                case 400:
                case 500:
                default :
                    if (LyraMsgType.Refund.msgType.equals(tmm.getMsgType()) || LyraMsgType.Reversal.msgType.equals(tmm.getMsgType())) {
                        resSrcTmm = getSuccessResSourceTmm(lyraResData, tmm);
                        resSrcTmm.setResCode("96");
                        resSrcTmm.setDrcrFlag("N");
                    }
                    break;
            }

            logger.trace("Lyra Refund Response: {}", lyraResData);
        } catch (Exception e) {
            logger.error("", e);
        }
        return resSrcTmm;
    }

    private TransactionMessageModel getSuccessResSourceTmm(TransactionMessageModel.LyraResData lyraResData, TransactionMessageModel reqSrcTmm) {
        TransactionMessageModel resSourceTmm = new TransactionMessageModel();
        setCommonResponseFields(reqSrcTmm, resSourceTmm);
        if (lyraResData != null) {
            resSourceTmm.setTargetTxnId(lyraResData.getExternalId());
            resSourceTmm.setRetrievalRefNo(lyraResData.getExternalId());
        }
        return resSourceTmm;
    }

    private void setCommonResponseFields(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSourceTmm) {
        resSourceTmm.setConnectionType(ConnectionType.API);
        resSourceTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resSourceTmm.setTransactionId(reqSrcTmm.getTransactionId());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setMsgType(reqSrcTmm.getMsgType());
        resSourceTmm.setProcessingCode(reqSrcTmm.getProcessingCode());
        resSourceTmm.setSourceProcessor(reqSrcTmm.getSourceProcessor());
        resSourceTmm.setResponseReceivedTime(OffsetDateTime.now());
        resSourceTmm.setAquirerCountryCode(reqSrcTmm.getAquirerCountryCode());
        resSourceTmm.setAquirerIdCode(reqSrcTmm.getAquirerIdCode());
        resSourceTmm.setCardAcceptorId(reqSrcTmm.getCardAcceptorId());
        resSourceTmm.setCardAcceptorTerminalId(reqSrcTmm.getCardAcceptorTerminalId());
        resSourceTmm.setEncryptedExpirationDate(reqSrcTmm.getEncryptedExpirationDate());
        resSourceTmm.setEntityId(reqSrcTmm.getEntityId());
        resSourceTmm.setMerchantType(reqSrcTmm.getMerchantType());
        resSourceTmm.setPosEntryMode(reqSrcTmm.getPosEntryMode());
        resSourceTmm.setResponseSentTime(OffsetDateTime.now());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setTxnAmt(reqSrcTmm.getTxnAmt());
        resSourceTmm.setDrcrFlag(reqSrcTmm.getDrcrFlag());
        resSourceTmm.setTerminalStan(reqSrcTmm.getTerminalStan());
        resSourceTmm.setStan(reqSrcTmm.getStan());
        resSourceTmm.setEncryptedPan(reqSrcTmm.getEncryptedPan());
        resSourceTmm.setMaskedPan(reqSrcTmm.getMaskedPan());
        resSourceTmm.setCardAcceptorInfo(reqSrcTmm.getCardAcceptorInfo());
        resSourceTmm.setForwardingInstIdCode(reqSrcTmm.getForwardingInstIdCode());
        resSourceTmm.setSettlementCurrenyCode(reqSrcTmm.getSettlementCurrenyCode());
        resSourceTmm.setSource(reqSrcTmm.getTarget());
        resSourceTmm.setTarget(reqSrcTmm.getSource());
        resSourceTmm.setTransactionName(reqSrcTmm.getTransactionName().replace("request", "response"));
        resSourceTmm.setTargetType(reqSrcTmm.getTargetType());
        resSourceTmm.setPgData(reqSrcTmm.getPgData());
        resSourceTmm.setTerminalBatchNo(reqSrcTmm.getTerminalBatchNo());
//		resSourceTmm.setResCode("00");
        resSourceTmm.setSmartRouteData(reqSrcTmm.getSmartRouteData());
        resSourceTmm.setTxnCurrencyCode(reqSrcTmm.getTxnCurrencyCode());
        resSourceTmm.setMerchantTxnRefNo(reqSrcTmm.getMerchantTxnRefNo());
    }

    public void validateResponseErrorCode(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TargetApiInfo.Lyra lyra = targetConfigModel.getAdditionalData().getApiInfo().getLyra();
        if (lyra != null && !StringUtils.isBlank(lyra.getTechErrorCodes())) {
            String[] split = lyra.getTechErrorCodes().split(",");
            Set<String> techErrorCodes = Arrays.stream(split).collect(Collectors.toSet());
            boolean value = techErrorCodes.contains(apiTxnModel.getError());
            if (value) {
                throw new BankServerException("Deliberately failed the transaction due to the bank server issue : ", targetConfigModel.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
            }
        }
    }

    public static BigDecimal getTotalAmountInPaisaIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = new BigDecimal(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = new BigDecimal(tmmModel.getConvenienceFee());
        BigDecimal cgst = new BigDecimal(tmmModel.getCgst());
        BigDecimal sgst = new BigDecimal(tmmModel.getSgst());
        BigDecimal igst = new BigDecimal(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return new BigDecimal(amount.setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString());
    }

    public static BigDecimal getTotalAmountInRupeesIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getConvenienceFee());
        BigDecimal cgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getCgst());
        BigDecimal sgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getSgst());
        BigDecimal igst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return amount.setScale(2, RoundingMode.HALF_UP);
    }


    public String callApiUsingWebClient(MultiValueMap<String, String> mapBody, String strBody, String url, Map<String, String> headers, HttpHeaders httpHeaders) {
        logger.info("Invoking API through Web Client: {}, with Request Body: {} {}", url, mapBody, strBody);
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        } catch (SSLException e) {
            e.printStackTrace();
        }
        SslContext finalSslContext = sslContext;
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = null;
        HttpStatus httpStatus = null;
        WebClient.RequestBodySpec requestBodySpec = null;
        if(headers != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .post()
                    .uri(url)
                    .headers(headers1 -> {
                        headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                    });
        }else if(httpHeaders != null){
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .post()
                    .uri(url)
                    .headers(headers1 -> {
                        httpHeaders.forEach((key, value) -> headers1.put(key, value));
                    });
        }
        if (mapBody != null) {
            block = requestBodySpec.body(BodyInserters.fromFormData(mapBody)).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        } else if (strBody != null) {
            block = requestBodySpec.body(Mono.just(strBody), String.class).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        }
        String res = null;
        if(httpStatus == HttpStatus.OK || httpStatus == HttpStatus.CREATED){
            res  = block.bodyToMono(String.class).block();
        }else {
            res = "status : " + httpStatus.toString() + "##" +" body : " + block.bodyToMono(String.class).block();
        }

        logger.info("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

}