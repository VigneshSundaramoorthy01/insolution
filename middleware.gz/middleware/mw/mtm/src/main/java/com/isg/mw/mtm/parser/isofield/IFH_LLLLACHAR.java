package com.isg.mw.mtm.parser.isofield;

import org.jpos.iso.ISOStringFieldPackager;
import org.jpos.iso.NullPadder;

import com.isg.mw.mtm.parser.interpreter.HexToEbcdicInterpreter;
import com.isg.mw.mtm.parser.prefixer.AsciiPrefixer;

public class IFH_LLLLACHAR extends ISOStringFieldPackager {

	public IFH_LLLLACHAR() {
		super(NullPadder.INSTANCE, HexToEbcdicInterpreter.INSTANCE, AsciiPrefixer.LLLL);
	}

	/**
	 * @param len         - field len
	 * @param description symbolic descrption
	 */
	public IFH_LLLLACHAR(int len, String description) {
		super(len, description, NullPadder.INSTANCE, HexToEbcdicInterpreter.INSTANCE, AsciiPrefixer.LLLL);
		checkLength(len, 9999);
	}

	@Override
	public void setLength(int len) {
		checkLength(len, 9999);
		super.setLength(len);
	}
}
