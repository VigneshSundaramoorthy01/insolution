package com.isg.mw.mtm.util;

public class MtmConstants {

	public static final String RAW_LOG = "rawLog";

	public static final String SENSITIVE_DATA_HIDE_ALIAS = "PRESENT";

	// TODO: move it specific strategies after strategy pattern is used
	public static final String POS_TERMINAL_INVOICE_NO = "0004";
	public static final String POS_TERMINAL_BATCH_NO = "0005";
	public static final String POS_HARDWARE_SERIAL_NO = "0006";
	public static final String DEFAULT_MSG_FORMAT = "0000";
	public static final String DECLINE_TXN_START = "decline";
	public static final String DECLINE_TXN_PG_START = "decline.pg";
	public static final String MC_MERCHANT_TYPE = "6010";

	
	public static final String POS_TERMINAL_KSN_1 = "0014";
	public static final String POS_TERMINAL_KSN_2 = "0015";
	public static final String DEVICE_MFTR = "0016";
	public static final String POS_TERMINAL_CID = "0405";
	public static final String POS_AAV_DATA = "0402";
	public static final String POS_TRID_DATA = "0601";
	
	public static final String DECLINE_TXN_BQR_START = "decline.bqr";
	
	public static final String POS_TERMINAL_ORIGINAL_AMT = "0007";
	public static final String MAC_TAG_NAME = "0990";

	/**********************|ICC Tags|**************************/
	public static final String ICC_CARD_SEQ_NUM = "5f34";
	public static final String ICC_TXN_TYPE = "9C";
	public static final String ICC_APP_INDICATOR = "84";
	/**********************************************************/
	
	/**********************|DCC Transaction Tags|**************************/
	public static final String RATE_LOOKUP_TXN_RRN = "0017";
	public static final String DCC_AMOUNT = "0300";
	public static final String DCC_EXCHANGE_RATE = "0301";
	public static final String DCC_MARKUP_PERCENT = "0302";
	public static final String DCC_TXN_CURRENCY_CODE = "0303";
	public static final String DCC_CURRENCY_NAME = "0304";
	public static final String DCC_NO_OF_DECIMALS = "0305";
	public static final String DCC_INDICATOR = "0306";
	public static final String DCC_ORG__TXN_CURRENCY_CODE = "0307";
	public static final String DCC_ORG__TXN_AMOUNT = "0308";
	public static final String TXN_CURRENCY_CODE = "0001";
	/**********************************************************/
	
	/**********************|Terminal batch Details|************************/
	public static final String TERMINAL_BATCH_NO = "0601";
	public static final String TERMINAL_MERCHANT_NAME = "0602";
	public static final String TERMINAL_MERCHANT_CURRENCY = "0603";
	public static final String TERMINAL_MERCHANT_COUNTRY = "0604";
	public static final String TERMINAL_MERCHANT_ADDRESS= "0605";
	public static final String TERMINAL_MERCHANT_CITY= "0606";
	public static final String TERMINAL_MERCHANT_ZIPCODE= "0607";
	/**********************************************************/

	public static final String NETWORK_LINK = "1110";

}
