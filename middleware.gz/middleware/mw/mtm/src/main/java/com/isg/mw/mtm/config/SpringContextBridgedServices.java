package com.isg.mw.mtm.config;

import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.mtm.util.MwRedisCacheUtil;
import org.springframework.web.client.RestTemplate;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.dstm.service.HsmCommonService;
import org.springframework.web.reactive.function.client.WebClient;

public interface SpringContextBridgedServices {

    public CacheServices getCacheService();

    public HsmCommonService getHsmCommonService();

    public EncryptService getEncryptionService();

    public WebClient.Builder getWebClient();

    public RestTemplate getRestTemplate();

    public MwRedisCacheUtil getMwRedisCacheUtil();

    public DecryptService getDecryptionService();

    CacheUtil getCacheUtil();

    InitRestClient getInitRestClient();

    SmartRouteSpringCacheService getSrCacheService();
}
