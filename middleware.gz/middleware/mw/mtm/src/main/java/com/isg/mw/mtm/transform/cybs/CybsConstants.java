package com.isg.mw.mtm.transform.cybs;

public class CybsConstants {
    public static final String RES_AUTHORIZED = "AUTHORIZED";
    public static final String RES_PARTIAL_AUTHORIZED = "PARTIAL_AUTHORIZED";
    public static final String RES_AUTHORIZED_PENDING_REVIEW = "AUTHORIZED_PENDING_REVIEW";
    public static final String RES_AUTHORIZED_RISK_DECLINED = "AUTHORIZED_RISK_DECLINED";
    public static final String RES_PENDING_AUTHENTICATION = "PENDING_AUTHENTICATION";
    public static final String RES_PENDING_REVIEW = "PENDING_REVIEW";
    public static final String RES_DECLINED = "DECLINED";
    public static final String RES_INVALID_REQUEST = "INVALID_REQUEST";
    public static final String REVERSED = "REVERSED";
}
