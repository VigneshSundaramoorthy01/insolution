package com.isg.mw.mtm.transform.pg;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.pg.PgMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class PgMessageTransformation extends BaseMessageTransformation {
    private Logger logger = LogManager.getLogger(getClass());
    private static final Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {
        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }
        /**
         * Switch To Scheme Purchase Request and Scheme To Switch Purchase Response
         */
        getPgToSwitchPurchaseRequest(tmmConfig);
        getSwitchToPgPurchaseResponse(tmmConfig);

        /**
         * Switch To Scheme Purchase Aav Request and Scheme To Switch Purchase Aav Response
         */
        getPgToSwitchPurchaseAavRequest(tmmConfig);
        getSwitchToPgPurchaseAavResponse(tmmConfig);

        /**
         * Switch To Scheme Purchase Aav Request and Scheme To Switch Purchase Aav Response
         */
        getPgToSwitchOnlineRefundAavRequest(tmmConfig);
        getSwitchToPgOnlineRefundAavResponse(tmmConfig);

        /**
         * Switch To Scheme  Aav Request and Scheme To Switch  Aav Response
         */
        getPgToSwitchAavRequest(tmmConfig);
        getSwitchToPgAavResponse(tmmConfig);


        /**
         * Switch To Scheme PreAuth Request and Scheme To Switch PreAuth Response
         */
        getPgToSwitchPreAuthRequest(tmmConfig);
        getSwitchToPgPreAuthResponse(tmmConfig);

        /**
         * Switch To Scheme PreAuthCompletion Request and Scheme To Switch PreAuthCompletion Response
         */
        getPgToSwitchCaptureRequest(tmmConfig);
        getSwitchToPgCaptureResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Request and Scheme To Switch Refund Response
         */
        getPgToSwitchOnlineRefundRequest(tmmConfig);
        getSwitchToPgOnlineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Request and Scheme To Switch Refund Response
         */
        getPgToSwitchOfflineRefundRequest(tmmConfig);
        getSwitchToPgOfflineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Reversal Request and Scheme To Switch Reversal Response
         */
        getPgToSwitchReversalRequest(tmmConfig);
        getSwitchToPgReversalResponse(tmmConfig);


        getPgToSwitchReversalVoidRequest(tmmConfig);
        getSwitchToPgReversalVoidResponse(tmmConfig);

        /**
         * Switch To Scheme SIRP Request and Scheme To Switch SIRP Response
         */
        getPgToSwitchAmexSIRequest(tmmConfig);
        getSwitchToPgAmexSIResponse(tmmConfig);

        /**
         * Switch To Scheme SI Request and Scheme To Switch SI Response
         */
        getPgToSwitchSIRequest(tmmConfig);
        getSwitchToPgSIResponse(tmmConfig);

        /**
         * Switch To Scheme RP Request and Scheme To Switch RP Response
         */
        getPgToSwitchRPRequest(tmmConfig);
        getSwitchToPgRPResponse(tmmConfig);

        /**
         * Switch To Scheme OnlineOfflineRefund Request and Scheme To Switch OnlineOfflineRefund Response
         */
        getPgToSwitchOnlineOfflineRefundRequest(tmmConfig);
        getSwitchToPgOnlineOfflineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme PreAuthReversal Request and Scheme To Switch PreAuthReversal Response
         */
        getPgToSwitchPreAuthReversalRequest(tmmConfig);
        getSwitchToPgPreAuthReversalResponse(tmmConfig);


        /**
         * Switch To Scheme PreAuthReversal Void Request and Scheme To Switch PreAuthReversal Void Response
         */

        getPgToSwitchPreAuthReversalVoidRequest(tmmConfig);
        getSwitchToPgPreAuthReversalVoidResponse(tmmConfig);
        /**
         * PG To Switch Moto sale Request and Switch To PG Moto sale Response
         */
        getPgToSwitchMotoSaleRequest(tmmConfig);
        getSwitchToPgMotoSaleResponse(tmmConfig);

        /**
         * PG To Switch Moto Reversal Request and Switch To PG Moto Reversal Response
         */
        getPgToSwitchMotoReversalRequest(tmmConfig);
        getSwitchToPgMotoReversalResponse(tmmConfig);

        /**
         * PG To Switch Moto Refund Request and Switch To PG Moto Refund Response
         */
        getPgToSwitchMotoRefundRequest(tmmConfig);
        getSwitchToPgMotoRefundResponse(tmmConfig);


        /**
         * PG To Switch Mo sale Request and Switch To PG Mo sale Response
         */
        getPgToSwitchMoSaleRequest(tmmConfig);
        getSwitchToPgMoSaleResponse(tmmConfig);

        /**
         * PG To Switch To sale Request and Switch To PG To sale Response
         */
        getPgToSwitchToSaleRequest(tmmConfig);
        getSwitchToPgToSaleResponse(tmmConfig);

        /**
         * PG To Switch Mo Reversal Request and Switch To PG Mo Reversal Response
         */
        getPgToSwitchMoReversalRequest(tmmConfig);
        getSwitchToPgMoReversalResponse(tmmConfig);

        /**
         * PG To Switch To Reversal Request and Switch To PG To Reversal Response
         */
        getPgToSwitchToReversalRequest(tmmConfig);
        getSwitchToPgToReversalResponse(tmmConfig);

        /**
         * PG To Switch Mo Refund Request and Switch To PG Mo Refund Response
         */
        getPgToSwitchMoRefundRequest(tmmConfig);
        getSwitchToPgMoRefundResponse(tmmConfig);

        /**
         * PG To Switch To Refund Request and Switch To PG To Refund Response
         */
        getPgToSwitchToRefundRequest(tmmConfig);
        getSwitchToPgToRefundResponse(tmmConfig);

        /**
         * Switch To Scheme PreAuthAav Request and Scheme To Switch PreAuthAav Response
         */
        getPgToSwitchPreAuthAavRequest(tmmConfig);
        getSwitchToPgPreAuthAavResponse(tmmConfig);

        /**
         * Switch To Scheme SIAmex aav Request and Scheme To Switch SIAmex aav Response
         */
        getPgToSwitchAmexSIAavRequest(tmmConfig);
        getSwitchToPgAmexSIAavResponse(tmmConfig);



        /**
         * Switch To Scheme RP Aav Request and Scheme To Switch RP aav Response
         */
        getPgToSwitchRPAavRequest(tmmConfig);
        getSwitchToPgRPAavResponse(tmmConfig);

        /**
         * PG To Switch Mo sale aav Request and Switch To PG Mo sale aav Response
         */
        getPgToSwitchMoSaleAavRequest(tmmConfig);
        getSwitchToPgMoSaleAavResponse(tmmConfig);

        /**
         * PG To Switch To sale Request and Switch To PG To sale Response
         */
        getPgToSwitchToSaleAavRequest(tmmConfig);
        getSwitchToPgToSaleAavResponse(tmmConfig);
        
        /**
         * PG To Switch Moto PreAuth Request and Switch To PG Moto PreAuth Response
         */
        getPgToSwitchMotoPreAuthRequest(tmmConfig);
        getSwitchToPgMotoPreAuthResponse(tmmConfig);
        
        /**
         * PG To Switch Moto Capture Request and Switch To PG Moto Capture Response
         */
        getPgToSwitchMotoCaptureRequest(tmmConfig);
        getSwitchToPgMotoCaptureResponse(tmmConfig);
        
        /**
         * PG To Switch ZVAV Sale Request Request and Switch To ZVAV Sale Response
         */
        getPgToSwitchZvavSaleRequest(tmmConfig);
        getSwitchToPgZvavSaleResponse(tmmConfig);
        
        /**
         * PG To Switch ZVAV Sale Avv Request Request and Switch To ZVAV Sale Avv Response
         */
        getPgToSwitchZvavSaleAvvRequest(tmmConfig);
        getSwitchToPgZvavSaleAvvResponse(tmmConfig);

        return tmmConfig;
    }


    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        fieldsMap.put(90,TmmConstants.AUTH_OUTAGE_INDICATOR);
        tmmConfig.put(new TransactionTypeConfig("0200", "01", TmmConstants.PG_PURCHASE_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "01", TmmConstants.PG_PURCHASE_RESPONSE), fieldsMap);
    }
    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchPurchaseAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "21", TmmConstants.PG_PURCHASE_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgPurchaseAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "21", TmmConstants.PG_PURCHASE_AAV_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "22", TmmConstants.PG_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "22", TmmConstants.PG_AAV_RESPONSE), fieldsMap);
    }


    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "02", TmmConstants.PG_PREAUTH_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "02", TmmConstants.PG_PREAUTH_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,15,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchCaptureRequest(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "03", TmmConstants.PG_CAPTURE_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getSwitchToPgCaptureResponse(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "03", TmmConstants.PG_CAPTURE_RESPONSE),
                fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getPgToSwitchOnlineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "12", TmmConstants.PG_ONLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSwitchToPgOnlineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "12", TmmConstants.PG_ONLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getPgToSwitchOnlineRefundAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "23", TmmConstants.PG_REFUND_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSwitchToPgOnlineRefundAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "23", TmmConstants.PG_REFUND_AAV_RESPONSE), fieldsMap);
    }
    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getPgToSwitchOfflineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "04", TmmConstants.PG_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSwitchToPgOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "04", TmmConstants.PG_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,9,10,11,15,19,21,29,34}
     */
    private void getPgToSwitchReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "05", TmmConstants.PG_REVERSAL_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getSwitchToPgReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "05", TmmConstants.PG_REVERSAL_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,9,10,11,15,19,21,29,34}
     */
    private void getPgToSwitchReversalVoidRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "05", TmmConstants.PG_REVERSAL_VOID_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getSwitchToPgReversalVoidResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "05", TmmConstants.PG_REVERSAL_VOID_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchSIRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(23, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37, TmmConstants.PAN);
        fieldsMap.put(38, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39, TmmConstants.TAVV);
        fieldsMap.put(40, TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(41, TmmConstants.FIELD_41);
        fieldsMap.put(46, TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47, TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(63, TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64, TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65, TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66, TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67, TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68, TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69, TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70, TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71, TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73, TmmConstants.ACTION_DATE);
        fieldsMap.put(84, TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);    //MultiPurposeMerIndicator
        fieldsMap.put(87, TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        fieldsMap.put(89, TmmConstants.RECURRING_PAYMENT_INDICATOR);
        tmmConfig.put(new TransactionTypeConfig("0200", "11", TmmConstants.PG_SI_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgSIResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(41, TmmConstants.FIELD_41);
        fieldsMap.put(46, TmmConstants.ISO_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72, TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73, TmmConstants.ACTION_DATE);
        fieldsMap.put(84, TmmConstants.DEBITS_PROCESSING_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        tmmConfig.put(new TransactionTypeConfig("0210", "11", TmmConstants.PG_SI_RESPONSE), fieldsMap);
    }


    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchAmexSIRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7,TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12,TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20,TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33,TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(41,TmmConstants.FIELD_41);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        fieldsMap.put(89,TmmConstants.RECURRING_PAYMENT_INDICATOR);
        tmmConfig.put(new TransactionTypeConfig("0200", "27", TmmConstants.PG_SI_AMEX_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgAmexSIResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4,TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "27", TmmConstants.PG_SI_AMEX_RESPONSE), fieldsMap);
    }




    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchRPRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7,TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12,TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20,TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33,TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(41,TmmConstants.FIELD_41);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        fieldsMap.put(89,TmmConstants.RECURRING_PAYMENT_INDICATOR);
        tmmConfig.put(new TransactionTypeConfig("0200", "28", TmmConstants.PG_RP_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgRPResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4,TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "28", TmmConstants.PG_RP_RESPONSE), fieldsMap);
    }




    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getPgToSwitchOnlineOfflineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "13", TmmConstants.PG_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSwitchToPgOnlineOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "13", TmmConstants.PG_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,15,18,20,22,34}
     */
    private void getPgToSwitchPreAuthReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "14", TmmConstants.PG_PREAUTH_REVERSAL_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,18,20,22,33}
     */
    private void getSwitchToPgPreAuthReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "14", TmmConstants.PG_PREAUTH_REVERSAL_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,15,18,20,22,34}
     */
    private void getPgToSwitchPreAuthReversalVoidRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "14", TmmConstants.PG_PREAUTH_REVERSAL_VOID_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,18,20,22,33}
     */
    private void getSwitchToPgPreAuthReversalVoidResponse(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18,TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "14", TmmConstants.PG_PREAUTH_REVERSAL_VOID_RESPONSE), fieldsMap);
    }


    private void getPgToSwitchMotoSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(18,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "15", TmmConstants.PG_MOTO_SALE_REQUEST), fieldsMap);
    }

    private void getSwitchToPgMotoSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "15", TmmConstants.PG_MOTO_SALE_RESPONSE), fieldsMap);
    }

    private void getPgToSwitchMotoReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(18,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(41,TmmConstants.FIELD_41);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "16", TmmConstants.PG_MOTO_REVERSAL_REQUEST), fieldsMap);
    }

    private void getSwitchToPgMotoReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "16", TmmConstants.PG_MOTO_REVERSAL_RESPONSE), fieldsMap);
    }

    private void getPgToSwitchMotoRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7,TmmConstants.CVV2);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "17", TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    private void getSwitchToPgMotoRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "17", TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }

    private void getPgToSwitchMoSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(18,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "18", TmmConstants.PG_MO_SALE_REQUEST), fieldsMap);
    }

    private void getSwitchToPgMoSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "18", TmmConstants.PG_MO_SALE_RESPONSE), fieldsMap);
    }


    private void getPgToSwitchToSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(18,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "19", TmmConstants.PG_TO_SALE_REQUEST), fieldsMap);
    }

    private void getSwitchToPgToSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "19", TmmConstants.PG_TO_SALE_RESPONSE), fieldsMap);
    }


    private void getPgToSwitchMoReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(18,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(41,TmmConstants.FIELD_41);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "25", TmmConstants.PG_MO_REVERSAL_REQUEST), fieldsMap);
    }

    private void getSwitchToPgMoReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "25", TmmConstants.PG_MO_REVERSAL_RESPONSE), fieldsMap);
    }


    private void getPgToSwitchToReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(18,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(41,TmmConstants.FIELD_41);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(62,TmmConstants.REVERSAL_MSG_REASON_CODE);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0400", "26", TmmConstants.PG_TO_REVERSAL_REQUEST), fieldsMap);
    }

    private void getSwitchToPgToReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0410", "26", TmmConstants.PG_TO_REVERSAL_RESPONSE), fieldsMap);
    }

    private void getPgToSwitchMoRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7,TmmConstants.CVV2);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "20", TmmConstants.PG_MO_REFUND_REQUEST), fieldsMap);
    }

    private void getSwitchToPgMoRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "20", TmmConstants.PG_MO_REFUND_RESPONSE), fieldsMap);
    }


    private void getPgToSwitchToRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7,TmmConstants.CVV2);
        fieldsMap.put(8,TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15,TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(35, TmmConstants.CANCELATION_ID);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "24", TmmConstants.PG_TO_REFUND_REQUEST), fieldsMap);
    }

    private void getSwitchToPgToRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "24", TmmConstants.PG_TO_REFUND_RESPONSE), fieldsMap);
    }
    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchPreAuthAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "29", TmmConstants.PG_PREAUTH_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgPreAuthAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "29", TmmConstants.PG_PREAUTH_AAV_RESPONSE), fieldsMap);
    }
    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchAmexSIAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "30", TmmConstants.PG_SI_AMEX_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgAmexSIAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "30", TmmConstants.PG_SI_AMEX_AAV_RESPONSE), fieldsMap);
    }




    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchRPAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(49,TmmConstants.AAV_LENGTH_LAYOUT);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "31", TmmConstants.PG_RP_AAV_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgRPAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "31", TmmConstants.PG_RP_AAV_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchMoSaleAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "32", TmmConstants.PG_MO_SALE_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgMoSaleAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "32", TmmConstants.PG_MO_SALE_AAV_RESPONSE), fieldsMap);
    }




    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getPgToSwitchToSaleAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(49,TmmConstants.AAV_LENGTH_LAYOUT);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "33", TmmConstants.PG_TO_SALE_AAV_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSwitchToPgToSaleAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "33", TmmConstants.PG_TO_SALE_AAV_RESPONSE), fieldsMap);
    }


    private void getPgToSwitchMotoPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0200", "34", TmmConstants.PG_MOTO_PREAUTH_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgMotoPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0210", "34", TmmConstants.PG_MOTO_PREAUTH_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,15,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchMotoCaptureRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(74,TmmConstants.DEPARTURE_DATE);
        fieldsMap.put(75,TmmConstants.AIRLINE_PASSANGER_NAME);
        fieldsMap.put(76,TmmConstants.ORIGIN);
        fieldsMap.put(77,TmmConstants.DESTINATION);
        fieldsMap.put(78,TmmConstants.NO_OF_CITIES);
        fieldsMap.put(79,TmmConstants.ROUTING_CITIES);
        fieldsMap.put(80,TmmConstants.NO_OF_AIRLINE_CARRIERS);
        fieldsMap.put(81,TmmConstants.AIRLINE_CARRIRS);
        fieldsMap.put(82,TmmConstants.FARE_BASIS);
        fieldsMap.put(83,TmmConstants.NO_OF_PASSANGERS);
        fieldsMap.put(84,TmmConstants.MULTI_PURPOSE_MERCHANT_INDICATOR);
        fieldsMap.put(87,TmmConstants.MERCHANT_PAYMENT_GATEWAY_ID);
        tmmConfig.put(new TransactionTypeConfig("0220", "35", TmmConstants.PG_MOTO_CAPTURE_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getSwitchToPgMotoCaptureResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        tmmConfig.put(new TransactionTypeConfig("0230", "35", TmmConstants.PG_MOTO_CAPTURE_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchZvavSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        tmmConfig.put(new TransactionTypeConfig("0200", "36", TmmConstants.PG_ZVAV_PURCHASE_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgZvavSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        tmmConfig.put(new TransactionTypeConfig("0210", "36", TmmConstants.PG_ZVAV_PURCHASE_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getPgToSwitchZvavSaleAvvRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(7, TmmConstants.CVV2);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.AVV);
        fieldsMap.put(13,TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14,TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(23,TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(26,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(37,TmmConstants.PAN);
        fieldsMap.put(38,TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(39,TmmConstants.TAVV);
        fieldsMap.put(40,TmmConstants.TOKEN_REQUESTOR_ID);
        fieldsMap.put(42,TmmConstants.DS_TRANSACTION_ID);
        fieldsMap.put(43,TmmConstants.DS_MSG_CATEGORY);
        fieldsMap.put(44,TmmConstants.DD_ADD_MATCH_INDICATOR);
        fieldsMap.put(45,TmmConstants.DD_SECURE_INDICATOR);
        fieldsMap.put(46,TmmConstants.COF_TXN_ORIGIN);
        fieldsMap.put(47,TmmConstants.MASTERCARD_POS_DATA);
        fieldsMap.put(48,TmmConstants.CID);
        fieldsMap.put(50,TmmConstants.AAV_CARDMEMBER_BILLING_POSTAL_CODE);
        fieldsMap.put(51,TmmConstants.AAV_CARDMEMBER_BILLING_ADDRESS);
        fieldsMap.put(52,TmmConstants.AAV_CARDMEMBER_BILLING_FIRST_NAME);
        fieldsMap.put(53,TmmConstants.AAV_CARDMEMBER_BILLING_LAST_NAME);
        fieldsMap.put(54,TmmConstants.AAV_CARDMEMBER_BILLING_PHONE_NUMBER);
        fieldsMap.put(55,TmmConstants.AAV_SHIP_TO_POSTAL_CODE);
        fieldsMap.put(56,TmmConstants.AAV_SHIP_TO_ADDRESS);
        fieldsMap.put(57,TmmConstants.AAV_SHIP_TO_FIRST_NAME);
        fieldsMap.put(58,TmmConstants.AAV_SHIP_TO_LAST_NAME);
        fieldsMap.put(59,TmmConstants.AAV_SHIP_TO_PHONE_NUMBER);
        fieldsMap.put(60,TmmConstants.AAV_SHIP_TO_COUNTRY_CODE);
        fieldsMap.put(63,TmmConstants.CUSTOMER_EMAIL);
        fieldsMap.put(64,TmmConstants.CUSTOMER_HOSTNAME);
        fieldsMap.put(65,TmmConstants.HTTP_BROWSER_TYPE);
        fieldsMap.put(66,TmmConstants.SHIP_TO_COUNTRY);
        fieldsMap.put(67,TmmConstants.SHIPPING_METHOD);
        fieldsMap.put(68,TmmConstants.MERCHANT_PRODUCT_SKU);
        fieldsMap.put(69,TmmConstants.CUSTOMER_IP);
        fieldsMap.put(70,TmmConstants.CUSTOMER_ANI);
        fieldsMap.put(71,TmmConstants.CUSTOMER_II_DIGIT);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        tmmConfig.put(new TransactionTypeConfig("0200", "37", TmmConstants.PG_ZVAV_PURCHASE_AAV_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSwitchToPgZvavSaleAvvResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        tmmConfig.put(new TransactionTypeConfig("0210", "37", TmmConstants.PG_ZVAV_PURCHASE_AAV_RESPONSE), fieldsMap);
    }
    
    @Override
    public MessageContext constructMessage(TransactionMessageModel tmm, String epId, TransactionTypeConfig txnTypeConfig,
                                           MessageTransformationConfig msgTransConfig) {
        return super.constructMessage(tmm, epId, txnTypeConfig, msgTransConfig);
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new PgMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 14;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor sourceProcessor) {
        return new PgMessageConstruction();
    }
}
