package com.isg.mw.mtm.exception;

public class DataAuthenticationException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public DataAuthenticationException(String errorMsg) {
        super(errorMsg);
    }

    public DataAuthenticationException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}
