package com.isg.mw.mtm.config;
/**
 * Decrypt Service
 * 
 *
 */
public interface DecryptService {

	String decrypt(String data);
}
