package com.isg.mw.mtm.construct;

import lombok.Getter;

public final class TrackData {
	private String trackDataValue;
	@Getter
	private String panOrCardNo;
	@Getter
	private String expiryDate;
	@Getter
	private String cvv;

	public TrackData(String trackData) {
		this.trackDataValue = trackData;
		if (this.trackDataValue != null)
			splitData();
	}

	// 0005391699020177742D 2202 2261 000067799999
	// seperator can D or =
	// PAN / Card no = 0005391699020177742
	// expiry date = 2202 (YYMM)
	// CVV = 2261 (if 3 digits left most value be 0)
	private void splitData() {
		String[] trackDataArr = this.trackDataValue.split("D");
		this.panOrCardNo = String.valueOf(Long.parseLong(trackDataArr[0])); // to truncate first zero's
		this.expiryDate = trackDataArr[1].substring(0, 4);
		this.cvv = trackDataArr[1].substring(4, 8);
	}

}