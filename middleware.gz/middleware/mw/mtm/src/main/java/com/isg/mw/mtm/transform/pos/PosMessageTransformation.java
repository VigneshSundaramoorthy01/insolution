package com.isg.mw.mtm.transform.pos;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.pos.MosambeeRegTidRequestModel;
import com.isg.mw.core.model.pos.MosambeeRequestModel;
import com.isg.mw.core.model.pos.MosambeeUpdateStatusRequestModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.pos.PosMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import com.isg.mw.core.model.constants.SourceProcessor;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class PosMessageTransformation extends BaseMessageTransformation {

    private Logger logger = LogManager.getLogger(getClass());
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();
    
    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        /**
         * POS To Switch Purchase Request and Switch To POS Purchase Response
         */
        getPosToSwitchPurchaseRequest(tmmConfig);
        getSwitchToPosPurchaseResponse(tmmConfig);

        getPosToSwitchCashWithdrawalRequest(tmmConfig);
        getSwitchToPosCashWithdrawalResponse(tmmConfig);

        getPosToSwitchCashAtPosRequest(tmmConfig);
        getSwitchToPosCashAtPosResponse(tmmConfig);
        
        getPosToSwitchPurCashAtPosRequest(tmmConfig);
        getSwitchToPosPurCashAtPosResponse(tmmConfig);

        getPosToSwitchPreAuthRequest(tmmConfig);
        getSwitchToPosPreAuthResponse(tmmConfig);

        getPosToSwitchMOTORequest(tmmConfig);
        getSwitchToPosMOTOResponse(tmmConfig);

        // pre-auth/ sale completion request response
        getPosToSwitchPreAuthCompletionRequest(tmmConfig);
        getSwitchToPosPreAuthCompletionResponse(tmmConfig);

        getPosToSwitchBalanceInqRequest(tmmConfig);
        getSwitchToPosBalanceInqResponse(tmmConfig);
        
        getPosToSwitchBalanceInqRupayRequest(tmmConfig);
        getSwitchToPosBalanceInqRupayResponse(tmmConfig);

        getPosToSwitchRefundRequest(tmmConfig);
        getSwitchToPosRefundResponse(tmmConfig);

        // tip-adjust request/response
        getPosToSwitchTipAdjustRequest(tmmConfig);
        getSwitchToPosTipAdjustResponse(tmmConfig);

        // off-line sale request/response

        getPosToSwitchOffLineSaleRequest(tmmConfig);
        getSwitchToPosOffLineSaleResponse(tmmConfig);

        getPosToSwitchVoidOthersRequest(tmmConfig);
        getSwitchToPosVoidOthersResponse(tmmConfig);

        getPosToSwitchVoidRefundRequest(tmmConfig);
        getSwitchToPosVoidRefundResponse(tmmConfig);

        getPosToSwitchReversalRequest(tmmConfig);
        getSwitchToPosReversalResponse(tmmConfig);

        // settlement / settlement after batch upload request/response
        getPosToSwitchDirectSettlementRequest(tmmConfig);
        getSwitchToPosDirectSettlementResponse(tmmConfig);

        getPosToSwitchBatchUploadSettlementRequest(tmmConfig);
        getSwitchToPosBatchUploadSettlementResponse(tmmConfig);

        // batch upload request/response
        getPosToSwitchBatchUploadRequest(tmmConfig);
        getSwitchToPosBatchUploadResponse(tmmConfig);

        // Add money
        
        getPosToSwitchAddMoneyRequest(tmmConfig);
        getSwitchToPosAddMoneyResponse(tmmConfig);
        
        
        // Balance Update
        
        getPosToSwitchBalanceUpdateRequest(tmmConfig);
        getSwitchToPosBalanceUpdateResponse(tmmConfig);
        
        //Service Creation
        getPosToSwitchServiceCreationRequest(tmmConfig);
        getSwitchToPosServiceCreationResponse(tmmConfig);
        
        //DCC Rate LookUp request/response
        getPosToSwitchDccRateLookUpRequest(tmmConfig);
        getSwitchToPosDccRateLookUpResponse(tmmConfig);
        
        /**
         * POS To Switch Signon Request and Switch To POS Signon Response
         */
        getPosToSwitchSignOnRequest(tmmConfig);
        getSwitchToPosSignOnResponse(tmmConfig);

        getPosToSwitchTerminalInitRequest(tmmConfig);
        getSwitchToPosTerminalInitResponse(tmmConfig);

        // For EFTPOS
        getSwithToSchemeFinancialTransactionAdvicePurchaseRequest(tmmConfig);
        getSchemeToSwitchFinancialTransactionAdvicePurchaseResponse(tmmConfig);

        getSwithToSchemeFinancialTransactionRefundRequest(tmmConfig);
        getSchemeToSwitchFinancialTransactionRefundResponse(tmmConfig);

        getSwithToSchemeReversalAdviceRepeatRequest(tmmConfig);

        getPosToSwitchFinancialAdviceCashAtPosRequest(tmmConfig);
        getSwitchToPosFinancialAdviceCashAtPosResponse(tmmConfig);

        getPosToSwitchFinancialAdvicePurCashAtPosRequest(tmmConfig);
        getSwitchToPosFinancialAdvicePurCashAtPosResponse(tmmConfig);

        getPosToSwitchDirectEftposSettlementRequest(tmmConfig);
        getSwitchToPosDirectEftposSettlementResponse(tmmConfig);
        
        getPosToSwitchZvavRequest(tmmConfig);
        getSwitchToPosZvavResponse(tmmConfig);


        return tmmConfig;
    }

    /**
     * @param tmmConfig
     */
    private void getPosToSwitchSignOnRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0800", "99", TmmConstants.POS_SIGNON_REQUEST), fieldsMap);
    }

    // for request
    private void getPosToSwitchPreAuthCompletionRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0220", "40", TmmConstants.PREAUTH_COMPLETION_REQUEST), fieldsMap);

    }

    // for response
    private void getSwitchToPosPreAuthCompletionResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0230", "40", TmmConstants.PREAUTH_COMPLETION_RESPONSE), fieldsMap);
    }

    // for request
    private void getPosToSwitchDirectSettlementRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0500", "92", TmmConstants.DIRECT_SETTLEMENT_REQUEST), fieldsMap);
    }

    private void getPosToSwitchDirectEftposSettlementRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0500", "93", TmmConstants.EFTPOS_SETTLEMENT_REQUEST), fieldsMap);
    }

    // for response
    private void getSwitchToPosDirectSettlementResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
//        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        //fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0510", "92", TmmConstants.DIRECT_SETTLEMENT_RESPONSE), fieldsMap);
    }

    private void getSwitchToPosDirectEftposSettlementResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
//        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        //fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0510", "93", TmmConstants.EFTPOS_SETTLEMENT_RESPONSE), fieldsMap);
    }

    // for request
    private void getPosToSwitchBatchUploadSettlementRequest(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0500", "96", TmmConstants.BATCH_UPLOAD_SETTLEMENT_REQUEST),
                fieldsMap);
    }

    // for response
    private void getSwitchToPosBatchUploadSettlementResponse(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
//        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
       // fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0510", "96", TmmConstants.BATCH_UPLOAD_SETTLEMENT_RESPONSE),
                fieldsMap);
    }

    // for request
    private void getPosToSwitchTipAdjustRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0220", "50", TmmConstants.TIP_ADJUSTMENT_REQUEST), fieldsMap);

    }

    // for response
    private void getSwitchToPosTipAdjustResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        //fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0230", "50", TmmConstants.TIP_ADJUSTMENT_RESPONSE), fieldsMap);

    }

    // for request
    private void getPosToSwitchOffLineSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0220", "00", TmmConstants.OFFLINE_REQUEST), fieldsMap);

    }

    // for response
    private void getSwitchToPosOffLineSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(55, TmmConstants.ICC_DATA);
//		fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0230", "00", TmmConstants.OFFLINE_RESPONSE), fieldsMap);
    }

    // for request
    private void getPosToSwitchBatchUploadRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0320", null, TmmConstants.BATCH_UPLOAD_REQUEST), fieldsMap);
    }

    // for response
    private void getSwitchToPosBatchUploadResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
//		fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
//		fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0330", null, TmmConstants.BATCH_UPLOAD_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToPosSignOnResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        tmmConfig.put(new TransactionTypeConfig("0810", "99", TmmConstants.POS_SIGNON_RESPONSE), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getPosToSwitchPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "00", TmmConstants.PURCHASE_REQUEST), fieldsMap);

    }

    private void getSwitchToPosPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "00", TmmConstants.PURCHASE_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getPosToSwitchCashWithdrawalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "01", TmmConstants.CASHWITHDRAWAL_REQUEST), fieldsMap);

    }

    private void getSwitchToPosCashWithdrawalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "01", TmmConstants.CASHWITHDRAWAL_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "09", TmmConstants.CASHATPOS_REQUEST), fieldsMap);
    }

    private void getSwitchToPosCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "09", TmmConstants.CASHATPOS_RESPONSE), fieldsMap);
    }
    
    private void getPosToSwitchPurCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "09", TmmConstants.PURCHASE_CASHATPOS_REQUEST), fieldsMap);
    }

    private void getSwitchToPosPurCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "09", TmmConstants.PURCHASE_CASHATPOS_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchMOTORequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "51", TmmConstants.MOTO_REQUEST), fieldsMap);
    }

    private void getSwitchToPosMOTOResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "51", TmmConstants.MOTO_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchBalanceInqRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);

        tmmConfig.put(new TransactionTypeConfig("0100", "30", TmmConstants.BALANCE_INQUIRY_REQUEST), fieldsMap);
    }

    private void getSwitchToPosBalanceInqResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38, TmmConstants.AUTH_ID_RES); //optional field
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA); //optional field
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0110", "30", TmmConstants.BALANCE_INQUIRY_RESPONSE), fieldsMap);
    }
    
    
    
    private void getPosToSwitchBalanceInqRupayRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);

        tmmConfig.put(new TransactionTypeConfig("0100", "31", TmmConstants.RUPAY_BALANCE_INQUIRY_REQUEST), fieldsMap);
    }

    private void getSwitchToPosBalanceInqRupayResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38, TmmConstants.AUTH_ID_RES); //optional field
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA); //optional field
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0110", "31", TmmConstants.RUPAY_BALANCE_INQUIRY_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PREAUTH_REQUEST), fieldsMap);
    }

    private void getSwitchToPosPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PREAUTH_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "20", TmmConstants.REFUND_REQUEST), fieldsMap);
    }

    private void getSwitchToPosRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);//optional field
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "20", TmmConstants.REFUND_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.REVERSAL_REQUEST), fieldsMap);
    }

    private void getSwitchToPosReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38, TmmConstants.AUTH_ID_RES);//optional field
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.REVERSAL_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchVoidOthersRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0220", "02", TmmConstants.VOID_OTHERS_REQUEST), fieldsMap);
    }

    private void getSwitchToPosVoidOthersResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0230", "02", TmmConstants.VOID_OTHERS_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchVoidRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0220", "22", TmmConstants.VOID_REFUND_REQUEST), fieldsMap);
    }

    private void getSwitchToPosVoidRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0230", "22", TmmConstants.VOID_REFUND_RESPONSE), fieldsMap);
    }

    
    private void getPosToSwitchAddMoneyRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

    	tmmConfig.put(new TransactionTypeConfig("0200", "28", TmmConstants.ADD_MONEY_REQUEST), fieldsMap);
    }

    private void getSwitchToPosAddMoneyResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
    	
    	tmmConfig.put(new TransactionTypeConfig("0210", "28", TmmConstants.ADD_MONEY_RESPONSE), fieldsMap);
    }


    private void getPosToSwitchBalanceUpdateRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

    	tmmConfig.put(new TransactionTypeConfig("0200", "29", TmmConstants.BALANCE_UPDATE_REQUEST), fieldsMap);
    }

    private void getSwitchToPosBalanceUpdateResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

    	tmmConfig.put(new TransactionTypeConfig("0210", "29", TmmConstants.BALANCE_UPDATE_RESPONSE), fieldsMap);

    }


    /**
     * @param tmmConfig
     */
    private void getSwithToSchemeFinancialTransactionAdvicePurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES); // DE 38 for future use
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0220", "00", TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_REQUEST), fieldsMap);

    }

    private void getSwithToSchemeReversalAdviceRepeatRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0221", "00", TmmConstants.EFTPOS_REPEAT_ADVICE_REQUEST), fieldsMap);

    }

    private void getSchemeToSwitchFinancialTransactionAdvicePurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0230", "00", TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_RESPONSE), fieldsMap);
    }



    private void getPosToSwitchFinancialAdviceCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0220", "01", TmmConstants.EFTPOS_FINANCIAL_ADVICE_CASHATPOS_REQUEST), fieldsMap);
    }

    private void getSwitchToPosFinancialAdviceCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0230", "01", TmmConstants.EFTPOS_FINANCIAL_ADVICE_CASHATPOS_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchFinancialAdvicePurCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0220", "09", TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_REQUEST), fieldsMap);
    }

    private void getSwitchToPosFinancialAdvicePurCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        //fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0230", "09", TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_RESPONSE), fieldsMap);
    }

    // For EFTPOS
    private void  getSwithToSchemeFinancialTransactionRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0220", "20", TmmConstants.EFTPOS_FINANCIAL_REFUND_REQUEST), fieldsMap);
    }

    private void  getSchemeToSwitchFinancialTransactionRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);//optional field
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0230", "20", TmmConstants.EFTPOS_FINANCIAL_REFUND_RESPONSE), fieldsMap);
    }
    
    
    private void getPosToSwitchServiceCreationRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        //fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

    	tmmConfig.put(new TransactionTypeConfig("0200", "83", TmmConstants.SERVICE_CREATION_REQUEST), fieldsMap);
    }

    private void getSwitchToPosServiceCreationResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

    	tmmConfig.put(new TransactionTypeConfig("0210", "83", TmmConstants.SERVICE_CREATION_RESPONSE), fieldsMap);

    }
    
    private void getPosToSwitchDccRateLookUpRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0600", "00", TmmConstants.DCC_RATE_LOOKUP_REQUEST), fieldsMap);

    }

    private void getSwitchToPosDccRateLookUpResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0610", "00", TmmConstants.DCC_RATE_LOOKUP_RESPONSE), fieldsMap);
    }
    
    /**
     * @param tmmConfig
     */
    private void getPosToSwitchZvavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0200", "33", TmmConstants.ZVAV_REQUEST), fieldsMap);

    }

    private void getSwitchToPosZvavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0210", "33", TmmConstants.ZVAV_RESPONSE), fieldsMap);
    }

    private void getPosToSwitchTerminalInitRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0800", "01", TmmConstants.POS_TERMINAL_INIT_REQUEST), fieldsMap);
    }
    
    private void getSwitchToPosTerminalInitResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0810", "01", TmmConstants.POS_TERMINAL_INIT_RESPONSE), fieldsMap);

    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel tmm, String epId, TransactionTypeConfig txnTypeConfig,
                                           MessageTransformationConfig msgTransConfig) {
        MessageContext msgContext = super.constructMessage(tmm, epId, txnTypeConfig, msgTransConfig);

        if (msgContext.getRawMsg() instanceof ISOMsg) {
            ISOMsg isoMsg = (ISOMsg) msgContext.getRawMsg();
            byte[] rawMsgWithBodyHeader;
            try {
                boolean isSignOnResponse = MessageConstructionHelper.isSignOnResponse(msgContext.getEpMsgType());
                rawMsgWithBodyHeader = buildHeader(isoMsg, isSignOnResponse);
                /*logger.trace("MTI: {}, Is Sign On Response: {}", msgContext.getEpMsgType(), isSignOnResponse);
                if (isSignOnResponse) {
                    String ipek = msgContext.getTransactionMessageModel().getPostalCode();
                    int dataLength = ipek.length() / 2;
                    byte[] ipekBytes = MtmUtil.toBytesAsIs(String.format("%04d", dataLength) + ipek);
                    byte[] tmp = new byte[rawMsgWithBodyHeader.length + ipekBytes.length];
                    System.arraycopy(rawMsgWithBodyHeader, 0, tmp, 0, rawMsgWithBodyHeader.length);
                    System.arraycopy(ipekBytes, 0, tmp, rawMsgWithBodyHeader.length, ipekBytes.length);
                    rawMsgWithBodyHeader = tmp;
                }*/

                byte[] bcdRawMsgWithBodyHeader = buildBcdMessage(rawMsgWithBodyHeader);
                msgContext.setRawMsg(bcdRawMsgWithBodyHeader);

                String encryptedRawMsg = TxnLogger.encryptRawMsg(bcdRawMsgWithBodyHeader);
                if (tmm.getTlmMessageType() != null && tmm.getTlmMessageType().equals(TlmMessageType.REQUEST)) {
                    msgContext.getTransactionMessageModel().setRawRequest(encryptedRawMsg);
                } else if (tmm.getTlmMessageType() != null && tmm.getTlmMessageType().equals(TlmMessageType.RESPONSE)) {
                    msgContext.getTransactionMessageModel().setRawResponse(encryptedRawMsg);
                }
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(tmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        tmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(tmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        tmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return msgContext;
    }

    private byte[] buildHeader(ISOMsg isoMsg, boolean isSignOnResponse) throws ISOException {
        byte[] bodyBytes = isoMsg.pack();
        if (isSignOnResponse) {
            byte[] bodyBytesNo62 = new byte[bodyBytes.length - 2];
            System.arraycopy(bodyBytes, 0, bodyBytesNo62, 0, bodyBytes.length - 2);
            bodyBytes = bodyBytesNo62;
        }
        return buildHeader(bodyBytes);
    }

    private byte[] buildHeader(byte[] bodyBytes) {
        byte[] rawMsgWithBodyHeader = null;
        byte[] headerBytes = MtmUtil.toBytesAsIs("6000560000");

        rawMsgWithBodyHeader = new byte[bodyBytes.length + headerBytes.length];

        System.arraycopy(headerBytes, 0, rawMsgWithBodyHeader, 0, headerBytes.length);
        System.arraycopy(bodyBytes, 0, rawMsgWithBodyHeader, headerBytes.length, bodyBytes.length);

        return rawMsgWithBodyHeader;
    }

    private byte[] buildBcdMessage(final byte[] bcdRawMsgWithBodyHeader) {
        int intsize2 = bcdRawMsgWithBodyHeader.length / 256;
        int intsize3 = bcdRawMsgWithBodyHeader.length % 256;
        String lenStr = String.format("%c%c", intsize2, intsize3);
        //This change is made for the Offline sale and Pre Auth Completion transaction for the delayed response at the terminal.
        /*The array generated by lenStr.getBytes() is size 3 for the packet length of 192.
        But it should return array of size 2 as lenStr.getBytes(StandardCharsets.ISO_8859_1)
        does.*/
        /*
		 * byte[] size1 = lenStr.getBytes();
		  *byte[] size2 = lenStr.getBytes(StandardCharsets.ISO_8859_1);
		 * for (byte b : size1)
    		System.out.println("lenStr.getBytes() output: "+b);
        
		  *for (byte b : size2)
    		System.out.println("lenStr.getBytes(StandardCharsets.ISO_8859_1): "+b);
    		
            The output of the above program is given below:
			Byte array values:

			lenStr.getBytes() --> [0, -61, -128]
			lenStr.getBytes(StandardCharsets.ISO_8859_1) --> [0, -64]
			
			Output of the code:

            lenStr.getBytes() output: 0
            lenStr.getBytes() output: -61
            lenStr.getBytes() output: -128
            lenStr.getBytes(StandardCharsets.ISO_8859_1): 0
            lenStr.getBytes(StandardCharsets.ISO_8859_1): -64

         */
        byte[] size1 = lenStr.getBytes(StandardCharsets.ISO_8859_1);
        logger.trace("size1: ");
        for (byte b : size1)
            logger.trace(b);
        int lengthOfTotalMsgLength = 2;
        byte[] msgLengthHeaderBytes = new byte[lengthOfTotalMsgLength];
        msgLengthHeaderBytes[0] = size1[0];
        msgLengthHeaderBytes[1] = size1[1];

        byte[] finalBcdMsgArr = new byte[msgLengthHeaderBytes.length + bcdRawMsgWithBodyHeader.length];
        System.arraycopy(msgLengthHeaderBytes, 0, finalBcdMsgArr, 0, msgLengthHeaderBytes.length);

        System.arraycopy(bcdRawMsgWithBodyHeader, 0, finalBcdMsgArr, msgLengthHeaderBytes.length,
                bcdRawMsgWithBodyHeader.length);
        return finalBcdMsgArr;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new PosMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 14;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor sourceProcessor) {
        return new PosMessageConstruction();
    }

}
