package com.isg.mw.mtm.transform.bqr;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.bqr.BqrMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;

public class BqrMessageTransformation extends BaseMessageTransformation {


	private final Logger logger = LogManager.getLogger(getClass());
	private static final Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

	@Override
	public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

		if (!tmmConfig.isEmpty()) {
			return tmmConfig;
		}

		/**
		 * BQR To MM Purchase Notifiction Request
		 */
		getSwitchtoBqrNotifyRequest(tmmConfig);

		getBqrToSwitchRefundRequest(tmmConfig);
		getSwitchToBqrRefundResponse(tmmConfig);

		getBqrToSwitchReversalRequest(tmmConfig);
		getSwitchToBqrReversalResponse(tmmConfig);

		getBqrToSwitchSignOnRequest(tmmConfig);
		getSwitchToBqrSignOnResponse(tmmConfig);

		return tmmConfig;
	}


	private void getBqrToSwitchSignOnRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.BITMAP);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(24, TmmConstants.NIIID);
		fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(62, TmmConstants.POSTAL_CODE);
		fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

		tmmConfig.put(new TransactionTypeConfig("0800", null, TmmConstants.BQR_SIGNON_REQUEST), fieldsMap);

	}


	private void getSwitchToBqrSignOnResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.BITMAP);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(39, TmmConstants.RES_CODE);
		fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
		fieldsMap.put(62, TmmConstants.POSTAL_CODE);

		tmmConfig.put(new TransactionTypeConfig("0810", null, TmmConstants.BQR_SIGNON_RESPONSE), fieldsMap);

	}


	/**
	 * @param tmmConfig
	 */
	private void getSwitchtoBqrNotifyRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.BITMAP);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(4, TmmConstants.PAN);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(7,TmmConstants.TRANSMISSION_TIME);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);   //Approval code
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(29, TmmConstants.SWITCH_TRANSACTION_ID);
		fieldsMap.put(31, TmmConstants.CUSTOMER_PAN);
		fieldsMap.put(32, TmmConstants.CUSTOMER_NAME);
		fieldsMap.put(35, TmmConstants.POSTAL_CODE);  //purchaseidentifier


		tmmConfig.put(new TransactionTypeConfig("0110", "80", TmmConstants.BQR_NOTIFY_REQUEST), fieldsMap);

	}

	/**
	 * @param tmmConfig
	 */

	private void getBqrToSwitchRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(4, TmmConstants.PAN);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);                           //Approval code
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(29, TmmConstants.SWITCH_TRANSACTION_ID);
		fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);               //Aggregator Reference Number

		tmmConfig.put(new TransactionTypeConfig("0210", "04", TmmConstants.BQR_REFUND_REQUEST), fieldsMap);
	}

	private void getSwitchToBqrRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(4, TmmConstants.PAN);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(29, TmmConstants.SWITCH_TRANSACTION_ID);
		fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);

		tmmConfig.put(new TransactionTypeConfig("0220", "04", TmmConstants.BQR_REFUND_RESPONSE), fieldsMap);
	}

	private void getBqrToSwitchReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.BITMAP);
		fieldsMap.put(2, TmmConstants.PAN);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(4, TmmConstants.TXN_AMT);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
		fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(24, TmmConstants.NIIID);
		fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
		fieldsMap.put(39, TmmConstants.RES_CODE);
		fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
		fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
		fieldsMap.put(55, TmmConstants.ICC_DATA);
		fieldsMap.put(61, TmmConstants.CIAD);
		fieldsMap.put(62, TmmConstants.POSTAL_CODE);
		fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

		tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.BQR_REVERSAL_REQUEST), fieldsMap);
	}

	private void getSwitchToBqrReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.BITMAP);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		//fieldsMap.put(4, TmmConstants.TXN_AMT);//optional field
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(24, TmmConstants.NIIID);
		fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
		//fieldsMap.put(38, TmmConstants.AUTH_ID_RES);//optional field
		fieldsMap.put(39, TmmConstants.RES_CODE);
		fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(55, TmmConstants.ICC_DATA);
		fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

		tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.BQR_REVERSAL_RESPONSE), fieldsMap);
	}



	@Override
	public MessageContext constructMessage(TransactionMessageModel tmm, String epId, TransactionTypeConfig txnTypeConfig,
										   MessageTransformationConfig msgTransConfig) {

		return super.constructMessage(tmm, epId, txnTypeConfig, msgTransConfig);
	}


	@Override
	public SwitchBaseMessageConstruction getMessageConstruction() {
		return new BqrMessageConstruction();
	}

	@Override
	public int getDefaultHeaderLength() {
		return 14;
	}

	@Override
	public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor sourceProcessor) {
		return new BqrMessageConstruction();
	}

}