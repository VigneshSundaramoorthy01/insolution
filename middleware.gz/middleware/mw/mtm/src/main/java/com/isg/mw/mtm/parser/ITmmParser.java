/**
 * 
 */
package com.isg.mw.mtm.parser;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.parser.msg.MwMessage;

/**
 * @author prasad_t026
 *
 */
public interface ITmmParser {

	TransactionMessageModel parse(MwMessage s, String entityId, String epId, String srcTxnName);
}