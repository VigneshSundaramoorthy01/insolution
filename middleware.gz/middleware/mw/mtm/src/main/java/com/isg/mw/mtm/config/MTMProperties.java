package com.isg.mw.mtm.config;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.Setter;

@Configuration
@Setter
@Getter
@PropertySource("${spring.config.location}appconfig.properties")
public class MTMProperties {

	@Value("${resource.path}")
	private String path;

	private static ResourceBundle messagesBundle;

	@PostConstruct
	public void postConstruct() throws MalformedURLException {
		File file = new File(path);
		URL[] urls = { file.toURI().toURL() };
		ClassLoader loader = new URLClassLoader(urls);
		if (!(path.isEmpty()) || path != null) {
			MTMProperties.messagesBundle = ResourceBundle.getBundle("mtm-config", new Locale("en"), loader);
		} else {
			MTMProperties.messagesBundle = ResourceBundle.getBundle("mtm-config", new Locale("en"));
		}
	}

	public static String getProperty(String msgKey) {
		String msg = null;
		try {
			msg = (String) messagesBundle.getObject(msgKey);
		} catch (NullPointerException | MissingResourceException ex) {
			msg = "Unknown message";
		}
		return msg;
	}
}
