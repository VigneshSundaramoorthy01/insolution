package com.isg.mw.mtm.construct.mastercard;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isMasterCardEchoResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isMasterCardSchemeInitiatedDynamicKeyExchange;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isMasterCardSigOnResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isMasterCardSignOffResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isSignOnRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isSignOnResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isBqrPurchase;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.exception.InvalidTxnException;
import com.isg.mw.mtm.exception.MessageConstructionException;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import com.isg.mw.mtm.util.TlvAns;

public class BqrMasterCardMessageConstruction extends MasterCardMessageConstruction {
	/**
	 * 1.<br>
	 * ISO8583 -1987, AS2805 - Secondary bitmap <br>
	 * Base24, ISG, XML - Bit map
	 */


	/**
	 * 2.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
	 * Account Number
	 */
	@Override
	public void setPan(int fieldNo) {
		String pan = this.sourceTmm.getPan();

		if (isMasterCardEchoResponse(this.sourceTmm)) {
			pan = this.sourceTmm.getPan();
		} else if (isSignOnRequest(this.sourceMsgType)) {
			// TODO: take group sign on id from endpoint configuration (Config Mgmt: Issue #94 point 2)
			pan = MTMProperties.getProperty("target.master.group.signon.id");
		}

		this.targetTmm.setPan(pan);
		this.baseMessage.set(fieldNo, pan);
	}

	/**
	 * 3. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
	 * <br>
	 * mPOS - Transaction Type
	 */
	@Override
	public void setProcessingCode(int fieldNo) {
		this.targetTmm.setProcessingCode(this.targetMsgTypeId);
		this.baseMessage.set(fieldNo, this.targetMsgTypeId);
	}


	/**
	 * 4. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
	 * CyberSource API - AuthorizedAmount
	 * <p>
	 * It is mandatory for all type of transactions
	 */
	@Override
	public void setTxnAmt(int fieldNo) {
		String txnAmt = this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0";
		txnAmt = StringUtils.leftPad(txnAmt, 4, "0");
		this.targetTmm.setTxnAmt(txnAmt);
		this.baseMessage.set(fieldNo, txnAmt);
	}

	/**
	 * 5.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
	 */
	@Override
	public void setSettlementAmt(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
	}

	/**
	 * 6.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
	 */
	@Override
	public void setCardHolderBillingAmt(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
		String cardHolderBillingAmt = sourceTmm.getCardHolderBillingAmt();
		this.targetTmm.setCardHolderBillingAmt(cardHolderBillingAmt);
		this.baseMessage.set(fieldNo, cardHolderBillingAmt);
	}

	/**
	 * 7. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setTransmissionTime(int fieldNo) {
		String formattedDate = null;
		if (isMasterCardSchemeInitiatedDynamicKeyExchange(sourceTmm) || isMasterCardEchoResponse(this.sourceTmm)
				|| isMasterCardSigOnResponse(sourceTmm) || isMasterCardSignOffResponse(sourceTmm)) {
			formattedDate = sourceTmm.getTransmissionTime();
		} else {
			formattedDate = MtmUtil.formatDate("MMddhhmmss", ZoneOffset.UTC);
		}
		this.targetTmm.setTransmissionTime(formattedDate);
		this.baseMessage.set(fieldNo, formattedDate);
	}

	/**
	 * 8. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
	 */


	/**
	 * 9. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
	 */
	@Override
	public void setSettlementConversionRate(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
	}

	/**
	 * 10. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
	 */
	@Override
	public void setCardHolderBillingConversionRate(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
		String cardHolderBillingConversionRate = sourceTmm.getCardHolderBillingConversionRate();
		this.targetTmm.setCardHolderBillingConversionRate(cardHolderBillingConversionRate);
		this.baseMessage.set(fieldNo, cardHolderBillingConversionRate);
	}


	/**
	 * 11. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
	 * <br>
	 * CyberSource API - T id
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setStan(int fieldNo) {
		if (isMasterCardSchemeInitiatedDynamicKeyExchange(sourceTmm) || isMasterCardEchoResponse(sourceTmm)
				|| isMasterCardSigOnResponse(sourceTmm) || isMasterCardSignOffResponse(sourceTmm) 
				|| isBqrPurchase(this.sourceTmm.getMsgType(), this.sourceTmm.getProcessingCode())) {
			String stan = sourceTmm.getStan();
			this.targetTmm.setExpirationDate(stan);
			this.targetTmm.setSchemeStan(stan);
			this.baseMessage.set(fieldNo, stan);
		} else {
			super.setStan(fieldNo);
			this.targetTmm.setSchemeStan(this.targetTmm.getStan());
		}

	}

	/**
	 * 12. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
	 * CyberSource API - Transaction Local Date Time
	 */
	@Override
	public void setLocalTxnTime(int fieldNo) {
		String localTxnTime = MtmUtil.formatDate("HHmmss");
		this.targetTmm.setLocalTxnTime(localTxnTime);
		this.baseMessage.set(fieldNo, localTxnTime);
	}

	/**
	 * 13. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
	 */
	@Override
	public void setLocalTxnDate(int fieldNo) {
		String localTxnDate = MtmUtil.formatDate("MMdd");
		this.targetTmm.setLocalTxnDate(localTxnDate);
		this.baseMessage.set(fieldNo, localTxnDate);
	}


	/**
	 * 14. <br>
	 * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
	 * Date
	 */


	/**
	 * 15. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
	 */
	@Override
	public void setSettlementDate(int fieldNo) {
		String settlementDate = sourceTmm.getSettlementDate();
		this.targetTmm.setSettlementDate(settlementDate);
		this.baseMessage.set(fieldNo, settlementDate);

	}

	/**
	 * 16. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
	 */
	@Override
	public void setConversionDate(int fieldNo) {
		String conversionDate = sourceTmm.getConversionDate();
		this.targetTmm.setConversionDate(conversionDate);
		this.baseMessage.set(fieldNo, conversionDate);
	}


	/**
	 * 17. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
	 */


	/**
	 * 18.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
	 * ISO8583 -1987, CyberSource API - Category Code
	 */
	/* It is mandatory for all type of transactions */
	/*
	 * In Marstercard's Cashwithdrawal transaction there has to be a check for the merchant type field.
	 * If the target is Mastercard and the transaction is Cashwithdrawal then check for the value of merchant type field.
	 * And If the value of the field merchantType is '6010' then proceed forward.
	 * Else it is a invalid transaction, so rescode '12' has to be send in this case.
	 * For that InvalidTxnException is thrown from here.
	 */
	@Override
	public void setMerchantType(int fieldNo) {
		String merchantType = this.merchantData.getMerchantType();

		if (MessageConstructionHelper.isCashWithdrawal(this.sourceMsgType, this.sourceMsgTypeId)
				&& (!MtmConstants.MC_MERCHANT_TYPE.equals(merchantType))) {
			throw new InvalidTxnException("MerchantType " + merchantType + " is invalid.");
		}
		this.targetTmm.setMerchantType(merchantType);
		this.baseMessage.set(fieldNo, merchantType);
	}


	/**
	 * 19. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
	 * Country Code <br>
	 * mPOS - terminalCountryCode
	 */


	/**
	 * 20. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
	 * code
	 */

	/**
	 * 21. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
	 */


	/**
	 * 22. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
	 * Entry Mode <br>
	 * mPOS - NFC Enabled
	 * <p>
	 * It is mandatory for all type of transactions
	 */
	@Override
	public void setPosEntryMode(int fieldNo) {
		String posEntryMode = this.sourceTmm.getPosEntryMode();
		if (this.sourceTmm.getNiiId().equals(TmmConstants.MPOS_TXN)) {
			posEntryMode = "072";
			this.targetTmm.setPosEntryMode(posEntryMode);
			this.baseMessage.set(fieldNo, posEntryMode);
		} else if (MtmUtil.getPOS_ENTRY_MODE_DATA().contains(posEntryMode)) {
			if (posEntryMode.equals("021") || posEntryMode.equals("901")) {
				posEntryMode = "901";
			}
			this.targetTmm.setPosEntryMode(posEntryMode);
			this.baseMessage.set(fieldNo, posEntryMode);
		} else {
			throw new MessageConstructionException(
					"Could not validate POS Entry Mode against master data available");
		}
	}

	/**
	 * 23. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
	 */


	/**
	 * 24. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
	 * CyberSource API - Type
	 */


	/**
	 * 25. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
	 */


	/**
	 * 26. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
	 */


	/**
	 * 27. <br>
	 * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
	 * length
	 */


	/**
	 * 28. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
	 */


	/**
	 * 29. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
	 */


	/**
	 * 30. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
	 */


	/**
	 * 31.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
	 *
	 */


	/**
	 * 32. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
	 * Code
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setAquirerIdCode(int fieldNo) {
		String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
		this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
		this.baseMessage.set(fieldNo, acquirerInstitutionId);
	}


	/**
	 * 33.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
	 * Code
	 */
	@Override
	public void setForwardingInstIdCode(int fieldNo) {
		String forwardingInstitutionId = null;
		if (isSignOnRequest(this.sourceMsgType)) {
			if (isMasterCardSchemeInitiatedDynamicKeyExchange(sourceTmm) || isMasterCardEchoResponse(sourceTmm)
					|| isMasterCardSigOnResponse(sourceTmm) || isMasterCardSignOffResponse(sourceTmm)) {
				forwardingInstitutionId = sourceTmm.getForwardingInstIdCode();
			} else {
				forwardingInstitutionId = sourceTmm.getForwardingInstIdCode() == null ?
						MTMProperties.getProperty("target.master.forwarding.inst.id") :
							StringUtils.leftPad(sourceTmm.getForwardingInstIdCode(), 6, '0');
			}
		} else {
			forwardingInstitutionId = StringUtils.leftPad(sourceTmm.getForwardingInstIdCode(), 6, '0');
		}
		this.targetTmm.setForwardingInstIdCode(forwardingInstitutionId);
		this.baseMessage.set(fieldNo, forwardingInstitutionId);
	}

	/**
	 * 34.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
	 */

	/**
	 * 35.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
	 *
	 */


	/**
	 * 36.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
	 */


	/**
	 * 37.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
	 * Number<br>
	 * CyberSource API - TransactionId
	 */
	@Override
	public void setRetrievalRefNo(int fieldNo) {
		if (isMasterCardEchoResponse(this.sourceTmm)
				|| isBqrPurchase(this.sourceTmm.getMsgType(), this.sourceTmm.getProcessingCode())) {
			String rrnNumber = this.sourceTmm.getRetrievalRefNo();

			this.targetTmm.setRetrievalRefNo(rrnNumber);
			this.baseMessage.set(fieldNo, rrnNumber.getBytes());
		} else {
			super.setRetrievalRefNo(fieldNo);
		}
	}


	/**
	 * 38.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
	 * Response<br>
	 * mPOS - AuthCode
	 */
	@Override
	public void setAuthIdRes(int fieldNo) {
		String authIdRes = sourceTmm.getTransactionId();
		
		authIdRes = sourceTmm.getTransactionId().substring(authIdRes.length()-6, authIdRes.length());
		
		this.targetTmm.setAuthIdRes(authIdRes);
		this.baseMessage.set(fieldNo, authIdRes.getBytes());
	}

	/**
	 * 39.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
	 * mPOS - Status Code
	 */
	@Override
	public void setResCode(int fieldNo) {
		String resCode = this.sourceTmm.getResCode();
		this.targetTmm.setResCode(resCode);
		this.baseMessage.set(fieldNo, resCode.getBytes());
	}


	/**
	 * 40.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
	 */


	/**
	 * 41.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
	 * Identification
	 */
	@Override
	public void setCardAcceptorTerminalId(int fieldNo) {
		String cardAcceptorTermId = this.sourceTmm.getCardAcceptorTerminalId();
		if (cardAcceptorTermId != null) {
			this.targetTmm.setCardAcceptorTerminalId(cardAcceptorTermId);
			this.baseMessage.set(fieldNo, cardAcceptorTermId.getBytes());
		}
	}

	/**
	 * 42. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
	 * Identification code<br>
	 * mPOS - TxnId
	 */
	@Override
	public void setCardAcceptorId(int fieldNo) {
		String cardAcceptorId = this.sourceTmm.getCardAcceptorId();
		this.targetTmm.setCardAcceptorId(cardAcceptorId);
		this.baseMessage.set(fieldNo, cardAcceptorId.getBytes());
	}

	/**
	 * 43.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
	 * Name/Location
	 * <p>
	 * Logic:<br>
	 * Switch has to extract it from Merchant / POS Master table and send it to
	 * Scheme. card acceptor name (1-22),<br>
	 * space(23),<br>
	 * city name (24-36),<br>
	 * space(37),<br>
	 * Country code (38-40)
	 */
	@Override
	public void setCardAcceptorInfo(int fieldNo) {
		String cardAcceptorInfo = null;
		String cardAcceptorName = null;

		if (this.merchantData.getAggregatorFlag().equals("Y")) {
			cardAcceptorName = this.merchantData.getPaymentFacilitatorName() + "*" + this.merchantData.getMerchantName();
		} else {
			cardAcceptorName = this.merchantData.getMerchantName();
		}
		String merchantCity = StringUtils.rightPad(this.merchantData.getMerchantCity(), 14);
		String merchantCountryCode = StringUtils.rightPad(this.merchantData.getMerchantCountryCode(), 3);
		String cardAccName = StringUtils.rightPad(cardAcceptorName, 23);
		cardAcceptorInfo = cardAccName.substring(0, 23) + merchantCity.substring(0, 14) + merchantCountryCode.substring(0, 3);
		this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
		this.baseMessage.set(fieldNo, cardAcceptorInfo);
	}

	/**
	 * 44.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
	 */


	/**
	 * 45.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
	 */


	/**
	 * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
	 */


	/**
	 * 47.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Data National
	 */


	/**
	 * 48.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setPrivateAd(int fieldNo) {
		String privateAd = null;
		logger.trace("Src Tmm Category : {}", sourceTmm.getTransactionCategory());

		if (TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) || TmmConstants.RES_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType())) {
			if (isSignOnResponse(sourceTmm.getMsgType()) && isMasterCardSchemeInitiatedDynamicKeyExchange(sourceTmm)) {
				privateAd = sourceTmm.getPrivateAd();
			}
		} else {
			privateAd = buildVRPrivateAd();
		}

		this.targetTmm.setPrivateAd(privateAd);
		this.baseMessage.set(fieldNo, privateAd);
	}

	private String buildVRPrivateAd() {
		List<TlvAns> f48 = new ArrayList<>();
		String tcc = this.merchantData.getTerminalCategoryCode();
		if (this.merchantData.getAggregatorFlag().equals("Y")) {
			StringBuilder subField37Value = new StringBuilder();
			subField37Value.append("01");
			subField37Value.append(this.merchantData.getPaymentFacilitatorId().length());
			subField37Value.append(this.merchantData.getPaymentFacilitatorId());
			subField37Value.append("02");
			subField37Value.append(this.merchantData.getIndependentSaleOrganizationId().length());
			subField37Value.append(this.merchantData.getIndependentSaleOrganizationId());
			subField37Value.append("03");
			subField37Value.append(this.merchantData.getMid().length());
			subField37Value.append(this.merchantData.getMid());
			f48.add(new TlvAns("37", subField37Value.toString()));
		}
		String subField48Value = "00001";
		f48.add(new TlvAns("61", subField48Value));
		f48.add(new TlvAns("65", "22"));
		return tcc + TlvAns.getBytes(f48);
	}

	/**
	 * 49.<br>
	 * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
	 * Code
	 */
	@Override
	public void setTxnCurrencyCode(int fieldNo) {
		String merchantCurrencyCode = this.sourceTmm.getTxnCurrencyCode() != null ? this.sourceTmm.getTxnCurrencyCode()
				: this.merchantData.getAcquirerCurrencyCode();
		this.targetTmm.setTxnCurrencyCode(merchantCurrencyCode);
		this.baseMessage.set(fieldNo, merchantCurrencyCode);
	}

	/**
	 * 50.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
	 */


	/**
	 * 51.<br>
	 * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
	 */
	@Override
	public void setCardHolderBillingCurrencyCode(int fieldNo) {
		String merchantCurrencyCode = this.sourceTmm.getCardHolderBillingCurrencyCode() != null ? this.sourceTmm.getCardHolderBillingCurrencyCode()
				: this.merchantData.getAcquirerCurrencyCode();
		this.targetTmm.setCardHolderBillingCurrencyCode(merchantCurrencyCode);
		this.baseMessage.set(fieldNo, merchantCurrencyCode);
	}


	/**
	 * 52.<br>
	 * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
	 * (PIN) Data<br>
	 * CyberSource API - Encrypted Pin
	 */


	/**
	 * 53.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
	 * Information<br>
	 * CyberSource API - Encrypted Key Serial Number
	 */


	/**
	 * 54.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
	 */

	/**
	 * 55.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
	 * Base24 - ISO Reserved<br>
	 * CyberSource API- EMV
	 */
	@Override
	public void setIccData(int fieldNo) {

	}


	/**
	 * 56.<br>
	 * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
	 */


	/**
	 * 57.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Amount cash
	 */


	/**
	 * 58.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Ledger balance
	 */


	/**
	 * 59.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Account balance, Cleared funds
	 */


	/**
	 * 60.<br>
	 * ISO8583-1987 - Reserved for national use<br>
	 * AS2805,ISG, XML - Reserved private<br>
	 * Base24 - Terminal Data
	 */


	/**
	 * 61.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
	 * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
	 * Data
	 * <p>
	 * Other transactions: 0000000000800356POSTAL<br>
	 * PreAuth: 0000004000800356POSTAL<br>
	 * MOTO: 2032102000800356POSTAL<br>
	 * POSTAL means-- 6 digit postal code of merchant.<br>
	 * <p>
	 * Note: It is mandatory for all type of transactions
	 */
	@Override
	public void setCiad(int fieldNo) {
		final String merchantZipCode = this.merchantData.getMerchantZipCode();
		String ciad = "0000000000300356";
		ciad += merchantZipCode;
		this.targetTmm.setCiad(ciad);
		this.baseMessage.set(fieldNo, ciad);
	}

	/**
	 * 62.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - Postal Code
	 */

	/**
	 * 63.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - ATM PIN Offset POS Additional Data
	 */
	@Override
	public void setAtmPinOffsetData(int fieldNo) {
		String atmPinOffsetData = sourceTmm.getAtmPinOffsetData();

		this.targetTmm.setAtmPinOffsetData(atmPinOffsetData);
		this.baseMessage.set(fieldNo, atmPinOffsetData);
	}

	/**
	 * 64.<br>
	 * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
	 * Base24 -Primary Message Authentication Code
	 */


	/**
	 * 65.<br>
	 * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
	 * Base24 -Reserved for ISO use
	 */


	/**
	 * 66.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Code
	 */


	/**
	 * 67.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Extended payment code
	 */


	/**
	 * 68.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
	 * mPOS - Transaction Country Code
	 */


	/**
	 * 69.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
	 *
	 */


	/**
	 * 70.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
	 */
	@Override
	public void setNetworkMgmtInfoCode(int fieldNo) {
		String networkMgmtInfoCode = null;
		if (isSignOnRequest(this.sourceMsgType)) {

			switch (this.sourceTmm.getTransactionCategory()) {
			case HEARTBEAT:
				networkMgmtInfoCode = TmmConstants.MASTERCARD_ECHO_NW_INFO_CODE;
				break;

			case SIGNON:
				networkMgmtInfoCode = TmmConstants.MASTERCARD_SIGNON_NW_INFO_CODE;
				break;

			case SIGNOFF:
				networkMgmtInfoCode = TmmConstants.MASTERCARD_SIGNOFF_NW_INFO_CODE;
				break;

			case DYNAMIC_KEY_EXCHANGE:
				if (sourceTmm.getNetworkMgmtInfoCode() == null || sourceTmm.getNetworkMgmtInfoCode().isEmpty()) {
					//For switch initiate Dynamic Key Exchange .......
					networkMgmtInfoCode = TmmConstants.MASTERCARD_SWITCH_INIT_KEY_EXCHANGE_NW_INFO_CODE;
				} else {//For Scheme initiate Dynamic Key Exchange .......
					networkMgmtInfoCode = sourceTmm.getNetworkMgmtInfoCode();
				}
				break;

			case HOST_SESSION_ACTIVATION:
				networkMgmtInfoCode = TmmConstants.MASTERCARD_HOST_ACTIVATION_NW_INFO_CODE;
				break;

			case HOST_SESSION_DEACTIVATION:
				networkMgmtInfoCode = TmmConstants.MASTERCARD_HOST_DEACTIVATION_NW_INFO_CODE;
				break;
			default:
				networkMgmtInfoCode = this.sourceTmm.getNetworkMgmtInfoCode();
			}
		}

		this.targetTmm.setNetworkMgmtInfoCode(networkMgmtInfoCode);
		this.baseMessage.set(fieldNo, networkMgmtInfoCode);
	}


	/**
	 * 71.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number
	 */


	/**
	 * 72.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number Last
	 */


	/**
	 * 73.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Action Date
	 */


	/**
	 * 74.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Credits
	 */


	/**
	 * 75.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
	 */


	/**
	 * 76.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Debits
	 */


	/**
	 * 77.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
	 */


	/**
	 * 78.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Transfer
	 */


	/**
	 * 79.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
	 */


	/**
	 * 80.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
	 */


	/**
	 * 81.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
	 */


	/**
	 * 82.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
	 */


	/**
	 * 83.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
	 */


	/**
	 * 84.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
	 */


	/**
	 * 85.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
	 */


	/**
	 * 86.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Credits
	 */


	/**
	 * 87.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
	 */


	/**
	 * 88.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Debits
	 */


	/**
	 * 89.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
	 */


	/**
	 * 90.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
	 */


	/**
	 * 91.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Update Code
	 */


	/**
	 * 92.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Security Code
	 */


	/**
	 * 93.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Response Indicator
	 */


	/**
	 * 94.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Service Indicator
	 */
	private static final String SERVICE_INDICATOR = "0B0    ";

	@Override
	public void setServiceIndicator(int fieldNo) {
		if (targetTmm.getTransactionCategory().equals(TransactionCategory.SIGNON) ||
				targetTmm.getTransactionCategory().equals(TransactionCategory.SIGNOFF)) {
			this.targetTmm.setServiceIndicator(SERVICE_INDICATOR);
			this.baseMessage.set(fieldNo, SERVICE_INDICATOR);
		}
	}

	/**
	 * 95.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
	 */

	/**
	 * 96.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Security Code
	 */
	private static final String MSG_SECURITY_CODE = "00000000";

	@Override
	public void setMsgSecurityCode(int fieldNo) {
		if (isSignOnRequest(this.sourceMsgType) && (targetTmm.getTransactionCategory().equals(TransactionCategory.SIGNON)
				|| targetTmm.getTransactionCategory().equals(TransactionCategory.SIGNOFF))) {
			this.targetTmm.setMsgSecurityCode(MSG_SECURITY_CODE);
			this.baseMessage.set(fieldNo, MSG_SECURITY_CODE);
		}
	}


	/**
	 * 97.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
	 */


	/**
	 * 98.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Payee
	 */


	/**
	 * 99.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
	 * Code
	 */


	/**
	 * 100.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
	 */


	/**
	 * 101.ISO8583-1987, AS2805, Base24, XML - File Name
	 */


	/**
	 * 102.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
	 */


	/**
	 * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
	 */


	/**
	 * 104.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
	 * mPOS - transaction_type
	 */


	/**
	 * 105.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 106.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 107.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 108.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */
	@Override
	public void setReserved108(int fieldNo) {
		String reserved108 = sourceTmm.getReserved108();
		this.targetTmm.setReserved108(reserved108);
		this.baseMessage.set(fieldNo, reserved108);
	}

	/**
	 * 109.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 110.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	@Override
	public void setReserved110(int fieldNo) {
		String reserved110 = this.sourceTmm.getReserved110();
		this.targetTmm.setReserved110(reserved110);
		this.baseMessage.set(fieldNo, reserved110);
	}


	/**
	 * 111.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 112.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use<br>
	 * AS2805 - Key Management data
	 */


	/**
	 * 113.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 114.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 115.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 116.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 117. <br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 118.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 119.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 120.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
	 */
	@Override
	public void setReserved120(int fieldNo) {
		// optional in scheme sign on, hence intentionally left blank
		String reserved120 = this.sourceTmm.getReserved120();
		this.targetTmm.setReserved120(reserved120);
		this.baseMessage.set(fieldNo, reserved120);
	}


	/**
	 * 121. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS Authorization Indicators
	 */
	@Override
	public void setReserved121(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
	}

	/**
	 * 122.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -Card Issuer Identification Code
	 */


	/**
	 * 123.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
	 * Invoice Data/Settlement Record
	 */


	/**
	 * 124.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
	 */
	@Override
	public void setReserved124(int fieldNo) {
		String reserved124 = this.sourceTmm.getReserved124();
		this.targetTmm.setReserved124(reserved124);
		this.baseMessage.set(fieldNo, reserved124);
	}

	/**
	 * 125.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
	 */


	/**
	 * 126. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
	 */


	/**
	 * 127.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS User Data
	 */
	@Override
	public void setReserved127(int fieldNo) {
		String reserved127 = this.sourceTmm.getReserved127();
		this.targetTmm.setReserved127(reserved127);
		this.baseMessage.set(fieldNo, reserved127);
	}

	/**
	 * 128.<br>
	 * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
	 * Base24 - Secondary Message Authentication Code
	 */

}