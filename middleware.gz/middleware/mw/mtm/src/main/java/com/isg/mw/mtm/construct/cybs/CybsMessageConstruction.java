package com.isg.mw.mtm.construct.cybs;

import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.commons.lang3.StringUtils;

import java.text.DecimalFormat;
import java.time.ZoneId;

public class CybsMessageConstruction extends SwitchBaseMessageConstruction {

    private static final DecimalFormat df = new DecimalFormat("0.00");

    @Override
    public void setIccData(int fieldNo) {
    }

    public String setRetrievalRefNo() {
        super.setRetrievalRefNo(37);
        return this.targetTmm.getRetrievalRefNo();
    }

    public String setTxnAmt() {
        double txnAmt = Double.parseDouble(this.sourceTmm.getTxnAmt()) / 100;
        this.targetTmm.setTxnAmt(this.sourceTmm.getTxnAmt());
        return df.format(txnAmt);
    }

    public String setExpirationMonth() {
        String expirationDate = this.sourceTmm.getExpirationDate();
        return expirationDate != null ? expirationDate.substring(2) : null;
    }

    public String setExpirationYear() {
        String expirationDate = this.sourceTmm.getExpirationDate();
        return expirationDate != null ? "20" + expirationDate.substring(0, 2) : null;
    }


    public String setFirstName() {
        String[] merName = this.merchantData.getMerchantName().split(" ");
        return merName != null ? merName[0] : this.merchantData.getMerchantName();
    }

    public String setLastName() {
        String[] merName = this.merchantData.getMerchantName().split(" ");
        return merName != null ? merName[1] : this.merchantData.getMerchantName();
    }

    public String setAddress() {
        return this.merchantData.getMerchantAddress();
    }

    public String setLocality() {
        return this.merchantData.getMerchantCity();
    }

//    public String setAdministrativeArea() {
//        return "";
//    }

    public String setPostalCode() {
        //this.targetTmm.setPostalCode(this.merchantData.getMerchantZipCode());
        return this.merchantData.getMerchantZipCode();
    }

    public String setCountry() {
        return this.merchantData.getMerchantCountryCode();
    }

    public void setAquirerIdCode(int fieldNo) {
        String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
        this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
    }

    public String setAquirerCountryCode() {
        String acqCountryCode = this.merchantData.getAcquiringInstitutionCountryCode();
        this.targetTmm.setAquirerCountryCode(acqCountryCode);
        return acqCountryCode;
    }

    public String setMerchantCurrencyCode() {
        String merchantCurrency = this.merchantData.getMerchantCurrencyCode();
        this.targetTmm.setSettlementCurrenyCode(merchantCurrency);
        return merchantCurrency;
    }

    public void setCardAcceptorInfo() {
        String merchantName = StringUtils.rightPad(this.merchantData.getMerchantName(), 25);
        String merchantCity = StringUtils.rightPad(this.merchantData.getMerchantCity(), 13);
        String merchantCountryShortCode = StringUtils.rightPad(this.merchantData.getMerchantShortCountryCode(), 2); // e.g. IN

        String cardAcceptorInfo = merchantName + merchantCity + merchantCountryShortCode;
        this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
    }

    public void setCardHolderBillingAmt() {
        String txnAmt = this.sourceTmm.getTxnAmt();
        this.targetTmm.setCardHolderBillingAmt(txnAmt);
    }

    public void setPosConditionCode() {
        String posConditionCode = "59";
        this.targetTmm.setPosConditionCode(posConditionCode);
    }

    public void setTransmissionTime() {
        String transmissionTime = MtmUtil.formatDate("MMddHHmmss", ZoneId.of("GMT"));
        this.targetTmm.setTransmissionTime(transmissionTime);
    }

    public String setCardType() {
        String cardType = MtmUtil.getCybsCardTypes().get(this.sourceTmm.getTargetType());
        this.targetTmm.getCybsData().setCardType(cardType);
        return cardType;
    }
}
