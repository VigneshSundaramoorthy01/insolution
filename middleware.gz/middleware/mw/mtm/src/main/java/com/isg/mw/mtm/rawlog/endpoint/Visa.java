package com.isg.mw.mtm.rawlog.endpoint;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.construct.MessageConstructionHelper;

public class Visa {

    private Visa() { throw new IllegalStateException("Utility class");}

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */
    public static String getPostalCode(Object object, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm) {
        String value = null;

        if(MessageConstructionHelper.isPosRefundReq(srcTmm.getMsgType(), srcTmm.getProcessingCode())) {
            value = object.toString();
        }
        return value;
    }
    
    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */
    public static String  getReserved126(Object object, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm) {
        String value=null;

        value=object.toString();

        return value;

    }

}
