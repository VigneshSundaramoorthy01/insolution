package com.isg.mw.mtm.transform;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.construct.DeclineMessageConstruction;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class DeclineMessageTransformation extends BaseMessageTransformation {

    private Logger logger = LogManager.getLogger(getClass());
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();


    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        getPosDeclineResponse(tmmConfig);
        getPurchaseResponse(tmmConfig);
        getPreAuthDeclineResponse(tmmConfig);
        getPreauthSaleCompletionDeclineResponse(tmmConfig);
        getBalanceInquiryDeclineResponse(tmmConfig);
        getOnlineRefundDeclineResponse(tmmConfig);
        getTipAdjustDeclineResponse(tmmConfig);
        getOfflineSaleDeclineResponse(tmmConfig);
        getReversalDeclineResponse(tmmConfig);
        getVoidDeclineResponse(tmmConfig);
        getVoidRefundDeclineResponse(tmmConfig);
        getMotoDeclineResponse(tmmConfig);
        getSettlementDeclineResponse(tmmConfig);
        getSettlementAfterBatchDeclineResponse(tmmConfig);
        getBatchUploadDeclineResponse(tmmConfig);
        getKeyExchangeDeclineResponse(tmmConfig);
        getCashWithdarwalDeclineResponse(tmmConfig);
        getCashatPosDeclineResponse(tmmConfig);
        getPurCashatPosDeclineResponse(tmmConfig);

        getAddMoneyDeclineResponse(tmmConfig);

        getBalanceUpdateDeclineResponse(tmmConfig);
        
        getServiceCreationDeclineResponse(tmmConfig);

        getRupayBalanceInquiryDeclineResponse(tmmConfig);
        
        getPosSignOnDeclineResponse(tmmConfig);
        
        getPosDccRateLookUpDeclineResponse(tmmConfig);
        
        getPosZvavDeclineResponse(tmmConfig);

        getPosTerminalInitDeclineResponse(tmmConfig);

        return tmmConfig;

    }

    private void getPosDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("DECLINE", "DECLINE", "decline.transaction.response"), fieldMap);

    }

    public void getPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0210", "00", "decline.purchase.response"), fieldMap);
    }

    public void getPreAuthDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", "decline.preauth.response"), fieldMap);

    }

    public void getPreauthSaleCompletionDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0230", "40", "decline.preauth.completion.response"), fieldMap);

    }

    public void getBalanceInquiryDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(4, TmmConstants.TXN_AMT);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0110", "30", "decline.vm.balance.inquiry.response"), fieldMap);

    }

    public void getRupayBalanceInquiryDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(4, TmmConstants.TXN_AMT);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0110", "31", "decline.rupay.balance.inquiry.response"), fieldMap);

    }

    public void getOnlineRefundDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0210", "20", "decline.refund.response"), fieldMap);

    }

    public void getTipAdjustDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0230", "50", "decline.tipadjust.response"), fieldMap);

    }

    public void getOfflineSaleDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0230", "00", "decline.offline.response"), fieldMap);

    }

    public void getReversalDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0410", null, "decline.reversal.response"), fieldMap);

    }

    public void getVoidDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0230", "02", "decline.void.others.response"), fieldMap);

    }

    public void getVoidRefundDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0230", "22", "decline.void.refund.response"), fieldMap);

    }

    public void getMotoDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0210", "51", "decline.moto.response"), fieldMap);

    }

    public void getSettlementDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldMap.put(61, TmmConstants.TERMINAL_DATA);
        tmmConfig.put(new TransactionTypeConfig("0510", "92", "decline.direct.settlement.response"), fieldMap);

    }

    public void getSettlementAfterBatchDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldMap.put(61, TmmConstants.CIAD);
        tmmConfig.put(new TransactionTypeConfig("0510", "96", "decline.batch.upload.settlement.response"), fieldMap);

    }

    public void getBatchUploadDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0330", null, "decline.batchupload.response"), fieldMap);

    }

    public void getKeyExchangeDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldMap.put(62, TmmConstants.POSTAL_CODE);
        tmmConfig.put(new TransactionTypeConfig("0810", null, "decline.pos.signon.response"), fieldMap);

    }

    private void getCashWithdarwalDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);

        tmmConfig.put(new TransactionTypeConfig("0210", "01", "decline.cashwithdrawal.response"), fieldsMap);
    }

    private void getCashatPosDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);

        tmmConfig.put(new TransactionTypeConfig("0210", "09", "decline.cashatpos.response"), fieldsMap);
    }

    private void getPurCashatPosDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);

        tmmConfig.put(new TransactionTypeConfig("0210", "09", "decline.purchase.cashatpos.response"), fieldsMap);
    }

    private void getAddMoneyDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);

        tmmConfig.put(new TransactionTypeConfig("0210", "28", "decline.addmoney.response"), fieldsMap);
    }


    private void getBalanceUpdateDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);

        tmmConfig.put(new TransactionTypeConfig("0210", "29", "decline.balanceupdate.response"), fieldsMap);
    }
    
    /**
     * @param tmmConfig
     */
    private void getPosSignOnDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        tmmConfig.put(new TransactionTypeConfig("0810", "99", "decline.pos.signon.response"), fieldsMap);

    }

    private void getServiceCreationDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

    	tmmConfig.put(new TransactionTypeConfig("0210", "83", "decline.servicecreation.response"), fieldsMap);

    }
    
    private void getPosDccRateLookUpDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        tmmConfig.put(new TransactionTypeConfig("0610", "00", "decline.dcc.rate.lookup.response"), fieldsMap);
    }
    
    private void getPosZvavDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
//		fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("0210", "33", "decline.zvav.response"), fieldsMap);
    }
    
    
    private void getPosTerminalInitDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        tmmConfig.put(new TransactionTypeConfig("0810", "01", "decline.pos.terminal.init.response"), fieldsMap);
    }
    
    @Override
    public MessageContext constructMessage(TransactionMessageModel tmm, String epId, TransactionTypeConfig txnTypeConfig,
                                           MessageTransformationConfig msgTransConfig) {

        MessageContext msgContext = super.constructMessage(tmm, epId, txnTypeConfig, msgTransConfig);

        if (tmm.getSourceProcessor() != SourceProcessor.PG_SWITCH 
        		&& msgContext.getRawMsg() instanceof ISOMsg) {
            ISOMsg isoMsg = (ISOMsg) msgContext.getRawMsg();
            byte[] rawMsgWithBodyHeader;
            try {
                boolean isSignOnResponse = MessageConstructionHelper.isSignOnResponse(msgContext.getEpMsgType());
                rawMsgWithBodyHeader = buildHeader(isoMsg, isSignOnResponse);
                logger.trace("MTI: {}, Is Sign On Response: {}", msgContext.getEpMsgType(), isSignOnResponse);
                /*if (isSignOnResponse) {
                    String ipek = msgContext.getTransactionMessageModel().getPostalCode();
                    int dataLength = ipek.length() / 2;
                    byte[] ipekBytes = MtmUtil.toBytesAsIs(String.format("%04d", dataLength) + ipek);
                    byte[] tmp = new byte[rawMsgWithBodyHeader.length + ipekBytes.length];
                    System.arraycopy(rawMsgWithBodyHeader, 0, tmp, 0, rawMsgWithBodyHeader.length);
                    System.arraycopy(ipekBytes, 0, tmp, rawMsgWithBodyHeader.length, ipekBytes.length);
                    rawMsgWithBodyHeader = tmp;
                }*/

                byte[] bcdRawMsgWithBodyHeader = buildBcdMessage(rawMsgWithBodyHeader);
                msgContext.setRawMsg(bcdRawMsgWithBodyHeader);

                String encryptedRawMsg = TxnLogger.encryptRawMsg(bcdRawMsgWithBodyHeader);
                if (tmm.getTlmMessageType() != null && tmm.getTlmMessageType().equals(TlmMessageType.REQUEST)) {
                    msgContext.getTransactionMessageModel().setRawRequest(encryptedRawMsg);
                } else if (tmm.getTlmMessageType() != null && tmm.getTlmMessageType().equals(TlmMessageType.RESPONSE)) {
                    msgContext.getTransactionMessageModel().setRawResponse(encryptedRawMsg);
                }
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(tmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        tmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(tmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        tmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return msgContext;

    }

    private byte[] buildHeader(ISOMsg isoMsg, boolean isSignOnResponse) throws ISOException {
        byte[] bodyBytes = isoMsg.pack();
        if (isSignOnResponse) {
            byte[] bodyBytesNo62 = new byte[bodyBytes.length - 2];
            System.arraycopy(bodyBytes, 0, bodyBytesNo62, 0, bodyBytes.length - 2);
            bodyBytes = bodyBytesNo62;
        }
        return buildHeader(bodyBytes);
    }

    private byte[] buildHeader(byte[] bodyBytes) {
        byte[] rawMsgWithBodyHeader = null;
        byte[] headerBytes = MtmUtil.toBytesAsIs("6000560000");

        rawMsgWithBodyHeader = new byte[bodyBytes.length + headerBytes.length];

        System.arraycopy(headerBytes, 0, rawMsgWithBodyHeader, 0, headerBytes.length);
        System.arraycopy(bodyBytes, 0, rawMsgWithBodyHeader, headerBytes.length, bodyBytes.length);

        return rawMsgWithBodyHeader;
    }

    private byte[] buildBcdMessage(final byte[] bcdRawMsgWithBodyHeader) {
        int intsize2 = bcdRawMsgWithBodyHeader.length / 256;
        int intsize3 = bcdRawMsgWithBodyHeader.length % 256;
        String lenStr = String.format("%c%c", intsize2, intsize3);
        byte[] size1 = lenStr.getBytes();
        logger.trace("size1: ");
        for (byte b : size1)
            logger.trace(b);
        int lengthOfTotalMsgLength = 2;
        byte[] msgLengthHeaderBytes = new byte[lengthOfTotalMsgLength];
        msgLengthHeaderBytes[0] = size1[0];
        msgLengthHeaderBytes[1] = size1[1];

        byte[] finalBcdMsgArr = new byte[msgLengthHeaderBytes.length + bcdRawMsgWithBodyHeader.length];
        System.arraycopy(msgLengthHeaderBytes, 0, finalBcdMsgArr, 0, msgLengthHeaderBytes.length);

        System.arraycopy(bcdRawMsgWithBodyHeader, 0, finalBcdMsgArr, msgLengthHeaderBytes.length,
                bcdRawMsgWithBodyHeader.length);
        return finalBcdMsgArr;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new DeclineMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        return new DeclineMessageConstruction();
    }

}
