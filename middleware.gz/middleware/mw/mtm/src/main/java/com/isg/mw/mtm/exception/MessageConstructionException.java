package com.isg.mw.mtm.exception;

public class MessageConstructionException extends MessageTransformationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageConstructionException(String expMsg) {
		super(expMsg);
	}

	public MessageConstructionException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}
