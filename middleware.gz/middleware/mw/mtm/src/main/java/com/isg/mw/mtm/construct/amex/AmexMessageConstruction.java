package com.isg.mw.mtm.construct.amex;

import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.core.model.construct.amex.AmexMsgTypeHelper;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.commons.lang3.StringUtils;
import org.jpos.iso.ISOUtil;
import org.jpos.tlv.TLVList;
import org.jpos.tlv.TLVMsg;

import java.time.ZoneOffset;
import java.util.Locale;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

public class AmexMessageConstruction  extends PgAmexMessageConstruction {
	/**
	 * 1.<br>
	 * ISO8583 -1987, AS2805 - Secondary bitmap <br>
	 * Base24, ISG, XML - Bit map
	 */


	/**
	 * 2.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
	 * Account Number
	 */

	/**
	 * 3. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
	 * <br>
	 * mPOS - Transaction Type
	 */
	@Override
	public void setProcessingCode(int fieldNo) {
		String msgTypeId = null;
		String processingCode = "";
		if (this.sourceMsgTypeId != null) {
			processingCode = this.sourceMsgTypeId.substring(0, 2);
		}
		switch (processingCode) {
		case "00":
			if (this.sourceTmm.getPosAavData() != null) {
				msgTypeId = "004800";
			} else {
				msgTypeId = "004000";
			}
			break;
		case "20":
			if (this.sourceTmm.getPosAavData() != null) {
				msgTypeId = "200800";
			} else {
				msgTypeId = "200000";
			}
			break;
		case "33":
			if (this.sourceTmm.getPosAavData() != null) {
				msgTypeId = "334800";
			} else {
				msgTypeId = "334000";
			}
			break;
		default:
			msgTypeId = "000000";
			break;
		}
		this.targetTmm.setProcessingCode(msgTypeId);
		this.baseMessage.set(fieldNo, msgTypeId);
	}
	
	/**
	 * 4. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
	 * CyberSource API - AuthorizedAmount
	 * <p>
	 * It is mandatory for all type of transactions
	 */
	//    @Override
	//    public void setTxnAmt(int fieldNo) {
	//        if(this.sourceTmm.getTransactionCategory().equals("181")){
	//
	//        }
	//    }
	
	/**
	 * 5.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
	 */

	/**
	 * 6.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
	 */


	/**
	 * 7. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setTransmissionTime(int fieldNo) {
		String formattedDate = null;
		formattedDate = MtmUtil.formatDate("MMddhhmmss", ZoneOffset.UTC);
		this.targetTmm.setTransmissionTime(formattedDate);
		this.baseMessage.set(fieldNo, formattedDate);

	}

	/**
	 * 8. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
	 */


	/**
	 * 9. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
	 */


	/**
	 * 10. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
	 */


	/**
	 * 11. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
	 * <br>
	 * CyberSource API - T id
	 */
	/* It is mandatory for all type of transactions */

	/**
	 * 12. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
	 * CyberSource API - Transaction Local Date Time
	 */
	@Override
	public void setLocalTxnTime(int fieldNo) {
		String currentYear = MtmUtil.formatDate("YY");
		String localTxnDateTime = MtmUtil.formatDate("MMddhhmmss");
		/*if(!StringUtils.isBlank(this.sourceTmm.getLocalTxnDate())
				&& !StringUtils.isBlank(this.sourceTmm.getLocalTxnTime())){
			localTxnDate = this.sourceTmm.getLocalTxnDate();
			localTxnTime = this.sourceTmm.getLocalTxnTime();
		}*/
		this.targetTmm.setLocalTxnTime(currentYear + localTxnDateTime);
		this.baseMessage.set(fieldNo, currentYear + localTxnDateTime);
	}

	/**
	 * 13. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
	 */
	@Override
	public void setLocalTxnDate(int fieldNo) {
		String currentYear = MtmUtil.formatDate("YY");
		String localTxnDate = null;
		if(!StringUtils.isBlank(this.sourceTmm.getLocalTxnDate())){
			localTxnDate = this.sourceTmm.getLocalTxnDate().substring(0,2);
		}
		this.targetTmm.setLocalTxnDate(currentYear+localTxnDate);
		this.baseMessage.set(fieldNo, currentYear+localTxnDate);
	}


	/**
	 * 14. <br>
	 * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
	 * Date
	 */

	/**
	 * 15. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
	 */


	/**
	 * 16. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
	 */


	/**
	 * 17. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
	 */


	/**
	 * 18.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
	 * ISO8583 -1987, CyberSource API - Category Code
	 */


	/**
	 * 19. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
	 * Country Code <br>
	 * mPOS - terminalCountryCode
	 */
	@Override
	public void setAquirerCountryCode(int fieldNo) {
		// this method implementation has been intentionally left blank
		String aquirerCountryCode = this.merchantData.getAcquirerCurrencyCode();

		this.targetTmm.setAquirerCountryCode(aquirerCountryCode);
		this.baseMessage.set(fieldNo, aquirerCountryCode);
	}

	/**
	 * 20. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
	 * code
	 */

	/**
	 * 21. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
	 */


	/**
	 * 22.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
	 * Entry Mode <br>
	 * mPOS - NFC Enabled
	 * <p>
	 * It is mandatory for all type of transactions
	 */
	@Override
	public void setPosEntryMode(int fieldNo) {
		String posEntryMode = "51010151134C";
		String entryMode = this.sourceTmm.getPosEntryMode();

		if (MessageConstructionHelper.isMagstripeWithPin(entryMode.substring(0, 2), this.sourceTmm.getPin())) {
			posEntryMode = "51010121514C";
        } else if (MessageConstructionHelper.isMagstripeWithoutPin(entryMode.substring(0, 2), this.sourceTmm.getPin())) {
        	if (this.sourceTmm.getPosCid() != null) {
        		posEntryMode = "500101W5414C";
        	} else {
        		posEntryMode = "50010125414C";
        	}
        } else if (MessageConstructionHelper.isContactlessTxn(entryMode.substring(0, 2))) {
        	String position7 = "2";
        	if (MessageConstructionHelper.isMsrContactlessTxn(entryMode)) {
        		position7 = "5";
        	}
        	if (this.sourceTmm.getPin() != null && this.sourceTmm.getPin().isEmpty() == false) {
        		posEntryMode = "51010X"+position7+"1534C";
        	} else {
        		posEntryMode = "50010X"+position7+"0234C";
        	}
        } else if (MessageConstructionHelper.isFallbackWithPin(entryMode.substring(0, 2), this.sourceTmm.getPin())) {
        	posEntryMode = "51010191514C";
        } else if (MessageConstructionHelper.isFallbackWithoutPin(entryMode.substring(0, 2), this.sourceTmm.getPin())) {
        	posEntryMode = "50010195414C";
        } else if (MessageConstructionHelper.isManualTxn(entryMode.substring(0, 2))) {
        	if (this.sourceTmm.getPosCid() != null) {
        		posEntryMode = "500101S5414C";
        	} else {
        		posEntryMode = "50010165414C";
        	}
        } else {
        	if (this.sourceTmm.getPin() != null && this.sourceTmm.getPin().isEmpty() == false) {
        		posEntryMode = "51010151534C";
        	} else {
        		posEntryMode = "50010150234C";
        	}
        }

		this.targetTmm.setPosEntryMode(posEntryMode);
		this.baseMessage.set(fieldNo, posEntryMode);
	}

	/**
	 * 23. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
	 */


	/**
	 * 24. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
	 * CyberSource API - Type
	 */
	@Override
	public void setNiiId(int fieldNo) {
		String functionCode = null;
		if(AmexMsgTypeHelper.isSignOnRequest(this.targetMsgType)){
			switch (this.sourceTmm.getTransactionCategory()) {
			case SIGNON:
				functionCode = TmmConstants.AMEX_SIGNON_NW_INFO_CODE;
				break;

			case SIGNOFF:
				functionCode = TmmConstants.AMEX_SIGNOFF_NW_INFO_CODE;
				break;

			case HEARTBEAT:
				functionCode = TmmConstants.AMEX_ECHO_MESSAGE_NW_INFO_CODE;
				break;

			case DYNAMIC_KEY_EXCHANGE:
				functionCode = TmmConstants.AMEX_KEY_EXCHANGE_NW_INFO_CODE;
				break;

			default:
				functionCode = this.sourceTmm.getNiiId();
				break;
			}
		} else if (AmexMsgTypeHelper.isAuthResquest(this.targetMsgType, this.targetMsgTypeId)) {
			functionCode = "100";
		}

		this.targetTmm.setNiiId(functionCode);
		this.baseMessage.set(fieldNo, functionCode);

	}

	/**
	 * 25. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
	 */
	@Override
	public void setPosConditionCode(int fieldNo) {

		String posConditioncode = "";
		if (AmexMsgTypeHelper.isSignOnRequest(this.targetMsgType)) {
			posConditioncode = "8700";
		} else {
			posConditioncode = "1900";
		}
		this.targetTmm.setPosConditionCode(posConditioncode);
		this.baseMessage.set(fieldNo, posConditioncode);
	}


	/**
	 * 26. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
	 */
	@Override
	public void setPosCaptureCode(int fieldNo) {
		String posCaptureCode = this.merchantData.getMerchantType();
		this.targetTmm.setPosCaptureCode(posCaptureCode);
		this.baseMessage.set(fieldNo, posCaptureCode.getBytes());
	}

	/**
	 * 27. <br>
	 * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
	 * length
	 */


	/**
	 * 28. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
	 */


	/**
	 * 29. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
	 */


	/**
	 * 30. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
	 */


	/**
	 * 31.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
	 */


	/**
	 * 32. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
	 * Code
	 */
	@Override
	public void setAquirerIdCode(int fieldNo) {
		String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
		this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
	}


	/**
	 * 33.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
	 * Code
	 */
	@Override
	public void setForwardingInstIdCode(int fieldNo) {
		String forwardingInstitutionId = this.sourceTmm.getForwardingInstIdCode();

		this.targetTmm.setForwardingInstIdCode(forwardingInstitutionId);
		this.baseMessage.set(fieldNo, forwardingInstitutionId);
	}

	/**
	 * 34.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
	 */

	/**
	 * 35.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
	 *
	 */

	/**
	 * 36.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
	 */


	/**
	 * 37.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
	 * Number<br>
	 * CyberSource API - TransactionId
	 */
	@Override
	public void setRetrievalRefNo(int fieldNo) {

		super.setRetrievalRefNo(fieldNo);
	}


	/**
	 * 38.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
	 * Response<br>
	 * mPOS - AuthCode
	 */


	/**
	 * 39.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
	 * mPOS - Status Code
	 * <p>
	 * It is mandatory for reversal and void only
	 */


	/**
	 * 40.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
	 */


	/**
	 * 41.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
	 * Identification
	 */
	/**
	 * 42. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
	 * Identification code<br>
	 * mPOS - TxnId
	 */


	/**
	 * 43.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
	 * Name/Location
	 * <p>
	 * Logic:<br>
	 * Switch has to extract it from Merchant / POS Master table and send it to
	 * Scheme. card acceptor name (1-22),<br>
	 * space(23),<br>
	 * city name (24-36),<br>
	 * space(37),<br>
	 * Country code (38-40)
	 */
	@Override
	public void setCardAcceptorInfo(int fieldNo) {
		String payAggrName = "";
		if ("Y".equals(this.merchantData.getAggregatorFlag())) {
			payAggrName = (this.merchantData.getPaymentFacilitatorName() == null || this.merchantData.getPaymentFacilitatorName().isEmpty()) ? "=" : this.merchantData.getPaymentFacilitatorName() + "=";
		}

		String cardAcceptorInfo = payAggrName
				+ StringUtils.substring(this.merchantData.getMerchantName(), 0, 30) + "\\"
				+ StringUtils.substring(this.merchantData.getMerchantAddress(), 0, 30) + "\\"
				+ StringUtils.substring(this.merchantData.getMerchantCity(), 0, 15) + "\\"
				+ StringUtils.substring(StringUtils.rightPad(this.merchantData.getMerchantZipCode(), 10), 0, 10)
				+ StringUtils.substring(StringUtils.rightPad(this.merchantData.getMerchantStateCode(), 3), 0, 3)
				+ StringUtils.substring(StringUtils.rightPad(this.merchantData.getMerchantCountryCode(), 3), 0, 3) + "\\";
		
		//cardAcceptorInfo = cardAcceptorInfo.replaceAll(" ", "~");
		
		this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
		this.baseMessage.set(fieldNo, cardAcceptorInfo);
	}

	/**
	 * 44.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
	 */


	/**
	 * 45.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
	 */


	/**
	 * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
	 */


	/**
	 * 47.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Data National
	 */
	@Override
    public void setNationalAd(int fieldNo) {
		
	}

	/**
	 * 48.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
	 */
	/* It is mandatory for all type of transactions */

	/**
	 * 49.<br>
	 * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
	 * Code
	 */


	/**
	 * 50.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
	 */


	/**
	 * 51.<br>
	 * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
	 */


	/**
	 * 52.<br>
	 * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
	 * (PIN) Data<br>
	 * CyberSource API - Encrypted Pin
	 */
	@Override
	public void setPin(int fieldNo) {
		String pan = this.sourceTmm.getPan();
		if (pan != null && this.sourceTmm.getPin() != null) {
			TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(this.sourceTmm.getTarget());

			String dynamicKeyAndKcv = mwRedisCacheUtil.
					getTargetDynamicKeyData(this.sourceTmm.getEntityId() + "_" + SpringContextBridge.services().getHsmCommonService().
							getHsmVendorByEntityId(sourceTmm.getEntityId()) + TmmConstants.DYNAMIC_KEY, targetType);
			String [] data = dynamicKeyAndKcv.split("##");
			String dynamicKey = data[0];

			Map<HsmCommandArg, String> hsmCmdArgMap = cacheServices.getMftrBDK(sourceTmm.getDeviceMftr());


			String aesBDK = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).bdkTranslationAmex(this.sourceTmm.getEntityId(), this.sourceTmm.getTarget(), this.sourceTmm.getTarget(), 
					hsmCmdArgMap.get(HsmCommandArg.Bdk2));
			
			String pinTranslation = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).pinTranslationAmex(
					this.sourceTmm.getEntityId(), this.sourceTmm.getSource(), this.sourceTmm.getTarget(),
					this.sourceTmm.getPinblockKsn(), this.sourceTmm.getPin(), pan, dynamicKey, aesBDK);

			byte[] pinBytes = MtmUtil.toBytesAsIs(pinTranslation);
			this.targetTmm.setPin(pinTranslation);
			this.apiTargetTmm.setPin(ISOUtil.byte2hex(pinBytes));
			this.baseMessage.set(fieldNo, pinBytes);
		}
	}


	/**
	 * 53.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
	 * Information<br>
	 * CyberSource API - Encrypted Key Serial Number
	 */
	@Override
	public void setSecurityControlInfo(int fieldNo) {
		// this method implementation has been intentionally left blank

		if (this.sourceTmm.getPosCid() != null){
			String posCid = this.sourceTmm.getPosCid();
			this.targetTmm.setSecurityControlInfo(posCid);
			this.baseMessage.set(fieldNo, posCid);
		} else {
			this.targetTmm.setSecurityControlInfo("");
		}

	}

	/**
	 * 54.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
	 */



	/**
	 * 55.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
	 * Base24 - ISO Reserved<br>
	 * CyberSource API- EMV
	 */
	@Override
	public void setIccData(int fieldNo) {
		/*
		 * Reason to convert the data to as is bytes is because JPOS data type is
		 * HBINARY
		 */
		String iccData = this.sourceTmm.getIccData();

		if (iccData != null) {
			TLVList list = new TLVList();
			list.unpack(ISOUtil.hex2byte(iccData));

			String subField1 = "";
			String subField2 = "";
			String subField3 = "";
			String subField4 = "";
			String subField5 = "";
			String subField6 = "";
			String subField7 = "";
			String subField8 = "";
			String subField9 = "";
			String subField10 = "";
			String subField11 = "";
			String subField12 = "";
			String subField13 = "";
			String subField14 = "";
			
			for (TLVMsg tlvMsg : list.getTags()) {
				switch (tlvMsg.getTag()) {
				case 40742:
					subField1 = tlvMsg.getStringValue();
					break;

				case 40720:
					subField2 = tlvMsg.getStringValue();
					break;

				case 40759:
					subField3 = tlvMsg.getStringValue();
					break;

				case 40758:
					subField4 = tlvMsg.getStringValue();
					break;

				case 149:
					subField5 = tlvMsg.getStringValue();
					break;

				case 154:
					subField6 = tlvMsg.getStringValue();
					break;

				case 156:
					subField7 = tlvMsg.getStringValue();
					break;

				case 40706:
					subField8 = tlvMsg.getStringValue();
					break;

				case 24362:
					subField9 = tlvMsg.getStringValue();
					break;

				case 40730:
					subField10 = tlvMsg.getStringValue();
					break;

				case 130:
					subField11 = tlvMsg.getStringValue();
					break;

				case 40707:
					subField12 = tlvMsg.getStringValue();
					break;

				case 24372:
					subField13 = tlvMsg.getStringValue();
					break;

				case 40743:
					subField14 = tlvMsg.getStringValue();
					break;
				}
			}
			byte[] subFieldBytesAssIs1= MtmUtil.toBytesAsIs(subField1);
			byte[] subFieldBytesAssIs2= MtmUtil.toBytesAsIs(subField2);
			byte[] subFieldBytesAssIs3= MtmUtil.toBytesAsIs(subField3);
			byte[] subFieldBytesAssIs4= MtmUtil.toBytesAsIs(subField4);
			byte[] subFieldBytesAssIs5= MtmUtil.toBytesAsIs(subField5);
			byte[] subFieldBytesAssIs6= MtmUtil.toBytesAsIs(subField6);
			byte[] subFieldBytesAssIs7= MtmUtil.toBytesAsIs(subField7);
			byte[] subFieldBytesAssIs8= MtmUtil.toBytesAsIs(subField8);
			byte[] subFieldBytesAssIs9= MtmUtil.toBytesAsIs(subField9);
			byte[] subFieldBytesAssIs10= MtmUtil.toBytesAsIs(subField10);
			byte[] subFieldBytesAssIs11= MtmUtil.toBytesAsIs(subField11);
			byte[] subFieldBytesAssIs12= MtmUtil.toBytesAsIs(subField12);
			byte[] subFieldBytesAssIs13= MtmUtil.toBytesAsIs(subField13);
			byte[] subFieldBytesAssIs14= MtmUtil.toBytesAsIs(subField14);
			
			String iccHeaderName = "AGNS";
			String iccHeaderNumber = "0001";

			byte[] axes = ISOUtil.asciiToEbcdic(iccHeaderName);
			byte[] aads = MtmUtil.toBytesAsIs(iccHeaderNumber);

			int totalLength = axes.length + aads.length + subFieldBytesAssIs1.length
					+ subFieldBytesAssIs2.length + subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length
					+ subFieldBytesAssIs6.length + subFieldBytesAssIs7.length + subFieldBytesAssIs8.length + subFieldBytesAssIs9.length
					+ subFieldBytesAssIs10.length + subFieldBytesAssIs11.length + subFieldBytesAssIs12.length + subFieldBytesAssIs13.length
					+ subFieldBytesAssIs14.length;

			byte[] finalMsgBytes = new byte[totalLength];

			System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
			System.arraycopy(aads, 0, finalMsgBytes, axes.length, aads.length);
			System.arraycopy(subFieldBytesAssIs1, 0, finalMsgBytes, axes.length + aads.length, subFieldBytesAssIs1.length);
			System.arraycopy(subFieldBytesAssIs2, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length, subFieldBytesAssIs2.length);
			System.arraycopy(subFieldBytesAssIs3, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					, subFieldBytesAssIs3.length);
			System.arraycopy(subFieldBytesAssIs4, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length, subFieldBytesAssIs4.length);
			System.arraycopy(subFieldBytesAssIs5, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length, subFieldBytesAssIs5.length);
			System.arraycopy(subFieldBytesAssIs6, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length, subFieldBytesAssIs6.length);
			System.arraycopy(subFieldBytesAssIs7, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length, subFieldBytesAssIs7.length);
			System.arraycopy(subFieldBytesAssIs8, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					, subFieldBytesAssIs8.length);
			System.arraycopy(subFieldBytesAssIs9, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					+ subFieldBytesAssIs8.length, subFieldBytesAssIs9.length);
			System.arraycopy(subFieldBytesAssIs10, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					+ subFieldBytesAssIs8.length + subFieldBytesAssIs9.length, subFieldBytesAssIs10.length);
			System.arraycopy(subFieldBytesAssIs11, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					+ subFieldBytesAssIs8.length + subFieldBytesAssIs9.length + subFieldBytesAssIs10.length, subFieldBytesAssIs11.length);
			System.arraycopy(subFieldBytesAssIs12, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					+ subFieldBytesAssIs8.length + subFieldBytesAssIs9.length + subFieldBytesAssIs10.length + subFieldBytesAssIs11.length, subFieldBytesAssIs12.length);
			System.arraycopy(subFieldBytesAssIs13, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					+ subFieldBytesAssIs8.length + subFieldBytesAssIs9.length + subFieldBytesAssIs10.length + subFieldBytesAssIs11.length + subFieldBytesAssIs12.length
					, subFieldBytesAssIs13.length);
			System.arraycopy(subFieldBytesAssIs14, 0, finalMsgBytes, axes.length + aads.length + subFieldBytesAssIs1.length + subFieldBytesAssIs2.length
					+ subFieldBytesAssIs3.length + subFieldBytesAssIs4.length + subFieldBytesAssIs5.length + subFieldBytesAssIs6.length + subFieldBytesAssIs7.length
					+ subFieldBytesAssIs8.length + subFieldBytesAssIs9.length + subFieldBytesAssIs10.length + subFieldBytesAssIs11.length + subFieldBytesAssIs12.length
					+ subFieldBytesAssIs13.length, subFieldBytesAssIs14.length);

			this.targetTmm.setIccData(iccData);
			this.baseMessage.set(fieldNo, finalMsgBytes);
		}
	}

	/**
	 * 56.<br>
	 * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
	 */

	/**
	 * 57.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Amount cash
	 */


	/**
	 * 58.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Ledger balance
	 */


	/**
	 * 59.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Account balance, Cleared funds
	 */


	/**
	 * 60.<br>
	 * ISO8583-1987 - Reserved for national use<br>
	 * AS2805,ISG, XML - Reserved private<br>
	 * Base24 - Terminal Data
	 */

	@Override
	public void setTerminalData(int fieldNo) {
		String ax = "AX";
		String aad = "AAD";
		boolean isAggregator = "Y".equals(this.merchantData.getAggregatorFlag());
		//String txnId = !StringUtils.isBlank(this.sourceTmm.getActionDate()) ? this.sourceTmm.getActionDate() : "";
		if (isAggregator) {
			String sellerId = StringUtils.rightPad(this.merchantData.getIndependentSaleOrganizationId(), 20, " ");
			String sellerEmailId = !StringUtils.isBlank(this.merchantData.getMerchantEmail())? this.merchantData.getMerchantEmail() :"";
			String sellerPhoneNo = !StringUtils.isBlank(this.merchantData.getMerchantPhoneNo())?StringUtils.rightPad(this.merchantData.getMerchantPhoneNo(), 20, " ") : StringUtils.rightPad("", 20, " ");
			String trid = !StringUtils.isBlank(this.sourceTmm.getPosTridData())? this.sourceTmm.getPosTridData(): null;
			String bitmap = "70000000";
			String reservedPrivate = ax
					+ aad
					+ bitmap
					+ sellerId
					+ sellerEmailId.length()
					+ sellerEmailId
					+ sellerPhoneNo;

			if (trid != null) {
				bitmap = "78000000";
				reservedPrivate = reservedPrivate + trid;
			}

			byte[] axes = ISOUtil.asciiToEbcdic(ax);
			byte[] aads = ISOUtil.asciiToEbcdic(aad);
			byte[] bitmapBytes = MtmUtil.toBytesAsIs(bitmap);
			byte[] sellerIdBytes = ISOUtil.asciiToEbcdic(sellerId);
			byte[] lengthBytes = ISOUtil.asciiToEbcdic(StringUtils.leftPad("" + sellerEmailId.length(), 2, '0'));
			byte[] sellerEmailBytes = ISOUtil.asciiToEbcdic(sellerEmailId);
			byte[] sellerPhoneNoBytes = ISOUtil.asciiToEbcdic(sellerPhoneNo);
			byte[] tridBytes = null;
			

			int totalLength = axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length
					+ lengthBytes.length + sellerEmailBytes.length + sellerPhoneNoBytes.length;
			if (trid != null) {
				tridBytes = ISOUtil.asciiToEbcdic(trid);
				totalLength = totalLength + tridBytes.length;
			}
			
			byte[] finalMsgBytes = new byte[totalLength];

			System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
			System.arraycopy(aads, 0, finalMsgBytes, axes.length, aads.length);
			System.arraycopy(bitmapBytes, 0, finalMsgBytes, axes.length + aads.length, bitmapBytes.length);
			System.arraycopy(sellerIdBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length, sellerIdBytes.length);
			System.arraycopy(lengthBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length, lengthBytes.length);
			System.arraycopy(sellerEmailBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length + lengthBytes.length, sellerEmailBytes.length);
			System.arraycopy(sellerPhoneNoBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length + lengthBytes.length + sellerEmailBytes.length, sellerPhoneNoBytes.length);
			if (tridBytes != null) {
				System.arraycopy(tridBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length + lengthBytes.length + sellerEmailBytes.length + sellerPhoneNoBytes.length, tridBytes.length);

			}
			this.targetTmm.setTerminalData(reservedPrivate);
			this.baseMessage.set(fieldNo, finalMsgBytes);
		} 
	}

	/**
	 * 61.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
	 * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
	 * Data
	 * <p>
	 * Other transactions: 0000000000800356POSTAL<br>
	 * PreAuth: 0000004000800356POSTAL<br>
	 * MOTO: 2032102000800356POSTAL<br>
	 * POSTAL means-- 6 digit postal code of merchant.<br>
	 * <p>
	 * Note: It is mandatory for all type of transactions
	 */
	@Override
	public void setCiad(int fieldNo) {

	}


	/**
	 * 62.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - Postal Code
	 */


	/**
	 * 63.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - ATM PIN Offset POS Additional Data
	 */
	@Override
	public void setAtmPinOffsetData(int fieldNo) {
		if (this.sourceTmm.getPosAavData() != null) {
            String privateUseData = "";
            String posAvvData = this.sourceTmm.getPosAavData();
            String aavCardMemBillPhNo = null;
            String custEmail = posAvvData.substring(6,29);
            String reqIdentifier = (!StringUtils.isBlank(custEmail) || aavCardMemBillPhNo != null) ? "AE" : "AD";
            String aavShipToPostCode = null;
            String aavShipToAdd = null;
            String aavShipToCountryCode = null;
            String aavShipToLastName = null;
            String aavShipToFirstName = null;
            String aavCardMemBillFirstName = null;
            String aavCardMemBillLastName = null;
            String aavCardMemBillPostCode = posAvvData.substring(0,5);
            String aavCardMemBillAdd = posAvvData.substring(30,posAvvData.length());

            if (aavCardMemBillPhNo != null || aavShipToPostCode != null || aavShipToAdd != null || aavShipToFirstName != null || aavShipToLastName != null || aavShipToCountryCode != null) {
                privateUseData = "AX" + reqIdentifier + get205FormatData(aavCardMemBillPostCode, aavCardMemBillAdd, aavCardMemBillFirstName, aavCardMemBillLastName, aavCardMemBillPhNo, aavShipToPostCode, aavShipToAdd, aavShipToFirstName, aavShipToLastName, this.sourceTmm.getPgData().getAavShipToPhoneNumber(), aavShipToCountryCode);
            } else if (aavCardMemBillFirstName != null || aavCardMemBillLastName != null) {
            	privateUseData = "AX" + reqIdentifier + get78FormatData(aavCardMemBillPostCode, aavCardMemBillAdd, aavCardMemBillFirstName, aavCardMemBillLastName);
            } else {
                privateUseData = "AX" + reqIdentifier + get33FormatData(aavCardMemBillPostCode, aavCardMemBillAdd);
            }

            this.targetTmm.setAtmPinOffsetData(privateUseData);
            this.baseMessage.set(fieldNo, privateUseData);
        }
	}

	/**
	 * 64.<br>
	 * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
	 * Base24 -Primary Message Authentication Code
	 */


	/**
	 * 65.<br>
	 * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
	 * Base24 -Reserved for ISO use
	 */


	/**
	 * 66.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Code
	 */


	/**
	 * 67.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Extended payment code
	 */


	/**
	 * 68.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
	 * mPOS - Transaction Country Code
	 */


	/**
	 * 69.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
	 *
	 */


	/**
	 * 70.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
	 */

	/**
	 * 71.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number
	 */


	/**
	 * 72.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number Last
	 */


	/**
	 * 73.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Action Date
	 */


	/**
	 * 74.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Credits
	 */


	/**
	 * 75.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
	 */


	/**
	 * 76.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Debits
	 */


	/**
	 * 77.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
	 */


	/**
	 * 78.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Transfer
	 */


	/**
	 * 79.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
	 */


	/**
	 * 80.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
	 */


	/**
	 * 81.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
	 */


	/**
	 * 82.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
	 */


	/**
	 * 83.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
	 */


	/**
	 * 84.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
	 */


	/**
	 * 85.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
	 */


	/**
	 * 86.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Credits
	 */


	/**
	 * 87.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
	 */


	/**
	 * 88.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Debits
	 */


	/**
	 * 89.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
	 */


	/**
	 * 90.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
	 */


	/**
	 * 91.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Update Code
	 */


	/**
	 * 92.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Security Code
	 */


	/**
	 * 93.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Response Indicator
	 */


	/**
	 * 94.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Service Indicator
	 */


	/**
	 * 95.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
	 */

	/**
	 * 96.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Security Code
	 */
	@Override
	public void setMsgSecurityCode(int fieldNo) {
		if (AmexMsgTypeHelper.isSignOnResponse(this.sourceTmm.getMsgType())) {
			String msgSecCode = this.sourceTmm.getMsgSecurityCode();
			logger.info("SignOn response: {}", msgSecCode);
			TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(this.sourceTmm.getTarget());

			mwRedisCacheUtil.putTargetDynamicKeyData(this.sourceTmm.getEntityId() + "_" + SpringContextBridge.services().getHsmCommonService().
					getHsmVendorByEntityId(sourceTmm.getEntityId()) + TmmConstants.DYNAMIC_KEY,
					targetType, msgSecCode);
			
			
			this.targetTmm.setMsgSecurityCode(msgSecCode);
			this.baseMessage.set(fieldNo, msgSecCode);

		} else {
			String bitmap = "00000000";

			String reservedData = "AX" + "KCV" ;

			byte[] axes = ISOUtil.asciiToEbcdic("AX");
			byte[] aeds = ISOUtil.asciiToEbcdic("KCV");
			String pin = !StringUtils.isBlank(this.sourceTmm.getPin()) ? this.sourceTmm.getPin(): "";
			byte[] pinBytes = ISOUtil.asciiToEbcdic(pin);
			byte[] bitMapBytes = MtmUtil.toBytesAsIs(bitmap);

			int totalLength = axes.length + aeds.length + pinBytes.length + bitMapBytes.length;

			byte[] finalMsgBytes = new byte[totalLength];

			System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
			System.arraycopy(aeds, 0, finalMsgBytes, axes.length, aeds.length);
			System.arraycopy(pinBytes, 0, finalMsgBytes, axes.length + aeds.length, pinBytes.length);
			System.arraycopy(bitMapBytes, 0, finalMsgBytes, axes.length + aeds.length + pinBytes.length, bitMapBytes.length);

			this.targetTmm.setMsgSecurityCode(reservedData);
			this.baseMessage.set(fieldNo, finalMsgBytes);
		}
	}
	/**
	 * 97.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
	 */


	/**
	 * 98.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Payee
	 */


	/**
	 * 99.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
	 * Code
	 */


	/**
	 * 100.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
	 */


	/**
	 * 101.ISO8583-1987, AS2805, Base24, XML - File Name
	 */


	/**
	 * 102.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
	 */


	/**
	 * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
	 */


	/**
	 * 104.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
	 * mPOS - transaction_type
	 */


	/**
	 * 105.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 106.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 107.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 108.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 109.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 110.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 111.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	@Override
	public void setReserved111(int fieldNo) {
		if(AmexMsgTypeHelper.isSignOnRequest(this.targetMsgType)) {
			if(TransactionCategory.DYNAMIC_KEY_EXCHANGE.name().equals(this.sourceTmm.getTransactionCategory().name())) {
				String reserved = "00000000";
				String keyType = "PIN";
				String keyUsage = "P0";
				String algorithm = "T1";
				
				//  if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCofTxnOrigin())) {
				String reservedData = "AX" + "KXR" + reserved + keyType + keyUsage + algorithm;

				byte[] axes = ISOUtil.asciiToEbcdic("AX");
				byte[] aeds = ISOUtil.asciiToEbcdic("KXR");

				byte[] reservedBytes = ISOUtil.asciiToEbcdic(reserved);
				byte[] keyTypeBytes = ISOUtil.asciiToEbcdic(keyType);
				byte[] keyUsageBytes = ISOUtil.asciiToEbcdic(keyUsage);
				byte[] algorithBytes = ISOUtil.asciiToEbcdic(algorithm);

				int totalLength = axes.length + aeds.length + reservedBytes.length + keyTypeBytes.length + keyUsageBytes.length + algorithBytes.length;

				byte[] finalMsgBytes = new byte[totalLength];

				System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
				System.arraycopy(aeds, 0, finalMsgBytes, axes.length, aeds.length);
				System.arraycopy(reservedBytes, 0, finalMsgBytes, axes.length + aeds.length, reservedBytes.length);
				System.arraycopy(keyTypeBytes, 0, finalMsgBytes, axes.length + aeds.length + reservedBytes.length, keyTypeBytes.length);
				System.arraycopy(keyUsageBytes, 0, finalMsgBytes, axes.length + aeds.length + reservedBytes.length + keyTypeBytes.length,keyUsageBytes.length);
				System.arraycopy(algorithBytes, 0, finalMsgBytes, axes.length + aeds.length + reservedBytes.length +keyTypeBytes.length+ keyUsageBytes.length, algorithBytes.length);

				this.targetTmm.setReserved111(reservedData);
				this.baseMessage.set(fieldNo, finalMsgBytes);
			}
		} else {
			if (this.sourceTmm.getPin() != null && this.sourceTmm.getPan() != null) {
				
				String pan = this.sourceTmm.getPan();
				TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(this.sourceTmm.getTarget());
				String dynamicKeyAndKcv = mwRedisCacheUtil.
						getTargetDynamicKeyData(this.sourceTmm.getEntityId() + "_" + SpringContextBridge.services().getHsmCommonService().
								getHsmVendorByEntityId(sourceTmm.getEntityId()) + TmmConstants.DYNAMIC_KEY, targetType);
				
				String [] data = dynamicKeyAndKcv.split("##");
				String dynamicKey = data[0];

				Map<HsmCommandArg, String> hsmCmdArgMap = cacheServices.getMftrBDK(sourceTmm.getDeviceMftr());

				/*String aesBDK = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).bdkTranslationAmex(this.sourceTmm.getEntityId(), this.sourceTmm.getTarget(), this.sourceTmm.getTarget(), 
						hsmCmdArgMap.get(HsmCommandArg.Bdk2));*/
				logger.info("dynamicKey: {}",  dynamicKey);
				String pinTranslation = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).pinTranslationAmex(
						this.sourceTmm.getEntityId(), this.sourceTmm.getSource(), this.sourceTmm.getTarget(),
						this.sourceTmm.getPinblockKsn(), this.sourceTmm.getPin(), pan, dynamicKey, hsmCmdArgMap.get(HsmCommandArg.Bdk2));

				String kcv = data[1];
				String reserved = "00000000";
				String pinBlock = pinTranslation;
				
				String pinVli = StringUtils.leftPad(String.valueOf(pinBlock.length()/2), 2, '0');
				String kcvVli = StringUtils.leftPad(String.valueOf(kcv.length()/2), 2, '0');

				String reservedData = "AX" + "DKE" + pinVli + pinBlock + kcvVli + kcv + reserved;

				byte[] axes = ISOUtil.asciiToEbcdic("AX");
				byte[] aeds = ISOUtil.asciiToEbcdic("DKE");

				byte[] pinVliBytesAssIs= ISOUtil.asciiToEbcdic(pinVli);
				byte[] dkePinBytes = DatatypeConverter.parseHexBinary(pinBlock);
				byte[] kcvVliBytes = ISOUtil.asciiToEbcdic(kcvVli);
				byte[] kcvBytes = DatatypeConverter.parseHexBinary(kcv);
				byte[] reservedBytes = ISOUtil.asciiToEbcdic(reserved);
				//  byte[] bitMapBytes = MtmUtil.toBytesAsIs(bitmap);

				int totalLength = axes.length + aeds.length + pinVliBytesAssIs.length + dkePinBytes.length + kcvVliBytes.length + kcvBytes.length + reservedBytes.length;

				byte[] finalMsgBytes = new byte[totalLength];

				System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
				System.arraycopy(aeds, 0, finalMsgBytes, axes.length, aeds.length);
				System.arraycopy(pinVliBytesAssIs, 0, finalMsgBytes, axes.length + aeds.length, pinVliBytesAssIs.length);
				System.arraycopy(dkePinBytes, 0, finalMsgBytes, axes.length + aeds.length + pinVliBytesAssIs.length, dkePinBytes.length);
				System.arraycopy(kcvVliBytes, 0, finalMsgBytes, axes.length + aeds.length + pinVliBytesAssIs.length + dkePinBytes.length, kcvVliBytes.length);
				System.arraycopy(kcvBytes, 0, finalMsgBytes, axes.length + aeds.length + pinVliBytesAssIs.length + dkePinBytes.length + kcvVliBytes.length, kcvBytes.length);
				System.arraycopy(reservedBytes, 0, finalMsgBytes, axes.length + aeds.length + pinVliBytesAssIs.length + dkePinBytes.length + kcvVliBytes.length + kcvBytes.length, reservedBytes.length);

				this.targetTmm.setReserved111(reservedData);
				this.baseMessage.set(fieldNo, finalMsgBytes);
			}
		}
	}
	/**
	 * 112.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use<br>
	 * AS2805 - Key Management data
	 */


	/**
	 * 113.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */
	@Override
    public void setReserved113(int fieldNo) {
		
	}

	/**
	 * 114.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 115.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 116.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 117. <br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 118.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 119.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 120.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
	 */


	/**
	 * 121. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS Authorization Indicators
	 */


	/**
	 * 122.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -Card Issuer Identification Code
	 */


	/**
	 * 123.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
	 * Invoice Data/Settlement Record
	 */


	/**
	 * 124.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
	 */


	/**
	 * 125.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
	 */


	/**
	 * 126. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
	 */


	/**
	 * 127.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS User Data
	 */

	/**
	 * 128.<br>
	 * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
	 * Base24 - Secondary Message Authentication Code
	 */


	private String get33FormatData(String aavCardMemberBillingPostalCode, String aavCardMemberBillingAddress) {
		String data = "";
		data = (StringUtils.isBlank(aavCardMemberBillingPostalCode) ? StringUtils.rightPad("", 9, " ") : StringUtils.rightPad(aavCardMemberBillingPostalCode, 9, " ")) + (StringUtils.isBlank(aavCardMemberBillingAddress) ? StringUtils.rightPad("", 20, " ") : StringUtils.rightPad(aavCardMemberBillingAddress.toUpperCase(Locale.ROOT), 20, " "));

		return data;
	}

	private String get78FormatData(String aavCardMemberBillingPostalCode, String aavCardMemberBillingAddress, String aavCardMemberBillingFirstName, String aavCardMemberBillingLastName) {
		String data = "";
		data = get33FormatData(aavCardMemberBillingPostalCode, aavCardMemberBillingAddress) + (StringUtils.isBlank(aavCardMemberBillingFirstName) ? StringUtils.rightPad("", 15, " ") : StringUtils.rightPad(aavCardMemberBillingFirstName, 15, " ")) + (StringUtils.isBlank(aavCardMemberBillingLastName) ? StringUtils.rightPad("", 30, " ") : StringUtils.rightPad(aavCardMemberBillingLastName, 30, " "));

		return data;
	}

	private String get205FormatData(String aavCardMemberBillingPostalCode, String aavCardMemberBillingAddress, String aavCardMemberBillingFirstName, String aavCardMemberBillingLastName, String aavCardMemberBillingPhoneNumber, String aavShipToPostalCode, String aavShipToAddress, String aavShipToFirstName, String aavShipToLastName, String aavShipToPhoneNumber, String aavShipToCountryCode) {
		String data = "";

		data = get78FormatData(aavCardMemberBillingPostalCode, aavCardMemberBillingAddress, aavCardMemberBillingFirstName, aavCardMemberBillingLastName) + (StringUtils.isBlank(aavCardMemberBillingPhoneNumber) ? StringUtils.rightPad("", 10, " ") : StringUtils.rightPad(aavCardMemberBillingPhoneNumber, 10, " ")) + (StringUtils.isBlank(aavShipToPostalCode) ? StringUtils.rightPad("", 9, " ") : StringUtils.rightPad(aavShipToPostalCode, 9, " ")) +
				(StringUtils.isBlank(aavShipToAddress) ? StringUtils.rightPad("", 50, " ") : StringUtils.rightPad(aavShipToAddress, 50, " ")) + (StringUtils.isBlank(aavShipToFirstName) ? StringUtils.rightPad("", 15, " ") : StringUtils.rightPad(aavShipToFirstName, 15, " ")) + (StringUtils.isBlank(aavShipToLastName) ? StringUtils.rightPad("", 30, " ") : StringUtils.rightPad(aavShipToLastName, 30, " ")) + (StringUtils.isBlank(aavShipToPhoneNumber) ? StringUtils.rightPad("", 10, " ") : StringUtils.rightPad(aavShipToPhoneNumber, 10, " ")) + (StringUtils.isBlank(aavShipToCountryCode) ? StringUtils.rightPad("", 3, " ") : StringUtils.rightPad(aavShipToCountryCode, 3, " "));

		return data;
	}

}
