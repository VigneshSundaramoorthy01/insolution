package com.isg.mw.mtm.exception;

public class ChargebackFoundException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public ChargebackFoundException(String errorMsg) {
        super(errorMsg);
    }

    public ChargebackFoundException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}
