package com.isg.mw.mtm.transform.rupay;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.rupay.BqrRupayMessageConstruction;
import com.isg.mw.mtm.construct.rupay.RupayMessageConstruction;
import com.isg.mw.mtm.construct.rupay.VoidReversalRupayMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import com.isg.mw.core.model.constants.SourceProcessor;

public class RupayMessageTransformation extends BaseMessageTransformation {

    private Logger logger = LogManager.getLogger();
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();


    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        getSwitchToSchemeSignOnRequest(tmmConfig);
        getSchemeToSwitchSignOnResponse(tmmConfig);

        // purchase

        getSwitchToSchemaPurchaseRequest(tmmConfig);
        getSchemaToSwitchPurchaseResponse(tmmConfig);

        // cash withdrawl

        getSwitchToSchemaCashWithdrawlRequest(tmmConfig);
        getSchemaToSwitchCashWithdrawlResponse(tmmConfig);

        // cashPos

        getSwitchToSchemaCashPosRequest(tmmConfig);
        getSchemaToSwitchCashPosResponse(tmmConfig);

        // PurCashPos

        getSwitchToSchemaPurchaseCashPosRequest(tmmConfig);
        getSchemaToSwitchPurchaseCashPosResponse(tmmConfig);

        // MOTO

        getSwitchToSchemaMotoRequest(tmmConfig);
        getSchemaToSwitchMotoResponse(tmmConfig);

        // Pre-Auth Req&Resp

        getSwitchToSchemaPreAuthenticationRequest(tmmConfig);
        getSchemaToSwitchPreAuthenticationResponse(tmmConfig);

        // Refund

        getSwitchToSchemaRefundRequest(tmmConfig);
        getSchemaToSwitchRefundResponse(tmmConfig);

        // BalanceEnquiry

        getSwitchToSchemaBalanceEnquiryRequest(tmmConfig);
        getSchemaToSwitchBalanceEnquiryResponse(tmmConfig);

        // Reversal

        getSwitchToSchemaReversalRequest(tmmConfig);
        getSchemaToSwitchReversalResponse(tmmConfig);

        // Void others

        getSwitchToSchemaVoidOthersRequest(tmmConfig);
        getSchemaToSwitchVoidOthersResponse(tmmConfig);

        // Void refund

        getSwitchToSchemaVoidRefundRequest(tmmConfig);
        getSchemaToSwitchVoidRefundResponse(tmmConfig);


        // Add money

        getSwitchToSchemeAddMoneyRequest(tmmConfig);
        getSchemeToSwitchAddMoneyResponse(tmmConfig);


        // Balance Update

        getSwitchToSchemeBalanceUpdateRequest(tmmConfig);
        getSchemeToSwitchBalanceUpdateResponse(tmmConfig);
        
        // Service Creation
        
        getSwitchToSchemeServiceCreationRequest(tmmConfig);
        getSchemeToSwitchServiceCreationResponse(tmmConfig);

        //Bqr

        getBqrSwitchToSchemaPurchaseRequest();
        getBqrSchemaToSwitchPurchaseResponse();

        getBqrSwitchToSchemaRefundRequest();
        getBqrSchemaToSwitchRefundResponse();

        getBqrSwitchToSchemaReversalRequest();
        getBqrSchemaToSwitchReversalResponse();

        getBqrSwitchToSchemeStipRequest();
        getBqrSchemeToSwitchStipResponse();

        return tmmConfig;
    }

    private void getSwitchToSchemeSignOnRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        //Conditional Fields - 15,48
        tmmConfig.put(new TransactionTypeConfig("0800", null, TmmConstants.RUPAY_SIGNON_REQUEST), fieldsMap);

    }

    private void getSchemeToSwitchSignOnResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        //Conditional Fields - 15
        tmmConfig.put(new TransactionTypeConfig("0810", null, TmmConstants.RUPAY_SIGNON_RESPONSE), fieldsMap);

    }

    private void getSwitchToSchemaPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional-121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PURCHASE_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,55,62,120
        // Optional - 102,121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PURCHASE_RESPONSE), fieldsMap);


    }


    private void getSwitchToSchemaCashWithdrawlRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional- 121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "01", TmmConstants.CASHWITHDRAWAL_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchCashWithdrawlResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
//        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,23,28,33,38,44,50,51,55,62,120
        // Optional - 54,102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "01", TmmConstants.CASHWITHDRAWAL_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaCashPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional - 121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "01", TmmConstants.CASHATPOS_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchCashPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,23,28,33,38,44,50,51,55,62,120
        // Optional - 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "01", TmmConstants.CASHATPOS_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaPurchaseCashPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional - 121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "09", TmmConstants.PURCHASE_CASHATPOS_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchPurchaseCashPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,55,62,120
        // Optional- 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "09", TmmConstants.PURCHASE_CASHATPOS_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaMotoRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional-121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.MOTO_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchMotoResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,55,62,120
        // Optional - 102,121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.MOTO_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional-121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.REFUND_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,55,62,120
        // Optional - 102,121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.REFUND_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaPreAuthenticationRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,28,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional-121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PREAUTH_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchPreAuthenticationResponse(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,55,62,120
        // Optional - 102,121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PREAUTH_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaBalanceEnquiryRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        //Conditional Fields - 14,23,33,35,40,45,52,55,111,112,113,114,115,116,117,118,119,120,123,124,125,126,127
        // Optional - 121, 122
        tmmConfig.put(new TransactionTypeConfig("0100", "31", TmmConstants.RUPAY_BALANCE_INQUIRY_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchBalanceEnquiryResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 23,33,38,44,55,62,120
        // Optional - 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0110", "31", TmmConstants.RUPAY_BALANCE_INQUIRY_RESPONSE), fieldsMap);

    }


    private void getSwitchToSchemaReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
//        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 23,28,33,38,54,55,95,120
        // Optional - 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0420", null, TmmConstants.REVERSAL_REQUEST), fieldsMap);

    }

    private void getSchemaToSwitchReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,54,55,95,120
        // Optional 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0430", null, TmmConstants.REVERSAL_RESPONSE), fieldsMap);
    }


    private void getSwitchToSchemaVoidOthersRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 23,28,33,38,54,55,95,120
        // Optional - 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0420", null, TmmConstants.VOID_OTHERS_REQUEST), fieldsMap);
    }

    private void getSchemaToSwitchVoidOthersResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,54,55,95,120
        // Optional 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0430", null, TmmConstants.VOID_OTHERS_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemaVoidRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
    //    fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 23,28,33,38,54,55,95,120
        // Optional - 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0420", null, TmmConstants.VOID_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemaToSwitchVoidRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
//        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        //Conditional Fields - 5,6,9,10,15,16,23,28,33,38,44,50,51,54,55,95,120
        // Optional 102, 121, 122
        tmmConfig.put(new TransactionTypeConfig("0430", null, TmmConstants.VOID_REFUND_RESPONSE), fieldsMap);
    }

 
    private void getSwitchToSchemeAddMoneyRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);

    	tmmConfig.put(new TransactionTypeConfig("0100", "28", TmmConstants.ADD_MONEY_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchAddMoneyResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(120, TmmConstants.RESERVED_120);

    	tmmConfig.put(new TransactionTypeConfig("0110", "28", TmmConstants.ADD_MONEY_RESPONSE), fieldsMap);
    }


    private void getSwitchToSchemeBalanceUpdateRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	 fieldsMap.put(2, TmmConstants.PAN);
         fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
         fieldsMap.put(4, TmmConstants.TXN_AMT);
         fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
         fieldsMap.put(11, TmmConstants.STAN);
         fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
         fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
         fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
         fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
         fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
         fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
         fieldsMap.put(23, TmmConstants.CARD_SEQNO);
         fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
         fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
         //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
         fieldsMap.put(35, TmmConstants.TRACK2_DATA);
         fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
         fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
         fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
         fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
         fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
         fieldsMap.put(48, TmmConstants.PRIVATE_AD);
         fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
         fieldsMap.put(52, TmmConstants.PIN);
         fieldsMap.put(55, TmmConstants.ICC_DATA);
         fieldsMap.put(61, TmmConstants.CIAD);

    	tmmConfig.put(new TransactionTypeConfig("0100", "29", TmmConstants.BALANCE_UPDATE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchBalanceUpdateResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);

    	tmmConfig.put(new TransactionTypeConfig("0110", "29", TmmConstants.BALANCE_UPDATE_RESPONSE), fieldsMap);

    }

    
    private void getSwitchToSchemeServiceCreationRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	 fieldsMap.put(2, TmmConstants.PAN);
         fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
         fieldsMap.put(4, TmmConstants.TXN_AMT);
         fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
         fieldsMap.put(11, TmmConstants.STAN);
         fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
         fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
         fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
         fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
         fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
         fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
         fieldsMap.put(23, TmmConstants.CARD_SEQNO);
         fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
         fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
         //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
         fieldsMap.put(35, TmmConstants.TRACK2_DATA);
         fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
         fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
         fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
         fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
         fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
         fieldsMap.put(48, TmmConstants.PRIVATE_AD);
         fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
         fieldsMap.put(52, TmmConstants.PIN);
         fieldsMap.put(55, TmmConstants.ICC_DATA);
         fieldsMap.put(61, TmmConstants.CIAD);

    	tmmConfig.put(new TransactionTypeConfig("0100", "83", TmmConstants.SERVICE_CREATION_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchServiceCreationResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig){
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
    	fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        //fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        //fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        //fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        //fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        //fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        //fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        //fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        //fieldsMap.put(62, TmmConstants.POSTAL_CODE);

    	tmmConfig.put(new TransactionTypeConfig("0110", "83", TmmConstants.SERVICE_CREATION_RESPONSE), fieldsMap);

    }

    /**
     * Bqr
     */
    private void getBqrSwitchToSchemaPurchaseRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        // Mandatory -61, 104
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0200", "26", TmmConstants.BQR_PURCHASE_REQUEST), fieldsMap);

    }

    private void getBqrSchemaToSwitchPurchaseResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //Conditional Fields - 37.
        // Mandatory 43,48,104.
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0210", null, TmmConstants.BQR_PURCHASE_RESPONSE), fieldsMap);


    }

    private void getBqrSwitchToSchemaRefundRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        // Mandatory -61, 104
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0220", "20", TmmConstants.BQR_REFUND_REQUEST), fieldsMap);

    }

    private void getBqrSchemaToSwitchRefundResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //Conditional Fields - 37.
        // Mandatory 43,48,104.
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0220", "20", TmmConstants.BQR_REFUND_RESPONSE), fieldsMap);

    }
    private void getBqrSwitchToSchemaReversalRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        // Mandatory -61, 104
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0400", "26", TmmConstants.BQR_REVERSAL_REQUEST), fieldsMap);

    }

    private void getBqrSchemaToSwitchReversalResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //Conditional Fields - 37.
        // Mandatory 43,48,104.
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.BQR_REVERSAL_RESPONSE), fieldsMap);
    }


    private void getBqrSwitchToSchemeStipRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        // Mandatory -61, 104
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0220", "26", TmmConstants.BQR_STIP_REQUEST), fieldsMap);

    }

    private void getBqrSchemeToSwitchStipResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //Conditional Fields - 37.
        // Mandatory 43,48,104.
        RupayMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0230", null, TmmConstants.BQR_STIP_RESPONSE), fieldsMap);


    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId, TransactionTypeConfig txnTypeConfig,
                                           MessageTransformationConfig msgTransConfig) {
        MessageContext messageContext = super.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
        Object rawMsg = messageContext.getRawMsg();
        if (rawMsg instanceof ISOMsg) {
            byte[] rawMsgBytes;
            try {
                rawMsgBytes = prefixLength(((ISOMsg) rawMsg).pack());
                messageContext.setRawMsg(rawMsgBytes);
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, messageContext.getEpMsgType(),
                        sourceTmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, messageContext.getEpMsgType(),
                        sourceTmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return messageContext;
    }

    public byte[] prefixLength(byte[] pack) {
        byte[] newPack = null;
        String length = Integer.toHexString(pack.length);
        String hexLength = "";
        for (int i = length.length(); i < 4; i++) {
            hexLength += "0";
        }
        hexLength = hexLength + length;
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(ISOUtil.hex2byte(hexLength));
            outputStream.write(pack);
            newPack = outputStream.toByteArray();
        } catch (Exception ex) {
            newPack = pack;
        }
        return newPack;

    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new RupayMessageConstruction();
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        RupayMessageConstruction rupayMessageConstruction = null;
        if (MessageConstructionHelper.isPosVoidRequest(msgType, subMsgType) ||
                MessageConstructionHelper.isReversalRequest(msgType)) {
            rupayMessageConstruction = new VoidReversalRupayMessageConstruction();
        } else {
            switch (srcProcessor) {
                case BQR_SWITCH:
                    rupayMessageConstruction = new BqrRupayMessageConstruction();
                    break;
                default:
                    rupayMessageConstruction = new RupayMessageConstruction();
                    break;
            }
        }
        return rupayMessageConstruction;
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

}
