package com.isg.mw.mtm.parser;

import com.isg.mw.mtm.exception.MessageBuildException;
import com.isg.mw.mtm.parser.msg.BaseMessage;
import com.isg.mw.mtm.parser.msg.Iso8583Message;
import com.isg.mw.mtm.parser.msg.MwMessage;
import com.isg.mw.mtm.rawlog.TxnLogger;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.packager.GenericPackager;
import org.jpos.util.RotateLogListener;

import java.io.InputStream;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MwIsoPackager {

    private static final Logger logger = LogManager.getLogger(MwIsoPackager.class);
    private static final org.jpos.util.Logger jposLogger = new org.jpos.util.Logger();

    static {
        jposLogger.addListener(new RotateLogListener());
    }

    /**
     * Parses the given transaction string using JPOS library and then converts to
     * JSON string.
     *
     * @return Returns the JSON string
     */
    public static MwMessage parse(byte[] msg, InputStream msgFormatStream) {
        Iso8583Message isoMsg = new Iso8583Message();
        try {
            GenericPackager packager = new GenericPackager(msgFormatStream);
            if (!TxnLogger.isEncryptionEnabled())
                packager.setLogger(jposLogger, "debug");
            isoMsg.setPackager(packager);
            int consumedBytes = isoMsg.unpack(msg);
            if (msg.length != consumedBytes) {
                throw new MessageBuildException("Could not consume all the bytes - raw msg bytes: " + msg.length
                        + ", consumed bytes: " + consumedBytes);
            }
        } catch (ISOException e) {
            throw new MessageBuildException("Error while parsing raw message: " + ISOUtil.byte2hex(msg) + " using JPOS",
                    e);
        }
        return isoMsg;
    }

    public static void buildMessage(String targetMsgType, BaseMessage baseMessage, InputStream msgFormatStream) {
        try {
            GenericPackager packager = new GenericPackager(msgFormatStream);
            if (!TxnLogger.isEncryptionEnabled())
                packager.setLogger(jposLogger, "debug");
            baseMessage.setMTI(targetMsgType);
            baseMessage.setPackager(packager);
        } catch (ISOException e) {
            throw new MessageBuildException("Error while packing a message using JPOS", e);
        }
    }
}
