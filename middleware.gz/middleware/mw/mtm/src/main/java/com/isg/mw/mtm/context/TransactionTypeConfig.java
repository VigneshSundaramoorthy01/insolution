package com.isg.mw.mtm.context;

import lombok.Data;

import java.util.Objects;

@Data
public class TransactionTypeConfig {

	/**
	 * MTI of the transaction<br>
	 * e.g 0200, 0210
	 */
	private String epMsgType;

	/**
	 * Processing code of the transaction<br>
	 * e.g. "000000"
	 */
	private String processingCode;

	/**
	 * Name of the transaction<br>
	 * e.g. "purchase", "sale"
	 */
	private String txnTypeName;

    private String apiPath;

    private String httpMethod;

	public TransactionTypeConfig(String epMsgType, String processingCode, String txnTypeName) {
		this.epMsgType = epMsgType;
		this.processingCode = processingCode;
		this.txnTypeName = txnTypeName;
	}

    public TransactionTypeConfig(String epMsgType, String processingCode, String txnTypeName, String apiPath, String httpMethod) {
        this.epMsgType = epMsgType;
        this.processingCode = processingCode;
        this.txnTypeName = txnTypeName;
        this.apiPath = apiPath;
        this.httpMethod = httpMethod;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TransactionTypeConfig that = (TransactionTypeConfig) o;
        return epMsgType.equals(that.epMsgType) && Objects.equals(processingCode, that.processingCode) && txnTypeName.equals(that.txnTypeName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(epMsgType, processingCode, txnTypeName);
    }
}
