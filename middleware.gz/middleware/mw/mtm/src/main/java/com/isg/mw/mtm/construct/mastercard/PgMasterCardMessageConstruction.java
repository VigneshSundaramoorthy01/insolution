package com.isg.mw.mtm.construct.mastercard;

import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import com.isg.mw.mtm.util.TlvAns;

import java.util.ArrayList;
import java.util.List;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isSignOnResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;

public class PgMasterCardMessageConstruction extends MasterCardMessageConstruction {

    private final boolean masterMandate7111 = Boolean.parseBoolean(MTMProperties.getProperty("enable.master.mandate.7111"));
    private final boolean masterMandate6568 = Boolean.parseBoolean(MTMProperties.getProperty("enable.master.mandate.6568"));
    private final boolean masterMandate5524 = Boolean.parseBoolean(MTMProperties.getProperty("enable.master.mandate.5524"));

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */


    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */

    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        String processingCode = this.sourceMsgTypeId;
        String msgTypeId = null;
        switch (processingCode) {
            case "04":
            case "13":
            case "17":
                msgTypeId = "200000";
                break;
            default:
                msgTypeId = "000000";
                break;
        }
        this.targetTmm.setProcessingCode(msgTypeId);
        this.baseMessage.set(fieldNo, msgTypeId);
    }

    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     */

    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */

    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */

    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */

    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */

    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */

    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    @Override
    public void setStan(int fieldNo) {
        String stan = this.sourceTmm.getStan();
        if (StringUtils.isBlank(stan)) {
            super.setStan(fieldNo);
        } else {
            this.targetTmm.setStan(stan);
            this.baseMessage.set(fieldNo, stan);
        }
    }


    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    @Override
    public void setLocalTxnTime(int fieldNo) {
        String localTxnTime = MtmUtil.formatDate("HHmmss");
        if (!StringUtils.isBlank(this.sourceTmm.getLocalTxnTime())) {
            localTxnTime = this.sourceTmm.getLocalTxnTime();
        }
        this.targetTmm.setLocalTxnTime(localTxnTime);
        this.baseMessage.set(fieldNo, localTxnTime);
    }

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */
    @Override
    public void setLocalTxnDate(int fieldNo) {
        String localTxnDate = MtmUtil.formatDate("MMdd");
        if (!StringUtils.isBlank(this.sourceTmm.getLocalTxnDate())) {
            localTxnDate = this.sourceTmm.getLocalTxnDate();
        }
        this.targetTmm.setLocalTxnDate(localTxnDate);
        this.baseMessage.set(fieldNo, localTxnDate);
    }

    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */
    @Override
    public void setExpirationDate(int fieldNo) {
        final String expiryDate = this.sourceTmm.getExpirationDate();
        this.targetTmm.setExpirationDate(expiryDate);
        this.baseMessage.set(fieldNo, expiryDate);
    }

    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */

    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */

    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */

    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */
    @Override
    public void setMerchantType(int fieldNo) {
        String merchantType = this.getSourceTmm().getMerchantType() != null ? this.getSourceTmm().getMerchantType()
                : this.merchantData.getMerchantType();
        this.targetTmm.setMerchantType(merchantType);
        this.baseMessage.set(fieldNo, this.merchantData.getMerchantType());
    }

    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */

    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */

    /**
     * 22. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled
     */
    @Override
    public void setPosEntryMode(int fieldNo) {
        String posEntryMode = null;
        String entryMode = this.sourceTmm.getPosEntryMode();
        if (PgMsgTypeHelper.isReversal(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoReversal(this.sourceMsgType, this.sourceMsgTypeId)) {
            posEntryMode = this.sourceTmm.getOriginalTmm().getPosEntryMode();
        } else {
            posEntryMode = entryMode;
        }
        //For SI and Purchase field 22 pass as it is (810 -> 810 and 100 -> 100) to scheme
        if (PgMsgTypeHelper.isMotoSale(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            posEntryMode = "010";
        } else if (PgMsgTypeHelper.isPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            posEntryMode = "810";
        } else if (PgMsgTypeHelper.isSI(this.sourceMsgType, this.sourceMsgTypeId)) {
            posEntryMode = "100";
        }
        this.targetTmm.setPosEntryMode(posEntryMode);
        this.baseMessage.set(fieldNo, posEntryMode);
    }

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */


    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    @Override
    public void setPosConditionCode(int fieldNo) {
        String posConditionCode = "15";
        if (PgMsgTypeHelper.isMotoSale(this.sourceMsgType, this.sourceMsgTypeId) ||
                PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoReversal(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isSI(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            posConditionCode = "08";
        }
        this.targetTmm.setPosConditionCode(posConditionCode);
        //this.baseMessage.set(fieldNo, posConditionCode);
    }

    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */

    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */

    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */

    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */

    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */

    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */

    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */


    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */


    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     */

    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */

    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {
        if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            String rrnNumber = this.sourceTmm.getRetrievalRefNo();
            this.targetTmm.setRetrievalRefNo(rrnNumber);
            this.baseMessage.set(fieldNo, rrnNumber.getBytes());
        } else
            super.setRetrievalRefNo(fieldNo);
    }

    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */

    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     */

    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */

    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     */

    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     */

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     */

    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */

    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */

    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */

    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */
    @Override
    public void setPrivateAd(int fieldNo) {
        String privateAd = null;
        List<TlvAns> f48 = new ArrayList<>();
        if (TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) || TmmConstants.RES_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType())) {
            if (isSignOnResponse(sourceTmm.getMsgType())) {
                privateAd = sourceTmm.getPrivateAd();
            }
        } else {
            privateAd = buildVRPrivateAd();
        }
//
        this.targetTmm.setPrivateAd(privateAd);
        this.baseMessage.set(fieldNo, privateAd);
    }

    private String buildVRPrivateAd() {
        List<TlvAns> f48 = new ArrayList<>();
        String tcc = this.merchantData.getTerminalCategoryCode();
        String aggregatorFlag = this.merchantData.getAggregatorFlag();

        String field22 =  this.sourceTmm.getPgData().getMultiPurposeMerIndicator();
        if (masterMandate5524
                && field22 != null) {
            StringBuilder subField22Value = new StringBuilder();
            subField22Value.append("05");
            subField22Value.append(StringUtils.padLeftZeros(String.valueOf(field22.length()), 2));
            subField22Value.append(field22);

            f48.add(new TlvAns("22", subField22Value.toString()));
        }

        StringBuilder subField37Value = new StringBuilder();
        if (aggregatorFlag != null && !aggregatorFlag.trim().isEmpty() && aggregatorFlag.equals("Y")) {
            subField37Value.append("01");
            subField37Value.append(this.merchantData.getPaymentFacilitatorId().length());
            subField37Value.append(this.merchantData.getPaymentFacilitatorId());
            subField37Value.append("02");
            subField37Value.append(this.merchantData.getIndependentSaleOrganizationId().length());
            subField37Value.append(this.merchantData.getIndependentSaleOrganizationId());
            subField37Value.append("03");
            subField37Value.append(this.merchantData.getMid().length());
            subField37Value.append(this.merchantData.getMid());
            /*subField37Value.append("04");
            subField37Value.append(StringUtils.padLeftZeros(String.valueOf(this.merchantData.getMerchantCountryCode().length()), 2));
            subField37Value.append(this.merchantData.getMerchantCountryCode());*/
        }

        if (masterMandate6568) {
            if(!(PgMsgTypeHelper.isMoSale(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isMoRefund(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isMoSaleAav(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isMoReversal(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isToSale(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isToRefund(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isToSaleAav(this.sourceMsgType, this.sourceMsgTypeId)
                    || PgMsgTypeHelper.isToReversal(this.sourceMsgType, this.sourceMsgTypeId))) {
                String mpgIdValue = null;
                if (!StringUtils.isBlank(this.sourceTmm.getPgData().getMerchantPaymentGatewayId())) {
                    mpgIdValue = this.sourceTmm.getPgData().getMerchantPaymentGatewayId();
                } else if (!StringUtils.isBlank(this.merchantData.getMpgId())) {
                    mpgIdValue = this.merchantData.getMpgId();
                } else if (!StringUtils.isBlank(this.sourceTmm.getSourceMpgId())) {
                    mpgIdValue = this.sourceTmm.getSourceMpgId();
                }
                subField37Value.append("05");
                subField37Value.append(StringUtils.padLeftZeros(mpgIdValue, 11).length());
                subField37Value.append(StringUtils.padLeftZeros(mpgIdValue, 11));
            }
        }
        f48.add(new TlvAns("37", subField37Value.toString()));

        if (PgMsgTypeHelper.isSI(this.sourceMsgType, this.sourceMsgTypeId)) {
            String field41 = this.sourceTmm.getPgData().getField41();
            if (field41 != null) {
                f48.add(new TlvAns("41", field41));
            }
        }

        String ecomId = this.sourceTmm.getPgData().getEcommerceIndicator();
        String tag42 = null;

        if (masterMandate7111
                && this.sourceTmm.getPgData().getAvv() != null) {
            String firstTwoPosition = this.sourceTmm.getPgData().getAvv().substring(0, 2);
            if (firstTwoPosition.substring(0).equals("h") ||
                    firstTwoPosition.substring(0).equals("j")) {
                tag42 = "0103210";
            } else if (TmmConstants.sli211.contains(firstTwoPosition)) {
                tag42 = "0103211";
            } else if (TmmConstants.sli212.contains(firstTwoPosition)) {
                tag42 = "0103212";
            } else if (TmmConstants.sli214.contains(firstTwoPosition)) {
                //kX , kY , kZ
                tag42 = "0103214";
            } else if (TmmConstants.sli216.contains(firstTwoPosition)) {
                //kN, kU, kV, kW
                tag42 = "0103216";
            } else if (TmmConstants.sli217.contains(firstTwoPosition)) {
                tag42 = "0103217";
            } else {
                tag42 = "0103210";
            }
        } else if (PgMsgTypeHelper.isMotoSale(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            tag42 = "0103210";
        }    else if (ecomId != null) {
            tag42 = "010321" + ecomId.substring(1);
        } else {
            if (this.sourceTmm.getOriginalTmm() != null && this.sourceTmm.getOriginalTmm().getPgData() != null) {
                tag42 = "010321" + this.sourceTmm.getOriginalTmm().getPgData().getEcommerceIndicator().substring(1);
            } else {
                tag42 = "0103210";
            }
        }
        f48.add(new TlvAns("42", tag42));

        if (this.sourceTmm.getPgData().getAvv() != null) {
            f48.add(new TlvAns("43", this.sourceTmm.getPgData().getAvv()));
        }

        String subField48Value = "00001";
        if (PgMsgTypeHelper.isPreAuth(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            subField48Value = "00000";
        }
        f48.add(new TlvAns("61", subField48Value));
        
        if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            String traceId = fetchTraceId(this.originalTmm.getAtmPinOffsetData(), this.originalTmm.getSettlementDate());
            f48.add(new TlvAns("63", traceId));
        }

        if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            String traceId = fetchTraceId(this.originalTmm.getAtmPinOffsetData(), this.originalTmm.getSettlementDate());
            f48.add(new TlvAns("63", traceId));
        }

        if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            String traceId = fetchTraceId(this.originalTmm.getAtmPinOffsetData(), this.originalTmm.getSettlementDate());
            f48.add(new TlvAns("63", traceId));
        }

        if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            String traceId = fetchTraceId(this.originalTmm.getAtmPinOffsetData(), this.originalTmm.getSettlementDate());
            f48.add(new TlvAns("63", traceId));
        }

        StringBuilder subField66Value = new StringBuilder();
        String dsVersion = this.sourceTmm.getPgData().getDsVersion(); //33
        String dsTransactionId = this.sourceTmm.getPgData().getDsTransactionId();//42
        if (dsVersion != null) {
            dsVersion = dsVersion.substring(0, 1);
            subField66Value.append("01");
            subField66Value.append(StringUtils.padLeftZeros(String.valueOf(dsVersion.length()), 2));
            subField66Value.append(dsVersion);
        }
        if (dsTransactionId != null) {
            subField66Value.append("02");
            subField66Value.append(StringUtils.padLeftZeros(String.valueOf(dsTransactionId.length()), 2));
            subField66Value.append(dsTransactionId);
        }

        if (!StringUtils.isBlank(subField66Value.toString())) {
            f48.add(new TlvAns("66", subField66Value.toString()));
        }

        String cvv = this.sourceTmm.getPgData().getCvv2();
        if (this.sourceTmm.getPgData().getCvv2() != null) {
            f48.add(new TlvAns("92", cvv.substring(3, 6)));
        }
        //Following changes has been done because master sale transaction declined on production by resCode=30

//        if (PgMsgTypeHelper.isMotoSale(this.sourceMsgType, this.sourceMsgTypeId) ||
//            PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType,this.sourceMsgTypeId)) {
//                f48.add(new TlvAns("48", "02013"));
//        }else{
//            f48.add(new TlvAns("48", "02012"));
//        }
        return tcc + TlvAns.getBytes(f48);
    }

    private String fetchTraceId(String atmPinOffSet, String settlementDate) {
        return atmPinOffSet + settlementDate + org.apache.commons.lang3.StringUtils.repeat(' ', 2);
    }


    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */
    @Override
    public void setTxnCurrencyCode(int fieldNo) {
        String txnCurrencyCode = this.sourceTmm.getTxnCurrencyCode() != null ? this.sourceTmm.getTxnCurrencyCode()
                : this.merchantData.getAcquirerCurrencyCode();
        this.targetTmm.setTxnCurrencyCode(txnCurrencyCode);
        this.baseMessage.set(fieldNo, txnCurrencyCode);
    }

    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */

    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */

    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */

    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */

    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */

    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */

    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */

    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     */

    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     */
    @Override
    public void setCiad(int fieldNo) {
        String posEntryMode = this.sourceTmm.getPosEntryMode();
        final String merchantZipCode = this.merchantData.getMerchantZipCode();
        String txnCountryCode = this.sourceTmm.getAquirerCountryCode() != null ? this.sourceTmm.getAquirerCountryCode()
                : this.merchantData.getMerchantCountryCode();
        String ciad = "1025110006000" + txnCountryCode;
//        if (PgMsgTypeHelper.isPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
//            ciad = "102511400600" + txnCurrencyCode;
//        }if(PgMsgTypeHelper.isSI(this.sourceMsgType,this.sourceMsgTypeId)){
//            ciad = "102411000600"+txnCurrencyCode;
//        }
        String mastercardPosData = this.sourceTmm.getPgData().getMastercardPosData();
        if (mastercardPosData != null) {
            ciad = mastercardPosData + txnCountryCode;
        }

        if (PgMsgTypeHelper.isMotoSale(this.sourceMsgType, this.sourceMsgTypeId)) {
            if (posEntryMode.equals("810")) {
                ciad = "2032110000000" + txnCountryCode;
            } else if (posEntryMode.equals("100")) {
                ciad = "2033110000000" + txnCountryCode;
            }
        } else if (PgMsgTypeHelper.isPurchase(this.sourceMsgType, this.sourceMsgTypeId)) {
            if (posEntryMode.equals("810") || posEntryMode.equals("100")) {
                ciad = "1025110006000" + txnCountryCode;
            }
        } else if (PgMsgTypeHelper.isSI(this.sourceMsgType, this.sourceMsgTypeId)) {
            if (posEntryMode.equals("100")) {
                ciad = "2034110000000" + txnCountryCode;
            } else if (posEntryMode.equals("810")) {
                ciad = "1024110006000" + txnCountryCode;
            }
        } else if (PgMsgTypeHelper.isPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            ciad = "1025114006000" + txnCountryCode;
        } else if (PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            ciad = "2032110000000" + txnCountryCode;
        } else if (PgMsgTypeHelper.isMotoPreAuth(this.sourceMsgType, this.sourceMsgTypeId)) {
            ciad = "2032114000000" + txnCountryCode;
        }
        ciad += merchantZipCode;
        this.targetTmm.setCiad(ciad);
        this.baseMessage.set(fieldNo, ciad);
    }

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */

    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     */

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */

    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */

    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */

    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */

    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */

    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     */

    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */

    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */

    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */

    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */

    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */

    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */

    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */

    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */

    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */

    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */

    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */

    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */

    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */

    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */

    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */

    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */

    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */

    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */

    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */

    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */

    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */

    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */

    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */

    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */

    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */

    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */

    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */

    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */

    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */

    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */

    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */

    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */


    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */

    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */


    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */

    @Override
    public void setTxnDesc(int fieldNo) {
        if ((this.sourceTmm.getPosEntryMode().equals("100") || this.sourceTmm.getPosEntryMode().equals("810"))
                && this.sourceTmm.getPgData().getTavv() != null) {

            String tavv = "001028" + this.sourceTmm.getPgData().getTavv();

    		this.targetTmm.setTxnDesc(tavv);
    		this.baseMessage.set(fieldNo, tavv);
    	}

    }

    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */

    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */

    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */

    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */

    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */

    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */

    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */

    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */

    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */

    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */

    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */

    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */

    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */

    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */

    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */


    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */


    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */

    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */

    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */

    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */

    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */

    /**
     * 128.<br>
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */
}