package com.isg.mw.mtm.construct;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isAllSchemeReversalRes;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isBatchSettlementRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isBatchUploadRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isOfflineRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isPosVoidResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isPreAuthCompletionRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isReversalRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isSignOnRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isTipAdjustRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isVoidResponse;

import java.util.ArrayList;
import java.util.List;

import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.util.MtmUtil;
import com.isg.mw.mtm.util.TlvAns;

public class DeclineMessageConstruction extends SwitchBaseMessageConstruction {

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */


    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */
    public void setMsgType(int fieldNo) {
        String msgType = this.sourceTmm.getMsgType();
        this.targetTmm.setMsgType(msgType);
    }


    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        if (MessageConstructionHelper.isAllSchemeReversalRes(this.targetMsgType) || MessageConstructionHelper.isBatchUploadRequest(this.sourceTmm.getBatchUploadMsgType())) {
            this.targetTmm.setProcessingCode(this.sourceTmm.getProcessingCode());
            this.baseMessage.set(fieldNo, this.sourceTmm.getProcessingCode());
        } else {
            this.targetTmm.setProcessingCode(this.targetMsgTypeId);
            this.baseMessage.set(fieldNo, this.targetMsgTypeId);
        }
    }

    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     */
    @Override
    public void setTxnAmt(int fieldNo) {
        super.setTxnAmt(fieldNo);
    }

    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */


    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */


    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */


    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */


    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */


    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */


    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    @Override
    public void setStan(int fieldNo) {
        String stan = this.sourceTmm.getStan();
        this.targetTmm.setStan(stan);
        this.baseMessage.set(fieldNo, stan);
        this.targetTmm.setTerminalStan(stan);
    }

    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */


    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */


    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */


    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */
    @Override
    public void setSettlementDate(int fieldNo) {
        // intentionally left blank
    }

    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */


    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */


    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */


    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */
    @Override
    public void setAquirerCountryCode(int fieldNo) {
        // intentionally left blank
    }

    public void setPgTxnRefNo(int fieldNo) {
        String pgTxnRefNo = this.sourceTmm.getPgData().getPgTxnRefNo();
        this.targetTmm.getPgData().setPgTxnRefNo(pgTxnRefNo);
    }

    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */


    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */
    public void setOriginalTxnPgid(int fieldNo) {
        String OriginalTxnPgID = this.sourceTmm.getPgData().getOriginalTxnPgid();
        this.targetTmm.getPgData().setOriginalTxnPgid(OriginalTxnPgID);
    }

    /**
     * 22. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled
     */


    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */


    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */
    @Override
    public void setNiiId(int fieldNo) {
        String niid = this.getSourceTmm().getNiiId();
        this.targetTmm.setNiiId(niid);
        this.baseMessage.set(fieldNo, niid);
    }

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */


    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */


    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */


    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */


    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */
    public void setPgId(int fieldNo) {
        String pgId = this.sourceTmm.getPgData().getPgId();
        this.targetTmm.getPgData().setPgId(pgId);
    }


    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */


    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */


    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    @Override
    public void setAquirerIdCode(int fieldNo) {

    }

    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */


    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */
    public void setBankName(int fieldNo) {
        String bankName = this.sourceTmm.getPgData().getBankName();
        this.targetTmm.getPgData().setBankName(bankName);
    }


    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     */


    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */


    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {
        if (isSignOnRequest(this.sourceMsgType) || isOfflineRequest(this.sourceMsgType, this.sourceMsgTypeId)
                || (isReversalRequest(this.sourceMsgType) || this.sourceTmm.getRetrievalRefNo() == null)
                || isBatchSettlementRequest(this.sourceMsgType, this.sourceMsgTypeId)) {
            super.setRetrievalRefNo(fieldNo);
        } else {
            this.targetTmm.setRetrievalRefNo(this.sourceTmm.getRetrievalRefNo());
            this.baseMessage.set(fieldNo, this.sourceTmm.getRetrievalRefNo());
        }
    }

    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */
    @Override
    public void setAuthIdRes(int fieldNo) {

        if (isTipAdjustRequest(this.sourceMsgType, this.sourceMsgTypeId)
                || isVoidOrReversal()
                || isPosVoidResponse(this.sourceMsgType, this.sourceMsgTypeId)
                || isVoidResponse(this.sourceMsgType)
                || isAllSchemeReversalRes(this.sourceMsgType)) {
            this.targetTmm.setAuthIdRes(this.sourceTmm.getOriginalTmm().getAuthIdRes());
            this.baseMessage.set(fieldNo, this.sourceTmm.getOriginalTmm().getAuthIdRes());

        } else {
            this.targetTmm.setAuthIdRes(this.sourceTmm.getAuthIdRes());
            this.baseMessage.set(fieldNo, this.sourceTmm.getAuthIdRes());
        }
    }

    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     */
    @Override
    public void setResCode(int fieldNo) {
        String resCode = null;
        if (isSignOnRequest(this.sourceMsgType)) {
            resCode = this.targetTmm.getResCode() != null ? this.targetTmm.getResCode() : "00";
        } else {
            resCode = this.sourceTmm.getResCode();
        }
        this.targetTmm.setResCode(resCode);
        this.baseMessage.set(fieldNo, resCode);
    }

    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */


    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     */


    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     */


    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     */


    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */
    @Override
    public void setAdditionalResData(int fieldNo) {
        // intentionally left blank
    }

    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */


    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */


    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */


    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */


    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */


    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */


    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */


    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */


    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */
    @Override
    public void setSecurityControlInfo(int fieldNo) {
        if(this.merchantData != null) {
            this.targetTmm.setSecurityControlInfo(this.merchantData.getKsn());
            this.baseMessage.set(fieldNo, this.merchantData.getKsn());
        }
    }

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */
    @Override
    public void setAdditionalAmounts(int fieldNo) {

    }

    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */
    @Override
    public void setIccData(int fieldNo) {
        String iccData = this.sourceTmm.getIccData();
        /*
         * Reason to convert the data to as is bytes is because JPOS data type is
         * HBINARY
         */
        if (iccData != null) {
            byte[] iccDataBytesAsIs = MtmUtil.toBytesAsIs(iccData);
            this.targetTmm.setIccData(iccData);
            this.baseMessage.set(fieldNo, iccDataBytesAsIs);
        }
    }

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */
    @Override
    public void setReserved56(int fieldNo) {
        // intentionally left blank
    }

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */


    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */


    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */


    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     */


    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     */


    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */
    @Override
    public void setPostalCode(int fieldNo) {

        if (isSignOnRequest(this.sourceMsgType)) {
            HsmVendor hsmVendor = hsmCommonService.getHsmVendorByEntityId(sourceTmm.getEntityId());
            String ipek = SpringContextBridge.getHsmProcessorService(hsmVendor).keyGenerator(this.sourceTmm.getEntityId(), this.sourceTmm.getSource(),
                    this.merchantData.getKsn());

            if (ipek != null) {
                this.targetTmm.setPostalCode(ipek);
                this.targetTmm.setResCode("00");
            } else {
                this.targetTmm.setResCode("96");
            }
            setResCode(39);
            this.baseMessage.set(fieldNo, "");
        } else {
            // ask ramkumar
        }
    }

    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     */
    @Override
    public void setAtmPinOffsetData(int fieldNo) {
        if (isTipAdjustRequest(this.sourceMsgType, this.sourceMsgTypeId)
                || isBatchUploadRequest(this.sourceTmm.getBatchUploadMsgType())) {

            this.targetTmm.setAtmPinOffsetData(this.sourceTmm.getAtmPinOffsetData());
            this.baseMessage.set(fieldNo, this.sourceTmm.getAtmPinOffsetData());

        } else if (isVoidOrReversal()
                || isPosVoidResponse(this.sourceMsgType, this.sourceMsgTypeId)
                || isVoidResponse(this.sourceMsgType)
                || isAllSchemeReversalRes(this.sourceMsgType)) {

            this.targetTmm.setAtmPinOffsetData(this.sourceTmm.getOriginalTmm().getAtmPinOffsetData());
            this.baseMessage.set(fieldNo, this.sourceTmm.getOriginalTmm().getAtmPinOffsetData());

        } else if (isPreAuthCompletionRequest(this.sourceMsgType, this.sourceMsgTypeId)
                || isOfflineRequest(this.sourceMsgType, this.sourceMsgTypeId)) {

            super.setAtmPinOffsetData(fieldNo);
        } else {
            String transactionId = null;
            switch (sourceTmm.getTargetType()) {

                case Master:
                    transactionId = this.sourceTmm.getAtmPinOffsetData();
                    break;

                case Visa:
                    transactionId = this.sourceTmm.getPostalCode();
                    break;

                case Rupay:
                    break;

                default:
                    break;
            }

            if (transactionId != null && transactionId.length() > 16) {
                String substring = transactionId.substring(16);
                transactionId = buildAtmPinOffsetData(substring);
            } else if (transactionId != null) {
                transactionId = buildAtmPinOffsetData(transactionId);
            }

            this.targetTmm.setAtmPinOffsetData(transactionId);
            this.baseMessage.set(fieldNo, transactionId);

        }
    }

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */


    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */


    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */


    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */


    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */


    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     */


    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */


    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */


    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */


    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */


    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */


    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */


    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */


    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */


    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */


    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */


    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */


    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */


    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */


    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */


    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */


    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */


    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */


    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */


    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */


    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */


    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */
    @Override
    public void setOriginalDataElements(int fieldNo) {
        // intentionally left blank
    }

    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */


    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */


    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */


    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */


    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */


    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */


    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */


    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */


    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */


    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */


    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */


    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */


    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */


    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */


    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */


    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */


    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */


    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */


    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */


    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */


    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */


    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */


    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */


    /**
     * 128.<br>
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */
    private String buildAtmPinOffsetData(String transactionId) {
        List<TlvAns> f48 = new ArrayList<>();
        String tcc = transactionId;
        f48.add(new TlvAns("0002", tcc));
        return TlvAns.getBytes(f48);
    }

}