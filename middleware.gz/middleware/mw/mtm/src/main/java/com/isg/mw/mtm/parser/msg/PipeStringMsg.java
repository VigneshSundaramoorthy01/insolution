package com.isg.mw.mtm.parser.msg;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class PipeStringMsg implements MwMessage {
    private String pipeMsg;
}
