package com.isg.mw.mtm.exception;

public class InvalidTxnException extends RuntimeException  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTxnException(String expMsg) {
		super(expMsg);
	}

	public InvalidTxnException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}
