package com.isg.mw.mtm.config;
/**
 * Encrypt Service
 * 
 * @author akshay3978
 *
 */
public interface EncryptService {

	String encrypt(String data);
}
