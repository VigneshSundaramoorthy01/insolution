package com.isg.mw.mtm.transform.tpsl;

import com.fasterxml.uuid.Generators;
import com.isg.mw.cache.mgmt.config.CacheTargetPaymentModeAndOptions;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sr.*;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.model.tpsl.*;
import com.isg.mw.core.utils.IsgCurrencyConversionUtils;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.SHA512Utils;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.BankServerException;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.util.MtmUtil;
import com.tp.pg.util.TransactionRequestBean;
import com.tp.pg.util.TransactionResponseBean;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import static com.isg.mw.core.utils.IsgJsonUtils.removeQuotesAndUnescape;
import static com.isg.mw.mtm.context.MessageTransformationContext.getMessageTransformationConfig;
import static com.isg.mw.mtm.transform.MessageTransformer.identifyTargetTxnTypeConfig;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;

public class TpslMessageTransformation extends BaseMessageTransformation {
    private static final Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();
    private static final String ICICI_PREFIX_FOR_UNIQUE_ID = "ICICI";

    private final Logger logger = LogManager.getLogger(getClass());

    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {
        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }
        prepareTpslTxnTmmConfig();
        return tmmConfig;
    }

    private void prepareTpslTxnTmmConfig() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("Pay", "1", "icici.netbanking.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig("Refund", "1", "icici.netbanking.refund.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig("Reversal", null, "icici.netbanking.reversal.request"), fieldsMap);
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel reqSourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {

        MessageContext msgContext = new MessageContext(reqSourceTmm.getEntityId(), epId, txnTypeConfig.getEpMsgType());
//        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
//        MessageFormatConfigModel msgFormatModel = msgFormatMap.get(txnTypeConfig.getEpMsgType());
        TransactionMessageModel reqTargetTmm = SerializationUtils.clone(reqSourceTmm);
        reqTargetTmm.setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(epId));
        reqTargetTmm.setMsgType(txnTypeConfig.getEpMsgType());
        TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
        if (!StringUtils.isBlank(reqSourceTmm.getSmartRouteData().getEncryptionEnable()) && reqSourceTmm.getSmartRouteData().getEncryptionEnable().equalsIgnoreCase("Y")) {
            reqTargetTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getTpsl().getEncReturnUrl());
        } else {
            reqTargetTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getTpsl().getReturnUrl());
        }
        TransactionRequestBean txnRequestBean = null;
        if (CommonConstants.REFUND_TXN.equalsIgnoreCase(reqSourceTmm.getMsgType())
                || CommonConstants.REVERSAL_TXN.equalsIgnoreCase(reqSourceTmm.getMsgType())) {
//            txnRequestBean = getNetBankingRefundTxnReq(reqTargetTmm, targetAdditionalData);
            getTpslRefundTxnReq(reqTargetTmm, targetAdditionalData, msgContext);
        } else {
            txnRequestBean = getNetBankingTxnRequestBean(reqTargetTmm, targetAdditionalData);
            logger.info("Tpsl Transaction Request : {}", txnRequestBean.toString());
            String transactionToken = txnRequestBean.getTransactionToken();
            logger.info("Tpsl Transaction Token : {}", transactionToken);
            if (transactionToken.startsWith("ERROR")) {
                reqTargetTmm.setResCode("96");
                reqTargetTmm.setDrcrFlag("N");
            } else {
                if (reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REFUND_TXN)
                        || reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN)) {
                    String status = "";
                    String tpsl_txn_id = "";
                    String[] pipeSplit = transactionToken.split("\\|");
                    for (String equalsSplit : pipeSplit) {
                        String[] resKeyVal = equalsSplit.split("=");
                        switch (resKeyVal[0]) {
                            case "txn_status":
                                status = resKeyVal[1];
                                break;
                            case "tpsl_txn_id":
                                tpsl_txn_id = resKeyVal[1];
                                break;
                        }
                    }
                    if (status.equals("0400")) {
                        reqTargetTmm.setResCode("00");
                        reqTargetTmm.setDrcrFlag("C");
                        if (reqSourceTmm.getMsgType().equalsIgnoreCase(CommonConstants.REVERSAL_TXN)) {
                            reqTargetTmm.setDrcrFlag("R");
                        }
                        reqTargetTmm.setTargetTxnId(tpsl_txn_id);
                    } else {
                        reqTargetTmm.setResCode("96");
                        reqTargetTmm.setDrcrFlag("N");
                    }
                } else {
                    reqTargetTmm.setResCode("-1");
                    reqTargetTmm.setDrcrFlag("D");
                }
                reqTargetTmm.getSmartRouteData().setRedirectUrl(transactionToken);
            }
        }
        msgContext.setTransactionMessageModel(reqTargetTmm);
        msgContext.setMessageTransformationConfig(msgTransConfig);
        logger.trace("TPSL request url :: {} "+targetAdditionalData.getApiInfo().getTpsl().getTxnUrl());
        return msgContext;
    }

    private void getTpslRefundTxnReq(TransactionMessageModel reqTargetTmm, TargetAdditionalData targetAdditionalData, MessageContext msgContext) {
        CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqTargetTmm.getTarget());
//        String targetMid = cacheUtil.getTargetMid(targetId, reqTargetTmm.getCardAcceptorId(),reqTargetTmm.getCardAcceptorTerminalId());
        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getCardAcceptorTerminalId());

        TpslRefundRequestModel refundRequestModel = new TpslRefundRequestModel();
        refundRequestModel.getMerchant().setIdentifier(targetMerchantMaster.getTargetMid());
        refundRequestModel.getTransaction().setRequestType("R");
        refundRequestModel.getTransaction().setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(reqTargetTmm.getTxnAmt()));
        refundRequestModel.getTransaction().setCurrency("INR");
        refundRequestModel.getTransaction().setDateTime(MtmUtil.formatDate("dd-MM-yyyy"));
        refundRequestModel.getTransaction().setToken(reqTargetTmm.getOriginalTmm().getTargetTxnId());
        refundRequestModel.getTransaction().setDeviceIdentifier("S");

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("apikey",targetAdditionalData.getApiInfo().getTpsl().getApikey());

        msgContext.setApiHeaders(headers);
        logger.info("TPSL Refund Transaction Headers : {}",headers);
        msgContext.setRawMsg(IsgJsonUtils.getJsonString(refundRequestModel));
        reqTargetTmm.setRawRequest(IsgJsonUtils.getJsonString(refundRequestModel));
        reqTargetTmm.setDrcrFlag("C");
        if(CommonConstants.REVERSAL_TXN.equalsIgnoreCase(reqTargetTmm.getMsgType())){
            reqTargetTmm.setDrcrFlag("R");
        }
        reqTargetTmm.setResCode("-1");
        reqTargetTmm.getSmartRouteData().setRedirectUrl(null);
        reqTargetTmm.setTargetType(TargetType.Tpsl);
    }

    public String getTpslTxnSatusReq(TransactionMessageModel reqTargetTmm, TargetConfigModel targetConfigModel) {
        CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
//        String targetMid = cacheUtil.getTargetMid(targetConfigModel.getId().toString(), reqTargetTmm.getCardAcceptorId(),reqTargetTmm.getCardAcceptorTerminalId());

        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetConfigModel.getId().toString(), reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getCardAcceptorTerminalId());


        TpslCheckTxnStatusRequestModel checkTxnStatusRequestModel = new TpslCheckTxnStatusRequestModel();
        checkTxnStatusRequestModel.getMerchant().setIdentifier(targetMerchantMaster.getTargetMid());
        checkTxnStatusRequestModel.getTransaction().setRequestType("O");
        checkTxnStatusRequestModel.getTransaction().setCurrency("INR");

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        Date date = Date.from(reqTargetTmm.getRequestReceivedTime().toInstant());
        checkTxnStatusRequestModel.getTransaction().setDateTime(formatter.format(date));
        checkTxnStatusRequestModel.getTransaction().setIdentifier(reqTargetTmm.getTransactionId());
        checkTxnStatusRequestModel.getTransaction().setDeviceIdentifier("S");
        String requestJsonStr = IsgJsonUtils.getJsonString(checkTxnStatusRequestModel);
        TargetAdditionalData targetAdditionalData = targetConfigModel.getAdditionalData();
        String host = targetAdditionalData.getApiInfo().getTpsl().getTxnStatusUrl();

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("apikey",targetAdditionalData.getApiInfo().getTpsl().getApikey());
        logger.info("TPSL Check Transaction Status Headers : {}",headers);
        String  res = null;
        try {
            res = callApiUsingWebClient(requestJsonStr, host, headers);
            if(!StringUtils.isBlank(res)){
                res = removeQuotesAndUnescape(res);
                String[] split = res.split(API_RESPONSE_SEPARATOR);
                int status = Integer.parseInt(split[0]);
                res = split[1];
               return res;
            }
        } catch (Exception e) {
            logger.info("Exception while calling target api :: {}", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }


    private TransactionRequestBean getNetBankingTxnRequestBean(TransactionMessageModel reqTargetTmm, TargetAdditionalData targetAdditionalData) {
        TransactionRequestBean objTxnReqBean = new TransactionRequestBean();
        objTxnReqBean.setStrRequestType("T");
        CacheServices cacheService = SpringContextBridge.services().getCacheService();
        MerchantMasterModel merchantMasterModel = cacheService.validateAndGetMerchantMaster(reqTargetTmm.getEntityId(), reqTargetTmm.getCardAcceptorId());
        CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqTargetTmm.getTarget());
//        String targetMid = cacheUtil.getTargetMid(targetId, reqTargetTmm.getCardAcceptorId(),reqTargetTmm.getCardAcceptorTerminalId());
        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getCardAcceptorTerminalId());

        objTxnReqBean.setStrMerchantCode(targetAdditionalData.getApiInfo().getTpsl().getLid());

        objTxnReqBean.setWebServiceLocator(targetAdditionalData.getApiInfo().getTpsl().getTxnUrl());
        objTxnReqBean.setMerchantTxnRefNumber(reqTargetTmm.getTransactionId());
        objTxnReqBean.setAdditionalInfo(reqTargetTmm.getTransactionId());
        BigDecimal amount = getTotalAmountInRupeesIfCCSIinPaisa(reqTargetTmm);
        objTxnReqBean.setStrAmount(amount.toString());
        objTxnReqBean.setStrReturnURL(reqTargetTmm.getSmartRouteData().getReturnUrl());
        // format for shopping cart details is ProductCode_TxnAmount_CommissionAmount
        objTxnReqBean.setStrShoppingCartDetails(targetAdditionalData.getApiInfo().getTpsl().getProductCode() + "_" + amount + "_0.0");
        objTxnReqBean.setTxnDate(MtmUtil.formatDate("dd-MM-yyyy"));
        objTxnReqBean.setStrUniqueCustomerId(reqTargetTmm.getCardAcceptorId());
        PaymentModesModel paymentMode = srCacheService.getPaymentMode(Long.parseLong(reqTargetTmm.getSmartRouteData().getPayModeId()));
        objTxnReqBean.setStrITC("ICICI_ID:"+targetMerchantMaster.getTargetMid()+"~Sector:"+merchantMasterModel.getMerchantSector()+"~transactionId:"+reqTargetTmm.getTransactionId()+"~linkHashId:"+reqTargetTmm.getLinkHashId()
                +"~paymentFamily:"+paymentMode.getPaymentModeName()
                +"~merchantName:"+merchantMasterModel.getMerchantName()
                +"~payOpt:"+reqTargetTmm.getSmartRouteData().getPayOpt()
                +"~origTxnAmt:"+reqTargetTmm.getTxnAmt()
                +"~merchantTxnRefNumber:"+reqTargetTmm.getSmartRouteData().getMerchantTxnRefNo());

        CacheTargetPaymentModeAndOptions tgtPayModeAndOpsData = srCacheService.getTargetPayModeAndOptionsData(reqTargetTmm.getEntityId(), targetId,
                reqTargetTmm.getSmartRouteData().getPayModeId(), reqTargetTmm.getSmartRouteData().getPayModeOptionId());
        TargetPaymentModeOptionsModel targetPaymentModeOptionsModel = tgtPayModeAndOpsData.getTargetPaymentModeOptions().stream().filter(tgtPayModeOpt -> tgtPayModeOpt.getPaymentModeOptionId().toString().equals(reqTargetTmm.getSmartRouteData().getPayModeOptionId())).collect(Collectors.toList()).get(0);
        objTxnReqBean.setStrBankCode(targetPaymentModeOptionsModel.getAdditionalData().getExternalIdentifier());// bank opted code
        objTxnReqBean.setStrMobileNumber(merchantMasterModel.getMerchantMobNo());
        objTxnReqBean.setKey(targetAdditionalData.getApiInfo().getTpsl().getKey().getBytes());
        objTxnReqBean.setIv(targetAdditionalData.getApiInfo().getTpsl().getIv().getBytes());
        try {
            logger.trace("TPSL Request: {} with EncData : {}", objTxnReqBean.getRequestMessage(),objTxnReqBean.getEncData());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return objTxnReqBean;
    }


    public TransactionRequestBean getNetBankingRefundTxnReq(TransactionMessageModel reqTargetTmm, TargetAdditionalData targetAdditionalData) {
        TransactionRequestBean objTransactionRequestBean = new TransactionRequestBean();
        objTransactionRequestBean.setStrRequestType("R");

        CacheUtil cacheUtil = SpringContextBridge.services().getCacheUtil();
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqTargetTmm.getTarget());
//        String targetMid = cacheUtil.getTargetMid(targetId, reqTargetTmm.getCardAcceptorId(),reqTargetTmm.getCardAcceptorTerminalId());
        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqTargetTmm.getCardAcceptorId(), reqTargetTmm.getCardAcceptorTerminalId());
        objTransactionRequestBean.setStrMerchantCode(targetMerchantMaster.getTargetMid());

        objTransactionRequestBean.setWebServiceLocator(targetAdditionalData.getApiInfo().getTpsl().getTxnUrl());
        objTransactionRequestBean.setMerchantTxnRefNumber(reqTargetTmm.getSmartRouteData().getMerchantTxnRefNo());
//        BigDecimal txnAmt = new BigDecimal(reqTargetTmm.getTxnAmt());
//        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        objTransactionRequestBean.setStrAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(reqTargetTmm.getTxnAmt()));
        objTransactionRequestBean.setStrReturnURL(reqTargetTmm.getSmartRouteData().getReturnUrl());
        objTransactionRequestBean.setStrShoppingCartDetails(targetAdditionalData.getApiInfo().getTpsl().getProductCode() + "_" + IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(reqTargetTmm.getTxnAmt()) + "_0.0");
        objTransactionRequestBean.setTxnDate(MtmUtil.formatDate("dd-MM-yyyy"));
        objTransactionRequestBean.setStrUniqueCustomerId(reqTargetTmm.getCardAcceptorId());
        objTransactionRequestBean.setStrTPSLTxnID(reqTargetTmm.getOriginalTmm().getTargetTxnId());
//        objTransactionRequestBean.setAdditionalInfo(reqTargetTmm.getTransactionId());

        CacheTargetPaymentModeAndOptions tgtPayModeAndOpsData = srCacheService.getTargetPayModeAndOptionsData(reqTargetTmm.getEntityId(), targetId,
                reqTargetTmm.getSmartRouteData().getPayModeId(), reqTargetTmm.getSmartRouteData().getPayModeOptionId());
        TargetPaymentModeOptionsModel targetPaymentModeOptionsModel = tgtPayModeAndOpsData.getTargetPaymentModeOptions().stream().filter(tgtPayModeOpt -> tgtPayModeOpt.getPaymentModeOptionId().toString().equals(reqTargetTmm.getSmartRouteData().getPayModeOptionId())).collect(Collectors.toList()).get(0);
        objTransactionRequestBean.setStrBankCode(targetPaymentModeOptionsModel.getAdditionalData().getExternalIdentifier());// bank opted code

        objTransactionRequestBean.setKey(targetAdditionalData.getApiInfo().getTpsl().getKey().getBytes());
        objTransactionRequestBean.setIv(targetAdditionalData.getApiInfo().getTpsl().getIv().getBytes());

        try {
            logger.trace("TPSL Request: {}", objTransactionRequestBean.getEncData());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
//        String transactionToken = objTransactionRequestBean.getTransactionToken();
//        System.out.println("REFUND RESPONSE : " + transactionToken);

        return objTransactionRequestBean;
    }

    @Override
    public TransactionMessageModel parseResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TransactionResponseBean responseBean = new TransactionResponseBean();
        responseBean.setIv(targetConfigModel.getAdditionalData().getApiInfo().getTpsl().getIv().getBytes());
        responseBean.setKey(targetConfigModel.getAdditionalData().getApiInfo().getTpsl().getKey().getBytes());
        String msg = apiTxnModel.getMsg().replace(" ", "+");
        responseBean.setResponsePayload(msg);
        String responsePayload = responseBean.getResponsePayload();
        logger.trace("TPSL Txn Response: {}", responsePayload);

        TransactionMessageModel resTgtTmm = apiTxnModel.buildTmm();
        TransactionMessageModel.TpslData tpslData = resTgtTmm.getSmartRouteData().getTpslData();
        String[] pipeSplit = responsePayload.split("\\|");
        for (String equalsSplit : pipeSplit) {
            String[] resKeyVal = equalsSplit.split("=");
            if (resKeyVal.length > 1) {
                switch (resKeyVal[0]) {
                    case "txn_status":
                        tpslData.setTxnStatus(resKeyVal[1]);
                        if (resKeyVal[1].equals("0300")) {
                            resTgtTmm.setResCode("00");
                        } else {
                            resTgtTmm.setResCode("01");
                            apiTxnModel.setError(resKeyVal[1]);
                        }
                        break;
                    case "txn_msg":
                        tpslData.setTxnMsg(resKeyVal[1]);
                        break;
                    case "txn_err_msg":
                        tpslData.setTxnErrMsg(resKeyVal[1]);
                        break;
                    case "clnt_txn_ref":
                        tpslData.setClientTxnRef(resKeyVal[1]);
                        apiTxnModel.setMerchantTxnRefNo(resKeyVal[1]);
//                        resTgtTmm.setMerchantTxnRefNo(resKeyVal[1]);
                        break;
                    case "tpsl_bank_cd":
                        tpslData.setTpslBankCode(resKeyVal[1]);
                        break;
                    case "tpsl_txn_id":
                        tpslData.setTpslTxnId(resKeyVal[1]);
                        resTgtTmm.setTargetTxnId(resKeyVal[1]);
                        break;
                    case "txn_amt":
                        //resTgtTmm.setTxnAmt(IsgCurrencyConversionUtils.convertRupeesToPaisa(resKeyVal[1]));
                        break;
                    case "clnt_rqst_meta":
                        tpslData.setClientReqMeta(resKeyVal[1]);
                        String mid = getValueFromResKeyVal(resKeyVal[1], "custid");
                        apiTxnModel.setMid(mid);
                        resTgtTmm.setCardAcceptorId(mid);
                        resTgtTmm.setTransactionId((getValueFromResKeyVal(resKeyVal[1], "transactionId")));
                        String linkHashId = getValueFromResKeyVal(resKeyVal[1], "linkHashId");
                        resTgtTmm.setLinkHashId(linkHashId);
                        apiTxnModel.setLinkHashId(linkHashId);
                        String payOpt = getValueFromResKeyVal(resKeyVal[1], "payOpt");
                        apiTxnModel.setPayOpt(payOpt);
                        resTgtTmm.getSmartRouteData().setPayOpt(payOpt);
                        String paymentFamily = getValueFromResKeyVal(resKeyVal[1], "paymentFamily");
                        if (paymentFamily.equalsIgnoreCase("Wallet")) {
                            resTgtTmm.setTransactionName("icici.wallet.response");
                        } else if (paymentFamily.equalsIgnoreCase("Netbanking")) {
                            resTgtTmm.setTransactionName("icici.netbanking.response");
                        }
                        apiTxnModel.setPaymentFamily(paymentFamily);
                        String merchantName = getValueFromResKeyVal(resKeyVal[1], "merchantName");
                        apiTxnModel.setMerchantName(merchantName);
                        String origTxnAmt = getValueFromResKeyVal(resKeyVal[1], "origTxnAmt");
                        resTgtTmm.setTxnAmt(origTxnAmt);
                        String merchantTxnRefNumber = getValueFromResKeyVal(resKeyVal[1], "merchantTxnRefNumber");
                        resTgtTmm.setMerchantTxnRefNo(merchantTxnRefNumber);
                        apiTxnModel.setMerchantTxnRefNo(merchantTxnRefNumber);
                        break;
                    case "tpsl_txn_time":
                        tpslData.setTpslTxnTime(resKeyVal[1]);
                        break;
                    case "tpsl_rfnd_id":
                        tpslData.setTpslRfndId(resKeyVal[1]);
                        break;
                    case "bal_amt":
                        tpslData.setBalAmt(resKeyVal[1]);
                        break;
                    case "rqst_token":
                        tpslData.setRequestToken(resKeyVal[1]);
                        break;
                    case "hash":
                        tpslData.setHash(resKeyVal[1]);
                        break;
                }
            }
        }
        resTgtTmm.setMsgType("Pay");
        resTgtTmm.setDrcrFlag("D");
        resTgtTmm.setResponseReceivedTime(OffsetDateTime.now());
        return resTgtTmm;
    }

    public static String getValueFromResKeyVal(String resKeyVal, String key){
        resKeyVal = resKeyVal.substring(1, resKeyVal.length() - 1); // to crop the first and last bracket
        String[] splitResKeyVal = resKeyVal.split("\\}\\{"); // to get an array of results
        String res = null;
        for (String s : splitResKeyVal) {
            if (s.contains("itc:")) {
                s = s.replace("itc:", "");
            }
            String[] keyValue = s.split("~");
            for (String s1 : keyValue) {
                String[] split = s1.split(":", 2);
                if (split[0].equals(key)) {
                    String value = split[1];
                    return value.equalsIgnoreCase("null") || value.equalsIgnoreCase("")?null:value;
                }
            }
        }
        return res;
    }

    @Override
    public String verifyPaymentStatusByTransactionId(String originalHashedTxnId)  {
        TransactionRequestBean objTxnReqBean = new TransactionRequestBean();
        objTxnReqBean.setStrRequestType("S");
        String status = "Failed";
        try {
            TransactionMessageModel originalTmm;
            try {
                originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(getTransactionMessageModel(originalHashedTxnId));
            } catch (Exception e) {
                logger.trace(e.getMessage());
                return status;
            }
            SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
            String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(originalTmm.getTarget());
//            String targetMid = cacheUtil.getTargetMid(targetId, originalTmm.getCardAcceptorId(),originalTmm.getCardAcceptorTerminalId());
            CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, originalTmm.getCardAcceptorId(), originalTmm.getCardAcceptorTerminalId());
            objTxnReqBean.setStrMerchantCode(targetMerchantMaster.getTargetMid());
            objTxnReqBean.setMerchantTxnRefNumber(originalTmm.getSmartRouteData().getMerchantTxnRefNo());
            objTxnReqBean.setAdditionalInfo(originalTmm.getTransactionId());
            objTxnReqBean.setStrAmount(originalTmm.getTxnAmt());
            objTxnReqBean.setStrReturnURL(originalTmm.getSmartRouteData().getReturnUrl());
            objTxnReqBean.setTxnDate(MtmUtil.formatDate("dd-MM-yyyy"));

            CacheTargetPaymentModeAndOptions tgtPayModeAndOpsData = srCacheService.getTargetPayModeAndOptionsData(originalTmm.getEntityId(), targetId,
                    originalTmm.getSmartRouteData().getPayModeId(), originalTmm.getSmartRouteData().getPayModeOptionId());
            TargetPaymentModeOptionsModel targetPaymentModeOptionsModel = tgtPayModeAndOpsData.getTargetPaymentModeOptions().stream().filter(tgtPayModeOpt -> tgtPayModeOpt.getPaymentModeOptionId().toString().equals(originalTmm.getSmartRouteData().getPayModeOptionId())).collect(Collectors.toList()).get(0);
            objTxnReqBean.setStrBankCode(targetPaymentModeOptionsModel.getAdditionalData().getExternalIdentifier());// bank opted code

            TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(originalTmm.getTransactionName(), originalTmm.getTargetType(), originalTmm.getTarget());
            logger.trace("Fetching MessageTransformationConfig for: {}", txnTypeConfig);
            MessageTransformationConfig msgTransConfig = getMessageTransformationConfig(originalTmm.getEntityId(), originalTmm.getTarget(),
                    txnTypeConfig);
            TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
            objTxnReqBean.setStrShoppingCartDetails(targetAdditionalData.getApiInfo().getTpsl().getProductCode() + "_" + originalTmm.getTxnAmt() + "_0.0");
            objTxnReqBean.setWebServiceLocator(targetAdditionalData.getApiInfo().getTpsl().getTxnUrl());
            objTxnReqBean.setKey(targetAdditionalData.getApiInfo().getTpsl().getKey().getBytes());
            objTxnReqBean.setIv(targetAdditionalData.getApiInfo().getTpsl().getIv().getBytes());
        } catch (Exception e) {
//            throw new RuntimeException(e);
            logger.trace(e.getMessage());
            return status;
        }
        return "Success";
    }


    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return null;
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        return null;
    }

    private TransactionMessageModel getTransactionMessageModel(String hashedTransactionId) {
        TransactionMessageModel model = new TransactionMessageModel();
        model.setOriginalHashedTxnId(hashedTransactionId);
        model.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        return model;
    }

    public void validateResponseErrorCode(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TargetApiInfo.Tpsl tpsl = targetConfigModel.getAdditionalData().getApiInfo().getTpsl();
        if (tpsl != null && !StringUtils.isBlank(tpsl.getTechErrorCodes())) {
            String[] split = tpsl.getTechErrorCodes().split(",");
            Set<String> techErrorCodes = Arrays.stream(split).collect(Collectors.toSet());
            boolean value = techErrorCodes.contains(apiTxnModel.getError());
            if (value) {
                throw new BankServerException("Deliberately failed the transaction due to the bank server issue : ", targetConfigModel.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
            }
        }
    }

    public TpslMerchantRequestModel createMerchant(MerchantMasterModel masterModel,TargetConfigModel targetConfigModel){
        logger.info("Get Tpsl Mapping For Mcc : {}" , masterModel.getMccCode());
        MerchantTypeModel merchantMappingByMcc = getMerchantMappingByMcc(masterModel.getMccCode());
        TpslMerchantRequestModel merReqModel = new TpslMerchantRequestModel();
        merReqModel.setUniqueId(ICICI_PREFIX_FOR_UNIQUE_ID + "T" + masterModel.getMid());
        merReqModel.setMerchantName(masterModel.getMerchantName());
        merReqModel.setMerchantSector(merchantMappingByMcc.getMerchantSector());
        merReqModel.setCorporateAddress(masterModel.getMerchantAddress());
        merReqModel.setCorporateAddressPincode(masterModel.getMerchantPincode().toString());
        merReqModel.setCorporateAddressCountry(masterModel.getCountryName());
        merReqModel.setPurposeOfPG(masterModel.getPurposeOfPG());
        merReqModel.setMerchantPAN(!StringUtils.isBlank(masterModel.getPanNumber()) ? masterModel.getPanNumber() : CacheSrConfigProperties.getProperty("tpsl.default.pan.no"));
        merReqModel.setSignatoryPAN(!StringUtils.isBlank(masterModel.getPanNumber()) ? masterModel.getPanNumber() : CacheSrConfigProperties.getProperty("tpsl.default.signatory.pan.no"));
        merReqModel.setMerchantGSTNo(!StringUtils.isBlank(masterModel.getGstNumber()) ? masterModel.getGstNumber() : CacheSrConfigProperties.getProperty("tpsl.default.gst.no"));
        merReqModel.setContactPerson(masterModel.getContactPerson());
        merReqModel.setTelephone(masterModel.getMerchantMobNo());
        merReqModel.setEmail(masterModel.getMerchantEmail());
        merReqModel.setExpectedNoOfTransactions(masterModel.getExpectedNoOfTransactions());
        merReqModel.setAverageTicketSize("1001 - 5000");
        merReqModel.setMidCategory(merchantMappingByMcc.getMidCategorySmall());
        merReqModel.setRegisteredAddPincode(masterModel.getMerchantPincode().toString());
        merReqModel.setRegisteredAddCountry(masterModel.getCountryName());
        String entityType = getOwnershipTypeByConsCode(masterModel.getOwnershipType(), "tpsl");
        merReqModel.setEntityType(entityType);
        merReqModel.setBusinessType(masterModel.getBusinessType());
        merReqModel.setProductServices(merchantMappingByMcc.getProductService());
        merReqModel.setWebsiteStatus(masterModel.getWebsiteStatus());
        merReqModel.setTermsAndConditions(masterModel.getTermsAndConditions());
        merReqModel.setPrivacyPolicy(masterModel.getPrivacyPolicy());
        merReqModel.setRefundsAndCancellationPolicy(masterModel.getRefundsAndCancellationPolicy());
        merReqModel.setContactDetailsAvailable(masterModel.getContactDetailsAvailable());
        merReqModel.setProductDetailAndPricingStructure(masterModel.getProductDetailAndPricingStructure());
        merReqModel.setMidType(merchantMappingByMcc.getMidType());
        merReqModel.setMerchantURL(!StringUtils.isBlank(masterModel.getMerchantURL()) ? masterModel.getMerchantURL() :"https://icici.ms");
        merReqModel.setLegalRegisteredAddress(masterModel.getMerchantAddress());
        merReqModel.setRegisteredAddPincode(masterModel.getMerchantPincode().toString());
        merReqModel.setCheckSumValue(generateCheckSum(merReqModel,targetConfigModel.getAdditionalData().getApiInfo().getTpsl().getKey()));
//        String jsonString = IsgJsonUtils.getJsonString(merReqModel);

//        Map<String, String> headers = new HashMap<>();
//        headers.put("Content-Type", "application/json");
//
//
//        Object res = callApiUsingWebClient(jsonString, merchantUrl, headers);
//        String resBody = IsgJsonUtils.getJsonString(res);
//        TpslMerchantResponseModel tpslMerResponse = IsgJsonUtils.getObjectFromJsonString(resBody, TpslMerchantResponseModel.class);
//
        return  merReqModel;

    }

//    public static String genrateUniqueId() {
//        UUID uuid = Generators.timeBasedGenerator().generate();
//        return new AtomicLong(uuid.timestamp()).toString();
//    }

    public String generateCheckSum(TpslMerchantRequestModel tpslMerchantRequestModel, String checkSumKey) {
        String reqForCheckSum = tpslMerchantRequestModel.getUniqueId() + "|" + tpslMerchantRequestModel.getMerchantName() + "|" + tpslMerchantRequestModel.getMerchantSector() + "|" + checkSumKey;
        try {
            return SHA512Utils.generateChecksum(reqForCheckSum);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public MerchantTypeModel getMerchantMappingByMcc(String mcc) {
        String url = MTMProperties.getProperty("get.merchant.mapping.by.mcc");
        url = url + "?merchantType=" + mcc;
        logger.info("Calling CM Api To Get Merchant Mapping By Mcc : {} ", url);
        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            ResponseEntity<MerchantTypeModel> exchange = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers),
                    MerchantTypeModel.class);
            HttpStatus statusCode = exchange.getStatusCode();
            if (statusCode == HttpStatus.OK) {
                return exchange.getBody();
            }
            logger.info("Updated Model Successfully In Database With status : {}  and response Body : {} ", statusCode, exchange.getBody());
        } catch (RuntimeException e) {
            logger.error("Failed to post target merchant master model " + e);
        }
        return null;
    }

    @Override
    public TransactionMessageModel parseResponse(String responseBody, TransactionMessageModel tmm, String epId,
                                                 TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        logger.info("Tpsl Response Body : {}",responseBody);
        int status = 200;
        String response = null;
        if(!StringUtils.isBlank(responseBody)){
            responseBody = removeQuotesAndUnescape(responseBody);
            String[] split = responseBody.split(API_RESPONSE_SEPARATOR);
            status = Integer.parseInt(split[0]);
            response = split[1];
        }
        TpslRefundResponseModel tpslResData = null;
        //PtsV2PaymentsPost400Response cybsFailureResponse;
        TransactionMessageModel resSrcTmm = null;
        try {
            switch (status) {
                case 200:
                    if (CommonConstants.REFUND_TXN.equalsIgnoreCase(tmm.getMsgType()) || CommonConstants.REVERSAL_TXN.equalsIgnoreCase(tmm.getMsgType()) ) {
                        tpslResData = IsgJsonUtils.getObjectFromJsonString(response, TpslRefundResponseModel.class);
                        resSrcTmm = getSuccessResSourceTmm(tpslResData, tmm);
                        if (tpslResData != null && (tpslResData.getPaymentMethod().getPaymentTransaction().getStatusCode().equalsIgnoreCase("0400"))) {
                            resSrcTmm.setResCode("00");
                            resSrcTmm.setDrcrFlag("C");
                            resSrcTmm.setTargetTxnId(tpslResData.getPaymentMethod().getPaymentTransaction().getRefundIdentifier());
                            TransactionMessageModel.TpslData tpslData = resSrcTmm.getSmartRouteData().getTpslData();
                            tpslData.setRefundResponseToken(tpslResData.getPaymentMethod().getToken());
                        } else {
                            resSrcTmm.setResCode("96");
                            resSrcTmm.setDrcrFlag("N");
                        }
                    }
                    break;
                case 400:
                    break;
            }

            logger.trace("Tpsl Refund Response: {}", tpslResData);
        } catch (Exception e) {
            logger.error("", e);
        }
        return resSrcTmm;
    }

    private TransactionMessageModel getSuccessResSourceTmm(TpslRefundResponseModel tpslResData, TransactionMessageModel reqSrcTmm) {
        TransactionMessageModel resSourceTmm = new TransactionMessageModel();
        setCommonResponseFields(reqSrcTmm, resSourceTmm);
        return resSourceTmm;
    }

    private void setCommonResponseFields(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSourceTmm) {
        resSourceTmm.setConnectionType(ConnectionType.API);
        resSourceTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resSourceTmm.setTransactionId(reqSrcTmm.getTransactionId());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setMsgType(reqSrcTmm.getMsgType());
        resSourceTmm.setProcessingCode(reqSrcTmm.getProcessingCode());
        resSourceTmm.setSourceProcessor(reqSrcTmm.getSourceProcessor());
        resSourceTmm.setResponseReceivedTime(OffsetDateTime.now());
        resSourceTmm.setAquirerCountryCode(reqSrcTmm.getAquirerCountryCode());
        resSourceTmm.setAquirerIdCode(reqSrcTmm.getAquirerIdCode());
        resSourceTmm.setCardAcceptorId(reqSrcTmm.getCardAcceptorId());
        resSourceTmm.setCardAcceptorTerminalId(reqSrcTmm.getCardAcceptorTerminalId());
        resSourceTmm.setEncryptedExpirationDate(reqSrcTmm.getEncryptedExpirationDate());
        resSourceTmm.setEntityId(reqSrcTmm.getEntityId());
        resSourceTmm.setMerchantType(reqSrcTmm.getMerchantType());
        resSourceTmm.setPosEntryMode(reqSrcTmm.getPosEntryMode());
        resSourceTmm.setResponseSentTime(OffsetDateTime.now());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setTxnAmt(reqSrcTmm.getTxnAmt());
        resSourceTmm.setDrcrFlag(reqSrcTmm.getDrcrFlag());
        resSourceTmm.setTerminalStan(reqSrcTmm.getTerminalStan());
        resSourceTmm.setStan(reqSrcTmm.getStan());
        resSourceTmm.setEncryptedPan(reqSrcTmm.getEncryptedPan());
        resSourceTmm.setMaskedPan(reqSrcTmm.getMaskedPan());
        resSourceTmm.setCardAcceptorInfo(reqSrcTmm.getCardAcceptorInfo());
        resSourceTmm.setForwardingInstIdCode(reqSrcTmm.getForwardingInstIdCode());
        resSourceTmm.setSettlementCurrenyCode(reqSrcTmm.getSettlementCurrenyCode());
        resSourceTmm.setSource(reqSrcTmm.getTarget());
        resSourceTmm.setTarget(reqSrcTmm.getSource());
        resSourceTmm.setTransactionName(reqSrcTmm.getTransactionName().replace("request", "response"));
        resSourceTmm.setTargetType(reqSrcTmm.getTargetType());
        resSourceTmm.setPgData(reqSrcTmm.getPgData());
        resSourceTmm.setTerminalBatchNo(reqSrcTmm.getTerminalBatchNo());
        resSourceTmm.setSmartRouteData(reqSrcTmm.getSmartRouteData());
        resSourceTmm.setTxnCurrencyCode(reqSrcTmm.getTxnCurrencyCode());
        resSourceTmm.setMerchantTxnRefNo(reqSrcTmm.getMerchantTxnRefNo());
        resSourceTmm.setOriginalTransactionId(reqSrcTmm.getOriginalTransactionId());
    }

    public static BigDecimal getTotalAmountInPaisaIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = new BigDecimal(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = new BigDecimal(tmmModel.getConvenienceFee());
        BigDecimal cgst = new BigDecimal(tmmModel.getCgst());
        BigDecimal sgst = new BigDecimal(tmmModel.getSgst());
        BigDecimal igst = new BigDecimal(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return new BigDecimal(amount.setScale(2,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString());
    }

    public static BigDecimal getTotalAmountInRupeesIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getConvenienceFee());
        BigDecimal cgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getCgst());
        BigDecimal sgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getSgst());
        BigDecimal igst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return amount.setScale(2,RoundingMode.HALF_UP);
    }

    public String callApiUsingWebClient(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Request Body: {}", url, body);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new BankServerException("Target is not responding");
        }
        //To test TimeOut Reversal
        /*if(url.equals("https://apitest.cybersource.com/pts/v2/payments")){
            throw new TargetNoResponseException("Target is not responding");
        }*/
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

}
