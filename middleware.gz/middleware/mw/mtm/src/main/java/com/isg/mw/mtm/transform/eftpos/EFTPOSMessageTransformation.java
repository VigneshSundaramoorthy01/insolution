package com.isg.mw.mtm.transform.eftpos;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.KeyModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.eftpos.EFTPOSMessageConstruction;
import com.isg.mw.mtm.construct.eftpos.ReversalEFTPOSMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.IMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class EFTPOSMessageTransformation extends BaseMessageTransformation implements IMessageTransformation {
    private static final Logger logger = LogManager.getLogger(EFTPOSMessageTransformation.class);
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        EFTPOSMessageConstruction eftposc = null;
        if (MessageConstructionHelper.isReversalRequest(msgType)) {
            eftposc = new ReversalEFTPOSMessageConstruction();
        } else {
            eftposc = new EFTPOSMessageConstruction();
        }
        return eftposc;
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId, TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
    	MessageContext msgContext = super.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
        if (msgContext.getRawMsg() instanceof ISOMsg) {
            ISOMsg isoMsg = (ISOMsg) msgContext.getRawMsg();
            byte[] pack;
            try {
                pack = isoMsg.pack();

                // MAC Data Not Required For Sign-On and Key change
                if(!(sourceTmm.getMsgType().equals("0800")) && !(sourceTmm.getMsgType().equals("0820"))) {
                    String rawMsg = ISOUtil.byte2hex(pack);
                    String macFiledValue = rawMsg.substring(0, rawMsg.length() - 16);
                    logger.info("Original Mac Field Value: {}", macFiledValue);

                    String dynamicKey = null;
                    String macValue = null;
                    EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1));
                    KeyModel keyModel = eftposKeyModel.getTargetKey().entrySet().stream().filter(e -> e.getKey().equals(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1))).map(Map.Entry::getValue).findFirst().orElse(null);
                    dynamicKey = keyModel.getZakUnderLMK();

                    if(sourceTmm.getMsgType().equals("0221") || sourceTmm.getMsgType().equals("0421")) {
                    	//Below logic was done when the position of MTI was known and is coming first in Data.
                    	String repeatMacFiledValue = macFiledValue.substring(0, 3)+"0"+ macFiledValue.substring(4, macFiledValue.length()) ;
                        HsmVendor hsmVendor = SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(sourceTmm.getEntityId());
                        macValue = SpringContextBridge.getHsmProcessorService(hsmVendor).generateMacForEFTPOS(sourceTmm.getEntityId(), TmmConstants.EFTPOS_SCHEME_TYPE, repeatMacFiledValue, sourceTmm.getTarget(), dynamicKey);
                    	logger.info("Updated Mac Field Value: {}", macFiledValue);
                    } else {
                        HsmVendor hsmVendor = SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(sourceTmm.getEntityId());
                        macValue = SpringContextBridge.getHsmProcessorService(hsmVendor).generateMacForEFTPOS(sourceTmm.getEntityId(), TmmConstants.EFTPOS_SCHEME_TYPE, macFiledValue, sourceTmm.getTarget(), dynamicKey);
                    }

                    String macData =  macValue.substring(8, macValue.length());
                    String data = StringUtils.rightPad(macData, 16, "0");
                    rawMsg = macFiledValue + data;
                    pack = ISOUtil.hex2byte(rawMsg);

                }
                byte[] finalMsg = prefixLength(pack);
                msgContext.setRawMsg(finalMsg);
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(), sourceTmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(), sourceTmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return msgContext;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new EFTPOSMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 4;
    }

    public byte[] prefixLength(byte[] pack) {
        byte[] newPack = null;
        String length = Integer.toHexString(pack.length);
        StringBuilder hexLength = new StringBuilder();
        for (int i = length.length(); i < 4; i++) {
            hexLength.append("0");
        }
        hexLength = hexLength.append(length);
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(ISOUtil.hex2byte(hexLength.toString()));
            outputStream.write(pack);
            newPack = outputStream.toByteArray();
        } catch (Exception ex) {
            newPack = pack;
        }
        return newPack;
    }

    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        /**
         * Switch To Scheme Sign-on Request and Scheme To Switch Sign-on Response
         */
        buildSignOnRequest(tmmConfig);
        buildSignOnResponse(tmmConfig);

        /**
         * Switch To Scheme Key-Exchange Request and Scheme To Switch Key-Exchange Response
         */
        buildKeyExchangeRequest(tmmConfig);
        buildKeyExchangeResponse(tmmConfig);

        /**
         * Switch To Scheme HeartBeat Request and Scheme To Switch HeartBeat Response
         */
        buildHeartBeatRequest(tmmConfig);
        buildHeartBeatResponse(tmmConfig);


        /**
         * Switch To Scheme Purchase Request and Scheme To Switch Purchase Response
         */
        getSwithToSchemePurchaseRequest(tmmConfig);
        getSchemeToSwitchPurchaseResponse(tmmConfig);

        /**
         * Switch To Scheme Cash@Pos/Sale Request and Scheme To Switch Cash@Pos/Sale Response
         */
        getSwithToSchemeCashAtPosAndPurchaseRequest(tmmConfig);
        getSchemeToSwitchCashAtPosAndPurchaseResponse(tmmConfig);

        /**
         * Switch To Scheme Cash@Pos Request and Scheme To Switch Cash@Pos Response
         */
        getSwithToSchemeCashAtPosRequest(tmmConfig);
        getSchemeToSwitchCashAtPosResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Request and Scheme To Switch Refund Response
         */
        getSwithToSchemeRefundRequest(tmmConfig);
        getSchemeToSwitchRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Reversal Request and Scheme To Switch Reversal Response
         */
        getSwithToSchemeReversalRequest(tmmConfig);
        getSchemeToSwitchReversalResponse(tmmConfig);

        /**
         * Switch To Scheme Repeat Reversal Request and Scheme To Switch Repeat Reversal Response
         */
        getSwithToSchemeRepeatReversalRequest(tmmConfig);
        getSwithToSchemeRepeatReversalResponse(tmmConfig);

        /**
         * Switch To Scheme Advice Purchase Request and Scheme To Switch Advice Purchase Response
         */
        getSwithToSchemeFinancialTransactionAdvicePurchaseRequest(tmmConfig);
        getSchemeToSwitchFinancialTransactionAdvicePurchaseResponse(tmmConfig);

        /**
         * Switch To Scheme Advice Refund Request and Scheme To Switch Advice Refund Response
         */
        getSwithToSchemeFinancialTransactionRefundRequest(tmmConfig);
        getSchemeToSwitchFinancialTransactionRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Advice Reversal Request and Scheme To Switch Advice Reversal Response
         */
        getSwithToSchemeReversalAdviceRepeatRequest(tmmConfig);
        getSchemeToSwitchReversalAdviceRepeatResponse(tmmConfig);

        /**
         * Switch To Scheme Advice Repeat Reversal Request and Scheme To Switch Advice Repeat Reversal Response
         */
        getSwithToSchemeReversalAdviceRequest(tmmConfig);
        getSchemeToSwitchReversalAdviceResponse(tmmConfig);

        /**
         * Switch To Scheme Reconciliation Request and Scheme To Switch Reconciliation Response
         */
        getSwithToSchemeAcquirerReconciliationAdviseRequest(tmmConfig);
        getSchemeToSwitchAcquirerReconciliationAdviseResponse(tmmConfig);

        return tmmConfig;
    }

    private void buildSignOnRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        tmmConfig.put(new TransactionTypeConfig("0800", null, TmmConstants.EFTPOS_SIGNON_REQUEST), fieldsMap);
    }
    private void buildSignOnResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        tmmConfig.put(new TransactionTypeConfig("0810", null, TmmConstants.EFTPOS_SIGNON_RESPONSE), fieldsMap);
    }

    private void buildKeyExchangeRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        tmmConfig.put(new TransactionTypeConfig("0820", null, TmmConstants.EFTPOS_KEYEXCHNAGE_REQUEST), fieldsMap);
    }
    private void buildKeyExchangeResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        tmmConfig.put(new TransactionTypeConfig("0830", null, TmmConstants.EFTPOS_KEYEXCHANGE_RESPONSE), fieldsMap);
    }

    private void buildHeartBeatRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        tmmConfig.put(new TransactionTypeConfig("0800", null, TmmConstants.EFTPOS_HEARTBEAT_REQUEST), fieldsMap);
    }
    private void buildHeartBeatResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        tmmConfig.put(new TransactionTypeConfig("0810", null, TmmConstants.EFTPOS_HEARTBEAT_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemePurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0200", "00", TmmConstants.PURCHASE_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0210", "00", TmmConstants.PURCHASE_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeCashAtPosAndPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0200", "09", TmmConstants.PURCHASE_CASHATPOS_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchCashAtPosAndPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0210", "09", TmmConstants.PURCHASE_CASHATPOS_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0200", "01", TmmConstants.CASHATPOS_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0210", "01", TmmConstants.CASHATPOS_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0200", "20", TmmConstants.REFUND_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0210", "20", TmmConstants.REFUND_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        //fieldsMap.put(52, TmmConstants.PIN); // PIN Not Required for reversal
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0420", "00", TmmConstants.REVERSAL_REQUEST), fieldsMap);
    }

    private void  getSchemeToSwitchReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0430", null, TmmConstants.REVERSAL_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeRepeatReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
       // fieldsMap.put(52, TmmConstants.PIN); // PIN Not Required for reversal
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0421", "00", TmmConstants.EFTPOS_REPEAT_REVERSAL_REQUEST), fieldsMap);
    }

    private void  getSwithToSchemeRepeatReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0430", null, TmmConstants.EFTPOS_REPEAT_REVERSAL_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeFinancialTransactionAdvicePurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES); // DE 38 for future use
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0220", "00", TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchFinancialTransactionAdvicePurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0230", "00", TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeReversalAdviceRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0420", "09", TmmConstants.EFTPOS_REPEAT_REVERSAL_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchReversalAdviceResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0430", "09", TmmConstants.EFTPOS_REPEAT_REVERSAL_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeReversalAdviceRepeatRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0221", "00", TmmConstants.EFTPOS_REPEAT_ADVICE_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchReversalAdviceRepeatResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0230", "09", TmmConstants.EFTPOS_REPEAT_ADVICE_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeFinancialTransactionRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0220", "20", TmmConstants.EFTPOS_FINANCIAL_REFUND_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchFinancialTransactionRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        tmmConfig.put(new TransactionTypeConfig("0230", "20", TmmConstants.EFTPOS_FINANCIAL_REFUND_RESPONSE), fieldsMap);
    }

    private void  getSwithToSchemeAcquirerReconciliationAdviseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
//        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
//        fieldsMap.put(66, TmmConstants.SETTLEMENT_CODE);
        fieldsMap.put(74, TmmConstants.NO_OF_CREDITS);
        fieldsMap.put(75, TmmConstants.CREDITS_REVERSAL_NO);
        fieldsMap.put(76, TmmConstants.NO_OF_DEBITS);
        fieldsMap.put(77, TmmConstants.DEBITS_REVERSAL_NO);
        fieldsMap.put(80, TmmConstants.NO_OF_INQUIRIES);
        fieldsMap.put(81, TmmConstants.NO_OF_AUTHS);
        fieldsMap.put(83, TmmConstants.CREDITS_TXN_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(87, TmmConstants.CREDITS_REVERSAL);
        fieldsMap.put(88, TmmConstants.TOTAL_DEBITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        fieldsMap.put(97, TmmConstants.NET_SETTLEMENT);
        fieldsMap.put(99, TmmConstants.SETTLEMENT_ID_CODE);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0520", null, TmmConstants.EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchAcquirerReconciliationAdviseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(66, TmmConstants.SETTLEMENT_CODE);
        fieldsMap.put(74, TmmConstants.NO_OF_CREDITS);
        fieldsMap.put(75, TmmConstants.CREDITS_REVERSAL_NO);
        fieldsMap.put(76, TmmConstants.NO_OF_DEBITS);
        fieldsMap.put(77, TmmConstants.DEBITS_REVERSAL_NO);
        fieldsMap.put(80, TmmConstants.NO_OF_INQUIRIES);
        fieldsMap.put(81, TmmConstants.NO_OF_AUTHS);
        fieldsMap.put(83, TmmConstants.CREDITS_TXN_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(87, TmmConstants.CREDITS_REVERSAL);
        fieldsMap.put(88, TmmConstants.TOTAL_DEBITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        fieldsMap.put(97, TmmConstants.NET_SETTLEMENT);
        fieldsMap.put(99, TmmConstants.SETTLEMENT_ID_CODE);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0530", null, TmmConstants.EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_RESPONSE), fieldsMap);
    }
    private void  getSwithToSchemeAcquirerReconciliationAdviseRepeatRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(66, TmmConstants.SETTLEMENT_CODE);
        fieldsMap.put(74, TmmConstants.NO_OF_CREDITS);
        fieldsMap.put(75, TmmConstants.CREDITS_REVERSAL_NO);
        fieldsMap.put(76, TmmConstants.NO_OF_DEBITS);
        fieldsMap.put(77, TmmConstants.DEBITS_REVERSAL_NO);
        fieldsMap.put(80, TmmConstants.NO_OF_INQUIRIES);
        fieldsMap.put(81, TmmConstants.NO_OF_AUTHS);
        fieldsMap.put(83, TmmConstants.CREDITS_TXN_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(87, TmmConstants.CREDITS_REVERSAL);
        fieldsMap.put(88, TmmConstants.TOTAL_DEBITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        fieldsMap.put(97, TmmConstants.NET_SETTLEMENT);
        fieldsMap.put(99, TmmConstants.SETTLEMENT_ID_CODE);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0521", null, TmmConstants.EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_REPEAT_REQUEST), fieldsMap);
    }
    private void  getSchemeToSwitchAcquirerReconciliationAdviseRepeatResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(66, TmmConstants.SETTLEMENT_CODE);
        fieldsMap.put(74, TmmConstants.NO_OF_CREDITS);
        fieldsMap.put(75, TmmConstants.CREDITS_REVERSAL_NO);
        fieldsMap.put(76, TmmConstants.NO_OF_DEBITS);
        fieldsMap.put(77, TmmConstants.DEBITS_REVERSAL_NO);
        fieldsMap.put(80, TmmConstants.NO_OF_INQUIRIES);
        fieldsMap.put(81, TmmConstants.NO_OF_AUTHS);
        fieldsMap.put(83, TmmConstants.CREDITS_TXN_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(87, TmmConstants.CREDITS_REVERSAL);
        fieldsMap.put(88, TmmConstants.TOTAL_DEBITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        fieldsMap.put(97, TmmConstants.NET_SETTLEMENT);
        fieldsMap.put(99, TmmConstants.SETTLEMENT_ID_CODE);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        tmmConfig.put(new TransactionTypeConfig("0530", null, TmmConstants.EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_REPEAT_RESPONSE), fieldsMap);
    }
}
