package com.isg.mw.mtm.transform.pg;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.mtm.construct.pg.PgDeclineMessageConstruction;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;

public class PgDeclineMessageTransformation extends BaseMessageTransformation {

	private static final Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

	public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

		if (!tmmConfig.isEmpty()) {
			return tmmConfig;
		}
		getDeclinePgPurchaseResponse(tmmConfig);
		getDeclinePgOnlineRefundResponse(tmmConfig);
		getDeclinePgOfflineRefundResponse(tmmConfig);
		getDeclinePgOnlineOfflineRefundResponse(tmmConfig);
		getDeclinePgPreAuthResponse(tmmConfig);
		getDeclinePgCaptureResponse(tmmConfig);
		getDeclinePgReversalResponse(tmmConfig);
		getDeclinePgSIResponse(tmmConfig);
		getDeclinePgOnlineOfflineRefundResponse(tmmConfig);
		getDeclinePgPreAuthReversalResponse(tmmConfig);
		getDeclinePgMotoSaleResponse(tmmConfig);
		getDeclinePgMotoReversalResponse(tmmConfig);
		getDeclinePgMotoOnlineOfflineRefundResponse(tmmConfig);
        getDeclinePgMoSaleResponse(tmmConfig);
        getDeclinePgMoSaleAavResponse(tmmConfig);
        getDeclinePgToSaleResponse(tmmConfig);
        getDeclinePgToSaleAavResponse(tmmConfig);
		getDeclinePgRPResponse(tmmConfig);
        getDeclinePgRPAavResponse(tmmConfig);
        getDeclinePgSIAmexResponse(tmmConfig);
        getDeclinePgSIAmexAavResponse(tmmConfig);
        getDeclinePgMoRefundResponse(tmmConfig);
        getDeclinePgMoReversalResponse(tmmConfig);
        getDeclinePgToRefundResponse(tmmConfig);
        getDeclinePgToReversalResponse(tmmConfig);
        getDeclinePgMotoPreAuthResponse(tmmConfig);
        getDeclinePgMotoCaptureResponse(tmmConfig);
        getDeclinePgPurchaseAvvResponse(tmmConfig);
        getDeclinePgAvvResponse(tmmConfig);
        getDeclinePgOnlineRefundAvvResponse(tmmConfig);
        getDeclinePgZvavSaleAResponse(tmmConfig);
        getDeclinePgZvavSaleAvvResponse(tmmConfig);
		return tmmConfig;
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "01", "decline.pg.purchase.response"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgPurchaseAvvResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "21", "decline.pg.purchase.avv.response"), fieldsMap);
	}
	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgAvvResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "22", "decline.pg.avv.response"), fieldsMap);
	}
	/**
	 * @param pgTmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
	 */
	private void getDeclinePgOnlineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		pgTmmConfig.put(new TransactionTypeConfig("0230", "12", "decline.pg.online.refund.request"), fieldsMap);
	}


	/**
	 * @param pgTmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
	 */
	private void getDeclinePgOnlineRefundAvvResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		pgTmmConfig.put(new TransactionTypeConfig("0230", "23", "decline.pg.refund.avv.request"), fieldsMap);
	}

	private void getDeclinePgOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0230", "04", "decline.pg.offline.refund.request"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,22,29,34}
	 */
	private void getDeclinePgOnlineOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		pgTmmConfig.put(new TransactionTypeConfig("0230", "13", "decline.pg.online.offline.refund.response"),
				fieldsMap);
	}


	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "02", "decline.pg.preauth.response"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
	 */
	private void getDeclinePgCaptureResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		pgTmmConfig.put(new TransactionTypeConfig("0230", "03", "decline.pg.capture.response"), fieldsMap);
	}


	/**
	 * @param pgTmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
	 */
	private void getDeclinePgReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		pgTmmConfig.put(new TransactionTypeConfig("0410", "05", "decline.pg.reversal.response"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
	 */
	private void getDeclinePgSIResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(4, TmmConstants.PAN);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "11", "decline.pg.si.response"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,18,20,22,33}
	 */
	private void getDeclinePgPreAuthReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();

		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(33, TmmConstants.DS_VERSION);
		pgTmmConfig.put(new TransactionTypeConfig("0110", "14", "decline.pg.preauth.reversal.response"), fieldsMap);
	}

	private void getDeclinePgMotoSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		tmmConfig.put(new TransactionTypeConfig("0210", "15", "decline.pg.moto.sale.response"), fieldsMap);
	}

	private void getDeclinePgMotoReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0410", "16", "decline.pg.moto.reversal.response"), fieldsMap);
	}

	private void getDeclinePgMotoOnlineOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0230", "17", "decline.pg.moto.online.offline.refund.response"),
				fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgRPResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "28", "decline.pg.rp.response"), fieldsMap);
	}


	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgSIAmexResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "01", "decline.pg.si.amex.response"), fieldsMap);
	}
	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgMoSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "18", "decline.pg.mo.sale.response"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgToSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "19", "decline.pg.to.sale.response"), fieldsMap);
	}



	private void getDeclinePgMoRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0230", "20", "decline.pg.mo.refund.response"),
				fieldsMap);
	}

	private void getDeclinePgToRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0230", "24", "decline.pg.to.refund.response"),
				fieldsMap);
	}


	private void getDeclinePgMoReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0410", "25", "decline.pg.mo.reversal.response"), fieldsMap);
	}


	private void getDeclinePgToReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		tmmConfig.put(new TransactionTypeConfig("0410", "26", "decline.pg.to.reversal.response"), fieldsMap);
	}


	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgRPAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "31", "decline.pg.rp.aav.response"), fieldsMap);
	}


	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgSIAmexAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "30", "decline.pg.si.amex.aav.response"), fieldsMap);
	}
	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgMoSaleAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "32", "decline.pg.mo.sale.aav.response"), fieldsMap);
	}

	/**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgToSaleAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "33", "decline.pg.to.sale.aav.response"), fieldsMap);
	}


	 /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getDeclinePgMotoPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(36, TmmConstants.MAC);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        tmmConfig.put(new TransactionTypeConfig("0210", "34", "decline.pg.moto.preauth.response"), fieldsMap);
    }
    
    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getDeclinePgMotoCaptureResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
        fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
        fieldsMap.put(29, TmmConstants.PG_ID);
        fieldsMap.put(34, TmmConstants.BANK_NAME);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(72,TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73,TmmConstants.ACTION_DATE);
        tmmConfig.put(new TransactionTypeConfig("0230", "35", "decline.pg.moto.capture.response"), fieldsMap);
    }
    
    /**
	 * @param pgTmmConfig MandateField
	 *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
	 */
	private void getDeclinePgZvavSaleAResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "36", "decline.pg.zvav.purchase.response"), fieldsMap);
	}
	
	private void getDeclinePgZvavSaleAvvResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
		fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
		fieldsMap.put(11, TmmConstants.STAN);
		fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
		fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
		fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
		fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(18, TmmConstants.CVV_RESULT);
		fieldsMap.put(19, TmmConstants.PG_TXN_REF_NO);
		fieldsMap.put(21, TmmConstants.ORIGINAL_TXN_PGID);
		fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
		fieldsMap.put(29, TmmConstants.PG_ID);
		fieldsMap.put(34, TmmConstants.BANK_NAME);
		fieldsMap.put(36, TmmConstants.MAC);
		pgTmmConfig.put(new TransactionTypeConfig("0210", "37", "decline.pg.zvav.purchase.aav.response"), fieldsMap);
	}

	@Override
	public SwitchBaseMessageConstruction getMessageConstruction() {
		return new PgDeclineMessageConstruction();
	}

	@Override
	public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
		return new PgDeclineMessageConstruction();
	}

	@Override
	public int getDefaultHeaderLength() {
		return 0;
	}

}
