/*
 * jPOS Project [http://jpos.org]
 * Copyright (C) 2000-2020 jPOS Software SRL
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.isg.mw.mtm.parser.prefixer;

import com.isg.mw.mtm.util.MtmUtil;
import org.jpos.iso.Prefixer;

/**
 * BinaryPrefixer constructs a prefix storing the length in binary.
 *
 * @author joconnor
 * @version $Revision$ $Date$
 */
public class ISG_BinaryPrefixer implements Prefixer {
    /**
     * A length prefixer for up to 255 chars. The length is encoded with 1 unsigned byte.
     */
    public static final ISG_BinaryPrefixer B = new ISG_BinaryPrefixer(1);

    /**
     * A length prefixer for up to 65535 chars. The length is encoded with 2 unsigned bytes.
     */
    public static final ISG_BinaryPrefixer BB = new ISG_BinaryPrefixer(2);

    /**
     * The number of digits allowed to express the length
     */
    private int nBytes;

    public ISG_BinaryPrefixer(int nBytes) {
        this.nBytes = nBytes;
    }

    @Override
    public void encodeLength(int length, byte[] b) {
        /*
        Length here comes as a no of bytes in the track2data (always even), currently it is assumed that padding of 0 will always be there,
        because here there is no way to identify whether data contains padding or not.
         */
        length = (length * 2);
        length = length > 37 ? 37 : length;
        String hexLength = Integer.toHexString(length);
        byte[] hexLengthBytes = MtmUtil.toBytesAsIs(hexLength);

        for (int i = nBytes - 1; i >= 0; i--) {
            b[i] = hexLengthBytes[i];
        }
    }

    @Override
    public int decodeLength(byte[] b, int offset) {
        // not tested
        int len = 0;
        for (int i = 0; i < nBytes; i++) {
            len = 256 * len + (b[offset + i] & 0xFF);
        }
        return len;
    }


    @Override
    public int getPackedLength() {
        return nBytes;
    }
}