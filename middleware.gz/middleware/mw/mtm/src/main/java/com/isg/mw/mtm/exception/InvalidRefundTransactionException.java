package com.isg.mw.mtm.exception;

public class InvalidRefundTransactionException  extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public InvalidRefundTransactionException(String errorMsg) {
        super(errorMsg);
    }

    public InvalidRefundTransactionException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}