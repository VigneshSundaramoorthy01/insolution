package com.isg.mw.mtm.rawlog.endpoint;

public class Rupay {
}
