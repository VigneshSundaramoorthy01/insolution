package com.isg.mw.mtm.transform.visa;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.visa.*;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.IMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.header.BASE1Header;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author gaurav3539
 */
public class VisaMessageTransformation extends BaseMessageTransformation implements IMessageTransformation {

    private Logger logger = LogManager.getLogger();
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();


    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        /**
         * Switch To Scheme Purchase Request and Scheme To Switch Purchase Response
         */
        getSwitchToSchemePurchaseRequest(tmmConfig);
        getSchemeToSwitchPurchaseResponse(tmmConfig);

        /**
         * Swtch To Scheme Cash Withdrawal Request and Scheme to Switch Cash Withdrawal
         * Response
         */
        getSwitchToSchemeCashWithdrawalRequest(tmmConfig);
        getSchemeToSwitchCashWithdrawalResponse(tmmConfig);

        /**
         * Switch To Scheme Cash Pos Request and Scheme To Switch Cash Pos Response
         */
        getSwitchToSchemeCashAtPosRequest(tmmConfig);
        getSchemeToSwitchCashAtPosResponse(tmmConfig);

        /**
         * Switch To Scheme Purchase Cash Pos Request and Scheme To Switch Purchase Cash Pos Response
         */
        getSwitchToSchemePurCashAtPosRequest(tmmConfig);
        getSchemeToSwitchPurCashAtPosResponse(tmmConfig);

        /**
         * Switch to Scheme pre-auth Request and Scheme to Switch pre-auth response
         */
        getSwitchToSchemePreAuthRequest(tmmConfig);
        getSchemeToSwitchPreAuthResponse(tmmConfig);

        /**
         * Switch to Scheme Moto request and Scheme to Switch Moto response
         */
        getSwitchToSchemeMotoRequest(tmmConfig);
        getSchemeToSwithMotoResponse(tmmConfig);

        /**
         * Switch to Scheme balace inq request and Scheme to Switch balance inq response
         */
        getSwitchToSchemeBalanceInqRequest(tmmConfig);
        getSchemeToSwitchBalanceInqResponse(tmmConfig);

        /**
         * Switch To Scheme Signon Request and Scheme To Switch Signon Response
         */
        getSwitchToSchemeSignOnRequest(tmmConfig);
        getSchemeToSwitchSignOnResponse(tmmConfig);

        /**
         * switch to scheme refund request and scheme to switch refund response
         */
        getSwitchToSchemeRefundRequest(tmmConfig);
        getSchemeToSwitchRefundResponse(tmmConfig);

        /**
         * Switch to scheme reversal request and scheme to switch reversal response
         */
        getSwitchToSchemeReversalRequest(tmmConfig);
        getSchemeToSwitchReversalResponse(tmmConfig);

        /**
         * Switch to Scheme void refund request and Scheme to Switch void refund
         * response
         */
        getSwitchToSchemeVoidRefundRequest(tmmConfig);
        getSchemeToSwitchVoidRefundResponse(tmmConfig);

        /**
         * Switch to Scheme void others request and Scheme to Switch void others
         * response
         */
        getSwitchToSchemeVoidOthersRequest(tmmConfig);
        getSchemeToSwitchVoidOthersResponse(tmmConfig);
        
        /**
         * Pg
        */

        /**
         * Switch To Scheme Purchase Request and Scheme To Switch Purchase Response
         */
        getSwitchToSchemePgPurchaseRequest(tmmConfig);
        getSchemeToSwitchPgPurchaseResponse(tmmConfig);


        /**
         * Switch To Scheme PreAuth Request and Scheme To Switch PreAuth Response
         */
        getSwitchToSchemePgPreAuthRequest(tmmConfig);
        getSchemeToSwitchPgPreAuthResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Request and Scheme To Switch Refund Response
         */
        getSwitchToSchemePgOnlineRefundRequest(tmmConfig);
        getSchemeToSwitchPgOnlineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Reversal Request and Scheme To Switch Reversal Response
         */
        getSwitchToSchemePgReversalRequest(tmmConfig);
        getSchemeToSwitchPgReversalResponse(tmmConfig);

        /**
         * Switch To Scheme SI Request and Scheme To Switch SI Response
         */
        getSwitchToSchemePgSIRequest(tmmConfig);
        getSchemeToSwitchPgSIResponse(tmmConfig);

        /**
         * Switch To Scheme OnlineOfflineRefund Request and Scheme To Switch OnlineOfflineRefund Response
         */
        getSwitchToSchemePgOnlineOfflineRefundRequest(tmmConfig);
        getSchemeToSwitchPgOnlineOfflineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme PreAuthReversal Request and Scheme To Switch PreAuthReversal Response
         */
        getSwitchToSchemePgPreAuthReversalRequest(tmmConfig);
        getSchemeToSwitchPgPreAuthReversalResponse(tmmConfig);

        /**
         * Switch To Scheme Moto sale Request and Scheme To Switch Moto sale Response
         */
        getSwitchToSchemeMotoSaleRequest(tmmConfig);
        getSchemeToSwitchMotoSaleResponse(tmmConfig);

        /**
         * Switch To Schemeh Moto Reversal Request and Scheme To Switch Moto Reversal Response
         */
        getSwitchToSchemeMotoReversalRequest(tmmConfig);
        getSchemeToSwitchMotoReversalResponse(tmmConfig);

        /**
         * Switch To Scheme Moto Refund Request and Scheme To Switch Moto Refund Response
         */
        getSwitchToSchemeMotoRefundRequest(tmmConfig);
        getSchemeToSwitchMotoRefundResponse(tmmConfig);
        
        /**
         * Switch To Scheme Moto PreAuth Request and Scheme To Switch Moto PreAuth Response
         */
        getSwitchToSchemePgMotoPreAuthRequest(tmmConfig);
        getSchemeToSwitchPgMotoPreAuthResponse(tmmConfig);

        /**
         * Bqr
        */

        getBqrSwitchToSchemePurchaseRequest();
        getBqrSchemeToSwitchPurchaseResponse();

        getBqrSwitchToSchemeRefundRequest();
        getBqrSchemeToSwitchRefundResponse();

        getBqrSwitchToSchemeReversalRequest();
        getBqrSchemeToSwitchReversalResponse();

        getBqrSwitchToSchemeStipRequest();
        getBqrSchemeToSwitchStipResponse();

        return tmmConfig;
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeSignOnRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);

        tmmConfig.put(new TransactionTypeConfig("0800", null, TmmConstants.VISA_SIGNON_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchSignOnResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);

        tmmConfig.put(new TransactionTypeConfig("0810", null, TmmConstants.VISA_SIGNON_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemePurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//		fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
//		fieldsMap.put(45, TmmConstants.TRACK1_DATA);
//		fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PURCHASE_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PURCHASE_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeCashWithdrawalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "01", TmmConstants.CASHWITHDRAWAL_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchCashWithdrawalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "01", TmmConstants.CASHWITHDRAWAL_RESPONSE), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//		fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.CASHATPOS_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.CASHATPOS_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemePurCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//		fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PURCHASE_CASHATPOS_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchPurCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PURCHASE_CASHATPOS_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeMotoRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//		fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO); // this is conditional, send only when 52 is present
//		fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.MOTO_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwithMotoResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.MOTO_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemePreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PREAUTH_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PREAUTH_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//		fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeBalanceInqRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);

        tmmConfig.put(new TransactionTypeConfig("0100", "30", TmmConstants.BALANCE_INQUIRY_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchBalanceInqResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "30", TmmConstants.BALANCE_INQUIRY_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.REVERSAL_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.REVERSAL_RESPONSE), fieldsMap);

    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeVoidRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.VOID_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchVoidRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.VOID_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSwitchToSchemeVoidOthersRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.VOID_OTHERS_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig
     */
    private void getSchemeToSwitchVoidOthersResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.VOID_OTHERS_RESPONSE), fieldsMap);
    }

    /**
     * @paramtmmConfig MandateField
     * ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getSwitchToSchemePgPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        //fieldsMap.put(0, TmmConstants.PG_LENGTH);
        //fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        pgTmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_PURCHASE_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField
     *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSchemeToSwitchPgPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_PURCHASE_RESPONSE), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField
     *                    ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getSwitchToSchemePgPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        pgTmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_PREAUTH_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField
     *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSchemeToSwitchPgPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_PREAUTH_RESPONSE), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField
     *                    ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getSwitchToSchemePgOnlineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        //fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        pgTmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.PG_ONLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSchemeToSwitchPgOnlineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.PG_ONLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getSwitchToSchemePgOnlineOfflineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        //fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.PG_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSchemeToSwitchPgOnlineOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.PG_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField ={0,1,2,3,4,5,9,10,11,15,19,21,29,34}
     */
    private void getSwitchToSchemePgReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
//        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
//        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
//        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
//        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        pgTmmConfig.put(new TransactionTypeConfig("0400", "00", TmmConstants.PG_REVERSAL_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getSchemeToSwitchPgReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
//        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
//        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38,TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        pgTmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.PG_REVERSAL_RESPONSE), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getSwitchToSchemePgSIRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(126, TmmConstants.RESERVED_126);

        pgTmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_SI_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField
     *                    ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSchemeToSwitchPgSIResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_SI_RESPONSE), fieldsMap);
    }


    /**
     * @param pgTmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,15,18,20,22,34}
     */
    private void getSwitchToSchemePgPreAuthReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(0, TmmConstants.PG_LENGTH);
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(34, TmmConstants.BANK_NAME);

        pgTmmConfig.put(new TransactionTypeConfig("0100", "14", TmmConstants.PG_PREAUTH_REVERSAL_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,18,20,22,33}
     */
    private void getSchemeToSwitchPgPreAuthReversalResponse(
            Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(0, TmmConstants.PG_LENGTH);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "14", TmmConstants.PG_PREAUTH_REVERSAL_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeMotoSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        pgTmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_MOTO_SALE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_MOTO_SALE_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeMotoReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
//        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
//        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51,TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
//        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        tmmConfig.put(new TransactionTypeConfig("0400", "00", TmmConstants.PG_MOTO_REVERSAL_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
//        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
//        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38,TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.PG_MOTO_REVERSAL_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeMotoRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        //fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }
    
    
    /**
     * @param pgTmmConfig MandateField
     *                    ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getSwitchToSchemePgMotoPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
//        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
//        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        pgTmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_MOTO_PREAUTH_REQUEST), fieldsMap);
    }

    /**
     * @param pgTmmConfig MandateField
     *                    ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSchemeToSwitchPgMotoPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> pgTmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        pgTmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_MOTO_PREAUTH_RESPONSE), fieldsMap);
    }

    /*
    Bqr
    */

    private void getBqrSwitchToSchemePurchaseRequest(){
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(21, TmmConstants.PAN_FORWARDING_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(24, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(29, TmmConstants.SETTLEMENT_FEE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(36, TmmConstants.TRACK3_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(46, TmmConstants.ISO_AD);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        fieldsMap.put(65, TmmConstants.EXTENDED_BITMAP_INDICATOR);
        fieldsMap.put(66, TmmConstants.SETTLEMENT_CODE);
        fieldsMap.put(67, TmmConstants.EXTENDED_PAYMENT_CODE);
        fieldsMap.put(68, TmmConstants.RECEIVER_COUNTRY_CODE);
        fieldsMap.put(69, TmmConstants.SETTLEMENT_COUNTRY_CODE);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(71, TmmConstants.MSG_NO);
        fieldsMap.put(72, TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73, TmmConstants.ACTION_DATE);
        fieldsMap.put(74, TmmConstants.NO_OF_CREDITS);
        fieldsMap.put(75, TmmConstants.CREDITS_REVERSAL_NO);
        fieldsMap.put(76, TmmConstants.NO_OF_DEBITS);
        fieldsMap.put(77, TmmConstants.DEBITS_REVERSAL_NO);
        fieldsMap.put(78, TmmConstants.TRANSFER_NO);
        fieldsMap.put(79, TmmConstants.TRANSFER_REVERSAL_NO);
        fieldsMap.put(80, TmmConstants.NO_OF_INQUIRIES);
        fieldsMap.put(81, TmmConstants.NO_OF_AUTHS);
        fieldsMap.put(82, TmmConstants.CREDITS_PROCESSING_FEE);
        fieldsMap.put(83, TmmConstants.CREDITS_TXN_FEE);
        fieldsMap.put(84, TmmConstants.DEBITS_PROCESSING_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(87, TmmConstants.CREDITS_REVERSAL);
        fieldsMap.put(88, TmmConstants.TOTAL_DEBITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(91, TmmConstants.FILE_UPDATE_CODE);
        fieldsMap.put(92, TmmConstants.FILE_SECURITY_CODE);
        fieldsMap.put(93, TmmConstants.RES_INDICATOR);
        fieldsMap.put(94, TmmConstants.SERVICE_INDICATOR);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(96, TmmConstants.MSG_SECUIRTY_CODE);
        fieldsMap.put(97, TmmConstants.NET_SETTLEMENT);
        fieldsMap.put(98, TmmConstants.PAYEE);
        fieldsMap.put(99, TmmConstants.SETTLEMENT_ID_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        fieldsMap.put(101, TmmConstants.FILE_NAME);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(103, TmmConstants.ACCID_2);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(106, TmmConstants.RESERVED_106);
        fieldsMap.put(107, TmmConstants.RESERVED_107);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(109, TmmConstants.RESERVED_109);
        fieldsMap.put(110, TmmConstants.RESERVED_110);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        fieldsMap.put(128, TmmConstants.RESERVED_128);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0200", "26", TmmConstants.BQR_PURCHASE_REQUEST), fieldsMap);


    }

    private void getBqrSchemeToSwitchPurchaseResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0210", "26", TmmConstants.BQR_PURCHASE_RESPONSE), fieldsMap);
    }

    private void getBqrSwitchToSchemeRefundRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0220", "20", TmmConstants.BQR_REFUND_REQUEST), fieldsMap);
    }

    private void getBqrSchemeToSwitchRefundResponse() {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104, TmmConstants.TXN_DESC);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0230", "20", TmmConstants.BQR_REFUND_RESPONSE), fieldsMap);
    }

    private void getBqrSwitchToSchemeReversalRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0400", "26", TmmConstants.BQR_REVERSAL_REQUEST), fieldsMap);

    }

    private void getBqrSchemeToSwitchReversalResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0410", "26", TmmConstants.BQR_REVERSAL_RESPONSE), fieldsMap);

    }

    private void getBqrSwitchToSchemeStipRequest(){
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(104, TmmConstants.TXN_DESC);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0220", "26", TmmConstants.BQR_STIP_REQUEST), fieldsMap);
    }

    private void getBqrSchemeToSwitchStipResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);

        VisaMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0230", "26", TmmConstants.BQR_STIP_RESPONSE), fieldsMap);
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        MessageContext msgContext = super.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
        if (msgContext.getRawMsg() instanceof ISOMsg) {
            ISOMsg isoMsg = (ISOMsg) msgContext.getRawMsg();
            byte[] pack;
            try {
                pack = isoMsg.pack();
                byte[] rawMsgWithBodyHeader = buildHeader(isoMsg, pack.length);
                byte[] bcdRawMsgWithBodyHeader = buildBcdMessage(rawMsgWithBodyHeader);
                msgContext.setRawMsg(bcdRawMsgWithBodyHeader);

                String encryptedRawMsg = TxnLogger.encryptRawMsg(bcdRawMsgWithBodyHeader);
                TlmMessageType tlmMessageType = sourceTmm.getTlmMessageType();
                TransactionMessageModel targetTmm = msgContext.getTransactionMessageModel();
                if (tlmMessageType != null && tlmMessageType.equals(TlmMessageType.REQUEST)) {
                    targetTmm.setRawRequest(encryptedRawMsg);
                } else if (tlmMessageType != null && tlmMessageType.equals(TlmMessageType.RESPONSE)) {
                    targetTmm.setRawResponse(encryptedRawMsg);
                }
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        sourceTmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        sourceTmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return msgContext;
    }

    private byte[] buildHeader(ISOMsg isoMsg, int msgLength) throws ISOException {
        BASE1Header baseHeader = new BASE1Header(MTMProperties.getProperty("target.visa.stationid"), "000000");
        baseHeader.setLen(msgLength);
        isoMsg.setHeader(baseHeader);
        return isoMsg.pack();
    }

    private byte[] buildBcdMessage(final byte[] bcdRawMsgWithBodyHeader) {
        final int totalMsgLength = 4;
        final int startMsgLengthIndex = 3;

        byte[] finalBcdMsgArr = new byte[totalMsgLength + bcdRawMsgWithBodyHeader.length];
        System.arraycopy(bcdRawMsgWithBodyHeader, startMsgLengthIndex, finalBcdMsgArr, 0, totalMsgLength);
        System.arraycopy(bcdRawMsgWithBodyHeader, 0, finalBcdMsgArr, totalMsgLength, bcdRawMsgWithBodyHeader.length);

        return finalBcdMsgArr;
    }

    /*
     * Issue: message length was getting incorrectly calculated while sending the
     * moto transaction
     */
    private byte[] oldbuildBcdMessage(final byte[] bcdRawMsgWithBodyHeader) {
        int intsize2 = bcdRawMsgWithBodyHeader.length / 256;
        int intsize3 = bcdRawMsgWithBodyHeader.length % 256;
        String lenStr = String.format("%c%c", intsize2, intsize3);
        byte[] size1 = lenStr.getBytes();
        logger.trace("size1: ");
        for (byte b : size1)
            logger.trace(b);
        int lengthOfTotalMsgLength = 4;
        byte[] headerBytes = new byte[lengthOfTotalMsgLength];
        headerBytes[0] = size1[0];
        headerBytes[1] = size1[1];
        if (lengthOfTotalMsgLength == 4) {// Visa
            headerBytes[2] = 0;
            headerBytes[3] = 0;
        }

        byte[] finalBcdMsgArr = new byte[headerBytes.length + bcdRawMsgWithBodyHeader.length];
        System.arraycopy(headerBytes, 0, finalBcdMsgArr, 0, headerBytes.length);
        System.arraycopy(headerBytes, 0, bcdRawMsgWithBodyHeader, 3, 2);
        System.arraycopy(bcdRawMsgWithBodyHeader, 0, finalBcdMsgArr, headerBytes.length,
                bcdRawMsgWithBodyHeader.length);

        return finalBcdMsgArr;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new VisaMessageConstruction();
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        VisaMessageConstruction mcmc = null;
        if (MessageConstructionHelper.isPosVoidRequest(msgType, subMsgType) ||
        		MessageConstructionHelper.isReversalRequest(msgType)) {
        	switch (srcProcessor) {
        	case PG_SWITCH:
        		mcmc = new PgVoidReversalVisaMessageConstruction();
        		break;
        	default:
        		mcmc = new VoidReversalVisaMessageConstruction();
        		break;
        	}
        } else {
            switch (srcProcessor) {
                case PG_SWITCH:
                    mcmc = new PgVisaMessageConstruction();
                    break;
                case BQR_SWITCH:
                    mcmc = new BqrVisaMessageConstruction();
                    break;
                default:
                    mcmc = new VisaMessageConstruction();
                    break;
            }
        }
        return mcmc;
    }

    @Override
    public int getDefaultHeaderLength() {
        return 52;
    }

    @Override
    public List<Integer> fetchIfeCharFields() {
        return null;
    }

}
