package com.isg.mw.mtm.construct.icici;

import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.utils.IsgCurrencyConversionUtils;
import com.isg.mw.core.utils.NumberUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageTransformationContext;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

public class IciciMessageConstruction extends SwitchBaseMessageConstruction implements IMessageConstruction {
    @Override
    public void setIccData(int fieldNo) {
        // ICC data is not required for this implementation

    }

    public String setTxnAmt() {
        String txnAmt = this.sourceTmm.getTxnAmt();
        if (this.sourceTmm.getMsgType().equals(IciciMsgType.UpiRefund.msgType)) {
            Double stringToDouble = NumberUtils.getStringToDouble(txnAmt);
            //txnAmt = String.format("%.2f", stringToDouble/100, 0); need to be change
             txnAmt = String.format("%.2f", stringToDouble, 0);
            this.targetTmm.setTxnAmt(txnAmt);
        } else {
            this.targetTmm.setTxnAmt(txnAmt);
        }
        setCommonData();
        return IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(txnAmt);
    }

    public String setTxnCurrencyCode() {
        String merchantCurrencyCode = this.sourceTmm.getTxnCurrencyCode() != null ? this.sourceTmm.getTxnCurrencyCode()
                : this.merchantData.getAcquirerCurrencyCode();
        this.targetTmm.setTxnCurrencyCode(merchantCurrencyCode);
        return this.targetTmm.getTxnCurrencyCode();
    }

    public void setCardAcceptorTerminalId(int fieldNo) {
        String cardAcceptorId = this.sourceTmm.getCardAcceptorId();
        this.targetTmm.setCardAcceptorId(cardAcceptorId);
    }

    public void setCommonData(){
        setTxnCurrencyCode();
    }
}