package com.isg.mw.mtm.transform;

import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import com.isg.mw.mtm.transform.payu.PayUMessageTransformation;
import com.isg.mw.mtm.transform.tpsl.TpslMessageTransformation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IMessageTransformationFactory {

    private static Logger logger = LogManager.getLogger(IMessageTransformationFactory.class);

    public static IMessageTransformation getMessageTransformation(TargetType targetType) {
        try {
            if (targetType == null)
                return null;
            switch (targetType) {
                case Tpsl:
                    return TpslMessageTransformation.class.newInstance();
                case PayU:
                    return PayUMessageTransformation.class.newInstance();
                case Lyra:
                    return LyraMessageTransformation.class.newInstance();
                default:
                    logger.trace(targetType + " is unknown targetType to get messageTransformation class ");
                    //throw new IllegalArgumentException(targetType + " is unknown targetType to get messageTransformation class ");
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

}
