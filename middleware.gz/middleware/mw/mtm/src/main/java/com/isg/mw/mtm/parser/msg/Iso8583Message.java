package com.isg.mw.mtm.parser.msg;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
public class Iso8583Message extends BaseMessage implements MwMessage {

}
