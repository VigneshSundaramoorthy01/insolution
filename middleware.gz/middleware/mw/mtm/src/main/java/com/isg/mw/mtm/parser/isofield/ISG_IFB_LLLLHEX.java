package com.isg.mw.mtm.parser.isofield;

import org.jpos.iso.BcdPrefixer;
import org.jpos.iso.ISOBinaryFieldPackager;

import com.isg.mw.mtm.parser.interpreter.ISG_HexInterpreter;

public class ISG_IFB_LLLLHEX extends ISOBinaryFieldPackager {

	public ISG_IFB_LLLLHEX() {
        super(ISG_HexInterpreter.INSTANCE, BcdPrefixer.LLLL);
    }
    /**
     * @param len - field len
     * @param description symbolic descrption
     */
    public ISG_IFB_LLLLHEX (int len, String description) {
        super(len, description, ISG_HexInterpreter.INSTANCE, BcdPrefixer.LLLL);
        checkLength(len, 9999);
    }

    @Override
    public void setLength(int len)
    {
        checkLength(len, 9999);
        super.setLength(len);
    }
}
