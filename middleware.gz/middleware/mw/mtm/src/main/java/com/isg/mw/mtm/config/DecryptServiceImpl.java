package com.isg.mw.mtm.config;

import java.util.Arrays;

import javax.crypto.SecretKey;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.isg.mw.core.service.EnvPropertyService;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.security.algorithms.AES;
import com.isg.mw.security.security.Decryptor;

/**
 * Decrypt Service Implementation
 * 
 *
 */
@Service("decryptService")
public class DecryptServiceImpl implements InitializingBean, DecryptService {

	/*public static final String DECRYTION_KEY_PROVIDER_PATH_KEY = "decryption.key.provider.path";
	
	@Autowired
	private EnvPropertyService envPropertyService;

	private Decryptor<RSA, PrivateKey> decryptor;

	@Override
	public void afterPropertiesSet() throws Exception {
		init();
	}

	private void init() {
		String rsaPublicKeyProviderPath = envPropertyService.getPropertyValue(DECRYTION_KEY_PROVIDER_PATH_KEY);
		decryptor = new Decryptor<RSA, PrivateKey>(rsaPublicKeyProviderPath);

	}

	@Override
	public String decrypt(String data) {

		return decryptor.decrypt(data);

	}*/
	
	
	/**
	 * AES DECRYPTION CODE
	 */
	protected static Logger logger = LogManager.getLogger();

	public static final String DECRYPTION_KEY_PROVIDER_PATH_KEY = "decryption.key.provider.path";
	
	public static final String SECRET_KEY_API_URL = "fetch.secret.key.by.config.type";

	@Autowired
	private EnvPropertyService envPropertyService;

	private Decryptor<AES, SecretKey> decryptor;

	@Override
	public void afterPropertiesSet() throws Exception {
		init();
	}

	private void init(){
		String aesSecretKeyProviderPath = envPropertyService.getPropertyValue(DECRYPTION_KEY_PROVIDER_PATH_KEY);
		decryptor = new Decryptor<AES, SecretKey>(aesSecretKeyProviderPath, getSecretKey());
	}

	@Override
	public String decrypt(String data) {
		return decryptor.decrypt(data);

	}
	
	public String getSecretKey() {
		String url = envPropertyService.getPropertyValue(SECRET_KEY_API_URL) + "?configType=SECRET&status=Active";

		logger.info("Calling Tlm Api To Get secret key By config type : {} " , url);
		String secretKey = null;
		try {
			String JWT_KEY = "";
			String USER_NAME_HEADER = "";
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers),
					String.class);
			secretKey = exchange.getBody();
			logger.info("Secret Key Fetched Successfully.");
		} catch (RuntimeException e) {
			logger.error(" Failed to fetch secret key :  " + e);
		}
		if(!StringUtils.isBlank(secretKey)) {
			return secretKey;
		}else{
			logger.info("Secret Key is null");
			return secretKey;
		}
	}

}
