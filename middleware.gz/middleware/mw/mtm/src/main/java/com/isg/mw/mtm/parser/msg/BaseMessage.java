package com.isg.mw.mtm.parser.msg;

import java.util.BitSet;
import java.util.Map;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author juber3709
 *
 */
@Getter
@Setter
public class BaseMessage extends ISOMsg implements MwMessage {

	public BaseMessage() {
	}

	public Map<Integer, Object> getFields() {
		return this.fields;
	}

	public String getBitMap() {
		BitSet bset = (BitSet) this.getValue(-1);
		byte[] bitSet2byte = ISOUtil.bitSet2byte(bset);
		return ISOUtil.hexString(bitSet2byte);
	}

	public String getField(int fieldNo) {
		String val = null;
		Object obj = this.getFields().get(fieldNo);
		if (obj instanceof ISOField) {
			ISOField field = (ISOField) obj;
			val = (String) field.getValue();
		}
		return val;
	}

}
