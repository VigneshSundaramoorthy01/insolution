package com.isg.mw.mtm.transform.bqr;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.rawlog.TxnLogger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.bqr.BqrDeclineMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.header.BASE1Header;

public class BqrDeclineMessageTransformation extends BaseMessageTransformation {

    private static final Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

    private final Logger logger = LogManager.getLogger(getClass());

    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        getPurchaseDeclineResponse(tmmConfig);
        getMasterPurchaseDeclineResponse(tmmConfig);
        getStipDeclineResponse(tmmConfig);
        getMasterStipDeclineResponse(tmmConfig);
        getReversalDeclineResponse(tmmConfig);
        getMasterReversalDeclineResponse(tmmConfig);
        getRefundDeclineResponse(tmmConfig);

        return tmmConfig;

    }

    public void getPurchaseDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
    /*    fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);*/
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(2, TmmConstants.PAN);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(4, TmmConstants.TXN_AMT);
        fieldMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldMap.put(28, TmmConstants.TXN_FEE);
        fieldMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldMap.put(48, TmmConstants.PRIVATE_AD);
        fieldMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldMap.put(62, TmmConstants.POSTAL_CODE);
        fieldMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldMap.put(102, TmmConstants.ACCID_1);
        tmmConfig.put(new TransactionTypeConfig("0210", "26", "decline.bqr.purchase.response"), fieldMap);
    }

    
    public void getMasterPurchaseDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0110", "28", "decline.bqr.purchase.response"), fieldMap);
    }

    public void getStipDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0230", "26", "decline.bqr.stip.response"), fieldMap);

    }
    
    public void getMasterStipDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0130", "28", "decline.bqr.stip.response"), fieldMap);

    }
    
    

    public void getReversalDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0410", null, "decline.bqr.reversal.response"), fieldMap);
    }
    
    
    public void getMasterReversalDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldMap = new LinkedHashMap<>();
        fieldMap.put(1, TmmConstants.BITMAP);
        fieldMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldMap.put(11, TmmConstants.STAN);
        fieldMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldMap.put(24, TmmConstants.NIIID);
        fieldMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldMap.put(39, TmmConstants.RES_CODE);
        fieldMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        tmmConfig.put(new TransactionTypeConfig("0430", "28", "decline.bqr.reversal.response"), fieldMap);
    }
    
    
    private void getRefundDeclineResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
		Map<Integer, String> fieldsMap = new LinkedHashMap<>();
		fieldsMap.put(1, TmmConstants.BITMAP);
		fieldsMap.put(2, TmmConstants.MSG_TYPE);
		fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
		fieldsMap.put(4, TmmConstants.PAN);
		fieldsMap.put(5, TmmConstants.TXN_AMT);
		fieldsMap.put(16, TmmConstants.EXPIRATION_DATE);
		fieldsMap.put(17, TmmConstants.RES_CODE);
		fieldsMap.put(29, TmmConstants.NIIID);
		fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);

		tmmConfig.put(new TransactionTypeConfig("0220", "04", "decline.bqr.refund.response"), fieldsMap);
	}


    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId, TransactionTypeConfig txnTypeConfig,
                                           MessageTransformationConfig msgTransConfig) {

        MessageContext msgContext = super.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
        if (msgContext.getRawMsg() instanceof ISOMsg) {
            ISOMsg isoMsg = (ISOMsg) msgContext.getRawMsg();
            byte[] pack;
            try {
                pack = isoMsg.pack();
                byte[] rawMsgWithBodyHeader = buildHeader(isoMsg, pack.length);
                byte[] bcdRawMsgWithBodyHeader = buildBcdMessage(rawMsgWithBodyHeader);
                msgContext.setRawMsg(bcdRawMsgWithBodyHeader);

                String encryptedRawMsg = TxnLogger.encryptRawMsg(bcdRawMsgWithBodyHeader);
                TlmMessageType tlmMessageType = sourceTmm.getTlmMessageType();
                TransactionMessageModel targetTmm = msgContext.getTransactionMessageModel();
                if (tlmMessageType != null && tlmMessageType.equals(TlmMessageType.REQUEST)) {
                    targetTmm.setRawRequest(encryptedRawMsg);
                } else if (tlmMessageType != null && tlmMessageType.equals(TlmMessageType.RESPONSE)) {
                    targetTmm.setRawResponse(encryptedRawMsg);
                }
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        sourceTmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(),
                        sourceTmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return msgContext;

    }
    private byte[] buildHeader(ISOMsg isoMsg, int msgLength) throws ISOException {
        BASE1Header baseHeader = new BASE1Header(MTMProperties.getProperty("target.visa.stationid"), "000000");
        baseHeader.setLen(msgLength);
        isoMsg.setHeader(baseHeader);
        return isoMsg.pack();
    }

    private byte[] buildBcdMessage(final byte[] bcdRawMsgWithBodyHeader) {
        final int totalMsgLength = 4;
        final int startMsgLengthIndex = 3;

        byte[] finalBcdMsgArr = new byte[totalMsgLength + bcdRawMsgWithBodyHeader.length];
        System.arraycopy(bcdRawMsgWithBodyHeader, startMsgLengthIndex, finalBcdMsgArr, 0, totalMsgLength);
        System.arraycopy(bcdRawMsgWithBodyHeader, 0, finalBcdMsgArr, totalMsgLength, bcdRawMsgWithBodyHeader.length);

        return finalBcdMsgArr;
    }



    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new BqrDeclineMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 14;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        return new BqrDeclineMessageConstruction();
    }

}
