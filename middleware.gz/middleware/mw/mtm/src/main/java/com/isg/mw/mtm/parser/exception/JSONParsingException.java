package com.isg.mw.mtm.parser.exception;

import com.isg.mw.core.model.exception.MWException;

public class JSONParsingException extends MWException {
	
	private static final long serialVersionUID = -8520368308755314448L;

	public JSONParsingException(String message, Throwable cause) {
		super(message, cause);
	}

	public JSONParsingException(String message) {
		super(message);
	}

}