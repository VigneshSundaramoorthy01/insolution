package com.isg.mw.mtm.exception;

public class InvalidVoidOrReversalDataException extends MessageConstructionException {
    public InvalidVoidOrReversalDataException(String expMsg) {
        super(expMsg);
    }

    public InvalidVoidOrReversalDataException(String expMsg, Throwable e) {
        super(expMsg, e);
    }
}
