package com.isg.mw.mtm.transform;

import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;

public interface IMessageTransformation {

    MessageContext constructMessage(TransactionMessageModel tmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig);

    SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor);

    default TransactionMessageModel parseResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {

        return null;
    }

    default TransactionMessageModel parseResponse(String responseBody, TransactionMessageModel tmm, String epId,
                                                  TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        return null;
    }

    default String verifyPaymentStatusByTransactionId(String originalHashedTxnId) {
        return null;
    }

}
