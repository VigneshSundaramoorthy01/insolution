package com.isg.mw.mtm.rawlog;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOComponent;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOUtil;

import com.isg.mw.core.model.constants.MsgFlow;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.mtm.config.EncryptService;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.rawlog.endpoint.Master;
import com.isg.mw.mtm.rawlog.endpoint.Pos;
import com.isg.mw.mtm.rawlog.endpoint.Visa;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmConstants;

import lombok.Getter;

public class TxnLogger {

    private TxnLogger() {
        throw new IllegalStateException("Utility class");
    }

    private static final Logger rawLogger = LogManager.getLogger(MtmConstants.RAW_LOG);

    @Getter
    @Setter
    public static boolean isEncryptionEnabled;

    private static final Map<TargetType, List<Integer>> tgtSpecificFields = new EnumMap<>(TargetType.class);

    static {
        tgtSpecificFields.put(TargetType.Pos, Arrays.asList(60, 61, 62));
        tgtSpecificFields.put(TargetType.Visa, Arrays.asList(62, 126));
        tgtSpecificFields.put(TargetType.Master, Collections.singletonList(54));
    }

    /**
     * <p><b>Key -> Transaction Id @String </b><br>
     * <b>Value -> Txn Detail Msg @StringBuilder </b><br>
     * </p><p><b>Example : </b><br><pre> <b>Key : </b>138498612900740207</pre><pre><b>Value :
     * </b>MSGTYPE [0100] -&gt; DE[2][PRESENT] DE[3][000000] DE[4][000000001000] DE[7][0902013340] DE[11][000664]
     * DE[12][133340] DE[13][0902] DE[18][6010] DE[19][356] DE[22][051] DE[23][000] DE[25][00] DE[32][720455]
     * DE[35][PRESENT] DE[37][124513000664] DE[41][HPYBL007] DE[42][HPYBIJALIP00007]
     * DE[43][VISA TEST CARD           CHENNAI      IN] DE[49][356] DE[52][82E9AB97EC0895DC] DE[53][2001010100000000]
     * DE[55][PRESENT] DE[60][050000100020] DE[63][8000000000]</pre>
     * </p>
     */
    @Getter
    private static Map<String, StringBuilder> logMsgMap = new HashMap<>();

    public static void logRawMsg(MsgFlow msgFlow, byte[] rawMsg) {
        rawLogger.info("[{}] : [{}]", msgFlow, encryptRawMsg(rawMsg));
    }

    public static void logRawMsg(MsgFlow msgFlow, byte[] rawMsg, TransactionMessageModel tmm) {
        rawLogger.info(LogUtils.buildLogMessage(tmm.getEntityId(), tmm.getTarget(), tmm.getMsgType(),
                        tmm.getTransactionId(), tmm.getTransactionName(), "[{}] : [{}]"), msgFlow,
                encryptRawMsg(rawMsg));

        if (MsgFlow.OUTBOUND.equals(msgFlow) && logMsgMap.containsKey(tmm.getTransactionId())) {
            rawLogger.info(LogUtils.buildLogMessage(tmm.getEntityId(), tmm.getTarget(), tmm.getMsgType(),
                    tmm.getTransactionId(), tmm.getTransactionName(), "[{}] : {}"), msgFlow, logMsgMap.remove(tmm.getTransactionId()));
        }
    }

    public static void logTxnDetail(MsgFlow msgFlow, Map<Integer, Object> jposMap, TransactionMessageModel tmm, TransactionMessageModel srcTmm) {

        StringBuilder txnDetailLog = getTxnDetailLogMsg(jposMap, tmm, srcTmm);

        if (MsgFlow.OUTBOUND.equals(msgFlow)) {
            if (!logMsgMap.containsKey(tmm.getTransactionId())) {
                logMsgMap.put(tmm.getTransactionId(), txnDetailLog);
            }
        } else {
            rawLogger.info(LogUtils.buildLogMessage(tmm.getEntityId(), tmm.getTarget(), tmm.getMsgType(),
                    tmm.getTransactionId(), tmm.getTransactionName(), "[{}] : {}"), msgFlow, txnDetailLog);
        }
    }

    private static StringBuilder getTxnDetailLogMsg(Map<Integer, Object> jposMap, TransactionMessageModel tmm, TransactionMessageModel srcTmm) {
        StringBuilder txnDetailLog = new StringBuilder();
        String mti = getMtiFromJposMap(jposMap);
        txnDetailLog.append("MSGTYPE [").append(mti).append("] -> ");

        jposMap.forEach((fieldNo, isoObj) -> {
            Object value;
            if (fieldNo > 0) {
                value = hideSensitiveData(tmm, fieldNo);

                if (value == null) {
                    if (tmm.getTargetType() != null &&
                            checkForExceptionField(tmm.getTargetType(), fieldNo)) {
                        value = jposFieldUsingCustomParser(fieldNo, isoObj, tmm, srcTmm);
                    }

                    value = Optional.ofNullable(value)
                            .orElse(Optional.ofNullable(getFieldFromTmm(tmm, fieldNo))
                                    .orElse(getFieldFromJposMap((ISOComponent) isoObj)));

                }

                txnDetailLog.append("DE[").append(fieldNo).append("][").append(value).append("] ");
            }
        });

        return txnDetailLog;
    }

    public static Object hideSensitiveData(TransactionMessageModel tmm, Integer fieldNo) {
        Object value = null;
        if (TmmConstants.txnSensitiveDataList.contains(fieldNo)) {
            if (fieldNo == TmmConstants.DE_02_PAN) {
                if (!MessageConstructionHelper.isSignOnRequest(tmm.getMsgType()) &&
                        !MessageConstructionHelper.isSignOnResponse(tmm.getMsgType())) {
                    value = Optional.ofNullable(tmm.getMaskedPan()).orElse(MtmConstants.SENSITIVE_DATA_HIDE_ALIAS);
                }
            } else {
                value = MtmConstants.SENSITIVE_DATA_HIDE_ALIAS;
            }
        }
        return value;
    }

    private static String getMtiFromJposMap(Map<Integer, Object> jposMap) {
        ISOField isoMTI = (ISOField) jposMap.get(0);
        return (String) isoMTI.getValue();
    }

    private static Object getFieldFromJposMap(ISOComponent isoObj) {
        Object value = null;

        try {
            value = isoObj.getValue();
        } catch (ISOException e) {
            e.printStackTrace();
        }

        return value;
    }

    public static Object getFieldFromTmm(TransactionMessageModel tmm, Integer fieldNo) {
        Object value = null;
        String methodName = TmmConstants.txnDataElementsForGetAndSet.get(fieldNo);

        try {
            Method declaredMethod = TransactionMessageModel.class.getDeclaredMethod("get" + methodName);
            value = declaredMethod.invoke(tmm);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            e.printStackTrace();
        }

        return value;
    }

    public static boolean checkForExceptionField(TargetType targetType, Integer fieldNo) {
        boolean retVal = false;

        if (tgtSpecificFields.containsKey(targetType)) {
            retVal = tgtSpecificFields.get(targetType).contains(fieldNo);
        }

        return retVal;
    }

    public static Object jposFieldUsingCustomParser(Integer fieldNo, Object isoObj, TransactionMessageModel tgtTmm,
                                                    TransactionMessageModel srcTmm) {
        Object value = null;
        TargetType targetType = tgtTmm.getTargetType();

        if (TargetType.Pos.equals(targetType)) {
            value = callMethodFromEndpoint(fieldNo, isoObj, tgtTmm, srcTmm, Pos.class);
        } else if (TargetType.Visa.equals(targetType)) {
            value = callMethodFromEndpoint(fieldNo, isoObj, tgtTmm, srcTmm, Visa.class);
        } else if (TargetType.Master.equals(targetType)) {
            value = callMethodFromEndpoint(fieldNo, isoObj, tgtTmm, srcTmm, Master.class);
        }
        return value;
    }

    private static Object callMethodFromEndpoint(Integer fieldNo, Object isoObject, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm, Class endpoint) {
        Object value = null;
        String methodName = TmmConstants.txnDataElementsForGetAndSet.get(fieldNo);

        try {
            Method declaredMethod = endpoint.getDeclaredMethod("get" + methodName, Object.class, TransactionMessageModel.class, TransactionMessageModel.class);
            value = declaredMethod.invoke(null, isoObject, tgtTmm, srcTmm);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            e.printStackTrace();
        }

        return value;
    }

    public static void logPgTxnDetail(MsgFlow msgFlow, String rawMsg, TransactionMessageModel tmm) {
        StringBuilder txnDetailLog = getPgTxnDetailLogMsg(rawMsg);
        if (MsgFlow.OUTBOUND.equals(msgFlow)) {
            if (!TxnLogger.getLogMsgMap().containsKey(tmm.getTransactionId())) {
                TxnLogger.getLogMsgMap().put(tmm.getTransactionId(), txnDetailLog);
            } else {
                rawLogger.info(LogUtils.buildLogMessage(tmm.getEntityId(), tmm.getTarget(), tmm.getMsgType(),
                        tmm.getTransactionId(), tmm.getTransactionName(), "[{}] : {}"), msgFlow, txnDetailLog.toString());
                logMsgMap.remove(tmm.getTransactionId());
            }
        } else {
            rawLogger.info(LogUtils.buildLogMessage(tmm.getEntityId(), tmm.getTarget(), tmm.getMsgType(),
                    tmm.getTransactionId(), tmm.getTransactionName(), "[{}] : {}"), msgFlow, txnDetailLog.toString());
        }
    }

    public static StringBuilder getPgTxnDetailLogMsg(String msg) {
        StringBuilder txnDetailLog = new StringBuilder();
        String[] deNoAndDataArr = msg.split("\\|");
        Map<Integer, String> deFieldsMap = new LinkedHashMap<>();
        for (String deNoAndData : deNoAndDataArr) {
            int fieldNo = Integer.parseInt(deNoAndData.split(",")[0]);
            String data = deNoAndData.split(",")[1];
            deFieldsMap.put(fieldNo, data);
        }
        String mti = deFieldsMap.get(2);
        txnDetailLog.append("MSGTYPE [").append(mti).append("] -> ");

        deFieldsMap.forEach((fieldNo, value) -> {
            if (value != null && !value.equals("null")) {
                if (fieldNo == 4)
                    value = MaskingUtility.maskCardNumber(value);
                txnDetailLog.append("DE[").append(fieldNo).append("][").append(value).append("] ");
            }
        });
        return txnDetailLog;
    }

    public static void logPgRawMsg(MsgFlow msgFlow, String rawMsg) {
        if (isEncryptionEnabled())
            rawLogger.info("[{}] : [{}]", msgFlow, encryptRawMsg(rawMsg.getBytes()));
        else
            rawLogger.info("[{}] : [{}]", msgFlow, rawMsg);
    }

    public static String encryptRawMsg(byte[] rawMsgArr) {
        String rawMsg = ISOUtil.byte2hex(rawMsgArr);
        if (isEncryptionEnabled()) {
            EncryptService encryptService = SpringContextBridge.services().getEncryptionService();
            return encryptService.encrypt(rawMsg);
        }
        return rawMsg;
    }

    public static String encryptRawMsg(String rawMsg) {
        if (isEncryptionEnabled()) {
            EncryptService encryptService = SpringContextBridge.services().getEncryptionService();
            return encryptService.encrypt(rawMsg);
        }
        return rawMsg;
    }
}
