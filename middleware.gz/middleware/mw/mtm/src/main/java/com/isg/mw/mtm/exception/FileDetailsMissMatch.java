package com.isg.mw.mtm.exception;

public class FileDetailsMissMatch extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public FileDetailsMissMatch(String expMsg) {
        super(expMsg);
    }

    public FileDetailsMissMatch(String expMsg, Throwable e) {
        super(expMsg, e);
    }

}
