package com.isg.mw.mtm.context;

import java.time.OffsetDateTime;
import java.util.Map;

import com.isg.mw.core.model.tlm.TransactionMessageModel;

import lombok.Data;

/**
 * Message Context for a ongoing transaction either toPojo or
 * constructMessage.<br>
 * Contains all the information of a message.<br>
 * Information like Entity Id, Endpoint Id, Raw Message etc.
 * 
 * @author juber3709
 *
 */
@Data
public class MessageContext {
	/**
	 * Endpoint Entity Id
	 */
	private String entityId;
	/**
	 * Endpoint Id
	 */
	private String epId;
	/**
	 * Endpoint Transaction Message Type
	 */
	private String epMsgType;
	/**
	 * Transaction Raw Message
	 */
	private Object rawMsg;
	/**
	 * Map of fields for the current transformation<br>
	 * key -> Data element no<br>
	 * Value -> Setter method name for the respective data element no.
	 */
	private Map<String, String> apiHeaders;
	/**
	 * TransactionMessageModel for this message
	 */
	private TransactionMessageModel transactionMessageModel;
	/**
	 * Time of arrival or departure.
	 */
	private OffsetDateTime timeOfAction;
	/**
	 * 
	 */
	private MessageTransformationConfig messageTransformationConfig;

	private String txnApiPath;

	private TransactionMessageModel apiTmm;
	
	
	public MessageContext(String entityId, String epId, String epMsgType) {
		this.entityId = entityId;
		this.epId = epId;
		this.epMsgType = epMsgType;
	}

	public MessageContext(String entityId, String epId, String epMsgType, Object rawMsg) {
		this.entityId = entityId;
		this.epId = epId;
		this.epMsgType = epMsgType;
		this.rawMsg = rawMsg;
	}
}
