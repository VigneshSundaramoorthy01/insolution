package com.isg.mw.mtm.transform.mastercard;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.constants.SchemeBin;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.mastercard.*;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.InvalidTxnException;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.IMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MasterCardMessageTransformation extends BaseMessageTransformation implements IMessageTransformation {

    private Logger logger = LogManager.getLogger();
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();


    public TargetType getEpType() {
        return TargetType.Master;
    }

    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        getSwitchToSchemePurchaseRequest(tmmConfig);
        getSchemeToSwitchPurchaseResponse(tmmConfig);

        getSwitchToSchemeCashwithdrawalRequest(tmmConfig);
        getSchemeToSwitchCashwithdrawalResponse(tmmConfig);

        getSwitchToSchemeCashAtPosRequest(tmmConfig);
        getSchemeToSwitchCashAtPosResponse(tmmConfig);

        getSwitchToSchemePurCashAtPosRequest(tmmConfig);
        getSchemeToSwitchPurCashAtPosResponse(tmmConfig);

        getSwitchToSchemePreauthRequest(tmmConfig);
        getSchemeToSwitchPreauthResponse(tmmConfig);

        getSwitchToSchemeMotoRequest(tmmConfig);
        getSchemeToSwitchMotoResponse(tmmConfig);

        getSwitchToSchemeBalanceEnquiryRequest(tmmConfig);
        getSchemeToSwitchBalanceenquiryResponse(tmmConfig);

        getSwitchToSchemeRefundRequest(tmmConfig);
        getSchemeToSwitchRefundResponse(tmmConfig);

        getSwitchToSchemeVoidRefundRequest(tmmConfig);
        getSchemeToSwitchVoidRefundResponse(tmmConfig);

        getSwitchToSchemeVoidOthersRequest(tmmConfig);
        getSchemeToSwitchVoidOthersResponse(tmmConfig);

        getSwitchToSchemeReversalRequest(tmmConfig);
        getSchemeToSwitchReversalResponse(tmmConfig);

        getSwitchToSchemeSignonRequest(tmmConfig);
        getSchemeToSwitchSignonResponse(tmmConfig);

        getSchemeToSwitch820Request(tmmConfig);
        getSwitchToScheme820Response(tmmConfig);

        /**
         * Switch To Scheme Purchase Request and Scheme To Switch Purchase Response
         */
        getSwitchToSchemePgPurchaseRequest(tmmConfig);
        getSchemeToSwitchPgPurchaseResponse(tmmConfig);


        /**
         * Switch To Scheme PreAuth Request and Scheme To Switch PreAuth Response
         */
        getSwitchToSchemePgPreAuthRequest(tmmConfig);
        getSchemeToSwitchPgPreAuthResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Request and Scheme To Switch Refund Response
         */
        getSwitchToSchemePgOnlineRefundRequest(tmmConfig);
        getSchemeToSwitchPgOnlineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Reversal Request and Scheme To Switch Reversal Response
         */
        getSwitchToSchemePgReversalRequest(tmmConfig);
        getSchemeToSwitchPgReversalResponse(tmmConfig);

        /**
         * Switch To Scheme SI Request and Scheme To Switch SI Response
         */
        getSwitchToSchemePgSIRequest(tmmConfig);
        getSchemeToSwitchPgSIResponse(tmmConfig);

        /**
         * Switch To Scheme OnlineOfflineRefund Request and Scheme To Switch OnlineOfflineRefund Response
         */
        getSwitchToSchemePgOnlineOfflineRefundRequest(tmmConfig);
        getSchemeToSwitchPgOnlineOfflineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme PreAuthReversal Request and Scheme To Switch PreAuthReversal Response
         */
        getSwitchToSchemePgPreAuthReversalRequest(tmmConfig);
        getSchemeToSwitchPgPreAuthReversalResponse(tmmConfig);

        /**
         * Switch To Scheme Moto sale Request and Scheme To Switch Moto sale Response
         */
        getSwitchToSchemeMotoSaleRequest(tmmConfig);
        getSchemeToSwitchMotoSaleResponse(tmmConfig);

        /**
         * Switch To Schemeh Moto Reversal Request and Scheme To Switch Moto Reversal Response
         */
        getSwitchToSchemeMotoReversalRequest(tmmConfig);
        getSchemeToSwitchMotoReversalResponse(tmmConfig);

        /**
         * Switch To Scheme Moto Refund Request and Scheme To Switch Moto Refund Response
         */
        getSwitchToSchemeMotoRefundRequest(tmmConfig);
        getSchemeToSwitchMotoRefundResponse(tmmConfig);
        
        /**
         * Switch To Scheme Moto PreAuth Request and Scheme To Switch Moto PreAuth Response
         */
        getSwitchToSchemePgMotoPreAuthRequest(tmmConfig);
        getSchemeToSwitchPgMotoPreAuthResponse(tmmConfig);

        /**
         * Bqr
         */

        getBqrSwitchToSchemePurchaseRequest();
        getBqrSchemeToSwitchPurchaseResponse();

        getBqrSwitchToSchemeRefundRequest();
        getBqrSchemeToSwitchRefundResponse();

        getBqrSwitchToSchemeReversalRequest();
        getBqrSchemeToSwitchReversalResponse();

        getBqrSwitchToSchemeStipRequest();
        getBqrSchemeToSwitchStipResponse();

        return tmmConfig;
    }

    private void getSwitchToSchemePurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional-62
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PURCHASE_REQUEST), fieldsMap);

    }

    private void getSchemeToSwitchPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PURCHASE_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeCashwithdrawalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62
        tmmConfig.put(new TransactionTypeConfig("0100", "01", TmmConstants.CASHWITHDRAWAL_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchCashwithdrawalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "01", TmmConstants.CASHWITHDRAWAL_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62

        tmmConfig.put(new TransactionTypeConfig("0100", "09", TmmConstants.CASHATPOS_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "09", TmmConstants.CASHATPOS_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemePurCashAtPosRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62

        tmmConfig.put(new TransactionTypeConfig("0100", "09", TmmConstants.PURCHASE_CASHATPOS_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPurCashAtPosResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "09", TmmConstants.PURCHASE_CASHATPOS_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemePreauthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PREAUTH_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPreauthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PREAUTH_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeMotoRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.MOTO_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.MOTO_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeBalanceEnquiryRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62

        tmmConfig.put(new TransactionTypeConfig("0100", "30", TmmConstants.BALANCE_INQUIRY_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchBalanceenquiryResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "30", TmmConstants.BALANCE_INQUIRY_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        // Conditional Fields- 12,13,14,20,23,26,28,33,35,37,41,42,43,45,52,53,54,55
        // Optional Fields-62

        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,17,20,28,33,37,38,41,44,48,50,51,54,55,56,62.

        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.REFUND_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeVoidRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        // Conditional Fields- 12,13,14,20,23,28,33,35,37,38,41,42,43,54,63,95
        // Optional Fields-62,

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.VOID_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchVoidRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,16,17,20,28,33,37,41,44,48,50,51,56,62,95

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.VOID_REFUND_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeVoidOthersRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        // Conditional Fields- 12,13,14,20,23,28,33,35,37,38,41,42,43,54,63,95
        // Optional Fields-62,

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.VOID_OTHERS_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchVoidOthersResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,16,17,20,28,33,37,41,44,48,50,51,56,62,95

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.VOID_OTHERS_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        // Conditional Fields- 12,13,14,20,23,28,33,35,37,38,41,42,43,54,63,95
        // Optional Fields-62,

        tmmConfig.put(new TransactionTypeConfig("0400", null, TmmConstants.REVERSAL_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        // Conditional Fields -5,6,9,10,16,17,20,28,33,37,41,44,48,50,51,56,62,95

        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.REVERSAL_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeSignonRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(94, TmmConstants.SERVICE_INDICATOR);
        fieldsMap.put(96, TmmConstants.MSG_SECUIRTY_CODE);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("0800", null, TmmConstants.MASTERCARD_SIGNON_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchSignonResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        // Conditional Fields -44,127
        tmmConfig.put(new TransactionTypeConfig("0810", null, TmmConstants.MASTERCARD_SIGNON_RESPONSE), fieldsMap);
    }

    private void getSchemeToSwitch820Request(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(110, TmmConstants.RESERVED_110);
        // Conditional Fields -110
        tmmConfig.put(new TransactionTypeConfig("0820", null, TmmConstants.MASTERCARD_820_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getSwitchToSchemePgPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        //field 25 added only because we need it in DCF we are not sending it to the scheme
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(104,TmmConstants.TXN_DESC);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_PURCHASE_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSchemeToSwitchPgPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_PURCHASE_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getSwitchToSchemePgPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_PREAUTH_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSchemeToSwitchPgPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_PREAUTH_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getSwitchToSchemePgOnlineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(63,TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.PG_ONLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSchemeToSwitchPgOnlineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.PG_ONLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,9,10,11,15,19,21,29,34}
     */
    private void getSwitchToSchemePgReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(90,TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95,TmmConstants.REPLACEMENT_AMTS);
        tmmConfig.put(new TransactionTypeConfig("0400", "00", TmmConstants.PG_REVERSAL_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
     */
    private void getSchemeToSwitchPgReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38,TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.PG_REVERSAL_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,19,21,29,34}
     */
    private void getSwitchToSchemePgSIRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_SI_REQUEST), fieldsMap);

    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,10,11,13,14,15,16,17,19,21,29,34,36}
     */
    private void getSchemeToSwitchPgSIResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_SI_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,8,9,10,11,12,15,19,20,21,22,29,34,35}
     */
    private void getSwitchToSchemePgOnlineOfflineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(63,TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.PG_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
     */
    private void getSchemeToSwitchPgOnlineOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.PG_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,1,2,3,4,5,8,9,10,11,15,18,20,22,34}
     */
    private void getSwitchToSchemePgPreAuthReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(0, TmmConstants.PG_LENGTH);
        fieldsMap.put(1, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.PAN);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(8, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(34, TmmConstants.BANK_NAME);

        tmmConfig.put(new TransactionTypeConfig("0100", "14", TmmConstants.PG_PREAUTH_REVERSAL_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField ={0,2,3,5,9,10,11,13,14,15,16,17,18,20,22,33}
     */
    private void getSchemeToSwitchPgPreAuthReversalResponse(
            Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(0, TmmConstants.PG_LENGTH);
        fieldsMap.put(2, TmmConstants.MSG_TYPE);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(5, TmmConstants.TXN_AMT);
        fieldsMap.put(9, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(10, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(16, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(17, TmmConstants.RES_CODE);
        fieldsMap.put(18, TmmConstants.CVV_RESULT);
        fieldsMap.put(20, TmmConstants.ECOMMERCE_INDICATOR);
        fieldsMap.put(22, TmmConstants.FRM_IP_ADDRESS);
        fieldsMap.put(33, TmmConstants.DS_VERSION);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        tmmConfig.put(new TransactionTypeConfig("0110", "14", TmmConstants.PG_PREAUTH_REVERSAL_RESPONSE), fieldsMap);
    }


    private void getSwitchToSchemeMotoSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(104,TmmConstants.TXN_DESC);

        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_MOTO_SALE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_MOTO_SALE_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeMotoReversalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6,TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(90,TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(95,TmmConstants.REPLACEMENT_AMTS);
        tmmConfig.put(new TransactionTypeConfig("0400", "00", TmmConstants.PG_MOTO_REVERSAL_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        //fieldsMap.put(38,TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        tmmConfig.put(new TransactionTypeConfig("0410", null, TmmConstants.PG_MOTO_REVERSAL_RESPONSE), fieldsMap);
    }

    private void getSwitchToSchemeMotoRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(63,TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        tmmConfig.put(new TransactionTypeConfig("0100", "20", TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        tmmConfig.put(new TransactionTypeConfig("0110", "20", TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }
    
    /**
     * @param tmmConfig MandateField
     *                  ={0,1,2,3,4,5,6,7,8,9,10,11,12,19,20,21,22,29,33,34}
     */
    private void getSwitchToSchemePgMotoPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(104,TmmConstants.TXN_DESC);
        tmmConfig.put(new TransactionTypeConfig("0100", "00", TmmConstants.PG_MOTO_PREAUTH_REQUEST), fieldsMap);
    }

    /**
     * @param tmmConfig MandateField
     *                  ={0,2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34,36}
     */
    private void getSchemeToSwitchPgMotoPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        tmmConfig.put(new TransactionTypeConfig("0110", "00", TmmConstants.PG_MOTO_PREAUTH_RESPONSE), fieldsMap);
    }

    /**
     * Bqr
     */

    private void getBqrSwitchToSchemePurchaseRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9, TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(17, TmmConstants.CAPTURE_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(20, TmmConstants.PAN_EXTENDED_COUNTRY_CODE);
        fieldsMap.put(21, TmmConstants.PAN_FORWARDING_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(23, TmmConstants.CARD_SEQNO);
        fieldsMap.put(24, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(28, TmmConstants.TXN_FEE);
        fieldsMap.put(29, TmmConstants.SETTLEMENT_FEE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(36, TmmConstants.TRACK3_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(40, TmmConstants.SERVICE_RESTRICTION_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(46, TmmConstants.ISO_AD);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(57, TmmConstants.RESERVED_57);
        fieldsMap.put(58, TmmConstants.RESERVED_58);
        fieldsMap.put(59, TmmConstants.RESERVED_59);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(64, TmmConstants.MSG_AUTH_CODE);
        fieldsMap.put(65, TmmConstants.EXTENDED_BITMAP_INDICATOR);
        fieldsMap.put(66, TmmConstants.SETTLEMENT_CODE);
        fieldsMap.put(67, TmmConstants.EXTENDED_PAYMENT_CODE);
        fieldsMap.put(68, TmmConstants.RECEIVER_COUNTRY_CODE);
        fieldsMap.put(69, TmmConstants.SETTLEMENT_COUNTRY_CODE);
        fieldsMap.put(70, TmmConstants.NETWORK_MGMT_INFO_CODE);
        fieldsMap.put(71, TmmConstants.MSG_NO);
        fieldsMap.put(72, TmmConstants.LAST_MSG_NO);
        fieldsMap.put(73, TmmConstants.ACTION_DATE);
        fieldsMap.put(74, TmmConstants.NO_OF_CREDITS);
        fieldsMap.put(75, TmmConstants.CREDITS_REVERSAL_NO);
        fieldsMap.put(76, TmmConstants.NO_OF_DEBITS);
        fieldsMap.put(77, TmmConstants.DEBITS_REVERSAL_NO);
        fieldsMap.put(78, TmmConstants.TRANSFER_NO);
        fieldsMap.put(79, TmmConstants.TRANSFER_REVERSAL_NO);
        fieldsMap.put(80, TmmConstants.NO_OF_INQUIRIES);
        fieldsMap.put(81, TmmConstants.NO_OF_AUTHS);
        fieldsMap.put(82, TmmConstants.CREDITS_PROCESSING_FEE);
        fieldsMap.put(83, TmmConstants.CREDITS_TXN_FEE);
        fieldsMap.put(84, TmmConstants.DEBITS_PROCESSING_FEE);
        fieldsMap.put(85, TmmConstants.DEBITS_TXN_FEE);
        fieldsMap.put(86, TmmConstants.TOTAL_CREDITS);
        fieldsMap.put(87, TmmConstants.CREDITS_REVERSAL);
        fieldsMap.put(88, TmmConstants.TOTAL_DEBITS);
        fieldsMap.put(89, TmmConstants.DEBITS_REVERSAL);
        fieldsMap.put(90, TmmConstants.ORIGINAL_DATA_ELEMENTS);
        fieldsMap.put(91, TmmConstants.FILE_UPDATE_CODE);
        fieldsMap.put(92, TmmConstants.FILE_SECURITY_CODE);
        fieldsMap.put(93, TmmConstants.RES_INDICATOR);
        fieldsMap.put(94, TmmConstants.SERVICE_INDICATOR);
        fieldsMap.put(95, TmmConstants.REPLACEMENT_AMTS);
        fieldsMap.put(96, TmmConstants.MSG_SECUIRTY_CODE);
        fieldsMap.put(97, TmmConstants.NET_SETTLEMENT);
        fieldsMap.put(98, TmmConstants.PAYEE);
        fieldsMap.put(99, TmmConstants.SETTLEMENT_ID_CODE);
        fieldsMap.put(100, TmmConstants.RECEIVER_ID_CODE);
        fieldsMap.put(101, TmmConstants.FILE_NAME);
        fieldsMap.put(102, TmmConstants.ACCID_1);
        fieldsMap.put(103, TmmConstants.ACCID_2);
        fieldsMap.put(104, TmmConstants.TXN_DESC);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(106, TmmConstants.RESERVED_106);
        fieldsMap.put(107, TmmConstants.RESERVED_107);
        fieldsMap.put(108, TmmConstants.RESERVED_108);
        fieldsMap.put(109, TmmConstants.RESERVED_109);
        fieldsMap.put(110, TmmConstants.RESERVED_110);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        fieldsMap.put(112, TmmConstants.RESERVED_112);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(114, TmmConstants.RESERVED_114);
        fieldsMap.put(115, TmmConstants.RESERVED_115);
        fieldsMap.put(116, TmmConstants.RESERVED_116);
        fieldsMap.put(117, TmmConstants.RESERVED_117);
        fieldsMap.put(118, TmmConstants.RESERVED_118);
        fieldsMap.put(119, TmmConstants.RESERVED_119);
        fieldsMap.put(120, TmmConstants.RESERVED_120);
        fieldsMap.put(121, TmmConstants.RESERVED_121);
        fieldsMap.put(122, TmmConstants.RESERVED_122);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        fieldsMap.put(124, TmmConstants.RESERVED_124);
        fieldsMap.put(125, TmmConstants.RESERVED_125);
        fieldsMap.put(126, TmmConstants.RESERVED_126);
        fieldsMap.put(127, TmmConstants.RESERVED_127);
        fieldsMap.put(128, TmmConstants.RESERVED_128);
        // Conditional Fields- 5,6,9,10,12,13,15,16,33,50,51,61
        //Mandatory Fields- 63
        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0100", "28", TmmConstants.BQR_PURCHASE_REQUEST), fieldsMap);

    }

    private void getBqrSchemeToSwitchPurchaseResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        fieldsMap.put(110,TmmConstants.RESERVED_110);
        fieldsMap.put(120,TmmConstants.RESERVED_120);
        fieldsMap.put(124,TmmConstants.RESERVED_124);
        fieldsMap.put(127,TmmConstants.RESERVED_127);

        // Conditional Fields -6,10,16,33,37,38,51,120,124,127.
        //Mandatory Fields - 63
        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0110", "28", TmmConstants.BQR_PURCHASE_RESPONSE), fieldsMap);
    }



    private void getBqrSwitchToSchemeRefundRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9,  TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        // Conditional Fields- 5,6,9,10,12,13,15,16,33,50,51,61
        //Mandatory Fields- 63

        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0100", "28", TmmConstants.BQR_REFUND_REQUEST), fieldsMap);
    }

    private void getBqrSchemeToSwitchRefundResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(105, TmmConstants.RESERVED_105);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        fieldsMap.put(110,TmmConstants.RESERVED_110);
        fieldsMap.put(120,TmmConstants.RESERVED_120);
        fieldsMap.put(124,TmmConstants.RESERVED_124);
        fieldsMap.put(127,TmmConstants.RESERVED_127);

        // Conditional Fields -6,10,16,33,37,38,51,120,124,127.
        //Mandatory Fields - 63
        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0110", "28", TmmConstants.BQR_REFUND_RESPONSE), fieldsMap);
    }

    private void getBqrSwitchToSchemeReversalRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9,  TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        // Conditional Fields- 5,6,9,10,12,13,15,16,33,50,51,61
        //Mandatory Fields- 63

        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0420", null, TmmConstants.BQR_REVERSAL_REQUEST), fieldsMap);
    }

    private void getBqrSchemeToSwitchReversalResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        fieldsMap.put(110,TmmConstants.RESERVED_110);
        fieldsMap.put(120,TmmConstants.RESERVED_120);
        fieldsMap.put(124,TmmConstants.RESERVED_124);
        fieldsMap.put(127,TmmConstants.RESERVED_127);

        // Conditional Fields -6,10,16,33,37,38,51,120,124,127.
        //Mandatory Fields - 63
        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0430", "28", TmmConstants.BQR_REVERSAL_RESPONSE), fieldsMap);
    }


    private void getBqrSwitchToSchemeStipRequest() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(5, TmmConstants.SETTLEMENT_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(9,  TmmConstants.SETTLEMENT_CONVERSION_RATE);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(18, TmmConstants.MERCHANT_TYPE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(50, TmmConstants.SETTLEMENT_CURRENY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        // Conditional Fields- 5,6,9,10,12,13,15,16,33,50,51,61
        //Mandatory Fields- 63
        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0120", "28", TmmConstants.BQR_STIP_REQUEST), fieldsMap);

    }

    private void getBqrSchemeToSwitchStipResponse() {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(6, TmmConstants.CARD_HOLDER_BILLING_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(10, TmmConstants.CARD_HOLDER_BILLING_CONVERSION_RATE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(16, TmmConstants.CONVERSION_DATE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(51, TmmConstants.CARD_HOLDER_BILLING_CURRENCY_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(108,TmmConstants.RESERVED_108);
        fieldsMap.put(110,TmmConstants.RESERVED_110);
        fieldsMap.put(120,TmmConstants.RESERVED_120);
        fieldsMap.put(124,TmmConstants.RESERVED_124);
        fieldsMap.put(127,TmmConstants.RESERVED_127);

        // Conditional Fields -6,10,16,33,37,38,51,120,124,127.
        //Mandatory Fields - 63
        MasterCardMessageTransformation.tmmConfig.put(new TransactionTypeConfig("0130", "28", TmmConstants.BQR_STIP_RESPONSE), fieldsMap);
    }
    //Implementation will be done later
    private void getSwitchToScheme820Response(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId, TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        // validate the balance inquiry transaction here and then continue further processing

        CacheServices cacheService = SpringContextBridge.services().getCacheService();
        if (MessageConstructionHelper.isBalanceEnquiry(sourceTmm.getMsgType(), sourceTmm.getProcessingCode())
                && !((SchemeBin.DEBIT).toString().equals(cacheService.getSchemeBin(sourceTmm.getPan()).getCardProgram()))) {
            throw new InvalidTxnException("Cannot perform balance inquiry on Credit/ card");
        } else {
            MessageContext msgContext = super.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
            if (msgContext.getRawMsg() instanceof ISOMsg) {
                ISOMsg rawMsg = (ISOMsg) msgContext.getRawMsg();
                try {
                    byte[] finalMsg = prefixLength(rawMsg.pack());
                    msgContext.setRawMsg(finalMsg);
                } catch (ISOException e) {
                    logger.error(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(), sourceTmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                    logger.trace(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(), sourceTmm.getTransactionId(), "Failed to construct message"), e);
                }
            }
            return msgContext;
        }
    }


    public byte[] prefixLength(byte[] pack) {
        byte[] newPack = null;
        String length = Integer.toHexString(pack.length);
        StringBuilder hexLength = new StringBuilder();
        for (int i = length.length(); i < 4; i++) {
            hexLength.append("0");
        }
        hexLength = hexLength.append(length);
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(ISOUtil.hex2byte(hexLength.toString()));
            outputStream.write(pack);
            newPack = outputStream.toByteArray();
        } catch (Exception ex) {
            newPack = pack;
        }
        return newPack;

    }

    public byte[] oldPrefixLength(byte[] rawMsg) {
//		byte[] newPack = null;
        String msgHexLength = String.format("%02x", rawMsg.length);
//		String length = Integer.toHexString(pack.length);
//		String hexLength = "";
//		for (int i = length.length(); i < 4; i++) {
//			hexLength += "0";
//		}
//		hexLength = hexLength + length;
//		try {
        byte[] msgLengthBytes = ISOUtil.hex2byte(msgHexLength);
        byte[] finalMsgBytes = new byte[msgHexLength.length() + rawMsg.length];

        System.arraycopy(msgLengthBytes, 0, finalMsgBytes, 0, msgLengthBytes.length);
        System.arraycopy(rawMsg, 0, finalMsgBytes, msgLengthBytes.length, rawMsg.length);

//			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//			outputStream.write(ISOUtil.hex2byte(hexLength));
//			outputStream.write(rawMsg);
//			newPack = outputStream.toByteArray();
//		} catch (Exception ex) {
//			newPack = rawMsg;
//		}
        return finalMsgBytes;

    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new MasterCardMessageConstruction();
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        MasterCardMessageConstruction mcmc = null;
        if (MessageConstructionHelper.isPosVoidRequest(msgType, subMsgType) ||
        		MessageConstructionHelper.isReversalRequest(msgType)) {
        	switch (srcProcessor) {
        	case PG_SWITCH:
        		mcmc = new PgVoidReversalMasterCardMessageConstruction();
        		break;
        	default:
        		mcmc = new VoidReversalMasterCardMessageConstruction();
        		break;
        	}
        } else {
            switch (srcProcessor) {
                case PG_SWITCH:
                    mcmc = new PgMasterCardMessageConstruction();
                    break;
                case BQR_SWITCH:
                    mcmc = new BqrMasterCardMessageConstruction();
                    break;
                default:
                    mcmc = new MasterCardMessageConstruction();
                    break;
            }
        }
        return mcmc;
    }

    @Override
    public int getDefaultHeaderLength() {
        return 4;
    }

}