package com.isg.mw.mtm.transform.hitachi;

import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.hitachi.HitachiMerchantRequestModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.lyra.LyraMessageTransformation;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public class HitachiMessageTransformation extends BaseMessageTransformation {

    private Logger logger = LogManager.getLogger(HitachiMessageTransformation.class);


    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {
        return null;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return null;
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        return null;
    }

    public HitachiMerchantRequestModel createMerchant(MerchantMasterModel masterModel) {
        HitachiMerchantRequestModel requestModel = new HitachiMerchantRequestModel();
        requestModel.setMid(masterModel.getMid());
        requestModel.setTid(masterModel.getTid());
        requestModel.setBankEemiFlag("1");
        requestModel.setCcEmiFlag("1");
        requestModel.setDcEmiFlag("1");
        requestModel.setBrandEmiFlag("1");
        requestModel.setBrandCcEmiFlag("1");
        requestModel.setBrandDcEmiFlag("1");
        requestModel.setKycFlag("1");
        requestModel.setMccCode(masterModel.getMccCode());
        requestModel.setMccDesc(masterModel.getMccCode());
        requestModel.setPincode(masterModel.getMerchantPincode().toString());
        requestModel.setState(masterModel.getMerchantStateCode());
        requestModel.setCity(masterModel.getMerchantCity());
        requestModel.setSponsorBankCode("002SBI");
        requestModel.setGst(masterModel.getGstNumber());
        requestModel.setAggregatorCode(CacheSrConfigProperties.getProperty("hitachi.aggregator.code"));
        requestModel.setPan(masterModel.getPanNumber());
        requestModel.setStatus(masterModel.getStatus().name());
        requestModel.setAcqBank(CacheSrConfigProperties.getProperty("hitachi.acq.bank"));
        //20072023 112700
        SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MM-yyyy HHMMSS");
        Date date2 = Date.from(OffsetDateTime.now().toInstant());
        requestModel.setReqTimestamp(formatter2.format(date2));
        requestModel.setSrc("HPY");
        requestModel.setMerchantName(masterModel.getMerchantName());
        requestModel.setEmailId(masterModel.getMerchantEmail());
        requestModel.setMobileNo(masterModel.getMerchantMobNo());
        requestModel.setOperation("A");
        requestModel.setTerminalType("Android");
        requestModel.setTerminalModel("DX8000");
        return requestModel;
    }

    public String generateHitachiApiAccessToken(TargetAdditionalData targetAdditionalData, MerchantMasterModel merchantMasterModel) {
        String accessTokenApiUrl = targetAdditionalData.getApiInfo().getHitachi().getAccessTokenApiUrl();
        String res;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("sourceId", targetAdditionalData.getApiInfo().getHitachi().getSourceId());
            jsonObject.put("tid", merchantMasterModel.getTid());
            jsonObject.put("mid", merchantMasterModel.getMid());
            jsonObject.put("loginId",targetAdditionalData.getApiInfo().getHitachi().getLoginId());
            jsonObject.put("loginPassword", targetAdditionalData.getApiInfo().getHitachi().getLoginPassword());
            String jsonString = IsgJsonUtils.getJsonString(jsonObject);
            res = callApiUsingWebClient(null, jsonString, accessTokenApiUrl, null, headers);
            if (res != null) {
                res = new JSONObject(res).getString("Token");
            }
        } catch (Exception e) {
            res = "Error ::" + e.getMessage();
            logger.info("Exception while calling Hitachi Generate Access Token API Request : {} ", e.getMessage());
        }
        return res;
    }

    public String callApiUsingWebClient(MultiValueMap<String, String> mapBody, String strBody, String url, Map<String, String> headers, HttpHeaders httpHeaders) {
        logger.info("Invoking API through Web Client with Request URL : {} and Headers : {}", url, headers != null ? headers : httpHeaders);
        logger.info("Invoking API With Request Body:  {}", !StringUtils.isBlank(strBody) ? strBody : mapBody);
        SslContext sslContext = null;
        try {
            sslContext = SslContextBuilder.forClient()
                    .trustManager(InsecureTrustManagerFactory.INSTANCE).build();
        } catch (SSLException e) {
            e.printStackTrace();
        }
        SslContext finalSslContext = sslContext;
        HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(finalSslContext)).followRedirect(true);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = null;
        HttpStatus httpStatus = null;
        WebClient.RequestBodySpec requestBodySpec = null;
        if (headers != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .post()
                    .uri(url)
                    .headers(headers1 -> {
                        headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                    });
        } else if (httpHeaders != null) {
            requestBodySpec = webClient.clientConnector(new ReactorClientHttpConnector(httpClient))
                    .build()
                    .post()
                    .uri(url)
                    .headers(headers1 -> {
                        httpHeaders.forEach((key, value) -> headers1.put(key, value));
                    });
        }
        if (mapBody != null) {
            block = requestBodySpec.body(BodyInserters.fromFormData(mapBody)).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        } else if (strBody != null) {
            block = requestBodySpec.body(Mono.just(strBody), String.class).exchange().block(Duration.ofSeconds(20));
            httpStatus = block.statusCode();
        }
        String res = null;
        if (httpStatus == HttpStatus.OK || httpStatus == HttpStatus.CREATED || httpStatus == HttpStatus.ACCEPTED) {
            res = block.bodyToMono(String.class).block();
        } else {
            res = "status : " + httpStatus.toString() + "##" + " body : " + block.bodyToMono(String.class).block();
        }

        logger.info("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }




}
