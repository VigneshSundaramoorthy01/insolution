package com.isg.mw.mtm.transform;

import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.MsgFlow;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.InvalidTxnException;
import com.isg.mw.mtm.exception.InvalidVoidOrReversalDataException;
import com.isg.mw.mtm.exception.MessageBuildException;
import com.isg.mw.mtm.exception.MessageTransformationException;
import com.isg.mw.mtm.parser.MwIsoPackager;
import com.isg.mw.mtm.rawlog.TxnLogger;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public abstract class BaseMessageTransformation implements IMessageTransformation {

    private Logger logger = LogManager.getLogger(getClass());

    @Override
    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        String errorMsg = "Error while constructing message for transaction - ";
        MessageContext msgContext = new MessageContext(sourceTmm.getEntityId(), epId, txnTypeConfig.getEpMsgType());

        Class<?> className = msgTransConfig.getBusinessRuleClass();
        BaseMessageTransformation baseMsgTransformation;
        try {
            baseMsgTransformation = (BaseMessageTransformation) className.newInstance();
        } catch (InstantiationException | IllegalAccessException e1) {
            throw new MessageTransformationException(
                    "Error while creating instance of business rule class: " + className, e1);
        }

        SwitchBaseMessageConstruction baseMsgConstruction = baseMsgTransformation.getMessageConstruction(
                sourceTmm.getMsgType(), sourceTmm.getProcessingCode(), sourceTmm.getSourceProcessor());
        baseMsgConstruction.setPinTranslationType(msgTransConfig.getPinTranslationType());
        sourceTmm.setTarget(epId);

        Map<Integer, String> tmmConfig = msgTransConfig.getTmmConfig();
        String targetMsgType = txnTypeConfig.getEpMsgType();
        String targetProcessingCode = txnTypeConfig.getProcessingCode();
        logger.trace("Tmm config used while constructing the message: {}, for message type: {}, message type id: {}, transaction name: {}",
                tmmConfig, targetMsgType, targetProcessingCode, txnTypeConfig.getTxnTypeName());

        baseMsgConstruction.setSourceMsgType(sourceTmm.getMsgType());
        baseMsgConstruction.setSourceMsgTypeId(sourceTmm.getProcessingCode());
        baseMsgConstruction.setTargetMsgType(targetMsgType);
        String targetMsgTypeId = null;
        if (sourceTmm.getProcessingCode() != null)
            targetMsgTypeId = new StringBuilder().append(targetProcessingCode).append(sourceTmm.getProcessingCode().substring(2)).toString();

        baseMsgConstruction.setTargetMsgTypeId(targetMsgTypeId);

        baseMsgConstruction.setOriginalTmm(sourceTmm.getOriginalTmm());
        baseMsgConstruction.setSourceTmm(sourceTmm);
        TransactionMessageModel targetTmm = SerializationUtils.clone(sourceTmm);
        TransactionMessageModel apiTargetTmm = SerializationUtils.clone(sourceTmm);
        baseMsgConstruction.setTargetTmm(targetTmm);
        baseMsgConstruction.setApiTargetTmm(apiTargetTmm);
        baseMsgConstruction.updateDrCrFlag();


        tmmConfig.forEach((fieldNo, fieldMethodName) -> {
            if (fieldMethodName != null) {
                logger.trace("Invoking field {}, methodName: {}", fieldNo, fieldMethodName);
                try {
                    invokeFieldMethod(baseMsgConstruction, fieldMethodName, fieldNo);
                } catch (InvalidTxnException e) {
                    throw new InvalidTxnException("Message transformation error ", e);
                } catch (InvalidVoidOrReversalDataException e) {
                    throw new InvalidVoidOrReversalDataException("Data mismatch ", e);
                } catch (NoSuchMethodException | SecurityException | IllegalAccessException
                         | IllegalArgumentException e) {
                    throw new MessageTransformationException("Error while invoking method: " + fieldMethodName, e);
                } catch (Throwable e) {
                    throw new MessageTransformationException(errorMsg + " entity id: " + sourceTmm.getEntityId()
                            + ", message type: " + targetMsgType + ", processing code: " + targetProcessingCode, e);
                }
            }
        });
        try {
            String msgFormat = msgTransConfig.getMsgFormat();
            InputStream msgFormatStream = new ByteArrayInputStream(msgFormat.getBytes());
            MwIsoPackager.buildMessage(targetMsgType, baseMsgConstruction.getBaseMessage(), msgFormatStream);
            msgContext.setRawMsg(baseMsgConstruction.getBaseMessage());
            baseMsgConstruction.getTargetTmm().setMsgType(targetMsgType);
            baseMsgConstruction.getApiTargetTmm().setMsgType(targetMsgType);
            msgContext.setTransactionMessageModel(baseMsgConstruction.getTargetTmm());
            baseMsgConstruction.getTargetTmm().setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(epId));
            msgContext.setMessageTransformationConfig(msgTransConfig);
            msgContext.setApiTmm(baseMsgConstruction.getApiTargetTmm());

            TxnLogger.logTxnDetail(MsgFlow.OUTBOUND, baseMsgConstruction.getBaseMessage().getFields(), baseMsgConstruction.getTargetTmm(), baseMsgConstruction.getSourceTmm());

        } catch (MessageBuildException e) {
            throw new MessageTransformationException(errorMsg + " entity id: " + sourceTmm.getEntityId()
                    + ", message type: " + targetMsgType + ", processing code: " + targetProcessingCode, e);
        }
        return msgContext;
    }

    private void invokeFieldMethod(SwitchBaseMessageConstruction messageConstruction, String methodName, int fldNo) throws Throwable {
        MethodHandle methodHandle = null;
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        MethodType methodType = MethodType.methodType(void.class, int.class);
        methodHandle = lookup.findVirtual(messageConstruction.getClass(), methodName, methodType);
        methodHandle.invoke(messageConstruction, fldNo);
    }

    public abstract Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig();

    public abstract SwitchBaseMessageConstruction getMessageConstruction();

    public abstract int getDefaultHeaderLength();

    public List<Integer> fetchIfeCharFields() {
        return null;
    }

    @Override
    public TransactionMessageModel parseResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        return null;
    }

    public CacheTargetMerchantMaster fetchCacheTargetMerchantMaster(String targetId, String mid, String tid) {
        CacheTargetMerchantMaster targetMerchantMaster = SpringContextBridge.services().getSrCacheService().getTargetMerchantMasterModel(targetId, mid, tid);
        if (targetMerchantMaster == null || (targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Inprogress.name()) ||
                targetMerchantMaster.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Failed.name()))) {
            List<TargetMerchantMasterModel> targetMerchantMaster1 = SpringContextBridge.services().getInitRestClient().getTargetMerchantMaster(targetId, mid, tid, ActiveInactiveFlag.Active.name());
            if(targetMerchantMaster1 != null && !targetMerchantMaster1.isEmpty()){
                targetMerchantMaster = updateTargetMerchantMasterCache(targetMerchantMaster1.get(0));
            }else{
                return null;
            }
        }
        return targetMerchantMaster;
    }

    public CacheTargetMerchantMaster updateTargetMerchantMasterCache(TargetMerchantMasterModel targetMerchantMasterModel) {
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();

        CacheTargetMerchantMaster masterData = null;
        try {
            TargetMerchantMasterModel targetModel = null;
            if (targetMerchantMasterModel != null) {
                targetModel = SmartRouteConfigUtil.getTargetMerchantMasterModel(targetMerchantMasterModel);
                masterData = srCacheService.getTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(),targetModel.getTid());
                logger.info("Fetched Target Merchant Master From Redis For TargetId {} : and Status Is : {} " , targetModel.getTargetId(),masterData !=null ? masterData.getStatus() : null);
                CacheTargetMerchantMaster key;
                if (masterData != null && !masterData.getStatus().equalsIgnoreCase(ActiveInactiveFlag.Active.name())) {
                    srCacheService.removeTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid());
                    masterData = new CacheTargetMerchantMaster();
                    masterData.setTargetMid(targetModel.getTargetMid());
                    masterData.setMerchantVpa(targetModel.getMerchantVpa());
                    masterData.setKey(targetModel.getKey());
                    masterData.setSalt(targetModel.getSalt());
                    masterData.setStatus(targetModel.getStatus());
                    masterData.setProdApiKey(targetModel.getProdApiKey());
                    masterData.setTestApiKey(targetModel.getTestApiKey());
                    masterData.setDpdId(targetModel.getDpaId());
                    srCacheService.putTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid(), masterData);
//                    cacheUtil.putTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getStatus(), masterData);
                } else if (masterData == null) {
                    masterData = new CacheTargetMerchantMaster();
                    masterData.setTargetMid(targetModel.getTargetMid());
                    masterData.setMerchantVpa(targetModel.getMerchantVpa());
                    masterData.setKey(targetModel.getKey());
                    masterData.setSalt(targetModel.getSalt());
                    masterData.setStatus(targetModel.getStatus());
                    masterData.setProdApiKey(targetModel.getProdApiKey());
                    masterData.setTestApiKey(targetModel.getTestApiKey());
                    masterData.setDpdId(targetModel.getDpaId());
                    srCacheService.putTargetMerchantMasterModel(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid(), masterData);
//                    cacheUtil.putTargetMerchantMasterData(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getStatus(), masterData);
                }
            }
//            String targetMid = cacheUtil.getTargetMid(targetModel.getTargetId().toString(), targetModel.getMid(),targetModel.getTid());
//            masterData = cacheUtil.getTargetMerchantMaster(targetModel.getTargetId().toString(), targetModel.getMid(), targetModel.getTid());
            logger.trace("Target Merchant Master Model for targetMID : {} and status : {}  Inserted/Updated Successfully...",masterData.getTargetMid() , masterData.getStatus());
        } catch (Exception e) {
            logger.error("An error occurred!", e);
            return masterData;
        }
        return masterData;
    }


    public String getOwnershipTypeByConsCode(String consCode, String paymentSource){
        String url = MTMProperties.getProperty("ownership.type.by.cons.code") + "?consCode=" + consCode + "&paymentSource=" + paymentSource;

        logger.info("Calling CM Api To To Get Ownership Type For Cons Code : {}  : {} " , url,consCode);
        String str = null;
        try {
            String JWT_KEY = "";
            String USER_NAME_HEADER = "";
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
            logger.trace("JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers),
                    String.class);
            str = exchange.getBody();
            logger.info("Ownership Type : {} " ,str);
        } catch (RuntimeException e) {
            logger.error("Failed to fetch ownership Types " + e);
        }
        return str;
    }
}