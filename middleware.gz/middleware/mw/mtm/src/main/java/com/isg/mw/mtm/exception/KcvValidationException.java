package com.isg.mw.mtm.exception;

public class KcvValidationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public KcvValidationException(String errorMsg) {
        super(errorMsg);
    }

    public KcvValidationException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }
}
