package com.isg.mw.mtm.context;

import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.mt.MessageDefinition;
import com.isg.mw.core.model.mt.MessageTransformationConfigModel;
import com.isg.mw.core.model.sc.SourceConfigModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.mtm.exception.MTMInitializationException;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.DeclineMessageTransformation;
import com.isg.mw.mtm.transform.bqr.BqrDeclineMessageTransformation;
import com.isg.mw.mtm.transform.pg.PgDeclineMessageTransformation;
import com.isg.mw.mtm.util.MtmUtil;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static com.isg.mw.mtm.util.MtmConstants.*;

/**
 * @author juber3709
 */
public final class MessageTransformationContext {

    private static Logger logger = LogManager.getLogger(MessageTransformationContext.class);

    private MessageTransformationContext() {
    }

    /**
     * This map is needed only when we don't know the msg type of the message before
     * hand like in case of MessageTransformer.toPojo(...)<br>
     * <br>
     * key - entity id (Kotak) <br>
     * value -{ <br>
     * key - endpointId (Kotak.Pos)<br>
     * value - { <br>
     * key - TransactionTypeConfig (0200, 00000, purchase) <br>
     * value - MessageTransformationConfig (business_class_name, msgformat,
     * tmmConfig) <br>
     * }<br>
     * }<br>
     */
    @Getter
    private static final Map<String, Map<String, Map<TransactionTypeConfig, MessageTransformationConfig>>> msgTransformationConfig = new ConcurrentHashMap<>();

    /**
     * map of message format against msg type when message format is same for all
     * the msg types key -> isg.pos <br>
     * value -> {key -> msgtype (0200) , value -> msg format (jpos.xml)}
     */
    @Getter
    private static final Map<String, Map<String, MessageFormatConfigModel>> epIdMsgTypeMsgFormatMap = new ConcurrentHashMap<>();

    /**
     * map of message format against msg type & msgTypeId key -> msgtype.msgtypeid
     * (0200.000000) value -> msg type name (purchase)
     */
    @Getter
    private static final Map<String, Set<String>> msgTypeIdmsgTypeNameMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<String, TargetType> epIdTargetTypeMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<String, String> epIdTargetIdMap = new ConcurrentHashMap<>();

    @Getter
    private static final Map<TargetType, List<TransactionTypeConfig>> targetTypeTransTypeConfigMap = new HashMap<>();

    public static boolean initMTM(List<SourceConfigModel> sourceConfigList, List<TargetConfigModel> targetConfigList,
                                  List<MessageTransformationConfigModel> msgTransformationList) {
       /* msgTransformationList.forEach(routeDef -> {
            String entityId = routeDef.getEntityId();
            if (mesaageTransformationConfigMsg.containsKey(entityId)) {
                List<MessageTransformationConfigModel> list = mesaageTransformationConfigMsg.get(entityId);
                list.add(routeDef);

            } else {
                List<MessageTransformationConfigModel> list = new ArrayList<>();
                list.add(routeDef);
                mesaageTransformationConfigMsg.put(entityId, list);
            }
        });
        logger.debug("Message Transformation Config Message: {}", mesaageTransformationConfigMsg);*/

        msgTransformationList.forEach(routingDef -> routingDef.getRules().forEach(routingDefRule -> {

            String txnTypeName = routingDefRule.getName();
            if (routingDefRule.getSrc() != null) {
                buildTransactionTypeConfig(targetTypeTransTypeConfigMap, routingDefRule.getSrc(), txnTypeName);
            }

            if (routingDefRule.getDest() != null) {
                buildTransactionTypeConfig(targetTypeTransTypeConfigMap, routingDefRule.getDest(), txnTypeName);
            }
        }));
//        logger.debug("Transaction type config map: {}", targetTypeTransTypeConfigMap);
//        logger.debug("Message Type Id Msg Type Name Map: {}", msgTypeIdmsgTypeNameMap);

        sourceConfigList.forEach(sourceConfig -> {
            Map<String, Map<TransactionTypeConfig, MessageTransformationConfig>> epIdMsgTypeMap = new HashMap<>();
            buildMessageTranformationConfig(sourceConfig.getMessageFormats(), sourceConfig.getEntityId(),
                    sourceConfig.getName(), epIdMsgTypeMap,
                    targetTypeTransTypeConfigMap.get(sourceConfig.getSourceType()), sourceConfig.getSourceType(), null, null);

            epIdTargetTypeMap.put(sourceConfig.getName(), sourceConfig.getSourceType());
            epIdTargetIdMap.put(sourceConfig.getName(), sourceConfig.getId().toString());
        });

        targetConfigList.forEach(targetConfig -> {
            Map<String, Map<TransactionTypeConfig, MessageTransformationConfig>> epIdMsgTypeMap = new HashMap<>();
            buildMessageTranformationConfig(targetConfig.getMessageFormats(), targetConfig.getEntityId(),
                    targetConfig.getName(), epIdMsgTypeMap,
                    targetTypeTransTypeConfigMap.get(targetConfig.getTargetType()) != null
                            ? targetTypeTransTypeConfigMap.get(targetConfig.getTargetType()): new ArrayList<>()
                    , targetConfig.getTargetType(),
                    targetConfig.getPinTranslationType(), targetConfig.getAdditionalData());
            epIdTargetTypeMap.put(targetConfig.getName(), targetConfig.getTargetType());
            epIdTargetIdMap.put(targetConfig.getName(), targetConfig.getId().toString());
        });
        logger.info("MTM Initialized Successfully...");
        return true;
    }

    private static void buildTransactionTypeConfig(
            Map<TargetType, List<TransactionTypeConfig>> targetTypeTransTypeConfigMap, MessageDefinition msgDef,
            String txnTypeName) {

        String msgType = msgDef.getMsgType();
        String msgTypeId = msgDef.getMsgTypeId();
        TargetType targetType = msgDef.getTargetType();

        TransactionTypeConfig transTypSrcConfig = new TransactionTypeConfig(msgType, msgTypeId, txnTypeName, msgDef.getApiPath(), msgDef.getHttpMethod());

        String key = targetType + "." + msgType + "." + msgTypeId;
        
        if (msgTypeIdmsgTypeNameMap.containsKey(key)) {
        	Set<String> txnNameSet = msgTypeIdmsgTypeNameMap.get(key);
            txnNameSet.add(txnTypeName);
        } else {
        	Set<String> txnNameSet = new HashSet<String>();
        	txnNameSet.add(txnTypeName);
        	msgTypeIdmsgTypeNameMap.put(key, txnNameSet);
        }
        
        if (targetTypeTransTypeConfigMap.containsKey(targetType)) {
            List<TransactionTypeConfig> list = targetTypeTransTypeConfigMap.get(targetType);
            list.add(transTypSrcConfig);
        } else {
            List<TransactionTypeConfig> list = new ArrayList<>();
            list.add(transTypSrcConfig);
            targetTypeTransTypeConfigMap.put(targetType, list);
        }
    }

    /**
     * for each routeDef : List of RouteDefModel<br>
     * String entityId = routeDef.getEntityId() get source for given entity id from
     * SourceConfig get msgformats from source for each msgformat from msgFormats
     * msgformat.get get List of Target for given entity id from TargetConfig
     * <p>
     * List of rules from routeDef for each msgMapDef MessageMappingDef MsgDef =
     * msgMapDef.getSrc;
     *
     * @param msgFormats
     * @param entityId
     * @param endpointId
     * @param epIdTransTypeConfigMap
     * @param transTypeConfigList
     */
    private static void buildMessageTranformationConfig(List<MessageFormatConfigModel> msgFormats, String entityId,
                                                        String endpointId,
                                                        Map<String, Map<TransactionTypeConfig, MessageTransformationConfig>> epIdTransTypeConfigMap,
                                                        List<TransactionTypeConfig> transTypeConfigList, TargetType targetType,
                                                        PinTranslationType pinTranslationType, TargetAdditionalData targetAdditionalData) {

        /*
         * TODO: 1. optimize this logic for only one message format per endpoint id
         * TODO: 2. optimize this logic for per endpoint per msg type
         * Note: 3. below implementation is for per endpoint per msg type, msg sub type (processing code)
         */
        Map<TransactionTypeConfig, MessageTransformationConfig> msgTypeMTConfigMap = new HashMap<>();
        boolean[] isDefaultMsgFormatSet = {false};
        Optional<MessageFormatConfigModel> optDefMsgFormat = msgFormats.stream()
                .filter(msgFormat ->
                        msgFormat
                                .getMsgType()
                                .equalsIgnoreCase(DEFAULT_MSG_FORMAT)
                )
                .findFirst();
        MessageFormatConfigModel msgFmtModel = optDefMsgFormat.orElse(null);
        String defaultMsgFormat = msgFmtModel == null ? null : msgFmtModel.getMsgFormat();
        if(transTypeConfigList != null && !transTypeConfigList.isEmpty()) {
            for (TransactionTypeConfig transTypeConfig : transTypeConfigList) {
                for (MessageFormatConfigModel msgFormat : msgFormats) {
                    if (msgFormat.getMsgType().equals(transTypeConfig.getEpMsgType())) {
//                    logger.trace(
//                            "Creating Message Transformation Config for Entity Id: {}, Endpoint Id: {}, Message Type: {}",
//                            entityId, endpointId, msgFormat.getMsgType());
                        if (transTypeConfig.getTxnTypeName().startsWith(DECLINE_TXN_PG_START)) {
                            MessageTransformationConfig msgTransConfig = buildPgDecllineMessageTransformationConfig(transTypeConfig, msgFormat, defaultMsgFormat);
                            msgTypeMTConfigMap.put(transTypeConfig, msgTransConfig);
                            break;
                        } else if (transTypeConfig.getTxnTypeName().startsWith(DECLINE_TXN_BQR_START)) {
                            MessageTransformationConfig msgTransConfig = buildBqrDecllineMessageTransformationConfig(transTypeConfig, msgFormat, defaultMsgFormat);
                            msgTypeMTConfigMap.put(transTypeConfig, msgTransConfig);
                            break;

                        } else if (transTypeConfig.getTxnTypeName().startsWith(DECLINE_TXN_START)) {
                            MessageTransformationConfig msgTransConfig = buildDecllineMessageTransformationConfig(transTypeConfig, msgFormat, defaultMsgFormat);
                            msgTypeMTConfigMap.put(transTypeConfig, msgTransConfig);
                            break;
                        }

                        MessageTransformationConfig msgTransConfig = new MessageTransformationConfig();
                        msgTransConfig.setPinTranslationType(pinTranslationType);
                        msgTransConfig.setMsgFormat(msgFormat.getMsgFormat());

                        Class<?> businessRuleClass = null;
                        try {
                            businessRuleClass = Class.forName(msgFormat.getBusinessRule().getClassName());
                        } catch (ClassNotFoundException e) {
                            MtmUtil.throwException(new MTMInitializationException("Cannot find business rule class", e));
                        }
                        msgTransConfig.setBusinessRuleClass(businessRuleClass);
                        msgTransConfig.setMethodName(msgFormat.getBusinessRule().getMethodName());
                        // set default msg format if msg type specific is not found
                        String msgFormatStr = msgFormat.getMsgFormat() == null ? defaultMsgFormat
                                : msgFormat.getMsgFormat();
                        msgTransConfig.setMsgFormat(msgFormatStr);
                        //since, original record did not contain the message format; hence, setting it from default if null
                        msgFormat.setMsgFormat(msgFormatStr);
                        msgTransConfig.setTargetAdditionalData(targetAdditionalData);
                        putMessageFormat(endpointId, msgFormat, msgFormat.getMsgType());
                        Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = null;
                        try {
                            // TODO: do not invoke business class for each msg type
                            tmmConfig = getTmmConfig(businessRuleClass);
                            if (tmmConfig == null) {
                                msgTypeMTConfigMap.put(transTypeConfig, msgTransConfig);
                                continue;
                            }
                        } catch (MTMInitializationException e) {
                            MtmUtil.throwException(new MTMInitializationException("Cannot find business rule class", e));
                        }
                        Map<Integer, String> fieldsMap = tmmConfig.get(transTypeConfig);
//                    logger.trace("Fetching fields map from {}, for: {} and the map is: {}", businessRuleClass,
//                            transTypeConfig, fieldsMap);
                        msgTransConfig.setTmmConfig(fieldsMap);
                        msgTypeMTConfigMap.put(transTypeConfig, msgTransConfig);
                    } else if (!isDefaultMsgFormatSet[0] && msgFormat.getMsgType().equalsIgnoreCase(DEFAULT_MSG_FORMAT)) {
                        putMessageFormat(endpointId, msgFormat, DEFAULT_MSG_FORMAT);
                        isDefaultMsgFormatSet[0] = true;
                    }
                }
                msgTransformationConfig.put(entityId + "." + endpointId, epIdTransTypeConfigMap);
            }
        }
        assert isDefaultMsgFormatSet[0] : LogUtils.buildLogMessage(entityId, endpointId, DEFAULT_MSG_FORMAT, null,
                "Message Could not find default message format");
        epIdTransTypeConfigMap.put(endpointId, msgTypeMTConfigMap);
    }

    private static MessageTransformationConfig buildDecllineMessageTransformationConfig(TransactionTypeConfig transTypeConfig, MessageFormatConfigModel msgFormat, String defaultMsgFormat) {
        MessageTransformationConfig msgTransConfig = new MessageTransformationConfig();
        Class<?> businessRuleClass = DeclineMessageTransformation.class;
        msgTransConfig.setBusinessRuleClass(businessRuleClass);
        // set default msg format if msg type specific is not found
        String msgFormatStr = msgFormat.getMsgFormat() == null ? defaultMsgFormat
                : msgFormat.getMsgFormat();
        msgTransConfig.setMsgFormat(msgFormatStr);
        Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = null;
        try {
            // TODO: do not invoke business class for each msg type
            tmmConfig = getTmmConfig(businessRuleClass);
        } catch (MTMInitializationException e) {
            MtmUtil.throwException(new MTMInitializationException("Cannot find business rule class", e));
        }
        Map<Integer, String> fieldsMap = tmmConfig.get(transTypeConfig);
//        logger.trace("Fetching fields map from {}, for: {} and the map is: {}", businessRuleClass,
//                transTypeConfig, fieldsMap);
        msgTransConfig.setTmmConfig(fieldsMap);
        return msgTransConfig;
    }

    private static MessageTransformationConfig buildPgDecllineMessageTransformationConfig(TransactionTypeConfig transTypeConfig, MessageFormatConfigModel msgFormat, String defaultMsgFormat) {
        MessageTransformationConfig msgTransConfig = new MessageTransformationConfig();
        Class<?> businessRuleClass = PgDeclineMessageTransformation.class;
        msgTransConfig.setBusinessRuleClass(businessRuleClass);
        // set default msg format if msg type specific is not found
        String msgFormatStr = msgFormat.getMsgFormat() == null ? defaultMsgFormat
                : msgFormat.getMsgFormat();
        msgTransConfig.setMsgFormat(msgFormatStr);
        Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = null;
        try {
            // TODO: do not invoke business class for each msg type
            tmmConfig = getTmmConfig(businessRuleClass);
        } catch (MTMInitializationException e) {
            MtmUtil.throwException(new MTMInitializationException("Cannot find business rule class", e));
        }
        Map<Integer, String> fieldsMap = tmmConfig.get(transTypeConfig);
        logger.trace("Fetching fields map from {}, for: {} and the map is: {}", businessRuleClass,
                transTypeConfig, fieldsMap);
        msgTransConfig.setTmmConfig(fieldsMap);
        return msgTransConfig;
    }

    private static MessageTransformationConfig buildBqrDecllineMessageTransformationConfig(TransactionTypeConfig transTypeConfig, MessageFormatConfigModel msgFormat, String defaultMsgFormat) {
        MessageTransformationConfig msgTransConfig = new MessageTransformationConfig();
        Class<?> businessRuleClass = BqrDeclineMessageTransformation.class;
        msgTransConfig.setBusinessRuleClass(businessRuleClass);
        // set default msg format if msg type specific is not found
        String msgFormatStr = msgFormat.getMsgFormat() == null ? defaultMsgFormat
                : msgFormat.getMsgFormat();
        msgTransConfig.setMsgFormat(msgFormatStr);
        Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = null;
        try {
            // TODO: do not invoke business class for each msg type
            tmmConfig = getTmmConfig(businessRuleClass);
        } catch (MTMInitializationException e) {
            MtmUtil.throwException(new MTMInitializationException("Cannot find business rule class", e));
        }
        Map<Integer, String> fieldsMap = tmmConfig.get(transTypeConfig);
        logger.trace("Fetching fields map from {}, for: {} and the map is: {}", businessRuleClass,
                transTypeConfig, fieldsMap);
        msgTransConfig.setTmmConfig(fieldsMap);
        return msgTransConfig;
    }

    private static void putMessageFormat(String endpointId, MessageFormatConfigModel msgFormat, String msgType) {
        Map<String, MessageFormatConfigModel> msgTypeMsgFormatMap = epIdMsgTypeMsgFormatMap.get(endpointId);
        if (msgTypeMsgFormatMap == null) {
            msgTypeMsgFormatMap = new HashMap<>();
        }
        msgTypeMsgFormatMap.put(msgType, msgFormat);
        epIdMsgTypeMsgFormatMap.put(endpointId, msgTypeMsgFormatMap);
    }

    private static Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig(Class<?> className)
            throws MTMInitializationException {
        try {
            BaseMessageTransformation baseMsgTransformation = (BaseMessageTransformation) className.newInstance();
            return baseMsgTransformation.getTmmConfig();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new MTMInitializationException("Error while invoking getTmmConfig() on class: " + className, e);
        }
    }

    public static MessageTransformationConfig getMessageTransformationConfig(String entityId, String epId,
                                                                             TransactionTypeConfig txnTypConfig) {
        return msgTransformationConfig.get(entityId + "." + epId).get(epId).get(txnTypConfig);
    }

}