package com.isg.mw.mtm.parser.interpreter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.BinaryInterpreter;
import org.jpos.iso.LiteralBinaryInterpreter;

public class ISG_LiteralBinaryInterpreter implements BinaryInterpreter {
	private static Logger logger = LogManager.getLogger(ISG_LiteralBinaryInterpreter.class);

	public static final ISG_LiteralBinaryInterpreter INSTANCE = new ISG_LiteralBinaryInterpreter();

	/**
	 * Copies the input to the output.
	 */
	public void interpret(byte[] data, byte[] b, int offset) {
		LiteralBinaryInterpreter.INSTANCE.interpret(data, b, offset);
	}

	/**
	 * Copies the data out of the byte array.
	 */
	public byte[] uninterpret(byte[] rawData, int offset, int length) {
		length = length % 2 == 0 ? length : length + 1;
		return LiteralBinaryInterpreter.INSTANCE.uninterpret(rawData, offset, length);
	}

	/**
	 * Returns nBytes because we are not doing any conversion.
	 */
	public int getPackedLength(int nBytes) {
		nBytes = nBytes % 2 == 0 ? nBytes : nBytes + 1;
		return nBytes;
	}
}
