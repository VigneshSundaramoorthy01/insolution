package com.isg.mw.mtm.parser.msg;

/**
 * 
 * @author prasad_t026
 *
 */
public interface MwMessage {

}
