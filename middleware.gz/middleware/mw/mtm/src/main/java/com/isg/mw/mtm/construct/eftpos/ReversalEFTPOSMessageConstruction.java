package com.isg.mw.mtm.construct.eftpos;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.KeyModel;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOUtil;
import org.jpos.tlv.TLVList;
import org.jpos.tlv.TLVMsg;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.ZoneId;
import java.util.Map;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isEftposCashbackRequest;

public class ReversalEFTPOSMessageConstruction extends EFTPOSMessageConstruction implements IMessageConstruction {
    private static final Logger logger = LogManager.getLogger(EFTPOSMessageConstruction.class);

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */

    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */
    /*@Override
    public void setPan(int fieldNo) {
        String pan = this.sourceTmm.getPan();
        this.targetTmm.setPan(pan);
        this.apiTargetTmm.setPan(pan);
        this.baseMessage.set(fieldNo, pan);
    }*/


    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        this.targetTmm.setProcessingCode(this.originalTmm.getProcessingCode());
        this.baseMessage.set(fieldNo, this.originalTmm.getProcessingCode());
    }

    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     * <p>
     * It is mandatory for all type of transactions
     */
    @Override
    public void setTxnAmt(int fieldNo) {
        this.targetTmm.setTxnAmt(this.originalTmm.getTxnAmt());
        this.baseMessage.set(fieldNo, this.originalTmm.getTxnAmt());
    }

    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */


    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */
    @Override
    public void setTransmissionTime(int fieldNo) {
        String transmissionTime = null;
        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSigOn(this.sourceTmm) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            transmissionTime = this.sourceTmm.getTransmissionTime();
        } else {
            transmissionTime = MtmUtil.formatDate("MMddHHmmss", ZoneId.of("GMT"));
        }
        this.targetTmm.setTransmissionTime(transmissionTime);
        this.baseMessage.set(fieldNo, transmissionTime);
    }

    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */


    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */


    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */


    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    @Override
    public void setStan(int fieldNo) {
        String stan = null;
        String mti = this.targetMsgType;
        if (mti.equals("0421")){
            stan = this.originalTmm.getStan();
            stan = String.valueOf(Integer.valueOf(stan) +1);
            this.targetTmm.setStan(stan);
            this.baseMessage.set(fieldNo, stan);
            this.targetTmm.setSchemeStan(stan);
        } else {
            super.setStan(fieldNo);
            this.baseMessage.set(fieldNo, this.targetTmm.getStan());
            this.targetTmm.setSchemeStan(this.targetTmm.getStan());
        }
    }

    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    @Override
    public void setLocalTxnTime(int fieldNo) {
        String localTxnTime = this.originalTmm.getLocalTxnTime();
        originalTmm.getLocalTxnTime();
        this.targetTmm.setLocalTxnTime(localTxnTime);
        this.baseMessage.set(fieldNo, localTxnTime);
    }

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */
    @Override
    public void setLocalTxnDate(int fieldNo) {
        String localTxnDate = this.originalTmm.getLocalTxnDate();
        this.targetTmm.setLocalTxnDate(localTxnDate);
        this.baseMessage.set(fieldNo, localTxnDate);
    }

    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */
   /* @Override
    public void setExpirationDate(int fieldNo) {
        String expiryDate = this.sourceTmm.getExpirationDate();
        this.targetTmm.setExpirationDate(expiryDate);
        this.baseMessage.set(fieldNo, expiryDate);
    }*/

    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */
    @Override
    public void setSettlementDate(int fieldNo) {
        String settleDate = null;
        if(!StringUtils.isBlank(this.sourceTmm.getSettlementDate())){
            settleDate = this.sourceTmm.getSettlementDate();
        }else{
            settleDate =   MtmUtil.formatDate("MMdd", ZoneId.of("GMT"));
        }
        this.targetTmm.setSettlementDate(settleDate);
        this.baseMessage.set(fieldNo, settleDate);
    }

    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */


    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */


    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */
    @Override
    public void setMerchantType(int fieldNo) {
        String merchantType = this.originalTmm.getMerchantType();
        this.targetTmm.setMerchantType(merchantType);
        this.baseMessage.set(fieldNo, merchantType);
    }

    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */

    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */
    /**
     * 22. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled It is mandatory for all type of transactions
     */
    @Override
    public void setPosEntryMode(int fieldNo) {
        String posEntryMode = this.originalTmm.getPosEntryMode();
        this.targetTmm.setPosEntryMode(posEntryMode);
        this.baseMessage.set(fieldNo, posEntryMode);
    }

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */
    @Override
    public void setCardSeqNo(int fieldNo) {
    	/*String cardSeqNo = this.originalTmm.getCardSeqNo();
    	if(!cardSeqNo.equals("0")) {
    		this.targetTmm.setCardSeqNo(cardSeqNo);
    		this.baseMessage.set(fieldNo, cardSeqNo);
    	}*/

    }
    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    @Override
    public void setPosConditionCode(int fieldNo) {
        this.targetTmm.setPosConditionCode(this.sourceTmm.getPosConditionCode());
        this.baseMessage.set(fieldNo, this.sourceTmm.getPosConditionCode());
    }

    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */


    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */


    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */


    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */


    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */


    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    @Override
    public void setAquirerIdCode(int fieldNo) {
        String acquirerInstitutionId = this.originalTmm.getAquirerIdCode();
        this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
        this.baseMessage.set(fieldNo, acquirerInstitutionId);
    }

    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */


    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */

    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     *
     */
    @Override
    public void setTrack2Data(int fieldNo) {
        if(this.sourceTmm.getTrack2Data() != null) {
            String decryptedData = this.sourceTmm.getTrack2Data();
            this.targetTmm.setTrack2Data(decryptedData);
            this.baseMessage.set(fieldNo, decryptedData.replace("D", "="));
        }
    }


    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */


    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {
        this.targetTmm.setRetrievalRefNo(this.originalTmm.getRetrievalRefNo());
        this.baseMessage.set(fieldNo, this.originalTmm.getRetrievalRefNo());
    }
    
    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */


    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     */


    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */


    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     *
     * It is mandatory for Balance Inquiry ,for other transactions it is conditional
     *
     */
    @Override
    public void setCardAcceptorId(int fieldNo) {
        super.setCardAcceptorId(fieldNo);
    }
    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     *
     * It is mandatory for all type of transactions
     */

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     * <p>
     * It is mandatory for all type of transactions
     */
    @Override
    public void setCardAcceptorInfo(int fieldNo) {
        String merName = StringUtils.rightPad(this.merchantData.getMerchantName(), 25);
        String merCity = StringUtils.rightPad(this.merchantData.getMerchantCity(), 13);
        String merchantName = merName.substring(0,25);
        String merchantCity = merCity.substring(0,13);
        String merchantCountryShortCode = StringUtils.rightPad(this.merchantData.getMerchantShortCountryCode(), 2); // e.g. IN

        String cardAcceptorInfo = merchantName + merchantCity + merchantCountryShortCode;
        this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
        this.baseMessage.set(fieldNo, cardAcceptorInfo.getBytes());
    }

    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */


    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */


    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */


    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */
    @Override
    public void setNationalAd(int fieldNo) {
        String nationalAd = this.originalTmm.getNationalAd();
        if(null == nationalAd || StringUtils.isBlank(nationalAd)){
            this.targetTmm.setNationalAd(this.sourceTmm.getNationalAd());
            this.baseMessage.set(fieldNo, this.sourceTmm.getNationalAd());
        }else{
            this.targetTmm.setNationalAd(this.originalTmm.getNationalAd());
            this.baseMessage.set(fieldNo, this.originalTmm.getNationalAd());
        }
    }

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */


    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */
    /* It is mandatory for all type of transactions */


    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */


    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */


    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */

    @Override
    public void setPin(int fieldNo) {
        String pan = this.sourceTmm.getPan();

        if (pan != null && this.sourceTmm.getPin() != null) {
            TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(this.sourceTmm.getTarget());
            String dynamicKey= null;
            EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1));
            KeyModel keyModel = eftposKeyModel.getTargetKey().entrySet().stream().filter(e -> e.getKey().equals(sourceTmm.getTarget())).map(Map.Entry::getValue).findFirst().orElse(null);
            dynamicKey = keyModel.getZpkUnderLMK();

            Map<HsmCommandArg, String> hsmCmdArgMap = cacheServices.getMftrBDK(sourceTmm.getDeviceMftr());
            String pinTranslation = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).pinTranslation(
                    this.sourceTmm.getEntityId(), this.sourceTmm.getSource(), this.sourceTmm.getTarget(),
                    this.sourceTmm.getPinblockKsn(), this.sourceTmm.getPin(), pan, dynamicKey, hsmCmdArgMap == null ? null : hsmCmdArgMap.get(HsmCommandArg.Bdk2));

            byte[] pinBytes = MtmUtil.toBytesAsIs(pinTranslation);
            this.targetTmm.setPin(pinTranslation);
            this.apiTargetTmm.setPin(ISOUtil.byte2hex(pinBytes));
            this.baseMessage.set(fieldNo, pinBytes);
        }
    }

    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */
    @Override
    public void setSecurityControlInfo(int fieldNo) {
        String securityControlInfo = null;
        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSigOn(this.sourceTmm) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            securityControlInfo = this.sourceTmm.getSecurityControlInfo();
            this.targetTmm.setSecurityControlInfo(securityControlInfo);
            this.baseMessage.set(fieldNo, securityControlInfo);
        }else{
            if (!("0820".equals(this.sourceTmm.getMsgType()) && this.sourceTmm.getTransactionCategory().name().equals(TransactionCategory.SIGNOFF.name()))) {
                EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1));
                this.targetTmm.setSecurityControlInfo(eftposKeyModel.getKeySetId());
                this.baseMessage.set(fieldNo, eftposKeyModel.getKeySetId());
            }
        }
    }

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */
    @Override
    public void setAdditionalAmounts(int fieldNo) {
        if (isEftposCashbackRequest(this.sourceMsgType, this.sourceMsgTypeId)) {
            String typeOfAccount = this.sourceTmm.getProcessingCode().substring(3, 4);
            final String amtType = "56";
            String currencyCode = "036";
            final String debit = "D";
            String additionalAmts = this.sourceTmm.getAdditionalAmounts();
            String finalValue = typeOfAccount + amtType + currencyCode + debit + additionalAmts;
            this.targetTmm.setAdditionalAmounts(additionalAmts);
            this.baseMessage.set(fieldNo, finalValue);
        }
    }

    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */
    @Override
    public void setIccData(int fieldNo) {
        if(null == this.originalTmm.getIccData() || StringUtils.isBlank(this.originalTmm.getIccData())){
            /*
             * Reason to convert the data to as is bytes is because JPOS data type is
             * HBINARY
             */
            String txnAmt = "0";
            String cashTxnAmt = "0";
            String iccData = this.sourceTmm.getIccData();
            if (iccData != null) {
                TLVList list = new TLVList();
                TLVList newList = new TLVList();
                list.unpack(ISOUtil.hex2byte(iccData));
                for (TLVMsg tlvMsg : list.getTags()) {
                    if (!TmmConstants.eftposEmvTagSuppressList.contains(tlvMsg.getTag())) {
                        newList.append(tlvMsg.getTag(), tlvMsg.getStringValue());
                    }
                    if (tlvMsg.getTag() == Integer.parseInt("9F02", 16)) {
                        txnAmt = tlvMsg.getStringValue();
                    }
                    if (tlvMsg.getTag() == Integer.parseInt("9F03", 16)) {
                        cashTxnAmt = tlvMsg.getStringValue();
                    }
                }
                // Amount Changes
                long txnAmount = Long.valueOf(txnAmt);
                long cashAmount = Long.valueOf(cashTxnAmt);
                if (txnAmount != cashAmount) {
                    newList.append(Integer.parseInt("9F02", 16), StringUtils.leftPad(String.valueOf(txnAmount - cashAmount), 12, "0"));
                    newList.append(Integer.parseInt("9F03", 16), StringUtils.leftPad(String.valueOf(cashAmount), 12, "0"));
                } else {
                    newList.append(Integer.parseInt("9F02", 16), txnAmt);
                    newList.append(Integer.parseInt("9F03", 16), cashTxnAmt);
                }

                byte[] pack = newList.pack();
                iccData = ISOUtil.hexString(pack);
                byte[] iccDataBytesAsIs = MtmUtil.toBytesAsIs(iccData);

                this.targetTmm.setIccData(iccData);
                this.baseMessage.set(fieldNo, iccDataBytesAsIs);
            }
        }else {
            byte[] iccDataBytesAsIs = MtmUtil.toBytesAsIs(this.originalTmm.getIccData());
            this.targetTmm.setIccData( this.originalTmm.getIccData());
            this.baseMessage.set(fieldNo,  iccDataBytesAsIs);
        }
    }

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */
    @Override
    public void setReserved57(int fieldNo) {
        long txnAmount = Long.valueOf(this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0");
        long cashAmount = Long.valueOf(this.sourceTmm.getAdditionalAmounts() != null ? this.sourceTmm.getAdditionalAmounts() : "0");

        if(txnAmount > cashAmount && this.targetTmm.getProcessingCode().substring(0,2).equals("09")){
            this.targetTmm.setReserved57(StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(),12, "0"));
            this.baseMessage.set(fieldNo,StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(), 12, "0"));
        } else if (txnAmount == cashAmount && this.targetTmm.getProcessingCode().substring(0,2).equals("01")) {
            this.targetTmm.setReserved57(StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(),12, "0"));
            this.baseMessage.set(fieldNo,StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(), 12, "0"));
        } else{
            this.targetTmm.setReserved57("000000000000");
            this.baseMessage.set(fieldNo,"000000000000");
        }
    }

    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */


    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */


    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     * <p>
     * It is mandatory for all type of transactions
     */

    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     */

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */

    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     * <p>
     * It is mandatory for all type of transactions
     */

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */
    public void setMac(int fieldNo) {
        this.targetTmm.setMsgAuthCode("0000000000000000");
        this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs("0000000000000000"));
    }

    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */


    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */

    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */


    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */


    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     *
     */


    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */
    @Override
    public void setNetworkMgmtInfoCode(int fieldNo) {
        String networkMgmtInfoCode = null;

        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isSignOnRequest(this.sourceMsgType) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm)
                || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            switch (this.sourceTmm.getTransactionCategory()) {
                case SIGNON:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNON_NW_INFO_CODE;
                    break;
                case DYNAMIC_KEY_EXCHANGE:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_KEYEXCHANE_NW_INFO_CODE;
                    break;
                case HEARTBEAT:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_HEARTBEAT_NW_INFO_CODE;
                    break;
                case SIGNOFF:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNOFF_NW_INFO_CODE;
                    break;
                default:
                    networkMgmtInfoCode = this.sourceTmm.getNetworkMgmtInfoCode();
            }
        }else{
            switch (this.sourceTmm.getTransactionCategory()) {
                case SIGNON:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNON_NW_INFO_CODE;
                    break;
                case DYNAMIC_KEY_EXCHANGE:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_KEYEXCHANE_NW_INFO_CODE;
                    break;
                case HEARTBEAT:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_HEARTBEAT_NW_INFO_CODE;
                    break;
                case SIGNOFF:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNOFF_NW_INFO_CODE;
                    break;
                default:
                    networkMgmtInfoCode = this.sourceTmm.getNetworkMgmtInfoCode();
            }
        }
        this.targetTmm.setNetworkMgmtInfoCode(networkMgmtInfoCode);
        this.baseMessage.set(fieldNo, networkMgmtInfoCode);
    }
    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */


    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */


    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */


    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */

    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */


    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */


    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */


    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */


    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */


    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */


    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */


    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */


    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */


    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */


    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */


    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */


    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */


    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */


    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */


    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */
    @Override
    public void setOriginalDataElements(int fieldNo) {
        String msgType=this.originalTmm.getMsgType();
        String stan=this.originalTmm.getStan();
        String transmissionTime = this.originalTmm.getTransmissionTime();
        String acquirerId =StringUtils.leftPad(this.originalTmm.getAquirerIdCode(),11,"0");
        String fwdInstId="00000000000";
        String originalDataElements=msgType+stan+transmissionTime+acquirerId+fwdInstId;
        this.targetTmm.setOriginalDataElements(originalDataElements);
        this.baseMessage.set(fieldNo, originalDataElements);
    }

    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */


    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */


    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */


    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */


    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */


    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */


    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */


    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */


    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */


    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */


    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */


    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */


    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */


    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */

    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */


    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */


    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */


    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */


    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */


    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */


    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */


    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */


    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */


    /**
     * 128.<br>
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */
    @Override
    public void setReserved128(int fieldNo) {
        this.targetTmm.setReserved128("0000000000000000");
        this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs("0000000000000000"));
    }

}
