package com.isg.mw.mtm.exception;

public class InvalidTxnAmtException extends RuntimeException  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTxnAmtException(String expMsg) {
		super(expMsg);
	}

	public InvalidTxnAmtException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}