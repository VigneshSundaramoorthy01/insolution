package com.isg.mw.mtm.construct.amex;

import com.isg.mw.mtm.util.MtmUtil;

public class VoidReversalAmexMessageConstruction extends PgVoidReversalAmexMessageConstruction  {

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */


    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */


    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        String msgTypeId = null;
        if((this.sourceTmm.getResCode() != null && this.sourceTmm.getAuthIdRes() != null)
        		|| (this.originalTmm.getResCode() != null && this.originalTmm.getAuthIdRes() != null)) {
        	msgTypeId = "024000";
        }else{
            msgTypeId = "004000";
        }
        this.targetTmm.setProcessingCode(msgTypeId);
        this.baseMessage.set(fieldNo, msgTypeId);
    }
    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     * <p>
     * It is mandatory for all type of transactions
     */

    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */


    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */


    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */


    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */


    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */


    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    /*@Override
    public void setStan(int fieldNo) {
        String stan = this.originalTmm.getStan();
        this.targetTmm.setStan(stan);
        this.baseMessage.set(fieldNo, stan);
    }*/


    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    @Override
    public void setLocalTxnTime(int fieldNo) {
        String localTxnTime = MtmUtil.formatDate("YYMMddhhmmss");
        this.targetTmm.setLocalTxnTime(localTxnTime);
        this.baseMessage.set(fieldNo, localTxnTime);
    }

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */


    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */

    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */


    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */


    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */


    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */


    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */


    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */


    /**
     * 22.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled
     * <p>
     * It is mandatory for all type of transactions
     */
    @Override
    public void setPosEntryMode(int fieldNo) {
    	String posEntryMode = this.originalTmm.getPosEntryMode();

		this.targetTmm.setPosEntryMode(posEntryMode);
		this.baseMessage.set(fieldNo, posEntryMode);
	}

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */


    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */


    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    @Override
    public void setPosConditionCode(int fieldNo) {
        String posConditioncode = "1400";

        this.targetTmm.setPosConditionCode(posConditioncode);
        this.baseMessage.set(fieldNo, posConditioncode);
    }

    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */
    @Override
    public void setPosCaptureCode(int fieldNo) {
    	String posCaptureCode=this.originalTmm.getPosCaptureCode();
    	if (posCaptureCode == null) {
    		posCaptureCode = this.merchantData.getMerchantType();
    	}
        this.targetTmm.setPosCaptureCode(posCaptureCode);
        this.baseMessage.set(fieldNo, posCaptureCode.getBytes());
    }

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */


    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */


    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */


    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */


    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */
    @Override
    public void setSettlementProcessingFee(int fieldNo) {
    	String aqurRefData = this.sourceTmm.getOriginalTmm().getSettlementProcessingFee();
    	this.targetTmm.setSettlementProcessingFee(aqurRefData);
    	this.baseMessage.set(fieldNo, aqurRefData);
    }
    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    /* It is mandatory for all type of transactions */

    @Override
    public void setAquirerIdCode(int fieldNo) {
        String acquirerInstitutionId = this.sourceTmm.getOriginalTmm().getAquirerIdCode();
        this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
        this.baseMessage.set(fieldNo, acquirerInstitutionId);
    }
    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */
    @Override
    public void setForwardingInstIdCode(int fieldNo) {
        String forwardingInstitutionId = this.originalTmm.getForwardingInstIdCode();
        this.targetTmm.setForwardingInstIdCode(forwardingInstitutionId);
        this.baseMessage.set(fieldNo, forwardingInstitutionId);
    }

    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */

    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     *
     */


    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */


    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {
        String rrn=this.sourceTmm.getRetrievalRefNo();
        this.targetTmm.setRetrievalRefNo(rrn);
        this.baseMessage.set(fieldNo, rrn);
    }

    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */


    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     * <p>
     * It is mandatory for reversal and void only
     */


    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */


    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     */

    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     */

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     * <p>
     * Logic:<br>
     * Switch has to extract it from Merchant / POS Master table and send it to
     * Scheme. card acceptor name (1-22),<br>
     * space(23),<br>
     * city name (24-36),<br>
     * space(37),<br>
     * Country code (38-40)
     */


    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */


    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */


    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */


    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */
    @Override
    public void setNationalAd(int fieldNo) {
    	
    }

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */
    /* It is mandatory for all type of transactions */

    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */


    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */


    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */


    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */


    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */


    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */


    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */
    @Override
    public void setReserved56(int fieldNo) {
        String originalDataElements = this.originalTmm.getMsgType() + this.originalTmm.getStan() + this.originalTmm.getLocalTxnTime() + "\\";
        //for now there is no aquirerIdCode for amex changes done on 09/08/2022
        //(this.originalTmm.getAquirerIdCode() == null ? "\\" : StringUtils.leftPad(String.valueOf(this.originalTmm.getAquirerIdCode().length()), 2, "0") + this.originalTmm.getAquirerIdCode());
        this.targetTmm.setReserved56(originalDataElements);
        this.baseMessage.set(fieldNo, originalDataElements.getBytes());
    }

/**
 * 57.<br>
 * ISO8583-1987,Base24, XML - Reserved for national use<br>
 * AS2805 - Amount cash
 */


    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */


    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */


    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     */


    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     * <p>
     * Other transactions: 0000000000800356POSTAL<br>
     * PreAuth: 0000004000800356POSTAL<br>
     * MOTO: 2032102000800356POSTAL<br>
     * POSTAL means-- 6 digit postal code of merchant.<br>
     * <p>
     * Note: It is mandatory for all type of transactions
     */

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */


    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     */

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */


    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */


    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */


    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */


    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */


    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     *
     */


    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */

    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */


    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */


    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */


    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */


    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */


    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */


    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */


    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */


    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */


    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */


    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */


    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */


    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */


    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */


    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */


    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */


    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */


    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */


    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */


    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */


    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */


    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */


    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */


    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */


    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */

    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */

    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */


    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */


    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */


    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */


    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */


    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */


    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */


    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */


    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */


    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */


    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */


    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */


    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */


    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */


    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */


    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */


    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */

    /**
     * 128.<br>dddd
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */

}
