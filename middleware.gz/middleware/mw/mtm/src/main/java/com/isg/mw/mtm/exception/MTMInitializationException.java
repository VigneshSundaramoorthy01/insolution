package com.isg.mw.mtm.exception;

public class MTMInitializationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MTMInitializationException(String errorMsg) {
		super(errorMsg);
	}

	public MTMInitializationException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}

}
