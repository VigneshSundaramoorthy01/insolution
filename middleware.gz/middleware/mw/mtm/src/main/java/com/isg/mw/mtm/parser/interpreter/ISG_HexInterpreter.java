package com.isg.mw.mtm.parser.interpreter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.BinaryInterpreter;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.LiteralBinaryInterpreter;

import com.isg.mw.mtm.util.MtmUtil;

public class ISG_HexInterpreter implements BinaryInterpreter {
	private Logger logger = LogManager.getLogger();

	public static final ISG_HexInterpreter INSTANCE = new ISG_HexInterpreter();

	@Override
	public void interpret(byte[] data, byte[] b, int offset) {
		LiteralBinaryInterpreter.INSTANCE.interpret(data, b, offset);
	}

	@Override
	public byte[] uninterpret(byte[] rawData, int offset, int length) {
		byte[] dataBytes = LiteralBinaryInterpreter.INSTANCE.uninterpret(rawData, offset, length);
		byte[] finalDataBytes = new byte[(1 + length) / 2];
		if (length % 2 != 0) {
			length = length + 1;
			byte[] tempBytes = new byte[length / 2];
			logger.trace("ISOUtil.hexString(dataBytes): {}", ISOUtil.hexString(dataBytes));
			ISOUtil.str2hex(ISOUtil.hexString(dataBytes), true, tempBytes, 0);
			logger.trace("temp bytes length: {}, finaldatabytes length: {}", tempBytes.length, finalDataBytes.length);
			finalDataBytes = tempBytes;
			byte x = finalDataBytes[0];
			logger.trace("x: {}", x);
			finalDataBytes[0] = (byte) ((x & 0x0F) << 4 | (x & 0xF0) >> 4);
		} else {
			ISOUtil.str2hex(new String(dataBytes), true, finalDataBytes, 0);
		}
		return finalDataBytes;
	}

	@Override
	public int getPackedLength(int nBytes) {
		return nBytes;
	}

}
