package com.isg.mw.mtm.exception;

public class BankServerException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String entityId;
    private String merchantTxnRefNo;
    private String mid;

    public BankServerException(String errorMsg,String entityId,String mid,String merchantTxnRefNo) {
        super(errorMsg);
        this.mid = mid;
        this.entityId = entityId;
        this.merchantTxnRefNo = merchantTxnRefNo;
    }

    public String getEntityId() {return entityId;}

    public String getMerchantTxnRefNo() {return merchantTxnRefNo;}

    public String getMid() {return mid;}

    public BankServerException(String errorMsg) {
        super(errorMsg);
    }

    public BankServerException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}