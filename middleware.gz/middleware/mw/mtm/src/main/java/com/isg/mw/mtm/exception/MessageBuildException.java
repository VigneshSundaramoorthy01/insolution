package com.isg.mw.mtm.exception;

public class MessageBuildException extends MessageTransformationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageBuildException(String expMsg) {
		super(expMsg);
	}

	public MessageBuildException(String expMsg, Throwable e) {
		super(expMsg, e);
	}
}
