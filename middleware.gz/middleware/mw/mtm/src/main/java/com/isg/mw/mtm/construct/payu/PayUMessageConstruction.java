package com.isg.mw.mtm.construct.payu;

import com.isg.mw.cache.mgmt.config.CacheTargetPaymentModeAndOptions;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.construct.payu.PayUMsgTypeHelper;
import com.isg.mw.core.model.sr.TargetPaymentModeOptionsModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageTransformationContext;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.stream.Collectors;

public class PayUMessageConstruction extends SwitchBaseMessageConstruction implements IMessageConstruction {

    @Override
    public void setIccData(int fieldNo) {
        // ICC data is not required for this implementation
    }

    public void setKey(String key) {
        this.targetTmm.getSmartRouteData().getPayUData().setKey(key);
    }

    public String setTransactionId() {
        return this.targetTmm.getTransactionId();
    }

    public String setTxnAmt() {
        this.targetTmm.setTxnAmt(this.sourceTmm.getTxnAmt());
        BigDecimal amount = getTotalAmountInPaisaIfCCSIinPaisa(this.sourceTmm);
        return amount.toString();
    }

    public String setProductionInfo() {
        this.targetTmm.getSmartRouteData().setOrderInfo(this.sourceTmm.getSmartRouteData().getOrderInfo());
        return this.targetTmm.getSmartRouteData().getOrderInfo();
    }

    public String setFirstName() {
        this.targetTmm.getSmartRouteData().getPayUData().setFirstname(this.merchantData.getMerchantName());
        return this.targetTmm.getSmartRouteData().getPayUData().getFirstname();
    }

    public String setEmail() {
        this.targetTmm.getSmartRouteData().getPayUData().setEmail("dummyemail@dummy.com");
        return this.targetTmm.getSmartRouteData().getPayUData().getEmail();
    }

    public String setPhone() {
        String customerMobNo = StringUtils.defaultIfBlank(this.targetTmm.getSmartRouteData().getCustomerMobNo(),"0123456789");
        this.targetTmm.getSmartRouteData().getPayUData().setPhone(customerMobNo);
        return this.targetTmm.getSmartRouteData().getPayUData().getPhone();
    }

    public String setSUrl() {
        this.targetTmm.getSmartRouteData().getPayUData().setSurl(this.sourceTmm.getSmartRouteData().getReturnUrl());
        return this.targetTmm.getSmartRouteData().getPayUData().getSurl();
    }

    public String setFUrl() {
        this.targetTmm.getSmartRouteData().getPayUData().setFurl(this.sourceTmm.getSmartRouteData().getReturnUrl());
        return this.targetTmm.getSmartRouteData().getPayUData().getFurl();
    }

    public String setBankCode() {
        // // for NB - TESTPGNB, Wallet - PAYTM, AMZPAY
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(this.targetTmm.getTarget());
        CacheTargetPaymentModeAndOptions tgtPayModeAndOpsData = srCacheService.getTargetPayModeAndOptionsData(this.targetTmm.getEntityId(), targetId,
                this.targetTmm.getSmartRouteData().getPayModeId(), this.targetTmm.getSmartRouteData().getPayModeOptionId());
        TargetPaymentModeOptionsModel targetPaymentModeOptionsModel = tgtPayModeAndOpsData.getTargetPaymentModeOptions().stream().filter(tgtPayModeOpt -> tgtPayModeOpt.getPaymentModeOptionId().toString().equals(this.targetTmm.getSmartRouteData().getPayModeOptionId())).collect(Collectors.toList()).get(0);
        this.targetTmm.getSmartRouteData().getPayUData().setBankcode(targetPaymentModeOptionsModel.getAdditionalData().getExternalIdentifier());
        return this.targetTmm.getSmartRouteData().getPayUData().getBankcode();
    }

    public String setPg() {
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(this.targetTmm.getTarget());
        CacheTargetPaymentModeAndOptions tgtPayModeAndOpsData = srCacheService.getTargetPayModeAndOptionsData(this.targetTmm.getEntityId(), targetId,
                this.targetTmm.getSmartRouteData().getPayModeId(), this.targetTmm.getSmartRouteData().getPayModeOptionId());
        // for NB - TESTPG, Wallet - CASH
        this.targetTmm.getSmartRouteData().getPayUData().setPg(tgtPayModeAndOpsData.getTargetPaymentMode().getAdditionalData().getExternalIdentifier());
        return this.targetTmm.getSmartRouteData().getPayUData().getPg();
    }

    public String setUdf1() {
        this.targetTmm.getSmartRouteData().getPayUData().setUdf1(this.sourceTmm.getSmartRouteData().getMerchantTxnRefNo());
        return this.targetTmm.getSmartRouteData().getPayUData().getUdf1();
    }

    public String setUdf3() {
        this.targetTmm.getSmartRouteData().getPayUData().setUdf3(this.sourceTmm.getLinkHashId());
        return this.targetTmm.getSmartRouteData().getPayUData().getUdf3();
    }

    public String setUdf2() {
        this.targetTmm.getSmartRouteData().getPayUData().setUdf2(this.sourceTmm.getCardAcceptorId());
        return this.targetTmm.getSmartRouteData().getPayUData().getUdf2();
    }

    public String setUdf4() {
        this.targetTmm.getSmartRouteData().getPayUData().setUdf4(this.sourceTmm.getCardAcceptorTerminalId());
        return this.targetTmm.getSmartRouteData().getPayUData().getUdf4();
    }

    public String setHash(String salt) {
        TransactionMessageModel.PayUData payUData = this.targetTmm.getSmartRouteData().getPayUData();
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");

            String requestDetails;
            if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
                requestDetails = payUData.getKey() + "|"
                        + payUData.getCommand() + "|"
                        + payUData.getVar1() + salt;
            } else {
                requestDetails = payUData.getKey() + "|"
                        + this.targetTmm.getTransactionId() + "|"
                        + this.targetTmm.getTxnAmt() + "|"
                        + this.targetTmm.getSmartRouteData().getOrderInfo() + "|"
                        + payUData.getFirstname() + "|"
                        + payUData.getEmail() + "|"
                        + StringUtils.defaultIfBlank(payUData.getUdf1(), "") + "|"
                        + StringUtils.defaultIfBlank(payUData.getUdf2(), "") + "|"
                        + StringUtils.defaultIfBlank(payUData.getUdf3(), "") + "|"
                        + StringUtils.defaultIfBlank(payUData.getUdf4(), "") + "|"
                        + StringUtils.defaultIfBlank(payUData.getUdf5(), "") + "|"
                        + "|" + "|" + "|" + "|" + "|" + salt;
            }
            requestDetails = requestDetails.trim();
            byte[] messageDigest = md.digest(requestDetails.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);

            // Add preceding 0s to make it 32 bit
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }

            payUData.setHash(hashtext);
        }

        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        return payUData.getHash();
    }

    public String calculateResponseHash(String salt) {
        TransactionMessageModel.PayUData payUData = this.sourceTmm.getSmartRouteData().getPayUData();
        try {
            String requestDetails = salt + "|"
                    + payUData.getStatus() + "|"
                    + "|" + "|" + "|" + "|" + "|"
                    + StringUtils.defaultIfBlank(payUData.getUdf5(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getUdf4(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getUdf3(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getUdf2(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getUdf1(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getEmail(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getFirstname(), "") + "|"
                    + StringUtils.defaultIfBlank(payUData.getProductinfo(), "") + "|"
                    + StringUtils.defaultIfBlank(this.sourceTmm.getTxnAmt(), "") + "|"
                    + StringUtils.defaultIfBlank(this.sourceTmm.getTransactionId(), "") + "|"
                    + payUData.getKey();

            requestDetails = requestDetails.trim();
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] messageDigest = md.digest(requestDetails.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);

            // Add preceding 0s to make it 32 bit
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String setCommand() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setCommand("cancel_refund_transaction");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getCommand();
    }

    //PayuId
    public String setVar1() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar1("403993715521937565");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar1();
    }

    //SecreteTokenAtYourEnd
    public String setVar2() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar2("20201105");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar2();
    }

    //Amount
    public String setVar3() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar3("10");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar3();
    }

    //InternalUse
    public String setVar4() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar4("");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar4();
    }

    //Status call-back URL
    public String setVar5() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar5("");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar5();
    }

    //Alternate channel details
    //Note: This parameter is mandatory for instant refunds where
    // {"refund_mode":"2","be neficiary_full_name":""," beneficiary_account":"", "beneficiary_ifsc":""}.
    // For more information, refer to Instant Refunds.
    public String setVar6() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar6("");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar6();
    }

    //Refund Split Info
    //Refund split information provided by merchant
    // in a JSON format. This is applicable only with the Split transactions
    public String setVar8() {
        if (PayUMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.getSmartRouteData().getPayUData().setVar8("");
        }
        return this.targetTmm.getSmartRouteData().getPayUData().getVar8();
    }

}
