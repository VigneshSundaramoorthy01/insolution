package com.isg.mw.mtm.rawlog.endpoint;

import com.isg.mw.core.model.tlm.TransactionMessageModel;
import org.jpos.iso.ISOField;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isMasterCardCashbackRequest;

public class Master {

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */
    public static String getAdditionalAmounts(Object isoObj, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm) {
        String value = null;
        if (isMasterCardCashbackRequest(srcTmm.getMsgType(), srcTmm.getProcessingCode())) {
            ISOField isoField = (ISOField) isoObj;
            value = isoField.getValue().toString();
        }
        return value;
    }
}
