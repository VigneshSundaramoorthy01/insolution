package com.isg.mw.mtm.exception;

public class InvalidCardNumberException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidCardNumberException(String errorMsg) {
		super(errorMsg);
	}

	public InvalidCardNumberException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}

}
