package com.isg.mw.mtm.parser.interpreter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.EbcdicHexInterpreter;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.Interpreter;

public class HexToEbcdicInterpreter implements Interpreter {

	private Logger logger = LogManager.getLogger(getClass());

	private boolean leftPadded;
	private boolean fPadded;

	public static final HexToEbcdicInterpreter INSTANCE = new HexToEbcdicInterpreter();

	public static void main(String[] args) throws ISOException {
		HexToEbcdicInterpreter h = new HexToEbcdicInterpreter();
		h.interpret("HPYBL007", "HPYBL007".getBytes(), 0);
	}

	@Override
	public void interpret(String data, byte[] b, int offset) throws ISOException {
//		System.out.println(ISOUtil.byte2hex(b, offset, data.length()));
		ISOUtil.str2hex(data, leftPadded, b, offset);
		// if (fPadded && !leftPadded && data.length()%2 == 1)
		// b[b.length-1] |= (byte)(b[b.length-1] << 4) == 0 ? 0x0F : 0x00;
		int paddedSize = data.length() >> 1;
		if (fPadded && data.length() % 2 == 1)
			if (leftPadded)
				b[offset] |= (byte) 0xF0;
			else
				b[offset + paddedSize] |= (byte) 0x0F;
	}

	@Override
	public String uninterpret(byte[] rawData, int offset, int length) throws ISOException {
		String str = new String(rawData, offset, length, ISOUtil.CHARSET);
//		EbcdicHexInterpreter e2 = new EbcdicHexInterpreter();
//		byte[] uninterpret = e2.uninterpret(rawData, offset, length);
//		String aa = new String(uninterpret);
		return convertHexToString(str);
	}

	/**
	 * Converts the given string to Hex format
	 * 
	 * @param hex
	 * @return
	 */
	public String convertHexToString(String hex) {
		StringBuilder sb = new StringBuilder();
		StringBuilder temp = new StringBuilder();
		for (int i = 0; i < hex.length() - 1; i += 2) {
			// grab the hex in pairs
			String output = hex.substring(i, (i + 2));
			// convert hex to decimal
			int decimal = Integer.parseInt(output, 16);
			// convert the decimal to character
			sb.append((char) decimal);

			temp.append(decimal);
		}
		return sb.toString();
	}

	@Override
	public int getPackedLength(int nDataUnits) {
		return nDataUnits;
	}

}
