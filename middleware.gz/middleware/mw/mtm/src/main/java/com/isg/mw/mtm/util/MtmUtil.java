package com.isg.mw.mtm.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.constants.TargetType;

import lombok.Getter;
import org.apache.logging.log4j.ThreadContext;
import org.jpos.iso.ISOUtil;

public class MtmUtil {

    private static Logger logger = LogManager.getLogger(MtmUtil.class);

    public static final int POS_ENTRY_MODE_DATA_LENGTH = 3;

    @Getter
    private static final List<String> POS_ENTRY_MODE_DATA = new ArrayList<>();

    @Getter
    private static final Map<String, HashMap<TargetType, List<Integer>>> panEntryModeDataElements = new HashMap<String, HashMap<TargetType, List<Integer>>>();

    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_01 = new HashMap<TargetType, List<Integer>>();
    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_02 = new HashMap<TargetType, List<Integer>>();
    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_05 = new HashMap<TargetType, List<Integer>>();
    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_07 = new HashMap<TargetType, List<Integer>>();
    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_80 = new HashMap<TargetType, List<Integer>>();
    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_90 = new HashMap<TargetType, List<Integer>>();
    private static final HashMap<TargetType, List<Integer>> schemePanEntryMode_91 = new HashMap<TargetType, List<Integer>>();
    @Getter
    private static final HashMap<TargetType, String> cybsCardTypes = new HashMap<>();

    @Getter
    private static final ArrayList<String> contactTxn = new ArrayList<>();
    @Getter
    private static final ArrayList<String> contactlessTxn = new ArrayList<>();
    @Getter
    private static final ArrayList<String> manualAndMotoTxn = new ArrayList<>();

    @Getter
    private static final ArrayList<String> fallbackTxn = new ArrayList<>();

    @Getter
    private static final ArrayList<Character> txnIdLenIdentifier = new ArrayList<>();
    
    @Getter
    private static final ArrayList<String> msrContactlessTxn = new ArrayList<>();


    @Getter
    private static final List<String> visaIccDataTags = Arrays.asList("9F33", "95", "9F37", "9F10", "9F26", "9F36",
            "82", "9C", "9F1A", "9A", "9F02", "5F2A", "9F03", "84");

    @Getter
    private static final List<String> masterIccDataTags = Arrays.asList("9F26", "9F27", "9F10", "9F37", "9F36",
            "95", "9A", "9C", "9F02", "5F2A", "82", "9F1A", "9F34", "9F33", "84", "9F03", "5F34", "9F0A", "9F35",
            "9F1E", "9F53", "9F09", "9F41", "9F33", "9F6E");

    @Getter
    private static final List<String> eftposIccDataTags = Arrays.asList("5A", "9C", "9F02", "9F03", "9F06",
            "84", "8C", "9F10", "9F34", "9F27", "82", "9F34", "9F36", "57", "95", "9A", "9F33", "9F40", "9F35",
            "9F1A", "5F2A", "9F37", "9F26");

    @Getter
    public static final List<Integer> amexIccDataTags = new LinkedList<Integer>() {{
        add(Integer.parseInt("9F26", 16));
        add(Integer.parseInt("9F10", 16));
        add(Integer.parseInt("9F37", 16));
        add(Integer.parseInt("9F36", 16));
        add(Integer.parseInt("95", 16));
        add(Integer.parseInt("9A", 16));
        add(Integer.parseInt("9C", 16));
        add(Integer.parseInt("9F02", 16));
        add(Integer.parseInt("5F2A", 16));
        add(Integer.parseInt("9F1A", 16));
        add(Integer.parseInt("82", 16));
        add(Integer.parseInt("9F03", 16));
        add(Integer.parseInt("5F34", 16));
        add(Integer.parseInt("9F27", 16));
    }};

    static {
        POS_ENTRY_MODE_DATA.add("000");
        POS_ENTRY_MODE_DATA.add("001");
        POS_ENTRY_MODE_DATA.add("002");
        POS_ENTRY_MODE_DATA.add("003");
        POS_ENTRY_MODE_DATA.add("006");
        POS_ENTRY_MODE_DATA.add("008");
        POS_ENTRY_MODE_DATA.add("010");
        POS_ENTRY_MODE_DATA.add("011");
        POS_ENTRY_MODE_DATA.add("012");
        POS_ENTRY_MODE_DATA.add("013");
        POS_ENTRY_MODE_DATA.add("016");
        POS_ENTRY_MODE_DATA.add("018");
        POS_ENTRY_MODE_DATA.add("020");
        POS_ENTRY_MODE_DATA.add("021");
        POS_ENTRY_MODE_DATA.add("022");
        POS_ENTRY_MODE_DATA.add("023");
        POS_ENTRY_MODE_DATA.add("026");
        POS_ENTRY_MODE_DATA.add("028");
        POS_ENTRY_MODE_DATA.add("050");
        POS_ENTRY_MODE_DATA.add("051");
        POS_ENTRY_MODE_DATA.add("052");
        POS_ENTRY_MODE_DATA.add("053");
        POS_ENTRY_MODE_DATA.add("056");
        POS_ENTRY_MODE_DATA.add("058");
        POS_ENTRY_MODE_DATA.add("070");
        POS_ENTRY_MODE_DATA.add("071");
        POS_ENTRY_MODE_DATA.add("072");
        POS_ENTRY_MODE_DATA.add("073");
        POS_ENTRY_MODE_DATA.add("076");
        POS_ENTRY_MODE_DATA.add("078");
        POS_ENTRY_MODE_DATA.add("080");
        POS_ENTRY_MODE_DATA.add("081");
        POS_ENTRY_MODE_DATA.add("082");
        POS_ENTRY_MODE_DATA.add("083");
        POS_ENTRY_MODE_DATA.add("086");
        POS_ENTRY_MODE_DATA.add("088");
        POS_ENTRY_MODE_DATA.add("090");
        POS_ENTRY_MODE_DATA.add("091");
        POS_ENTRY_MODE_DATA.add("092");
        POS_ENTRY_MODE_DATA.add("093");
        POS_ENTRY_MODE_DATA.add("096");
        POS_ENTRY_MODE_DATA.add("098");
        POS_ENTRY_MODE_DATA.add("100");
        POS_ENTRY_MODE_DATA.add("790");
        POS_ENTRY_MODE_DATA.add("791");
        POS_ENTRY_MODE_DATA.add("792");
        POS_ENTRY_MODE_DATA.add("793");
        POS_ENTRY_MODE_DATA.add("796");
        POS_ENTRY_MODE_DATA.add("798");
        POS_ENTRY_MODE_DATA.add("800");
        POS_ENTRY_MODE_DATA.add("801");
        POS_ENTRY_MODE_DATA.add("802");
        POS_ENTRY_MODE_DATA.add("803");
        POS_ENTRY_MODE_DATA.add("806");
        POS_ENTRY_MODE_DATA.add("808");
        POS_ENTRY_MODE_DATA.add("810");
        POS_ENTRY_MODE_DATA.add("811");
        POS_ENTRY_MODE_DATA.add("812");
        POS_ENTRY_MODE_DATA.add("813");
        POS_ENTRY_MODE_DATA.add("816");
        POS_ENTRY_MODE_DATA.add("818");
        POS_ENTRY_MODE_DATA.add("820");
        POS_ENTRY_MODE_DATA.add("821");
        POS_ENTRY_MODE_DATA.add("822");
        POS_ENTRY_MODE_DATA.add("823");
        POS_ENTRY_MODE_DATA.add("826");
        POS_ENTRY_MODE_DATA.add("828");
        POS_ENTRY_MODE_DATA.add("900");
        POS_ENTRY_MODE_DATA.add("901");
        POS_ENTRY_MODE_DATA.add("902");
        POS_ENTRY_MODE_DATA.add("903");
        POS_ENTRY_MODE_DATA.add("906");
        POS_ENTRY_MODE_DATA.add("908");
        POS_ENTRY_MODE_DATA.add("910");
        POS_ENTRY_MODE_DATA.add("911");
        POS_ENTRY_MODE_DATA.add("912");
        POS_ENTRY_MODE_DATA.add("913");
        POS_ENTRY_MODE_DATA.add("916");
        POS_ENTRY_MODE_DATA.add("918");
        POS_ENTRY_MODE_DATA.add("950");
        POS_ENTRY_MODE_DATA.add("951");
        POS_ENTRY_MODE_DATA.add("952");
        POS_ENTRY_MODE_DATA.add("953");
        POS_ENTRY_MODE_DATA.add("956");
        POS_ENTRY_MODE_DATA.add("958");

        schemePanEntryMode_01.put(TargetType.Visa, Arrays.asList(2, 14));
        schemePanEntryMode_01.put(TargetType.Master, Arrays.asList(2, 14));
        schemePanEntryMode_01.put(TargetType.Rupay, Arrays.asList(2, 14));

        schemePanEntryMode_02.put(TargetType.Visa, Arrays.asList(2, 35));
        schemePanEntryMode_02.put(TargetType.Master, Arrays.asList(2, 35));
        schemePanEntryMode_02.put(TargetType.Rupay, Arrays.asList(2, 35));

        schemePanEntryMode_05.put(TargetType.Visa, Arrays.asList(2, 35, 55));
        schemePanEntryMode_05.put(TargetType.Master, Arrays.asList(2, 14, 35, 55));
        schemePanEntryMode_05.put(TargetType.Rupay, Arrays.asList(2, 35, 55));

        schemePanEntryMode_07.put(TargetType.Visa, Arrays.asList(2, 35, 55));
        schemePanEntryMode_07.put(TargetType.Master, Arrays.asList(2, 14, 35, 55));
        schemePanEntryMode_07.put(TargetType.Rupay, Arrays.asList(2, 35, 55));

        schemePanEntryMode_80.put(TargetType.Visa, Arrays.asList(2, 35));
        schemePanEntryMode_80.put(TargetType.Master, Arrays.asList(2, 35));
        schemePanEntryMode_80.put(TargetType.Rupay, Arrays.asList(2, 35));

        schemePanEntryMode_90.put(TargetType.Visa, Arrays.asList(2, 35));
        schemePanEntryMode_90.put(TargetType.Master, Arrays.asList(2, 35));
        schemePanEntryMode_90.put(TargetType.Rupay, Arrays.asList(2, 35));
        
        schemePanEntryMode_91.put(TargetType.Visa, Arrays.asList(2, 35));
        schemePanEntryMode_91.put(TargetType.Master, Arrays.asList(2, 35));
        schemePanEntryMode_91.put(TargetType.Rupay, Arrays.asList(2, 35));


        panEntryModeDataElements.put("01", schemePanEntryMode_01);
        panEntryModeDataElements.put("02", schemePanEntryMode_02);
        panEntryModeDataElements.put("05", schemePanEntryMode_05);
        panEntryModeDataElements.put("07", schemePanEntryMode_07);
        panEntryModeDataElements.put("80", schemePanEntryMode_80);
        panEntryModeDataElements.put("90", schemePanEntryMode_90);
        panEntryModeDataElements.put("91", schemePanEntryMode_91);

        contactTxn.add("02");
        contactTxn.add("05");
        contactTxn.add("80");
        contactTxn.add("90");
        contactTxn.add("91");

        contactlessTxn.add("07");
        contactlessTxn.add("91");
        
        msrContactlessTxn.add("071");

        manualAndMotoTxn.add("01");

        fallbackTxn.add("80");


        txnIdLenIdentifier.add('c');
        txnIdLenIdentifier.add('d');
        txnIdLenIdentifier.add('e');
        txnIdLenIdentifier.add('f');

        cybsCardTypes.put(TargetType.Visa,"001");
        cybsCardTypes.put(TargetType.Master, "002");
        cybsCardTypes.put(TargetType.Cybs, "001");

    }

    public static void invokeMethod(Class<?> className, String methodName) {
        Class<?> noparams[] = {};
        Object obj;
        try {
            obj = className.newInstance();
            Method declaredMethod = className.getDeclaredMethod(methodName, noparams);
            declaredMethod.invoke(obj);
        } catch (InstantiationException | IllegalAccessException | NoSuchMethodException | SecurityException
                | IllegalArgumentException | InvocationTargetException e) {
            logger.error("Error while invoking method", e);
        }
    }

    public static Object invokeMethod(Class<?> className, String methodName, String paramValue) {
        Class<?>[] paramString = new Class[1];
        paramString[0] = String.class;
        Object obj;
        try {
            obj = className.newInstance();
            Method declaredMethod = className.getDeclaredMethod(methodName, paramString);
            Object returedVal = declaredMethod.invoke(obj, new String(paramValue));
            return returedVal;
        } catch (InstantiationException | IllegalAccessException | NoSuchMethodException | SecurityException
                | IllegalArgumentException | InvocationTargetException e) {
            logger.error("Error while invoking method", e);
        }
        return null;
    }

    public static String formatDate(String format) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
        OffsetDateTime now = OffsetDateTime.now();
        return dtf.format(now);
    }

    public static String formatDate(String format, ZoneId zoneId) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
        OffsetDateTime now = OffsetDateTime.now(zoneId);
        return dtf.format(now);
    }

    public static String formatDate(String format, ZoneOffset zoneOffset) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
        OffsetDateTime now = OffsetDateTime.now(ZoneId.of(zoneOffset.getId()));
        return dtf.format(now);
    }

    @SuppressWarnings("unchecked")
    public static <T extends Exception, R> R throwException(Exception t) throws T {
        throw (T) t;
    }

    public static byte[] toBytesAsIs(byte[] bytes) {
        char[] charArray = bytesToChar(bytes);
        byte[] asIsBytes = new byte[charArray.length / 2];
        int j = 0;
        for (int i = 0; i < charArray.length; i++) {
            byte charHex = twoDigitsHexToDecimal(charArray[i++], charArray[i]);
            asIsBytes[j] = charHex;
            j++;
        }
        return asIsBytes;
    }

    public static char[] bytesToChar(byte[] bytes) {
        char[] buffer = new char[bytes.length >> 1];
        for (int i = 0; i < buffer.length; i++) {
            int bpos = i << 1;
            char c = (char) (((bytes[bpos] & 0x00FF) << 8) + (bytes[bpos + 1] & 0x00FF));
            buffer[i] = c;
        }
        return buffer;
    }

    public static byte[] toBytesAsIs(String str) {
        char[] charArray = str.toCharArray();
        byte[] asIsBytes = new byte[charArray.length / 2];
        int j = 0;
        for (int i = 0; i < charArray.length; i++) {
            byte charHex = twoDigitsHexToDecimal(charArray[i++], charArray[i]);
            asIsBytes[j] = charHex;
            j++;
        }
        return asIsBytes;
    }

    public static byte twoDigitsHexToDecimal(char c1, char c2) {
        byte ch = 0;

        ch = (byte) (ch | oneDigitHexToDec(c1));
        ch = (byte) (ch << 4);

        if (c2 != 'Z') {
            ch = (byte) (ch | oneDigitHexToDec(c2));
        }

        return ch;
    }

    public static int oneDigitHexToDec(char c) {
        int b = 0;
        switch (c) {
            case 'A':
                b = 10;
                break;
            case 'B':
                b = 11;
                break;
            case 'C':
                b = 12;
                break;
            case 'D':
                b = 13;
                break;
            case 'E':
                b = 14;
                break;
            case 'F':
                b = 15;
                break;
            case 'a':
                b = 10;
                break;
            case 'b':
                b = 11;
                break;
            case 'c':
                b = 12;
                break;
            case 'd':
                b = 13;
                break;
            case 'e':
                b = 14;
                break;
            case 'f':
                b = 15;
                break;
            default:
                b = c - '0';
                if (b < 0 || b > 10) {
                    logger.error("Invalid digit in raw message, can't convert to decimal");
                }
        }
        return b;
    }

    /*
     *
     * Card bin number is validated using Luhn's algorithm
     */

    public static boolean isValidCardNumber(String cardNumber) {
        int nDigits = cardNumber.length();

        int nSum = 0;
        boolean isSecond = false;
        for (int i = nDigits - 1; i >= 0; i--) {

            int d = cardNumber.charAt(i) - '0';

            if (isSecond == true)
                d = d * 2;

            // We add two digits to handle
            // cases that make two digits
            // after doubling
            nSum += d / 10;
            nSum += d % 10;

            isSecond = !isSecond;
        }
        return (nSum % 10 == 0);
    }

    public static String toISOAmt(Double amt) {
        String tmp = String.format("%.0f", amt, 0).replace(".", "");
        return StringUtils.leftPad(tmp, 12, "0");
    }

    public static String toISODccAmt(Double amt, String decimal) {
        String tmp = String.format("%."+ decimal +"f", amt, 0).replace(".", "");
        return StringUtils.leftPad(tmp, 12, "0");
    }

    /**
     * Converting 17658321652 (String) --> F1F7F6F5F8F3F2F1F6F5F2 (String)
     * because ISOUtil.asciiToEbcdic return byte[] array.
     * and this methode return it as a string
     */
    public static String asciiToEbcdic(String input) {
        StringBuilder retVal = new StringBuilder();
        byte[] array = ISOUtil.asciiToEbcdic(input);

        for (int i = 0; i < array.length; i++) {
            retVal.append(String.format("%X", array[i]));
        }
        return retVal.toString();
    }

    /**
     * @param input Byte[]
     * @return String
     * Eg.
     * 5A0860728600000007009C0100 (byte) -> 5A0860728600000007009C0100 (String)
     */
    public static String byteArrayToString(byte[] input) {
        StringBuilder retVal = new StringBuilder();
        for (Byte i : input) {
            retVal.append(String.format("%02X", i));
        }
        return retVal.toString();
    }

    /**
     * @return String YDDDHH - As per RRN
     */
    public static String generateFirstSixDigitOfRrn() {
        OffsetDateTime offsetDateTime = OffsetDateTime.now();

        char position1 = String.valueOf(offsetDateTime.getYear()).charAt(3);
        String position2TO4 = StringUtils.leftPad(String.valueOf(offsetDateTime.getDayOfYear()), 3, '0');
        String position5TO6 = StringUtils.leftPad(String.valueOf(offsetDateTime.getHour()), 2, '0');

        return position1 + position2TO4 + position5TO6;
    }

    public static String bitset2Hex(final BitSet bitset, final int minLength) {
        final StringBuilder result = new StringBuilder();
        for (int bytenum = 0; bytenum < minLength / 2; bytenum++) {
            byte v = 0;
            for (int bit = 0, mask = 0x80; mask >= 0x01; bit++, mask /= 2) {
                if (bitset.get((bytenum * 8) + bit)) {
                    v |= mask;
                }
            }
            result.append(String.format("%02X", v));
        }
        while (result.length() < minLength) {
            result.append("00");
        }
        return result.toString();
    }

    public static void setLoggerContext(TransactionMessageModel tmm) {
        StringBuilder traceIdBuilder = new StringBuilder();

        Optional.ofNullable(tmm.getCardAcceptorId()).ifPresent(traceIdBuilder::append);
        Optional.ofNullable(tmm.getCardAcceptorTerminalId()).ifPresent(traceIdBuilder::append);
        Optional.ofNullable(tmm.getStan()).ifPresent(traceIdBuilder::append);

        String traceId = traceIdBuilder.toString();
        tmm.setAcpTraceId(traceId);

        ThreadContext.putIfNull(FilterConstants.threadContextAcpTraceId, traceId);
        Optional.ofNullable(tmm.getRetrievalRefNo())
                .ifPresent(rrn -> ThreadContext.putIfNull(FilterConstants.threadContextRetrievalRefNo, rrn));
    }

    public static void clearLoggerContext() {
        ThreadContext.clearAll();
    }
}
