package com.isg.mw.mtm.transform.amex;

import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.MsgFlow;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.core.model.construct.amex.AmexMsgTypeHelper;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.dstm.service.IPinTranslationService;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.amex.AmexMessageConstruction;
import com.isg.mw.mtm.construct.amex.PgAmexMessageConstruction;
import com.isg.mw.mtm.construct.amex.PgVoidReversalAmexMessageConstruction;
import com.isg.mw.mtm.construct.amex.VoidReversalAmexMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.IMessageTransformation;
import com.isg.mw.mtm.transform.MessageTransformer;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;

import javax.xml.bind.DatatypeConverter;
import java.io.ByteArrayOutputStream;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.isg.mw.core.utils.IsgJsonUtils.removeQuotesAndUnescape;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;

public class AmexMessageTransformation extends BaseMessageTransformation implements IMessageTransformation {

    private Logger logger = LogManager.getLogger();
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();


    public TargetType getEpType() {
        return TargetType.Amex;
    }

    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        getSwithToSchemeSignonRequest(tmmConfig);
        getSchemeToSwitchSignonResponse(tmmConfig);


        /**
         * Switch To Scheme Purchase Request and Scheme To Switch Purchase Response
         */
        getSwithToSchemePurchaseRequest(tmmConfig);
        getSchemeToSwitchPurchaseResponse(tmmConfig);


        /**
         * Switch To Scheme Purchase Aav Request and Scheme To Switch Purchase Aav Response
         */
        getSwithToSchemePurchaseAavRequest(tmmConfig);
        getSchemeToSwitchPurchaseAavResponse(tmmConfig);

        /**
         * Switch To Scheme Aav Request and Scheme To Switch Aav Response
         */
        getSwithToSchemeAavRequest(tmmConfig);
        getSchemeToSwitchAavResponse(tmmConfig);

        /**
         * Switch To Scheme PreAuth Request and Scheme To Switch PreAuth Response
         */
        getSwithToSchemePreAuthRequest(tmmConfig);
        getSchemeToSwitchPreAuthResponse(tmmConfig);

        /**
         * Switch To Scheme SI Request and Scheme To Switch SI Response
         */
        getSwithToSchemeAmexSIRequest(tmmConfig);
        getSchemeToSwitchAmexSIResponse(tmmConfig);

        /**
         * Switch To Scheme RP Request and Scheme To Switch RP Response
         */
        getSwithToSchemeRPRequest(tmmConfig);
        getSchemeToSwitchRPResponse(tmmConfig);
        
        /**
         * Switch To Scheme MO Request and Scheme To Switch MO Response
         */
        getSwithToSchemeMOSaleRequest(tmmConfig);
        getSchemeToSwitchMOSaleResponse(tmmConfig);
        
        /**
         * Switch To Scheme TO Request and Scheme To Switch TO Response
         */
        getSwithToSchemeTOSaleRequest(tmmConfig);
        getSchemeToSwitchTOSaleResponse(tmmConfig);

        /**
         * Switch To Scheme MO Refund Request and Scheme To Switch MO Refund Response
         */
        getSwithToSchemeMORefundRequest(tmmConfig);
        getSchemeToSwitchMORefundResponse(tmmConfig);

        /**
         * Switch To Scheme TO Refund Request and Scheme To Switch TO Refund Response
         */
        getSwithToSchemeTORefundRequest(tmmConfig);
        getSchemeToSwitchTORefundResponse(tmmConfig);

        /**
         * Switch To Scheme MO Reversal Request and Scheme To Switch MO Reversal Response
         */
        getSwithToSchemeReversalMORequest(tmmConfig);
        getSchemeToSwitchMOReversalResponse(tmmConfig);
        
        /**
         * Switch To Scheme TO Request and Scheme To Switch TO Response
         */
        getSwithToSchemeReversalTORequest(tmmConfig);
        getSchemeToSwitchTOReversalResponse(tmmConfig);


        getSwithToSchemeAuthAdjustmentRequest(tmmConfig);
        getSchemeToSwitchAuthAdjustmentResponse(tmmConfig);
        
        /**
         * Switch To Scheme Refund Request and Scheme To Switch Refund Response
         */
        getSwithToSchemeOnlineRefundRequest(tmmConfig);
        getSchemeToSwitchOnlineRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Aav Request and Scheme To Switch Refund  Aav Response
         */
        getSwithToSchemeOnlineRefundAavRequest(tmmConfig);
        getSchemeToSwitchOnlineRefundAavResponse(tmmConfig);

        /**
         * Switch To Scheme Reversal Request and Scheme To Switch Reversal Response
         */
        getSwithToSchemeRevarsalAdviseRequest(tmmConfig);
        getSchemeToSwitchRevarsalAdviseResponse(tmmConfig);

        /**
         * Switch To Scheme Preauth Reversal Request and Scheme To Switch Preauth Reversal Response
         */
        getSwithToSchemePreauthRevarsalRequest(tmmConfig);
        getSchemeToSwitchPreauthRevarsalResponse(tmmConfig);

        /**
         * Switch To Scheme Void Reversal Request and Scheme To Switch Reversal Response
         */
        getSwithToSchemeRevarsalAdviseVoidRequest(tmmConfig);
        getSchemeToSwitchRevarsalAdviseVoidResponse(tmmConfig);

        /**
         * Switch To Scheme Preauth Void Reversal Request and Scheme To Switch Preauth Reversal void Response
         */
        getSwithToSchemePreauthRevarsalVoidRequest(tmmConfig);
        getSchemeToSwitchPreauthRevarsalVoidResponse(tmmConfig);
        /**
         * Switch To Scheme Preauth aav Request and Scheme To Switch Preauth aav Response
         */
        getSwithToSchemePreAuthAavRequest(tmmConfig);
        getSchemeToSwitchPreAuthAavResponse(tmmConfig);

        /**
         * Switch To Scheme SI Request and Scheme To Switch SI Response
         */
        getSwithToSchemeAmexSIAavRequest(tmmConfig);
        getSchemeToSwitchAmexSIAavResponse(tmmConfig);

        /**
         * Switch To Scheme RP Request and Scheme To Switch RP Response
         */
        getSwithToSchemeRPAavRequest(tmmConfig);
        getSchemeToSwitchRPAavResponse(tmmConfig);

        /**
         * Switch To Scheme MO aav Request and Scheme To Switch MO aav Response
         */
        getSwithToSchemeMOSaleAavRequest(tmmConfig);
        getSchemeToSwitchMOSaleAavResponse(tmmConfig);
        
        /**
         * Switch To Scheme TO Aav Request and Scheme To Switch TO Aav Response
         */
        getSwithToSchemeTOSaleAavRequest(tmmConfig);
        getSchemeToSwitchTOSaleAavResponse(tmmConfig);
        
        /**
         * Switch To Scheme Moto PreAuth Request and Scheme To Switch Moto PreAuth Response
         */
        getSwithToSchemeMotoPreAuthRequest(tmmConfig);
        getSchemeToSwitchMotoPreAuthResponse(tmmConfig);
        

        /**
         * Switch To Scheme Purchase Request and Scheme To Pos Purchase Response
         */
        getSwithToSchemePosPurchaseRequest(tmmConfig);
        getSchemeToSwitchPosPurchaseResponse(tmmConfig);

        /**
         * Switch To Scheme Refund Request and Scheme To Pos Refund Response
         */
        getSwithToSchemePosRefundRequest(tmmConfig);
        getSchemeToSwitchPosRefundResponse(tmmConfig);

        /**
         * Switch To Scheme Reversal Request and Scheme To Pos Reversal Response
         */
        getSwithToSchemePosRevarsalAdviseRequest(tmmConfig);
        getSchemeToSwitchPosRevarsalAdviseResponse(tmmConfig);
        
        /**
         * Switch To Scheme ZVAV Purchase Request and Scheme To Switch ZVAV Purchase Response
         */
        getSwithToSchemeZvavPurchaseRequest(tmmConfig);
        getSchemeToSwitchZvavPurchaseResponse(tmmConfig);
        
        /**
         * Switch To Scheme ZVAV Purchase Aav Request and Scheme To Switch ZVAV Purchase Aav Response
         */
        getSwithToSchemeZvavPurchaseAavRequest(tmmConfig);
        getSchemeToSwitchZvavPurchaseAavResponse(tmmConfig);
        
        /**
         * Switch To Scheme Zvav Request and Scheme To Pos Zvav Response
         */
        getSwithToSchemePosZvavRequest(tmmConfig);
        getSchemeToSwitchPosZvavResponse(tmmConfig);

        return tmmConfig;
    }


    private void getSwithToSchemeSignonRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1804", null, TmmConstants.AMEX_SIGNON_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchSignonResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(96, TmmConstants.MSG_SECUIRTY_CODE);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        tmmConfig.put(new TransactionTypeConfig("1814", "00", TmmConstants.AMEX_SIGNON_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemePurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_PURCHASE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        //fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        //fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        //fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        //fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        /*fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);*/
        fieldsMap.put(61, TmmConstants.CIAD);
        /*fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);*/
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_PURCHASE_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemePurchaseAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_PURCHASE_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPurchaseAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_PURCHASE_AAV_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "17", TmmConstants.PG_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        //fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        //fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        //fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        //fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        /*fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);*/
        tmmConfig.put(new TransactionTypeConfig("1110", "17", TmmConstants.PG_AAV_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemePreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        // fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_PREAUTH_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_PREAUTH_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeAmexSIRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_SI_AMEX_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchAmexSIResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_SI_AMEX_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeRPRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_RP_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchRPResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_RP_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeMOSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_MO_SALE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMOSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_MO_SALE_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeTOSaleRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_TO_SALE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchTOSaleResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        //fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        //fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        //fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        //fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        /*fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);*/
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_TO_SALE_RESPONSE), fieldsMap);
    }
    
    private void getSwithToSchemeOnlineOfflineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "20", TmmConstants.PG_ONLINE_OFFLINE_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchOnlineOfflineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "20", TmmConstants.PG_ONLINE_OFFLINE_REFUND_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeOnlineRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "20", TmmConstants.PG_ONLINE_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchOnlineRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "20", TmmConstants.PG_ONLINE_REFUND_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeOnlineRefundAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("1100", "20", TmmConstants.PG_REFUND_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchOnlineRefundAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);

        tmmConfig.put(new TransactionTypeConfig("1110", "20", TmmConstants.PG_REFUND_AAV_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeMORefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {

        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "20", TmmConstants.PG_MO_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMORefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "20", TmmConstants.PG_MO_REFUND_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeTORefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "20", TmmConstants.PG_TO_REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchTORefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "20", TmmConstants.PG_TO_REFUND_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeRevarsalAdviseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
  //      fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
//        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);

        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "00", TmmConstants.PG_REVERSAL_REQUEST), fieldsMap);
    }



    private void getSchemeToSwitchRevarsalAdviseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
       // fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);

        tmmConfig.put(new TransactionTypeConfig("1430", "00", TmmConstants.PG_REVERSAL_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemePreauthRevarsalRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
     //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
//        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "00", TmmConstants.PG_PREAUTH_REVERSAL_REQUEST), fieldsMap);
    }



    private void getSchemeToSwitchPreauthRevarsalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);

        tmmConfig.put(new TransactionTypeConfig("1430", "00", TmmConstants.PG_PREAUTH_REVERSAL_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemePreauthRevarsalVoidRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
       // fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);

        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "02", TmmConstants.PG_PREAUTH_REVERSAL_VOID_REQUEST), fieldsMap);
    }



    private void getSchemeToSwitchPreauthRevarsalVoidResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
   //     fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);

        tmmConfig.put(new TransactionTypeConfig("1430", "02", TmmConstants.PG_PREAUTH_REVERSAL_VOID_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeRevarsalAdviseVoidRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
     //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "02", TmmConstants.PG_REVERSAL_VOID_REQUEST), fieldsMap);
    }



    private void getSchemeToSwitchRevarsalAdviseVoidResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
       // fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        tmmConfig.put(new TransactionTypeConfig("1430", "02", TmmConstants.PG_REVERSAL_VOID_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeReversalMORequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
      //  fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
//        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "00", TmmConstants.PG_MO_REVERSAL_REQUEST), fieldsMap);
    }



    private void getSchemeToSwitchMOReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
      //  fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        tmmConfig.put(new TransactionTypeConfig("1430", "00", TmmConstants.PG_MO_REVERSAL_RESPONSE), fieldsMap);
    }



    private void getSwithToSchemeReversalTORequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
//        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "00", TmmConstants.PG_TO_REVERSAL_REQUEST), fieldsMap);
    }



    private void getSchemeToSwitchTOReversalResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
      //  fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        tmmConfig.put(new TransactionTypeConfig("1430", "00", TmmConstants.PG_TO_REVERSAL_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeAuthAdjustmentRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.TERMINAL_DATA);

        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1220", "22", TmmConstants.PG_AUTH_ADJUSTMENT_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchAuthAdjustmentResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(56, TmmConstants.TERMINAL_DATA);
        tmmConfig.put(new TransactionTypeConfig("1230", "22", TmmConstants.PG_AUTH_ADJUSTMENT_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemePreAuthAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        // fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_PREAUTH_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPreAuthAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_PREAUTH_AAV_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemeAmexSIAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_SI_AMEX_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchAmexSIAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_SI_AMEX_AAV_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeRPAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        fieldsMap.put(123, TmmConstants.RESERVED_123);
        
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_RP_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchRPAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_RP_AAV_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeMOSaleAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_MO_SALE_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMOSaleAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_MO_SALE_AAV_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeTOSaleAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_TO_SALE_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchTOSaleAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        //fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        //fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        //fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        //fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        /*fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);*/
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_TO_SALE_AAV_RESPONSE), fieldsMap);
    }
    
    private void getSwithToSchemeMotoPreAuthRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        // fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PG_MOTO_PREAUTH_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchMotoPreAuthResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PG_MOTO_PREAUTH_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemePosPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        //fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
      //  fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "00", TmmConstants.PURCHASE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPosPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        tmmConfig.put(new TransactionTypeConfig("1110", "00", TmmConstants.PURCHASE_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemePosRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //fieldsMap.put(52, TmmConstants.PIN);
        //fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(113, TmmConstants.RESERVED_113);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "20", TmmConstants.REFUND_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPosRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        tmmConfig.put(new TransactionTypeConfig("1110", "20", TmmConstants.REFUND_RESPONSE), fieldsMap);
    }


    private void getSwithToSchemePosRevarsalAdviseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

       // fieldsMap.put(52, TmmConstants.PIN);
//        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(56, TmmConstants.RESERVED_56);

        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1420", "00", TmmConstants.REVERSAL_REQUEST), fieldsMap);
    }


    private void getSchemeToSwitchPosRevarsalAdviseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        // fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);

        tmmConfig.put(new TransactionTypeConfig("1430", "00", TmmConstants.REVERSAL_RESPONSE), fieldsMap);
    }
    
    private void getSwithToSchemeZvavPurchaseRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "33", TmmConstants.PG_ZVAV_PURCHASE_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchZvavPurchaseResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "33", TmmConstants.PG_ZVAV_PURCHASE_RESPONSE), fieldsMap);
    }

    private void getSwithToSchemeZvavPurchaseAavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);

        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);

        fieldsMap.put(47, TmmConstants.NATIONAL_AD);

        fieldsMap.put(48, TmmConstants.PRIVATE_AD);

        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "33", TmmConstants.PG_ZVAV_PURCHASE_AAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchZvavPurchaseAavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);

        fieldsMap.put(15, TmmConstants.SETTLEMENT_DATE);
        fieldsMap.put(30, TmmConstants.TXN_PROCESSING_FEE);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        //   fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);

        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        tmmConfig.put(new TransactionTypeConfig("1110", "33", TmmConstants.PG_ZVAV_PURCHASE_AAV_RESPONSE), fieldsMap);
    }
    
    private void getSwithToSchemePosZvavRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(7, TmmConstants.TRANSMISSION_TIME);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(19, TmmConstants.AQUIRER_COUNTRY_CODE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(26, TmmConstants.POS_CAPTURE_CODE);
        fieldsMap.put(27, TmmConstants.AUTH_ID_RES_LENGTH);
        //fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        //fieldsMap.put(33, TmmConstants.FORWARDING_INST_ID_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(43, TmmConstants.CARD_ACCEPTOR_INFO);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);
        //fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
      //  fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
        fieldsMap.put(111, TmmConstants.RESERVED_111);
        // Conditional Fields -20
        // Optional Fields-127
        tmmConfig.put(new TransactionTypeConfig("1100", "33", TmmConstants.ZVAV_REQUEST), fieldsMap);
    }

    private void getSchemeToSwitchPosZvavResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(31, TmmConstants.SETTLEMENT_PROCESSING_FEE);
        fieldsMap.put(32, TmmConstants.AQUIRERID_CODE);
        fieldsMap.put(34, TmmConstants.PAN_EXTENDED);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(44, TmmConstants.ADDITIONAL_RES_DATA);
        fieldsMap.put(49, TmmConstants.TXN_CURRENCY_CODE);

        tmmConfig.put(new TransactionTypeConfig("1110", "33", TmmConstants.ZVAV_RESPONSE), fieldsMap);
    }
    
    @Override
    public MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId, TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        MessageContext msgContext = super.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
        if (msgContext.getRawMsg() instanceof ISOMsg) {
            ISOMsg rawMsg = (ISOMsg) msgContext.getRawMsg();
            try {
                byte[] msgBytes = rawMsg.pack();
                TxnLogger.logRawMsg(MsgFlow.OUTBOUND, msgBytes, sourceTmm);
                String hexMsg = "AuthorizationRequestParam=" + ISOUtil.byte2hex(msgBytes);
                msgContext.setRawMsg(hexMsg);
                TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
                msgContext.setApiHeaders(buildApiHeaders(hexMsg.length(), targetAdditionalData, targetAdditionalData.getApiInfo().getAmex().getMerchantId()));
            } catch (ISOException e) {
                logger.error(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(), sourceTmm.getTransactionId(), "Failed to construct message"), e.getMessage());
                logger.trace(LogUtils.buildLogMessage(sourceTmm.getEntityId(), epId, msgContext.getEpMsgType(), sourceTmm.getTransactionId(), "Failed to construct message"), e);
            }
        }
        return msgContext;
    }

    private Map<String, String> buildApiHeaders(int msgLength, TargetAdditionalData tgtAddlData, String mid) {
        Map<String, String> headers = new HashMap<>();
        headers.put("POST", tgtAddlData.getApiInfo().getAmex().getTxnUrl());
        headers.put("Accept-Language", "en-us");
        headers.put("Content-Type", "plain/text");
        headers.put("User-Agent", "Application");
        headers.put("Host", tgtAddlData.getApiInfo().getAmex().getRequestHost());
        headers.put("Content-Length", msgLength + "");
        headers.put("Cache-Control", "no-cache");
        headers.put("Connection", "Keep-Alive");
        headers.put("message", "ISO GCAG");
        headers.put("Origin", tgtAddlData.getApiInfo().getAmex().getOrigin());
        headers.put("country", tgtAddlData.getApiInfo().getAmex().getCountry());
        headers.put("region", tgtAddlData.getApiInfo().getAmex().getRegion());
        headers.put("MerchNbr", mid);
        headers.put("RtInd", tgtAddlData.getApiInfo().getAmex().getRouteIndicator());
        return headers;
    }

    private byte[] buildISOHeader(ISOMsg isoMsg) throws ISOException {
        byte[] isoMsgBytes = isoMsg.pack();
        String header = "9827078460";
        String headerHexBinary = DatatypeConverter.printHexBinary(header.getBytes());
        byte[] headerHexBinaryBytes = MtmUtil.toBytesAsIs(headerHexBinary);
        byte[] finalMsgArr = new byte[isoMsgBytes.length + headerHexBinaryBytes.length];
        System.arraycopy(headerHexBinaryBytes, 0, finalMsgArr, 0, headerHexBinaryBytes.length);
        System.arraycopy(isoMsgBytes, 0, finalMsgArr, headerHexBinaryBytes.length, isoMsgBytes.length);
        logger.trace(new String(headerHexBinaryBytes));
        return finalMsgArr;
    }

    public byte[] prefixLength(byte[] pack) {
        byte[] newPack = null;
        String length = Integer.toHexString(pack.length);
        StringBuilder hexLength = new StringBuilder();
        for (int i = length.length(); i < 4; i++) {
            hexLength.append("0");
        }
        hexLength = hexLength.append(length);
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(ISOUtil.hex2byte(hexLength.toString()));
            outputStream.write(pack);
            newPack = outputStream.toByteArray();
        } catch (Exception ex) {
            newPack = pack;
        }
        return newPack;

    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        PgAmexMessageConstruction amexmc = null;
        if (MessageConstructionHelper.isReversalRequest(msgType)) {
            switch (srcProcessor) {
                case PG_SWITCH:
                    amexmc = new PgVoidReversalAmexMessageConstruction();
                    break;
                default:
                    amexmc = new VoidReversalAmexMessageConstruction();
                    break;
            }
        } else {
            switch (srcProcessor) {
                case PG_SWITCH:
                    amexmc = new PgAmexMessageConstruction();
                    break;
                default:
                    amexmc = new AmexMessageConstruction();
                    break;
            }


        }
        return amexmc;

    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new PgAmexMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 4;
    }

    @Override
    public TransactionMessageModel parseResponse(String responseBody, TransactionMessageModel reqSrcTmm, String epId,
                                                 TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        responseBody = removeQuotesAndUnescape(responseBody);
        String[] split = responseBody.split(API_RESPONSE_SEPARATOR);
        int status = Integer.parseInt(split[0]);
        String response = split[1];

        TransactionMessageModel resSrcTmm = null;
        try {
        	switch (status) {
        	case 200:
        		resSrcTmm = MessageTransformer.toPojo(reqSrcTmm.getEntityId(), OffsetDateTime.now(), reqSrcTmm.getTarget(), ISOUtil.hex2byte(response), 
        				TlmMessageType.RESPONSE, reqSrcTmm.getTransactionName());
        		resSrcTmm.setTransactionId(reqSrcTmm.getTransactionId());
        		resSrcTmm.setTerminalStan(reqSrcTmm.getTerminalStan());

        		if (reqSrcTmm.getTransactionCategory() != null
        				&& TransactionCategory.DYNAMIC_KEY_EXCHANGE.name().equals(reqSrcTmm.getTransactionCategory().name())) {
        			dynaminKeyTranslationForAmex(resSrcTmm);
        		}
        		break;
        	}
        } catch (Exception e) {
            logger.error("", e);
        }
        return resSrcTmm;
    }

    public void dynaminKeyTranslationForAmex(TransactionMessageModel resSrcTmm) {
    	if (AmexMsgTypeHelper.isSignOnResponse(resSrcTmm.getMsgType())) {
    		String encryptedKey = resSrcTmm.getReserved111();
    		
    		
    		String amexKcv = encryptedKey.substring(36, 42).toUpperCase();
    		HsmVendor hsmVendor = SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(resSrcTmm.getEntityId());
    		IPinTranslationService pinTranslationService = SpringContextBridge.getPinTranslationService(hsmVendor, PinTranslationType.DYNAMIC);

    		String keyBlock = new String(DatatypeConverter.parseHexBinary(encryptedKey.substring(84, encryptedKey.length()).toUpperCase()));
    		logger.info("keyBlock: {}", keyBlock);
    		String translatedDynamicKey = pinTranslationService.keyTranslationAmex(resSrcTmm.getEntityId(), resSrcTmm.getSource(),
    				resSrcTmm.getSource(), keyBlock);
    		
    		if (translatedDynamicKey != null && translatedDynamicKey.length() > 32) {
    			/*
    			 * Exclude KCV ( Key Check Value ) i.e Last Six Digit.
    			 */
    			/*String[] data = translatedDynamicKey.split("P0");
        		int keyLength = Integer.parseInt(data[0].substring(4,data[0].length()));*/

        		String dynamicKey = translatedDynamicKey.substring(0, translatedDynamicKey.length() - 6);
        		String kcv = translatedDynamicKey.substring(translatedDynamicKey.length() - 6, translatedDynamicKey.length());
        		
    			SpringContextBridge.services().getMwRedisCacheUtil().putTargetDynamicKeyData(resSrcTmm.getEntityId() + "_" + hsmVendor + TmmConstants.DYNAMIC_KEY,
    					TargetType.Amex, dynamicKey+"##"+kcv);
    		}
    	}
    }
}
