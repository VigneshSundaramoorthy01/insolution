package com.isg.mw.mtm.parser.isofield;

import org.jpos.iso.ISOStringFieldPackager;
import org.jpos.iso.NullPadder;
import org.jpos.iso.NullPrefixer;

import com.isg.mw.mtm.parser.interpreter.HexToEbcdicInterpreter;

public class IFH_ACHAR extends ISOStringFieldPackager {

	public IFH_ACHAR() {
		super(NullPadder.INSTANCE, HexToEbcdicInterpreter.INSTANCE, NullPrefixer.INSTANCE);
	}

	/**
	 * @param len         - field len
	 * @param description symbolic descrption
	 */
	public IFH_ACHAR(int len, String description) {
		super(len, description, NullPadder.INSTANCE, HexToEbcdicInterpreter.INSTANCE, NullPrefixer.INSTANCE);
		checkLength(len, 9999);
	}

	@Override
	public void setLength(int len) {
		checkLength(len, 9999);
		super.setLength(len);
	}
}
