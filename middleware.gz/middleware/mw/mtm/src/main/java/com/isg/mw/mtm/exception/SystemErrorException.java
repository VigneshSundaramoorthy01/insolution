package com.isg.mw.mtm.exception;

public class SystemErrorException extends RuntimeException {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SystemErrorException(String errorMsg) {
		super(errorMsg);
	}

	public SystemErrorException(String errorMsg, Throwable e) {
		super(errorMsg, e);
	}

}