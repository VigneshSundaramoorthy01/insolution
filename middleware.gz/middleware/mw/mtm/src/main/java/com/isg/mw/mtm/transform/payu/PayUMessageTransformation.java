package com.isg.mw.mtm.transform.payu;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.construct.payu.PayUMsgType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.FormData;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.payu.PayUMessageConstruction;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.BankServerException;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.IMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.ApiUtil;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;

import static com.isg.mw.mtm.transform.MessageTransformer.identifyTargetTxnTypeConfig;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;

public class PayUMessageTransformation extends BaseMessageTransformation implements IMessageTransformation {
    private Logger logger = LogManager.getLogger();
    private static Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {

        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }

        /**
         * PayU Net Banking Request and Response
         */
        getNetBankingRequest(tmmConfig);

        /**
         * PayU Wallet Request and Response
         */
        getWalletRequest(tmmConfig);

        /**
         * PayU Refund Request and Response
         */
        getRefundRequest(tmmConfig);
        getRefundResponse(tmmConfig);

        /**
         * PayU Create Merchant Request and Response
         */
        getCreateMerchantRequest(tmmConfig);
        getCreateMerchantResponse(tmmConfig);

        getCheckTxnStatusRequest(tmmConfig);


        return tmmConfig;
    }


    private void getNetBankingRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("Pay", "1", TmmConstants.PAYU_NETBANKING_REQUEST), fieldsMap);
    }

    private void getWalletRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("Pay", "2", TmmConstants.PAYU_WALLET_REQUEST), fieldsMap);
    }

    private void getRefundRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("Refund", null, TmmConstants.PAYU_REFUND_REQUEST), fieldsMap);
    }

    private void getCheckTxnStatusRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("CheckTxnStatus", null, TmmConstants.PAYU_CHECK_TXN_STATUS_REQUEST), fieldsMap);
    }

    private void getRefundResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        tmmConfig.put(new TransactionTypeConfig("Refund", null, TmmConstants.PAYU_REFUND_RESPONSE), fieldsMap);
    }

    private void getCreateMerchantRequest(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig("CM", null, TmmConstants.PAYU_CREATE_MERCHANT_REQUEST), fieldsMap);
    }

    private void getCreateMerchantResponse(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();

        tmmConfig.put(new TransactionTypeConfig("CM", null, TmmConstants.PAYU_CREATE_MERCHANT_RESPONSE), fieldsMap);
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel reqSourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {

        MessageContext msgContext = new MessageContext(reqSourceTmm.getEntityId(), epId, txnTypeConfig.getEpMsgType());
        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
        MessageFormatConfigModel msgFormatModel = msgFormatMap.get(txnTypeConfig.getEpMsgType());
        TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
        //once "get" tokens are replaced, we have to set specific construction based tokens
        SwitchBaseMessageConstruction baseMsgConstruction = getMessageConstruction();
        baseMsgConstruction.setSourceTmm(reqSourceTmm);
        if (!StringUtils.isBlank(reqSourceTmm.getSmartRouteData().getEncryptionEnable()) && reqSourceTmm.getSmartRouteData().getEncryptionEnable().equalsIgnoreCase("Y")) {
            reqSourceTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getPayU().getEncReturnUrl());
        } else {
            reqSourceTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getPayU().getReturnUrl());
        }
        TransactionMessageModel reqTargetTmm = SerializationUtils.clone(reqSourceTmm);
        reqTargetTmm.setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(epId));
        reqTargetTmm.setMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetTmm(reqTargetTmm);

        baseMsgConstruction.setSourceMsgType(reqSourceTmm.getMsgType());
        baseMsgConstruction.setSourceMsgTypeId(reqSourceTmm.getProcessingCode());
        baseMsgConstruction.setTargetMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetMsgTypeId(txnTypeConfig.getProcessingCode());

        baseMsgConstruction.updateDrCrFlag();

        String msgFormat = msgFormatModel.getMsgFormat();
        TransactionMessageModel.PayUData reqTxnModel = IsgJsonUtils.getObjectFromJsonString(msgFormat, TransactionMessageModel.PayUData.class);
        ApiUtil.replaceTokens(reqTxnModel, reqSourceTmm, baseMsgConstruction);

        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqSourceTmm.getTarget());
        CacheTargetMerchantMaster targetMerchantMaster = srCacheService.getTargetMerchantMasterModel(targetId, reqSourceTmm.getCardAcceptorId(),reqSourceTmm.getCardAcceptorTerminalId());

        ((PayUMessageConstruction) baseMsgConstruction).setKey(targetMerchantMaster.getKey());
        reqTxnModel.setKey(targetMerchantMaster.getKey());
        reqTxnModel.setHash(((PayUMessageConstruction) baseMsgConstruction).setHash(targetMerchantMaster.getSalt()));
        String apiPath = txnTypeConfig.getApiPath() == null ? "" : txnTypeConfig.getApiPath();

        Map<String, String> headers = buildHeaders();
        msgContext.setApiHeaders(headers);
        ObjectMapper objectMapper = new ObjectMapper();

        Map<String, String> map = objectMapper.convertValue(reqTxnModel, Map.class);
        List<FormData> formDataList = new ArrayList<>();
        map.forEach((k, v) -> {
            if (v != null) {
                FormData formData = new FormData();
                formData.setKey(k);
                formData.setValue(v);
                formDataList.add(formData);
            }
        });

        msgContext.setRawMsg(formDataList);
        msgContext.setTransactionMessageModel(reqTargetTmm);
        msgContext.setMessageTransformationConfig(msgTransConfig);
        msgContext.setTxnApiPath(apiPath);
        reqTargetTmm.getSmartRouteData().setRedirectUrl(targetAdditionalData.getApiInfo().getPayU().getTxnUrl());
        reqTargetTmm.getSmartRouteData().setRedirectData(formDataList);
        if (reqTargetTmm.getMsgType().equals(PayUMsgType.Refund.msgType)) {
            reqTargetTmm.setResCode("00");
            reqTargetTmm.setDrcrFlag("C");
        } else {
            reqTargetTmm.setResCode("-1");
        }
        return msgContext;
    }

    private Map<String, String> buildHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept", MediaType.APPLICATION_FORM_URLENCODED_VALUE + "," + MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new PayUMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor
            srcProcessor) {
        return null;
    }

    public MultiValueMap<String, String> createMerchant(MerchantMasterModel merchantMasterModel) {
        // "https://uat-partner.payu.in/api/v3/merchants";
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("merchant[display_name]", merchantMasterModel.getMerchantName());
        map.add("merchant[email]", merchantMasterModel.getMerchantEmail());
        map.add("merchant[mobile]", merchantMasterModel.getMerchantMobNo());
        return map;
    }

    public MultiValueMap<String, String> getAccessToken(TargetConfigModel targetModel) {
        // https://uat-accounts.payu.in/oauth/token
        TargetApiInfo.PayU payUData = targetModel.getAdditionalData().getApiInfo().getPayU();
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id", payUData.getClientId());
        map.add("client_secret", payUData.getClientSecret());
        map.add("grant_type", "client_credentials");
        map.add("scope", "refer_merchant");
        return map;
    }

    public String refundTransaction(TransactionMessageModel reqSrcTmm) {
        String url = "https://test.payu.in/merchant/postservice?form=2";

        HttpHeaders headers = new HttpHeaders();

        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_HTML, MediaType.APPLICATION_FORM_URLENCODED));
        String body;
        try {
            TransactionMessageModel.PayUData payUData = new TransactionMessageModel.PayUData();
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            String salt = "aE0y3d4wfOWBQp1dvpkG4A1qSr7lTjP6";

            String requestDetails = payUData.getKey() + "|" + payUData.getCommand() + "|" + payUData.getVar1() + "|" + salt;

            requestDetails = requestDetails.trim();
            byte[] messageDigest = md.digest(requestDetails.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);

            // Add preceding 0s to make it 32 bit
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }

            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("key", payUData.getKey());
            map.add("command", payUData.getCommand());
            map.add("var1", payUData.getVar1());
            map.add("var2", payUData.getVar2());
            map.add("var3", payUData.getVar3());
            map.add("var4", payUData.getVar4());
            map.add("var5", payUData.getVar5());
            map.add("var6", payUData.getVar6());
            map.add("var7", payUData.getVar7());
            map.add("hash", "0" + hashtext);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
            logger.info("request: {}", request);
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.POST, request,
                    String.class);
            body = exchange.getBody();
            logger.info("Exchange Body:: {}", exchange.getBody());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        return body;
    }

    @Override
    public TransactionMessageModel parseResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TransactionMessageModel resSrcTmm = apiTxnModel.buildTmm();
        resSrcTmm.setEntityId(apiTxnModel.getEntityId());
        TransactionMessageModel resTgtTmm = SerializationUtils.clone(resSrcTmm);
        SwitchBaseMessageConstruction baseMsgConstruction = getMessageConstruction();
        baseMsgConstruction.setSourceTmm(resSrcTmm);
        resSrcTmm.setTarget(targetConfigModel.getName());
        SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(resSrcTmm.getTarget());
        CacheTargetMerchantMaster targetMerchantMaster = srCacheService.getTargetMerchantMasterModel(targetId, resSrcTmm.getCardAcceptorId(),resSrcTmm.getCardAcceptorTerminalId());

        String calculatedResHash = ((PayUMessageConstruction) baseMsgConstruction).calculateResponseHash(targetMerchantMaster.getSalt());
        String hash = apiTxnModel.getHash();
       // if (calculatedResHash.equalsIgnoreCase(hash)) {
            logger.trace("Payment response hash verified");
            if (apiTxnModel.getStatus().equalsIgnoreCase("success")) {
                resTgtTmm.setResCode("00");
            } else {
                resTgtTmm.setResCode("01");
                apiTxnModel.setError("01");
            }
        //} else {
           // resTgtTmm.setResCode("01");
      //  }
        resTgtTmm.setMsgType("Pay");
        resTgtTmm.setDrcrFlag("D");
        resTgtTmm.setTargetTxnId(apiTxnModel.getMihpayid());
        return resTgtTmm;
    }

    @Override
    public String verifyPaymentStatusByTransactionId(String originalHashedTxnId) {
        //This parameter must contain the name of the web service.
//        targetId - original Txn
//        entity
        String command = "verify_payment";
//      "https://test.payu.in/merchant/postservice?form=2";
        String url = null;
        String body;
        String status = "Failed";
        TransactionMessageModel originalTmm = null;
        try {
            try {
                originalTmm = SwitchBaseMessageConstruction.fetchOriginalTransaction(getTransactionMessageModel(originalHashedTxnId));
            } catch (Exception e) {
                logger.trace(e.getMessage());
                return status;
            }

            //fetch URL
            String txnTypeName = null;
            Set<String> txnNameList = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                    .get(originalTmm.getTargetType() + "." + PayUMsgType.CheckTxnStatus.msgType + "." + null);
            TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(txnTypeName, null, originalTmm.getTarget());
            String srcTxnName = originalTmm.getTransactionName();
            if (txnNameList.size() == 1) {
            	txnTypeName = txnNameList.stream().findFirst().orElse(null);
            } else if (txnNameList.size() > 1 && !StringUtils.isBlank(srcTxnName) ) {
            	txnTypeName = txnNameList.stream().filter(str -> str.equals(srcTxnName.replace("request", "response"))).findAny()
      		  .orElse(null);
            }

            Map<String, Map<String, Map<TransactionTypeConfig, MessageTransformationConfig>>> msgTransformationConfig = MessageTransformationContext.getMsgTransformationConfig();
            Map<String, Map<TransactionTypeConfig, MessageTransformationConfig>> stringMapMap = msgTransformationConfig.get(originalTmm.getEntityId()+"."+originalTmm.getTarget());
            Map<TransactionTypeConfig, MessageTransformationConfig> msgTransfonfigMap = stringMapMap.get(originalTmm.getTarget());
            MessageTransformationConfig messageTransformationConfig = msgTransfonfigMap.get(txnTypeConfig);
            url = messageTransformationConfig.getTargetAdditionalData().getApiInfo().getPayU().getCheckTxnStatusUrl();

            SmartRouteSpringCacheService srCacheService = SpringContextBridge.services().getSrCacheService();
            String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(originalTmm.getTarget());
            CacheTargetMerchantMaster targetMerchantMaster = srCacheService.getTargetMerchantMasterModel(targetId, originalTmm.getCardAcceptorId(),originalTmm.getCardAcceptorTerminalId());

            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_HTML, MediaType.APPLICATION_FORM_URLENCODED));
            TransactionMessageModel.PayUData payUData = originalTmm.getSmartRouteData().getPayUData();
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            String salt = null;

            if (targetMerchantMaster.getKey().equals(payUData.getKey())) {
                salt = targetMerchantMaster.getSalt();
            }
            String requestDetails = payUData.getKey() + "|" + command + "|" + originalTmm.getTransactionId() + "|" + salt;
            requestDetails = requestDetails.trim();
            byte[] messageDigest = md.digest(requestDetails.getBytes());
            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);

            // Add preceding 0s to make it 32 bit
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("key", payUData.getKey());
            map.add("command", command);
            map.add("var1", originalTmm.getTransactionId());
            map.add("hash", "0" + hashtext);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
            logger.info("request: {}", request);
            RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
            ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.POST, request,
                    String.class);
            body = exchange.getBody();
            if (exchange.getStatusCodeValue() == 200) {
                body = exchange.getStatusCodeValue() + API_RESPONSE_SEPARATOR + exchange.getBody();
            }
            getVerifyPaymentStatusResponse(body);
            logger.info("Exchange Body:: {}", exchange.getBody());
        } catch (Exception e) {
            logger.trace(e.getMessage());
            return status;
        }
        return "Success";
    }

    private TransactionMessageModel getTransactionMessageModel(String hashedTransactionId) {
        TransactionMessageModel model = new TransactionMessageModel();
        model.setOriginalHashedTxnId(hashedTransactionId);
        model.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        return model;
    }

    public void validateResponseErrorCode(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TargetApiInfo.PayU payU = targetConfigModel.getAdditionalData().getApiInfo().getPayU();
        if (payU != null && !StringUtils.isBlank(payU.getTechErrorCodes())) {
            String[] split = payU.getTechErrorCodes().split(",");
            Set<String> techErrorCodes = Arrays.stream(split).collect(Collectors.toSet());
            boolean value = techErrorCodes.contains(apiTxnModel.getError());
            if (value) {
                throw new BankServerException("Deliberately failed the transaction due to the bank server issue : ", targetConfigModel.getEntityId(), apiTxnModel.getMid(), apiTxnModel.getMerchantTxnRefNo());
            }
        }
    }

    private String getVerifyPaymentStatusResponse(String response) {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode jsonNode = null;
        String res = null;
        try {
            String[] split = response.split("##");
            String httpStatus = split[0];
            String httpResponse = split[1];
            if (httpStatus.equals("200")) {
                jsonNode = mapper.readTree(httpResponse);
                res = jsonNode.get("status").asText();
                if (res.equalsIgnoreCase("0")) {
                    return jsonNode.get("msg").toString();
                }
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return res;
    }


}
