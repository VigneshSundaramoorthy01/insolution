/*
 * jPOS Project [http://jpos.org]
 * Copyright (C) 2000-2020 jPOS Software SRL
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.isg.mw.mtm.parser.isofield;

import com.isg.mw.mtm.parser.prefixer.ISG_BinaryPrefixer;
import org.jpos.iso.ISOComponent;
import org.jpos.iso.ISOStringFieldPackager;
import org.jpos.iso.LiteralInterpreter;
import org.jpos.iso.NullPadder;

/**
 * ISOFieldPackager Binary LL Hex NUM
 * Almost the same as IFB_LLNUM but len is encoded as a binary
 * value. A len of 16 is encoded as 0x10 instead of 0x16
 *
 * @author apr@cs.com.uy
 * @version $Id$
 * @see ISOComponent
 */
public class ISG_IFB_LLHNUM extends ISOStringFieldPackager {
    public ISG_IFB_LLHNUM() {
        super(NullPadder.INSTANCE, LiteralInterpreter.INSTANCE, ISG_BinaryPrefixer.B);
    }

    /**
     * @param len         - field len
     * @param description symbolic descrption
     */
    public ISG_IFB_LLHNUM(int len, String description, boolean pad) {
        super(len, description, NullPadder.INSTANCE,
                LiteralInterpreter.INSTANCE, ISG_BinaryPrefixer.B);
        this.pad = pad;
        checkLength(len, 255);
    }

    public void setLength(int len) {
        checkLength(len, 255);
        super.setLength(len);
    }

    public void setPad(boolean pad) {
        this.pad = pad;
        setInterpreter(LiteralInterpreter.INSTANCE);
    }
}
