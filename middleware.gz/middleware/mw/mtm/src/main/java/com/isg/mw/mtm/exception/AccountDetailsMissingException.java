package com.isg.mw.mtm.exception;

public class AccountDetailsMissingException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public AccountDetailsMissingException(String errorMsg) {
        super(errorMsg);
    }

    public AccountDetailsMissingException(String errorMsg, Throwable e) {
        super(errorMsg, e);
    }

}
