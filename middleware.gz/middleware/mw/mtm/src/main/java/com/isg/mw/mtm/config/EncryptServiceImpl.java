package com.isg.mw.mtm.config;

import java.util.Arrays;

import com.isg.mw.cache.mgmt.init.InitProps;
import com.isg.mw.core.utils.StringUtils;
import com.isg.mw.security.algorithms.AES;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import com.isg.mw.core.service.EnvPropertyService;
import com.isg.mw.security.security.Encryptor;
import org.springframework.web.client.RestTemplate;

import javax.crypto.SecretKey;

//import static com.isg.mw.mtm.construct.SwitchBaseMessageConstruction.fetchSecretKey;

/**
 * Encrypt Service Implementation
 * 
 * @author akshay3978
 *
 */
@Service("encryptService")
public class EncryptServiceImpl implements InitializingBean, EncryptService {

	/**
	 * RSA ENCRYPTION CODE
	 */

	/*public static final String ENCRYTION_KEY_PROVIDER_PATH_KEY = "encryption.key.provider.path";

	@Autowired
	private EnvPropertyService envPropertyService;

	private Encryptor<RSA, PublicKey> encryptor;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		init();
	}

	private void init() {

		String rsaPublicKeyProviderPath = envPropertyService.getPropertyValue(ENCRYTION_KEY_PROVIDER_PATH_KEY);
		encryptor = new Encryptor<RSA, PublicKey>(rsaPublicKeyProviderPath);
	}

	@Override
	public String encrypt(String data) {

		return encryptor.encrypt(data);
	}*/

	/**
	 * AES ENCRYPTION CODE
	 */
	protected static Logger logger = LogManager.getLogger();

	public static final String ENCRYTION_KEY_PROVIDER_PATH_KEY = "encryption.key.provider.path";

	public static final String SECRET_KEY_API_URL = "fetch.secret.key.by.config.type";

	@Autowired
	private EnvPropertyService envPropertyService;

	@Autowired
	private InitProps initProps;

	private Encryptor<AES, SecretKey> encryptor;

	@Override
	public void afterPropertiesSet() throws Exception {
		init();
	}

	/*private void init() {
		String aesPublicKeyProviderPath = envPropertyService.getPropertyValue(ENCRYTION_KEY_PROVIDER_PATH_KEY);
		encryptor = new Encryptor<AES, SecretKey>(aesPublicKeyProviderPath);
		
	}*/

	private void init(){
		String aesSecretKeyProviderPath = envPropertyService.getPropertyValue(ENCRYTION_KEY_PROVIDER_PATH_KEY);
		encryptor = new Encryptor<AES, SecretKey>(aesSecretKeyProviderPath,getSecretKey());
	}

	@Override
	public String encrypt(String data) {
		return encryptor.encrypt(data);
	}


	public String getSecretKey() {
		String url = envPropertyService.getPropertyValue(SECRET_KEY_API_URL) + "?configType=SECRET&status=Active";

		logger.info("Calling Tlm Api To Get secret key By config type : {} " , url);
		String secretKey = null;
		try {
			String JWT_KEY = "";
			String USER_NAME_HEADER = "";
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
//			headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//			headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
//			logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers),
					String.class);
			secretKey = exchange.getBody();
			logger.info("Secret Key Fetched Successfully.");
		} catch (RuntimeException e) {
			logger.error(" Failed to fetch secret key :  " + e);
		}
		if(!StringUtils.isBlank(secretKey)) {
			return secretKey;
		}else{
			logger.info("Secret Key is null");
			return secretKey;
		}
	}
}
