package com.isg.mw.mtm.transform;

import java.util.*;

import com.isg.mw.core.model.construct.icici.IciciMsgType;
import lombok.Getter;

public class TmmConstants {

    public static final String AUTHORIZATION_REQUEST_MTI = "0100";
    public static final String AUTHORIZATION_RESPONSE_MTI = "0110";
    public static final String REQ_NW_MGMT_MSG_TYPE = "0800";
    public static final String RES_NW_MGMT_MSG_TYPE = "0810";
    public static final String SIGN_ON_REQUEST = "0800";
    public static final String BATCH_SETTLEMENT_REQUEST = "0500";
    public static final String REVERSAL_REQUEST_MTI = "0400";
    public static final String RUPAY_REVERSAL_REQ_MTI = "0420";
    public static final String REQ_NW_MGMT_MSG_TYPE_AMEX = "1804";
    public static final String RES_NW_MGMT_MSG_TYPE_AMEX = "1814";
    public static final String REVERSAL_REQUEST_MTI_AMEX = "1420";
    public static final String DCC_RATE_LOOKUP_MSG_TYPE = "0600";
    
    public static final String DCC_INDICATOR_ACTIVE = "1";
    public static final String DCC_INDICATOR_INACTIVE = "0";
    
    

    public static final String REQ_NW_MGMT_MSG_TYPE_EFTPOS = "0820";
    public static final String RES_NW_MGMT_MSG_TYPE_EFTPOS = "0830";


    public static final String REQ_RECONCILE_MSG_TYPE = "0520";
    public static final String RES_RECONCILE_MSG_TYPE = "0530";
    public static final String VISA_SIGNON_NW_INFO_CODE = "071";
    public static final String VISA_SIGNOFF_NW_INFO_CODE = "072";
    public static final String VISA_ECHO_NW_INFO_CODE = "301";

    public static final String MASTERCARD_SIGNON_NW_INFO_CODE = "061";
    public static final String MASTERCARD_SIGNOFF_NW_INFO_CODE = "062";
    public static final String MASTERCARD_ECHO_NW_INFO_CODE = "270";
    public static final String MASTERCARD_SCHEME_INIT_KEY_EXCHANGE_NW_INFO_CODE = "161";
    public static final String MASTERCARD_SWITCH_INIT_KEY_EXCHANGE_NW_INFO_CODE = "162";
    public static final String MASTERCARD_HOST_ACTIVATION_NW_INFO_CODE = "081";
    public static final String MASTERCARD_HOST_DEACTIVATION_NW_INFO_CODE = "082";

    public static final String RUPAY_SIGNON_NW_INFO_CODE = "001";
    public static final String RUPAY_SIGNOFF_NW_INFO_CODE = "002";
    public static final String RUPAY_ECHO_NW_INFO_CODE = "301";
    public static final String RUPAY_CUT_OVER_NW_MGMT_CODE = "201";
    public static final String RUPAY_SWITCH_INIT__KEY_EXCHANGE_NW_INFO_CODE = "164";
    public static final String RUPAY_SCHEME_INIT_KEY_EXCHANGE_NW_MGMT_CODE = "184";
    
    public static final String RUPAY_QSPARC_CARD_TXN_IDENTIFIER_DE48_TAG_079 = "079";
    public static final String MPOS_TXN = "001";
    public static final String QUEST_TXN = "058";
    public static final String POS_API_TXN = "005";
    public static final String UNATTENDED_TXN = "003";

    public static final String AMEX_SIGNON_NW_INFO_CODE = "801";
    public static final String AMEX_SIGNOFF_NW_INFO_CODE = "802";
    public static final String AMEX_ECHO_MESSAGE_NW_INFO_CODE = "831";
    public static final String AMEX_KEY_EXCHANGE_NW_INFO_CODE = "811";

    // EFTPOS Constan
    public static final String EFTPOS_SIGNON_NW_INFO_CODE = "001";
    public static final String EFTPOS_KEYEXCHANE_NW_INFO_CODE = "101";
    public static final String EFTPOS_HEARTBEAT_NW_INFO_CODE = "301";
    public static final String EFTPOS_SIGNOFF_NW_INFO_CODE = "002";

    private TmmConstants() {
    }

    public static final String PURCHASE_REQUEST = "purchase.request";
    public static final String PURCHASE_RESPONSE = "purchase.response";
    public static final String CASHWITHDRAWAL_REQUEST = "cashwithdrawal.request";
    public static final String CASHWITHDRAWAL_RESPONSE = "cashwithdrawal.response";
    public static final String CASHATPOS_REQUEST = "cashatpos.request";
    public static final String CASHATPOS_RESPONSE = "cashatpos.response";
    public static final String PURCHASE_CASHATPOS_REQUEST = "purchase.cashatpos.request";
    public static final String PURCHASE_CASHATPOS_RESPONSE = "purchase.cashatpos.response";
    public static final String MOTO_REQUEST = "moto.request";
    public static final String MOTO_RESPONSE = "moto.response";
    public static final String PREAUTH_REQUEST = "preauth.request";
    public static final String PREAUTH_RESPONSE = "preauth.response";
    public static final String PREAUTH_COMPLETION_REQUEST = "preauth.completion.request";
    public static final String PREAUTH_COMPLETION_RESPONSE = "preauth.completion.response";
    public static final String BALANCE_INQUIRY_REQUEST = "vm.balance.inquiry.request";
    public static final String BALANCE_INQUIRY_RESPONSE = "vm.balance.inquiry.response";
    public static final String RUPAY_BALANCE_INQUIRY_REQUEST = "rupay.balance.inquiry.request";
    public static final String RUPAY_BALANCE_INQUIRY_RESPONSE = "rupay.balance.inquiry.response";
    public static final String REFUND_REQUEST = "refund.request";
    public static final String REFUND_RESPONSE = "refund.response";
    public static final String TIP_ADJUSTMENT_REQUEST = "tip.adjustment.request";
    public static final String TIP_ADJUSTMENT_RESPONSE = "tip.adjustment.response";
    public static final String OFFLINE_REQUEST = "offline.request";
    public static final String OFFLINE_RESPONSE = "offline.response";
    public static final String VOID_REFUND_REQUEST = "void.refund.request";
    public static final String VOID_REFUND_RESPONSE = "void.refund.response";
    public static final String VOID_OTHERS_REQUEST = "void.others.request";
    public static final String VOID_OTHERS_RESPONSE = "void.others.response";
    public static final String REVERSAL_REQUEST = "reversal.request";
    public static final String REVERSAL_RESPONSE = "reversal.response";
    public static final String POS_SIGNON_REQUEST = "pos.signon.request";
    public static final String POS_SIGNON_RESPONSE = "pos.signon.response";
    public static final String VISA_SIGNON_REQUEST = "visa.signon.request";
    public static final String VISA_SIGNON_RESPONSE = "visa.signon.response";
    public static final String MASTERCARD_SIGNON_REQUEST = "master.signon.request";
    public static final String MASTERCARD_SIGNON_RESPONSE = "master.signon.response";
    public static final String MASTERCARD_820_REQUEST = "master.820.request";
    public static final String RUPAY_SIGNON_REQUEST = "rupay.signon.request";
    public static final String RUPAY_SIGNON_RESPONSE = "rupay.signon.response";
    public static final String AMEX_SIGNON_REQUEST = "amex.signon.request";
    public static final String AMEX_SIGNON_RESPONSE = "amex.signon.response";
    public static final String VERIFY_VPA_REQUEST = "verify.vpa.request";
    public static final String VERIFY_VPA_RESPONSE = "verify.vpa.response";
    public static final String DCC_RATE_LOOKUP_REQUEST = "dcc.rate.lookup.request";
    public static final String DCC_RATE_LOOKUP_RESPONSE = "dcc.rate.lookup.response";
    public static final String ZVAV_REQUEST = "zvav.request";
    public static final String ZVAV_RESPONSE = "zvav.response";
    public static final String POS_TERMINAL_INIT_REQUEST = "pos.terminal.init.request";
    public static final String POS_TERMINAL_INIT_RESPONSE = "pos.terminal.init.response";



    public static final String PAYU_NETBANKING_REQUEST = "payu.netbanking.request";
    public static final String PAYU_NETBANKING_RESPONSE = "payu.netbanking.response";
    public static final String PAYU_WALLET_REQUEST = "payu.wallet.request";
    public static final String PAYU_WALLET_RESPONSE = "payu.wallet.response";
    public static final String PAYU_REFUND_REQUEST = "payu.refund.request";
    public static final String PAYU_REFUND_RESPONSE = "payu.refund.response";
    public static final String PAYU_CREATE_MERCHANT_REQUEST = "payu.create_merchant.request";
    public static final String PAYU_CREATE_MERCHANT_RESPONSE = "payu.create_merchant.response";
    public static final String PAYU_CHECK_TXN_STATUS_REQUEST = "payu.check.txn.status.request";
    
    
    public static final String LYRA_SUBMIT_CARD_REQUEST = "lyra.submit.card.request";
    public static final String LYRA_SUBMIT_CARD_RESPONSE = "lyra.submit.card.response";
    public static final String LYRA_REFUND_CARD_REQUEST = "lyra.refund.card.request";
    public static final String LYRA_REFUND_CARD_RESPONSE = "lyra.refund.card.response";
    public static final String LYRA_REVERSAL_CARD_REQUEST = "lyra.reversal.card.request";
    public static final String LYRA_REVERSAL_CARD_RESPONSE = "lyra.reversal.card.response";

    public static final String BATCH_UPLOAD_REQUEST = "batch.upload.request";
    public static final String BATCH_UPLOAD_RESPONSE = "batch.upload.response";
    public static final String DIRECT_SETTLEMENT_REQUEST = "direct.settlement.request";
    public static final String DIRECT_SETTLEMENT_RESPONSE = "direct.settlement.response";
    public static final String BATCH_UPLOAD_SETTLEMENT_REQUEST = "batch.upload.settlement.request";
    public static final String BATCH_UPLOAD_SETTLEMENT_RESPONSE = "batch.upload.settlement.response";

    public static final String ADD_MONEY_REQUEST = "addmoney.request";
    public static final String ADD_MONEY_RESPONSE = "addmoney.response";
    public static final String BALANCE_UPDATE_REQUEST = "balanceupdate.request";
    public static final String BALANCE_UPDATE_RESPONSE = "balanceupdate.response";
    public static final String SERVICE_CREATION_REQUEST = "servicecreation.request";
    public static final String SERVICE_CREATION_RESPONSE = "servicecreation.response";

    /*bqr*/
    public static final String CUSTOMER_NAME = "setCustomerName";
    public static final String CUSTOMER_PAN = "setCustomerPan";

    public static final String BQR_PURCHASE_REQUEST = "bqr.purchase.request";
    public static final String BQR_PURCHASE_RESPONSE = "bqr.purchase.response";

    public static final String BQR_REVERSAL_REQUEST = "bqr.reversal.request";
    public static final String BQR_REVERSAL_RESPONSE = "bqr.reversal.response";

    public static final String BQR_REFUND_REQUEST = "bqr.refund.request";
    public static final String BQR_REFUND_RESPONSE = "bqr.refund.response";

    public static final String BQR_SIGNON_REQUEST = "bqr.signon.request";
    public static final String BQR_SIGNON_RESPONSE = "bqr.signon.response";
    
    public static final String BQR_STIP_REQUEST = "bqr.stip.request";
    public static final String BQR_STIP_RESPONSE = "bqr.stip.response";
    
    public static final String BQR_NOTIFY_REQUEST = "bqr.notify.request";

    public static final String SWITCH_TRANSACTION_ID = "setTransactionId";

    public static final String BITMAP = "setBitMap";
    public static final String PAN = "setPan";
    public static final String PROCESSING_CODE = "setProcessingCode";
    public static final String TXN_AMT = "setTxnAmt";
    public static final String SETTLEMENT_AMT = "setSettlementAmt";
    public static final String CARD_HOLDER_BILLING_AMT = "setCardHolderBillingAmt";
    public static final String TRANSMISSION_TIME = "setTransmissionTime";
    public static final String CARD_HOLDER_BILLING_FEE = "setCardHolderBillingFee";
    public static final String SETTLEMENT_CONVERSION_RATE = "setSettlementConversionRate";
    public static final String CARD_HOLDER_BILLING_CONVERSION_RATE = "setCardHolderBillingConversionRate";
    public static final String STAN = "setStan";
    public static final String LOCAL_TXN_TIME = "setLocalTxnTime";
    public static final String LOCAL_TXN_DATE = "setLocalTxnDate";
    public static final String EXPIRATION_DATE = "setExpirationDate";
    public static final String SETTLEMENT_DATE = "setSettlementDate";
    public static final String CONVERSION_DATE = "setConversionDate";
    public static final String CAPTURE_DATE = "setCaptureDate";
    public static final String MERCHANT_TYPE = "setMerchantType";
    public static final String AQUIRER_COUNTRY_CODE = "setAquirerCountryCode";
    public static final String PAN_EXTENDED_COUNTRY_CODE = "setPanExtendedCountryCode";
    public static final String PAN_FORWARDING_COUNTRY_CODE = "setPanForwardingCountryCode";
    public static final String POS_ENTRY_MODE = "setPosEntryMode";
    public static final String CARD_SEQNO = "setCardSeqNo";
    public static final String NIIID = "setNiiId";
    public static final String POS_CONDITION_CODE = "setPosConditionCode";
    public static final String POS_CAPTURE_CODE = "setPosCaptureCode";
    public static final String AUTH_ID_RES_LENGTH = "setAuthIdResLength";
    public static final String TXN_FEE = "setTxnFee";
    public static final String SETTLEMENT_FEE = "setSettlementFee";
    public static final String TXN_PROCESSING_FEE = "setTxnProcessingFee";
    public static final String SETTLEMENT_PROCESSING_FEE = "setSettlementProcessingFee";
    public static final String AQUIRERID_CODE = "setAquirerIdCode";
    public static final String FORWARDING_INST_ID_CODE = "setForwardingInstIdCode";
    public static final String PAN_EXTENDED = "setPanExtended";
    public static final String TRACK2_DATA = "setTrack2Data";
    public static final String TRACK3_DATA = "setTrack3Data";
    public static final String RETRIEVAL_REF_NO = "setRetrievalRefNo";
    public static final String AUTH_ID_RES = "setAuthIdRes";
    public static final String RES_CODE = "setResCode";
    public static final String SERVICE_RESTRICTION_CODE = "setServiceRestrictionCode";
    public static final String CARD_ACCEPTOR_TERMINAL_ID = "setCardAcceptorTerminalId";
    public static final String CARD_ACCEPTOR_ID = "setCardAcceptorId";
    public static final String CARD_ACCEPTOR_INFO = "setCardAcceptorInfo";
    public static final String ADDITIONAL_RES_DATA = "setAdditionalResData";
    public static final String TRACK1_DATA = "setTrack1Data";
    public static final String ISO_AD = "setIsoAd";
    public static final String NATIONAL_AD = "setNationalAd";
    public static final String PRIVATE_AD = "setPrivateAd";
    public static final String TXN_CURRENCY_CODE = "setTxnCurrencyCode";
    public static final String SETTLEMENT_CURRENY_CODE = "setSettlementCurrenyCode";
    public static final String CARD_HOLDER_BILLING_CURRENCY_CODE = "setCardHolderBillingCurrencyCode";
    public static final String PIN = "setPin";
    public static final String SECURITY_CONTROL_INFO = "setSecurityControlInfo";
    public static final String ADDITIONAL_AMOUNTS = "setAdditionalAmounts";
    public static final String ICC_DATA = "setIccData";
    public static final String RESERVED_56 = "setReserved56";
    public static final String RESERVED_57 = "setReserved57";
    public static final String RESERVED_58 = "setReserved58";
    public static final String RESERVED_59 = "setReserved59";
    public static final String TERMINAL_DATA = "setTerminalData";
    public static final String CIAD = "setCiad";
    public static final String POSTAL_CODE = "setPostalCode";
    public static final String ATM_PIN_OFFSET_DATA = "setAtmPinOffsetData";
    public static final String MSG_AUTH_CODE = "setMsgAuthCode";
    public static final String EXTENDED_BITMAP_INDICATOR = "setExtendedBitmapIndicator";
    public static final String SETTLEMENT_CODE = "setSettlementCode";
    public static final String EXTENDED_PAYMENT_CODE = "setExtendedPaymentCode";
    public static final String RECEIVER_COUNTRY_CODE = "setReceiverCountryCode";
    public static final String SETTLEMENT_COUNTRY_CODE = "setSettlementCountryCode";
    public static final String NETWORK_MGMT_INFO_CODE = "setNetworkMgmtInfoCode";
    public static final String MSG_NO = "setMsgNo";
    public static final String LAST_MSG_NO = "setLastMsgNo";
    public static final String ACTION_DATE = "setActionDate";
    public static final String RECURRING_PAYMENT_INDICATOR= "setRecurringPaymentIndicator";
    public static final String MERCHANT_PAYMENT_GATEWAY_ID= "setMerchantPaymentGatewayId";

    public static final String NO_OF_CREDITS = "setNoOfCredits";
    public static final String CREDITS_REVERSAL_NO = "setCreditsReversalNo";
    public static final String NO_OF_DEBITS = "setNoOfDebits";
    public static final String DEBITS_REVERSAL_NO = "setDebitsReversalNo";
    public static final String TRANSFER_NO = "setTransferNo";
    public static final String TRANSFER_REVERSAL_NO = "setTransferReversalNo";
    public static final String NO_OF_INQUIRIES = "setNoOfInquiries";
    public static final String NO_OF_AUTHS = "setNoOfAuths";
    public static final String CREDITS_PROCESSING_FEE = "setCreditsProcessingFee";
    public static final String CREDITS_TXN_FEE = "setCreditsTxnFee";
    public static final String DEBITS_PROCESSING_FEE = "setDebitsProcessingFee";
    public static final String DEBITS_TXN_FEE = "setDebitsTxnFee";
    public static final String TOTAL_CREDITS = "setTotalCredits";
    public static final String CREDITS_REVERSAL = "setCreditsReversal";
    public static final String TOTAL_DEBITS = "setTotalDebits";
    public static final String DEBITS_REVERSAL = "setDebitsReversal";
    public static final String ORIGINAL_DATA_ELEMENTS = "setOriginalDataElements";
    public static final String FILE_UPDATE_CODE = "setFileUpdateCode";
    public static final String FILE_SECURITY_CODE = "setFileSecurityCode";
    public static final String RES_INDICATOR = "setResIndicator";
    public static final String SERVICE_INDICATOR = "setServiceIndicator";
    public static final String REPLACEMENT_AMTS = "setReplacementAmts";
    // TODO: security spelling to be corrected first at TransactionMessageModel
    // level and then in MessageConstruction interface
    public static final String MSG_SECUIRTY_CODE = "setMsgSecurityCode";
    public static final String NET_SETTLEMENT = "setNetSettlement";
    public static final String PAYEE = "setPayee";
    public static final String SETTLEMENT_ID_CODE = "setSettlementIdCode";
    public static final String RECEIVER_ID_CODE = "setReceiverIdCode";
    public static final String FILE_NAME = "setFileName";
    public static final String ACCID_1 = "setAccId1";
    public static final String ACCID_2 = "setAccId2";
    public static final String TXN_DESC = "setTxnDesc";
    public static final String RESERVED_105 = "setReserved105";
    public static final String RESERVED_106 = "setReserved106";
    public static final String RESERVED_107 = "setReserved107";
    public static final String RESERVED_108 = "setReserved108";
    public static final String RESERVED_109 = "setReserved109";
    public static final String RESERVED_110 = "setReserved110";
    public static final String RESERVED_111 = "setReserved111";
    public static final String RESERVED_112 = "setReserved112";
    public static final String RESERVED_113 = "setReserved113";
    public static final String RESERVED_114 = "setReserved114";
    public static final String RESERVED_115 = "setReserved115";
    public static final String RESERVED_116 = "setReserved116";
    public static final String RESERVED_117 = "setReserved117";
    public static final String RESERVED_118 = "setReserved118";
    public static final String RESERVED_119 = "setReserved119";
    public static final String RESERVED_120 = "setReserved120";
    public static final String RESERVED_121 = "setReserved121";
    public static final String RESERVED_122 = "setReserved122";
    public static final String RESERVED_123 = "setReserved123";
    public static final String RESERVED_124 = "setReserved124";
    public static final String RESERVED_125 = "setReserved125";
    public static final String RESERVED_126 = "setReserved126";
    public static final String RESERVED_127 = "setReserved127";
    public static final String RESERVED_128 = "setReserved128";

    /*
     * PG - FIELD
     */
    public static final String PG_LENGTH = "setPgLength";
    public static final String CVV2 = "setCvv2";
    public static final String MSG_TYPE = "setMsgType";
    public static final String AVV = "setAvv";
    public static final String CVV_RESULT = "setCvvResult";
    public static final String PG_TXN_REF_NO = "setPgTxnRefNo";
    public static final String ECOMMERCE_INDICATOR = "setEcommerceIndicator";
    public static final String ORIGINAL_TXN_PGID = "setOriginalTxnPgid";
    public static final String FRM_IP_ADDRESS = "setFrmIpAddress";
    public static final String PG_ID = "setPgId";
    public static final String DS_VERSION = "setDsVersion";
    public static final String BANK_NAME = "setBankName";
    public static final String CANCELATION_ID = "setCancelationId";
    public static final String MAC = "setMac";
    public static final String TAVV = "setTavv";
    public static final String TOKEN_REQUESTOR_ID = "setTokenRequestorId";
    public static final String FIELD_41 = "setField41";
    public static final String DS_TRANSACTION_ID = "setDsTransactionId";
    public static final String DS_MSG_CATEGORY = "setDsMsgCategory";
    public static final String DD_ADD_MATCH_INDICATOR = "setDsAddMatchIndicator";
    public static final String DD_SECURE_INDICATOR = "setDsSecureIndicator";
    public static final String COF_TXN_ORIGIN = "setCofTxnOrigin";
    public static final String MASTERCARD_POS_DATA = "setMastercardPosData";
    public static final String REVERSAL_MSG_REASON_CODE = "setReversalMessageReasonCode";
    public static final String MULTI_PURPOSE_MERCHANT_INDICATOR= "setMultiPurposeMerIndicator";
    /*
     * PG SWITCH FIELDS FOR AMEX
     */
    public static final String CID = "setCid";
    public static final String AAV_LENGTH_LAYOUT = "setAavLengthLayout";
    public static final String AAV_CARDMEMBER_BILLING_POSTAL_CODE = "setAavCardMemberBillingPostalCode";
    public static final String AAV_CARDMEMBER_BILLING_ADDRESS = "setAavCardMemberBillingAddress";
    public static final String AAV_CARDMEMBER_BILLING_FIRST_NAME = "setAavCardMemberBillingFirstName";
    public static final String AAV_CARDMEMBER_BILLING_LAST_NAME = "setAavCardMemberBillingLastName";
    public static final String AAV_CARDMEMBER_BILLING_PHONE_NUMBER = "setAavCardMemberBillingPhoneNumber";
    public static final String AAV_SHIP_TO_POSTAL_CODE = "setAavShipToPostalCode";
    public static final String AAV_SHIP_TO_ADDRESS = "setAavShipToAddress";
    public static final String AAV_SHIP_TO_FIRST_NAME = "setAavShipToFirstName";
    public static final String AAV_SHIP_TO_LAST_NAME = "setAavShipToLastName";
    public static final String AAV_SHIP_TO_PHONE_NUMBER = "setAavShipToPhoneNumber";
    public static final String AAV_SHIP_TO_COUNTRY_CODE= "setAavShipToCountryCode";
    public static final String AAV_RESPONSE_VERIFICATION_CODE= "setAavResponseVerificationCode";
    public static final String CUSTOMER_EMAIL= "setCustomerEmail";
    public static final String CUSTOMER_HOSTNAME= "setCustomerHostname";
    public static final String HTTP_BROWSER_TYPE= "setHttpBrowserType";
    public static final String SHIP_TO_COUNTRY= "setShipToCountry";
    public static final String SHIPPING_METHOD= "setShippingMethod";
    public static final String MERCHANT_PRODUCT_SKU= "setMerchantProductSku";
    public static final String CUSTOMER_IP= "setCustomerIp";
    public static final String CUSTOMER_ANI= "setCustomerAni";
    public static final String CUSTOMER_II_DIGIT= "setCustomerIIDigits";
    public static final String TRANSACTION_IDENTIFIER= "setTransactionIdentifier";
    public static final String RESPONSE_VERIFICATION_CODE_FOR_TELEPHONE_EMAIL= "setResponseVerificationCodeForTelephoneEmail";
    public static final String DEPARTURE_DATE= "setDepartureDate";
    public static final String AIRLINE_PASSANGER_NAME= "setAirlinePassangerName";
    public static final String ORIGIN= "setOrigin";
    public static final String DESTINATION= "setDestination";
    public static final String NO_OF_CITIES= "setNoOfCities";
    public static final String ROUTING_CITIES= "setRoutingCities";
    public static final String NO_OF_AIRLINE_CARRIERS= "setNoOfAirlineCarriers";
    public static final String AIRLINE_CARRIRS= "setAirlineCarriers";
    public static final String FARE_BASIS= "setFareBasis";
    public static final String NO_OF_PASSANGERS= "setNoOfPassangers";
    public static final String AUTH_OUTAGE_INDICATOR= "setAuthenticationOutageIndicator";

    /*
     * PG SWITCH REQ AND RES STRING
     */

    public static final String PG_PURCHASE_REQUEST = "pg.purchase.request";
    public static final String PG_PURCHASE_RESPONSE = "pg.purchase.response";
    public static final String PG_PURCHASE_AAV_REQUEST = "pg.purchase.aav.request";
    public static final String PG_PURCHASE_AAV_RESPONSE = "pg.purchase.aav.response";
    public static final String PG_AAV_REQUEST = "pg.aav.request";
    public static final String PG_AAV_RESPONSE = "pg.aav.response";
    public static final String PG_ONLINE_REFUND_REQUEST = "pg.online.refund.request";
    public static final String PG_ONLINE_REFUND_RESPONSE = "pg.online.refund.response";
    public static final String PG_OFFLINE_REFUND_REQUEST = "pg.offline.refund.request";
    public static final String PG_OFFLINE_REFUND_RESPONSE = "pg.offline.refund.response";
    public static final String PG_REFUND_AAV_REQUEST = "pg.refund.aav.request";
    public static final String PG_REFUND_AAV_RESPONSE = "pg.refund.aav.response";
    public static final String PG_PREAUTH_REQUEST = "pg.preauth.request";
    public static final String PG_PREAUTH_RESPONSE = "pg.preauth.response";
    public static final String PG_PREAUTH_AAV_REQUEST = "pg.preauth.aav.request";
    public static final String PG_PREAUTH_AAV_RESPONSE = "pg.preauth.aav.response";
    public static final String PG_CAPTURE_REQUEST = "pg.capture.request";
    public static final String PG_CAPTURE_RESPONSE = "pg.capture.response";
    public static final String PG_REVERSAL_REQUEST = "pg.reversal.request";
    public static final String PG_REVERSAL_RESPONSE = "pg.reversal.response";
    public static final String PG_REVERSAL_VOID_REQUEST = "pg.reversal.void.request";
    public static final String PG_REVERSAL_VOID_RESPONSE = "pg.reversal.void.response";
    public static final String PG_VOID_REQUEST = "pg.void.request";
    public static final String PG_VOID_RESPONSE = "pg.void.response";
    public static final String PG_SI_REQUEST = "pg.si.request";
    public static final String PG_SI_RESPONSE = "pg.si.response";
    public static final String PG_SI_AMEX_REQUEST = "pg.si.amex.request";
    public static final String PG_SI_AMEX_RESPONSE = "pg.si.amex.response";
    public static final String PG_RP_REQUEST = "pg.rp.request";
    public static final String PG_RP_RESPONSE = "pg.rp.response";
    public static final String PG_SI_AMEX_AAV_REQUEST = "pg.si.amex.aav.request";
    public static final String PG_SI_AMEX_AAV_RESPONSE = "pg.si.amex.aav.response";
    public static final String PG_RP_AAV_REQUEST = "pg.rp.aav.request";
    public static final String PG_RP_AAV_RESPONSE = "pg.rp.aav.response";
    public static final String PG_MO_SALE_REQUEST = "pg.mo.sale.request";
    public static final String PG_MO_SALE_RESPONSE = "pg.mo.sale.response";
    public static final String PG_TO_SALE_REQUEST = "pg.to.sale.request";
    public static final String PG_TO_SALE_RESPONSE = "pg.to.sale.response";
    public static final String PG_MO_SALE_AAV_REQUEST = "pg.mo.sale.aav.request";
    public static final String PG_MO_SALE_AAV_RESPONSE = "pg.mo.sale.aav.response";
    public static final String PG_TO_SALE_AAV_REQUEST = "pg.to.sale.aav.request";
    public static final String PG_TO_SALE_AAV_RESPONSE = "pg.to.sale.aav.response";
    public static final String PG_MO_REFUND_REQUEST = "pg.mo.refund.request";
    public static final String PG_MO_REFUND_RESPONSE = "pg.mo.refund.response";
    public static final String PG_TO_REFUND_REQUEST = "pg.to.refund.request";
    public static final String PG_TO_REFUND_RESPONSE = "pg.to.refund.response";
    public static final String PG_MO_REVERSAL_REQUEST = "pg.mo.reversal.request";
    public static final String PG_MO_REVERSAL_RESPONSE = "pg.mo.reversal.response";
    public static final String PG_TO_REVERSAL_REQUEST = "pg.to.reversal.request";
    public static final String PG_TO_REVERSAL_RESPONSE = "pg.to.reversal.response";
    public static final String PG_AUTH_ADJUSTMENT_REQUEST = "pg.authorization.adjustment.request";
    public static final String PG_AUTH_ADJUSTMENT_RESPONSE = "pg.authorization.adjustment.response";
    public static final String PG_CYBS_REVERSAL_REQUEST = "pg.timeout.reversal.request";
    public static final String PG_CYBS_REVERSAL_RESPONSE = "pg.timeout.reversal.response";

    public static final String PG_MOTO_SALE_REQUEST = "pg.moto.sale.request";
    public static final String PG_MOTO_SALE_RESPONSE = "pg.moto.sale.response";
    public static final String PG_MOTO_REVERSAL_REQUEST = "pg.moto.reversal.request";
    public static final String PG_MOTO_REVERSAL_RESPONSE = "pg.moto.reversal.response";
    public static final String PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST = "pg.moto.online.offline.refund.request";
    public static final String PG_MOTO_ONLINE_OFFLINE_REFUND_RESPONSE = "pg.moto.online.offline.refund.response";

    public static final String PG_ONLINE_OFFLINE_REFUND_REQUEST = "pg.online.offline.refund.request";
    public static final String PG_ONLINE_OFFLINE_REFUND_RESPONSE = "pg.online.offline.refund.response";
    public static final String PG_PREAUTH_REVERSAL_REQUEST = "pg.preauth.reversal.request";
    public static final String PG_PREAUTH_REVERSAL_RESPONSE = "pg.preauth.reversal.response";
    public static final String PG_PREAUTH_REVERSAL_VOID_REQUEST = "pg.preauth.reversal.void.request";
    public static final String PG_PREAUTH_REVERSAL_VOID_RESPONSE = "pg.preauth.reversal.void.response";
    public static final String PG_API_ONLINE_OFFLINE_REFUND_REQUEST = "pg.refund.pay.request";
    public static final String PG_API_ONLINE_OFFLINE_REFUND_RESPONSE = "pg.refund.pay.response";
    
    public static final String PG_MOTO_PREAUTH_REQUEST = "pg.moto.preauth.request";
    public static final String PG_MOTO_PREAUTH_RESPONSE = "pg.moto.preauth.response";

    public static final String PG_MOTO_CAPTURE_REQUEST = "pg.moto.capture.request";
    public static final String PG_MOTO_CAPTURE_RESPONSE = "pg.moto.capture.response";
    
    public static final String PG_ZVAV_PURCHASE_REQUEST = "pg.zvav.purchase.request";
    public static final String PG_ZVAV_PURCHASE_RESPONSE = "pg.zvav.purchase.response";
    
    public static final String PG_ZVAV_PURCHASE_AAV_REQUEST = "pg.zvav.purchase.aav.request";
    public static final String PG_ZVAV_PURCHASE_AAV_RESPONSE = "pg.zvav.purchase.aav.response";
    
    public static final String PG_PURCHASE_010200 = "010200";
    public static final String PG_REFUND_040220 = "040220";
    public static final String PG_PREAUTH_020200 = "020200";
    public static final String PG_MOTO_PREAUTH_340200 = "340200";
    public static final String PG_MOTO_CAPTURE_350220 = "350220";
    public static final String PG_ZVAV_PURCHASE_360200 = "360200";
    public static final String PG_ZVAV_PURCHASE_AAV_370200 = "370200";
    public static final String PG_PREAUTH_COMPLETION_030220 = "030220";
    public static final String PG_REVERSAL_050400 = "050400";
    public static final String PG_VOID = "";
    public static final String PG_SI_110200 = "110200";
    public static final String PG_PREAUTH_REVERSAL = "";
    public static final String PG_ONLINE_OFFLINE_REFUND = "";
    public static final String TERMINAL_BDK = "_TERMINAL_BDK";
    public static final String DYNAMIC_KEY = "_DYNAMIC_KEY";

    // EFT POS Constant
    public static final String EFTPOS_SIGNON_REQUEST = "eft.pos.signon.request";
    public static final String EFTPOS_SIGNON_RESPONSE = "eft.pos.signon.response";
    public static final String EFTPOS_KEYEXCHNAGE_REQUEST = "eft.pos.key.change.request";
    public static final String EFTPOS_KEYEXCHANGE_RESPONSE = "eft.pos.key.change.response";
    public static final String EFTPOS_HEARTBEAT_REQUEST = "eft.pos.echo.request";
    public static final String EFTPOS_HEARTBEAT_RESPONSE = "eft.pos.echo.response";
    public static final String EFTPOS_SIGNOFF_REQUEST = "eft.pos.signoff.request";
    public static final String EFTPOS_SIGNOFF_RESPONSE = "eft.pos.signoff.response";
    public static final String EFTPOS_FINANCIAL_ADVICE_PURCHASE_REQUEST = "eft.pos.financial.advice.purchase.request";
    public static final String EFTPOS_FINANCIAL_ADVICE_PURCHASE_RESPONSE = "eft.pos.financial.advice.purchase.response";
    public static final String EFTPOS_FINANCIAL_ADVICE_CASHATPOS_REQUEST = "eft.pos.financial.cashatpos.request";
    public static final String EFTPOS_FINANCIAL_ADVICE_CASHATPOS_RESPONSE = "eft.pos.financial.cashatpos.response";
    public static final String EFTPOS_FINANCIAL_REFUND_REQUEST = "eft.pos.financial.refund.request";
    public static final String EFTPOS_FINANCIAL_REFUND_RESPONSE = "eft.pos.financial.refund.response";
    public static final String EFTPOS_REVERSAL_REQUEST = "eft.pos.reversal.request";
    public static final String EFTPOS_REVERSAL_RESPONSE = "eft.pos.reversal.response";
    public static final String EFTPOS_REPEAT_REVERSAL_REQUEST = "eft.pos.repeat.reversal.request";
    public static final String EFTPOS_REPEAT_REVERSAL_RESPONSE = "eft.pos.repeat.reversal.response";
    public static final String EFTPOS_REPEAT_ADVICE_REQUEST = "eft.pos.repeat.advice.request";
    public static final String EFTPOS_REPEAT_ADVICE_RESPONSE = "eft.pos.repeat.advice.response";
    public static final String EFTPOS_TERMINAL_REVERSAL_REQUEST = "eft.pos.terminal.reversal.request";
    public static final String EFTPOS_FINANCIAL_ADVICE_PURCHASE_AND_CASHATPOS_REQUEST = "eft.pos.financial.purch.cashatpos.request";
    public static final String EFTPOS_REVERSAL_ADVICE_REQUEST = "eft.pos.reversal.advice.request";
    public static final String EFTPOS_REVERSAL_ADVICE_RESPONSE = "eft.pos.reversal.advice.response";
    public static final String EFTPOS_REVERSAL_ADVICE_REPEAT_RESPONSE = "eft.pos.reversal.advice.repeat.response";
    public static final String EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_REQUEST = "eft.pos.acquirer.reconciliation.advice.request";
    public static final String EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_RESPONSE = "eft.pos.acquirer.reconciliation.advice.response";
    public static final String EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_REPEAT_REQUEST = "eft.pos.acquirer.reconciliation.advice.repeat.request";
    public static final String EFTPOS_ACQUIRER_RECONCILIATION_ADVICE_REPEAT_RESPONSE = "eft.pos.acquirer.reconciliation.advice.repeat.response";

    public static final String EFTPOS_SETTLEMENT_REQUEST = "eftpos.settlement.request";
    public static final String EFTPOS_SETTLEMENT_RESPONSE = "eftpos.settlement.response";

    public static final String EFTPOS_TARGET_TYPE = "isg.eft.pos";
    public static final String EFTPOS_SCHEME_TYPE = "EftPos";
    // END

    //Payu
    public static final String KEY = "setKey";
    public static final String PRODUCTION_INFO = "setProductionInfo";
    public static final String FIRST_NAME = "setFirstName";
    public static final String EMAIL = "setEmail";
    public static final String PHONE = "setPhone";
    public static final String S_URL = "setSUrl";
    public static final String F_URL = "setFUrl";
    public static final String PG = "setPg";
    public static final String BANK_CODE = "setBankCode";
    public static final String HASH = "setHash";
    public static final String MIHPAYID = "setMihPayId";
    public static final String MODE = "setMode";
    public static final String STATUS = "setStatus";
    public static final String UNMAPPED_STATUS = "setUnmappedStatus";
    public static final String DISCOUNT = "setDiscount";
    public static final String NET_AMOUNT_DEBIT = "setNetAmountDebit";
    public static final String ADDED_ON = "setAddedOn";
    public static final String LAST_NAME = "setLastName";
    public static final String ADDRESS1 = "setAddress1";
    public static final String ADDRESS2 = "setAddress2";
    public static final String CITY = "setCity";
    public static final String STATE = "setState";
    public static final String COUNTRY = "setCountry";
    public static final String ZIPCODE = "setZipCode";
    public static final String UDF1 = "setUdf1";
    public static final String UDF2 = "setUdf2";
    public static final String UDF3 = "setUdf3";
    public static final String UDF4 = "setUdf4";
    public static final String UDF5 = "setUDF5";
    public static final String UDF6 = "setUdf6";



    public static final String API_RESPONSE_SEPARATOR = "##";

    public static final String CORRELATION_ID_SEPARATOR = "##";

    private static final Set<String> posSwitchTxns = new HashSet<String>() {{
        add(TIP_ADJUSTMENT_REQUEST);
        add(POS_SIGNON_REQUEST);
        add(PREAUTH_COMPLETION_REQUEST);
        add(OFFLINE_REQUEST);
        add(DIRECT_SETTLEMENT_REQUEST);
        add(EFTPOS_SETTLEMENT_REQUEST);
        add(BATCH_UPLOAD_REQUEST);
        add(BATCH_UPLOAD_SETTLEMENT_REQUEST);
        add(DCC_RATE_LOOKUP_REQUEST);
        add(POS_TERMINAL_INIT_REQUEST);
    }};

    private static final Set<String> pgSwitchTxns = new HashSet<String>() {{
        add(PG_CAPTURE_REQUEST);
    }};

    private static final Set<String> iciciUpiMsgType = new HashSet<String>() {{
        add(IciciMsgType.Pay.msgType);
        add(IciciMsgType.VerifyVPA.msgType);
        add(IciciMsgType.TransactionStatus.msgType);
        add(IciciMsgType.GetAutoCreatedVPA.msgType);
        add(IciciMsgType.UpiRefund.msgType);
        add(IciciMsgType.UpiReversal.msgType);
        add(IciciMsgType.UpiQR.msgType);
    }};

    private static final Set<String> iciciCorpNBMsgType = new HashSet<String>() {{
        add(IciciMsgType.NbCorpPay.msgType);
    }};

    private static final Set<String> iciciRetailNBMsgType = new HashSet<String>() {{
        add(IciciMsgType.NbRetailPay.msgType);
    }};

    private static final Set<String> originalTxnsRequired = new HashSet<String>() {{
        add(TIP_ADJUSTMENT_REQUEST);
        add(PREAUTH_COMPLETION_REQUEST);
        add(VOID_OTHERS_REQUEST);
        add(VOID_REFUND_REQUEST);
        add(REVERSAL_REQUEST);
        add(PG_CAPTURE_REQUEST);
        add(PG_ONLINE_REFUND_REQUEST);
        add(PG_REVERSAL_REQUEST);
        add(PG_REVERSAL_VOID_REQUEST);
        add(PG_PREAUTH_REVERSAL_REQUEST);
        add(PG_PREAUTH_REVERSAL_VOID_REQUEST);
        add(PG_OFFLINE_REFUND_REQUEST);
        add(PG_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_MOTO_REVERSAL_REQUEST);
        add(PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_API_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_MO_REVERSAL_REQUEST);
        add(PG_TO_REVERSAL_REQUEST);
        add(PG_MO_REFUND_REQUEST);
        add(PG_TO_REFUND_REQUEST);
        add(PG_MOTO_CAPTURE_REQUEST);
        add(PG_REFUND_AAV_REQUEST);
        add(BQR_REFUND_REQUEST);
        add(BQR_REVERSAL_REQUEST);
    }};

    private static final Set<String> txnLogNotRequired = new HashSet<String>() {{
        add(TIP_ADJUSTMENT_REQUEST);
        add(TIP_ADJUSTMENT_RESPONSE);
        add(POS_SIGNON_REQUEST);
        add(POS_SIGNON_RESPONSE);
        add(VERIFY_VPA_REQUEST);
        add(VERIFY_VPA_RESPONSE);
        add(POS_TERMINAL_INIT_REQUEST);
        add(POS_TERMINAL_INIT_RESPONSE);
    }};

    private static final Set<String> pgMsgTypwAndMsgTypeIdValidation = new HashSet<String>() {{
        add(PG_PURCHASE_010200);
        add(PG_REFUND_040220);
        add(PG_PREAUTH_020200);
        add(PG_PREAUTH_COMPLETION_030220);
        add(PG_REVERSAL_050400);
        add(PG_SI_110200);
        add(PG_ONLINE_OFFLINE_REFUND);
        add(PG_MOTO_PREAUTH_340200);
        add(PG_MOTO_CAPTURE_350220);
        add(PG_ZVAV_PURCHASE_360200);
        add(PG_ZVAV_PURCHASE_AAV_370200);
    }};

    private static final Set<String> validTxnsList = new HashSet<String>(){{
    	add(PURCHASE_REQUEST);
    	add(MOTO_REQUEST);
    	add(CASHWITHDRAWAL_REQUEST);
    	add(CASHATPOS_REQUEST);
    	add(PURCHASE_CASHATPOS_REQUEST);
    	add(PREAUTH_REQUEST);
    	add(PREAUTH_COMPLETION_REQUEST);
    	add(BALANCE_INQUIRY_REQUEST);
    	add(RUPAY_BALANCE_INQUIRY_REQUEST);
    	add(REFUND_REQUEST);
    	add(TIP_ADJUSTMENT_REQUEST);
        add(OFFLINE_REQUEST);
        add(VOID_OTHERS_REQUEST);
        add(VOID_REFUND_REQUEST);
        add(REVERSAL_REQUEST);
        add(DIRECT_SETTLEMENT_REQUEST);
        add(BATCH_UPLOAD_REQUEST);
        add(BATCH_UPLOAD_SETTLEMENT_REQUEST);
        add(POS_SIGNON_REQUEST);
        add(ADD_MONEY_REQUEST);
        add(BALANCE_UPDATE_REQUEST);
        add(SERVICE_CREATION_REQUEST);
        add(ZVAV_REQUEST);
        add(POS_TERMINAL_INIT_REQUEST);
        //pg switch
        add(PG_PURCHASE_REQUEST);
        add(PG_ONLINE_REFUND_REQUEST);
        add(PG_OFFLINE_REFUND_REQUEST);
        add(PG_PREAUTH_REQUEST);
        add(PG_CAPTURE_REQUEST);
        add(PG_REVERSAL_REQUEST);
        add(PG_VOID_REQUEST);
        add(PG_SI_REQUEST);
        add(PG_SI_AMEX_REQUEST);
        add(PG_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_PREAUTH_REVERSAL_REQUEST);
        add(PG_PREAUTH_REVERSAL_VOID_REQUEST);
        add(PG_AUTH_ADJUSTMENT_REQUEST);
        add(PG_MOTO_SALE_REQUEST);
        add(PG_MOTO_REVERSAL_REQUEST);
        add(PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_PURCHASE_AAV_REQUEST);
        add(PG_AAV_REQUEST);
        add(PG_REFUND_AAV_REQUEST);
        add(PG_MO_SALE_REQUEST);
        add(PG_MO_REFUND_REQUEST);
        add(PG_MO_REVERSAL_REQUEST);
        add(PG_TO_SALE_REQUEST);
        add(PG_TO_REFUND_REQUEST);
        add(PG_TO_REVERSAL_REQUEST);
        add(PG_RP_REQUEST);
        add(PG_RP_AAV_REQUEST);
        add(PG_SI_AMEX_AAV_REQUEST);
        add(PG_MO_SALE_AAV_REQUEST);
        add(PG_TO_SALE_AAV_REQUEST);
        add(PG_MOTO_PREAUTH_REQUEST);
        add(PG_MOTO_CAPTURE_REQUEST);
        add(PG_ZVAV_PURCHASE_AAV_REQUEST);
        add(PG_ZVAV_PURCHASE_REQUEST);
        
        //BQR Switch
        add(BQR_PURCHASE_REQUEST);
        add(BQR_REFUND_REQUEST);
        add(BQR_REVERSAL_REQUEST);
        add(BQR_STIP_REQUEST);
        add(DCC_RATE_LOOKUP_REQUEST);

        //For EFTPOS
        add(EFTPOS_FINANCIAL_ADVICE_PURCHASE_REQUEST);
        add(EFTPOS_FINANCIAL_ADVICE_CASHATPOS_REQUEST);
        add(EFTPOS_FINANCIAL_ADVICE_PURCHASE_AND_CASHATPOS_REQUEST);
        add(EFTPOS_FINANCIAL_REFUND_REQUEST);
        add(EFTPOS_REPEAT_ADVICE_REQUEST);
        add(EFTPOS_SETTLEMENT_REQUEST);

    }};

    @Getter
    private static final Set<String> TxnEligibleForAutoReversal = new HashSet<String>() {{
        add(MOTO_REQUEST);
        add(MOTO_RESPONSE);
        add(PURCHASE_REQUEST);
        add(PURCHASE_RESPONSE);
        add(CASHATPOS_REQUEST);
        add(CASHATPOS_REQUEST);
        add(PURCHASE_CASHATPOS_REQUEST);
        add(PURCHASE_CASHATPOS_REQUEST);
        add(CASHWITHDRAWAL_REQUEST);
        add(CASHWITHDRAWAL_RESPONSE);
        add(REFUND_REQUEST);
        add(REFUND_RESPONSE);
        add(PREAUTH_REQUEST);
        add(PREAUTH_RESPONSE);
        
        //Pg Transactions
        add(PG_PURCHASE_REQUEST);
        add(PG_PURCHASE_RESPONSE);
        add(PG_PURCHASE_AAV_REQUEST);
        add(PG_PURCHASE_AAV_RESPONSE);
        add(PG_ONLINE_REFUND_REQUEST);
        add(PG_ONLINE_REFUND_RESPONSE);
        add(PG_OFFLINE_REFUND_REQUEST);
        add(PG_OFFLINE_REFUND_RESPONSE);
        add(PG_PREAUTH_REQUEST);
        add(PG_PREAUTH_RESPONSE);
        add(PG_CAPTURE_REQUEST);
        add(PG_CAPTURE_RESPONSE);
        add(PG_SI_REQUEST);
        add(PG_SI_RESPONSE);
        add(PG_SI_AMEX_REQUEST);
        add(PG_SI_AMEX_RESPONSE);
        add(PG_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_ONLINE_OFFLINE_REFUND_RESPONSE);
        add(PG_AUTH_ADJUSTMENT_REQUEST);
        add(PG_AUTH_ADJUSTMENT_RESPONSE);
        add(PG_MOTO_SALE_REQUEST);
        add(PG_MOTO_SALE_RESPONSE);
        add(PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST);
        add(PG_MOTO_ONLINE_OFFLINE_REFUND_RESPONSE);
        add(PG_AAV_REQUEST);
        add(PG_AAV_RESPONSE);
        add(PG_REFUND_AAV_REQUEST);
        add(PG_REFUND_AAV_RESPONSE);
        add(PG_MO_SALE_REQUEST);
        add(PG_MO_SALE_RESPONSE);
        add(PG_MO_REFUND_REQUEST);
        add(PG_MO_REFUND_RESPONSE);
        add(PG_TO_SALE_REQUEST);
        add(PG_TO_SALE_RESPONSE);
        add(PG_TO_REFUND_REQUEST);
        add(PG_TO_REFUND_RESPONSE);
        add(PG_RP_REQUEST);
        add(PG_RP_RESPONSE);
        add(PG_RP_AAV_REQUEST);
        add(PG_RP_AAV_RESPONSE);
        add(PG_SI_AMEX_AAV_REQUEST);
        add(PG_SI_AMEX_AAV_RESPONSE);
        add(PG_MO_SALE_AAV_REQUEST);
        add(PG_MO_SALE_AAV_RESPONSE);
        add(PG_TO_SALE_AAV_REQUEST);
        add(PG_TO_SALE_AAV_RESPONSE);
        add(PG_MOTO_PREAUTH_REQUEST);
        add(PG_MOTO_PREAUTH_RESPONSE);
        add(PG_MOTO_CAPTURE_REQUEST);
        add(PG_MOTO_CAPTURE_RESPONSE);
    }};

    public static boolean isTxnLogRequired(String txnName) {
        return !txnLogNotRequired.contains(txnName);
    }

    public static boolean isOriginalTxnRequired(String txnName) {
        return originalTxnsRequired.contains(txnName);
    }

    public static boolean isPosSwitchTxn(String txnName) {
        return posSwitchTxns.contains(txnName);
    }

    public static boolean isPgSwitchTxn(String txnName) {
        return pgSwitchTxns.contains(txnName);
    }

    public static boolean isIciciUpiMsgType(String txnName) {
        return iciciUpiMsgType.contains(txnName);
    }

    public static boolean isIciciCorpNBMsgType(String txnName) {
        return iciciCorpNBMsgType.contains(txnName);
    }

    public static boolean isIciciRetailNBMsgType(String txnName) {
        return iciciRetailNBMsgType.contains(txnName);
    }

    public static boolean isPosSwitchTipAdjustTxn(String txnName) {
        return posSwitchTxns.contains(txnName) && TIP_ADJUSTMENT_REQUEST.equals(txnName);
    }

    public static boolean isPosSwitchDccRateLookupTxn(String txnName) {
        return posSwitchTxns.contains(txnName) && DCC_RATE_LOOKUP_REQUEST.equals(txnName);
    }
    
    public static boolean isValidTxnType(String txnName) {
        return validTxnsList.contains(txnName);
    }

    public static boolean pgMsgTypwAndMsgTypeIdValidation(String msgTypeAndMsgTypeId) {
        return pgMsgTypwAndMsgTypeIdValidation.contains(msgTypeAndMsgTypeId);

    }

    public static final String RES_CODE_SUCCESS = "00";
    public static final String RES_CODE_INVALID_TXN = "12";
    public static final String RES_CODE_INVALID_TXN_AMT = "13";
    public static final String RES_CODE_MANDATORY_FIELD_NOT_PRESENT = "30";
    public static final String RES_CODE_ORIGINAL_TXN_NOT_PRESENT = "78";
    public static final String RES_CODE_OFFLINE_SALE = "Y1";
    public static final String RES_CODE_ISSUER_UNAVAILABLE = "91";
    public static final String RES_CODE_INVALID_MERCHANT = "03";
    public static final String RES_CODE_SYSTEM_ERROR = "96";
    public static final String RES_CODE_TERMINAL_BATCH_UNSETTLED = "97";
    public static final String RES_CODE_INVALID_CARD_NUMBER = "14";
    public static final String RES_CODE_INVALID_MAC = "89";
    public static final String RES_CODE_AMT_VERFICATION = "85";
    public static final String RES_AMEX_KEY_EXCHANE_CODE_SUCCESS = "800";
    public static final String RES_AMEX_REVERSAL_CODE_SUCCESS = "400";
    public static final String RES_CODE_INVALID_REFUND_AMT = "61";
    public static final String RES_CODE_INVALID_REFUND_COUNT = "65";

    public static final String RES_CODE_DATA_ERROR = "DE";
    public static final String RES_CODE_FORMAT_ERROR = "FE";
    public static final String RES_CODE_INVALID_BIN = "31";
    //This applicable when original Txn for refund and pre auth completion not found
    public static final String RES_CODE_ORIGINAL_TXN_NOT_FOUND = "NF";
    //Original txn of reversal is not found
    public static final String RES_CODE_ORIGINAL_OF_REVERSAL_NOT_FOUND = "45";
    public static final String RES_CODE_ISSUER_NOT_AVAILABLE = "UC";
    public static final String RES_CODE_CAPTURE_EXCEEDED = "CE";
    public static final String RES_CODE_REFUND_EXCEEDED = "RE";
    public static final String RES_CODE_REVERSAL_EXCEEDED = "ER";

    public static final String RUPAY_TIMEOUT_REVERSAL_RES_CODE = "68";

    public static final int DE_01_BITMAP = 1;
    public static final int DE_02_PAN = 2;
    public static final int DE_14_EXPIRY_DATE = 14;
    public static final int DE_35_TRACK2DATA = 35;
    public static final int DE_45_TRACK1DATA = 45;
    public static final int DE_52_PIN = 52;
    public static final int DE_55_ICC = 55;

    public static final int DE_04_PG_PAN = 4;

    public static final HashSet<Integer> txnSensitiveDataList = new HashSet<Integer>() {{
        add(DE_02_PAN);
        add(DE_14_EXPIRY_DATE);
        add(DE_35_TRACK2DATA);
        add(DE_45_TRACK1DATA);
        add(DE_52_PIN);
    }};

    public static final List<String> txnDataElementsForGetAndSet = new ArrayList<String>() {{
        add("MTI");
        add("BitMap");
        add("Pan");
        add("ProcessingCode");
        add("TxnAmt");
        add("SettlementAmt");
        add("CardHolderBillingAmt");
        add("TransmissionTime");
        add("CardHolderBillingFee");
        add("SettlementConversionRate");
        add("CardHolderBillingConversionRate");
        add("Stan");
        add("LocalTxnTime");
        add("LocalTxnDate");
        add("ExpirationDate");
        add("SettlementDate");
        add("ConversionDate");
        add("CaptureDate");
        add("MerchantType");
        add("AquirerCountryCode");
        add("PanExtendedCountryCode");
        add("PanForwardingCountryCode");
        add("PosEntryMode");
        add("CardSeqNo");
        add("NiiId");
        add("PosConditionCode");
        add("PosCaptureCode");
        add("AuthIdResLength");
        add("TxnFee");
        add("SettlementFee");
        add("TxnProcessingFee");
        add("SettlementProcessingFee");
        add("AquirerIdCode");
        add("ForwardingInstIdCode");
        add("PanExtended");
        add("Track2Data");
        add("Track3Data");
        add("RetrievalRefNo");
        add("AuthIdRes");
        add("ResCode");
        add("ServiceRestrictionCode");
        add("CardAcceptorTerminalId");
        add("CardAcceptorId");
        add("CardAcceptorInfo");
        add("AdditionalResData");
        add("Track1Data");
        add("IsoAd");
        add("NationalAd");
        add("PrivateAd");
        add("TxnCurrencyCode");
        add("SettlementCurrenyCode");
        add("CardHolderBillingCurrencyCode");
        add("Pin");
        add("SecurityControlInfo");
        add("AdditionalAmounts");
        add("IccData");
        add("Reserved56");
        add("Reserved57");
        add("Reserved58");
        add("Reserved59");
        add("TerminalData");
        add("Ciad");
        add("PostalCode");
        add("AtmPinOffsetData");
        add("MsgAuthCode");
        add("ExtendedBitmapIndicator");
        add("SettlementCode");
        add("ExtendedPaymentCode");
        add("ReceiverCountryCode");
        add("SettlementCountryCode");
        add("NetworkMgmtInfoCode");
        add("MsgNo");
        add("LastMsgNo");
        add("ActionDate");
        add("NoOfCredits");
        add("CreditsReversalNo");
        add("NoOfDebits");
        add("DebitsReversalNo");
        add("TransferNo");
        add("TransferReversalNo");
        add("NoOfInquiries");
        add("NoOfAuths");
        add("CreditsProcessingFee");
        add("CreditsTxnFee");
        add("DebitsProcessingFee");
        add("DebitsTxnFee");
        add("TotalCredits");
        add("CreditsReversal");
        add("TotalDebits");
        add("DebitsReversal");
        add("OriginalDataElements");
        add("FileUpdateCode");
        add("FileSecurityCode");
        add("ResIndicator");
        add("ServiceIndicator");
        add("ReplacementAmts");
        add("MsgSecurityCode");
        add("NetSettlement");
        add("Payee");
        add("SettlementIdCode");
        add("ReceiverIdCode");
        add("FileName");
        add("AccId1");
        add("AccId2");
        add("TxnDesc");
        add("Reserved105");
        add("Reserved106");
        add("Reserved107");
        add("Reserved108");
        add("Reserved109");
        add("Reserved110");
        add("Reserved111");
        add("Reserved112");
        add("Reserved113");
        add("Reserved114");
        add("Reserved115");
        add("Reserved116");
        add("Reserved117");
        add("Reserved118");
        add("Reserved119");
        add("Reserved120");
        add("Reserved121");
        add("Reserved122");
        add("Reserved123");
        add("Reserved124");
        add("Reserved125");
        add("Reserved126");
        add("Reserved127");
        add("Reserved128");
    }};

    public static final Set<Integer> rupayEmvTagSuppressList = new HashSet<Integer>() {{
//        add(Integer.parseInt("df15", 16));
//        add(Integer.parseInt("df16", 16));
        add(Integer.parseInt("9f53", 16));
        add(Integer.parseInt("5f28", 16));
        add(Integer.parseInt("9f42", 16));
    }};

    public static final Set<Integer> eftposEmvTagSuppressList = new HashSet<Integer>() {{
        add(Integer.parseInt("5A", 16));
        add(Integer.parseInt("9F06", 16));
        add(Integer.parseInt("8C", 16));
        add(Integer.parseInt("57", 16));
        add(Integer.parseInt("9F40", 16));
        add(Integer.parseInt("5F34", 16));
        add(Integer.parseInt("9F02", 16));
        add(Integer.parseInt("9F03", 16));
    }};


    public static final Set<String> rupayCardCategorySuppressList = new HashSet<String>() {{
        add("DPAS");
        add("UPI");
        add("JCB");
    }};
    
    public static final Set<String> sli211 = new HashSet<String>() {{
        add("kE");
        add("kF");
        add("kL");
        add("kM");
    }};

    public static final Set<String> sli212 = new HashSet<String>() {{
        add("kA");
        add("kB");
        add("kC");
        add("kD");
        add("kG");
        add("kH");
        add("kJ");
        add("kK");
        add("kQ");
        add("kR");
        add("kS");
        add("kT");
    }};

    public static final Set<String> sli214 = new HashSet<String>() {{
        add("kX");
        add("kY");
        add("kZ");
    }};

    public static final Set<String> sli216 = new HashSet<String>() {{
        add("kN");
        add("kU");
        add("kK");
        add("kW");
    }};

    public static final Set<String> sli217 = new HashSet<String>() {{
        add("kO");
        add("kP");
    }};


}
