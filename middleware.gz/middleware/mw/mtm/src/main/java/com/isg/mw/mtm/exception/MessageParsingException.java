package com.isg.mw.mtm.exception;

public class MessageParsingException extends MessageTransformationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageParsingException(String expMsg) {
		super(expMsg);
	}

	public MessageParsingException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}
