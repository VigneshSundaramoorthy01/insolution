package com.isg.mw.mtm.transform.pos.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.isg.mw.mtm.transform.TmmConstants;

public class MandatoryFieldUtility {
	
	private MandatoryFieldUtility() {
    }

	public static final String PAN = "getPan";
	public static final String PROCESSING_CODE = "getProcessingCode";
	public static final String TXN_AMT = "getTxnAmt";
	public static final String STAN = "getStan";
	public static final String LOCAL_TXN_TIME = "getLocalTxnTime";
	public static final String LOCAL_TXN_DATE = "getLocalTxnDate";
	public static final String EXPIRATION_DATE = "getExpirationDate";
	public static final String POS_ENTRY_MODE = "getPosEntryMode";
	public static final String NIIID = "getNiiId";
	public static final String POS_CONDITION_CODE = "getPosConditionCode";
	public static final String RETRIEVAL_REF_NO = "getRetrievalRefNo";
	public static final String AUTH_ID_RES = "getAuthIdRes";
	public static final String RES_CODE = "getResCode";
	public static final String CARD_ACCEPTOR_TERMINAL_ID = "getCardAcceptorTerminalId";
	public static final String CARD_ACCEPTOR_ID = "getCardAcceptorId";
	public static final String ADDITIONAL_AMOUNTS = "getAdditionalAmounts";
	public static final String POSTAL_CODE = "getPostalCode";
	public static final String ATM_PIN_OFFSET_DATA = "getAtmPinOffsetData";
	public static final String ORIGINAL_AMOUNT = "getTerminalData";
	public static final String SALE_COUNT = "getSaleCount";
	public static final String SALE_AMOUNT = "getSaleAmount";
	public static final String REFUND_COUNT = "getRefundCount";
    public static final String REFUND_AMOUNT = "getRefundAmount";
    /*
     * PG - FIELD 
     */
    public static final String PG_LENGTH = "getPgLength";
    public static final String CVV2 = "getCvv2";
    public static final String MSG_TYPE = "getMsgType";
    public static final String MERCHANT_TYPE = "getMerchantType";
    public static final String AVV = "getAvv";
    public static final String CVV_RESULT = "getCvvResult";
    public static final String PG_TXN_REF_NO = "getPgTxnRefNo";
    public static final String ECOMMERCE_INDICATOR = "getEcommerceIndicator";
    public static final String ORIGINAL_TXN_PGID = "getOriginalTxnPgid";
    public static final String FRM_IP_ADDRESS = "getFrmIpAddress";
    public static final String PG_ID = "getPgId";
    public static final String DS_VERSION = "getDsVersion";
    public static final String BANK_NAME = "getBankName";
    public static final String CANCELATION_ID = "getCancelationId";
    public static final String MAC = "getMac";
    

	//fieldSet = txnfieldMap.get(reqSrcTmm.getTransactionName);

	/*case 20000://SALE
	case 20001://CASH WITHDRAWAL
	case 20009://SALE WITH CASH@POS / CASH@POS
	MandateField = {3,4,11,22,24,25,41,42,62}
	 */
	private static final Set<String> saleSet = new HashSet<String>(){{

		add(PROCESSING_CODE);
		add(TXN_AMT);
		add(STAN);
		add(POS_ENTRY_MODE);
		add(NIIID);
		add(POS_CONDITION_CODE);
		add(CARD_ACCEPTOR_TERMINAL_ID);
		add(CARD_ACCEPTOR_ID);		
		add(POSTAL_CODE);

	}};
	

	/*case 10000://PRE-AUTHORIZATION
	MandateField = {3,4,11,22,24,25,41,42,62}*/
	private static final Set<String> preAuthSet = new HashSet<String>() {{
		add(PROCESSING_CODE);
		add(TXN_AMT);
		add(STAN);
		add(POS_ENTRY_MODE);
		add(NIIID);
		add(POS_CONDITION_CODE);
		add(CARD_ACCEPTOR_TERMINAL_ID);
		add(CARD_ACCEPTOR_ID);
		add(POSTAL_CODE);
	}};


	/*case 22040://PRE-AUTH COMPLETION / SALE COMPLETION
	MandateField = {3,4,11,12,13,14,22,24,25,37,38,41,42,62};//39//61
	 */	private static final Set<String> preAuthCompletionSet = new HashSet<String>() {{        
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(LOCAL_TXN_TIME);
		 add(LOCAL_TXN_DATE);
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(RETRIEVAL_REF_NO);
		 add(AUTH_ID_RES);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(POSTAL_CODE);
	 }};


	 /*case 22000://OFF-LINE SALE (ONLINE)
	MandateField = {2,3,4,11,12,13,14,22,24,25,41,42,62};*/
	 private static final Set<String> offlineSaleSet = new HashSet<String>() {{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(LOCAL_TXN_TIME);
		 add(LOCAL_TXN_DATE);
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(POSTAL_CODE);
	 }};

	 /*case 20031://BALANCE INQUIRY//Temporary FIX
case 10031://BALANCE INQUIRY
	MandateField = {3,11,22,24,25,41,42};*/
	 private static final Set<String> balInquiryReqSet = new HashSet<String>() {{
		 add(PROCESSING_CODE);
		 add(STAN);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);

	 }};
	 
	 private static final Set<String> balInquiryResSet = new HashSet<String>() {{
		 add(PROCESSING_CODE);
		 add(STAN);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(ADDITIONAL_AMOUNTS);
	 }};

	 /*case 20020://REFUND ONLINE
	MandateField = {3,4,11,12,13,22,24,25,41,42,62};*/
	 private static final Set<String> refundSet = new HashSet<String>() {{
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(LOCAL_TXN_TIME);
		 add(LOCAL_TXN_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(POSTAL_CODE);
	 }};


	 /*case 20051://MOTO TXN
	MandateField = {2,3,4,11,14,22,24,25,41,42,62};*/
	 private static final Set<String> motoSet = new HashSet<String>() {{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(POSTAL_CODE);
	 }};


	 /*case 22050://TIP ADJUST

	MandateField = {2,3,4,11,12,13,14,22,24,25,37,38,39,41,42,54,60,62}*/
	 private static final Set<String> tipAdjustSet = new HashSet<String>() {{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(LOCAL_TXN_TIME);
		 add(LOCAL_TXN_DATE);
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(RETRIEVAL_REF_NO);
		 add(AUTH_ID_RES);
		 add(RES_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(ADDITIONAL_AMOUNTS);
		 add(ORIGINAL_AMOUNT);
		 add(POSTAL_CODE);
	 }};

	 /*case 400://REVERSAL

	MandateField = {2,3,4,11,14,22,24,25,41,42,62}*/
	 private static final Set<String> reversalSet = new HashSet<String>() {{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);	 
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(POSTAL_CODE);
	 }};

	 /*case 22002://Void of Sale/Cash Advance/Cash back/Sale with cash back/PreAuthorization/Offline Sale
case 22022://VOID of Refund
	MandateField = {2,3,4,11,12,13,14,22,24,25,37,38,39,41,42,60,62}*/
	 private static final Set<String> voidSet = new HashSet<String>() {{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(LOCAL_TXN_TIME);
		 add(LOCAL_TXN_DATE);	 
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(RETRIEVAL_REF_NO);
		 add(AUTH_ID_RES);
		 add(RES_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(ORIGINAL_AMOUNT);
		 add(POSTAL_CODE);
	 }};



	 /*case 50092://Direct Settlement
case 50096://Settlement after batch upload

	MandateField = {3,11,24,41,42,60,62}*/
	 private static final Set<String> settlementSet = new HashSet<String>() {{
		 add(PROCESSING_CODE);
		 add(STAN);
		 add(NIIID);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(SALE_COUNT);
		 add(SALE_AMOUNT);
		 add(REFUND_COUNT);
		 add(REFUND_AMOUNT);
		 add(POSTAL_CODE);
	 }};

	 /*case 320://BATCH UPLOAD
	MandateField = {2,3,4,11,12,13,14,22,24,25,37,38,39,41,42,62};//60 commented for testing.*/	
	 private static final Set<String> batchUploadSet = new HashSet<String>() {{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(LOCAL_TXN_TIME);
		 add(LOCAL_TXN_DATE);	 
		 add(EXPIRATION_DATE);
		 add(POS_ENTRY_MODE);
		 add(NIIID);
		 add(POS_CONDITION_CODE);
		 add(RETRIEVAL_REF_NO);
		 add(AUTH_ID_RES);
		 add(RES_CODE);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(POSTAL_CODE);
	 }};


	 /*case 80099://KEY EXCHANGE
	MandateField = {3,11,41,42,63}*/
	 private static final Set<String> keyExchangeSet = new HashSet<String>() {{
		 add(PROCESSING_CODE);
		 add(STAN);
		 //add(LOCAL_TXN_TIME);
		 //add(LOCAL_TXN_DATE);
		 add(NIIID);
	 }};

	  
	 /*case 20028://ADD MONEY
		case 20029://BALANCE UPADTE
	
		MandateField = {3,4,11,22,24,25,41,42,62,63}
		 */
	 private static final Set<String> addMoneySet = new HashSet<String>(){{

			add(PROCESSING_CODE);
			add(TXN_AMT);
			add(STAN);
			add(POS_ENTRY_MODE);
			add(NIIID);
			add(POS_CONDITION_CODE);
			add(CARD_ACCEPTOR_TERMINAL_ID);
			add(CARD_ACCEPTOR_ID);		
			add(POSTAL_CODE);
			add(ATM_PIN_OFFSET_DATA);
	 }};
	 /*case 60091://CURRENCY CONVERSION TRANSACTION
	MandateField = {3,11,41,42,63}*/
	 /*private static final Set<String> currConSet = new HashSet<String>() {{
		 add(PROCESSING_CODE);
		 add(STAN);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);
		 add(ATM_PIN_OFFSET_DATA);
	 }};*/

		/*case 60000://DCC RATE LOOKUP
	
		MandateField = {3,4,11,22,24,25,41,42,62,63}
		 */
		
		
	 private static final Set<String> dccRateLookupSet = new HashSet<String>(){{
		 add(PAN);
		 add(PROCESSING_CODE);
		 add(TXN_AMT);
		 add(STAN);
		 add(NIIID);
		 add(CARD_ACCEPTOR_TERMINAL_ID);
		 add(CARD_ACCEPTOR_ID);		
		 //add(ATM_PIN_OFFSET_DATA);
	 }};
	 
	 
	 public static Map<String, Set<String>> getTxnfieldMap() {
		 
		 Map<String, Set<String>> txnfieldMap = new HashMap<String, Set<String>>();
		 
		 txnfieldMap.put(TmmConstants.PURCHASE_REQUEST, saleSet);
		 txnfieldMap.put(TmmConstants.CASHWITHDRAWAL_REQUEST, saleSet);
		 txnfieldMap.put(TmmConstants.CASHATPOS_REQUEST, saleSet);
		 txnfieldMap.put(TmmConstants.PURCHASE_CASHATPOS_REQUEST, saleSet);
		 txnfieldMap.put(TmmConstants.PREAUTH_REQUEST, preAuthSet);
		 txnfieldMap.put(TmmConstants.PREAUTH_COMPLETION_REQUEST, preAuthCompletionSet);
		 txnfieldMap.put(TmmConstants.OFFLINE_REQUEST, offlineSaleSet);
		 txnfieldMap.put(TmmConstants.BALANCE_INQUIRY_REQUEST, balInquiryReqSet);
		 txnfieldMap.put(TmmConstants.BALANCE_INQUIRY_RESPONSE, balInquiryResSet);
		 txnfieldMap.put(TmmConstants.RUPAY_BALANCE_INQUIRY_REQUEST, balInquiryReqSet);
		 txnfieldMap.put(TmmConstants.RUPAY_BALANCE_INQUIRY_RESPONSE, balInquiryResSet);
		 txnfieldMap.put(TmmConstants.REFUND_REQUEST, refundSet);
		 txnfieldMap.put(TmmConstants.MOTO_REQUEST, motoSet);
		 txnfieldMap.put(TmmConstants.TIP_ADJUSTMENT_REQUEST, tipAdjustSet);
		 txnfieldMap.put(TmmConstants.REVERSAL_REQUEST, reversalSet);
		 txnfieldMap.put(TmmConstants.VOID_OTHERS_REQUEST, voidSet);
		 txnfieldMap.put(TmmConstants.VOID_REFUND_REQUEST, voidSet);
		 
		 txnfieldMap.put(TmmConstants.DIRECT_SETTLEMENT_REQUEST, settlementSet);
		 txnfieldMap.put(TmmConstants.BATCH_UPLOAD_SETTLEMENT_REQUEST, settlementSet);
		 txnfieldMap.put(TmmConstants.BATCH_UPLOAD_REQUEST, batchUploadSet);
		 txnfieldMap.put(TmmConstants.BALANCE_UPDATE_REQUEST, addMoneySet);
		 txnfieldMap.put(TmmConstants.ADD_MONEY_REQUEST, addMoneySet);
		 txnfieldMap.put(TmmConstants.DCC_RATE_LOOKUP_REQUEST, dccRateLookupSet);
		 
		 txnfieldMap.put(TmmConstants.POS_SIGNON_REQUEST, keyExchangeSet);
		 
		 txnfieldMap.put(TmmConstants.POS_TERMINAL_INIT_REQUEST, keyExchangeSet);
		 
		 txnfieldMap.put(TmmConstants.SERVICE_CREATION_REQUEST, addMoneySet);
		 
		 //txnfieldMap.put("", currConSet);//Not present in routing defination
		 
		 //PG SWITCH KEYs
		 txnfieldMap.put(TmmConstants.PG_PURCHASE_REQUEST, pgSaleReqSet);
		 txnfieldMap.put(TmmConstants.PG_ONLINE_OFFLINE_REFUND_REQUEST, pgOnlineOfflineRefundReqSet);
		 txnfieldMap.put(TmmConstants.PG_PREAUTH_REQUEST, pgPreAuthReqSet);
		 txnfieldMap.put(TmmConstants.PG_MOTO_PREAUTH_REQUEST, pgPreAuthReqSet);
		 txnfieldMap.put(TmmConstants.PG_CAPTURE_REQUEST, pgCaptureReqSet);
		 txnfieldMap.put(TmmConstants.PG_MOTO_CAPTURE_REQUEST, pgCaptureReqSet);
		 txnfieldMap.put(TmmConstants.PG_REVERSAL_REQUEST, pgReversalReqSet);
		 txnfieldMap.put(TmmConstants.PG_SI_REQUEST, pgSIReqSet);
		 txnfieldMap.put(TmmConstants.PG_MOTO_SALE_REQUEST,pgMotoSaleReqSet);
		 txnfieldMap.put(TmmConstants.PG_MOTO_REVERSAL_REQUEST,pgReversalReqSet);
		 txnfieldMap.put(TmmConstants.PG_MOTO_ONLINE_OFFLINE_REFUND_REQUEST,pgOnlineOfflineRefundReqSet);
		 
		 
		 		 
		 return txnfieldMap;
	 }

	/*
	 * Sale Request-pg
	 * MandateField ={1,2,3,4,5,6,7,9,10,11,12,19,20,21,22,29,33,34}
	 */
	private static final Set<String> pgSaleReqSet = new HashSet<String>() {
		{

//			add(POS_ENTRY_MODE);
			add(MSG_TYPE);
			add(PROCESSING_CODE);
			add(PAN);
			add(TXN_AMT);
			/*For certification test case 12.5 exp_date should be commented*/
			//add(EXPIRATION_DATE);
			//add(CVV2);
			add(CARD_ACCEPTOR_TERMINAL_ID);
			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			add(PG_TXN_REF_NO);
//			add(ECOMMERCE_INDICATOR);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			//add(DS_VERSION);
//			add(BANK_NAME);

		}
	};

	/*
	 * Sale Response-pg
	 * PreAuth Response -pg
	 * MandateField ={2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34}
	 */
	private static final Set<String> pgSaleResSet = new HashSet<String>() {
		{
			add(PROCESSING_CODE);
			add(TXN_AMT);
			add(CARD_ACCEPTOR_TERMINAL_ID);
			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(RES_CODE);
//			add(CVV_RESULT);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};

	/*
	 * PreAuth Request-pg
	 * MandateField ={1,2,3,4,5,6,7,9,10,11,12,19,20,21,22,29,33,34}
	 */
	private static final Set<String> pgPreAuthReqSet = new HashSet<String>() {
		{

//			add(POS_ENTRY_MODE);
			add(MSG_TYPE);
			add(PROCESSING_CODE);
			add(PAN);
			add(TXN_AMT);
//			add(EXPIRATION_DATE);
//			add(CVV2);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			add(PG_TXN_REF_NO);
//			add(ECOMMERCE_INDICATOR);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			//add(DS_VERSION);
//			add(BANK_NAME);
		}
	};

	/*
	 * PreAuth Response-pg
	 * PreAuth Response -pg
	 * MandateField ={2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34}
	 */
	private static final Set<String> pgPreAuthResSet = new HashSet<String>() {
		{
			add(PROCESSING_CODE);
			add(TXN_AMT);
			add(CARD_ACCEPTOR_TERMINAL_ID);
			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(RES_CODE);
//			//add(CVV_RESULT);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};

	/*
	 * online-offline refund Request-pg
	 * MandateField = {0,1,2,3,4,5,9,10,11,12,14,19,20,21,22,29,33,34,35}
	 */
	private static final Set<String> pgOnlineOfflineRefundReqSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
			add(MSG_TYPE);
			add(PROCESSING_CODE);
			add(PAN);
			add(TXN_AMT);
			add(CARD_ACCEPTOR_TERMINAL_ID);
			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			//add(LOCAL_TXN_TIME);
//			add(PG_TXN_REF_NO);
//			add(ECOMMERCE_INDICATOR);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			//add(DS_VERSION);
//			add(BANK_NAME);
//			add(CANCELATION_ID);
		}
	};

	/*
	 * MandateField = {0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,22,29,34}
	 */
	private static final Set<String> pgOnlineOfflineRefundResSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
			add(MSG_TYPE);
			add(PROCESSING_CODE);
			add(TXN_AMT);
			add(CARD_ACCEPTOR_TERMINAL_ID);
			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(AUTH_ID_RES);
//			add(RES_CODE);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};

	/*
	 * online-offline refund Response-pg/*
	 * capture Request-pg
	 * MandateField = {0,1,2,3,4,5,6,7,9,10,11,12,15,19,20,21,22,29,33,34}
	 */
	private static final Set<String> pgCaptureReqSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(PAN);
//			add(TXN_AMT);
//			add(EXPIRATION_DATE);
//			add(CVV2);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			add(RETRIEVAL_REF_NO);
//			add(PG_TXN_REF_NO);
//			add(ECOMMERCE_INDICATOR);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			//add(DS_VERSION);
//			add(BANK_NAME);
		}
	};

	/*
	 * Capture Response-pg Refund Response - pg
	 *  MandateField = {0,1,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
	 */
	private static final Set<String> pgCaptureResSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(AUTH_ID_RES);
//			add(RES_CODE);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};

	/*
	 * Reversal Request-pg
	 * MandateField = {0,1,2,3,4,5,9,10,11,15,19,21,29,34}
	 */
	private static final Set<String> pgReversalReqSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(PAN);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(RETRIEVAL_REF_NO);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};

	/*
	 * Reversal Response-pg
	 * MandateField = {0,2,3,5,9,10,11,13,14,15,16,17,19,21,29,34}
	 */
	private static final Set<String> pgReversalResSet = new HashSet<String>() {
		{
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(AUTH_ID_RES);
//			add(RES_CODE);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};


	/*
	 * SI Request-pg
	 * MandateField = {0,1,2,3,4,5,9,10,11,19,21,29,34}
	 */
	private static final Set<String> pgSIReqSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(PAN);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(PG_ID);
//			//add(DS_VERSION);
//			add(BANK_NAME);

		}
	};


	/*
	 * Sale Request-pg
	 * MandateField ={1,2,3,4,5,6,7,9,10,11,12,19,20,21,22,29,33,34}
	 */
	private static final Set<String> pgMotoSaleReqSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(PAN);
//			add(TXN_AMT);
//			add(CVV2);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			add(PG_TXN_REF_NO);
//			//add(ECOMMERCE_INDICATOR);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			//add(DS_VERSION);
//			add(BANK_NAME);

		}
	};

	/*
	 * Sale Response-pg
	 * PreAuth Response -pg
	 * MandateField ={2,3,5,9,10,11,13,14,15,17,18,19,21,22,29,34}
	 */
	private static final Set<String> pgMotoSaleResSet = new HashSet<String>() {
		{
//			add(PROCESSING_CODE);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(RES_CODE);
//			add(CVV_RESULT);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			add(BANK_NAME);
		}
	};


	/*
	 * Refund Request-pg
	 * MandateField = {0,1,2,3,4,5,9,10,11,12,15,19,20,21,22,29,34,35}
	 */
	private static final Set<String> pgRefundReqSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(PAN);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(AVV);
//			add(RETRIEVAL_REF_NO);
//			add(PG_TXN_REF_NO);
//			add(ECOMMERCE_INDICATOR);
//			add(ORIGINAL_TXN_PGID);
//			add(FRM_IP_ADDRESS);
//			add(PG_ID);
//			add(BANK_NAME);
//			add(CANCELATION_ID);

		}
	};

	/*
	 * Refund Request-pg
	 * MandateField = {0,1,2,3,5,9,10,11,13,14,15,16,19,21,29,34}
	 */
	private static final Set<String> pgRefundResSet = new HashSet<String>() {
		{
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(AUTH_ID_RES);
//			add(PG_TXN_REF_NO);
//			add(ORIGINAL_TXN_PGID);
//			add(PG_ID);
//			add(BANK_NAME);

		}
	};

	/*
	 * Pre-Auth Reversal Request-pg
	 * MandateField = {0,1,2,3,4,5,9,10,11,15,18,20,22,34}
	 */
	private static final Set<String> pgPreAuthReversalReqSet = new HashSet<String>() {
		{
//			add(PG_LENGTH);
//			add(POS_ENTRY_MODE);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(PAN);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(RETRIEVAL_REF_NO);
//			add(CVV_RESULT);
//			add(ECOMMERCE_INDICATOR);
//			add(FRM_IP_ADDRESS);
			//add(DS_VERSION);
		}
	};

	/*
	 * Pre-Auth Reversal refund Response-pg
	 * MandateField = {0,2,3,5,9,10,11,13,14,15,16,17,18,20,22,33}
	 */
	private static final Set<String> pgPreAuthReversalResSet = new HashSet<String>() {
		{
//			add(PG_LENGTH);
//			add(MSG_TYPE);
//			add(PROCESSING_CODE);
//			add(TXN_AMT);
//			add(CARD_ACCEPTOR_TERMINAL_ID);
//			add(CARD_ACCEPTOR_ID);
//			add(STAN);
//			add(LOCAL_TXN_DATE);
//			add(LOCAL_TXN_TIME);
//			add(RETRIEVAL_REF_NO);
//			add(AUTH_ID_RES);
//			add(RES_CODE);
//			add(CVV_RESULT);
//			add(ECOMMERCE_INDICATOR);
//			add(FRM_IP_ADDRESS);
			//add(DS_VERSION);
		}
	};

}
