package com.isg.mw.mtm.construct.amex;

import com.isg.mw.core.model.construct.amex.AmexMsgTypeHelper;
import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.mtm.config.DecryptService;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.commons.lang3.StringUtils;
import org.jpos.iso.ISOUtil;

import java.time.ZoneOffset;
import java.util.Base64;
import java.util.BitSet;
import java.util.Locale;

public class PgAmexMessageConstruction extends SwitchBaseMessageConstruction implements IMessageConstruction {
    DecryptService decryptionService = SpringContextBridge.services().getDecryptionService();

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */


    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */

    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        String processingCode = "";
        String msgTypeId = null;
        if (this.sourceMsgTypeId != null) {
        	processingCode = this.sourceMsgTypeId;
        }
        switch (processingCode) {
            case "01":
            case "02":
            case "03":
            case "05":
            case "11":
            case "18":
            case "19":
            case "27":
            case "28":
                msgTypeId = "004000";
                break;
            case "04":
            case "12":
            case "20":
            case "24":
                msgTypeId = "200000";
                break;
            case "21":
            case "30":
            case "31":
            case "32":
            case "33":
                msgTypeId = "004800";
                break;
            case "22":
                msgTypeId = "174800";
                break;
            case "23":
                msgTypeId = "200800";
                break;
            case "36":
            	msgTypeId = "334000";
                break;
            case "37":
            	msgTypeId = "334800";
                break;
            default:
                msgTypeId = "000000";
                break;
        }
        this.targetTmm.setProcessingCode(msgTypeId);
        this.baseMessage.set(fieldNo, msgTypeId);
    }
    
    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     * <p>
     * It is mandatory for all type of transactions
     */


    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */


    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */
    /* It is mandatory for all type of transactions */
    @Override
    public void setTransmissionTime(int fieldNo) {
        String formattedDate = null;
        formattedDate = MtmUtil.formatDate("MMddhhmmss", ZoneOffset.UTC);
        this.targetTmm.setTransmissionTime(formattedDate);
        this.baseMessage.set(fieldNo, formattedDate);

    }

    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */


    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */


    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */


    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    /* It is mandatory for all type of transactions */

    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    @Override
    public void setLocalTxnTime(int fieldNo) {
    	String currentYear = MtmUtil.formatDate("YY");
    	String localTxnDateTime = MtmUtil.formatDate("MMddhhmmss");
    	/*if(!StringUtils.isBlank(this.sourceTmm.getLocalTxnDate())
				&& !StringUtils.isBlank(this.sourceTmm.getLocalTxnTime())){
			localTxnDate = this.sourceTmm.getLocalTxnDate();
			localTxnTime = this.sourceTmm.getLocalTxnTime();
		}*/
    	this.targetTmm.setLocalTxnTime(currentYear + localTxnDateTime);
    	this.baseMessage.set(fieldNo, currentYear + localTxnDateTime);

    }

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */
    @Override
    public void setLocalTxnDate(int fieldNo) {
        String currentYear = MtmUtil.formatDate("YY");
        String localTxnDate = null;
        if(!StringUtils.isBlank(this.sourceTmm.getLocalTxnDate())){
            localTxnDate = this.sourceTmm.getLocalTxnDate().substring(0,2);
        }
        this.targetTmm.setLocalTxnDate(currentYear+localTxnDate);
        this.baseMessage.set(fieldNo, currentYear+localTxnDate);
    }


    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */
    @Override
    public void setExpirationDate(int fieldNo) {
        if(PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isMoRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isToRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isRefundAav(this.sourceMsgType, this.sourceMsgTypeId)){
            String expiryDate = this.sourceTmm.getOriginalTmm().getEncryptedExpirationDate();
            String decryptedData=  decryptionService.decrypt(expiryDate);
            this.targetTmm.setExpirationDate(decryptedData);
            this.baseMessage.set(fieldNo, decryptedData);
        }
        else{
            super.setExpirationDate(fieldNo);
        }
    }

    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */


    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */


    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */


    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */


    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */
    @Override
    public void setAquirerCountryCode(int fieldNo) {
        // this method implementation has been intentionally left blank
        String aquirerCountryCode = this.merchantData.getAcquirerCurrencyCode();

        this.targetTmm.setAquirerCountryCode(aquirerCountryCode);
        this.baseMessage.set(fieldNo, aquirerCountryCode);
    }

    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */


    /**
     * 22.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled
     * <p>
     * It is mandatory for all type of transactions
     */
    @Override
    public void setPosEntryMode(int fieldNo) {
        String posEntryMode = this.sourceTmm.getPosEntryMode();

        if (PgMsgTypeHelper.isAmexSI(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isAmexSIAav(this.sourceMsgType, this.sourceMsgTypeId)) {
            if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCofTxnOrigin()) && this.sourceTmm.getPgData().getCofTxnOrigin().equals("C")) {
                posEntryMode = "A60010A05130";
            } else {
                posEntryMode = "A60040A05130";
            }
        } else if (PgMsgTypeHelper.isRP(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isRPAav(this.sourceMsgType, this.sourceMsgTypeId)) {
            if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCofTxnOrigin()) && this.sourceTmm.getPgData().getCofTxnOrigin().equals("C")) {
            	if (!StringUtils.isBlank(this.sourceTmm.getPgData().getRecurringPaymentIndicator()) 
            			&& this.sourceTmm.getPgData().getRecurringPaymentIndicator().equals("R")) {
            		posEntryMode = "A60010A00130";
            	} else {
            		posEntryMode = "A60010A05130";
            	}
            } else {
            	if (!StringUtils.isBlank(this.sourceTmm.getPgData().getRecurringPaymentIndicator()) 
            			&& this.sourceTmm.getPgData().getRecurringPaymentIndicator().equals("R")) {
            		posEntryMode = "A60090A00130";
            	} else {
            		posEntryMode = "A60090A05130";
            	}
            }
        } else if (PgMsgTypeHelper.isMoSale(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isMoRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isMoReversal(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isMoSaleAav(this.sourceMsgType, this.sourceMsgTypeId)) {
            posEntryMode = "60002010014C";

        } else if (PgMsgTypeHelper.isToSale(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isToRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isToReversal(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isToSaleAav(this.sourceMsgType, this.sourceMsgTypeId)) {
            if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCofTxnOrigin()) && this.sourceTmm.getPgData().getCofTxnOrigin().equals("M")) {
                posEntryMode = "60003010014C";
            } else {
                posEntryMode = "60013010014C";
            }
        } else {
            if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isRefundAav(this.sourceMsgType, this.sourceMsgTypeId)) {
                posEntryMode = "1600S0105130";
            } else {
                posEntryMode = "160010105130";
            }
        }
        if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCid())) {
            char[] chars = posEntryMode.toCharArray();
            chars[6] = 'S';
            posEntryMode = String.valueOf(chars);
        }
        this.targetTmm.setPosEntryMode(posEntryMode);
        this.baseMessage.set(fieldNo, posEntryMode);
    }

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */


    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */
    @Override
    public void setNiiId(int fieldNo) {
        String functionCode = null;

        if (AmexMsgTypeHelper.isSignOnRequest(this.sourceMsgType)) {

            switch (this.sourceTmm.getTransactionCategory()) {
                case SIGNON:
                    functionCode = TmmConstants.AMEX_SIGNON_NW_INFO_CODE;
                    break;

                case SIGNOFF:
                    functionCode = TmmConstants.AMEX_SIGNOFF_NW_INFO_CODE;
                    break;

                case HEARTBEAT:
                    functionCode = TmmConstants.AMEX_ECHO_MESSAGE_NW_INFO_CODE;
                    break;

                case DYNAMIC_KEY_EXCHANGE:
                    functionCode = TmmConstants.AMEX_KEY_EXCHANGE_NW_INFO_CODE;
                    break;

                default:
                    functionCode = this.sourceTmm.getNiiId();
            }


        } else if (AmexMsgTypeHelper.isAuthResquest(this.targetMsgType, this.targetMsgTypeId)) {
            functionCode = "100";
        }

        this.targetTmm.setNiiId(functionCode);
        this.baseMessage.set(fieldNo, functionCode);

    }

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    @Override
    public void setPosConditionCode(int fieldNo) {

        String posConditioncode = "";
        if (AmexMsgTypeHelper.isSignOnRequest(this.sourceMsgType)) {
            posConditioncode = "8700";
        } else {
            posConditioncode = "1900";
        }
        this.targetTmm.setPosConditionCode(posConditioncode);
        this.baseMessage.set(fieldNo, posConditioncode);
    }


    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */
    @Override
    public void setPosCaptureCode(int fieldNo) {
        String posCaptureCode = this.merchantData.getMerchantType();
        this.targetTmm.setPosCaptureCode(posCaptureCode);
        this.baseMessage.set(fieldNo, posCaptureCode.getBytes());
    }

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */


    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */


    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */


    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */


    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */


    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    @Override
    public void setAquirerIdCode(int fieldNo) {
        String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
        this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
    }


    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */
    @Override
    public void setForwardingInstIdCode(int fieldNo) {
        String forwardingInstitutionId = this.sourceTmm.getForwardingInstIdCode();

        this.targetTmm.setForwardingInstIdCode(forwardingInstitutionId);
        this.baseMessage.set(fieldNo, forwardingInstitutionId);
    }

    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */

    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     *
     */


    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */


    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {
        if (PgMsgTypeHelper.isRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isRefundAav(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isMoRefund(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isToRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
        String rrn=this.sourceTmm.getRetrievalRefNo();
            this.targetTmm.setRetrievalRefNo(rrn);
            this.baseMessage.set(fieldNo, rrn);
        }else {
            super.setRetrievalRefNo(fieldNo);
        }

    }


    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */


    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     * <p>
     * It is mandatory for reversal and void only
     */


    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */


    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     */

    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     */

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     * <p>
     * Logic:<br>
     * Switch has to extract it from Merchant / POS Master table and send it to
     * Scheme. card acceptor name (1-22),<br>
     * space(23),<br>
     * city name (24-36),<br>
     * space(37),<br>
     * Country code (38-40)
     */
    @Override
    public void setCardAcceptorInfo(int fieldNo) {
        String payAggrName = "";
        if ("Y".equals(this.merchantData.getAggregatorFlag())) {
            payAggrName = (this.merchantData.getPaymentFacilitatorName() == null || this.merchantData.getPaymentFacilitatorName().isEmpty()) ? "=" : this.merchantData.getPaymentFacilitatorName() + "=";
        }

        String cardAcceptorInfo = payAggrName
                + StringUtils.substring(this.merchantData.getMerchantName(), 0, 30) + "\\"
                + StringUtils.substring(this.merchantData.getMerchantAddress(), 0, 30) + "\\"
                + StringUtils.substring(this.merchantData.getMerchantCity(), 0, 15) + "\\"
                + StringUtils.substring(StringUtils.rightPad(this.merchantData.getMerchantZipCode(), 10), 0, 10)
                + StringUtils.substring(StringUtils.rightPad(this.merchantData.getMerchantStateCode(), 3), 0, 3)
                + StringUtils.substring(StringUtils.rightPad(this.merchantData.getMerchantCountryCode(), 3), 0, 3) + "\\";

        this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
        this.baseMessage.set(fieldNo, cardAcceptorInfo);
    }

    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */


    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */


    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */


    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */
    @Override
    public void setNationalAd(int fieldNo) {
    	// if (PgMsgTypeHelper.isAav(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isPurchaseAav(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isRefundAav(this.sourceMsgType, this.sourceMsgTypeId)) {

    	String nationalAddData = "";

    	if(!StringUtils.isBlank(this.sourceTmm.getPgData().getDepartureDate())) {
    		String departureDate = (StringUtils.isBlank(this.sourceTmm.getPgData().getDepartureDate()) ? "" : this.sourceTmm.getPgData().getDepartureDate());
    		String airlinePassangerName = getDataWithLength(this.sourceTmm.getPgData().getAirlinePassangerName(), "APN") ;
    		String origin = (StringUtils.isBlank(this.sourceTmm.getPgData().getOrigin()) ? "" : this.sourceTmm.getPgData().getOrigin());
    		String destination = (StringUtils.isBlank(this.sourceTmm.getPgData().getDestination()) ? "" : this.sourceTmm.getPgData().getDestination());
    		String  noOfCities=StringUtils.leftPad(this.sourceTmm.getPgData().getNoOfCities(),2,"0");
    		String  routingCities=getDataWithLength(noOfCities+this.sourceTmm.getPgData().getRoutingCities(),"RTG");
    		String  noOfAirlineCarriers=StringUtils.leftPad(this.sourceTmm.getPgData().getNoOfAirlineCarriers(),2,"0");
    		String  airlineCarriers=getDataWithLength(noOfAirlineCarriers+this.sourceTmm.getPgData().getAirlineCarriers(),"ALC");
    		String  fareBasis=StringUtils.rightPad(this.sourceTmm.getPgData().getFareBasis(),24," ");
    		String  numberOfPassanger=StringUtils.leftPad(this.sourceTmm.getPgData().getNoOfPassangers(),3,"0");
    		String custIpDetails = (StringUtils.isBlank(this.sourceTmm.getPgData().getCustomerIp()) ? "" : this.sourceTmm.getPgData().getCustomerIp());
    		String custEmailDetails = getDataWithLength(this.sourceTmm.getPgData().getCustomerEmail(), "CE ");
    		nationalAddData = "AX" + "IAC" + departureDate + airlinePassangerName + origin + destination+routingCities+airlineCarriers+fareBasis+numberOfPassanger+custIpDetails+custEmailDetails;

    		this.targetTmm.setNationalAd(nationalAddData);
    		this.baseMessage.set(fieldNo, nationalAddData);

    	} else {
    		String custEmailDetails = getDataWithLength(this.sourceTmm.getPgData().getCustomerEmail(), "CE ");
    		String custHostNameDetails = getDataWithLength(this.sourceTmm.getPgData().getCustomerHostname(), "CH ");
    		String hbtIdDetails = getDataWithLength(this.sourceTmm.getPgData().getHttpBrowserType(), "HBT");
    		String stcIdDetails = getDataWithLength(this.sourceTmm.getPgData().getShipToCountry(), "STC");
    		String smIdDetails = getDataWithLength(this.sourceTmm.getPgData().getShippingMethod(), "SM ");
    		String mpsdDetails = getDataWithLength(this.sourceTmm.getPgData().getMerchantProductSku(), "MPS");
    		String custIpDetails = (StringUtils.isBlank(this.sourceTmm.getPgData().getCustomerIp()) ? "" : this.sourceTmm.getPgData().getCustomerIp());
    		String custAniDetails = (StringUtils.isBlank(this.sourceTmm.getPgData().getCustomerAni()) ? "" : this.sourceTmm.getPgData().getCustomerAni());
    		String custIIDigitsDetails = (StringUtils.isBlank(this.sourceTmm.getPgData().getCustomerIIDigits()) ? "" : this.sourceTmm.getPgData().getCustomerIIDigits());
    		if (custEmailDetails != "" || custHostNameDetails != "" || hbtIdDetails != "" || stcIdDetails != "" || smIdDetails != "" || mpsdDetails != "" || custIpDetails != "" || custIIDigitsDetails != "") {
    			nationalAddData = "AX" + "ITD" + custEmailDetails + custHostNameDetails + hbtIdDetails + stcIdDetails + smIdDetails + mpsdDetails + custIpDetails + custAniDetails + custIIDigitsDetails;
    			this.targetTmm.setNationalAd(nationalAddData);
    			this.baseMessage.set(fieldNo, nationalAddData);
    		}
    	}
    	// }
    }

    private String getDataWithLength(String data, String prefix) {
        return (StringUtils.isBlank(data) ? "" : prefix + StringUtils.leftPad(String.valueOf(data.length()), 2, "0") + data);
    }

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */
    /* It is mandatory for all type of transactions */

    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */


    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */


    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */


    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */


    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */
    @Override
    public void setSecurityControlInfo(int fieldNo) {
        // this method implementation has been intentionally left blank
        if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCid())) {
            String securityControlInfo = this.sourceTmm.getPgData().getCid();
            this.targetTmm.setSecurityControlInfo(securityControlInfo);
            this.baseMessage.set(fieldNo, securityControlInfo);
        } else {
            super.setSecurityControlInfo(fieldNo);
        }
    }

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */


    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */
    @Override
    public void setIccData(int fieldNo) {


    }

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */


    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */


    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */


    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     */
    @Override
    public void setTerminalData(int fieldNo) {
        String ax = "AX";
        String aad = "AAD";
        boolean isAggregator = "Y".equals(this.merchantData.getAggregatorFlag());
        boolean isCit = "C".equals(this.sourceTmm.getPgData().getCofTxnOrigin());
        boolean isMit = "M".equals(this.sourceTmm.getPgData().getCofTxnOrigin());
        String txnId = !StringUtils.isBlank(this.sourceTmm.getActionDate()) ? this.sourceTmm.getActionDate() : "";
        if (isAggregator) {
            String sellerId = StringUtils.leftPad(this.merchantData.getIndependentSaleOrganizationId(), 20, "0");
            String sellerEmailId = !StringUtils.isBlank(this.merchantData.getMerchantEmail())? this.merchantData.getMerchantEmail():"";
            String sellerPhoneNo = !StringUtils.isBlank(this.merchantData.getMerchantPhoneNo())?StringUtils.rightPad(this.merchantData.getMerchantPhoneNo(), 20, " ") : StringUtils.rightPad("", 20, " ");
            String bitmap = isMit ? "72000000" : "70000000";
            String reservedPrivate = ax
                    + aad
                    + bitmap
                    + sellerId
                    + sellerEmailId.length()
                    + sellerEmailId
                    + sellerPhoneNo;

            reservedPrivate += isMit ? txnId : "";

            byte[] axes = ISOUtil.asciiToEbcdic(ax);
            byte[] aads = ISOUtil.asciiToEbcdic(aad);
            byte[] bitmapBytes = MtmUtil.toBytesAsIs(bitmap);
            byte[] sellerIdBytes = ISOUtil.asciiToEbcdic(sellerId);
            byte[] lengthBytes = ISOUtil.asciiToEbcdic(StringUtils.leftPad("" + sellerEmailId.length(), 2, '0').getBytes());
            byte[] sellerEmailBytes = ISOUtil.asciiToEbcdic(sellerEmailId);
            byte[] sellerPhoneNoBytes = ISOUtil.asciiToEbcdic(sellerPhoneNo);
            byte[] txnIdBytes = isMit ? ISOUtil.asciiToEbcdic(txnId) : new byte[0];

            int totalLength = axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length
                    + lengthBytes.length + sellerEmailBytes.length + sellerPhoneNoBytes.length + txnIdBytes.length;

            byte[] finalMsgBytes = new byte[totalLength];

            System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
            System.arraycopy(aads, 0, finalMsgBytes, axes.length, aads.length);
            System.arraycopy(bitmapBytes, 0, finalMsgBytes, axes.length + aads.length, bitmapBytes.length);
            System.arraycopy(sellerIdBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length, sellerIdBytes.length);
            System.arraycopy(lengthBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length, lengthBytes.length);
            System.arraycopy(sellerEmailBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length + lengthBytes.length, sellerEmailBytes.length);
            System.arraycopy(sellerPhoneNoBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length + lengthBytes.length + sellerEmailBytes.length, sellerPhoneNoBytes.length);
            if (isMit) {
                System.arraycopy(txnIdBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length + sellerIdBytes.length + lengthBytes.length + sellerEmailBytes.length + sellerPhoneNoBytes.length, txnIdBytes.length);
            }

            this.targetTmm.setTerminalData(reservedPrivate);
            this.baseMessage.set(fieldNo, finalMsgBytes);
        } else if (isMit) {
            String reservedPrivate = ax
                    + aad
                    + "02000000"
                    + txnId;
            byte[] axes = ISOUtil.asciiToEbcdic(ax);
            byte[] aads = ISOUtil.asciiToEbcdic(aad);
            byte[] bitmapBytes = MtmUtil.toBytesAsIs("02000000");
            byte[] transactionIdBytes = ISOUtil.asciiToEbcdic(txnId);

            int totalLength = axes.length + aads.length + bitmapBytes.length + transactionIdBytes.length;

            byte[] finalMsgBytes = new byte[totalLength];

            System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
            System.arraycopy(aads, 0, finalMsgBytes, axes.length, aads.length);
            System.arraycopy(bitmapBytes, 0, finalMsgBytes, axes.length + aads.length, bitmapBytes.length);
            System.arraycopy(transactionIdBytes, 0, finalMsgBytes, axes.length + aads.length + bitmapBytes.length, transactionIdBytes.length);

            this.targetTmm.setTerminalData(reservedPrivate);
            this.baseMessage.set(fieldNo, finalMsgBytes);
        }
    }
    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     * <p>
     * Other transactions: 0000000000800356POSTAL<br>
     * PreAuth: 0000004000800356POSTAL<br>
     * MOTO: 2032102000800356POSTAL<br>
     * POSTAL means-- 6 digit postal code of merchant.<br>
     * <p>
     * Note: It is mandatory for all type of transactions
     */
    @Override
    public void setCiad(int fieldNo) {
        if (!PgMsgTypeHelper.isMoSale(this.sourceMsgType, this.sourceMsgTypeId)
                && !PgMsgTypeHelper.isToSale(this.sourceMsgType, this.sourceMsgTypeId)
                && !PgMsgTypeHelper.isMoRefund(this.sourceMsgType, this.sourceMsgTypeId)
                && !PgMsgTypeHelper.isToRefund(this.sourceMsgType, this.sourceMsgTypeId)
                && !PgMsgTypeHelper.isMoSaleAav(this.sourceMsgType, this.sourceMsgTypeId)
                && !PgMsgTypeHelper.isToSaleAav(this.sourceMsgType, this.sourceMsgTypeId)) {
            String encodedAevv="";
            String decodedStr="";
            String xid="";
            String sf616="";
            String sf617="";
            String sf614="";
            String ecomIndicator = this.sourceTmm.getPgData().getEcommerceIndicator();
            boolean isEcom = StringUtils.isBlank(ecomIndicator);
            if(!isEcom && !ecomIndicator.equals("07")) {
                 encodedAevv = StringUtils.substring(this.sourceTmm.getPgData().getAvv(), 0, 28) ;
                byte[] decodedAevvBytes = Base64.getDecoder().decode(encodedAevv) ;
                decodedStr = ISOUtil.byte2hex(decodedAevvBytes) ;

                sf614 = decodedAevvBytes.length == 0 ? "" : "AEVV" ;

//                if (this.sourceTmm.getPgData().getAvv().length() > 28) {
//                    xid = StringUtils.substring(this.sourceTmm.getPgData().getAvv(), 28, this.sourceTmm.getPgData().getAvv().length());
//                    sf616 =  xid.length() == 0  ? "" :"XID";
//                }
                if (!StringUtils.isBlank(this.sourceTmm.getPgData().getDsVersion()) && !StringUtils.isBlank(this.sourceTmm.getPgData().getDsTransactionId())) {
                   String dsVersion=StringUtils.remove(this.sourceTmm.getPgData().getDsVersion(),'.');

           //         String dsVersion="0"+StringUtils.replaceAll(this.sourceTmm.getPgData().getDsVersion(),".","0")+"00";

                    String updatedDsVersion="";
                    char[] arr = dsVersion.toCharArray();
                    for(int i=0;i<dsVersion.length();i++){
                        String value="0";
                        updatedDsVersion=updatedDsVersion+ value +arr[i];

                    }
                    updatedDsVersion=updatedDsVersion+"00";

                    String dsTransactionId=StringUtils.remove(this.sourceTmm.getPgData().getDsTransactionId(),'-');
                    xid = updatedDsVersion + dsTransactionId;
                    sf616 =  xid.length() == 0  ? "" :"XID";
                }
            }
            String sf613 = isEcom ? "" : ecomIndicator;

            byte[] axes = ISOUtil.asciiToEbcdic("AX");
            byte[] asks = ISOUtil.asciiToEbcdic("ASK");
            byte[] sf613Bytes = ISOUtil.asciiToEbcdic(sf613);
            byte[] sf614Bytes = ISOUtil.asciiToEbcdic(sf614);
            byte[] aevvBytes = MtmUtil.toBytesAsIs(decodedStr);
            byte[] sf616Bytes = ISOUtil.asciiToEbcdic(sf616);
            byte[] xidBytes = ISOUtil.asciiToEbcdic(xid);

            int totalLength = axes.length + asks.length + sf613Bytes.length + sf614Bytes.length + aevvBytes.length+ sf616Bytes.length + xidBytes.length;

            byte[] finalMsgBytes = new byte[totalLength];

            System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
            System.arraycopy(asks, 0, finalMsgBytes, axes.length, asks.length);
            System.arraycopy(sf613Bytes, 0, finalMsgBytes, axes.length + asks.length, sf613Bytes.length);
            System.arraycopy(sf614Bytes, 0, finalMsgBytes, axes.length + asks.length + sf613Bytes.length, sf614Bytes.length);
            System.arraycopy(aevvBytes, 0, finalMsgBytes, axes.length + asks.length + sf613Bytes.length + sf614Bytes.length, aevvBytes.length);
            System.arraycopy(sf616Bytes, 0, finalMsgBytes, axes.length + asks.length + sf613Bytes.length + sf614Bytes.length+ aevvBytes.length,sf616Bytes.length);
            System.arraycopy(xidBytes, 0, finalMsgBytes, axes.length + asks.length + sf613Bytes.length + sf614Bytes.length+ aevvBytes.length + sf616Bytes.length, xidBytes.length);
            this.baseMessage.set(fieldNo, finalMsgBytes);
            this.targetTmm.setCiad("AX" + "ASK" + sf613 + sf614 + encodedAevv +sf616 + xid) ;
        }
    }


    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */


    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     */
    @Override
    public void setAtmPinOffsetData(int fieldNo) {
        if (PgMsgTypeHelper.isAav(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isPurchaseAav(this.sourceMsgType, this.sourceMsgTypeId) 
        		|| PgMsgTypeHelper.isRefundAav(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isAmexSIAav(this.sourceMsgType, this.sourceMsgTypeId) 
        		|| PgMsgTypeHelper.isRPAav(this.sourceMsgType, this.sourceMsgTypeId)|| PgMsgTypeHelper.isMoSaleAav(this.sourceMsgType, this.sourceMsgTypeId) 
        		|| PgMsgTypeHelper.isToSaleAav(this.sourceMsgType, this.sourceMsgTypeId) ||  PgMsgTypeHelper.isPreAuthAav(this.sourceMsgType, this.sourceMsgTypeId)
        		|| PgMsgTypeHelper.isZvavPurchaseAav(this.sourceMsgType, this.sourceMsgTypeId)) {
            String privateUseData = "";
            String custEmail = this.sourceTmm.getPgData().getCustomerEmail();
            String aavCardMemBillPhNo = this.sourceTmm.getPgData().getAavCardMemberBillingPhoneNumber();
            String reqIdentifier = (custEmail != null || aavCardMemBillPhNo != null) ? "AE" : "AD";
            String aavShipToPostCode = this.sourceTmm.getPgData().getAavShipToPostalCode();
            String aavShipToAdd = this.sourceTmm.getPgData().getAavShipToAddress();
            String aavShipToCountryCode = this.sourceTmm.getPgData().getAavShipToCountryCode();
            String aavShipToLastName = this.sourceTmm.getPgData().getAavShipToLastName();
            String aavShipToFirstName = this.sourceTmm.getPgData().getAavShipToFirstName();
            String aavCardMemBillFirstName = this.sourceTmm.getPgData().getAavCardMemberBillingFirstName();
            String aavCardMemBillLastName = this.sourceTmm.getPgData().getAavCardMemberBillingLastName();
            String aavCardMemBillPostCode = this.sourceTmm.getPgData().getAavCardMemberBillingPostalCode();
            String aavCardMemBillAdd = this.sourceTmm.getPgData().getAavCardMemberBillingAddress();

            if (aavCardMemBillPhNo != null || aavShipToPostCode != null || aavShipToAdd != null || aavShipToFirstName != null || aavShipToLastName != null || aavShipToCountryCode != null) {
                privateUseData = "AX" + reqIdentifier + get205FormatData(aavCardMemBillPostCode, aavCardMemBillAdd, aavCardMemBillFirstName, aavCardMemBillLastName, aavCardMemBillPhNo, aavShipToPostCode, aavShipToAdd, aavShipToFirstName, aavShipToLastName, this.sourceTmm.getPgData().getAavShipToPhoneNumber(), aavShipToCountryCode);
            } else if (aavCardMemBillFirstName != null || aavCardMemBillLastName != null) {
            	privateUseData = "AX" + reqIdentifier + get78FormatData(aavCardMemBillPostCode, aavCardMemBillAdd, aavCardMemBillFirstName, aavCardMemBillLastName);
            } else {
                privateUseData = "AX" + reqIdentifier + get33FormatData(aavCardMemBillPostCode, aavCardMemBillAdd);
            }

            this.targetTmm.setAtmPinOffsetData(privateUseData);
            this.baseMessage.set(fieldNo, privateUseData);
        } else {
            super.setAtmPinOffsetData(fieldNo);
        }
    }

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */


    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */


    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */


    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */


    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */


    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     *
     */


    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */

    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */


    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */


    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */


    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */


    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */


    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */


    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */


    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */


    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */


    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */


    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */


    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */


    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */


    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */


    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */


    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */


    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */


    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */


    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */


    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */


    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */


    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */


    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */


    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */


    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */

    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */

    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */


    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */


    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */


    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */


    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */


    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */


    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */


    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */


    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */


    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    @Override
    public void setReserved113(int fieldNo) {
    	BitSet bitSet113 = new BitSet();
    	if (!StringUtils.isBlank(this.sourceTmm.getPgData().getCofTxnOrigin())) {
    		
    		String authOutageIndicator = "";
    		if (!StringUtils.isBlank(this.sourceTmm.getPgData().getAuthenticationOutageIndicator())) {
    			bitSet113.set(4);
    			authOutageIndicator = this.sourceTmm.getPgData().getAuthenticationOutageIndicator();
    		}
    		String bitmap =  MtmUtil.bitset2Hex(bitSet113, 8);
    		String reservedData = "AX" + "AED" + ("C".equals(this.sourceTmm.getPgData().getCofTxnOrigin()) ? "0" : "1") + bitmap;

    		byte[] axes = ISOUtil.asciiToEbcdic("AX");
    		byte[] aeds = ISOUtil.asciiToEbcdic("AED");
    		String cofTxnOrigin = "C".equals(this.sourceTmm.getPgData().getCofTxnOrigin()) ? "0" : "1";
    		byte[] cofBytes = ISOUtil.asciiToEbcdic(cofTxnOrigin);
    		byte[] bitMapBytes = MtmUtil.toBytesAsIs(bitmap);
    		byte[] aoiBytes = null;
    		int totalLength = 0;
    		if (!StringUtils.isBlank(authOutageIndicator)) {
    			aoiBytes = ISOUtil.asciiToEbcdic(authOutageIndicator);
    			totalLength = axes.length + aeds.length + cofBytes.length + bitMapBytes.length + aoiBytes.length;
    		} else {
    			totalLength = axes.length + aeds.length + cofBytes.length + bitMapBytes.length;
    		}
    		
    		

    		byte[] finalMsgBytes = new byte[totalLength];

    		System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
    		System.arraycopy(aeds, 0, finalMsgBytes, axes.length, aeds.length);
    		System.arraycopy(cofBytes, 0, finalMsgBytes, axes.length + aeds.length, cofBytes.length);
    		System.arraycopy(bitMapBytes, 0, finalMsgBytes, axes.length + aeds.length + cofBytes.length, bitMapBytes.length);
    		if (!StringUtils.isBlank(authOutageIndicator)) {
    			System.arraycopy(aoiBytes, 0, finalMsgBytes, axes.length + aeds.length + cofBytes.length + bitMapBytes.length, aoiBytes.length);
    		}

    		this.targetTmm.setReserved113(reservedData);
    		this.baseMessage.set(fieldNo, finalMsgBytes);
    	}
    }

    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */


    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */


    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */


    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */


    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */
    @Override
    public void setReserved123(int fieldNo) {
         if (PgMsgTypeHelper.isAmexSI(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isAmexSIAav(this.sourceMsgType, this.sourceMsgTypeId)
        		 || PgMsgTypeHelper.isRP(this.sourceMsgType, this.sourceMsgTypeId) || PgMsgTypeHelper.isRPAav(this.sourceMsgType, this.sourceMsgTypeId)) {
        	 BitSet bitSet123 = new BitSet();
             bitSet123.set(0);
             String bitmap =  MtmUtil.bitset2Hex(bitSet123, 8);
        	 String reservedData = "";
             BitSet bitSet = new BitSet();
             String txnDesc = this.sourceTmm.getPgData().getField41();
             if (txnDesc != null) {
            	 StringBuilder field123 = new StringBuilder();
                 //Bit 1
            	 bitSet.set(0);
            	 field123.append(StringUtils.leftPad(txnDesc.substring(1, 3),2,'0'));
                 //Bit 2
            	 bitSet.set(1);
            	 String subFiled2 = txnDesc.substring(0, 1);
            	 char padding = '0';
            	 if ("Z".equalsIgnoreCase(subFiled2)) {
            		 padding = 'Z';
            	 } else if ("9".equalsIgnoreCase(subFiled2)) {
            		 padding = '9';
            	 }
            	 field123.append(StringUtils.leftPad(subFiled2,3,padding));
                 //Bit 3
            	 bitSet.set(2);
            	 field123.append(StringUtils.leftPad(txnDesc.substring(23, 25),2,'0'));
                 //Bit 4
            	 bitSet.set(3);
            	 field123.append(StringUtils.leftPad(txnDesc.substring(25, 26),2,'0'));
                 //Bit 5
            	 bitSet.set(4);
                 String subField84Value = (StringUtils.leftPad(txnDesc.substring(13, 23),12,'0'));
                 field123.append(subField84Value);
                 //Bit 6
                 bitSet.set(5);
                 String subField85Value =(StringUtils.leftPad(txnDesc.substring(4, 13),12,'0'));
                 field123.append(subField85Value);
                 //Bit 7
                 bitSet.set(6);
                 field123.append(StringUtils.leftPad(txnDesc.substring(3, 4),1,'0'));
                 
                 reservedData = field123.toString();
             }
             String bitMap123 = MtmUtil.bitset2Hex(bitSet, 8);

             byte[] axes = ISOUtil.asciiToEbcdic("AX");
             byte[] atds = ISOUtil.asciiToEbcdic("ATD");
             byte[] bitMapBytes = MtmUtil.toBytesAsIs(bitmap);
             byte[] bitMap123Bytes = MtmUtil.toBytesAsIs(bitMap123);
             String reservedDataVli = StringUtils.leftPad(String.valueOf((bitMap123.length()/2)+reservedData.length()), 3, '0');
             byte[] reservedDataVliBytesAssIs= ISOUtil.asciiToEbcdic(reservedDataVli);
             byte[] reservedDataBytes = ISOUtil.asciiToEbcdic(reservedData);
             
             int totalLength = axes.length + atds.length + bitMapBytes.length + reservedDataVliBytesAssIs.length +  bitMap123Bytes.length + reservedDataBytes.length ;

             byte[] finalMsgBytes = new byte[totalLength];

             System.arraycopy(axes, 0, finalMsgBytes, 0, axes.length);
             System.arraycopy(atds, 0, finalMsgBytes, axes.length, atds.length);
             System.arraycopy(bitMapBytes, 0, finalMsgBytes, axes.length + atds.length, bitMapBytes.length);
             System.arraycopy(reservedDataVliBytesAssIs, 0, finalMsgBytes, axes.length + atds.length + bitMapBytes.length, reservedDataVliBytesAssIs.length);
             System.arraycopy(bitMap123Bytes, 0, finalMsgBytes, axes.length + atds.length + bitMapBytes.length + reservedDataVliBytesAssIs.length, bitMap123Bytes.length);
             System.arraycopy(reservedDataBytes, 0, finalMsgBytes, axes.length + atds.length + bitMapBytes.length + reservedDataVliBytesAssIs.length + bitMap123Bytes.length, reservedDataBytes.length);
             

             this.targetTmm.setReserved123(reservedData);
             this.baseMessage.set(fieldNo, finalMsgBytes);
         }
    }

    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */


    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */


    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */


    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */

    /**
     * 128.<br>
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */


    private String get33FormatData(String aavCardMemberBillingPostalCode, String aavCardMemberBillingAddress) {
        String data = "";
        data = (StringUtils.isBlank(aavCardMemberBillingPostalCode) ? StringUtils.rightPad("", 9, " ") : StringUtils.rightPad(aavCardMemberBillingPostalCode, 9, " ")) + (StringUtils.isBlank(aavCardMemberBillingAddress) ? StringUtils.rightPad("", 20, " ") : StringUtils.rightPad(aavCardMemberBillingAddress.toUpperCase(Locale.ROOT), 20, " "));

        return data;
    }

    private String get78FormatData(String aavCardMemberBillingPostalCode, String aavCardMemberBillingAddress, String aavCardMemberBillingFirstName, String aavCardMemberBillingLastName) {
        String data = "";
        data = get33FormatData(aavCardMemberBillingPostalCode, aavCardMemberBillingAddress) + (StringUtils.isBlank(aavCardMemberBillingFirstName) ? StringUtils.rightPad("", 15, " ") : StringUtils.rightPad(aavCardMemberBillingFirstName, 15, " ")) + (StringUtils.isBlank(aavCardMemberBillingLastName) ? StringUtils.rightPad("", 30, " ") : StringUtils.rightPad(aavCardMemberBillingLastName, 30, " "));

        return data;
    }

    private String get205FormatData(String aavCardMemberBillingPostalCode, String aavCardMemberBillingAddress, String aavCardMemberBillingFirstName, String aavCardMemberBillingLastName, String aavCardMemberBillingPhoneNumber, String aavShipToPostalCode, String aavShipToAddress, String aavShipToFirstName, String aavShipToLastName, String aavShipToPhoneNumber, String aavShipToCountryCode) {
        String data = "";

        data = get78FormatData(aavCardMemberBillingPostalCode, aavCardMemberBillingAddress, aavCardMemberBillingFirstName, aavCardMemberBillingLastName) + (StringUtils.isBlank(aavCardMemberBillingPhoneNumber) ? StringUtils.rightPad("", 10, " ") : StringUtils.rightPad(aavCardMemberBillingPhoneNumber, 10, " ")) + (StringUtils.isBlank(aavShipToPostalCode) ? StringUtils.rightPad("", 9, " ") : StringUtils.rightPad(aavShipToPostalCode, 9, " ")) +
                (StringUtils.isBlank(aavShipToAddress) ? StringUtils.rightPad("", 50, " ") : StringUtils.rightPad(aavShipToAddress, 50, " ")) + (StringUtils.isBlank(aavShipToFirstName) ? StringUtils.rightPad("", 15, " ") : StringUtils.rightPad(aavShipToFirstName, 15, " ")) + (StringUtils.isBlank(aavShipToLastName) ? StringUtils.rightPad("", 30, " ") : StringUtils.rightPad(aavShipToLastName, 30, " ")) + (StringUtils.isBlank(aavShipToPhoneNumber) ? StringUtils.rightPad("", 10, " ") : StringUtils.rightPad(aavShipToPhoneNumber, 10, " ")) + (StringUtils.isBlank(aavShipToCountryCode) ? StringUtils.rightPad("", 3, " ") : StringUtils.rightPad(aavShipToCountryCode, 3, " "));

        return data;
    }

}
