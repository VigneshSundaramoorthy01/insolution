package com.isg.mw.mtm.exception;

public class MessageConstructionPanMismatchException extends MessageConstructionException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageConstructionPanMismatchException(String expMsg) {
		super(expMsg);
	}

	public MessageConstructionPanMismatchException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}
