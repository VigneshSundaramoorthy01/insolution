package com.isg.mw.mtm.rawlog.endpoint;

import com.isg.mw.core.model.tlm.TransactionMessageModel;

import javax.xml.bind.DatatypeConverter;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;

public class Pos {

    private Pos() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     * <p>It is mandatory for all type of transactions</p>
     */
    public static String getTerminalData(Object isoObj, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm) {
        String value = null;
        if (isBatchSettlementRequest(tgtTmm.getMsgType(), tgtTmm.getProcessingCode()) ||
                isPosVoidReq(tgtTmm.getMsgType(), tgtTmm.getProcessingCode())) {
            String terminalData = isoObj.toString();
            value = new String(DatatypeConverter.parseHexBinary(terminalData));
        }

        return value;
    }

    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     */
    public static String getCiad(Object isoObj, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm) {
        String value = null;

        if (isBatchSettlementResponse(tgtTmm.getMsgType(), tgtTmm.getProcessingCode())) {
            value = tgtTmm.getCiad();
        } else if (isoObj != null && tgtTmm.getCiad() != null) {
            value = "PRESENT";
        }

        return value;
    }

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */

    public static String getPostalCode(Object isoObj, TransactionMessageModel tgtTmm, TransactionMessageModel srcTmm) {

        String postalCode = isoObj.toString();
        String value = null;
        if (postalCode != null && !isSignOnResponse(tgtTmm.getMsgType()) && !isBatchSettlementRequest(tgtTmm.getMsgType(), tgtTmm.getProcessingCode())) {
            value = new String(DatatypeConverter.parseHexBinary(postalCode));
        }
        return value;
    }
}
