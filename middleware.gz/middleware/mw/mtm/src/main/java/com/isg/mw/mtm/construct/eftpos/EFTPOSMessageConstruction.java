package com.isg.mw.mtm.construct.eftpos;

import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.core.model.eftpos.EFTPOSKeyModel;
import com.isg.mw.core.model.eftpos.KeyModel;
import com.isg.mw.core.model.eftpos.TempKeyModel;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.jpos.iso.ISOUtil;
import org.jpos.tlv.TLVList;
import org.jpos.tlv.TLVMsg;

import java.time.ZoneId;
import java.util.List;
import java.util.Map;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;

public  class EFTPOSMessageConstruction extends SwitchBaseMessageConstruction implements IMessageConstruction  {

    private static final Logger logger = LogManager.getLogger(EFTPOSMessageConstruction.class);

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */

    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */
    @Override
    public void setPan(int fieldNo) {
        if(MessageConstructionHelper.isManualTxn(this.sourceTmm.getPosEntryMode().substring(0,2))){
            String pan = this.sourceTmm.getPan();
            this.targetTmm.setPan(pan);
            this.apiTargetTmm.setPan(pan);
            this.baseMessage.set(fieldNo, pan);
        }
    }

    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        String processingCode = this.sourceMsgTypeId;
        if("20".equals(processingCode.substring(0,2))) { // for refund transaction
            String accountType = processingCode.substring(2,4);
            StringBuilder stringBuilder = new StringBuilder(processingCode);
            stringBuilder.replace(2,4,"00");
            stringBuilder.replace(4,6,accountType);
            processingCode = stringBuilder.toString();
        }else{
            String txnAmt = this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0";
            String cashTxnAmt = this.sourceTmm.getAdditionalAmounts() != null ? this.sourceTmm.getAdditionalAmounts() : "0";
            if (txnAmt.equals(cashTxnAmt)) {
                processingCode = processingCode.replace(processingCode.substring(0, 2), "01");
            }
        }
        this.targetTmm.setProcessingCode(processingCode);
        this.baseMessage.set(fieldNo, processingCode);
    }

    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     * <p>
     * It is mandatory for all type of transactions
     */
    @Override
    public void setTxnAmt(int fieldNo) {
        String txnAmt = this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0";
        this.targetTmm.setTxnAmt(txnAmt);
        this.apiTargetTmm.setTxnAmt(txnAmt);
        this.baseMessage.set(fieldNo, txnAmt);
    }


    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */


    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */

    @Override
    public void setTransmissionTime(int fieldNo) {
        String transmissionTime = null;
        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSigOn(this.sourceTmm) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            transmissionTime = this.sourceTmm.getTransmissionTime();
        } else {
            transmissionTime = MtmUtil.formatDate("MMddHHmmss", ZoneId.of("Australia/Sydney"));
        }

        this.targetTmm.setTransmissionTime(transmissionTime);
        this.baseMessage.set(fieldNo, transmissionTime);
    }


    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */


    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */


    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */


    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    /* It is mandatory for all type of transactions */

    @Override
    public void setStan(int fieldNo) {
        String stan = null;
        String mti = this.targetMsgType;
        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSigOn(this.sourceTmm) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            stan = this.sourceTmm.getStan();
            this.targetTmm.setStan(stan);
            this.baseMessage.set(fieldNo, stan);
        } else if ("0221".equals(mti)) {
            this.targetTmm.setStan(originalTmm.getSchemeStan());
            this.baseMessage.set(fieldNo, originalTmm.getSchemeStan());
        } else {
            super.setStan(fieldNo);
            this.targetTmm.setStan(this.targetTmm.getStan());
            this.targetTmm.setSchemeStan(this.targetTmm.getStan());
        }
    }


    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    @Override
    public void setLocalTxnTime(int fieldNo) {
        String localTxnTime = null;
        if(!(StringUtils.isBlank(this.sourceTmm.getLocalTxnTime()))){
            localTxnTime=this.sourceTmm.getLocalTxnTime();
        }else {
            localTxnTime =   MtmUtil.formatDate("HHmmss",ZoneId.of("Australia/Sydney"));
        }
        this.targetTmm.setLocalTxnTime( localTxnTime);
        this.baseMessage.set(fieldNo, localTxnTime);
    }

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */
    @Override
    public void setLocalTxnDate(int fieldNo) {
        String localTxnDate = null;

        if(!(StringUtils.isBlank(this.sourceTmm.getLocalTxnDate()))){
            localTxnDate = this.sourceTmm.getLocalTxnDate();
        }else{
            localTxnDate =   MtmUtil.formatDate("MMdd",ZoneId.of("Australia/Sydney"));
        }
        this.targetTmm.setLocalTxnDate(localTxnDate);
        this.baseMessage.set(fieldNo, localTxnDate);
    }


    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */
    @Override
    public void setExpirationDate(int fieldNo) {
        if(MessageConstructionHelper.isManualTxn(this.sourceTmm.getPosEntryMode().substring(0,2))) {
            String expiryDate = this.sourceTmm.getExpirationDate();
            this.targetTmm.setExpirationDate(expiryDate);
            this.baseMessage.set(fieldNo, expiryDate);
        }
    }
    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */
    @Override
    public void setSettlementDate(int fieldNo) {
        String settleDate = null;
        if(!(StringUtils.isBlank(this.sourceTmm.getSettlementDate()))){
            settleDate = this.sourceTmm.getSettlementDate();
        }else{
            settleDate =   MtmUtil.formatDate("MMdd", ZoneId.of("Australia/Sydney"));
        }

        // For Phase 2
          /*  String settleDate = null;
            Date cronJobTime = null;

            try {
                CronExpression cronExpression = new CronExpression(eftposSettlementTime);
                cronJobTime = cronExpression.getNextValidTimeAfter(new Date());
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            if(!StringUtils.isBlank(this.sourceTmm.getSettlementDate())){
                settleDate = this.sourceTmm.getSettlementDate();
            }else if(new Date().before(cronJobTime) && new Date().getDate() == cronJobTime.getDate()){
                settleDate =   MtmUtil.formatDate("MMdd", ZoneId.of("Australia/Sydney"));
            }else {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMdd");
                OffsetDateTime now = OffsetDateTime.now(ZoneId.of("Australia/Sydney"));
                settleDate =  dtf.format(now.plusDays(1));
            }
        */

        this.targetTmm.setSettlementDate(settleDate);
        this.baseMessage.set(fieldNo, settleDate);
    }

    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */


    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */


    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */
    @Override
    public void setMerchantType(int fieldNo) {
        String merchantType = this.merchantData.getMerchantType();
        this.targetTmm.setMerchantType(merchantType);
        this.baseMessage.set(fieldNo, merchantType);
    }

    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */


    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */

    /**
     * 22. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled It is mandatory for all type of transactions
     */
    @Override
    public void setPosEntryMode(int fieldNo) {
        String posEntryMode = this.sourceTmm.getPosEntryMode();
        if(MessageConstructionHelper.isManualTxn(this.sourceTmm.getPosEntryMode().substring(0,2))){
            posEntryMode="012";
        } else if(MessageConstructionHelper.isMagstripeWithPin(this.sourceTmm.getPosEntryMode().substring(0,2),this.sourceTmm.getPin())
                || "80".equals(this.sourceTmm.getPosEntryMode().substring(0,2))){
            posEntryMode="021";
        }else if("91".equals(this.sourceTmm.getPosEntryMode().substring(0,2))){
            posEntryMode="071";
        }

        this.targetTmm.setPosEntryMode(posEntryMode);
        this.baseMessage.set(fieldNo, posEntryMode);
    }

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */
    @Override
    public void setCardSeqNo(int fieldNo) {
        String iccData = this.sourceTmm.getIccData();
        if( null != iccData && !StringUtils.isBlank(iccData)) {
            TLVList list = new TLVList();
            list.unpack(ISOUtil.hex2byte(iccData));
            List<TLVMsg> tags = list.getTags();
            tags.forEach(tlvField -> {
                if (Integer.toHexString(tlvField.getTag()).equals("5f34")) {
                    String panSeqNo = ISOUtil.hexString(tlvField.getValue());
                    this.targetTmm.setCardSeqNo(StringUtils.leftPad(panSeqNo, 3, "0"));
                    this.baseMessage.set(fieldNo, panSeqNo);
                }
            });
        }

    }
    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    @Override
    public void setPosConditionCode(int fieldNo) {
        this.targetTmm.setPosConditionCode(this.sourceTmm.getPosConditionCode());
        this.baseMessage.set(fieldNo, this.sourceTmm.getPosConditionCode());
    }

    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */


    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */


    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */


    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */


    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */


    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    // TODO: 10-12-2023
    @Override
    public void setAquirerIdCode(int fieldNo) {
        String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
        this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
        this.baseMessage.set(fieldNo, acquirerInstitutionId);
    }

    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */


    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */

    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     *
     */
    @Override
    public void setTrack2Data(int fieldNo) {
        if(this.sourceTmm.getTrack2Data() != null){
            String decryptedData = this.sourceTmm.getTrack2Data() != null  ? StringUtils.isBlank(this.sourceTmm.getTrack2Data())?"":this.sourceTmm.getTrack2Data() :"";
            this.targetTmm.setTrack2Data(decryptedData);
            this.baseMessage.set(fieldNo, decryptedData.replace("D", "="));
        }
    }

    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */


    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {
        String mti = this.targetMsgType;
        if(isEftPosEchoResponse(this.sourceTmm)) {
            String rrnNumber = this.sourceTmm.getRetrievalRefNo().trim();
            this.targetTmm.setRetrievalRefNo(rrnNumber);
            this.baseMessage.set(fieldNo, rrnNumber.getBytes());
        } else if ("0221".equals(mti)) {
            this.targetTmm.setRetrievalRefNo(originalTmm.getRetrievalRefNo());
            this.baseMessage.set(fieldNo, originalTmm.getRetrievalRefNo().getBytes());
        } else {
            String position1TO6 = this.targetTmm.getStan();
            String position7TO12 = MtmUtil.formatDate("MMSSHH", ZoneId.of("GMT"));
            String rrnNumber = position1TO6 + position7TO12;

            ThreadContext.put(FilterConstants.threadContextRetrievalRefNo, rrnNumber);
            this.targetTmm.setRetrievalRefNo(rrnNumber);
            this.baseMessage.set(fieldNo, rrnNumber.getBytes());
        }
    }

    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */
    // For future use
    @Override
    public void setAuthIdRes(int fieldNo) {
        String  authIdRes = this.sourceTmm.getAuthIdRes();
        if(authIdRes != null && !(StringUtils.isBlank(authIdRes))) {
            this.targetTmm.setCardAcceptorInfo(authIdRes);
            this.baseMessage.set(fieldNo, authIdRes);
        }
    }

    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     */


    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */


    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     *
     * It is mandatory for Balance Inquiry ,for other transactions it is conditional
     *
     */
    @Override
    public void setCardAcceptorId(int fieldNo) {
        super.setCardAcceptorId(fieldNo);
    }
    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     *
     * It is mandatory for all type of transactions
     */

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     * <p>
     * It is mandatory for all type of transactions
     */
    @Override
    public void setCardAcceptorInfo(int fieldNo) {
        String cardAcceptorInfo = this.sourceTmm.getCardAcceptorInfo();
        if(cardAcceptorInfo == null){
            String merName = StringUtils.rightPad(this.merchantData.getMerchantName(), 25);
            String merCity = StringUtils.rightPad(this.merchantData.getMerchantCity(), 13);
            String merchantName = merName.substring(0,25);
            String merchantCity = merCity.substring(0,13);
            String merchantCountryShortCode = StringUtils.rightPad(this.merchantData.getMerchantShortCountryCode(), 2); // e.g. IN
            cardAcceptorInfo = merchantName + merchantCity  +  merchantCountryShortCode;
            //String cardAcceptorInfo = "00RC0500................................"; // enable for manual test case
            this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
            this.baseMessage.set(fieldNo, cardAcceptorInfo.getBytes());
        }else{
            this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
            this.baseMessage.set(fieldNo, cardAcceptorInfo.getBytes());
        }

    }

    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */


    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */


    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */


    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */
    @Override
    public void setNationalAd(int fieldNo) {
        String nationalAd = this.sourceTmm.getNationalAd();
        this.targetTmm.setNationalAd(nationalAd);
        this.baseMessage.set(fieldNo, nationalAd);
    }

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */
    /* It is mandatory for all type of transactions */
    @Override
    public void setPrivateAd(int fieldNo) {
        String dataElement48Request = "";
        String dataElement48Response = "";
        String invertedRandamNumber = "";
        String requestZakzpkKcv = "";
        String responseZakzpkKcv = "";

        HsmVendor hsmVendor = SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(sourceTmm.getEntityId());
        String transactionType = this.sourceTmm.getTransactionName();

        if (!this.sourceTmm.getTransactionCategory().equals(TransactionCategory.HEARTBEAT) && !this.sourceTmm.getTransactionCategory().equals(TransactionCategory.DYNAMIC_KEY_EXCHANGE_SIGNOFF)
                && !this.sourceTmm.getTransactionCategory().equals(TransactionCategory.SIGNOFF)){

            if (hsmVendor != null && transactionType.equalsIgnoreCase(TmmConstants.EFTPOS_SIGNON_REQUEST)) {
                String sourceData48 = this.sourceTmm.getPrivateAd() != null ? this.sourceTmm.getPrivateAd() : "";
                if(sourceData48.isEmpty() && !(MessageConstructionHelper.isEftPosSigOn(this.sourceTmm))) {
                    String hsmRandomNumber = SpringContextBridge.getHsmProcessorService(hsmVendor).randamKeyGeneration(sourceTmm.getEntityId(), this.sourceTmm.getTarget(), "0800", sourceData48);
                    String randomNumber = hsmRandomNumber.substring(8);
                    dataElement48Request = randomNumber.substring(0, 16);
                    //invertedRandamNumber = randomNumber.substring(16, 32);
                    this.targetTmm.setPrivateAd(dataElement48Request);
                    this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs(dataElement48Request));
                }else {
                    String hsmRandomNumber = SpringContextBridge.getHsmProcessorService(hsmVendor).validateRandamKeyGeneration(sourceTmm.getEntityId(), this.sourceTmm.getTarget(), "0800", this.sourceTmm.getPrivateAd());
                    String randomNumber = hsmRandomNumber.substring(8);
                    dataElement48Response = randomNumber.substring(0, 16);
                    //invertedRandamNumber = randomNumber.substring(16,32);
                    this.targetTmm.setPrivateAd(dataElement48Response);
                    this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs(dataElement48Response));
                }
            } else if (hsmVendor != null && this.sourceTmm.getTransactionName().equalsIgnoreCase(TmmConstants.EFTPOS_KEYEXCHNAGE_REQUEST)) {
                logger.info("TransactionName{} , Transaction Category{}", this.sourceTmm.getTransactionName(), sourceTmm.getTransactionCategory());

                EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1));
                String sourceData48 = this.sourceTmm.getPrivateAd() != null ? this.sourceTmm.getPrivateAd() : "";

                if(sourceData48.isEmpty() && !(MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm))) {
                    String hsmGenerateZPKAndZaKs = SpringContextBridge.getHsmProcessorService(hsmVendor).generateZPKAndZaK(sourceTmm.getEntityId(), this.sourceTmm.getTarget(), "0820", sourceData48);
                    String generateZPKAndZaKs = hsmGenerateZPKAndZaKs.substring(8);
                    if (!(StringUtils.isBlank(generateZPKAndZaKs)) && eftposKeyModel.isSignonKey() == false && this.sourceTmm.getPrivateAd() == null) {
                        // ZPK
                        String zpkUnderLMK = generateZPKAndZaKs.substring(0, 33);
                        String zpkUnderZMK = generateZPKAndZaKs.substring(34, 66);
                        String zpkKCV = generateZPKAndZaKs.substring(66, 72);
                        //ZAK
                        String zakUnderLMK = generateZPKAndZaKs.substring(72, 105);
                        String zakUnderZMK = generateZPKAndZaKs.substring(106, 138);
                        String zakKCV = generateZPKAndZaKs.substring(138, 144);
                        // ZEK
                        String zekUnderLMK = generateZPKAndZaKs.substring(144, 177);
                        String zekUnderZMK = generateZPKAndZaKs.substring(177, 210);
                        String zekKCV = generateZPKAndZaKs.substring(210, 216);

                        // put key in spring chache
                        TempKeyModel tempKeyModel = new TempKeyModel();
                        tempKeyModel.setZpkUnderLMK(zpkUnderLMK);
                        tempKeyModel.setZpkUnderZMK(zpkUnderZMK);
                        tempKeyModel.setZpkKCV(zpkKCV);

                        tempKeyModel.setZakUnderLMK(zakUnderLMK);
                        tempKeyModel.setZakUnderZMK(zakUnderZMK);
                        tempKeyModel.setZakKCV(zakKCV);

                        tempKeyModel.setZekUnderLMK(zekUnderLMK);
                        tempKeyModel.setZekUnderZMK(zekUnderZMK);
                        tempKeyModel.setZekKCV(zekKCV);

                        try {
                            dataElement48Request = tempKeyModel.getZakUnderZMK() + tempKeyModel.getZpkUnderZMK();
                            requestZakzpkKcv = tempKeyModel.getZakKCV() + tempKeyModel.getZpkKCV();
                            SpringContextBridge.services().getCacheService().updateEftposTempKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length() - 1), tempKeyModel);
                            logger.info("ZpkUnderLMK :: {}, targetName ::{}", tempKeyModel.getZpkUnderLMK(), sourceTmm.getTarget());
                            eftposKeyModel.setSignonKey(true);
                            SpringContextBridge.services().getCacheService().updateEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length() - 1), eftposKeyModel);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    this.targetTmm.setPrivateAd(dataElement48Request);
                    this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs(dataElement48Request));
                }else{
                    logger.info(" TransactionName{} , Transaction Category{}", this.sourceTmm.getTransactionName(), sourceTmm.getTransactionCategory());
                    String hsmRandomNumber = SpringContextBridge.getHsmProcessorService(hsmVendor).validateZPKAndZaK(sourceTmm.getEntityId(), this.sourceTmm.getTarget(), "0820", this.sourceTmm.getPrivateAd());
                    String randomNumber = hsmRandomNumber.substring(8);

                    String kcvProcessingFlag = randomNumber.substring(0, 1);

                    String zpkUnderLMKr = randomNumber.substring(1, 34);
                    String zpkUnderLMKKKCVr = randomNumber.substring(34, 40);

                    String zakUnderLMKr = randomNumber.substring(40, 73);
                    String zakUnderLMKKKCVr = randomNumber.substring(73, 79);

                    String zekUnderLMKr = randomNumber.substring(79, 112);
                    String zekUnderLMKKKCVr = randomNumber.substring(112, 118);

                    //Request -820 KCV
                    TempKeyModel tempKeyModel = SpringContextBridge.services().getCacheService().getTempEftposKeyDetails(this.sourceTmm.getTarget().substring(0,this.sourceTmm.getTarget().length()-1));
                    requestZakzpkKcv = tempKeyModel.getZakKCV() + tempKeyModel.getZpkKCV();
                    //END

                    //Request -830 KCV
                    responseZakzpkKcv=zakUnderLMKKKCVr+zpkUnderLMKKKCVr;
                    this.targetTmm.setPrivateAd(responseZakzpkKcv);
                    this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs(responseZakzpkKcv));
                }

            }//END


        } //END

    }

    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */
    /* It is mandatory for all type of transactions */

    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */


    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */


    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */
    @Override
    public void setPin(int fieldNo) {
        String pan = this.sourceTmm.getPan();

        if (pan != null && this.sourceTmm.getPin() != null) {

            String dynamicKey= null;
            EFTPOSKeyModel eftposKeyModel = cacheServices.getEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1));
            KeyModel keyModel = eftposKeyModel.getTargetKey().entrySet().stream().filter(e -> e.getKey().equals(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1))).map(Map.Entry::getValue).findFirst().orElse(null);
            dynamicKey = keyModel.getZpkUnderLMK();

            logger.info("ZpkUnderLMKet :: {}, targetName ::", dynamicKey, sourceTmm.getTarget());
            Map<HsmCommandArg, String> hsmCmdArgMap = cacheServices.getMftrBDK(sourceTmm.getDeviceMftr());
            String pinTranslation = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).pinTranslation(
                    this.sourceTmm.getEntityId(), this.sourceTmm.getSource(), this.sourceTmm.getTarget(), this.sourceTmm.getPinblockKsn(), this.sourceTmm.getPin(), pan, dynamicKey, hsmCmdArgMap == null ? null : hsmCmdArgMap.get(HsmCommandArg.Bdk2));
            byte[] pinBytes = MtmUtil.toBytesAsIs(pinTranslation);
            this.targetTmm.setPin(pinTranslation);
            this.apiTargetTmm.setPin(ISOUtil.byte2hex(pinBytes));
            this.baseMessage.set(fieldNo, pinBytes);
        }
    }

    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */
    @Override
    public void setSecurityControlInfo(int fieldNo) {
        String securityControlInfo = null;
        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSigOn(this.sourceTmm) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm)) {
            securityControlInfo = this.sourceTmm.getSecurityControlInfo();
            this.targetTmm.setSecurityControlInfo(securityControlInfo);
            this.baseMessage.set(fieldNo, securityControlInfo);
        } else {
            EFTPOSKeyModel eftposKeyModel = SpringContextBridge.services().getCacheService().getEftposKeyDetails(sourceTmm.getTarget().substring(0, sourceTmm.getTarget().length()-1));
            String keysetId = eftposKeyModel.getKeySetId();
            if ("0820".equals(this.sourceTmm.getMsgType()) && !(this.sourceTmm.getTransactionCategory().name().equals(TransactionCategory.SIGNOFF.name()))) {
                if("0000000000000002".equalsIgnoreCase(keysetId)) {
                    securityControlInfo = "0000000000000001";
                }else {
                    securityControlInfo = "0000000000000002";
                }
                this.targetTmm.setSecurityControlInfo(securityControlInfo);
                this.baseMessage.set(fieldNo, securityControlInfo);
            }else if(!("0820".equals(this.sourceTmm.getMsgType()))){
                securityControlInfo = keysetId;
                this.targetTmm.setSecurityControlInfo(securityControlInfo);
                this.baseMessage.set(fieldNo, securityControlInfo);
            }
        }
    }

    /**
     * 54.<br>d
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */
    @Override
    public void setAdditionalAmounts(int fieldNo) {
        String typeOfAccount = this.sourceTmm.getProcessingCode().substring(3, 4);
        final String amtType = "56";
        String currencyCode = "036";
        final String debit = "D";
        String additionalAmts = this.sourceTmm.getAdditionalAmounts();
        String finalValue = typeOfAccount + amtType + currencyCode + debit + additionalAmts;
        this.targetTmm.setAdditionalAmounts(finalValue);
        this.baseMessage.set(fieldNo, finalValue);
    }

    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */
    @Override
    public void setIccData(int fieldNo) {
        if(!(MessageConstructionHelper.isMagstripeWithPin(this.sourceTmm.getPosEntryMode().substring(0,2),this.sourceTmm.getPin())) ||
                (MessageConstructionHelper.isMagstripeWithoutPin(this.sourceTmm.getPosEntryMode().substring(0,2),this.sourceTmm.getPin()))) {
            String iccData = this.sourceTmm.getIccData();
            if (iccData != null) {
                TLVList list = new TLVList();
                TLVList newList = new TLVList();
                list.unpack(ISOUtil.hex2byte(iccData));
                for (TLVMsg tlvMsg : list.getTags()) {
                    if (!TmmConstants.eftposEmvTagSuppressList.contains(tlvMsg.getTag())) {
                        newList.append(tlvMsg.getTag(), tlvMsg.getStringValue());
                    }
                    if (tlvMsg.getTag() == Integer.parseInt("9C", 16) && "01".equals(this.targetTmm.getProcessingCode().substring(0,2)) ) {
                        newList.deleteByTag(Integer.parseInt("9C", 16));
                        newList.append(Integer.parseInt("9C", 16),"01");
                    }
                }

                byte[] pack = newList.pack();
                iccData = ISOUtil.hexString(pack);
                byte[] iccDataBytesAsIs = MtmUtil.toBytesAsIs(iccData);

                this.targetTmm.setIccData(iccData);
                this.baseMessage.set(fieldNo, iccDataBytesAsIs);
            }
        }
    }

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */

    @Override
    public void setReserved57(int fieldNo) {
        long txnAmount = Long.valueOf(this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0");
        long cashAmount = Long.valueOf(this.sourceTmm.getAdditionalAmounts() != null ? this.sourceTmm.getAdditionalAmounts() : "0");

        if(txnAmount > cashAmount && this.targetTmm.getProcessingCode().substring(0,2).equals("09")){
            this.targetTmm.setReserved57(StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(),12, "0"));
            this.baseMessage.set(fieldNo,StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(), 12, "0"));
        } else if (txnAmount == cashAmount && this.targetTmm.getProcessingCode().substring(0,2).equals("01")) {
            this.targetTmm.setReserved57(StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(),12, "0"));
            this.baseMessage.set(fieldNo,StringUtils.leftPad(this.sourceTmm.getAdditionalAmounts(), 12, "0"));
        } else{
            this.targetTmm.setReserved57("000000000000");
            this.baseMessage.set(fieldNo,"000000000000");
        }

    }


    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */


    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */


    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     * <p>
     * It is mandatory for all type of transactions
     */

    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     */

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */

    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     * <p>
     * It is mandatory for all type of transactions
     */

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */
    public void setMsgAuthCode(int fieldNo) {
        this.targetTmm.setMsgAuthCode("0000000000000000");
        this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs("0000000000000000"));
    }

    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */


    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */
    @Override
    public void setSettlementCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
        this.targetTmm.setSettlementCode("1");
        this.baseMessage.set(fieldNo, "1");
    }

    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */


    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */


    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     *
     */


    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */
    @Override
    public void setNetworkMgmtInfoCode(int fieldNo) {
        String networkMgmtInfoCode = null;

        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isSignOnRequest(this.sourceMsgType) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm)
                || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            switch (this.sourceTmm.getTransactionCategory()) {
                case SIGNON:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNON_NW_INFO_CODE;
                    break;
                case DYNAMIC_KEY_EXCHANGE:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_KEYEXCHANE_NW_INFO_CODE;
                    break;
                case HEARTBEAT:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_HEARTBEAT_NW_INFO_CODE;
                    break;
                case SIGNOFF:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNOFF_NW_INFO_CODE;
                    break;
                default:
                    networkMgmtInfoCode = this.sourceTmm.getNetworkMgmtInfoCode();
            }
        }else{
            switch (this.sourceTmm.getTransactionCategory()) {
                case SIGNON:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNON_NW_INFO_CODE;
                    break;
                case DYNAMIC_KEY_EXCHANGE:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_KEYEXCHANE_NW_INFO_CODE;
                    break;
                case HEARTBEAT:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_HEARTBEAT_NW_INFO_CODE;
                    break;
                case DYNAMIC_KEY_EXCHANGE_SIGNOFF:
                case SIGNOFF:
                    networkMgmtInfoCode = TmmConstants.EFTPOS_SIGNOFF_NW_INFO_CODE;
                    break;
                default:
                    networkMgmtInfoCode = this.sourceTmm.getNetworkMgmtInfoCode();
            }
        }
        this.targetTmm.setNetworkMgmtInfoCode(networkMgmtInfoCode);
        this.baseMessage.set(fieldNo, networkMgmtInfoCode);
    }

    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */


    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */


    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */


    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */
    @Override
    public void setNoOfCredits(int fieldNo) {
        if(this.sourceTmm.getNoOfCredits() != null) {
            this.targetTmm.setSettlementCode(this.sourceTmm.getNoOfCredits());
            this.baseMessage.set(fieldNo,this.sourceTmm.getNoOfCredits());
        }else{
            this.targetTmm.setSettlementCode("500");
            this.baseMessage.set(fieldNo,"500");
        }
    }

    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */
    @Override
    public void setCreditsReversalNo(int fieldNo) {
        if(this.sourceTmm.getCreditsReversalNo() != null) {
            this.targetTmm.setCreditsReversalNo(this.sourceTmm.getCreditsReversalNo());
            this.baseMessage.set(fieldNo,this.sourceTmm.getCreditsReversalNo());
        }else{
            this.targetTmm.setCreditsReversalNo("100");
            this.baseMessage.set(fieldNo,"100");
        }
    }

    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */
    @Override
    public void setNoOfDebits(int fieldNo) {
        if(this.sourceTmm.getNoOfDebits() != null) {
            this.targetTmm.setNoOfDebits(this.sourceTmm.getNoOfDebits());
            this.baseMessage.set(fieldNo,this.sourceTmm.getNoOfDebits());
        }else{
            this.targetTmm.setNoOfDebits("200");
            this.baseMessage.set(fieldNo,"200");
        }
    }

    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */
    @Override
    public void setDebitsReversalNo(int fieldNo) {
        if(this.sourceTmm.getDebitsReversalNo() != null) {
            this.targetTmm.setDebitsReversalNo(this.sourceTmm.getDebitsReversalNo());
            this.baseMessage.set(fieldNo,this.sourceTmm.getDebitsReversalNo());
        }else{
            this.targetTmm.setDebitsReversalNo("20");
            this.baseMessage.set(fieldNo,"20");
        }
    }

    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */


    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */


    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */
    @Override
    public void setNoOfInquiries(int fieldNo) {
        if(this.sourceTmm.getNoOfInquiries() != null) {
            this.targetTmm.setNoOfInquiries(this.sourceTmm.getNoOfInquiries());
            this.baseMessage.set(fieldNo,this.sourceTmm.getNoOfInquiries());
        }else{
            this.targetTmm.setNoOfInquiries("240");
            this.baseMessage.set(fieldNo,"240");
        }
    }

    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */
    @Override
    public void setNoOfAuths(int fieldNo) {
        if(this.sourceTmm.getNoOfAuths() != null) {
            this.targetTmm.setNoOfAuths(this.sourceTmm.getNoOfAuths());
            this.baseMessage.set(fieldNo,this.sourceTmm.getNoOfAuths());
        }else{
            this.targetTmm.setNoOfAuths("220");
            this.baseMessage.set(fieldNo,"220");
        }
    }

    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */


    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */
    @Override
    public void setCreditsTxnFee(int fieldNo) {
        if(this.sourceTmm.getCreditsTxnFee() != null) {
            this.targetTmm.setCreditsTxnFee(this.sourceTmm.getCreditsTxnFee());
            this.baseMessage.set(fieldNo,this.sourceTmm.getCreditsTxnFee());
        }else{
            this.targetTmm.setCreditsTxnFee("20");
            this.baseMessage.set(fieldNo,"20");
        }
    }

    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */
    @Override
    public void setDebitsProcessingFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */
    @Override
    public void setDebitsTxnFee(int fieldNo) {
        if(this.sourceTmm.getDebitsTxnFee() != null) {
            this.targetTmm.setDebitsTxnFee(this.sourceTmm.getDebitsTxnFee());
            this.baseMessage.set(fieldNo,this.sourceTmm.getDebitsTxnFee());
        }else{
            this.targetTmm.setDebitsTxnFee("2");
            this.baseMessage.set(fieldNo,"2");
        }
    }

    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */
    @Override
    public void setTotalCredits(int fieldNo) {
        if(this.sourceTmm.getTotalCredits() != null) {
            this.targetTmm.setTotalCredits(this.sourceTmm.getTotalCredits());
            this.baseMessage.set(fieldNo,this.sourceTmm.getTotalCredits());
        }else{
            this.targetTmm.setTotalCredits("221");
            this.baseMessage.set(fieldNo,"221");
        }
    }

    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */
    @Override
    public void setCreditsReversal(int fieldNo) {
        if(this.sourceTmm.getCreditsReversal() != null) {
            this.targetTmm.setCreditsReversal(this.sourceTmm.getCreditsReversal());
            this.baseMessage.set(fieldNo,this.sourceTmm.getCreditsReversal());
        }else{
            this.targetTmm.setCreditsReversal("233");
            this.baseMessage.set(fieldNo,"233");
        }
    }

    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */
    @Override
    public void setTotalDebits(int fieldNo) {
        if(this.sourceTmm.getTotalDebits() != null) {
            this.targetTmm.setTotalDebits(this.sourceTmm.getTotalDebits());
            this.baseMessage.set(fieldNo,this.sourceTmm.getTotalDebits());
        }else{
            this.targetTmm.setTotalDebits("23");
            this.baseMessage.set(fieldNo,"23");
        }
    }

    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */
    @Override
    public void setDebitsReversal(int fieldNo) {
        if(this.sourceTmm.getDebitsReversal() != null) {
            this.targetTmm.setDebitsReversal(this.sourceTmm.getDebitsReversal());
            this.baseMessage.set(fieldNo,this.sourceTmm.getDebitsReversal());
        }else{
            this.targetTmm.setDebitsReversal("33");
            this.baseMessage.set(fieldNo,"33");
        }
    }

    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */

    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */


    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */


    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */


    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */


    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */


    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */


    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */
    @Override
    public void setNetSettlement(int fieldNo) {
        if(this.sourceTmm.getNetSettlement() != null) {
            this.targetTmm.setNetSettlement(this.sourceTmm.getNetSettlement());
            this.baseMessage.set(fieldNo,this.sourceTmm.getNetSettlement());
        }else{
            this.targetTmm.setNetSettlement("333");
            this.baseMessage.set(fieldNo,"333");
        }
    }

    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */

    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */
    @Override
    public void setSettlementIdCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
        if(this.targetMsgType.equals("0530")){
            this.targetTmm.setSettlementIdCode("637204");
            this.baseMessage.set(fieldNo, "637204");
        }else{
            this.targetTmm.setSettlementIdCode("637204");
            this.baseMessage.set(fieldNo, "637204");
        }
    }

    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */
    @Override
    public void setReceiverIdCode(int fieldNo) {
        String receiverCode = null;
        if (MessageConstructionHelper.isEftPosEchoResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSigOn(this.sourceTmm) || MessageConstructionHelper.isEftPosKeyExchangeResponse(this.sourceTmm) || MessageConstructionHelper.isEftPosSignOffResponse(this.sourceTmm)) {
            receiverCode = this.sourceTmm.getReceiverIdCode();
            this.targetTmm.setReceiverIdCode(receiverCode);
            this.baseMessage.set(fieldNo, receiverCode);
        }else{
            this.targetTmm.setReceiverIdCode("637204");
            this.baseMessage.set(fieldNo, "637204");
        }
    }

    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */


    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */


    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */


    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */

    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */


    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */


    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */


    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */


    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */

    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */
    @Override
    public void setReserved118(int fieldNo) {
        if(this.sourceTmm.getReserved118() != null) {
            this.targetTmm.setReserved118(this.sourceTmm.getReserved118());
            this.baseMessage.set(fieldNo,this.sourceTmm.getReserved118());
        }else{
            this.targetTmm.setReserved118("43");
            this.baseMessage.set(fieldNo,"43");
        }
    }

    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */
    @Override
    public void setReserved119(int fieldNo) {

        if(this.sourceTmm.getReserved119() != null) {
            this.targetTmm.setReserved119(this.sourceTmm.getReserved119());
            this.baseMessage.set(fieldNo,this.sourceTmm.getReserved119());
        }else{
            this.targetTmm.setReserved119("423");
            this.baseMessage.set(fieldNo,"423");
        }
    }

    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */


    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */


    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */


    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */


    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */


    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */


    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */


    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */

    /**
     * 128.<br>
     * ISO8583-1987, XML - Message Authentication Code Use<br>
     * AS2805 - Cash Total number
     */
    @Override
    public void setReserved128(int fieldNo) {
        this.targetTmm.setReserved128("0000000000000000");
        this.baseMessage.set(fieldNo, MtmUtil.toBytesAsIs("0000000000000000"));
    }

}