package com.isg.mw.mtm.parser.factory;

import com.isg.mw.core.model.constants.MessageFormat;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.parser.ITmmParser;
import com.isg.mw.mtm.parser.msg.MwMessage;

/**
 * 
 * @author prasad_t026
 *
 * 
 */
public class Iso8583TmmParser extends BaseTmmParser implements ITmmParser {

	@Override
	public TransactionMessageModel parse(MwMessage message, String entityId, String epId, String txnName) {
		TransactionMessageModel tmm = super.parse(message, entityId, epId, txnName);
		tmm.setSourceType(MessageFormat.ISO8583);
		tmm.setDestinationType(MessageFormat.ISO8583);
		return tmm;
	}

}