package com.isg.mw.mtm.parser.factory;

import static com.isg.mw.mtm.context.MessageTransformationContext.getMessageTransformationConfig;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.constants.MsgFlow;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.parser.ITmmParser;
import com.isg.mw.mtm.parser.msg.MwMessage;
import com.isg.mw.mtm.parser.msg.PipeStringMsg;
import com.isg.mw.mtm.rawlog.TxnLogger;

public class PipeStringParser extends BaseTmmParser implements ITmmParser {
	private Logger logger = LogManager.getLogger(getClass());

    @Override
    public TransactionMessageModel parse(MwMessage message, String entityId, String epId, String srcTxnName) {
        String reqMsgLength = ((PipeStringMsg) message).getPipeMsg().split("\\|")[0];
        String rawMsgWithoutLength = ((PipeStringMsg) message).getPipeMsg().substring(reqMsgLength.length() + 1);
        String rawMsgWithoutGarbagevalue = rawMsgWithoutLength.replace("\n\r", "");
        String[] deNoAndDataArr = rawMsgWithoutGarbagevalue.split("\\|");
        Map<Integer, String> deFieldsMap = new HashMap<>();
        for (String deNoAndData : deNoAndDataArr) {
            int fieldNo = Integer.parseInt(deNoAndData.split(",")[0]);
            String data = deNoAndData.split(",")[1];
            deFieldsMap.put(fieldNo, data);
        }
        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(epId);
        String msgType = deFieldsMap.get(2);
        String msgTypeId = deFieldsMap.get(3);
        String txnTypeName = null;
        Set<String> txnNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                .get(targetType + "." + msgType + "." + msgTypeId);
        
        logger.trace("Transaction Name List for given key {}.{}.{} is {} {}", targetType, msgType, msgTypeId, txnNameSet, srcTxnName);
        if (txnNameSet.size() == 1) {
        	txnTypeName = txnNameSet.stream().findFirst().orElse(null);
        } else if (txnNameSet.size() > 1 && StringUtils.isNotBlank(srcTxnName) ) {
        	txnTypeName = txnNameSet.stream().filter(str -> str.equals(srcTxnName.replace("request", "response"))).findAny()
  		  .orElse(null);
        }
        logger.trace("Transaction name selected: {}", txnTypeName);
        
        logger.trace("Fetching MessageTransformationConfig for: {}.{}.{}", targetType, msgType, msgTypeId);
        MessageTransformationConfig msgTransConfig = getMessageTransformationConfig(entityId, epId,
                new TransactionTypeConfig(msgType, msgTypeId, txnTypeName));
        Map<Integer, String> tmmConfig = msgTransConfig.getTmmConfig();

        TransactionMessageModel tmm = new TransactionMessageModel();
        tmm.setTransactionName(txnTypeName);
        tmm.setTargetType(targetType);

        TransactionMessageModel.PgData pgData = new TransactionMessageModel.PgData();
        
        logger.trace("Tmm config map: {} of Entity Id: {}, Endpoint Id: {}, TransactionTypeConfig: {}", tmmConfig,
                entityId, epId, new TransactionTypeConfig(msgType, msgTypeId, txnTypeName));

        deFieldsMap.forEach((fieldNo, data) -> buildTmm(tmm, pgData, tmmConfig, fieldNo, data));
        tmm.setPgData(pgData);
        if (tmm.getTerminalStan() == null)
            tmm.setTerminalStan(tmm.getStan());

        updateDrCrFlag(tmm);
        TxnLogger.logPgTxnDetail(MsgFlow.INBOUND, rawMsgWithoutGarbagevalue, tmm);
        return tmm;
    }

    public String convert(TransactionMessageModel tmm, Map<Integer, String> tmmConfig) {
        StringBuilder txnMsg = new StringBuilder();
        tmmConfig.forEach((fieldNo, methodName) -> {
            txnMsg.append(fieldNo)
                    .append(",")
                    .append(getData(tmm, methodName))
                    .append("|");
        });
        StringBuilder txnMsgfinalResponse = new StringBuilder();
        txnMsgfinalResponse.append(txnMsg.length() + 1).append("|").append(txnMsg);
        return txnMsgfinalResponse.toString();
    }
}
