package com.isg.mw.mtm.parser.factory;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.isAllSchemeReversalRes;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isBatchSettlementRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isBatchUploadRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isOfflineRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isPosZvavReq;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isPosZvavResponse;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isPreAuthCompletionRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isReversalRequest;
import static com.isg.mw.mtm.construct.MessageConstructionHelper.isVoidResponse;
import static com.isg.mw.mtm.context.MessageTransformationContext.getMessageTransformationConfig;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.jpos.iso.ISOBinaryField;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOField;
import org.jpos.iso.ISOUtil;
import org.jpos.tlv.TLVList;

import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.constants.MsgFlow;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.core.utils.TlvDataList;
import com.isg.mw.mtm.config.EncryptService;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.MessageParsingException;
import com.isg.mw.mtm.parser.ITmmParser;
import com.isg.mw.mtm.parser.msg.BaseMessage;
import com.isg.mw.mtm.parser.msg.MwMessage;
import com.isg.mw.mtm.rawlog.TxnLogger;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmConstants;
import com.isg.mw.mtm.util.MtmUtil;

/**
 * @author juber3709
 */
public class BaseTmmParser implements ITmmParser {
    private Logger logger = LogManager.getLogger(getClass());

    @Override
    public TransactionMessageModel parse(MwMessage message, String entityId, String epId, String srcTxnName) {

        BaseMessage baseMessage = (BaseMessage) message;
        Map<Integer, Object> fieldsMap = baseMessage.getFields();


        TransactionMessageModel tmm = new TransactionMessageModel();
        String msgType;
        try {
            msgType = baseMessage.getMTI();
        } catch (ISOException e1) {
            throw new MessageParsingException("Could not find endpoint message type in message", e1);
        }
        String msgTypeId = baseMessage.getField(3);
        if (msgTypeId != null)
            msgTypeId = msgTypeId.substring(0, 2);

        tmm.setProcessingCode(msgTypeId);

        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(epId);
        if (isVoidResponse(msgType) || isReversalRequest(msgType) || isAllSchemeReversalRes(msgType) || isBatchUploadRequest(msgType)) {
            // because, scheme returns original transaction's processing code
            msgTypeId = null;
        }
        tmm.setTargetType(targetType);
        String txnTypeName = null;
        
        Set<String> txnNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                .get(targetType + "." + msgType + "." + msgTypeId);
        
        logger.trace("Transaction Name List for given key {}.{}.{} is {} {}", targetType, msgType, msgTypeId, txnNameSet, srcTxnName);
        if (txnNameSet.size() == 1) {
        	txnTypeName = txnNameSet.stream().findFirst().orElse(null);
        } else if (txnNameSet.size() > 1) { 
        	if( StringUtils.isNotBlank(srcTxnName) ) {
        		txnTypeName = txnNameSet.stream().filter(str -> str.equals(srcTxnName.replace("request", "response"))).findAny()
        				.orElse(null);
        	} else {
        		txnTypeName = txnNameSet.stream().findFirst().orElse(null);
        	}
        }
        
        String txnFinancialAdivce = setFinancialAdivseOrOfflineTxnName(baseMessage, msgType, msgTypeId);
        txnTypeName = txnFinancialAdivce != null ? txnFinancialAdivce : txnTypeName;
        
        logger.trace("Transaction name selected: {}", txnTypeName);

        logger.trace("Fetching MessageTransformationConfig for: {}.{}.{}", targetType, msgType, msgTypeId);

        MessageTransformationConfig msgTransConfig = getMessageTransformationConfig(entityId, epId,
                new TransactionTypeConfig(msgType, msgTypeId, txnTypeName));
        Map<Integer, String> tmmConfig = msgTransConfig.getTmmConfig();
        logger.trace("Tmm config map: {} of Entity Id: {}, Endpoint Id: {}, TransactionTypeConfig: {}", tmmConfig,
                entityId, epId, new TransactionTypeConfig(msgType, msgTypeId, txnTypeName));

        Class<?> className = msgTransConfig.getBusinessRuleClass();
        logger.trace("Constructing message from class: {}", className);
        fieldsMap.forEach((fieldNo, fieldObj) -> {
            if (fieldObj instanceof ISOField) {
                ISOField isoFieldObj = (ISOField) fieldObj;
                buildTmm(tmm, null, tmmConfig, fieldNo, (String) isoFieldObj.getValue());
            } else if (fieldObj instanceof ISOBinaryField) {
                ISOBinaryField isoFieldObj = (ISOBinaryField) fieldObj;
                byte[] value = (byte[]) isoFieldObj.getValue();
                buildTmm(tmm, null, tmmConfig, fieldNo, ISOUtil.byte2hex(value));
            }
        });

        tmm.setMsgType(msgType);
        tmm.setBitMap(baseMessage.getBitMap());
        tmm.setTransactionName(txnTypeName);

        parsedandSetPosData(tmm, msgType, msgTypeId, targetType);
        
        if(txnTypeName.equals(TmmConstants.BQR_PURCHASE_REQUEST)|| txnTypeName.equals(TmmConstants.BQR_STIP_REQUEST)){
            if(targetType.equals(TargetType.Visa)){
                parseAndSetBqrPostalCode(tmm);
                parseAndSetBqrTxnDesc(tmm);
            }
        }
        
        String acpTraceId = tmm.getCardAcceptorId() + tmm.getCardAcceptorTerminalId() + tmm.getStan();
        ThreadContext.put(FilterConstants.threadContextAcpTraceId, acpTraceId);
        Optional.ofNullable(tmm.getRetrievalRefNo())
                .ifPresent( rrn -> ThreadContext.put(FilterConstants.threadContextRetrievalRefNo, rrn));

        TxnLogger.logTxnDetail(MsgFlow.INBOUND, fieldsMap, tmm, tmm);

        return tmm;
    }

	public void parsedandSetPosData(TransactionMessageModel tmm, String msgType, String msgTypeId,
			TargetType targetType) {
		// TODO: use strategy pattern for anything specific to pos, visa, master card, etc.
        if (targetType.equals(TargetType.Pos)) {

            // DE 22
            parseAndSetPosEntryMode(tmm);

            // DE 23
            parseAndSetPanSeqNo(tmm, msgType, msgTypeId);

            // DE53 (issue: jpos is parsing char 'D' to '='
            String securityControlInfo = tmm.getSecurityControlInfo();
            if (securityControlInfo != null) {
                tmm.setSecurityControlInfo(securityControlInfo.replace('=', 'D'));
                parseAndSetSecurityInfo(tmm);
            }

            // DE54
            parseAndSetAdditionalAmt(tmm);
            
            //Using D55
            if( null != tmm.getIccData() && !StringUtils.isBlank(tmm.getIccData())) {
                parseAndSetAppIndicator(tmm);
            }

            // DE 60
            parseAndSetTerminalData(tmm, msgType, msgTypeId);

            //DE 61 CCV OR Service Code
            parseAndSetCvv(tmm);

            // DE 62 invoice no
            parseAndSetPostalCode(tmm, msgType, msgTypeId);

            // DE 63
            parseAndSetAtmPinOffsetData(tmm, msgType, msgTypeId);
            updateDrCrFlag(tmm);
        }

        // for other than batch upload transactions
        if (tmm.getTerminalStan() == null)
            tmm.setTerminalStan(tmm.getStan());

        if (MessageConstructionHelper.isCashAtPos(msgType, msgTypeId)) {
            setCashbackTxnName(tmm, msgType, msgTypeId);
        }
	}

	public void parseAndSetAppIndicator(TransactionMessageModel tmm) {
		String appIndicator = "";
		TLVList iccDataList = new TLVList();
		try {
			iccDataList.unpack(ISOUtil.hex2byte(tmm.getIccData()));
			if (iccDataList.hasTag(Integer.parseInt(MtmConstants.ICC_APP_INDICATOR, 16))) {
				int tag9f06Index = iccDataList.findIndex(Integer.parseInt(MtmConstants.ICC_APP_INDICATOR, 16));
				appIndicator = iccDataList.index(tag9f06Index).getStringValue();
				tmm.setApplicationIdentifier(appIndicator);
			}
		} catch (Exception e) {
			tmm.setApplicationIdentifier("");
		}

	}
    
    private void parseAndSetSecurityInfo(TransactionMessageModel tmm) {
    	String securityControlInfo = tmm.getSecurityControlInfo(); 
    	TlvDataList tlvData = new TlvDataList(securityControlInfo);
    	
        String cardNumberKsn =  tlvData.getTagValue(MtmConstants.POS_TERMINAL_KSN_1);
        String pinblockKsn =  tlvData.getTagValue(MtmConstants.POS_TERMINAL_KSN_2);
        tmm.setCardNumberKsn(cardNumberKsn);
        tmm.setPinblockKsn(pinblockKsn);
    	
    }

    private void parseAndSetPanSeqNo(TransactionMessageModel tmm, String msgType, String msgTypeId) {
        String iccData = tmm.getIccData();
        if (iccData != null
                && (isOfflineRequest(msgType, msgTypeId)
                || isPreAuthCompletionRequest(msgType, msgTypeId))) {

            String cardSeqNo = iccData.substring(iccData.indexOf(MtmConstants.ICC_CARD_SEQ_NUM) + 6, iccData.indexOf(MtmConstants.ICC_CARD_SEQ_NUM) + 8);

            tmm.setCardSeqNo(cardSeqNo);
        }
    }

    private void parseAndSetPosEntryMode(TransactionMessageModel tmm) {
        String posEntryMode = tmm.getPosEntryMode();
        if (posEntryMode != null && !posEntryMode.isEmpty()) {
            tmm.setPosEntryMode(posEntryMode.substring(posEntryMode.length() - MtmUtil.POS_ENTRY_MODE_DATA_LENGTH));
        }
    }

    private void parseAndSetAdditionalAmt(TransactionMessageModel tmm) {
        String additionalAmt = tmm.getAdditionalAmounts();
        if (additionalAmt != null) {
            additionalAmt = new String(DatatypeConverter.parseHexBinary(additionalAmt));
            tmm.setAdditionalAmounts(additionalAmt);
        }
    }

    private void parseAndSetTerminalData(TransactionMessageModel tmm, String msgType, String msgTypeId) {
        String terminalData = tmm.getTerminalData();
        if (terminalData != null) {
            String termData = new String(DatatypeConverter.parseHexBinary(terminalData));
            if (isBatchUploadRequest(msgType)) {
                //DE 60 contains Original Message Data in Batch Upload.
                tmm.setMsgType(termData.substring(0, 4));
                tmm.setTerminalStan(termData.substring(4, 10));
                tmm.setRetrievalRefNo(termData.substring(10, 22));
                tmm.setBatchUploadMsgType(msgType);
                // TODO: if required will add original transaction id in future
            } else {
                TlvDataList tlvData = new TlvDataList(new String(DatatypeConverter.parseHexBinary(terminalData)));
                if (isBatchSettlementRequest(msgType, msgTypeId)) {
                    termData = tlvData.getTagValue(MtmConstants.POS_TERMINAL_BATCH_NO);
                    tmm.setTerminalBatchNo(termData);
                } else {
                    termData = tlvData.getTagValue(MtmConstants.POS_TERMINAL_ORIGINAL_AMT);
                }
            }
            tmm.setTerminalData(termData);
        }
    }

    private void parseAndSetCvv(TransactionMessageModel tmm) {
        String hexCvv = tmm.getCiad();
        if (hexCvv != null) {
            String cvv = new String(DatatypeConverter.parseHexBinary(hexCvv));
            tmm.setCiad(cvv);
        }
    }

    private void parseAndSetAtmPinOffsetData(TransactionMessageModel tmm, String msgType, String msgTypeId) {
        String atmPinOffsetData = tmm.getAtmPinOffsetData();
        if (atmPinOffsetData != null) {
            String atmData = new String(DatatypeConverter.parseHexBinary(atmPinOffsetData));
            tmm.setAtmPinOffsetData(atmData);
            //DE 63 contains Settlements Totals in Batch Settlement.
            if (isBatchSettlementRequest(msgType, msgTypeId)) {
                if (atmData.length() == 40) {
                    tmm.setSaleCount(atmData.substring(0, 5));
                    tmm.setSaleAmount(atmData.substring(5, 20));
                    tmm.setRefundCount(atmData.substring(20, 25));
                    tmm.setRefundAmount(atmData.substring(25));
                }
            } else if (isBatchUploadRequest(msgType)) {
                TlvDataList tlvData = new TlvDataList(atmData);
                //DE 63 contains terminal batch no. and hardware serial no in Batch Upload
                String terminalBatchNo = tlvData.getTagValue(MtmConstants.POS_TERMINAL_BATCH_NO);
                String hardwareSerialNo = tlvData.getTagValue(MtmConstants.POS_HARDWARE_SERIAL_NO);
                String deviceMftr = tlvData.getTagValue(MtmConstants.DEVICE_MFTR);
                tmm.setTerminalBatchNo(terminalBatchNo);
                tmm.setHardwareSerialNo(hardwareSerialNo);
                tmm.setDeviceMftr(deviceMftr);

            } else {
                TlvDataList tlvData = new TlvDataList(atmData);
                String terminalBatchNo = tlvData.getTagValue(MtmConstants.POS_TERMINAL_BATCH_NO);
                String deviceMftr = tlvData.getTagValue(MtmConstants.DEVICE_MFTR);
                
                String networkLink = tlvData.getTagValue(MtmConstants.NETWORK_LINK);
                String posAavData = tlvData.getTagValue(MtmConstants.POS_AAV_DATA);
                String posTridData = tlvData.getTagValue(MtmConstants.POS_TRID_DATA);
                
                tmm.setNetworkLink(networkLink);
                
                tmm.setTerminalBatchNo(terminalBatchNo);
                tmm.setAtmPinOffsetData(atmData);
                tmm.setDeviceMftr(deviceMftr);
                tmm.setPosAavData(posAavData);
                tmm.setPosTridData(posTridData);
                
                if (tlvData.getElements().containsKey(MtmConstants.DCC_TXN_CURRENCY_CODE)) {
                	String dccCurrencyName = tlvData.getTagValue(MtmConstants.DCC_CURRENCY_NAME);
                	String dccRateLookRrn = tlvData.getTagValue(MtmConstants.RATE_LOOKUP_TXN_RRN);
                	String dccAmt = tlvData.getTagValue(MtmConstants.DCC_AMOUNT);
                	String dccExchangeRate = tlvData.getTagValue(MtmConstants.DCC_EXCHANGE_RATE);
                	String dccMarkUpPercent = tlvData.getTagValue(MtmConstants.DCC_MARKUP_PERCENT);
                	String dccTxnCurrCode = tlvData.getTagValue(MtmConstants.DCC_TXN_CURRENCY_CODE);
                	String dccNoOfDecimals  = tlvData.getTagValue(MtmConstants.DCC_NO_OF_DECIMALS);
                	String dccIndicator = tlvData.getTagValue(MtmConstants.DCC_INDICATOR);

                	tmm.setDccCurrencyName(dccCurrencyName);
                	tmm.setDccRateLookRrn(dccRateLookRrn);
                	tmm.setDccAmount(dccAmt);
                	tmm.setDccExchangeRate(dccExchangeRate);
                	tmm.setDccMarkUpPercent(dccMarkUpPercent);
                	tmm.setDccTxnCurrCode(dccTxnCurrCode);
                	tmm.setDccNoOfDecimals(dccNoOfDecimals);
                	tmm.setDccIndicator(dccIndicator);
                	tmm.setDccData(atmData);
                }

            }
        }
    }

    private void parseAndSetPostalCode(TransactionMessageModel tmm, String msgType, String msgTypeId) {
        String postalCode = tmm.getPostalCode();
        if (postalCode != null && !isBatchSettlementRequest(msgType, msgTypeId)) {
            String invoiceNo = new String(DatatypeConverter.parseHexBinary(postalCode));
            String cidAmex = "";
            // DE 62 contains only invoice no(6) in void transactions
            if (invoiceNo.length() > 6) {
                TlvDataList tlvData = new TlvDataList(invoiceNo);
                invoiceNo = tlvData.getTagValue(MtmConstants.POS_TERMINAL_INVOICE_NO);
                cidAmex = tlvData.getTagValue(MtmConstants.POS_TERMINAL_CID);
            }
            tmm.setPostalCode(invoiceNo);
            tmm.setPosCid(cidAmex);
        }
    }

    private void parseAndSetBqrPostalCode(TransactionMessageModel tmm) {
        String postalCode = tmm.getPostalCode().substring(16, tmm.getPostalCode().length());
        postalCode = ISOUtil.ebcdicToAscii(ISOUtil.hex2byte(postalCode));
        tmm.setPostalCode(postalCode);
    }

    private void parseAndSetBqrTxnDesc(TransactionMessageModel tmm){
        String txnDesc = tmm.getTxnDesc();
        EncryptService encryptionService = SpringContextBridge.services().getEncryptionService();

        String senderRefNumber = ISOUtil.ebcdicToAscii(ISOUtil.hex2byte(txnDesc.substring(24,56)));
        tmm.setSenderRefNumber(senderRefNumber);

        String customerPan = ISOUtil.ebcdicToAscii(ISOUtil.hex2byte(txnDesc.substring(60,92)));
        tmm.setEncryptedPan(encryptionService.encrypt(customerPan));
        customerPan = MaskingUtility.maskCardNumber(customerPan);
        tmm.setCustomerPan(customerPan);

        String customerName = ISOUtil.ebcdicToAscii(ISOUtil.hex2byte(txnDesc.substring(96,txnDesc.length())));
        tmm.setCustomerName(customerName);

        StringBuilder sb = new StringBuilder();
        sb = sb.append(txnDesc.substring(0,24))
                .append(senderRefNumber)
                .append(txnDesc.substring(56,60))
                .append(customerPan)
                .append(txnDesc.substring(92,96))
                .append(customerName);

        txnDesc = sb.toString();
        tmm.setTxnDesc(txnDesc);
    }

    private void setCashbackTxnName(TransactionMessageModel tmm, String msgType, String msgTypeId) {
        String additionalAmt = tmm.getAdditionalAmounts();
        if (additionalAmt != null && additionalAmt.contains("D")) {
            additionalAmt = tmm.getAdditionalAmounts().substring(additionalAmt.indexOf("D") + 1, additionalAmt.length());
        }
        if (MessageConstructionHelper.isCashAtPosRequest(msgType, msgTypeId, tmm.getTxnAmt(), additionalAmt)) {
            tmm.setTransactionName(TmmConstants.CASHATPOS_REQUEST);
        } else if (MessageConstructionHelper.isSaleWithCashAtPosRequest(msgType, msgTypeId, tmm.getTxnAmt(), additionalAmt)) {
            tmm.setTransactionName(TmmConstants.PURCHASE_CASHATPOS_REQUEST);
        }
    }
    
    private String setFinancialAdivseOrOfflineTxnName(BaseMessage baseMessage, String msgType, String msgTypeId) {
    	String txnName = null;
    	if(MessageConstructionHelper.isOfflineRequest(msgType, msgTypeId)
    			|| MessageConstructionHelper.isEftPosFinancialAdviceRequest(msgType, msgTypeId)) {
    		if (baseMessage.getField(39).equals("Y1")
    				|| baseMessage.getField(39).equals("Y3")) {
    			txnName = TmmConstants.OFFLINE_REQUEST;
    		} else {
    			txnName = TmmConstants.EFTPOS_FINANCIAL_ADVICE_PURCHASE_REQUEST;
    		}
    	}
    	return txnName;
    }

    protected void updateDrCrFlag(TransactionMessageModel tmm) {
        String msgTypeId = tmm.getProcessingCode();
        String msgType = tmm.getMsgType();
        String reversalMsgReasonCode = tmm.getPgData() != null ? tmm.getPgData().getReversalMessageReasonCode() : null;
        if (MessageConstructionHelper.isPosVoidRequest(msgType, msgTypeId)) {
            tmm.setDrcrFlag("V");
        } else if (MessageConstructionHelper.isReversalRequest(msgType) ||
                isReversalRequest(msgType) || isAllSchemeReversalRes(msgType)) {
            if (!StringUtils.isBlank(reversalMsgReasonCode) && reversalMsgReasonCode.equals("V")) {
                tmm.setDrcrFlag("V");
            } else {
                tmm.setDrcrFlag("R");
            }
        } else if (MessageConstructionHelper.isPosRefundReq(msgType, msgTypeId)
                || PgMsgTypeHelper.isRefund(msgType, msgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(msgType, msgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(msgType, msgTypeId)) {
            tmm.setDrcrFlag("C");
        } else if (MessageConstructionHelper.isPreAuth(msgType, msgTypeId) ||
                MessageConstructionHelper.isBalanceEnquiry(msgType, msgTypeId) ||
                MessageConstructionHelper.isBatchSettlementRequest(msgType, msgTypeId) ||
                MessageConstructionHelper.isAddMoneyRequest(msgType, msgTypeId) ||
                MessageConstructionHelper.isBalanceUpdateRequest(msgType, msgTypeId) ||
                PgMsgTypeHelper.isPreAuth(msgType, msgTypeId) || 
                PgMsgTypeHelper.isMotoPreAuth(msgType, msgTypeId) ||
                MessageConstructionHelper.isDccRateLookup(msgType, msgTypeId) ||
                isPosZvavReq(msgType, msgTypeId) ||
                isPosZvavResponse(msgType, msgTypeId)) {
            tmm.setDrcrFlag("N");
        } else {
            tmm.setDrcrFlag("D");
        }
    }


    protected void buildTmm(TransactionMessageModel tmm, TransactionMessageModel.PgData pgData, Map<Integer, String> tmmConfig, int fieldNo, String value) {
        Class<?>[] stringParam = {String.class};
        String methodName = tmmConfig.get(fieldNo);
        if (methodName != null) {
            try {
                Method declaredMethod = TransactionMessageModel.class.getDeclaredMethod(methodName, stringParam);
                declaredMethod.invoke(tmm, value);
            } catch (NoSuchMethodException e) {
                try {
                    Method declaredMethod = TransactionMessageModel.PgData.class.getDeclaredMethod(methodName, stringParam);
                    declaredMethod.invoke(pgData, value);
                } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException
                         | InvocationTargetException ex) {
                    throw new MessageParsingException("Error while invoking method: " + methodName, ex);
                }
            } catch (SecurityException | IllegalAccessException | IllegalArgumentException
                     | InvocationTargetException e) {
                throw new MessageParsingException("Error while invoking method: " + methodName, e);
            }
        }
    }

    public String getData(TransactionMessageModel tmm, String methodName) {
        String data = null;
        if (methodName != null) {
            try {
                methodName = "get" + methodName.substring(3);
                Method declaredMethod = TransactionMessageModel.class.getDeclaredMethod(methodName);
                data = (String) declaredMethod.invoke(tmm);
            } catch (NoSuchMethodException e) {
                try {
                    Method declaredMethod = TransactionMessageModel.PgData.class.getDeclaredMethod(methodName);
                    data = (String) declaredMethod.invoke(tmm.getPgData());
                } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException
                         | InvocationTargetException ex) {
                    throw new MessageParsingException("Error while invoking method: " + methodName, ex);
                }
            } catch (SecurityException | IllegalAccessException | IllegalArgumentException
                     | InvocationTargetException e) {
                throw new MessageParsingException("Error while invoking method: " + methodName, e);
            }
        }
        return data;
    }


}