package com.isg.mw.mtm.transform.mosambee;

import com.isg.mw.core.model.pos.MosambeeRegTidRequestModel;
import com.isg.mw.core.model.pos.MosambeeRequestModel;
import com.isg.mw.core.model.pos.MosambeeUpdateStatusRequestModel;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.tc.TargetApiInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Component
public class MosambeeMessageTransformation {
    private Logger logger = LogManager.getLogger(getClass());

    @Value("${statecode.name.path}")
    private String stateCodeNamePath;

    @Value("${mosambee.config.file}")
    private String mosambeeConfigFile;

    private static String stateCodeNamePathStatic;

    private static String mosambeeConfigFileStatic;

    private static String acquirerName;
    private static String tg;

    private static String instrument;
    private static String instrumentCode;


    @PostConstruct
    public void init() {
        stateCodeNamePathStatic = stateCodeNamePath;
        mosambeeConfigFileStatic = mosambeeConfigFile;
        getMosambeeConfigData();
    }
    public MosambeeRequestModel createMerchant(MerchantMasterModel masterModel) {
        MosambeeRequestModel model = new MosambeeRequestModel();
        model.setMerchantName(masterModel.getMerchantName());  //Required
        model.setIsEnterprise("No"); //Required
        model.setEnterpriseCode("");//optional
        model.setEnterpriseLevel(""); //optional
        model.setEnterpiseLevelName(""); //optional
        model.setMerchantDba(masterModel.getMerchantName()); //optional
        model.setMobileNumber(masterModel.getMerchantMobNo()); //Required
        model.setBusinessEmail(masterModel.getMerchantEmail()); // Required
        model.setSpocName(masterModel.getContactPerson()); // Optional
        model.setMerchantAddress(masterModel.getMerchantAddress()); //Required
        model.setCity(masterModel.getMerchantCity());//Required
        model.setState(getStateName(masterModel.getCountryName(),masterModel.getMerchantStateCode()));//Required
        model.setCountry(masterModel.getCountryName());//Optional
        model.setProgramType("");//conditional
        model.setBusinessPin(masterModel.getMerchantPincode());//conditional
        model.setMccCode(masterModel.getMccCode());//required
        model.setIsIntegrated("0");//optional
        model.setMidRequest(getMidRequestModel(masterModel));//conditional
        return model;
    }

    public static MosambeeRequestModel.MidRequest  getMidRequestModel(MerchantMasterModel masterModel) {
        MosambeeRequestModel.MidRequest midModel = new MosambeeRequestModel.MidRequest();
        midModel.setMid(masterModel.getMid());//Required
        midModel.setProcessingMid("");//optional
        midModel.setAcquirer(acquirerName);//optional
        midModel.setTg(tg);//optional
        midModel.setInstrument(instrument);//optional
        midModel.setInstrumentCode(instrumentCode);//required
        midModel.setMidRef1("");//optional
        midModel.setMidRef2("");//optional
        midModel.setMidRef3("");//optional
        midModel.setTidDetails(getTidDetailsList(masterModel)); //conditional
        return midModel;
    }

    public static List<MosambeeRequestModel.TidDetail> getTidDetailsList(MerchantMasterModel masterModel) {
        MosambeeRequestModel.TidDetail tidModel = new MosambeeRequestModel.TidDetail();
        List<MosambeeRequestModel.TidDetail> tidDetailList = new ArrayList<>();

        tidModel.setTid(masterModel.getTid());//required
//        tidModel.setProcessingTid(""); //optional
//        tidModel.setUserName("");//optional
        tidModel.setTidType(masterModel.getTerminalType());//required
        tidModel.setStoreName(masterModel.getMerchantName()); //optional
        tidModel.setTerminalLocation(masterModel.getMerchantCity()); //Required
//        tidModel.setPosTerminalSupported("CPOC");//optional
//        tidModel.setDevicePairFlag(!masterModel.getDeviceSerialNo().trim().isEmpty()?"Y":"N");//optional
        tidModel.setDeviceSerialNo(masterModel.getDeviceSerialNo()!=null?masterModel.getDeviceSerialNo():""); //conditional
        tidModel.setTerminalAuthType("none");//required
        tidModel.setTerminalKeyValue("");//conditional
        tidModel.setTerminalSpocName(masterModel.getContactPerson()); //optional
        tidModel.setTerminalContactNo(masterModel.getMerchantMobNo());//conditional
        tidModel.setTerminalEmail(masterModel.getMerchantEmail());//conditional
        tidModel.setTerminalRef1("");//optional
        tidModel.setTerminalRef2("");//optional
        tidModel.setTerminalRef3("");//optional
//        tidModel.setAmexEnable(""); //optional
        tidDetailList.add(tidModel);
        return tidDetailList;
    }

    public MosambeeRequestModel createMerchantRegistrationUpdate(MerchantMasterModel masterModel) {
        MosambeeRequestModel model = new MosambeeRequestModel();
        model.setMerchantName(masterModel.getMerchantName());  //Required
        model.setIsEnterprise("No"); //Required
        model.setEnterpriseCode("");//optional
        model.setEnterpriseLevel(""); //optional
        model.setEnterpiseLevelName(""); //optional
        model.setMerchantDba(masterModel.getMerchantName()); //optional
        model.setMobileNumber(masterModel.getMerchantMobNo()); //Required
        model.setBusinessEmail(masterModel.getMerchantEmail()); // Required
        model.setSpocName(masterModel.getContactPerson()); // Optional
        model.setMerchantAddress(masterModel.getMerchantAddress()); //Required
        model.setCity(masterModel.getMerchantCity());//Required
        model.setState(getStateName(masterModel.getCountryName(),masterModel.getMerchantStateCode()));//Required
        model.setCountry(masterModel.getCountryName());//Optional
        model.setProgramType("");//conditional
        model.setBusinessPin(masterModel.getMerchantPincode());//conditional
        model.setMccCode(masterModel.getMccCode());//required
        model.setIsIntegrated("No");//optional
        model.setMidRequest(getMidRequestModel(masterModel));//conditional
        return model;
    }

    public MosambeeUpdateStatusRequestModel createMerchantUpdateStatus(MerchantMasterModel masterModel, String refId) {
        MosambeeUpdateStatusRequestModel model = new MosambeeUpdateStatusRequestModel();
        model.setRefId(refId);  //Required
        model.setRefType("merchant"); //Required Reference type, merchant, mid or tid. If merchant status need to rejected then merchant
        model.setAcquirer(acquirerName);//conditional
        model.setTg(tg); //conditional
        model.setInstrument(instrument); //conditional
        model.setInstrumentCode(instrumentCode); //conditional
        model.setStatus("D"); //Required
        model.setRemark("business not active."); // Required
        return model;
    }

    public MosambeeRegTidRequestModel createMerchantTidRegister(MerchantMasterModel masterModel, String refId) {
        MosambeeRegTidRequestModel model = new MosambeeRegTidRequestModel();
        model.setMidRefId(refId);  //Required
        model.setMid(masterModel.getMid()); //Required
        model.setAcquirer(acquirerName); //optional
        model.setTg(tg); //optional
        model.setInstrument(instrument); //optional
        model.setInstrumentCode(instrumentCode);//optional
        model.setTidDetails(getTidDetailsListRegisterTid(masterModel)); //conditional

        return model;
    }
    public static List<MosambeeRegTidRequestModel.TidDetail> getTidDetailsListRegisterTid(MerchantMasterModel masterModel) {
        MosambeeRegTidRequestModel.TidDetail tidModel = new MosambeeRegTidRequestModel.TidDetail();
        List<MosambeeRegTidRequestModel.TidDetail> tidDetailList = new ArrayList<>();

        tidModel.setTid(masterModel.getTid());//required
        tidModel.setProcessingTid(""); //optional
        tidModel.setUserName("");//optional
        tidModel.setTidType(masterModel.getTerminalType());//required
        tidModel.setStoreName(masterModel.getMerchantName()); //optional
        tidModel.setTerminalLocation(masterModel.getMerchantCity()); //Required
        tidModel.setPosTerminalSupported("CPOC");//optional
        tidModel.setDevicePairFlag("N");//optional
        tidModel.setDeviceSerialNo(masterModel.getDeviceSerialNo()); //conditional
        tidModel.setTerminalAuthType("none");//required
        tidModel.setTerminalKeyValue("");//conditional
        tidModel.setTerminalSpocName(masterModel.getContactPerson()); //optional
        tidModel.setTerminalContactNo(masterModel.getMerchantMobNo());//conditional
        tidModel.setTerminalEmail(masterModel.getMerchantEmail());//conditional
        tidModel.setTerminalRef1("");//optional
        tidModel.setTerminalRef2("");//optional
        tidModel.setTerminalRef3("");//optional
        tidDetailList.add(tidModel);
        return tidDetailList;
    }

    public String getStateName(String countryName, String stateCode) {

        String stateName = "";
        // Read JSON file from the filesystem
        try {
            String jsonData = new String(Files.readAllBytes(Paths.get(stateCodeNamePathStatic)));
            // Parse JSON data
            JSONObject jsonObject = new JSONObject(jsonData);

            // Get the country object using the country code
            JSONObject countryObject = jsonObject.getJSONObject(countryName);

            // Get the states object
            JSONObject statesObject = countryObject.getJSONObject("states");

            // Find and return the state name using the state code
            stateName = statesObject.optString(stateCode, null);

            if (stateName != null) {
                logger.info("State name: ", stateName);
            } else {
                logger.info("State or country code not found.");
            }
        } catch (IOException | JSONException e) {
            logger.error("State or country code not found error :."+e.getMessage());
        }
        return stateName;
    }

    public void getMosambeeConfigData() {
        // Read JSON file from the filesystem
        try {
            String jsonData = new String(Files.readAllBytes(Paths.get(mosambeeConfigFileStatic)));
            // Parse JSON data
            JSONObject jsonObject = new JSONObject(jsonData);

            // Get the country object using the country code
            JSONObject paramNameObject = jsonObject.getJSONObject("mosambeeConfig");

            // Find and return the state name using the state code
            acquirerName = paramNameObject.optString("acquirerName", null);
            tg = paramNameObject.optString("tg", null);
            instrument = paramNameObject.optString("instrument", null);
            instrumentCode = paramNameObject.optString("instrumentCode", null);
        } catch (IOException | JSONException e) {
            logger.error("mosambee config file param name error :."+e.getMessage());
        }
    }
}