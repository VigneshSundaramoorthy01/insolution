package com.isg.mw.mtm.transform.icici;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.CacheSrConfigProperties;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.util.SmartRouteConfigUtil;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.construct.payu.PayUMsgType;
import com.isg.mw.core.model.icici.*;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.pg.ApiTxnModel;
import com.isg.mw.core.model.sr.CacheTargetMerchantMaster;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.model.sr.TargetMerchantMasterModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tc.TargetApiInfo;
import com.isg.mw.core.model.tc.TargetConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.*;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.icici.IciciMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.BankServerException;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.ApiUtil;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

import javax.xml.bind.JAXBException;
import java.io.File;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.isg.mw.core.utils.IsgJsonUtils.removeQuotesAndUnescape;
import static com.isg.mw.mtm.transform.MessageTransformer.identifyTargetTxnTypeConfig;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;

public class IciciMessageTransformation extends BaseMessageTransformation {

    private final Logger logger = LogManager.getLogger(getClass());

    private static final Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig = new HashMap<>();

    private static final HashMap<String, Class> MSG_TYPE_MODEL_CLASS_MAP = new HashMap<>(12);

    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {
        if (!tmmConfig.isEmpty()) {
            return tmmConfig;
        }
        getICICIUpiReq(tmmConfig);
        getICICINbReq(tmmConfig);
        return tmmConfig;
    }

    private void getICICIUpiReq(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.Pay.msgType, "4", "icici.upi.pay.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.VerifyVPA.msgType, "4", "verify.vpa.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.TransactionStatus.msgType, "4", "transaction.status.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.GetAutoCreatedVPA.msgType, "4", "auto.created.vpa.response"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.UpiRefund.msgType, null, "upi.refund.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.UpiReversal.msgType, null, "upi.reversal.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.UpiQR.msgType, "4", "upi.qr.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.CallbackStatus.msgType, "4", "callback.status.request"), fieldsMap);
    }

    private void getICICINbReq(Map<TransactionTypeConfig, Map<Integer, String>> tmmConfig) {
        Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.NbCorpPay.msgType, "1", "icici.nb.corporate.pay.request"), fieldsMap);
        tmmConfig.put(new TransactionTypeConfig(IciciMsgType.NbRetailPay.msgType, "1", "icici.nb.retail.pay.request"), fieldsMap);
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel reqSourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {

        MessageContext msgContext = new MessageContext(reqSourceTmm.getEntityId(), epId, txnTypeConfig.getEpMsgType());
        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
        MessageFormatConfigModel msgFormatModel = msgFormatMap.get(txnTypeConfig.getEpMsgType());
        TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
        Long ownerId = msgFormatModel.getOwnerId();
        SwitchBaseMessageConstruction baseMsgConstruction = getMessageConstruction();
        baseMsgConstruction.setSourceTmm(reqSourceTmm);

        TransactionMessageModel reqTargetTmm = SerializationUtils.clone(reqSourceTmm);
        reqTargetTmm.setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(epId));
        reqTargetTmm.setMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetTmm(reqTargetTmm);

        baseMsgConstruction.setSourceMsgType(reqSourceTmm.getMsgType());
        baseMsgConstruction.setSourceMsgTypeId(reqSourceTmm.getProcessingCode());
        baseMsgConstruction.setTargetMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetMsgTypeId(txnTypeConfig.getProcessingCode());

        //https://apibankingonesandbox.icicibank.com/api/v1/upi2/CollectRequest
        String msgFormat = msgFormatModel.getMsgFormat();
//        Class<?> reqModelClass = MSG_TYPE_MODEL_CLASS_MAP.get(txnTypeConfig.getEpMsgType());
        String payload = null;
        if (TmmConstants.isIciciUpiMsgType(reqSourceTmm.getMsgType())) {
            String rawMsg = null;
            try{
                if(IciciMsgType.Pay.msgType.equalsIgnoreCase(reqSourceTmm.getMsgType())) {
                    CollectUpiRequest reqTxnModel = (CollectUpiRequest) IsgXmlUtils.convertXmlToObject(msgFormat, CollectUpiRequest.class);
                    generateCollectReqData(reqSourceTmm, reqTxnModel);
                    rawMsg = IsgXmlUtils.convertObjectToXml(reqTxnModel, CollectUpiRequest.class);
                    SpringContextBridge.services().getCacheUtil().putSeqNo(reqTxnModel.getSeqNo(),reqSourceTmm.getTransactionId());
                    reqTargetTmm.setTargetTxnId(reqTxnModel.getSeqNo());
                    reqTargetTmm.setMaskedPan(reqSourceTmm.getSmartRouteData().getUpiResponse().getPayerVpa());
                    logger.info("Collect Request {}",rawMsg);
                }else if(IciciMsgType.UpiQR.msgType.equalsIgnoreCase(reqSourceTmm.getMsgType())){
                    UpiQrRequest reqTxnModel = (UpiQrRequest) IsgXmlUtils.convertXmlToObject(msgFormat, UpiQrRequest.class);
                    generateQRData(reqSourceTmm, reqTxnModel);
                    rawMsg = IsgXmlUtils.convertObjectToXml(reqTxnModel, UpiQrRequest.class);
                    SpringContextBridge.services().getCacheUtil().putSeqNo(reqTxnModel.getRefId(),reqSourceTmm.getTransactionId());
                    reqTargetTmm.setTargetTxnId(reqTxnModel.getSeqNo());
                    reqTargetTmm.setMaskedPan(reqSourceTmm.getSmartRouteData().getUpiResponse().getPayerVpa());
                    logger.info("UPI QR Request {}",rawMsg);
                }else if(IciciMsgType.VerifyVPA.msgType.equalsIgnoreCase(reqSourceTmm.getMsgType())){
                    VerifyVpaRequest reqTxnModel = (VerifyVpaRequest) IsgXmlUtils.convertXmlToObject(msgFormat, VerifyVpaRequest.class);
                    generateVerifyVPAData(reqSourceTmm, reqTxnModel);
                    rawMsg = IsgXmlUtils.convertObjectToXml(reqTxnModel, VerifyVpaRequest.class);
                    reqTargetTmm.setTargetTxnId(reqTxnModel.getSeqNo());
                    reqTargetTmm.setMaskedPan(reqSourceTmm.getSmartRouteData().getUpiResponse().getPayerVpa());
                    logger.info("Verify VPA Request {}",rawMsg);
                }else if(IciciMsgType.UpiRefund.msgType.equalsIgnoreCase(reqSourceTmm.getMsgType())
                        || IciciMsgType.UpiReversal.msgType.equalsIgnoreCase(reqSourceTmm.getMsgType()) ){
                    UpiRefundRequest reqTxnModel = (UpiRefundRequest) IsgXmlUtils.convertXmlToObject(msgFormat, UpiRefundRequest.class);
                    generateUpiRefundData(reqSourceTmm, reqTxnModel);
                    rawMsg = IsgXmlUtils.convertObjectToXml(reqTxnModel, UpiRefundRequest.class);
                    SpringContextBridge.services().getCacheUtil().putSeqNo(reqTxnModel.getSeqNo(),reqSourceTmm.getTransactionId());
                    reqTargetTmm.setTargetTxnId(reqTxnModel.getSeqNo());
                    reqTargetTmm.setMaskedPan(reqSourceTmm.getResSmartRouteData() != null ? reqSourceTmm.getResSmartRouteData().getUpiResponse().getPayerVpa():null);
                    logger.info("UPI Refund Request {}",rawMsg);
                }
            }catch (Exception e){
                logger.info("Exception while encrypting data : {} ", e.getMessage());
            }
            msgContext.setRawMsg(rawMsg);
            msgContext.setApiHeaders(getUpiXmlHeaders());
        } else if (TmmConstants.isIciciCorpNBMsgType(reqSourceTmm.getMsgType()) ||
                TmmConstants.isIciciRetailNBMsgType(reqSourceTmm.getMsgType())) {
            TransactionMessageModel.IciciNbData reqTxnModel = IsgJsonUtils.getObjectFromJsonString(msgFormat, TransactionMessageModel.IciciNbData.class);
            ApiUtil.replaceTokens(reqTxnModel, reqSourceTmm, baseMsgConstruction);
            reqTxnModel.setUniqueRefNo(reqSourceTmm.getSmartRouteData().getMerchantTxnRefNo());
            reqTxnModel.setItcRefNo(reqSourceTmm.getTransactionId());
            reqTargetTmm.getSmartRouteData().setReturnUrl(targetAdditionalData.getApiInfo().getIciciUpi().getReturnUrl());
            reqTxnModel.setReturnUrl(targetAdditionalData.getApiInfo().getIciciUpi().getReturnUrl());
            String targetUrl = null;
            if (TmmConstants.isIciciCorpNBMsgType(reqSourceTmm.getMsgType())) {
                targetUrl = targetAdditionalData.getApiInfo().getIciciUpi().getIciciNbCorporateUrl();
                reqTxnModel.setReturnUrl(targetAdditionalData.getApiInfo().getIciciUpi().getReturnUrl()+ "%26mid=" +reqTargetTmm.getCardAcceptorId()+
                        "%26tid=" +reqTargetTmm.getCardAcceptorTerminalId() +
                        "%26merchantTxnRefNo=" +reqTargetTmm.getMerchantTxnRefNo()+
                        "%26transactionId=" +reqTargetTmm.getTransactionId() +
                        "%26payOpt=" +reqTargetTmm.getSmartRouteData().getPayOpt() +
                        "%26linkHashId=" +(reqTargetTmm.getLinkHashId() != null ? reqTargetTmm.getLinkHashId() : ""));
                payload = getQueryString(IsgJsonUtils.getJsonString(reqTxnModel));
                reqTargetTmm.getSmartRouteData().setRedirectUrl(targetUrl + payload);
                logger.info("Icici Corporate Request URL : {}",targetUrl + payload);
            } else if (TmmConstants.isIciciRetailNBMsgType(reqSourceTmm.getMsgType())) {
                targetUrl = targetAdditionalData.getApiInfo().getIciciUpi().getIciciNbRetailUrl();
                String esData = getESData(reqTxnModel,reqTargetTmm);
                logger.info("Icici Retail Request :: {}",esData);
                String aesEncryptES = null;
                try {
                    aesEncryptES = RSAUtil.encryptRetailReq(esData, targetAdditionalData.getApiInfo().getIciciUpi().getRetailMasterKey());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Map<String, Object> nodeMap = new HashMap<>();
                ObjectMapper mapper = new ObjectMapper();
                nodeMap.put("SBMTTYPE", "POST");
                nodeMap.put("MD", reqTxnModel.getModeOfPayment());
                nodeMap.put("PID", reqTxnModel.getPayeeId());
                nodeMap.put("ES", aesEncryptES);
                JsonNode jsonNode = mapper.convertValue(nodeMap, JsonNode.class);
                payload = jsonNode.toString();
                reqTargetTmm.getSmartRouteData().setRedirectUrl(targetUrl + "?IWQRYTASKOBJNAME=" +reqTxnModel.getLogin()
                        + "&BAY_BANKID=" + reqTxnModel.getBayBankId());
                reqTargetTmm.getSmartRouteData().setRedirectData(jsonNode);
            }
            msgContext.setRawMsg(targetUrl + payload);
            msgContext.setApiHeaders(getUpiHeaders());
//            reqTargetTmm.getSmartRouteData().setRedirectData(payload);
        }

        if (reqTargetTmm.getMsgType().equals(IciciMsgType.UpiRefund.msgType)) {
            reqTargetTmm.setResCode("00");
            reqTargetTmm.setDrcrFlag("C");
        } else if (reqTargetTmm.getMsgType().equals(IciciMsgType.UpiReversal.msgType)) {
            reqTargetTmm.setResCode("00");
            reqTargetTmm.setDrcrFlag("R");
        } else {
            reqTargetTmm.setResCode("-1");
            reqTargetTmm.setDrcrFlag("D");
        }
        msgContext.setTransactionMessageModel(reqTargetTmm);
        msgContext.setMessageTransformationConfig(msgTransConfig);
        return msgContext;
    }

    private void generateUpiRefundData(TransactionMessageModel reqSourceTmm, UpiRefundRequest reqTxnModel) {
        MerchantMasterModel masterModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchantMaster(reqSourceTmm.getEntityId(), reqSourceTmm.getCardAcceptorId());

        MapsInfoModel mapsModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchant(reqSourceTmm.getEntityId(),reqSourceTmm.getCardAcceptorId(),reqSourceTmm.getCardAcceptorTerminalId(),null);

        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqSourceTmm.getTarget());

        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqSourceTmm.getCardAcceptorId(),
                reqSourceTmm.getCardAcceptorTerminalId());

        TransactionMessageModel.SmartRouteData resSmartRouteData = reqSourceTmm.getResSmartRouteData();
        reqTxnModel.setAccountProvider(CacheSrConfigProperties.getProperty("pg.upi.account.provider"));
        reqTxnModel.setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(reqSourceTmm.getTxnAmt()));
        reqTxnModel.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
        reqTxnModel.setCurrency(mapsModel.getMerchantCurrencyCode());
        reqTxnModel.setDeviceId(masterModel.getMid());
        reqTxnModel.setMcc(masterModel.getMccCode());
        reqTxnModel.setMTxnId(reqSourceTmm.getTransactionId());
        reqTxnModel.setMid(reqSourceTmm.getCardAcceptorId());
        reqTxnModel.setMobile(masterModel.getMerchantMobNo());
        reqTxnModel.setMsId(masterModel.getMccCode());
        reqTxnModel.setMTid(reqSourceTmm.getCardAcceptorTerminalId());
        String uuid = getRandomUuid();
        reqTxnModel.setOrgId(uuid);
        reqTxnModel.setPayeeAccount(resSmartRouteData.getUpiResponse().getPayerAccount());
        reqTxnModel.setPayeeIfsc(resSmartRouteData.getUpiResponse().getPayerIFSC());
        reqTxnModel.setPayeeVa(resSmartRouteData.getUpiResponse().getPayerVpa());
        reqTxnModel.setPayerVa(targetMerchantMaster.getMerchantVpa());
        reqTxnModel.setProfileId(targetMerchantMaster.getTargetMid());
        reqTxnModel.setRefId(uuid);
        reqTxnModel.setSeqNo("ICI" + uuid);
        reqTxnModel.setSubMerName(masterModel.getMerchantName());
        reqTxnModel.setSubMid(reqSourceTmm.getCardAcceptorId());
    }

    private void generateVerifyVPAData(TransactionMessageModel reqSourceTmm, VerifyVpaRequest reqTxnModel) {
        MerchantMasterModel masterModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchantMaster(reqSourceTmm.getEntityId(), reqSourceTmm.getCardAcceptorId());

        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqSourceTmm.getTarget());

        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqSourceTmm.getCardAcceptorId(),
                reqSourceTmm.getCardAcceptorTerminalId());


        reqTxnModel.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
        reqTxnModel.setDeviceId(masterModel.getMid());
        reqTxnModel.setMobile(masterModel.getMerchantMobNo());
        reqTxnModel.setPayeeName(masterModel.getMerchantName());
        reqTxnModel.setProfileId(targetMerchantMaster.getTargetMid());
        String uuid = getRandomUuid();
        reqTxnModel.setSeqNo("ICI" + uuid);
        reqTxnModel.setVirtualAddress(reqSourceTmm.getSmartRouteData().getUpiResponse().getPayerVpa());
    }

    private void generateCollectReqData(TransactionMessageModel reqSourceTmm, CollectUpiRequest reqTxnModel) {

        MerchantMasterModel masterModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchantMaster(reqSourceTmm.getEntityId(), reqSourceTmm.getCardAcceptorId());

        MapsInfoModel mapsModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchant(reqSourceTmm.getEntityId(),reqSourceTmm.getCardAcceptorId(),reqSourceTmm.getCardAcceptorTerminalId(),null);

        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqSourceTmm.getTarget());
        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqSourceTmm.getCardAcceptorId(),
                reqSourceTmm.getCardAcceptorTerminalId());
        reqTxnModel.setAccountNumber(CacheSrConfigProperties.getProperty("pg.upi.account.no"));
        reqTxnModel.setAccountProvider(CacheSrConfigProperties.getProperty("pg.upi.account.provider"));
        reqTxnModel.setAccountType(CacheSrConfigProperties.getProperty("pg.upi.account.type"));
        reqTxnModel.setAmount(IsgCurrencyConversionUtils.convertPaisaToRupeesFormatted(reqSourceTmm.getTxnAmt()));
        reqTxnModel.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
        reqTxnModel.setCurrency(mapsModel.getMerchantCurrencyCode());
        reqTxnModel.setDeviceId(masterModel.getMid());
        reqTxnModel.setIfsc(CacheSrConfigProperties.getProperty("pg.upi.ifsc"));
        reqTxnModel.setMcc(masterModel.getMccCode());
        reqTxnModel.setMTxnId(reqSourceTmm.getTransactionId());
        reqTxnModel.setMid(reqSourceTmm.getCardAcceptorId());
        reqTxnModel.setMobile(masterModel.getMerchantMobNo());
        reqTxnModel.setMsId(masterModel.getMccCode());
        reqTxnModel.setMTid(reqSourceTmm.getCardAcceptorTerminalId());
        String uuid = getRandomUuid();
        reqTxnModel.setOrgId(uuid);
        reqTxnModel.setPayeeVa(targetMerchantMaster.getMerchantVpa());
        reqTxnModel.setPayerVa(reqSourceTmm.getSmartRouteData().getUpiResponse().getPayerVpa());
        reqTxnModel.setProfileId(targetMerchantMaster.getTargetMid());
        reqTxnModel.setSeqNo("ICI" + uuid);
        reqTxnModel.setSubMerName(masterModel.getMerchantName());
        reqTxnModel.setSubMid(CacheSrConfigProperties.getProperty("upi.sub.Mid"));
    }

    private String getRandomUuid() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().replace("-","");
    }

    private void generateQRData(TransactionMessageModel reqSourceTmm, UpiQrRequest reqTxnModel) {
        MerchantMasterModel masterModel = SpringContextBridge.services().getCacheService().
                validateAndGetMerchantMaster(reqSourceTmm.getEntityId(), reqSourceTmm.getCardAcceptorId());
        String targetId = MessageTransformationContext.getEpIdTargetIdMap().get(reqSourceTmm.getTarget());

        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetId, reqSourceTmm.getCardAcceptorId(),
                reqSourceTmm.getCardAcceptorTerminalId());
        reqTxnModel.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
        reqTxnModel.setDeviceId(masterModel.getMid());
        reqTxnModel.setMobile(masterModel.getMerchantMobNo());
        reqTxnModel.setProfileId(targetMerchantMaster.getTargetMid());

        LocalDateTime myDateObj = LocalDateTime.now().plusMinutes(4);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String format = myFormatObj.format(myDateObj);

        reqTxnModel.setQrValidityEndDatetime(format);
        reqTxnModel.setRefId("EPG" + reqSourceTmm.getTransactionId());
        String uuid = getRandomUuid();
        reqTxnModel.setSeqNo("ICI" + uuid);
    }

    private Map<String, String> getUpiHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "text/plan");
        headers.put("apikey", "RhWG05f48ZVbfRhrTynYVbpkGAAtjzS2");
        headers.put("cache-control", "no-cache");
        headers.put("postman-token", "602a8219-032a-405f-bb65-b93e42e642c6");
        logger.info("UPI Headers : {}", headers);
        return headers;
    }

    private Map<String, String> getUpiXmlHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/xml");
        logger.info("UPI Headers : {}", headers);
        return headers;
    }


    public UpiTxnStatusResponse checkTransactionStatus(TargetConfigModel targetConfigModel, TransactionMessageModel reqSrcTmm,
                                                       TransactionMessageModel originalTmm) throws JAXBException {
        TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(targetConfigModel.getName());
        Set<String> transactionNameSet = MessageTransformationContext.getMsgTypeIdmsgTypeNameMap()
                .get(targetType + "." + reqSrcTmm.getMsgType() + "." + reqSrcTmm.getProcessingCode());
        String txnTypeName = transactionNameSet.stream().findFirst().orElse(null);
        TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(txnTypeName, null, targetConfigModel.getName());
        reqSrcTmm.setTransactionName(txnTypeName);
        CacheServices cacheService = SpringContextBridge.services().getCacheService();
        MerchantMasterModel merchantMasterModel = cacheService.validateAndGetMerchantMaster(targetConfigModel.getEntityId(), reqSrcTmm.getCardAcceptorId());

        CacheTargetMerchantMaster targetMerchantMaster = fetchCacheTargetMerchantMaster(targetConfigModel.getId().toString(), reqSrcTmm.getCardAcceptorId(),reqSrcTmm.getCardAcceptorTerminalId());

        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(targetConfigModel.getName());
        MessageFormatConfigModel msgFormatModel = msgFormatMap.get(txnTypeConfig.getEpMsgType());
        String msgFormat = msgFormatModel.getMsgFormat();

        String targetUrl = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi().getCheckTxnStatusUrl();
        Object res = null;
        String seqNo=null;
        try {
            TransactionStatusRequest txnStatusReq = (TransactionStatusRequest)IsgXmlUtils.convertXmlToObject(msgFormat, TransactionStatusRequest.class);
            txnStatusReq.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
            txnStatusReq.setDeviceId(reqSrcTmm.getCardAcceptorId());
            txnStatusReq.setMobile(merchantMasterModel.getMerchantMobNo());
            txnStatusReq.setOrigSeqNo(originalTmm != null ? originalTmm.getTargetTxnId() : reqSrcTmm.getTargetTxnId());
            txnStatusReq.setProfileId(targetMerchantMaster.getTargetMid());
            seqNo = getRandomUuid();
            txnStatusReq.setSeqNo("ICI"+seqNo);
            String payload = IsgXmlUtils.convertObjectToXml(txnStatusReq, TransactionStatusRequest.class);
            res = callApiUsingWebClient(payload, targetUrl, getUpiXmlHeaders());
        }catch (Exception e){
            logger.info("Exception while Calling Txn Status Api : {} ", e.getMessage());
        }
        logger.info("Response For Txn Status Api : {} ",res);
        UpiTxnStatusResponse upiResponse = null;
//        String upiResFromFile = getUpiResFromFile(reqSrcTmm.getMsgType());
//        res = upiResFromFile.replace("#targetTxnId#",seqNo);
        if(res != null) {
            String[] split = String.valueOf(res).split("##");
            String response = split[1];
            upiResponse =(UpiTxnStatusResponse) IsgXmlUtils.convertXmlToObject(response, UpiTxnStatusResponse.class);
        }
        return upiResponse;
    }


    public String  getUpiResFromFile(String msgType){
        ObjectMapper parser = new ObjectMapper();
        String res;
        try {
            Object object = parser.readValue(new File(MTMProperties.getProperty("upi.txn.response")), Object.class);
            LinkedHashMap<String, String> map = (LinkedHashMap<String, String>) object;
            res = map.get(msgType);
        } catch (Exception e) {
            res = e.getMessage();
        }
        return res;
    }


    public String getDecryptedMsg(String res) {
        String privateKeyPath = MTMProperties.getProperty("decryption.key.provider.path.isg.icici.upi");
        PrivateKey privateKeyFromJKS;
        String decrypt = null;
        try {
            UpiKeyModel upiKeyModel = RSAUtil.readProviders(new File(privateKeyPath));
            privateKeyFromJKS = RSAUtil.getPivateKeyFromJKS(upiKeyModel.getKeyStorePath(), upiKeyModel.getKeyStoreCred(), upiKeyModel.getKeyId(), upiKeyModel.getKeyStoreCred());
            decrypt = RSAUtil.decrypt(res, privateKeyFromJKS);

        } catch (Exception e) {
            logger.info("Exception while encrypting data : {} ", e.getMessage());
        }
        logger.info("Decrypted msg : {}", decrypt);
        return decrypt;
    }


    public CheckVpaRequest buildCheckVpaRequest(MerchantMasterModel merchantMasterModel) {
        CheckVpaRequest upiRequest = new CheckVpaRequest();
        upiRequest.setDeviceId(merchantMasterModel.getMid());
        upiRequest.setMessageType("1200");
        upiRequest.setMobile(merchantMasterModel.getMerchantMobNo());
        if("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            upiRequest.setProcCode(CacheSrConfigProperties.getProperty("pg.upi.check.vpa.proc.code"));
            upiRequest.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
            upiRequest.setVirtualAddress("IBMS" + merchantMasterModel.getTid() + "@icici");
        }else if("POS".equalsIgnoreCase(merchantMasterModel.getIntegrationType())){
            upiRequest.setProcCode(CacheSrConfigProperties.getProperty("pos.upi.check.vpa.proc.code"));
            upiRequest.setChannelCode(CacheSrConfigProperties.getProperty("pos.upi.channel.code"));
            upiRequest.setVirtualAddress("ibkPOS."+merchantMasterModel.getTid()+"@icici");
        }
        String seqNo = getRandomUuid();
        upiRequest.setSeqNo("ICI" + seqNo);
        upiRequest.setUpi("check-va");
        return upiRequest;
    }

    public StoreAccountDetailsRequest buildStoreAccountDetailsRequest(MerchantMasterModel merchantMasterModel, UpiResponse upiResponse) {
        StoreAccountDetailsRequest storeAccountRequest = new StoreAccountDetailsRequest();
        if ("PG".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            storeAccountRequest.setAccountNumber(CacheSrConfigProperties.getProperty("pg.upi.account.no"));
            storeAccountRequest.setAccountProvider(CacheSrConfigProperties.getProperty("pg.upi.account.provider"));
            storeAccountRequest.setAccountType(CacheSrConfigProperties.getProperty("pg.upi.account.type"));
            storeAccountRequest.setBrand(CacheSrConfigProperties.getProperty("pg.upi.bank.name"));
            storeAccountRequest.setFranchise(CacheSrConfigProperties.getProperty("pg.upi.bank.name"));
            storeAccountRequest.setIfsc(CacheSrConfigProperties.getProperty("pg.upi.ifsc"));
            storeAccountRequest.setProcCode(CacheSrConfigProperties.getProperty("pg.upi.acc.details.proc.code"));
            storeAccountRequest.setSkipRefIdValidation("N");
            storeAccountRequest.setChannelCode(CacheSrConfigProperties.getProperty("pg.upi.channel.code"));
            storeAccountRequest.setVirtualAddress(upiResponse.getPayeeVpa());
            storeAccountRequest.setMerchantGenre("ONLINE");
        } else if ("POS".equalsIgnoreCase(merchantMasterModel.getIntegrationType())) {
            storeAccountRequest.setAccountNumber(CacheSrConfigProperties.getProperty("pos.upi.account.no"));
            storeAccountRequest.setAccountProvider(CacheSrConfigProperties.getProperty("pos.upi.account.provider"));
            storeAccountRequest.setAccountType(CacheSrConfigProperties.getProperty("pos.upi.account.type"));
            storeAccountRequest.setBrand(CacheSrConfigProperties.getProperty("pos.upi.bank.name"));
            storeAccountRequest.setFranchise(CacheSrConfigProperties.getProperty("pos.upi.bank.name"));
            storeAccountRequest.setIfsc(CacheSrConfigProperties.getProperty("pos.upi.ifsc"));
            storeAccountRequest.setProcCode(CacheSrConfigProperties.getProperty("pos.upi.acc.details.proc.code"));
            storeAccountRequest.setSkipRefIdValidation("N");
            storeAccountRequest.setChannelCode(CacheSrConfigProperties.getProperty("pos.upi.channel.code"));
            storeAccountRequest.setVirtualAddress(upiResponse.getPayeeVpa());
        }
        //POS-PG COMMON
        storeAccountRequest.setDeviceId(merchantMasterModel.getTid());
        storeAccountRequest.setMobile(merchantMasterModel.getMerchantMobNo());
        String seqNo = getRandomUuid();
        storeAccountRequest.setSeqNo("ICI" + seqNo);
        storeAccountRequest.setMmid("");
        storeAccountRequest.setProfileId("");
        storeAccountRequest.setName(merchantMasterModel.getMerchantName());
        storeAccountRequest.setDefaultCredit("D");
        storeAccountRequest.setDefaultDebit("N");

        //PG FIELDS
        storeAccountRequest.setAllowPaymentFromCc("N");
        storeAccountRequest.setFlag("StaticQR");
        storeAccountRequest.setLegal("NA");
        storeAccountRequest.setMcc(merchantMasterModel.getMccCode());
        storeAccountRequest.setMerchantClass("LARGE");
        storeAccountRequest.setMerchantType("ENTITY");
        storeAccountRequest.setMessageType("1200");
        storeAccountRequest.setMid(merchantMasterModel.getMid());
        storeAccountRequest.setMsId(merchantMasterModel.getMccCode());
        storeAccountRequest.setMTid(merchantMasterModel.getTid());
        String ownershipType = getOwnershipTypeByConsCode(merchantMasterModel.getOwnershipType(), "upi");
        storeAccountRequest.setOwnershipType(ownershipType);
        storeAccountRequest.setUpi("store-merchant-acc-details");
        storeAccountRequest.setCcSmallTxnFlag("N");
        storeAccountRequest.setPpiSmallTxnFlag("N");
        storeAccountRequest.setStopSms("Y");
        return storeAccountRequest;
    }


    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new IciciMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor srcProcessor) {
        return null;
    }

    @Override
    public TransactionMessageModel parseResponse(String responseBody, TransactionMessageModel tmm, String epId,
                                                 TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        int status = 0;
        String response = null;
        responseBody = removeQuotesAndUnescape(responseBody);
        String[] split = responseBody.split(API_RESPONSE_SEPARATOR);
        status = Integer.parseInt(split[0]);
        response = split[1];
        TransactionMessageModel resSrcTmm = null;
        UpiResponse upiResponse = null;
        try {
            switch (status) {
                case 200:
                    if (TmmConstants.isIciciCorpNBMsgType(tmm.getMsgType()) ||
                            TmmConstants.isIciciRetailNBMsgType(tmm.getMsgType())) {
//                        resSrcTmm = getSuccessResSourceTmmForNB(iciciUpiSuccessResponse, tmm);
                        resSrcTmm.setIciciNbCorporateUrl("http://10.16.169.253:8184/iciciagp/WebPages/Corporateresponse.action?&&BID=0471285566&PRN=41270000&AMT=1.00&ITC=41270000&PAID=Y&CRN=INR");
                    } else {
                        upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(response,UpiResponse.class);
                        resSrcTmm = getSuccessResSourceTmmForUpi(upiResponse,null, tmm);
                    }
                    break;
                case 500:
                    upiResponse = (UpiResponse) IsgXmlUtils.convertXmlToObject(response,UpiResponse.class);
                    resSrcTmm = getSuccessResSourceTmmForUpi(upiResponse,null, tmm);
                    break;
            }

            logger.trace("ICICI UPI Response: {} , {}", null,upiResponse);
        } catch (Exception e) {
            logger.error("", e);
        }
        return resSrcTmm;
    }

//    private TransactionMessageModel getSuccessResSourceTmmForNB(IciciUpiResponse iciciUpiRes, TransactionMessageModel reqSrcTmm) {
//        TransactionMessageModel resSourceTmm = new TransactionMessageModel();
//        resSourceTmm.setUpiResponse(iciciUpiRes);
//        setCommonResponseFields(reqSrcTmm, resSourceTmm);
//        return resSourceTmm;
//    }

    public static TransactionMessageModel getSuccessResSourceTmmForUpi(UpiResponse upiResponse,UpiCallbackRequest callbackRequest, TransactionMessageModel reqSrcTmm) {
        TransactionMessageModel resSourceTmm = (reqSrcTmm == null ? new TransactionMessageModel() : SerializationUtils.clone(reqSrcTmm));
        TransactionMessageModel.SmartRouteData smartRouteData = resSourceTmm.getSmartRouteData();
        setIciciUpiData(upiResponse, callbackRequest, resSourceTmm);
        smartRouteData.setUpiResponse(upiResponse);
        setCommonResponseFields(reqSrcTmm, resSourceTmm);
        resSourceTmm.setUpiResponse(upiResponse);
        resSourceTmm.setSmartRouteData(smartRouteData);
        resSourceTmm.setOriginalBankRRN(upiResponse.getBankRRN());
        resSourceTmm.setRetrievalRefNo(upiResponse.getBankRRN());
        resSourceTmm.setTargetTxnId(upiResponse.getSeqNo());
        if (!(IciciMsgType.UpiRefund.msgType.equals(reqSrcTmm.getMsgType()) || IciciMsgType.UpiReversal.msgType.equals(reqSrcTmm.getMsgType()))) {
            resSourceTmm.setResCode("-1");
        }
        return resSourceTmm;
    }

    private static void setIciciUpiData(UpiResponse upiResponse,UpiCallbackRequest upiCallbackRequest, TransactionMessageModel resSourceTmm) {
        if (upiCallbackRequest != null) {
            upiResponse.setSeqNo(upiCallbackRequest.getOriginalTxnId());
            upiResponse.setBankRRN(upiCallbackRequest.getRrn());
            upiResponse.setSuccess(upiCallbackRequest.getTxnStatus());
            upiResponse.setAccountNumber(upiCallbackRequest.getPayer().getAccountNo());
            upiResponse.setPayerAccount(upiCallbackRequest.getPayer().getAccountNo());
            upiResponse.setPayerVpa(upiCallbackRequest.getPayer().getVa());
            upiResponse.setPayerMobile(upiCallbackRequest.getPayer().getMobile());
            upiResponse.setAccountType(upiCallbackRequest.getPayer().getAccountType());
            upiResponse.setPayerName(upiCallbackRequest.getPayer().getName());
            upiResponse.setPayerIFSC(upiCallbackRequest.getPayer().getIfsc());
            upiResponse.setPayeeVpa(upiCallbackRequest.getPayee().getVa());
            upiResponse.setPayeeName(upiCallbackRequest.getPayee().getName());
            upiResponse.setTxnStatus(upiCallbackRequest.getTxnStatus());
            if("SUCCESS".equalsIgnoreCase(upiCallbackRequest.getTxnStatus())) {
                upiResponse.setActCode("0");
            }
        }
    }

    private static void setCommonResponseFields(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSourceTmm) {
        resSourceTmm.setConnectionType(ConnectionType.API);
        resSourceTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resSourceTmm.setSourceProcessor(SourceProcessor.SMART_ROUTE);
        resSourceTmm.setTransactionId(reqSrcTmm.getTransactionId());
        resSourceTmm.setHashedTransactionId(reqSrcTmm.getHashedTransactionId());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setMsgType(reqSrcTmm.getMsgType());
        resSourceTmm.setProcessingCode(reqSrcTmm.getProcessingCode());
        resSourceTmm.setSourceProcessor(reqSrcTmm.getSourceProcessor());
        resSourceTmm.setResponseReceivedTime(OffsetDateTime.now());
        resSourceTmm.setAquirerCountryCode(reqSrcTmm.getAquirerCountryCode());
        resSourceTmm.setAquirerIdCode(reqSrcTmm.getAquirerIdCode());
        resSourceTmm.setCardAcceptorId(reqSrcTmm.getCardAcceptorId());
        resSourceTmm.setCardAcceptorTerminalId(reqSrcTmm.getCardAcceptorTerminalId());
        resSourceTmm.setEncryptedExpirationDate(reqSrcTmm.getEncryptedExpirationDate());
        resSourceTmm.setEntityId(reqSrcTmm.getEntityId());
        resSourceTmm.setMerchantType(reqSrcTmm.getMerchantType());
        resSourceTmm.setPosEntryMode(reqSrcTmm.getPosEntryMode());
        resSourceTmm.setResponseSentTime(OffsetDateTime.now());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setTxnAmt(reqSrcTmm.getTxnAmt());
        resSourceTmm.setDrcrFlag(reqSrcTmm.getDrcrFlag());
        resSourceTmm.setTerminalStan(reqSrcTmm.getTerminalStan());
        resSourceTmm.setStan(reqSrcTmm.getStan());
        resSourceTmm.setEncryptedPan(reqSrcTmm.getEncryptedPan());
        resSourceTmm.setMaskedPan(reqSrcTmm.getMaskedPan());
        resSourceTmm.setCardAcceptorInfo(reqSrcTmm.getCardAcceptorInfo());
        resSourceTmm.setForwardingInstIdCode(reqSrcTmm.getForwardingInstIdCode());
        resSourceTmm.setSettlementCurrenyCode(reqSrcTmm.getSettlementCurrenyCode());
        resSourceTmm.setSource(reqSrcTmm.getTarget());
        resSourceTmm.setTarget(reqSrcTmm.getSource());
        resSourceTmm.setTransactionName(reqSrcTmm.getTransactionName().replace("request", "response"));
        resSourceTmm.setTargetType(reqSrcTmm.getTargetType());
        resSourceTmm.setPgData(reqSrcTmm.getPgData());
        resSourceTmm.setTerminalBatchNo(reqSrcTmm.getTerminalBatchNo());
        resSourceTmm.setResCode("00");
        resSourceTmm.setTxnCurrencyCode(reqSrcTmm.getTxnCurrencyCode());
    }

    public TransactionMessageModel parseRetailResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TargetApiInfo.IciciUpi iciciUpi = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi();
        String retailRes = null;
        logger.info("Icici Retail Respnse : {} ",apiTxnModel.getEs());
        try {
            retailRes = RSAUtil.decryptRetailRes(apiTxnModel.getEs(), iciciUpi.getRetailMasterKey());
        }catch (Exception e){
            logger.info("Error While Decrypting Icici Retail Response : {}",e.getMessage());
        }
        logger.info("Icici Retail Decrypted Respnse : {} ",retailRes);
        TransactionMessageModel resTgtTmm = apiTxnModel.buildTmm();
        TransactionMessageModel.SmartRouteData smartRouteData = resTgtTmm.getSmartRouteData();
        String[] pipeSplit = retailRes.split("&");
        for (String equalsSplit : pipeSplit) {
            String[] resKeyVal = equalsSplit.split("=");
            switch (resKeyVal[0]) {
                case "PRN":
                    smartRouteData.getIciciRetailData().setPrn(resKeyVal[1]);
                    break;
                case "ITC":
                    smartRouteData.getIciciRetailData().setItc(resKeyVal[1]);
                    resTgtTmm.setTransactionId(resKeyVal[1]);
                    break;
                case "AMT":
                    smartRouteData.getIciciRetailData().setAmount(resKeyVal[1]);
                    resTgtTmm.setTxnAmt(IsgCurrencyConversionUtils.convertRupeesToPaisa(resKeyVal[1]));
                    break;
                case "CRN":
                    smartRouteData.getIciciRetailData().setCrn(resKeyVal[1]);
                    break;
                case "PAID":
                    smartRouteData.getIciciRetailData().setPaid(resKeyVal[1]);
                    if(resKeyVal[1].equalsIgnoreCase("Y")){
                        resTgtTmm.setResCode("00");
                        resTgtTmm.setDrcrFlag("D");
                    }else {
                        resTgtTmm.setResCode("01");
                        apiTxnModel.setError("01");
                        resTgtTmm.setDrcrFlag("N");
                    }
                    break;
                case "BID":
                    smartRouteData.getIciciRetailData().setBid(resKeyVal[1]);
                    resTgtTmm.setTargetTxnId(resKeyVal[1]);
                    break;
            }
        }
        resTgtTmm.setTarget(targetConfigModel.getName());
        resTgtTmm.setTransactionName("icici.nb.retail.pay.response");
        resTgtTmm.setResponseReceivedTime(OffsetDateTime.now());
        return resTgtTmm;
    }

    public TransactionMessageModel parseCorporateResponse(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TransactionMessageModel resTgtTmm = apiTxnModel.buildTmm();
        resTgtTmm.setTransactionId(apiTxnModel.getTransactionId());
        TransactionMessageModel.SmartRouteData smartRouteData = resTgtTmm.getSmartRouteData();
        logger.info("Icici Corporate Response with Amount : {} ,Transaction Id: {} ,Paid : {} ",apiTxnModel.getCorporateAmount(),apiTxnModel.getItc(),apiTxnModel.getCorporatePaid());
        smartRouteData.getIciciRetailData().setPrn(apiTxnModel.getPrn());
        smartRouteData.getIciciRetailData().setItc(apiTxnModel.getItc());
        String amount = apiTxnModel.getCorporateAmount();
        if (!StringUtils.isBlank(amount)) {
            smartRouteData.getIciciRetailData().setAmount(amount);
            resTgtTmm.setTxnAmt(IsgCurrencyConversionUtils.convertRupeesToPaisa(amount));
        }
        smartRouteData.getIciciRetailData().setCrn(apiTxnModel.getCrn());
        String paid = apiTxnModel.getCorporatePaid();
        smartRouteData.getIciciRetailData().setPaid(paid);
        if (!StringUtils.isBlank(paid) && paid.equalsIgnoreCase("Y")) {
            resTgtTmm.setResCode("00");
            resTgtTmm.setDrcrFlag("D");
        } else {
            resTgtTmm.setResCode("01");
            apiTxnModel.setError("01");
            resTgtTmm.setDrcrFlag("N");
        }
        smartRouteData.getIciciRetailData().setBid(apiTxnModel.getBid());
        resTgtTmm.setTargetTxnId(apiTxnModel.getBid());
        resTgtTmm.setTarget(targetConfigModel.getName());
        resTgtTmm.setTransactionName("icici.nb.corporate.pay.response");
        resTgtTmm.setResponseReceivedTime(OffsetDateTime.now());
        return resTgtTmm;
    }


    public Object callApiUsingWebClient(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Request Body: {}", url, body);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new RuntimeException("Target is not responding");
        }
        //To test TimeOut Reversal
        /*if(url.equals("https://apitest.cybersource.com/pts/v2/payments")){
            throw new TargetNoResponseException("Target is not responding");
        }*/
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }

    public Object callApiUsingProxyWebClient(String body, String url, Map<String, String> headers) {
        logger.trace("Invoking API through Web Client: {}, with Request Body: {}", url, body);
        String host = MTMProperties.getProperty("icici.proxy.host");
        int port = Integer.parseInt(MTMProperties.getProperty("icici.proxy.port"));
        logger.info("Proxy Host ::"+ host + " Proxy Port :: " + port);
        HttpClient httpClient = HttpClient.create().tcpConfiguration(tcpClient -> tcpClient.proxy(proxy -> proxy.type(ProxyProvider.Proxy.HTTP))
                .host(host)
                .port(port));
        ReactorClientHttpConnector reactorClientHttpConnector = new ReactorClientHttpConnector(httpClient);
        WebClient.Builder webClient = SpringContextBridge.services().getWebClient().clientConnector(reactorClientHttpConnector);
        ClientResponse block = webClient.build()
                .post()
                .uri(url)
                .headers(headers1 -> {
                    headers.forEach((key, value) -> headers1.put(key, Collections.singletonList(value)));
                })
                .body(Mono.just(body), String.class)
                .exchange()
                .block(Duration.ofSeconds(20));
        HttpStatus httpStatus = block.statusCode();
        if (httpStatus == HttpStatus.BAD_GATEWAY) {
            throw new RuntimeException("Target is not responding");
        }
        //To test TimeOut Reversal
        /*if(url.equals("https://apitest.cybersource.com/pts/v2/payments")){
            throw new TargetNoResponseException("Target is not responding");
        }*/
        String res = httpStatus.value() + API_RESPONSE_SEPARATOR + block.bodyToMono(String.class).block();
        logger.trace("API Response status: {}, Body: {}", httpStatus, res);
        return res;
    }


    public static String getQueryString(String unparsedString) {
        StringBuilder sb = new StringBuilder();
        JSONObject json = new JSONObject(unparsedString);
        Iterator<String> keys = json.keys();
        sb.append("?"); //start of query args
        while (keys.hasNext()) {
            String key = keys.next();
            sb.append(key);
            sb.append("=");
            sb.append(json.get(key));
            sb.append("&"); //To allow for another argument.

        }
        int i = sb.toString().lastIndexOf("&");
        return sb.deleteCharAt(i).toString();
    }

    public static String getESData(TransactionMessageModel.IciciNbData reqTxnModel, TransactionMessageModel reqTargetTmm) {
        StringBuilder sb = new StringBuilder();
        sb.append("PRN=" + (StringUtils.isBlank(reqTxnModel.getUniqueRefNo()) ? "" : reqTxnModel.getUniqueRefNo()))
                .append("&ITC=" + (StringUtils.isBlank(reqTxnModel.getItcRefNo()) ? "" : reqTxnModel.getItcRefNo()))
                .append("&AMT=" + (StringUtils.isBlank(reqTxnModel.getAmount()) ? "" : reqTxnModel.getAmount()))
                .append("&CRN=INR")
                .append("&RU=" + (StringUtils.isBlank(reqTxnModel.getReturnUrl()) ? "" : reqTxnModel.getReturnUrl() +
                        "&mid=" +reqTargetTmm.getCardAcceptorId()+
                        "&tid=" +reqTargetTmm.getCardAcceptorTerminalId() +
                        "&merchantTxnRefNo=" +reqTargetTmm.getMerchantTxnRefNo()+
                        "&transactionId=" +reqTargetTmm.getTransactionId() +
                        "&payOpt=" +reqTargetTmm.getSmartRouteData().getPayOpt()+
                        "&linkHashId=" +(reqTargetTmm.getLinkHashId() != null ? reqTargetTmm.getLinkHashId() : "")))
                .append("&payopt=" + (StringUtils.isBlank(reqTxnModel.getPayOpt()) ? "" : reqTxnModel.getPayOpt()))
                .append("&redeemgc=" + (StringUtils.isBlank(reqTxnModel.getRedeeMgc()) ? "" : reqTxnModel.getRedeeMgc()))
                .append("&gcertno=" + (StringUtils.isBlank(reqTxnModel.getGcertNo()) ? "" : reqTxnModel.getGcertNo()))
                .append("&CG=" + (StringUtils.isBlank(reqTxnModel.getGatewayParameter()) ? "" : reqTxnModel.getGatewayParameter()));
        return sb.toString();
    }

    public void validateResponseErrorCode(ApiTxnModel apiTxnModel, TargetConfigModel targetConfigModel) {
        TargetApiInfo.IciciUpi icici = targetConfigModel.getAdditionalData().getApiInfo().getIciciUpi();
        if(icici != null && !StringUtils.isBlank(icici.getTechErrorCodes())){
            String[] split = icici.getTechErrorCodes().split(",");
            Set<String> techErrorCodes = Arrays.stream(split).collect(Collectors.toSet());
            boolean value = techErrorCodes.contains(apiTxnModel.getError());
            if (value) {
                throw new BankServerException("Deliberately failed the transaction due to the bank server issue : ",targetConfigModel.getEntityId(),apiTxnModel.getMid(),apiTxnModel.getMerchantTxnRefNo());
            }
        }
    }



}