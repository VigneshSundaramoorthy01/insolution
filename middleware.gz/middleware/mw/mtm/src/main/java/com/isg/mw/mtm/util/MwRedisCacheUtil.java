package com.isg.mw.mtm.util;

import com.isg.mw.core.model.bi.BillingCurrencyModel;
import com.isg.mw.core.model.bi.RateLookupModel;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.TargetType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import static com.isg.mw.cache.mgmt.config.CacheConstants.KEY_SEPERATE;

import java.time.Duration;
import java.util.Map;

@Configuration
public class MwRedisCacheUtil {

    private HashOperations<String, String, Map<HsmCommandArg, String>> terminalBdkKeyInfoHashOps;

    private HashOperations<String, TargetType, String> targetDynamicKeyOps;
    
    private final ValueOperations<String, RateLookupModel> dccRateLookUpOps;
    
    private final ValueOperations<Integer, BillingCurrencyModel> billingCurrenciesOps;
    

    private RedisAtomicInteger atomicInteger;


    @Autowired
    public MwRedisCacheUtil(RedisTemplate<String, Map<HsmCommandArg, String>> hsmRedisTemplate,
                            RedisTemplate<String, Map<TargetType, String>> targetDynamicKeyTemplate,
                            RedisTemplate<String, RateLookupModel> dccRateLookUpTemplate,
                            RedisTemplate<Integer, BillingCurrencyModel> billingCurrenciesTemplate,
                            RedisTemplate<String, Integer> atomicIntegerTemplate) {
        this.terminalBdkKeyInfoHashOps = hsmRedisTemplate.opsForHash();
        this.targetDynamicKeyOps = targetDynamicKeyTemplate.opsForHash();
        this.dccRateLookUpOps = dccRateLookUpTemplate.opsForValue();
        this.billingCurrenciesOps = billingCurrenciesTemplate.opsForValue();
        this.atomicInteger = new RedisAtomicInteger("stanCounter", atomicIntegerTemplate.getConnectionFactory());
    }

    /**
     * @param terminalBdkMapKey combination of ENTITYID_TERMINAL_BDK
     *                          eg. 1234_TERMINAL_BDK
     * @param terminalId        Terminal id
     * @param keyMap            BDK/IPEK key data for the terminal
     */
    public void putTerminalBdkKeyData(String terminalBdkMapKey, String terminalId, Map<HsmCommandArg, String> keyMap) {
        terminalBdkKeyInfoHashOps.put(terminalBdkMapKey, terminalId, keyMap);
    }

    public Map<HsmCommandArg, String> getTerminalBdkKeyData(String terminalBdkMapKey, String terminalId) {
        Map<String, Map<HsmCommandArg, String>> entries = terminalBdkKeyInfoHashOps.entries(terminalBdkMapKey);
        return entries.get(terminalId);
    }

    /**
     * @param targetDynamicKey combination of ENTITYID_HSMVENDOR_DYNAMIC_KEY
     *                         eg. 1234_THALES_DYNAMIC_KEY
     * @param targetType       Visa/Master/Rupay
     * @param value            value
     */
    public void putTargetDynamicKeyData(String targetDynamicKey, TargetType targetType, String value) {
        targetDynamicKeyOps.put(targetDynamicKey, targetType, value);
    }

    public RateLookupModel getDccRateLookUpData(String entityId, Integer dccCurrencyCode) {
        return this.dccRateLookUpOps.get(entityId + KEY_SEPERATE + dccCurrencyCode);
    }
    
    public void setDccRateLookUpData(String entity, Integer dccCurrencyCode, RateLookupModel rateLookUp) {
    	dccRateLookUpOps.set(entity  + KEY_SEPERATE +  dccCurrencyCode, rateLookUp, Duration.ofDays(1));
    }
    
    public void setBillingCurrenciesData(Integer dccCurrencyCode, BillingCurrencyModel billingCurrency) {
    	billingCurrenciesOps.set(dccCurrencyCode, billingCurrency, Duration.ofDays(1));
    }
    
    public BillingCurrencyModel getBillingCurrenciesData(Integer dccCurrencyCode) {
        return this.billingCurrenciesOps.get(dccCurrencyCode);
    }
    
    public RedisAtomicInteger getAtomicInteger() {
        return this.atomicInteger;
    }
    
    public String getTargetDynamicKeyData(String hashKey, TargetType targetType) {
        Map<TargetType, String> entries = targetDynamicKeyOps.entries(hashKey);
        return entries.get(targetType);
    }
    
    public void removeTargetDynamicKeyData(String hashKey, TargetType targetType) {
       targetDynamicKeyOps.delete(hashKey, targetType);
    }

}
