package com.isg.mw.mtm.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class ApiUtil {

    private ApiUtil() {
    }

    private static final Logger logger = LogManager.getLogger(ApiUtil.class);

    public static void replaceTokens(Object tokenObject, Object dataObject) {
        replaceTokens(tokenObject, dataObject, null);
    }

    public static void replaceTokens(Object tokenObject, Object dataObject, Object constructionObject) {
        Method[] tokenObjDeclaredMethods = tokenObject.getClass().getDeclaredMethods();
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        for (Method tokenMethodObj : tokenObjDeclaredMethods) {
            if (tokenMethodObj.getModifiers() == Modifier.PUBLIC && tokenMethodObj.getName().startsWith("get")) {
                try {
                    Object methodStrObj = tokenMethodObj.invoke(tokenObject);
                    if (methodStrObj instanceof String) {
                        String tokenMethodStr = (String) methodStrObj;
                        setTokenData(tokenObject, dataObject, tokenMethodObj, tokenMethodStr, lookup, constructionObject);
                    } else if (methodStrObj != null) {
                        replaceTokens(methodStrObj, dataObject, constructionObject);
                    }
                } catch (IllegalAccessException | InvocationTargetException e) {
                    logger.error("error", e);
                }
            }
        }
    }

    private static void setTokenData(Object tokenObject, Object dataObject, Method tokenMethodObj, String tokenMethodStr, MethodHandles.Lookup lookup, Object constructionObject) {
        if (tokenMethodStr.startsWith("#") && tokenMethodStr.endsWith("#")) {
            String dataObjMethodName = tokenMethodStr.substring(1).substring(0, tokenMethodStr.length() - 2);
            String setMethodOfTokenObj = tokenMethodObj.getName().replace("get", "set");
            String dataObjMethodVal = null;
            String dataObjInnerMethodName;
            //e.g "getPgData.getAvv"
            Object currentObj = dataObject;
            while (dataObjMethodName.contains(".")) {
                dataObjInnerMethodName = dataObjMethodName.substring(0, dataObjMethodName.indexOf("."));
                //Get method
                currentObj = invokeGetMethod(currentObj, dataObjInnerMethodName, lookup);
                dataObjMethodName = dataObjMethodName.replace(dataObjInnerMethodName + ".", "");
            }
            if (dataObjMethodName.startsWith("get")) {
                //Get value from TMM field
                dataObjMethodVal = (String) invokeGetMethod(currentObj, dataObjMethodName, lookup);
            } else if (dataObjMethodName.startsWith("set")) {
                // Get value from construction object
                dataObjMethodVal = (String) invokeGetMethod(constructionObject, dataObjMethodName, lookup);
            }
            //Set value to Pg model
            invokeSetMethod(tokenObject, setMethodOfTokenObj, dataObjMethodVal, lookup, void.class, String.class);
        }
    }

    private static void invokeSetMethod(Object obj, String methodName, String setValue, MethodHandles.Lookup lookup,
                                        Class<?> returnType, Class<?> paramType) {
        MethodType methodType = MethodType.methodType(returnType, paramType);
        try {
            MethodHandle methodHandle = lookup.findVirtual(obj.getClass(), methodName, methodType);
            methodHandle.invoke(obj, setValue);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public static Object invokeGetMethod(Object obj, String methodName, MethodHandles.Lookup lookup) {
        try {
            Method method = obj.getClass().getMethod(methodName);
            MethodHandle methodHandle = lookup.unreflect(method);
            return methodHandle.invoke(obj);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }
}
