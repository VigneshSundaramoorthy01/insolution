package com.isg.mw.mtm.construct.rupay;

import com.isg.mw.core.utils.TlvDataList;
import com.isg.mw.mtm.construct.MessageConstructionHelper;
import com.isg.mw.mtm.exception.InvalidTxnException;
import com.isg.mw.mtm.exception.MessageConstructionException;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmConstants;
import com.isg.mw.mtm.util.MtmUtil;
import org.apache.commons.lang3.StringUtils;

import java.time.ZoneId;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;

public class BqrRupayMessageConstruction extends RupayMessageConstruction {

	/**
	 * 1.<br>
	 * ISO8583 -1987, AS2805 - Secondary bitmap <br>
	 * Base24, ISG, XML - Bit map
	 */
	@Override
	public void setBitMap(int fieldNo) {
		// method has been intentionally left blank, actual bitmap value will be set by
		// JPOS
	}

	/**
	 * 2.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
	 * Account Number
	 */
	@Override
	public void setPan(int fieldNo) {
		String pan = this.sourceTmm.getPan();
		this.targetTmm.setPan(pan);
		this.baseMessage.set(fieldNo, pan);
	}

	/**
	 * 3. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
	 * <br>
	 * mPOS - Transaction Type
	 */
	@Override
	public void setProcessingCode(int fieldNo) {
		this.targetTmm.setProcessingCode(this.targetMsgTypeId);
		this.baseMessage.set(fieldNo, this.targetMsgTypeId);
	}

	/**
	 * 4. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
	 * CyberSource API - AuthorizedAmount
	 */
	@Override
	public void setTxnAmt(int fieldNo) {
		String txnAmt = this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0";
		txnAmt = StringUtils.leftPad(txnAmt, 4, "0");
		this.targetTmm.setTxnAmt(txnAmt);
		this.baseMessage.set(fieldNo, txnAmt);
	}

	/**
	 * 5.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
	 */

	/**
	 * 6.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
	 */

	/**
	 * 7. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setTransmissionTime(int fieldNo) {

		String transmissionTime = null;
		if (isCutOverResponse(this.sourceTmm.getNetworkMgmtInfoCode()) || isRupaySchemeInitiatedDynamicKeyExchange(this.sourceTmm) ||
				isRupayEchoResponse(this.sourceTmm) || isRupaySignOnResponse(this.sourceTmm) || isRupaySignOffResponse(this.sourceTmm)) {
			transmissionTime = this.sourceTmm.getTransmissionTime();
		} else {
			transmissionTime = MtmUtil.formatDate("MMddHHmmss", ZoneId.of("GMT"));
		}
		this.targetTmm.setTransmissionTime(transmissionTime);
		this.baseMessage.set(fieldNo, transmissionTime);
	}

	/**
	 * 8. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
	 */

	/**
	 * 9. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
	 */

	/**
	 * 10. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
	 */

	/**
	 * 11. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
	 * <br>
	 * CyberSource API - T id
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setStan(int fieldNo) {
		String stan = null;
		if (isCutOverResponse(this.sourceTmm.getNetworkMgmtInfoCode()) || isRupaySchemeInitiatedDynamicKeyExchange(this.sourceTmm)
				|| isRupayEchoResponse(this.sourceTmm) || isRupaySignOnResponse(this.sourceTmm) || isRupaySignOffResponse(this.sourceTmm)
				|| isBqrPurchase(this.sourceTmm.getMsgType(), this.sourceTmm.getProcessingCode())) {
			stan = this.sourceTmm.getStan();
			this.targetTmm.setStan(stan);
			this.baseMessage.set(fieldNo, stan);
		} else {
			super.setStan(fieldNo);
			this.targetTmm.setSchemeStan(this.targetTmm.getStan());
		}
	}

	/**
	 * 12. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
	 * CyberSource API - Transaction Local Date Time
	 */
	@Override
	public void setLocalTxnTime(int fieldNo) {
		String localTxnTime = MtmUtil.formatDate("HHmmss");
		this.targetTmm.setLocalTxnTime(localTxnTime);
		this.baseMessage.set(fieldNo, localTxnTime);
	}

	/**
	 * 13. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
	 */
	@Override
	public void setLocalTxnDate(int fieldNo) {
		String localTxnDate = MtmUtil.formatDate("MMdd");
		this.targetTmm.setLocalTxnDate(localTxnDate);
		this.baseMessage.set(fieldNo, localTxnDate);
	}

	/**
	 * 14. <br>
	 * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
	 * Date
	 */

	/**
	 * 15. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
	 */

	/**
	 * 16. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
	 */

	/**
	 * 17. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
	 */

	/**
	 * 18.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
	 * ISO8583 -1987, CyberSource API - Category Code
	 */
	/* It is mandatory for all type of transactions */
	/*
	 * In RuPay's Cashwithdrawal transaction there has to be a check for the merchant type field.
	 * If the target is RuPay and the transaction is Cashwithdrawal then check for the value of merchant type field.
	 * And If the value of the field merchantType is '6010' then proceed forward.
	 * Else it is a invalid transaction, so rescode '12' has to be send in this case.
	 * For that InvalidTxnException is thrown from here.
	 */
	@Override
	public void setMerchantType(int fieldNo) {
		String merchantType = this.merchantData.getMerchantType();

		if (MessageConstructionHelper.isCashWithdrawal(this.sourceMsgType, this.sourceMsgTypeId)
				&& (!MtmConstants.MC_MERCHANT_TYPE.equals(merchantType))) {
			throw new InvalidTxnException("MerchantType " + merchantType + " is invalid.");
		}
		this.targetTmm.setMerchantType(merchantType);
		this.baseMessage.set(fieldNo, merchantType);
	}


	/**
	 * 19. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
	 * Country Code <br>
	 * mPOS - terminalCountryCode
	 */
	/* It is mandatory for all type of transactions except balance Enquiry */
	@Override
	public void setAquirerCountryCode(int fieldNo) {
		String acqCountryCode = this.merchantData.getAcquiringInstitutionCountryCode();
		this.targetTmm.setAquirerCountryCode(acqCountryCode);
		this.baseMessage.set(fieldNo, acqCountryCode);
	}

	/**
	 * 20. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
	 * code
	 */

	/**
	 * 21. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
	 */

	/**
	 * 22. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
	 * Entry Mode <br>
	 * mPOS - NFC Enabled
	 */
	@Override
	public void setPosEntryMode(int fieldNo) {
		String posEntryMode = this.sourceTmm.getPosEntryMode();
		if (MtmUtil.getPOS_ENTRY_MODE_DATA().contains(posEntryMode)) {
			if (posEntryMode.equals("021") || posEntryMode.equals("901")) {
				posEntryMode = "901";
			}
			this.targetTmm.setPosEntryMode(posEntryMode);
			this.baseMessage.set(fieldNo, posEntryMode);
		} else {
			throw new MessageConstructionException("Could not validate POS Entry Mode against master data available");
		}
	}

	/**
	 * 23. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
	 */

	/**
	 * 24. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
	 * CyberSource API - Type
	 */

	/**
	 * 25. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
	 */
	/* It is mandatory for all type of transactions except balance Enquiry */
	@Override
	public void setPosConditionCode(int fieldNo) {
		String posConditionCode;
		if (MessageConstructionHelper.isMoto(this.targetMsgType, this.targetMsgTypeId)) {
			posConditionCode = "08";
		} else {
			posConditionCode = "00";
		}
		this.targetTmm.setPosConditionCode(posConditionCode);
		this.baseMessage.set(fieldNo, posConditionCode);
	}

	/**
	 * 26. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
	 */

	/**
	 * 27. <br>
	 * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
	 * length
	 */

	/**
	 * 28. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
	 */

	/**
	 * 29. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
	 */


	/**
	 * 30. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
	 */


	/**
	 * 31.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
	 */


	/**
	 * 32. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
	 * Code
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setAquirerIdCode(int fieldNo) {
		String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
		this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
		this.baseMessage.set(fieldNo, acquirerInstitutionId);
	}


	/**
	 * 33.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
	 * Code
	 */

	/**
	 * 34.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
	 */


	/**
	 * 35.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
	 */


	/**
	 * 36.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
	 */


	/**
	 * 37.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
	 * Number<br>
	 * CyberSource API - TransactionId
	 */
	/*
	 * It is mandatory for all type of transactions except balance Enquiry,for
	 * balance enquiry it is conditional
	 */
	@Override
	public void setRetrievalRefNo(int fieldNo) {
		if (isRupayEchoResponse(this.sourceTmm)
				|| isBqrPurchase(this.sourceTmm.getMsgType(), this.sourceTmm.getProcessingCode())) {
			String rrnNumber = this.sourceTmm.getRetrievalRefNo();

			this.targetTmm.setRetrievalRefNo(rrnNumber);
			this.baseMessage.set(fieldNo, rrnNumber.getBytes());
		} else {
			super.setRetrievalRefNo(fieldNo);
		}
	}


	/**
	 * 38.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
	 * Response<br>
	 * mPOS - AuthCode
	 */
	@Override
	public void setAuthIdRes(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
	}

	/**
	 * 39.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
	 * mPOS - Status Code
	 */
	@Override
	public void setResCode(int fieldNo) {
		String resCode = this.sourceTmm.getResCode();
		this.targetTmm.setResCode(resCode);
		this.baseMessage.set(fieldNo, resCode.getBytes());
	}


	/**
	 * 40.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
	 */

	/**
	 * 41.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
	 * Identification
	 */
	/* It is mandatory for all type of transactions except balance Enquiry */
	@Override
	public void setCardAcceptorTerminalId(int fieldNo) {
		String cardAcceptorTermId = this.sourceTmm.getCardAcceptorTerminalId();
		if (cardAcceptorTermId != null) {
			this.targetTmm.setCardAcceptorTerminalId(cardAcceptorTermId);
			this.baseMessage.set(fieldNo, cardAcceptorTermId.getBytes());
		}
	}

	/**
	 * 42. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
	 * Identification code<br>
	 * mPOS - TxnId
	 */
	/* It is mandatory for all type of transactions except balance Enquiry */
	@Override
	public void setCardAcceptorId(int fieldNo) {
		String cardAcceptorId = this.sourceTmm.getCardAcceptorId();
		this.targetTmm.setCardAcceptorId(cardAcceptorId);
		this.baseMessage.set(fieldNo, cardAcceptorId.getBytes());
	}


	/**
	 * 43.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
	 * Name/Location
	 */
	/* It is mandatory for all type of transactions except balance Enquiry */
	@Override
	public void setCardAcceptorInfo(int fieldNo) {
		String merchantName = StringUtils.rightPad(this.merchantData.getMerchantName(), 23);
		String merchantCity = StringUtils.rightPad(this.merchantData.getMerchantCity(), 13);
		String merchantStateCode = StringUtils.rightPad(this.merchantData.getMerchantStateCode() == null ? "" : this.merchantData.getMerchantStateCode(), 2);
		String merchantCountryCode = StringUtils.rightPad(this.merchantData.getMerchantShortCountryCode(), 2);

		String cardAcceptorInfo = merchantName + merchantCity + merchantStateCode + merchantCountryCode;
		this.targetTmm.setCardAcceptorInfo(cardAcceptorInfo);
		this.baseMessage.set(fieldNo, cardAcceptorInfo);
	}

	/**
	 * 44.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
	 */


	/**
	 * 45.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
	 */


	/**
	 * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
	 */


	/**
	 * 47.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Data National
	 */


	/**
	 * 48.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
	 */
	/* It is mandatory for all type of transactions except balance Enquiry */
	@Override
	public void setPrivateAd(int fieldNo) {
		String privateAd = "051005POS0107800205";

		if (TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) || TmmConstants.RES_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType())) {
			if (isSignOnResponse(sourceTmm.getMsgType()) && isRupaySchemeInitiatedDynamicKeyExchange(sourceTmm)) {
				privateAd = sourceTmm.getPrivateAd();
			} else if (isRupayEchoRequest(sourceTmm) || isRupaySignOnRequest(sourceTmm)
					|| isRupayDynamicKeyExchangeRequest(sourceTmm)) {
				privateAd = null;
			}
		} else if (isRupayAddMoneyRequest(this.targetMsgType, this.targetMsgTypeId)
				|| isRupayBalanceUpdateRequest(this.targetMsgType, this.targetMsgTypeId)) {

			TlvDataList atmPinOffsetDataList = new TlvDataList(this.sourceTmm.getAtmPinOffsetData());
			privateAd = "051005POS01078002050790040000082002" + atmPinOffsetDataList.getTagValue("0501");
		}

		/**if (rupayMacFlag && this.targetMsgType.equals(TmmConstants.AUTHORIZATION_REQUEST_MTI)) {

            /**
		 * TODO: Remove below code of Invalid MAC Generation after certification

            if(rupayInvalidMacGenFlag) {
                privateAd = privateAd + MtmConstants.MAC_TAG_NAME + rupayInvalidMacValue;
            } else {
                String mac = buildMac();

                switch (hsmVendor) {
                    case THALES:
                        privateAd = privateAd + MtmConstants.MAC_TAG_NAME + (mac.substring(8, mac.length())).length() + mac.substring(8, mac.length());
                        break;

                    case SAFENET:
                        privateAd = privateAd + MtmConstants.MAC_TAG_NAME + (mac.substring(10, 26)).length() + mac.substring(10, 26);
                        break;

                    default:
                        break;

                }
            }
        }*/

		this.targetTmm.setPrivateAd(privateAd);
		this.baseMessage.set(fieldNo, privateAd);
	}

	/**
	 * 49.<br>
	 * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
	 * Code
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setTxnCurrencyCode(int fieldNo) {
		String merchantCurrencyCode = this.sourceTmm.getTxnCurrencyCode() != null ? this.sourceTmm.getTxnCurrencyCode()
				: this.merchantData.getAcquirerCurrencyCode();
		this.targetTmm.setTxnCurrencyCode(merchantCurrencyCode);
		this.baseMessage.set(fieldNo, merchantCurrencyCode);
	}

	@Override
	public void setIccData(int fieldNo) {

	}

	/**
	 * 50.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
	 */


	/**
	 * 51.<br>
	 * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
	 */


	/**
	 * 52.<br>
	 * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
	 * (PIN) Data<br>
	 * CyberSource API - Encrypted Pin
	 */


	/**
	 * 53.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
	 * Information<br>
	 * CyberSource API - Encrypted Key Serial Number
	 */

	/**
	 * 54.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
	 */

	/**
	 * 55.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
	 * Base24 - ISO Reserved<br>
	 * CyberSource API- EMV
	 */

	/**
	 * 56.<br>
	 * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
	 */


	/**
	 * 57.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Amount cash
	 */


	/**
	 * 58.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Ledger balance
	 */


	/**
	 * 59.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Account balance, Cleared funds
	 */


	/**
	 * 60.<br>
	 * ISO8583-1987 - Reserved for national use<br>
	 * AS2805,ISG, XML - Reserved private<br>
	 * Base24 - Terminal Data
	 */


	/**
	 * 61.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
	 * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
	 * Data
	 */
	/* It is mandatory for all type of transactions except reversal and void */
	@Override
	public void setCiad(int fieldNo) {
		String merchantAddress = this.merchantData.getMerchantAddress() == null ? ""
				: this.merchantData.getMerchantAddress();
		if (merchantAddress.length() > 20) {
			merchantAddress = merchantAddress.substring(0, 20);
		} else {
			merchantAddress = StringUtils.rightPad(merchantAddress, 20);
		}
		String merchantAdd = this.merchantData.getMerchantZipCode() + merchantAddress;
		String posConditionCode;
		if (MessageConstructionHelper.isMoto(this.targetMsgType, this.targetMsgTypeId)) {
			posConditionCode = "600141700033000";
		} else if (MessageConstructionHelper.isMagstripeWithPin(this.sourceTmm.getPosEntryMode().substring(0, 2), this.sourceTmm.getPin())
				|| MessageConstructionHelper.isFallbackWithPin(this.sourceTmm.getPosEntryMode().substring(0, 2), this.sourceTmm.getPin())) {
			posConditionCode = "820112220033000";
		} else if (MessageConstructionHelper.isMagstripeWithoutPin(this.sourceTmm.getPosEntryMode().substring(0, 2), this.sourceTmm.getPin())
				|| MessageConstructionHelper.isFallbackWithoutPin(this.sourceTmm.getPosEntryMode().substring(0, 2), this.sourceTmm.getPin())) {
			posConditionCode = "810112230033000";
		}  else if (MessageConstructionHelper.isContactlessTxn(this.sourceTmm.getPosEntryMode().substring(0, 2))) {
			if (this.sourceTmm.getPin() != null && this.sourceTmm.getPin().isEmpty() == false) {
				posConditionCode = "820112421033000";
			} else {
				posConditionCode = "810112411033000";
			}
		}  else {
			if (this.sourceTmm.getPin() != null && this.sourceTmm.getPin().isEmpty() == false) {
				posConditionCode = "820112321033000";
			} else {
				posConditionCode = "810112331033000";
			}

		}


		posConditionCode += merchantAdd;
		this.targetTmm.setCiad(posConditionCode);
		this.baseMessage.set(fieldNo, posConditionCode);
	}

	/**
	 * 62.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - Postal Code
	 */


	/**
	 * 63.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - ATM PIN Offset POS Additional Data
	 */


	/**
	 * 64.<br>
	 * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
	 * Base24 -Primary Message Authentication Code
	 */


	/**
	 * 65.<br>
	 * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
	 * Base24 -Reserved for ISO use
	 */


	/**
	 * 66.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Code
	 */


	/**
	 * 67.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Extended payment code
	 */


	/**
	 * 68.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
	 * mPOS - Transaction Country Code
	 */


	/**
	 * 69.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
	 */


	/**
	 * 70.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
	 */


	/**
	 * 71.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number
	 */


	/**
	 * 72.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number Last
	 */


	/**
	 * 73.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Action Date
	 */


	/**
	 * 74.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Credits
	 */


	/**
	 * 75.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
	 */


	/**
	 * 76.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Debits
	 */


	/**
	 * 77.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
	 */


	/**
	 * 78.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Transfer
	 */


	/**
	 * 79.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
	 */


	/**
	 * 80.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
	 */


	/**
	 * 81.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
	 */


	/**
	 * 82.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
	 */


	/**
	 * 83.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
	 */


	/**
	 * 84.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
	 */


	/**
	 * 85.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
	 */


	/**
	 * 86.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Credits
	 */


	/**
	 * 87.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
	 */


	/**
	 * 88.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Debits
	 */


	/**
	 * 89.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
	 */


	/**
	 * 90.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
	 */


	/**
	 * 91.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Update Code
	 */


	/**
	 * 92.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Security Code
	 */


	/**
	 * 93.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Response Indicator
	 */


	/**
	 * 94.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Service Indicator
	 */


	/**
	 * 95.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
	 */


	/**
	 * 96.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Security Code
	 */


	/**
	 * 97.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
	 */


	/**
	 * 98.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Payee
	 */


	/**
	 * 99.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
	 * Code
	 */


	/**
	 * 100.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
	 */


	/**
	 * 101.ISO8583-1987, AS2805, Base24, XML - File Name
	 */


	/**
	 * 102.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
	 */


	/**
	 * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
	 */


	/**
	 * 104.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
	 * mPOS - transaction_type
	 */
	@Override
	public void setTxnDesc(int fieldNo) {
		// throw new UndefinedBusinessRuleClassMethodException(fieldNo);
	}


	/**
	 * 105.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 106.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 107.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 108.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 109.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 110.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 111.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 112.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use<br>
	 * AS2805 - Key Management data
	 */


	/**
	 * 113.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 114.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 115.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 116.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 117. <br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 118.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 119.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 120.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
	 */


	/**
	 * 121. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS Authorization Indicators
	 */


	/**
	 * 122.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -Card Issuer Identification Code
	 */


	/**
	 * 123.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
	 * Invoice Data/Settlement Record
	 */


	/**
	 * 124.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
	 */


	/**
	 * 125.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
	 */


	/**
	 * 126. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
	 */


	/**
	 * 127.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS User Data
	 */


	/**
	 * 128.<br>
	 * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
	 * Base24 - Secondary Message Authentication Code
	 */



}
