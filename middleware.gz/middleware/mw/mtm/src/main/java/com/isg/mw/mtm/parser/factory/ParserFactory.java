package com.isg.mw.mtm.parser.factory;

import java.util.HashMap;
import java.util.Map;

import com.isg.mw.core.model.constants.MessageFormat;
import com.isg.mw.mtm.parser.ITmmParser;

/**
 *
 * @author prasad_t026
 *
 */
public class ParserFactory {

	private static Map<MessageFormat, ITmmParser> parsers = null;

	public ParserFactory() {
	}

    static {
        parsers = new HashMap<>();
        parsers.put(MessageFormat.ISO8583, new Iso8583TmmParser());
        parsers.put(MessageFormat.PG_PIPE_STRING, new PipeStringParser());
    }

	/**
	 * Get parse to convert transaction messages from different format to
	 * TransactionMessageModel
	 *
	 * @param format - source
	 * @return
	 */
	public static ITmmParser getParser(MessageFormat format) {
		return parsers.get(format);
	}

}