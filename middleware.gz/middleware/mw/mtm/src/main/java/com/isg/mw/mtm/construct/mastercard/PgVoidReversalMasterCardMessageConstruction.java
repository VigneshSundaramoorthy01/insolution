package com.isg.mw.mtm.construct.mastercard;

import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.TlvAns;
import com.isg.mw.core.utils.TlvDataList;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;

public final class PgVoidReversalMasterCardMessageConstruction extends VoidReversalMasterCardMessageConstruction implements IMessageConstruction {

	public void updateDrCrFlag() {
		if (isPosVoidRequest(this.sourceMsgType, this.sourceMsgTypeId)) {
			this.targetTmm.setDrcrFlag("V");
		} else {
			this.targetTmm.setDrcrFlag("R");
		}
	}

	/**
	 * 1.<br>
	 * ISO8583 -1987, AS2805 - Secondary bitmap <br>
	 * Base24, ISG, XML - Bit map
	 */

	/**
	 * 2.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
	 * Account Number
	 */

	/**
	 * 3. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
	 * <br>
	 * mPOS - Transaction Type
	 */


	/**
	 * 4. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
	 * CyberSource API - AuthorizedAmount
	 * <p>
	 * It is mandatory for all type of transactions
	 */


	/**
	 * 5.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
	 */

	/**
	 * 6.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
	 */

	/**
	 * 7. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
	 */
	/* It is mandatory for all type of transactions */

	/**
	 * 8. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
	 */

	/**
	 * 9. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
	 */

	/**
	 * 10. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
	 */

	/**
	 * 11. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
	 * <br>
	 * CyberSource API - T id
	 */


	/**
	 * 12. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
	 * CyberSource API - Transaction Local Date Time
	 */


	/**
	 * 13. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
	 */


	/**
	 * 14. <br>
	 * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
	 * Date
	 */


	/**
	 * 15. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
	 */

	/**
	 * 16. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
	 */

	/**
	 * 17. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
	 */

	/**
	 * 18.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
	 * ISO8583 -1987, CyberSource API - Category Code
	 */


	/**
	 * 19. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
	 * Country Code <br>
	 * mPOS - terminalCountryCode
	 */


	/**
	 * 20. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
	 * code
	 */

	/**
	 * 21. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
	 */

	/**
	 * 22. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
	 * Entry Mode <br>
	 * mPOS - NFC Enabled
	 * <p>
	 * It is mandatory for all type of transactions
	 */
	@Override
	public void setPosEntryMode(int fieldNo) {
		String posEntryMode = null;
		String entryMode = this.sourceTmm.getPosEntryMode();
		if (PgMsgTypeHelper.isReversal(this.sourceMsgType, this.sourceMsgTypeId)
				|| PgMsgTypeHelper.isMotoReversal(this.sourceMsgType, this.sourceMsgTypeId)) {
			posEntryMode = this.sourceTmm.getOriginalTmm().getPosEntryMode();
		} else {
			posEntryMode = entryMode;
		}
		this.targetTmm.setPosEntryMode(posEntryMode);
		this.baseMessage.set(fieldNo, posEntryMode);
	}


	/**
	 * 23. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
	 */


	/**
	 * 24. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
	 * CyberSource API - Type
	 */

	/**
	 * 25. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
	 */

	/**
	 * 26. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
	 */

	/**
	 * 27. <br>
	 * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
	 * length
	 */

	/**
	 * 28. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
	 */


	/**
	 * 29. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
	 */

	/**
	 * 30. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
	 */

	/**
	 * 31.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
	 *
	 */

	/**
	 * 32. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
	 * Code
	 */


	/**
	 * 33.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
	 * Code
	 */


	/**
	 * 34.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
	 */

	/**
	 * 35.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
	 *
	 */

	/**
	 * 36.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
	 */

	/**
	 * 37.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
	 * Number<br>
	 * CyberSource API - TransactionId
	 */


	/**
	 * 38.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
	 * Response<br>
	 * mPOS - AuthCode
	 */


	/**
	 * 39.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
	 * mPOS - Status Code
	 * <p>
	 * It is mandatory for reversal and void only
	 */
	@Override
	public void setResCode(int fieldNo) {
		String resCode = this.originalTmm.getResCode();
		String reversalMsgReasonCode = this.sourceTmm.getPgData() != null ?  this.sourceTmm.getPgData().getReversalMessageReasonCode() : null ;
		if (isTimeoutReversalReq(this.sourceMsgType, this.originalTmm.getAuthIdRes())) {
			resCode = "68";
		} else if (!StringUtils.isBlank(reversalMsgReasonCode)
				&& reversalMsgReasonCode.equalsIgnoreCase("T")) {
			resCode = "06";
		} else if (!StringUtils.isBlank(reversalMsgReasonCode)
				&& reversalMsgReasonCode.equalsIgnoreCase("V")) {
			resCode = "17";
		}

		this.targetTmm.setResCode(resCode);
		this.baseMessage.set(fieldNo, resCode.getBytes());
	}


	/**
	 * 40.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
	 */

	/**
	 * 41.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
	 * Identification
	 */

	/**
	 * 42. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
	 * Identification code<br>
	 * mPOS - TxnId
	 */


	/**
	 * 43.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
	 * Name/Location
	 * <p>
	 * Logic:<br>
	 * Switch has to extract it from Merchant / POS Master table and send it to
	 * Scheme. card acceptor name (1-22),<br>
	 * space(23),<br>
	 * city name (24-36),<br>
	 * space(37),<br>
	 * Country code (38-40)
	 */


	/**
	 * 44.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
	 */

	/**
	 * 45.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
	 */

	/**
	 * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
	 */

	/**
	 * 47.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Data National
	 */

	/**
	 * 48.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
	 */
	/* It is mandatory for all type of transactions */
	@Override
	public void setPrivateAd(int fieldNo) {
		String privateAd = null;

		if (TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) || TmmConstants.RES_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType())) {
			if (isSignOnResponse(sourceTmm.getMsgType())) {
				privateAd = sourceTmm.getPrivateAd();
			}
		} else {
			privateAd = buildVRPrivateAd();
		}

		this.targetTmm.setPrivateAd(privateAd);
		this.baseMessage.set(fieldNo, privateAd);
	}

	private String buildVRPrivateAd() {
		List<TlvAns> f48 = new ArrayList<>();
		String tcc = this.merchantData.getTerminalCategoryCode();

		String privateAd = this.originalTmm.getPrivateAd();
		String privateAd1 = null;
		if (!StringUtils.isBlank(privateAd)) {
			privateAd1 = privateAd.substring(1, privateAd.length());
		}

		TlvDataList tlvDataList = new TlvDataList(privateAd1, 2, 2);
		String tag42 = tlvDataList.getTagValue("42");
		String tag43 = tlvDataList.getTagValue("43");

		f48.add(new TlvAns("20", "S"));

		StringBuilder subField006 = new StringBuilder();
		String subField006Value = "0A";
		subField006.append("006");
		subField006.append(subField006Value.length());
		subField006.append(subField006Value);

		f48.add(new TlvAns("22", subField006.toString()));

		if (PgMsgTypeHelper.isSI(this.sourceMsgType, this.sourceMsgTypeId)) {
			String field41 = this.sourceTmm.getPgData().getField41();
			if (field41 != null) {
				f48.add(new TlvAns("41", "01" + field41.length() + field41));
			}

		}

		if (tag42 != null) {
			f48.add(new TlvAns("42", tag42.substring(4, 7)));
		}
		if (tag43 != null) {
			f48.add(new TlvAns("43", tag43));
		}

		String traceId=null;
		if (isTimeoutReversalReq(this.sourceMsgType, this.originalTmm.getAuthIdRes())) {
			traceId="MCC9999991231  ";
			f48.add(new TlvAns("63", traceId));
		} else {
			if (this.originalTmm.getAtmPinOffsetData() != null) {
				traceId = fetchTraceId(this.originalTmm.getAtmPinOffsetData(), this.originalTmm.getSettlementDate());
				f48.add(new TlvAns("63", traceId));
			}
		}

		if (isTimeoutReversalReq(this.sourceMsgType, this.originalTmm.getAuthIdRes())) {
			if (this.originalTmm.getPgData().getDsVersion() != null) {
				String subField66Value = "0101" + this.originalTmm.getPgData().getDsVersion();
				f48.add(new TlvAns("66", subField66Value));
			}
			String cvv=this.originalTmm.getPgData().getCvv2();
			if (this.originalTmm.getPgData().getCvv2() != null)
				f48.add(new TlvAns("92", cvv.substring(3,6)));
		} else {

			if (this.sourceTmm.getPgData().getDsVersion() != null) {
				String subField66Value = "0101" + this.sourceTmm.getPgData().getDsVersion();
				f48.add(new TlvAns("66", subField66Value));
			}

			String cvv=this.sourceTmm.getPgData().getCvv2();
			if (this.sourceTmm.getPgData().getCvv2() != null) {
				f48.add(new TlvAns("92", cvv.substring(3,6)));
			}
		}

		return tcc + TlvAns.getBytes(f48);
	}

	private String fetchTraceId (String atmPinOffSet, String settlementDate) {
		return atmPinOffSet + settlementDate + org.apache.commons.lang3.StringUtils.repeat(' ', 2);
	}


	/**
	 * 49.<br>
	 * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
	 * Code
	 */


	/**
	 * 50.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
	 */

	/**
	 * 51.<br>
	 * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
	 */

	/**
	 * 52.<br>
	 * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
	 * (PIN) Data<br>
	 * CyberSource API - Encrypted Pin
	 */

	/**
	 * 53.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
	 * Information<br>
	 * CyberSource API - Encrypted Key Serial Number
	 */


	/**
	 * 54.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
	 */


	/**
	 * 55.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
	 * Base24 - ISO Reserved<br>
	 * CyberSource API- EMV
	 */

	/**
	 * 56.<br>
	 * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
	 */

	/**
	 * 57.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Amount cash
	 */

	/**
	 * 58.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Ledger balance
	 */

	/**
	 * 59.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Account balance, Cleared funds
	 */

	/**
	 * 60.<br>
	 * ISO8583-1987 - Reserved for national use<br>
	 * AS2805,ISG, XML - Reserved private<br>
	 * Base24 - Terminal Data
	 */

	/**
	 * 61.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
	 * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
	 * Data
	 *
	 */
	@Override
    public void setCiad(int fieldNo) {
        String posEntryMode = this.sourceTmm.getOriginalTmm().getPosEntryMode();
        final String merchantZipCode = this.merchantData.getMerchantZipCode();
        String txnCountryCode = this.sourceTmm.getOriginalTmm().getAquirerCountryCode() != null ? this.sourceTmm.getAquirerCountryCode()
                : this.merchantData.getMerchantCountryCode();
        String ciad = "1025110006000" + txnCountryCode;

        if (PgMsgTypeHelper.isSI(this.sourceTmm.getOriginalTmm().getMsgType(), this.sourceTmm.getOriginalTmm().getProcessingCode())) {
            if (posEntryMode.equals("100")) {
                ciad = "2034110000000" + txnCountryCode;
            } else if (posEntryMode.equals("810")) {
                ciad = "1024110006000" + txnCountryCode;
            }
        }
        ciad += merchantZipCode;
        this.targetTmm.setCiad(ciad);
        this.baseMessage.set(fieldNo, ciad);

    }


	/**
	 * 62.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - Postal Code
	 */

	/**
	 * 63.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - ATM PIN Offset POS Additional Data
	 */

	/**
	 * 64.<br>
	 * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
	 * Base24 -Primary Message Authentication Code
	 */

	/**
	 * 65.<br>
	 * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
	 * Base24 -Reserved for ISO use
	 */

	/**
	 * 66.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Code
	 */

	/**
	 * 67.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Extended payment code
	 */


	/**
	 * 68.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
	 * mPOS - Transaction Country Code
	 */


	/**
	 * 69.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
	 *
	 */


	/**
	 * 70.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
	 */


	/**
	 * 71.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number
	 */


	/**
	 * 72.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number Last
	 */


	/**
	 * 73.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Action Date
	 */


	/**
	 * 74.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Credits
	 */


	/**
	 * 75.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
	 */


	/**
	 * 76.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Debits
	 */


	/**
	 * 77.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
	 */


	/**
	 * 78.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Transfer
	 */


	/**
	 * 79.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
	 */


	/**
	 * 80.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
	 */


	/**
	 * 81.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
	 */


	/**
	 * 82.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
	 */


	/**
	 * 83.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
	 */


	/**
	 * 84.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
	 */


	/**
	 * 85.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
	 */


	/**
	 * 86.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Credits
	 */


	/**
	 * 87.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
	 */


	/**
	 * 88.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Debits
	 */


	/**
	 * 89.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
	 */


	/**
	 * 90.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
	 */
	@Override
	public void setOriginalDataElements ( int fieldNo){
		String originalDataElements = null;
		StringBuilder originalDataElementsBuilder = new StringBuilder();

		String msgType = this.originalTmm.getMsgType();
		String stan = this.originalTmm.getStan();
		String transmissionTime = this.originalTmm.getTransmissionTime();
		if (isTimeoutReversalReq(this.sourceMsgType, this.originalTmm.getAuthIdRes())) {
			transmissionTime=this.targetTmm.getTransmissionTime();
		}
		String acquirerId = this.targetTmm.getAquirerIdCode();
		String forwardingInstId = this.targetTmm.getForwardingInstIdCode();

		originalDataElements = originalDataElementsBuilder.append(msgType).append(stan).append(transmissionTime)
				.append(StringUtils.leftPad(acquirerId, 11, '0'))
				.append(StringUtils.leftPad(forwardingInstId, 11, '0')).toString();

		this.targetTmm.setOriginalDataElements(originalDataElements);
		this.baseMessage.set(fieldNo, originalDataElements);
	}


	/**
	 * 91.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Update Code
	 */


	/**
	 * 92.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Security Code
	 */


	/**
	 * 93.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Response Indicator
	 */


	/**
	 * 94.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Service Indicator
	 */


	/**
	 * 95.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
	 */


	/**
	 * 96.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Security Code
	 */


	/**
	 * 97.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
	 */


	/**
	 * 98.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Payee
	 */


	/**
	 * 99.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
	 * Code
	 */


	/**
	 * 100.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
	 */


	/**
	 * 101.ISO8583-1987, AS2805, Base24, XML - File Name
	 */


	/**
	 * 102.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
	 */


	/**
	 * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
	 */


	/**
	 * 104.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
	 * mPOS - transaction_type
	 */


	/**
	 * 105.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 106.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 107.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 108.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 109.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 110.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 111.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */


	/**
	 * 112.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use<br>
	 * AS2805 - Key Management data
	 */


	/**
	 * 113.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 114.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 115.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 116.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */


	/**
	 * 117. <br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */


	/**
	 * 118.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 119.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */


	/**
	 * 120.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
	 */


	/**
	 * 121. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS Authorization Indicators
	 */


	/**
	 * 122.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -Card Issuer Identification Code
	 */


	/**
	 * 123.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
	 * Invoice Data/Settlement Record
	 */


	/**
	 * 124.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
	 */


	/**
	 * 125.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
	 */


	/**
	 * 126. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
	 */


	/**
	 * 127.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS User Data
	 */


	/**
	 * 128.<br>
	 * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
	 * Base24 - Secondary Message Authentication Code
	 */

}