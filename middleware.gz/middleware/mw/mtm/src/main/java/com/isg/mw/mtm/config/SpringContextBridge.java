package com.isg.mw.mtm.config;

import com.isg.mw.cache.mgmt.config.CacheUtil;
import com.isg.mw.cache.mgmt.init.InitRestClient;
import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.cache.mgmt.service.SmartRouteSpringCacheService;
import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.dstm.service.IPinTranslationService;

import com.isg.mw.mtm.util.MwRedisCacheUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import javax.annotation.PostConstruct;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Register this SpringContextBridge as a Spring Component.
 */
@Component
public class SpringContextBridge implements SpringContextBridgedServices, ApplicationContextAware {

    private static ApplicationContext applicationContext;

    @Autowired
    private CacheServices cacheService;

    @Autowired
    private HsmCommonService hsmCommonService;

    //    @Bean
//    @LoadBalanced [issue: works only when calling an API through discovery server]
    public WebClient.Builder loadBalancedWebClientBuilder() {
        return WebClient.builder();
    }

    @Autowired
    private WebClient.Builder webClient;

    @Autowired
    private List<HsmProcessorService> hsmServices;

    @Autowired
    private EncryptService encryptionService;

    @Autowired
    @Qualifier("plainTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private MwRedisCacheUtil mwRedisCacheUtil;

    @Autowired
    private CacheUtil cacheUtil;

    @Autowired
    private DecryptService decryptionService;

    @Autowired
    private InitRestClient initRestClient;

    @Autowired
    private SmartRouteSpringCacheService srCacheService;

    @PostConstruct
    public static Cipher getCipherInstance() {
        Cipher cipher;
        try {
            cipher = Cipher.getInstance("AES");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException(e);
        }
        return cipher;
    }

    private static long readProperty(String propertyName, long defaultVal) {
        return MTMProperties.getProperty(propertyName) == null ? defaultVal : Long.parseLong(MTMProperties.getProperty(propertyName));
    }

    @Bean
    public RestTemplate mtmRestTemplate(RestTemplateBuilder builder) {
        final long fetchOriginalTransactionTimeout = readProperty("fetch.original.txn.timeout", 1000L);
        builder.setConnectTimeout(Duration.ofMillis(fetchOriginalTransactionTimeout));
        return builder.build();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        SpringContextBridge.applicationContext = applicationContext;
    }

    public static SpringContextBridgedServices services() {
        return applicationContext.getBean(SpringContextBridgedServices.class);
    }

    @Autowired
    private List<IPinTranslationService> pinTranslationServices;

    private static final Map<HsmVendor, Map<PinTranslationType, IPinTranslationService>> hsmVendorPinTranslationServiceCache = new HashMap<>();

    private static final Map<HsmVendor, HsmProcessorService> hsmServiceCache = new HashMap<>();

    @Override
    public CacheServices getCacheService() {
        return cacheService;
    }

    @Override
    public HsmCommonService getHsmCommonService() {
        return hsmCommonService;
    }

    @Override
    public WebClient.Builder getWebClient() {
        return webClient;
    }

    @Override
    public EncryptService getEncryptionService() {
        return encryptionService;
    }

    @Override
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    @Override
    public MwRedisCacheUtil getMwRedisCacheUtil() {
        return mwRedisCacheUtil;
    }

    @Override
    public DecryptService getDecryptionService() {
        return decryptionService;
    }

    @Override
    public CacheUtil getCacheUtil() {
        return cacheUtil;
    }

    @Override
    public SmartRouteSpringCacheService getSrCacheService() {
        return srCacheService;
    }

    @Override
    public InitRestClient getInitRestClient() {
        return initRestClient;
    }

    @PostConstruct
    public void initPinTranslationServices() {
        pinTranslationServices.forEach(pinTranslationService -> {
            Map<PinTranslationType, IPinTranslationService> pinTrnsMap = hsmVendorPinTranslationServiceCache.get(pinTranslationService.getHsmVendorType());
            if (pinTrnsMap == null) {
                pinTrnsMap = new HashMap<>();
            }
            pinTrnsMap.put(pinTranslationService.getPinTranslationType(), pinTranslationService);
            hsmVendorPinTranslationServiceCache.put(pinTranslationService.getHsmVendorType(), pinTrnsMap);
        });
    }

    public static IPinTranslationService getPinTranslationService(HsmVendor hsmVendor, PinTranslationType ptst) {
        return hsmVendorPinTranslationServiceCache.get(hsmVendor).get(ptst);
    }

    @PostConstruct
    public void initHsmProcessorServices() {
        hsmServices.forEach(hsmService ->
                hsmServiceCache.put(hsmService.getHsmVendorType(), hsmService));
    }

    public static HsmProcessorService getHsmProcessorService(HsmVendor vendor) {
        return hsmServiceCache.get(vendor);
    }


}