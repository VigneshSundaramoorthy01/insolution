package com.isg.mw.mtm.transform.cybs;

import Model.*;
import com.google.gson.Gson;
import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.TlmMessageType;
import com.isg.mw.core.model.construct.cybs.CybsMsgType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;
import com.isg.mw.mtm.construct.cybs.CybsMessageConstruction;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.transform.BaseMessageTransformation;
import com.isg.mw.mtm.util.ApiUtil;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import static com.isg.mw.core.utils.IsgJsonUtils.removeQuotesAndUnescape;
import static com.isg.mw.mtm.transform.TmmConstants.API_RESPONSE_SEPARATOR;

public class CybsMessageTransformation extends BaseMessageTransformation {
    private final Logger logger = LogManager.getLogger(getClass());

    private static final HashMap<String, Class> MSG_TYPE_MODEL_CLASS_MAP = new HashMap<>(12);

    static {
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.Pay.msgType, CreatePaymentRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.ReversalPay.msgType, AuthReversalRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.ReversalTimeout.msgType, MitReversalRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.CapturePay.msgType, CapturePaymentRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.RefundPay.msgType, RefundPaymentRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.RefundCapture.msgType, RefundCaptureRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.Credit.msgType, CreateCreditRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.VoidPay.msgType, VoidPaymentRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.VoidCapture.msgType, VoidCaptureRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.VoidRefund.msgType, VoidRefundRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.VoidCredit.msgType, VoidCreditRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.VoidTimeout.msgType, MitVoidRequest.class);
        MSG_TYPE_MODEL_CLASS_MAP.put(CybsMsgType.Preauthpay.msgType, CreatePaymentRequest.class);
    }

    @Override
    public MessageContext constructMessage(TransactionMessageModel reqSourceTmm, String epId,
                                           TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        MessageContext msgContext = new MessageContext(reqSourceTmm.getEntityId(), epId, txnTypeConfig.getEpMsgType());
        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(epId);
        MessageFormatConfigModel msgFormatModel = msgFormatMap.get(txnTypeConfig.getEpMsgType());
        //once "get" tokens are replaced, we have to set specific construction based tokens
        SwitchBaseMessageConstruction baseMsgConstruction = getMessageConstruction();
        baseMsgConstruction.setSourceTmm(reqSourceTmm);

        TransactionMessageModel reqTargetTmm = SerializationUtils.clone(reqSourceTmm);
        reqTargetTmm.setTargetType(MessageTransformationContext.getEpIdTargetTypeMap().get(epId));
        reqTargetTmm.setMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetTmm(reqTargetTmm);
        baseMsgConstruction.setSourceMsgType(reqSourceTmm.getMsgType());
        baseMsgConstruction.setSourceMsgTypeId(reqSourceTmm.getProcessingCode());
        baseMsgConstruction.setTargetMsgType(txnTypeConfig.getEpMsgType());
        baseMsgConstruction.setTargetMsgTypeId(txnTypeConfig.getProcessingCode());

        baseMsgConstruction.updateDrCrFlag();

        String msgFormat = msgFormatModel.getMsgFormat();
        Class<?> reqModelClass = MSG_TYPE_MODEL_CLASS_MAP.get(txnTypeConfig.getEpMsgType());
        Object reqTxnModel = IsgJsonUtils.getObjectFromJsonString(msgFormat, reqModelClass);
        ApiUtil.replaceTokens(reqTxnModel, reqSourceTmm, baseMsgConstruction);

        String payload = IsgJsonUtils.getJsonString(reqTxnModel);
        TargetAdditionalData targetAdditionalData = msgTransConfig.getTargetAdditionalData();
        String merchantKeyId = targetAdditionalData.getApiInfo().getCybs().getMerchantKeyId();
        String httpMethod = txnTypeConfig.getHttpMethod();
        String requestHost = targetAdditionalData.getApiInfo().getCybs().getRequestHost();
        String apiPath = txnTypeConfig.getApiPath() == null ? "" : txnTypeConfig.getApiPath();

        if (reqSourceTmm.getOriginalTmm() != null && reqSourceTmm.getOriginalTmm().getCybsData().getReconciliationId() != null)
            apiPath = apiPath.replace("{id}", reqSourceTmm.getOriginalTmm().getCybsData().getReconciliationId());

        String apiUrl = targetAdditionalData.getApiInfo().getCybs().getTxnUrl() + apiPath;
        String merchantId = targetAdditionalData.getApiInfo().getCybs().getMerchantId();
        String merchantSecretKey = targetAdditionalData.getApiInfo().getCybs().getMerchantSecretKey();

        Map<String, String> headers = buildHeaders(payload, merchantKeyId, httpMethod, requestHost, apiUrl,
                merchantId, merchantSecretKey);
        msgContext.setApiHeaders(headers);
        msgContext.setRawMsg(payload);
        msgContext.setTransactionMessageModel(reqTargetTmm);
        msgContext.setMessageTransformationConfig(msgTransConfig);
        msgContext.setTxnApiPath(apiPath);
        return msgContext;
    }

    @Override
    public TransactionMessageModel parseResponse(String responseBody, TransactionMessageModel reqSrcTmm, String epId,
                                                 TransactionTypeConfig txnTypeConfig, MessageTransformationConfig msgTransConfig) {
        responseBody = removeQuotesAndUnescape(responseBody);
        String[] split = responseBody.split(API_RESPONSE_SEPARATOR);
        int status = Integer.parseInt(split[0]);
        String response = split[1];
        PtsV2PaymentsPost201Response cybsSuccessResponse = null;
        PtsV2PaymentsPost400Response cybsFailureResponse;
        TransactionMessageModel resSrcTmm = null;
        try {
            switch (status) {
                case 201:
                    cybsSuccessResponse = new Gson().fromJson(response, PtsV2PaymentsPost201Response.class);
                    resSrcTmm = getSuccessResSourceTmm(cybsSuccessResponse, reqSrcTmm);
                    break;
                case 400:
                    cybsFailureResponse = new Gson().fromJson(response, PtsV2PaymentsPost400Response.class);
                    resSrcTmm = getFailureResSourceTmm(cybsFailureResponse, reqSrcTmm);
                    break;
            }

            logger.trace("Cybs Response: {}", cybsSuccessResponse);
        } catch (Exception e) {
            logger.error("", e);
        }
        return resSrcTmm;
    }

    private TransactionMessageModel getFailureResSourceTmm(PtsV2PaymentsPost400Response cybsFailureResponse, TransactionMessageModel reqSrcTmm) {
        TransactionMessageModel resSourceTmm = new TransactionMessageModel();
        TransactionMessageModel.CybsData cybsData = new TransactionMessageModel.CybsData();
        cybsData.setStatus(cybsFailureResponse.getStatus());
        cybsData.setReason(cybsFailureResponse.getReason());
        cybsData.setErrorDetails(cybsFailureResponse.getMessage());
        resSourceTmm.setCybsData(cybsData);

        setCommonResponseFields(reqSrcTmm, resSourceTmm);
        return resSourceTmm;
    }

    private TransactionMessageModel getSuccessResSourceTmm(PtsV2PaymentsPost201Response cybsRes, TransactionMessageModel reqSrcTmm) {
        TransactionMessageModel resSourceTmm = new TransactionMessageModel();
        resSourceTmm.setTxnAmt(cybsRes.getOrderInformation() != null
                ? cybsRes.getOrderInformation().getAmountDetails().getAuthorizedAmount() : null);
        resSourceTmm.setTxnCurrencyCode(cybsRes.getOrderInformation() != null
                ? cybsRes.getOrderInformation().getAmountDetails().getCurrency() : null);

        resSourceTmm.setSchemeStan(cybsRes.getProcessorInformation() != null
                ? cybsRes.getProcessorInformation().getSystemTraceAuditNumber() : null);
        resSourceTmm.setAuthIdRes(cybsRes.getProcessorInformation() != null
                ? cybsRes.getProcessorInformation().getApprovalCode() : null);
        resSourceTmm.setResCode(cybsRes.getProcessorInformation() != null
                ? cybsRes.getProcessorInformation().getResponseCode() : null);

        TransactionMessageModel.CybsData cybsData = new TransactionMessageModel.CybsData();
        cybsData.setClientReferenceCode(cybsRes.getProcessorInformation() != null
                ? cybsRes.getClientReferenceInformation().getCode() : null);
        cybsData.setNetworkTransactionId(cybsRes.getProcessorInformation() != null
                ? cybsRes.getProcessorInformation().getNetworkTransactionId() : null);
        cybsData.setTransactionId(cybsRes.getProcessorInformation() != null
                ? cybsRes.getProcessorInformation().getTransactionId() : null);
        cybsData.setStatus(cybsRes.getStatus());
        cybsData.setReconciliationId(cybsRes.getReconciliationId());
        cybsData.setCardType(reqSrcTmm.getCybsData() != null ? reqSrcTmm.getCybsData().getCardType() : null);
        if (cybsRes.getErrorInformation() != null) {
            cybsData.setReason(cybsRes.getErrorInformation().getMessage());
            cybsData.setErrorDetails(String.valueOf(cybsRes.getErrorInformation().getDetails()));
        }
        resSourceTmm.setCybsData(cybsData);

        setCommonResponseFields(reqSrcTmm, resSourceTmm);
        return resSourceTmm;
    }

    private void setCommonResponseFields(TransactionMessageModel reqSrcTmm, TransactionMessageModel resSourceTmm) {
        resSourceTmm.setConnectionType(ConnectionType.API);
        resSourceTmm.setTlmMessageType(TlmMessageType.RESPONSE);
        resSourceTmm.setTransactionId(reqSrcTmm.getTransactionId());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setMsgType(reqSrcTmm.getMsgType());
        resSourceTmm.setProcessingCode(reqSrcTmm.getProcessingCode());
        resSourceTmm.setSourceProcessor(reqSrcTmm.getSourceProcessor());
        resSourceTmm.setResponseReceivedTime(OffsetDateTime.now());
        resSourceTmm.setAquirerCountryCode(reqSrcTmm.getAquirerCountryCode());
        resSourceTmm.setAquirerIdCode(reqSrcTmm.getAquirerIdCode());
        resSourceTmm.setCardAcceptorId(reqSrcTmm.getCardAcceptorId());
        resSourceTmm.setCardAcceptorTerminalId(reqSrcTmm.getCardAcceptorTerminalId());
        resSourceTmm.setEncryptedExpirationDate(reqSrcTmm.getEncryptedExpirationDate());
        resSourceTmm.setEntityId(reqSrcTmm.getEntityId());
        resSourceTmm.setMerchantType(reqSrcTmm.getMerchantType());
        resSourceTmm.setPosEntryMode(reqSrcTmm.getPosEntryMode());
        resSourceTmm.setResponseSentTime(OffsetDateTime.now());
        resSourceTmm.setRetrievalRefNo(reqSrcTmm.getRetrievalRefNo());
        resSourceTmm.setTxnAmt(reqSrcTmm.getTxnAmt());
        resSourceTmm.setDrcrFlag(reqSrcTmm.getDrcrFlag());
        resSourceTmm.setTerminalStan(reqSrcTmm.getTerminalStan());
        resSourceTmm.setStan(reqSrcTmm.getStan());
        resSourceTmm.setEncryptedPan(reqSrcTmm.getEncryptedPan());
        resSourceTmm.setMaskedPan(reqSrcTmm.getMaskedPan());
        resSourceTmm.setCardAcceptorInfo(reqSrcTmm.getCardAcceptorInfo());
        resSourceTmm.setForwardingInstIdCode(reqSrcTmm.getForwardingInstIdCode());
        resSourceTmm.setSettlementCurrenyCode(reqSrcTmm.getSettlementCurrenyCode());
        resSourceTmm.setSource(reqSrcTmm.getTarget());
        resSourceTmm.setTarget(reqSrcTmm.getSource());
        resSourceTmm.setTransactionName(reqSrcTmm.getTransactionName().replace("request","response"));
        resSourceTmm.setTargetType(reqSrcTmm.getTargetType());
        resSourceTmm.setPgData(reqSrcTmm.getPgData());
        resSourceTmm.setTerminalBatchNo(reqSrcTmm.getTerminalBatchNo());
    }

    private Map<String, String> buildHeaders(String payload, String merchantKeyId, String httpMethod, String requestHost,
                                             String apiUrl, String merchantId, String merchantSecretKey) {
        Map<String, String> headers = new HashMap<>();
        headers.put("host", requestHost);
        String gmtDateTime = getDate();
        String digest = getDigest(payload);
        headers.put("digest", digest);
        StringBuilder signature = getSignatureHeader(merchantId, merchantSecretKey, requestHost, apiUrl, merchantKeyId, httpMethod, gmtDateTime, payload);
        headers.put("signature", signature.toString());
        headers.put("v-c-merchant-id", merchantId);
        headers.put("date", gmtDateTime);
        headers.put("Content-Type", "application/json");
        return headers;
    }

    private String getDigest(String messageBody) {
        /* This method return Digest value which is SHA-256 hash of payload that is BASE64 encoded */
        try {
            MessageDigest digestString = MessageDigest.getInstance("SHA-256");

            byte[] digestBytes = digestString.digest(messageBody.getBytes("UTF-8"));

            String bluePrint = Base64.getEncoder().encodeToString(digestBytes);
            bluePrint = "SHA-256=" + bluePrint;

            return bluePrint;
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getDate() {
        /*  This Method returns Date in GMT format as defined by RFC7231. */
        return (DateTimeFormatter.RFC_1123_DATE_TIME.format(ZonedDateTime.now(ZoneId.of("GMT"))));
    }

    private StringBuilder getSignatureHeader(String merchantId, String merchantsecretKey, String requestHost, String resource, String merchantKeyId, String httpMethod, String gmtDateTime, String payload) {
        try {
            /* This method return SignatureHeader Value that contains following paramters
             * keyid -- Merchant ID obtained from EBC portal
             * algorithm -- Should have value as "HmacSHA256"
             * headers -- List of all header name passed in the Signature paramter below
             *            String getHeaders = "host date (request-target)" + " " + "v-c-merchant-id";
             *            String postHeaders = "host date (request-target) digest v-c-merchant-id";
             *            Note: Digest is not passed for GET calls
             * signature -- Signature header has paramter called signature
             *              Paramter 'Signature' must contain all the paramters mentioned in header above in given order
             */
            StringBuilder signatureHeaderValue = new StringBuilder();

            /* KeyId is the key obtained from EBC */
            signatureHeaderValue.append("keyid=\"" + merchantKeyId + "\"");

            /* Algorithm should be always HmacSHA256 for http signature */
            signatureHeaderValue.append(", algorithm=\"HmacSHA256\"");

            /* Headers - list is choosen based on HTTP method. Digest is not required for GET Method */
            String getHeaders = "host date (request-target)" + " " + "v-c-merchant-id";
            String postHeaders = "host date (request-target) digest v-c-merchant-id";

            if (httpMethod.equalsIgnoreCase("GET"))
                signatureHeaderValue.append(", headers=\"" + getHeaders + "\"");
            else if (httpMethod.equalsIgnoreCase("POST"))
                signatureHeaderValue.append(", headers=\"" + postHeaders + "\"");

            /* Get Value for paramter 'Signature' to be passed to Signature Header */
            String signatureValue = getSignatureParam(merchantId, merchantsecretKey, requestHost, resource, httpMethod, gmtDateTime, payload);
            signatureHeaderValue.append(", signature=\"" + signatureValue + "\"");

            return signatureHeaderValue;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getSignatureParam(String merchantId, String merchantsecretKey, String requestHost, String resource, String httpMethod, String gmtDateTime, String payload) throws Exception {
        /* This method returns value for paramter Signature which is then passed to Signature header
         * paramter 'Signature' is calucated based on below key values and then signed with SECRET KEY -
         * host: Sandbox (apitest.cybersource.com) or Production (api.cybersource.com) hostname
         * date: "HTTP-date" format as defined by RFC7231.
         * (request-target): Should be in format of httpMethod: path
         *                   Example: "post /pts/v2/payments"
         * Digest: Only needed for POST calls.
         *          digestString = BASE64( HMAC-SHA256 ( Payload ));
         *          Digest: "SHA-256=" + digestString;
         * v-c-merchant-id: set value to Cybersource Merchant ID
         *                   This ID can be found on EBC portal
         */

        StringBuilder signatureString = new StringBuilder();
        signatureString.append('\n');
        signatureString.append("host");
        signatureString.append(": ");
        signatureString.append(requestHost);
        signatureString.append('\n');
        signatureString.append("date");
        signatureString.append(": ");
        signatureString.append(gmtDateTime);
        signatureString.append('\n');
        signatureString.append("(request-target)");
        signatureString.append(": ");

        if (httpMethod.equalsIgnoreCase("GET"))
            signatureString.append("get ").append(resource);
        else if (httpMethod.equalsIgnoreCase("POST"))
            signatureString.append("post ").append(resource);

        signatureString.append('\n');

        if (httpMethod.equalsIgnoreCase("POST")) {
            signatureString.append("digest");
            signatureString.append(": ");
            String digest = getDigest(payload);
            signatureString.append(digest);
            signatureString.append('\n');
        }

        signatureString.append("v-c-merchant-id");
        signatureString.append(": ");
        signatureString.append(merchantId);
        signatureString.delete(0, 1);

        String signatureStr = signatureString.toString();

        /* Signature string generated from above parameters is Signed with SecretKey hased with SHA256 and base64 encoded.
         *  Secret Key is Base64 decoded before signing
         */
        SecretKeySpec secretKey = new SecretKeySpec(Base64.getDecoder().decode(merchantsecretKey), "HmacSHA256");
        Mac aKeyId = Mac.getInstance("HmacSHA256");
        aKeyId.init(secretKey);
        aKeyId.update(signatureStr.getBytes());
        byte[] aHeaders = aKeyId.doFinal();
        String base64EncodedSignature = Base64.getEncoder().encodeToString(aHeaders);
        return base64EncodedSignature;
    }

    @Override
    public Map<TransactionTypeConfig, Map<Integer, String>> getTmmConfig() {
        return null;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction() {
        return new CybsMessageConstruction();
    }

    @Override
    public int getDefaultHeaderLength() {
        return 0;
    }

    @Override
    public SwitchBaseMessageConstruction getMessageConstruction(String msgType, String subMsgType, SourceProcessor
            srcProcessor) {
        return null;
    }
}
