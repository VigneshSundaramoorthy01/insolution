package com.isg.mw.mtm.context;

import java.util.Map;

import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.tc.TargetAdditionalData;
import lombok.Data;

@Data
public class MessageTransformationConfig {
    private String msgFormat;
    private Class<?> businessRuleClass;
    private String methodName;
    private Map<Integer, String> tmmConfig;
    private PinTranslationType pinTranslationType;
    private TargetAdditionalData targetAdditionalData;

    @Override
    public String toString() {
        return "MessageTransformationConfig [businessRuleClass=" + businessRuleClass + ", methodName=" + methodName
                + ", tmmConfig=" + tmmConfig + "] call getMsgFormat to get msg format";
    }

}
