package com.isg.mw.mtm.transform;

import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.IsgJsonUtils;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.mtm.config.EncryptService;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.context.MessageContext;
import com.isg.mw.mtm.context.MessageTransformationConfig;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.context.TransactionTypeConfig;
import com.isg.mw.mtm.exception.*;
import com.isg.mw.mtm.parser.ITmmParser;
import com.isg.mw.mtm.parser.MwIsoPackager;
import com.isg.mw.mtm.parser.factory.ParserFactory;
import com.isg.mw.mtm.parser.factory.PipeStringParser;
import com.isg.mw.mtm.parser.msg.BaseMessage;
import com.isg.mw.mtm.parser.msg.MwMessage;
import com.isg.mw.mtm.parser.msg.PipeStringMsg;
import com.isg.mw.mtm.util.MtmUtil;

import lombok.Getter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jpos.core.InvalidCardException;
import org.jpos.core.Track2;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOUtil;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import javax.xml.bind.DatatypeConverter;

import static com.isg.mw.mtm.context.MessageTransformationContext.getMessageTransformationConfig;

public class MessageTransformer {

    @Getter
    public static final Map<Integer, TransactionMessageModel> responseMap = new ConcurrentHashMap<>();

    private MessageTransformer() {
    }

    private static Logger logger = LogManager.getLogger(MessageTransformer.class);

    private static String TRACK2_EXPR = "^([0-9]{1,19})[=D]([0-9]{4})([0-9]{3})?([0-9]{4})?([0-9]{1,19})?$";

    /**
     * This map will have performance issue when TPS is higher<br>
     * TODO: Find a better and optimized solution in which we might have to override
     * TimeoutCorrelatinoManagerSupport::getState()
     */
    public static TransactionMessageModel toResponsePojo(String entityId, String epId, byte[] rawMsg, String txnName) {
        String str = ISOUtil.byte2hex(rawMsg);
        if (responseMap.containsKey(str.hashCode())) {
            return responseMap.remove(str.hashCode());
        }
        TransactionMessageModel resPojo = toPojo(entityId, OffsetDateTime.now(), epId, rawMsg, TlmMessageType.RESPONSE, txnName);

        MtmUtil.setLoggerContext(resPojo);

        responseMap.put(str.hashCode(), resPojo);
        return resPojo;
    }

    public static TransactionMessageModel toPojo(String entityId, OffsetDateTime timeOfAction, String epId, byte[] rawMsg, TlmMessageType tlmMessageType, String txnName) {
        logger.debug("Starting to convert raw msg, to pojo for entity: {}, endpoint id: {}", entityId, epId);
        TransactionMessageModel sourceTmm = null;
        try {
            MwMessage mwMessage = parseUsingJpos(epId, rawMsg);
            sourceTmm = ParserFactory.getParser(MessageFormat.ISO8583).parse(mwMessage, entityId, epId, txnName);
            setAdditionalData(entityId, timeOfAction, epId, tlmMessageType, sourceTmm);
            logger.debug("Pojo conversion completed for entity: {}, endpoint id: {}", entityId, epId);
        } catch (MessageParsingException e) {
            logger.trace("", e);
            throw new MessageParsingException("Error while parsing the message using JPOS");
        } catch (MessageBuildException e) {
            logger.trace("", e);
            throw new MessageBuildException("Error while transforming raw message to TMM pojo", e);
        }
        return sourceTmm;
    }

    /**
     * Decrypts the track data using hsm decrypt service. <br>
     * After decrypting it sets decrypted data, card number and expiry date back to
     * source tmm.
     *
     * @param sourceTmm Source Transaction Message Model.
     */
    public static void decryptTrackData(TransactionMessageModel sourceTmm) {
        HsmVendor hsmVendor = SpringContextBridge.services().getHsmCommonService().getHsmVendorByEntityId(sourceTmm.getEntityId());
        EncryptService encryprtionService = SpringContextBridge.services().getEncryptionService();

        String encryptedData = null;
        boolean isPan = false;
        if (sourceTmm.getTrack2Data() != null) {
            encryptedData = sourceTmm.getTrack2Data();
        } else if (sourceTmm.getTrack1Data() != null) {
            encryptedData = sourceTmm.getTrack1Data();
        } else if (sourceTmm.getPan() != null) {
            encryptedData = sourceTmm.getPan();
            isPan = true;
        } else {
            return;
        }

        if (sourceTmm.getSourceProcessor() == SourceProcessor.POS_SWITCH || sourceTmm.getSourceProcessor() == SourceProcessor.SMART_ROUTE) {

            // Map<HsmCommandArg, String> hsmCmdArgMap = SpringContextBridge.services().getMwRedisCacheUtil().
            //getTerminalBdkKeyData(sourceTmm.getEntityId() + TmmConstants.TERMINAL_BDK,sourceTmm.getCardAcceptorTerminalId());

            Map<HsmCommandArg, String> hsmCmdArgMap = SpringContextBridge.services().getCacheService().getMftrBDK(sourceTmm.getDeviceMftr());

            if (hsmVendor != null) {
                String decryptedData = SpringContextBridge.getHsmProcessorService(hsmVendor).decrypt(sourceTmm.getEntityId(), sourceTmm.getSource(), hsmCmdArgMap == null ? null : hsmCmdArgMap.get(HsmCommandArg.Bdk1),
                        sourceTmm.getCardNumberKsn(), encryptedData);

                Track2 trackData = null;
                if (!isPan) {
                    try {
                        Track2.Builder trackBuilder = Track2.builder().pattern(Pattern.compile(TRACK2_EXPR)).track(decryptedData);
                        trackData = new Track2(trackBuilder);
                    } catch (InvalidCardException e) {
                        logger.error("", e);
                        //throw new MessageBuildException(e.getMessage());
                        throw new InvalidCardNumberException("Card Number " + decryptedData + " is invalid");
                    }
                }
                if (sourceTmm.getTrack2Data() != null) {
                    sourceTmm.setTrack2Data(decryptedData);
                    sourceTmm.setServiceRestrictionCode(trackData.getServiceCode());
                } else if (sourceTmm.getTrack1Data() != null) {
                    sourceTmm.setTrack1Data(decryptedData);
                    sourceTmm.setServiceRestrictionCode(trackData.getServiceCode());
                } else if (sourceTmm.getPan() != null) {
                    if (MtmUtil.isValidCardNumber(decryptedData)) {
                        sourceTmm.setPan(decryptedData);
                        sourceTmm.setMaskedPan(MaskingUtility.maskCardNumber(sourceTmm.getPan()));
                        sourceTmm.setEncryptedPan(encryprtionService.encrypt(sourceTmm.getPan()));
                        sourceTmm.setEncryptedExpirationDate(encryprtionService.encrypt(sourceTmm.getExpirationDate()));
                    } else {
                        throw new InvalidCardNumberException("Card Number " + decryptedData + " is invalid");
                    }
                }
                if (!isPan) {
                    String pan = trackData.getPan().replaceFirst("^0+(?!$)", "");
                    if (MtmUtil.isValidCardNumber(pan)) {
                        sourceTmm.setPan(pan);
                        sourceTmm.setMaskedPan(MaskingUtility.maskCardNumber(pan));
                        sourceTmm.setEncryptedPan(encryprtionService.encrypt(pan));
                        sourceTmm.setExpirationDate(trackData.getExp());
                        sourceTmm.setEncryptedExpirationDate(encryprtionService.encrypt(trackData.getExp()));
                    } else {
                        throw new InvalidCardNumberException("Card Number " + pan + " is invalid");
                    }
                    // CVV?
                }
            }
        } else if (sourceTmm.getSourceProcessor() == SourceProcessor.PG_SWITCH) {
            if (sourceTmm.getPan() != null) {
                sourceTmm.setMaskedPan(MaskingUtility.maskCardNumber(sourceTmm.getPan()));
                sourceTmm.setEncryptedPan(encryprtionService.encrypt(sourceTmm.getPan()));
                sourceTmm.setEncryptedExpirationDate(encryprtionService.encrypt(sourceTmm.getExpirationDate()));
            } else {
                throw new InvalidCardNumberException("Card Number " + sourceTmm.getPan() + " is invalid");
            }
        } else {
            throw new SystemErrorException("HSMService is not running");
        }
    }

    public static MessageContext constructMessage(TransactionMessageModel sourceTmm, String epId) {
        logger.debug("Starting to convert source pojo to raw msg for entity: {}, endpoint id: {}",
                sourceTmm.getEntityId(), epId);
        MessageContext msgContext = null;
        String txnName = sourceTmm.getTransactionName();

        TransactionTypeConfig txnTypeConfig = identifyTargetTxnTypeConfig(txnName, sourceTmm.getTargetType(), epId);

        logger.trace("Fetching MessageTransformationConfig for: {}", txnTypeConfig);
        MessageTransformationConfig msgTransConfig = getMessageTransformationConfig(sourceTmm.getEntityId(), epId,
                txnTypeConfig);
        Class<?> className = msgTransConfig.getBusinessRuleClass();
        logger.trace("Constructing message from class: {}", className);
        try {
            BaseMessageTransformation baseMsgTrans = (BaseMessageTransformation) className.newInstance();
            msgContext = baseMsgTrans.constructMessage(sourceTmm, epId, txnTypeConfig, msgTransConfig);
            msgContext.getTransactionMessageModel().setTransactionName(txnName);
        } catch (InvalidTxnException e) {
            throw new InvalidTxnException("Message transformation error ", e);
        } catch (InvalidVoidOrReversalDataException e) {
            throw new InvalidVoidOrReversalDataException("Data mismatch ", e);
        } catch (InstantiationException | IllegalAccessException e) {
            logger.error("Error while invoking business rule engine class: {} for entity: {} Endpoint id: {}",
                    className, sourceTmm.getEntityId(), epId, e);
        } catch (MessageTransformationException e) {
            logger.error("Message transformation error", e);
        }
        logger.debug("Conversion completed to raw msg for entity: {}, endpoint id: {}", sourceTmm.getEntityId(), epId);
        return msgContext;
    }

    public static TransactionTypeConfig identifyTargetTxnTypeConfig(String txnName, TargetType targetType,
                                                                    String epId) {
        TargetType epType = MessageTransformationContext.getEpIdTargetTypeMap().get(epId);
        /*
         * If schemeType is null it means switch is originating the transaction. e.g.
         * scheme sign on, heartbeat etc.
         */
        if (targetType != null && targetType.equals(epType)) {
            txnName = txnName.replace("request", "response");
        }
        List<TransactionTypeConfig> list = MessageTransformationContext.getTargetTypeTransTypeConfigMap().get(epType);
        for (TransactionTypeConfig txnType : list) {
            if (txnType.getTxnTypeName().equals(txnName)) {
                return txnType;
            }
        }
        throw new RuntimeException(LogUtils.buildLogMessage(null, epId, null, null,
                "Target message mapping definition does not exist for: " + txnName));
    }

    public static MwMessage parseUsingJpos(String endpointId, byte[] rawMsgBytes) {

        Map<String, MessageFormatConfigModel> msgFormatMap = MessageTransformationContext.getEpIdMsgTypeMsgFormatMap().get(endpointId);
        MessageFormatConfigModel defaultMsgFormat = msgFormatMap.get("0000");
        String msgTypeMsgFormat = null;
        MwMessage mwMessage = null;
        try {
            InputStream msgFormatStream = new ByteArrayInputStream(defaultMsgFormat.getMsgFormat().getBytes());
            mwMessage = MwIsoPackager.parse(rawMsgBytes, msgFormatStream);
            String msgType = ((BaseMessage) mwMessage).getMTI();

            logger.trace(LogUtils.buildLogMessage(null, endpointId, msgType, null, "Message type: {}"), msgType);

            MessageFormatConfigModel messageFormatConfigModel2 = msgFormatMap.get(msgType);
            msgTypeMsgFormat = messageFormatConfigModel2.getMsgFormat();
            if (msgTypeMsgFormat != null && !msgTypeMsgFormat.trim().isEmpty()) {
                msgFormatStream = new ByteArrayInputStream(msgTypeMsgFormat.getBytes());
                mwMessage = MwIsoPackager.parse(rawMsgBytes, msgFormatStream);
            }
        } catch (ISOException e) {
            e.printStackTrace();
        }
        return mwMessage;
    }

    public static TransactionMessageModel toPojo(String entityId, OffsetDateTime timeOfAction, String epId,
                                                 String strMsg, TlmMessageType tlmMessageType, String txnName) {
        logger.debug("Starting to convert raw msg, to pojo for entity: {}, endpoint id: {}", entityId, epId);
        TransactionMessageModel sourceTmm = null;
        try {
            PipeStringMsg pipeStringMsg = new PipeStringMsg(strMsg);
            ITmmParser parser = ParserFactory.getParser(MessageFormat.PG_PIPE_STRING);
            sourceTmm = parser.parse(pipeStringMsg, entityId, epId, txnName);
            setAdditionalData(entityId, timeOfAction, epId, tlmMessageType, sourceTmm);
            logger.debug("Pojo conversion completed for entity: {}, endpoint id: {}", entityId, epId);
        } catch (MessageBuildException e) {
            logger.trace("", e);
            throw new MessageBuildException("Error while transforming raw message to TMM pojo", e);
        } catch (Exception e) {
            logger.trace("", e);
        }
        return sourceTmm;

    }

    public static String getPgResponse(MessageContext targetMsgContext) {
        PipeStringParser parserObj = (PipeStringParser) ParserFactory.getParser(MessageFormat.PG_PIPE_STRING);
        TransactionMessageModel tmmModel = targetMsgContext.getTransactionMessageModel();

        String resString = null;
        try {

            Map<Integer, String> tmmConfig = targetMsgContext.getMessageTransformationConfig().getTmmConfig();
            resString = parserObj.convert(tmmModel, tmmConfig);
        } catch (Exception e) {
            logger.info("Exception During converting tmm to pg string : {} , {} ", e.getMessage(), e.getClass());
        }
        return resString;
    }

    public static void setAdditionalData(String entityId, OffsetDateTime timeOfAction, String epId,
                                         TlmMessageType tlmMessageType, TransactionMessageModel sourceTmm) {
        sourceTmm.setSource(epId);
        sourceTmm.setEntityId(entityId);
        sourceTmm.setTlmMessageType(tlmMessageType);
        if (tlmMessageType.equals(TlmMessageType.REQUEST)) {
            sourceTmm.setRequestReceivedTime(timeOfAction);
        } else {
            sourceTmm.setResponseReceivedTime(timeOfAction);
        }
    }
    
    
    public static byte[] parseAndCreateISO(String message) {
    	TransactionMessageModel reqSrcTmm = IsgJsonUtils.getObjectFromJsonString(message, TransactionMessageModel.class);
    	logger.info("POS API Request Tmm: " + reqSrcTmm);
    	StringBuilder msgString = new StringBuilder();
    	msgString.append("6000560000");
    	msgString.append(reqSrcTmm.getMsgType());
    	Map<Integer, String> fieldsMap = getJsonToFieldMap();
    	
    	fieldsMap.forEach((fieldNo, fieldMethodName) -> {
    		String data = getData(reqSrcTmm, fieldMethodName);
    		if (data != null) {
    			msgString.append(data);
    		}
        });
    	byte[] bytes = packData(DatatypeConverter.parseHexBinary(msgString.toString()));
    	//logger.info("Bytes Msg from API: "+ DatatypeConverter.printHexBinary(bytes));
    	return bytes;
    	
    }
    
    static byte[] packData(byte[] data) {
        int len = data.length;
        byte buf[] = new byte[len + 2];
        buf[0] = (byte) (len >> 8 & 255);
        buf[1] = (byte) (len & 255);
        System.arraycopy(data, 0, buf, 2, len);
        return buf;
    }
    
    public static String getData(TransactionMessageModel tmm, String methodName) {
        String data = null;
        if (methodName != null) {
            try {
                methodName = "get" + methodName.substring(3);
                Method declaredMethod = TransactionMessageModel.class.getDeclaredMethod(methodName);
                data = (String) declaredMethod.invoke(tmm);
            } catch (NoSuchMethodException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            	throw new MessageParsingException("Error while invoking method: " + methodName, e);
            }
        }
        return data;
    }
    
    public static Map<Integer, String> getJsonToFieldMap () {
    	Map<Integer, String> fieldsMap = new LinkedHashMap<>();
        fieldsMap.put(1, TmmConstants.BITMAP);
        fieldsMap.put(2, TmmConstants.PAN);
        fieldsMap.put(3, TmmConstants.PROCESSING_CODE);
        fieldsMap.put(4, TmmConstants.TXN_AMT);
        fieldsMap.put(11, TmmConstants.STAN);
        fieldsMap.put(12, TmmConstants.LOCAL_TXN_TIME);
        fieldsMap.put(13, TmmConstants.LOCAL_TXN_DATE);
        fieldsMap.put(14, TmmConstants.EXPIRATION_DATE);
        fieldsMap.put(22, TmmConstants.POS_ENTRY_MODE);
        fieldsMap.put(24, TmmConstants.NIIID);
        fieldsMap.put(25, TmmConstants.POS_CONDITION_CODE);
        fieldsMap.put(35, TmmConstants.TRACK2_DATA);
        fieldsMap.put(37, TmmConstants.RETRIEVAL_REF_NO);
        fieldsMap.put(38, TmmConstants.AUTH_ID_RES);
        fieldsMap.put(39, TmmConstants.RES_CODE);
        fieldsMap.put(41, TmmConstants.CARD_ACCEPTOR_TERMINAL_ID);
        fieldsMap.put(42, TmmConstants.CARD_ACCEPTOR_ID);
        fieldsMap.put(45, TmmConstants.TRACK1_DATA);
        fieldsMap.put(47, TmmConstants.NATIONAL_AD);
        fieldsMap.put(52, TmmConstants.PIN);
        fieldsMap.put(53, TmmConstants.SECURITY_CONTROL_INFO);
        fieldsMap.put(54, TmmConstants.ADDITIONAL_AMOUNTS);
        fieldsMap.put(55, TmmConstants.ICC_DATA);
        fieldsMap.put(60, TmmConstants.TERMINAL_DATA);
        fieldsMap.put(61, TmmConstants.CIAD);
        fieldsMap.put(62, TmmConstants.POSTAL_CODE);
        fieldsMap.put(63, TmmConstants.ATM_PIN_OFFSET_DATA);
		return fieldsMap;
    }
}
