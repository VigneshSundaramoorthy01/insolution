package com.isg.mw.mtm.parser.exception;

import com.isg.mw.core.model.exception.MWException;

public class ISO8583ParsingException extends MWException {

	private static final long serialVersionUID = -6193331342520912687L;
	
	public ISO8583ParsingException(String message, Throwable cause) {
		super(message, cause);
	}

	public ISO8583ParsingException(String message) {
		super(message);
	}

}