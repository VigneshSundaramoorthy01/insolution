package com.isg.mw.mtm.exception;

public class MessageTransformationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageTransformationException(String expMsg) {
		super(expMsg);
	}

	public MessageTransformationException(String expMsg, Throwable e) {
		super(expMsg, e);
	}

}
