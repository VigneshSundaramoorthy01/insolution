package com.isg.mw.mtm.construct;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.*;

import com.isg.mw.cache.mgmt.service.CacheServices;
import com.isg.mw.core.filter.constants.FilterConstants;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.construct.cybs.CybsMsgTypeHelper;
import com.isg.mw.core.model.construct.pg.PgMsgTypeHelper;
import com.isg.mw.core.model.sr.MerchantMasterModel;
import com.isg.mw.core.utils.IsgCurrencyConversionUtils;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MwRedisCacheUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOUtil;
import org.jpos.tlv.TLVList;
import org.jpos.tlv.TLVMsg;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.maps.MapsInfoModel;
import com.isg.mw.core.model.tlm.TransactionBatchResponseModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.rbac.utils.RbacUtil;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.mtm.config.MTMProperties;
import com.isg.mw.mtm.config.SpringContextBridge;
import com.isg.mw.mtm.context.MessageTransformationContext;
import com.isg.mw.mtm.exception.InvalidVoidOrReversalDataException;
import com.isg.mw.mtm.exception.MessageConstructionException;
import com.isg.mw.mtm.parser.msg.BaseMessage;
import com.isg.mw.mtm.util.MtmUtil;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static com.isg.mw.mtm.construct.MessageConstructionHelper.*;

public abstract class SwitchBaseMessageConstruction implements IMessageConstruction {

    protected static Logger logger = LogManager.getLogger();


    @Getter
    protected BaseMessage baseMessage;

    /**
     * Source Transaction Message Model
     */
    @Getter
    protected TransactionMessageModel sourceTmm;

    /**
     * Target Transaction Message Model
     */
    @Setter
    @Getter
    protected TransactionMessageModel targetTmm;

    @Setter
    protected TransactionMessageModel originalTmm;
    
    
    @Setter
    @Getter
    protected TransactionMessageModel apiTargetTmm;

    protected final CacheServices cacheServices;

    protected final HsmCommonService hsmCommonService;


    /**
     * MW as switch: Target processing code
     */
    @Getter
    @Setter
    protected String targetMsgTypeId;

    /**
     * MW as switch: Target MTI
     */
    @Getter
    @Setter
    protected String targetMsgType;

    /**
     * Hsm Vendor name
     */
    protected HsmVendor hsmVendor;

    /**
     * MW as switch: Target processing code
     */
    @Getter
    @Setter
    protected String sourceMsgTypeId;

    /**
     * MW as switch: Target MTI
     */
    @Getter
    @Setter
    protected String sourceMsgType;

    /**
     * Merchant data fetched from cache engine
     */
    protected MapsInfoModel merchantData;

    protected MerchantMasterModel merchantMasterModel;


    @Getter
    @Setter
    protected PinTranslationType pinTranslationType;

    protected final MwRedisCacheUtil mwRedisCacheUtil;

    private static final String ERROR_MSG = "Error while constructing data element: ";

    private static final int fetchOriginalTransactionRetries = readProperty("fetch.original.txn.retries", 3);
    private static final long fetchOriginalTransactionTimeout = readProperty("fetch.original.txn.timeout", 1000L);
    private static final long fetchOriginalTransactionRetryDelay = readProperty("fetch.original.txn.retry.delay", 500L);
    public static final int fetchReversalTimeoutRetries = readProperty("fetch.reversal.timeout.retries", 3);

    private static final int batchTransactionRetries = readProperty("batch.txn.retries", 3);
    //private static final long batchTransactionTimeout = readProperty("batch.txn.timeout", 1000L);
    private static final long batchTransactionRetryDelay = readProperty("batch.txn.retry.delay", 500L);

    private static final String JWT_KEY = "JWT-TOKEN";

    private static final String USER_NAME_HEADER = "User-Name";

    private static int readProperty(String propertyName, int defaultVal) {
        return MTMProperties.getProperty(propertyName) == null ? defaultVal
                : Integer.parseInt(MTMProperties.getProperty(propertyName));
    }

    private static long readProperty(String propertyName, long defaultVal) {
        return MTMProperties.getProperty(propertyName) == null ? defaultVal
                : Long.parseLong(MTMProperties.getProperty(propertyName));
    }

    protected SwitchBaseMessageConstruction() {
        this.baseMessage = new BaseMessage();
        this.cacheServices = SpringContextBridge.services().getCacheService();
        this.hsmCommonService = SpringContextBridge.services().getHsmCommonService();
        this.mwRedisCacheUtil = SpringContextBridge.services().getMwRedisCacheUtil();
    }

    public void setSourceTmm(TransactionMessageModel sourceTmm) {
        this.sourceTmm = sourceTmm;
        if (this.sourceTmm.getSourceProcessor() == SourceProcessor.SMART_ROUTE) {
            this.merchantData = this.cacheServices.validateAndGetMerchant(this.sourceTmm.getEntityId(),
                    this.sourceTmm.getCardAcceptorId(), this.sourceTmm.getCardAcceptorTerminalId(),
                    this.sourceTmm.getCardHolderBillingCurrencyCode());

            this.merchantMasterModel = this.cacheServices.validateAndGetMerchantMaster(this.sourceTmm.getEntityId(), this.sourceTmm.getCardAcceptorId());
        }

        if ((this.sourceTmm.getSourceProcessor() != SourceProcessor.SMART_ROUTE) && (this.sourceTmm.getCardAcceptorId() != null && this.sourceTmm.getCardAcceptorTerminalId() != null)) {
            this.merchantData = this.cacheServices.validateAndGetMerchant(this.sourceTmm.getEntityId(),
                    this.sourceTmm.getCardAcceptorId().trim(), this.sourceTmm.getCardAcceptorTerminalId(),
                    this.sourceTmm.getCardHolderBillingCurrencyCode());
            this.hsmVendor = hsmCommonService.getHsmVendorByEntityId(this.sourceTmm.getEntityId());

            if (isBatchUploadRequest(this.sourceTmm.getBatchUploadMsgType())) {
                uploadBatchUpload();
            }
            /*
             * else if (isPreAuthCompletionRequest(this.sourceMsgType,
             * this.sourceMsgTypeId)) { this.originalTmm =
             * fetchOriginalTransaction(this.sourceTmm); }
             */
            else if (isBatchSettlementRequest(this.sourceMsgType, this.sourceMsgTypeId)) {
                uploadBatchSettlement();
            } 
        }
    }

    public void updateDrCrFlag() {
        String reversalMsgReasonCode = this.sourceTmm.getPgData() != null ? this.sourceTmm.getPgData().getReversalMessageReasonCode() : null;
        if (isPosVoidReq(this.sourceMsgType, this.sourceMsgTypeId)
                || isPosVoidResponse(this.targetMsgType, this.targetMsgTypeId)) {
            this.targetTmm.setDrcrFlag("V");
        } else if (isReversalRequest(this.targetMsgType) || isAllSchemeReversalRes(this.targetMsgType)
                || isReversalRequest(this.sourceMsgType) || isAllSchemeReversalRes(this.sourceMsgType)
                || CybsMsgTypeHelper.isCybsReversal(this.targetMsgType) || CybsMsgTypeHelper.isReversalTimeout(this.targetMsgType)) {
            if (!StringUtils.isBlank(reversalMsgReasonCode) && reversalMsgReasonCode.equals("V")) {
                this.targetTmm.setDrcrFlag("V");
            } else {
                this.targetTmm.setDrcrFlag("R");
            }
        } else if (isPosRefundReq(this.sourceMsgType, this.sourceMsgTypeId)
                || isPosRefundResponse(this.targetMsgType, this.targetMsgTypeId)
                || PgMsgTypeHelper.isOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoOnlineOfflineRefund(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.setDrcrFlag("C");
        } else if (isPosPreAuthReq(this.sourceMsgType, this.sourceMsgTypeId)
                || isPosPreAuthResponse(this.targetMsgType, this.targetMsgTypeId)
                || isPosBalInqReq(this.sourceMsgType, this.sourceMsgTypeId)
                || isPosBalEnqResponse(this.targetMsgType, this.targetMsgTypeId)
                || isBatchSettlementRequest(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isPreAuth(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isMotoPreAuth(this.sourceMsgType, this.sourceMsgTypeId)
                || isDccRateLookup(this.targetMsgType, this.targetMsgTypeId)
                || PgMsgTypeHelper.isZvavPurchase(this.sourceMsgType, this.sourceMsgTypeId)
                || PgMsgTypeHelper.isZvavPurchaseAav(this.sourceMsgType, this.sourceMsgTypeId)
                || isPosZvavReq(this.sourceMsgType, this.sourceMsgTypeId)
                || isPosZvavResponse(this.sourceMsgType, this.sourceMsgTypeId)) {
            this.targetTmm.setDrcrFlag("N");
        } else {
            this.targetTmm.setDrcrFlag("D");
        }
    }

    private static TransactionMessageModel callTlmApi(String url, HttpHeaders headers,
                                                      TransactionMessageModel sourceTmm) {
        setLoggerContextDataInHttpHeader(headers);

        TransactionMessageModel messageModel = null;
        boolean fetchedOriginalTransaction = false;
        int currentFetchedOriginalTransactionRetries = fetchOriginalTransactionRetries;
        while (!fetchedOriginalTransaction && currentFetchedOriginalTransactionRetries > 0) {
            try {
                WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
                Mono<TransactionMessageModel> transactionMessageModelMono = webClient.build().post().uri(url).headers(httpHeaders -> {
                            httpHeaders.addAll(headers);
                        }).body(Mono.just(sourceTmm),
                                TransactionMessageModel.class).retrieve()
                        .bodyToMono(TransactionMessageModel.class);

                messageModel = transactionMessageModelMono.block(Duration.ofMillis(fetchOriginalTransactionTimeout));

//                RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
//                headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//
//                HttpEntity<TransactionMessageModel> request = new HttpEntity<>(sourceTmm, headers);
//
//                ResponseEntity<TransactionMessageModel> exchange = restTemplate.exchange(url, HttpMethod.POST, request,
//                        TransactionMessageModel.class);
//                messageModel = exchange.getBody();
                fetchedOriginalTransaction = true;
                logger.trace("TLM API Response: {}", messageModel);
            } catch (RuntimeException e) {
                logger.error(
                        LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                                sourceTmm.getTransactionId(), "Error fetching original transaction" + e));

                try {
                    Thread.sleep(fetchOriginalTransactionRetryDelay);
                } catch (InterruptedException interruptedException) {
                    throw new RuntimeException("Thread interrupted");
                }
                --currentFetchedOriginalTransactionRetries;
            }
        }
        if (fetchedOriginalTransaction) {
            logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                    sourceTmm.getTransactionId(), "Fetched original transaction"));
        } else if (!fetchedOriginalTransaction && (TmmConstants.REFUND_REQUEST.equals(sourceTmm.getTransactionName()))){
        	logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                    sourceTmm.getTransactionId(), "No Refund transaction found"));
        } else {
            logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                    sourceTmm.getTransactionId(), "Failed to fetch original transaction"));
            throw new InvalidVoidOrReversalDataException("NotFound");
        }

        Optional.ofNullable(messageModel).ifPresent(tmm -> tmm.setAcpTraceId(sourceTmm.getAcpTraceId()));

        return messageModel;
    }

    public static TransactionMessageModel fetchOriginalTransaction(TransactionMessageModel sourceTmm) {
        logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                sourceTmm.getTransactionId(), "Fetching original transaction"));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
        logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));

        String voidReversalUrl = MTMProperties.getProperty("void.reversal.tlm.api");

        logger.trace("Fetch existing transaction: {}", voidReversalUrl);
        return callTlmApi(voidReversalUrl, headers, sourceTmm);
    }


    public static TransactionMessageModel fetchTerminalBatchDetails(TransactionMessageModel sourceTmm) {
        logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                sourceTmm.getTransactionId(), "Fetching original transaction"));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
        logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));

        String terminalBatchDetailsUrl = MTMProperties.getProperty("terminal.batch.details.api");

        logger.trace("Fetch existing transaction: {}", terminalBatchDetailsUrl);
        return callTlmApi(terminalBatchDetailsUrl, headers, sourceTmm);
    }
    
    public static TransactionMessageModel fetchSettlementTxnTransactionEftpos(TransactionMessageModel sourceTmm) {
        logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                sourceTmm.getTransactionId(), "Fetching setement transaction"));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
        logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        String settlementEftposUrl = MTMProperties.getProperty("eftpos.settlement.tlm.api");

        logger.trace("Fetch existing transaction: {}", settlementEftposUrl);

        TransactionMessageModel messageModel = new TransactionMessageModel();
        try {
            JSONObject jn=new JSONObject();
            HashMap<String,String> hm=new HashMap<>();
            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
            formData.add("entityId", sourceTmm.getEntityId());
            formData.add("targetName", sourceTmm.getTarget());
//            formData.add("password", "XXXX");
            //jn.put("entityId", sourceTmm.getEntityId());
            WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
            Mono<TransactionMessageModel> transactionMessageModelMono = webClient.build().post()
                    .uri(settlementEftposUrl)
                    .headers(httpHeaders -> {
                        httpHeaders.addAll(headers);
                    })
                    .body(Mono.just(formData),
                            MultiValueMap.class).retrieve()

                    .bodyToMono(TransactionMessageModel.class);
//            Mono<TransactionMessageModel> transactionMessageModelMono = webClient.build().get().uri(settlementEftposUrl + "?entityId=" + sourceTmm.getEntityId()).retrieve().bodyToMono(TransactionMessageModel.class).onErrorResume(e -> Mono.empty());
//            webClient.build().get()
//                    .uri(uriBuilder - > uriBuilder
//                            .path("/products/")
//                            .queryParam("name", "AndroidPhone")
//                            .queryParam("color", "black")
//                            .queryParam("deliveryDate", "13/04/2019")
//                            .build())
//                    .retrieve()
//                    .bodyToMono(String.class)
//                    .onErrorResume(e -> Mono.empty())
//                    .block();

            messageModel = transactionMessageModelMono.block(Duration.ofSeconds(80));
            messageModel.setEntityId(sourceTmm.getEntityId());
            messageModel.setTarget(sourceTmm.getTarget());
            logger.trace("TLM API Response: {}", messageModel);
        } catch (RuntimeException e) {
            logger.error(
                    LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                            sourceTmm.getTransactionId(), "Error fetching original transaction" + e));
        }
        return messageModel;
    }

    private void uploadBatchSettlement() {
        logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                sourceTmm.getTransactionId(), "Initiating batch settlement transaction"));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
        logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));

        String batchSettlementUrl = MTMProperties.getProperty("batch.settlement.tlm.api");

        logger.trace("Rest URL: {}", batchSettlementUrl);

        callTlmApi(headers, batchSettlementUrl);
    }
    
    private void callTlmApi(HttpHeaders headers, String batchSettlementUrl) {
        setLoggerContextDataInHttpHeader(headers);

        boolean fetchedOriginalTransaction = false;
        TransactionBatchResponseModel messageModel = null;
        int currentSettlementTransactionRetries = batchTransactionRetries;
        while (!fetchedOriginalTransaction && currentSettlementTransactionRetries > 0) {
            try {
//                WebClient.Builder webClient = SpringContextBridge.services().getWebClient();
//                Mono<TransactionBatchResponseModel> transactionBatchResponseModelMono = webClient.build().post()
//                        .uri(batchSettlementUrl, headers).body(Mono.just(this.sourceTmm), TransactionMessageModel.class)
//                        .retrieve().bodyToMono(TransactionBatchResponseModel.class);

                RestTemplate restTemplate = SpringContextBridge.services().getRestTemplate();
                headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
                HttpEntity<TransactionMessageModel> request = new HttpEntity<>(sourceTmm, headers);

                ResponseEntity<TransactionBatchResponseModel> exchange = restTemplate.exchange(batchSettlementUrl,
                        HttpMethod.POST, request, TransactionBatchResponseModel.class);

//                messageModel = transactionBatchResponseModelMono.block(Duration.ofMillis(batchTransactionTimeout));
                messageModel = exchange.getBody();
                fetchedOriginalTransaction = true;
                logger.trace("Batch API Response: {}", messageModel);
                logger.info(
                        LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                                sourceTmm.getTransactionId(), "Successfully completed batch transaction"));
                this.sourceTmm.setResCode(messageModel.getCode());
            } catch (RuntimeException e) {
                logger.error(
                        LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                                sourceTmm.getTransactionId(), " Failed to complete batch transaction " + e));
                try {
                    Thread.sleep(batchTransactionRetryDelay);
                } catch (InterruptedException interruptedException) {
                    throw new RuntimeException("Thread interrupted");
                }
                --currentSettlementTransactionRetries;
            }
        }
    }
    
    private void uploadBatchUpload() {
        logger.info(LogUtils.buildLogMessage(sourceTmm.getEntityId(), sourceTmm.getSource(), sourceTmm.getMsgType(),
                sourceTmm.getTransactionId(), "Initiating batch upload transaction"));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", RbacUtil.getJwtTokenMap().get(JWT_KEY));
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add(USER_NAME_HEADER, RbacUtil.getJwtTokenMap().get(USER_NAME_HEADER));
        logger.trace("TLM JWT Authorization: {}", RbacUtil.getJwtTokenMap().get(JWT_KEY));

        String batchUploadUrl = MTMProperties.getProperty("batch.upload.tlm.api");
        logger.trace("Rest URL: {}", batchUploadUrl);

        callTlmApi(headers, batchUploadUrl);
    }

    private static void setLoggerContextDataInHttpHeader(HttpHeaders headers) {
        boolean isAcpTraceIdPresent = ThreadContext.containsKey(FilterConstants.threadContextAcpTraceId);
        boolean isRrnPresent = ThreadContext.containsKey(FilterConstants.threadContextRetrievalRefNo);

        if (isAcpTraceIdPresent) {
            headers.add(FilterConstants.httpHeaderAcpTraceId, ThreadContext.get(FilterConstants.threadContextAcpTraceId));
        }

        if(isRrnPresent) {
            headers.add(FilterConstants.httpHeaderRetrievalRefNo, ThreadContext.get(FilterConstants.threadContextRetrievalRefNo));
        }
    }

    @Override
    public void setMti() {
        try {
            baseMessage.setMTI(this.targetMsgType);
        } catch (ISOException e) {
            throw new MessageConstructionException(ERROR_MSG + "MTI", e);
        }
    }

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */
    @Override
    public void setBitMap(int fieldNo) {
        // method has been intentionally left blank, actual bitmap value will be set by
        // JPOS
    }

    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */
    @Override
    public void setPan(int fieldNo) {
        String pan = this.sourceTmm.getPan();
        this.targetTmm.setPan(pan);
        this.apiTargetTmm.setPan(pan);
        this.baseMessage.set(fieldNo, pan);
    }

    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    @Override
    public void setProcessingCode(int fieldNo) {
        this.targetTmm.setProcessingCode(this.targetMsgTypeId);
        this.apiTargetTmm.setProcessingCode(this.targetMsgTypeId);
        this.baseMessage.set(fieldNo, this.targetMsgTypeId);
    }

    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     */
    @Override
    public void setTxnAmt(int fieldNo) {
        String txnAmt = this.sourceTmm.getTxnAmt() != null ? this.sourceTmm.getTxnAmt() : "0";
        txnAmt = StringUtils.leftPad(txnAmt, 4, "0");
        this.targetTmm.setTxnAmt(txnAmt);
        this.apiTargetTmm.setTxnAmt(txnAmt);
        this.baseMessage.set(fieldNo, txnAmt);
    }

    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */
    @Override
    public void setSettlementAmt(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */
    @Override
    public void setCardHolderBillingAmt(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }


    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */
    public void setTransmissionTime(int fieldNo) {

    }

    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */
    @Override
    public void setCardHolderBillingFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */
    @Override
    public void setSettlementConversionRate(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */
    @Override
    public void setCardHolderBillingConversionRate(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    @Override
    public void setStan(int fieldNo) {
        buildStan();
        this.baseMessage.set(fieldNo, this.targetTmm.getStan());
    }

    protected void buildStan() {
        RedisAtomicInteger atomicInteger = mwRedisCacheUtil.getAtomicInteger();
        atomicInteger.compareAndSet(0, 1);
        atomicInteger.compareAndSet(999999, 1);
        String myStan = StringUtils.leftPad(String.valueOf(atomicInteger.getAndIncrement()), 6, "0");
        this.targetTmm.setStan(myStan);
        this.targetTmm.setSchemeStan(myStan);
    }

    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    @Override
    public void setLocalTxnTime(int fieldNo) {
        String localTxnTime = MtmUtil.formatDate("HHmmss");
        this.targetTmm.setLocalTxnTime(localTxnTime);
        this.apiTargetTmm.setLocalTxnTime(localTxnTime);
        this.baseMessage.set(fieldNo, localTxnTime);
    }

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */
    @Override
    public void setLocalTxnDate(int fieldNo) {
        String localTxnDate = MtmUtil.formatDate("MMdd");
        this.targetTmm.setLocalTxnDate(localTxnDate);
        this.apiTargetTmm.setLocalTxnDate(localTxnDate);
        this.baseMessage.set(fieldNo, localTxnDate);
    }

    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */
    @Override
    public void setExpirationDate(int fieldNo) {
        String expiryDate = this.sourceTmm.getExpirationDate();
        this.targetTmm.setExpirationDate(expiryDate);
        this.baseMessage.set(fieldNo, expiryDate);
    }

    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */
    @Override
    public void setSettlementDate(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */
    @Override
    public void setConversionDate(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */
    @Override
    public void setCaptureDate(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */
    @Override
    public void setMerchantType(int fieldNo) {
        this.targetTmm.setMerchantType(this.merchantData.getMerchantType());
        this.baseMessage.set(fieldNo, this.merchantData.getMerchantType());
    }

    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */
    @Override
    public void setAquirerCountryCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */
    @Override
    public void setPanExtendedCountryCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */
    @Override
    public void setPanForwardingCountryCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 22. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled
     */
    @Override
    public void setPosEntryMode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */
    @Override
    public void setCardSeqNo(int fieldNo) {
		/*if (validatePosEntryMode(55, this.sourceTmm.getPosEntryMode().substring(0, 2),
				MessageTransformationContext.getEpIdTargetTypeMap().get(this.sourceTmm.getTarget()))) {*/
        String iccData = this.sourceTmm.getIccData();
        if (iccData != null) {
            TLVList list = new TLVList();
            list.unpack(ISOUtil.hex2byte(iccData));
            List<TLVMsg> tags = list.getTags();
            tags.forEach(tlvField -> {
                if (Integer.toHexString(tlvField.getTag()).equals("5f34")) {
                    String panSeqNo = ISOUtil.hexString(tlvField.getValue());
                    this.targetTmm.setCardSeqNo(StringUtils.leftPad(panSeqNo, 3, "0"));
                    this.baseMessage.set(fieldNo, panSeqNo);
                    return;
                }
            });
        }
        //}
    }

    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */
    @Override
    public void setNiiId(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    @Override
    public void setPosConditionCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */
    @Override
    public void setPosCaptureCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */
    @Override
    public void setAuthIdResLength(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */
    @Override
    public void setTxnFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */
    @Override
    public void setSettlementFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */
    @Override
    public void setTxnProcessingFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */
    @Override
    public void setSettlementProcessingFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    @Override
    public void setAquirerIdCode(int fieldNo) {
        String acquirerInstitutionId = this.sourceTmm.getAquirerIdCode();
        this.targetTmm.setAquirerIdCode(acquirerInstitutionId);
        this.baseMessage.set(fieldNo, acquirerInstitutionId);
    }

    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */
    @Override
    public void setForwardingInstIdCode(int fieldNo) {
        String forwardingInstitutionId = sourceTmm.getForwardingInstIdCode();
        this.targetTmm.setForwardingInstIdCode(forwardingInstitutionId);
        this.baseMessage.set(fieldNo, forwardingInstitutionId);
    }

    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */
    @Override
    public void setPanExtended(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     */
    @Override
    public void setTrack2Data(int fieldNo) {
        String decryptedData = this.sourceTmm.getTrack2Data();
        this.targetTmm.setTrack2Data(decryptedData);
        this.apiTargetTmm.setTrack2Data(decryptedData);
        this.baseMessage.set(fieldNo, decryptedData);
    }

    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */
    @Override
    public void setTrack3Data(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * Format : YDDDHH000000
     * CyberSource API - TransactionId
     */
    @Override
    public void setRetrievalRefNo(int fieldNo) {

        String position1TO6 = MtmUtil.generateFirstSixDigitOfRrn();
        String position7TO12 = this.targetTmm.getStan();

        String rrnNumber = position1TO6 + position7TO12;

        ThreadContext.put(FilterConstants.threadContextRetrievalRefNo, rrnNumber);

        this.targetTmm.setRetrievalRefNo(rrnNumber);
        this.apiTargetTmm.setRetrievalRefNo(rrnNumber);
        this.baseMessage.set(fieldNo, rrnNumber.getBytes());
    }

    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */
    @Override
    public void setAuthIdRes(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     */
    @Override
    public void setResCode(int fieldNo) {
        String resCode = this.sourceTmm.getResCode();
        this.targetTmm.setResCode(resCode);
        this.apiTargetTmm.setResCode(resCode.getBytes().toString());
        this.baseMessage.set(fieldNo, resCode.getBytes());
    }

    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */
    @Override
    public void setServiceRestrictionCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     */
    @Override
    public void setCardAcceptorTerminalId(int fieldNo) {
        String cardAcceptorTermId = this.sourceTmm.getCardAcceptorTerminalId();
        if (cardAcceptorTermId != null) {
            this.targetTmm.setCardAcceptorTerminalId(cardAcceptorTermId);
            this.apiTargetTmm.setCardAcceptorTerminalId(ISOUtil.byte2hex(cardAcceptorTermId.getBytes()));
            this.baseMessage.set(fieldNo, cardAcceptorTermId.getBytes());
        }
    }

    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     */
    @Override
    public void setCardAcceptorId(int fieldNo) {
        String cardAcceptorId = this.sourceTmm.getCardAcceptorId();
        if (cardAcceptorId != null) {
        	this.targetTmm.setCardAcceptorId(cardAcceptorId);
        	this.apiTargetTmm.setCardAcceptorId(ISOUtil.byte2hex(cardAcceptorId.getBytes()));
        	this.baseMessage.set(fieldNo, cardAcceptorId.getBytes());
        }
    }

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     */
    @Override
    public void setCardAcceptorInfo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */
    @Override
    public void setAdditionalResData(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */
    @Override
    public void setTrack1Data(int fieldNo) {
        /*
         * if (this.sourceTmm.getTrack1Data() != null) { String decryptedData =
         * this.hsmService.decrypt(this.sourceTmm.getEntityId(),
         * this.sourceTmm.getSource(), this.sourceTmm.getSecurityControlInfo(),
         * this.sourceTmm.getTrack1Data()); this.targetTmm.setTrack1Data(decryptedData);
         * this.baseMessage.set(fieldNo, decryptedData); }
         */
    }

    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */
    @Override
    public void setIsoAd(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */
    @Override
    public void setNationalAd(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */
    @Override
    public void setPrivateAd(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */
    @Override
    public void setTxnCurrencyCode(int fieldNo) {
        String merchantCurrencyCode = this.sourceTmm.getTxnCurrencyCode() != null ? this.sourceTmm.getTxnCurrencyCode()
                : this.merchantData.getAcquirerCurrencyCode();
        this.targetTmm.setTxnCurrencyCode(merchantCurrencyCode);
        this.baseMessage.set(fieldNo, merchantCurrencyCode);
    }

    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */
    @Override
    public void setSettlementCurrencyCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */
    @Override
    public void setCardHolderBillingCurrencyCode(int fieldNo) {
        String merchantCurrencyCode = this.sourceTmm.getCardHolderBillingCurrencyCode() != null ? this.sourceTmm.getCardHolderBillingCurrencyCode()
                : this.merchantData.getAcquirerCurrencyCode();
        this.targetTmm.setCardHolderBillingCurrencyCode(merchantCurrencyCode);
        this.baseMessage.set(fieldNo, merchantCurrencyCode);
    }

    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */
    @Override
    public void setPin(int fieldNo) {
        String pan = this.sourceTmm.getPan();
        if (pan != null && this.sourceTmm.getPin() != null) {
            TargetType targetType = MessageTransformationContext.getEpIdTargetTypeMap().get(this.sourceTmm.getTarget());

            String dynamicKey = mwRedisCacheUtil.getTargetDynamicKeyData(this.sourceTmm.getEntityId() + "_" + SpringContextBridge.services().getHsmCommonService().
                            getHsmVendorByEntityId(sourceTmm.getEntityId()) + TmmConstants.DYNAMIC_KEY, targetType);

            Map<HsmCommandArg, String> hsmCmdArgMap = cacheServices.getMftrBDK(sourceTmm.getDeviceMftr());

            String pinTranslation = SpringContextBridge.getPinTranslationService(hsmVendor, pinTranslationType).pinTranslation(
                    this.sourceTmm.getEntityId(), this.sourceTmm.getSource(), this.sourceTmm.getTarget(),
                    this.sourceTmm.getPinblockKsn(), this.sourceTmm.getPin(), pan, dynamicKey, hsmCmdArgMap == null ? null : hsmCmdArgMap.get(HsmCommandArg.Bdk2));

            byte[] pinBytes = MtmUtil.toBytesAsIs(pinTranslation);
            this.targetTmm.setPin(pinTranslation);
            this.apiTargetTmm.setPin(ISOUtil.byte2hex(pinBytes));
            this.baseMessage.set(fieldNo, pinBytes);
        }
    }

    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */
    @Override
    public void setSecurityControlInfo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */
    @Override
    public void setAdditionalAmounts(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */
    public abstract void setIccData(int fieldNo);

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */
    @Override
    public void setReserved56(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */
    @Override
    public void setReserved57(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */
    @Override
    public void setReserved58(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */
    @Override
    public void setReserved59(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     */
    @Override
    public void setTerminalData(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);

    }

    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     */
    @Override
    public void setCiad(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);

    }

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code
     */
    @Override
    public void setPostalCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);


    }

    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     */
    @Override
    public void setAtmPinOffsetData(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */
    @Override
    public void setMsgAuthCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */
    @Override
    public void setExtendedBitmapIndicator(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */
    @Override
    public void setSettlementCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */
    @Override
    public void setExtendedPaymentCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */
    @Override
    public void setReceiverCountryCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     */
    @Override
    public void setSettlementCountryCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */
    @Override
    public void setNetworkMgmtInfoCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */
    @Override
    public void setMsgNo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */
    @Override
    public void setLastMsgNo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */
    @Override
    public void setActionDate(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */
    @Override
    public void setNoOfCredits(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */
    @Override
    public void setCreditsReversalNo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */
    @Override
    public void setNoOfDebits(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */
    @Override
    public void setDebitsReversalNo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */
    @Override
    public void setTransferNo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */
    @Override
    public void setTransferReversalNo(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */
    @Override
    public void setNoOfInquiries(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */
    @Override
    public void setNoOfAuths(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */
    @Override
    public void setCreditsProcessingFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */
    @Override
    public void setCreditsTxnFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */
    @Override
    public void setDebitsProcessingFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */
    @Override
    public void setDebitsTxnFee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */
    @Override
    public void setTotalCredits(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */
    @Override
    public void setCreditsReversal(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */
    @Override
    public void setTotalDebits(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */
    @Override
    public void setDebitsReversal(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */
    @Override
    public void setOriginalDataElements(int fieldNo) {
        if (isReversalRequest(this.sourceMsgType) || isPosVoidRequest(this.sourceMsgType, this.sourceMsgTypeId)) {
            String msgType = this.originalTmm.getMsgType();
            String stan = this.originalTmm.getStan();
            String transmissionTime = this.originalTmm.getTransmissionTime();
            String acquirerId = this.originalTmm.getAquirerIdCode();
            String forwardingInstId = Optional.ofNullable(this.sourceTmm.getForwardingInstIdCode()).orElse("00000000000");

            String originalDataElements = msgType + stan + transmissionTime + StringUtils.leftPad(acquirerId, 11, '0')
                    + StringUtils.leftPad(forwardingInstId, 11, '0');

            this.targetTmm.setOriginalDataElements(originalDataElements);
            this.baseMessage.set(fieldNo, originalDataElements);
        }
    }

    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */
    @Override
    public void setFileUpdateCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */
    @Override
    public void setFileSecurityCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */
    @Override
    public void setResIndicator(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */
    @Override
    public void setServiceIndicator(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */
    @Override
    public void setReplacementAmts(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */
    @Override
    public void setMsgSecurityCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */
    @Override
    public void setNetSettlement(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */
    @Override
    public void setPayee(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */
    @Override
    public void setSettlementIdCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */
    @Override
    public void setReceiverIdCode(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */
    @Override
    public void setFileName(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */
    @Override
    public void setAccId1(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */
    @Override
    public void setAccId2(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */
    @Override
    public void setTxnDesc(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    @Override
    public void setReserved105(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    @Override
    public void setReserved106(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    @Override
    public void setReserved107(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */
    @Override
    public void setReserved108(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    @Override
    public void setReserved109(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    @Override
    public void setReserved110(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    @Override
    public void setReserved111(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */
    @Override
    public void setReserved112(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    @Override
    public void setReserved113(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    @Override
    public void setReserved114(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    @Override
    public void setReserved115(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    @Override
    public void setReserved116(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */
    @Override
    public void setReserved117(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */
    @Override
    public void setReserved118(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */
    @Override
    public void setReserved119(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */
    @Override
    public void setReserved120(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */
    @Override
    public void setReserved121(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */
    @Override
    public void setReserved122(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */
    @Override
    public void setReserved123(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */
    @Override
    public void setReserved124(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */
    @Override
    public void setReserved125(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */
    @Override
    public void setReserved126(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */
    @Override
    public void setReserved127(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    /**
     * 128.<br>
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */
    @Override
    public void setReserved128(int fieldNo) {
        // throw new UndefinedBusinessRuleClassMethodException(fieldNo);
    }

    protected boolean isVoidOrReversal() {
        return isReversalRequest(this.sourceMsgType) || isPosVoidRequest(this.sourceMsgType, this.sourceMsgTypeId);
    }

    protected boolean validateVoidReversalData(String originalValue, String currentValue, String errorMsg) {
        if (currentValue != null && !currentValue.equals(originalValue)) {
            throw new InvalidVoidOrReversalDataException(
                    errorMsg + ", expected: " + originalValue + ", got: " + currentValue);
        }
        return true;
    }

    protected String fetchAvailableBalance(String de54AddlAmt) {
        return de54AddlAmt.substring(de54AddlAmt.length() - 12);
    }

    protected boolean validatePosEntryMode(final int dataElementNumber, final String PosEntryMode_1st2Digit,
                                           final TargetType Target) {
        boolean retValue = false;
        final List<Integer> dataElements = MtmUtil.getPanEntryModeDataElements().get(PosEntryMode_1st2Digit)
                .get(Target);
        if (dataElements != null && dataElements.contains(dataElementNumber)) {
            retValue = true;
        }
        return retValue;
    }

    protected boolean isCutOverResponse(final String networkMgmtInfoCode) {
        return "201".equals(networkMgmtInfoCode);
    }

    public static BigDecimal getTotalAmountInPaisaIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = new BigDecimal(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = new BigDecimal(tmmModel.getConvenienceFee());
        BigDecimal cgst = new BigDecimal(tmmModel.getCgst());
        BigDecimal sgst = new BigDecimal(tmmModel.getSgst());
        BigDecimal igst = new BigDecimal(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return new BigDecimal(amount.setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString());
    }

    public static BigDecimal getTotalAmountInRupeesIfCCSIinPaisa(TransactionMessageModel tmmModel) {
        BigDecimal amount = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getTxnAmt());
        //IF convenienceFee,cgst,sgst,igst in Paisa
        BigDecimal convenienceFee = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getConvenienceFee());
        BigDecimal cgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getCgst());
        BigDecimal sgst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getSgst());
        BigDecimal igst = IsgCurrencyConversionUtils.convertPaisaToRupees(tmmModel.getIgst());
        amount = amount.add(convenienceFee).add(cgst).add(sgst).add(igst);
        return amount.setScale(2,RoundingMode.HALF_UP);
    }
}
