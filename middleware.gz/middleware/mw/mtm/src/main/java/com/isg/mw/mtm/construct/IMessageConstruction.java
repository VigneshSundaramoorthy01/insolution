package com.isg.mw.mtm.construct;

//interface
public interface IMessageConstruction {

	void setMti();

	/**
	 * 1.<br>
	 * ISO8583 -1987, AS2805 - Secondary bitmap <br>
	 * Base24, ISG, XML - Bit map
	 */
	void setBitMap(int fieldNo);

	/**
	 * 2.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
	 * Account Number
	 */
	void setPan(int fieldNo);

	/**
	 * 3. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
	 * <br>
	 * mPOS - Transaction Type
	 */
	void setProcessingCode(int fieldNo);

	/**
	 * 4. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
	 * CyberSource API - AuthorizedAmount
	 */
	void setTxnAmt(int fieldNo);

	/**
	 * 5.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
	 */
	void setSettlementAmt(int fieldNo);

	/**
	 * 6.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
	 */
	void setCardHolderBillingAmt(int fieldNo);


    /**
	 * 7. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
	 */
	void setTransmissionTime(int fieldNo);

	/**
	 * 8. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
	 */
	void setCardHolderBillingFee(int fieldNo);

	/**
	 * 9. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
	 */
	void setSettlementConversionRate(int fieldNo);

	/**
	 * 10. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
	 */
	void setCardHolderBillingConversionRate(int fieldNo);

	/**
	 * 11. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
	 * <br>
	 * CyberSource API - T id
	 */
	void setStan(int fieldNo);

	/**
	 * 12. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
	 * CyberSource API - Transaction Local Date Time
	 */
	void setLocalTxnTime(int fieldNo);

	/**
	 * 13. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
	 */
	void setLocalTxnDate(int fieldNo);

	/**
	 * 14. <br>
	 * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
	 * Date
	 */
	void setExpirationDate(int fieldNo);

	/**
	 * 15. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
	 */
	void setSettlementDate(int fieldNo);

	/**
	 * 16. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
	 */
	void setConversionDate(int fieldNo);

	/**
	 * 17. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
	 */
	void setCaptureDate(int fieldNo);

	/**
	 * 18.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
	 * ISO8583 -1987, CyberSource API - Category Code
	 */
	void setMerchantType(int fieldNo);

	/**
	 * 19. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
	 * Country Code <br>
	 * mPOS - terminalCountryCode
	 */
	void setAquirerCountryCode(int fieldNo);

	/**
	 * 20. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
	 * code
	 */
	void setPanExtendedCountryCode(int fieldNo);

	/**
	 * 21. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
	 */
	void setPanForwardingCountryCode(int fieldNo);

	/**
	 * 22. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
	 * Entry Mode <br>
	 * mPOS - NFC Enabled
	 */
	void setPosEntryMode(int fieldNo);

	/**
	 * 23. <br>
	 * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
	 */
	void setCardSeqNo(int fieldNo);

	/**
	 * 24. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
	 * CyberSource API - Type
	 */
	void setNiiId(int fieldNo);

	/**
	 * 25. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
	 */
	void setPosConditionCode(int fieldNo);

	/**
	 * 26. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
	 */
	void setPosCaptureCode(int fieldNo);

	/**
	 * 27. <br>
	 * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
	 * length
	 */
	void setAuthIdResLength(int fieldNo);

	/**
	 * 28. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
	 */
	void setTxnFee(int fieldNo);

	/**
	 * 29. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
	 */
	void setSettlementFee(int fieldNo);

	/**
	 * 30. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
	 */
	void setTxnProcessingFee(int fieldNo);

	/**
	 * 31.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
	 * 
	 */
	void setSettlementProcessingFee(int fieldNo);

	/**
	 * 32. <br>
	 * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
	 * Code
	 */
	void setAquirerIdCode(int fieldNo);

	/**
	 * 33.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
	 * Code
	 */
	void setForwardingInstIdCode(int fieldNo);

	/**
	 * 34.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
	 */
	void setPanExtended(int fieldNo);

	/**
	 * 35.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
	 * 
	 */
	void setTrack2Data(int fieldNo);

	/**
	 * 36.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
	 */
	void setTrack3Data(int fieldNo);

	/**
	 * 37.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
	 * Number<br>
	 * CyberSource API - TransactionId
	 */
	void setRetrievalRefNo(int fieldNo);

	/**
	 * 38.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
	 * Response<br>
	 * mPOS - AuthCode
	 */
	void setAuthIdRes(int fieldNo);

	/**
	 * 39.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
	 * mPOS - Status Code
	 */
	void setResCode(int fieldNo);

	/**
	 * 40.<br>
	 * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
	 */
	void setServiceRestrictionCode(int fieldNo);

	/**
	 * 41.<br>
	 * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
	 * Identification
	 * 
	 */
	void setCardAcceptorTerminalId(int fieldNo);

	/**
	 * 42. <br>
	 * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
	 * Identification code<br>
	 * mPOS - TxnId
	 */
	void setCardAcceptorId(int fieldNo);

	/**
	 * 43.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
	 * Name/Location
	 */
	void setCardAcceptorInfo(int fieldNo);

	/**
	 * 44.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
	 */
	void setAdditionalResData(int fieldNo);

	/**
	 * 45.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
	 */
	void setTrack1Data(int fieldNo);

	/**
	 * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
	 */
	void setIsoAd(int fieldNo);

	/**
	 * 47.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Additional Data National
	 */
	void setNationalAd(int fieldNo);

	/**
	 * 48.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
	 */
	void setPrivateAd(int fieldNo);

	/**
	 * 49.<br>
	 * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
	 * Code
	 */
	void setTxnCurrencyCode(int fieldNo);

	/**
	 * 50.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
	 */
	void setSettlementCurrencyCode(int fieldNo);

	/**
	 * 51.<br>
	 * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
	 */
	void setCardHolderBillingCurrencyCode(int fieldNo);

	/**
	 * 52.<br>
	 * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
	 * (PIN) Data<br>
	 * CyberSource API - Encrypted Pin
	 */
	void setPin(int fieldNo);

	/**
	 * 53.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
	 * Information<br>
	 * CyberSource API - Encrypted Key Serial Number
	 */
	void setSecurityControlInfo(int fieldNo);

	/**
	 * 54.<br>
	 * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
	 */
	void setAdditionalAmounts(int fieldNo);

	/**
	 * 55.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
	 * Base24 - ISO Reserved<br>
	 * CyberSource API- EMV
	 */
	void setIccData(int fieldNo);

	/**
	 * 56.<br>
	 * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
	 */
	void setReserved56(int fieldNo);

	/**
	 * 57.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Amount cash
	 */
	void setReserved57(int fieldNo);

	/**
	 * 58.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Ledger balance
	 */
	void setReserved58(int fieldNo);

	/**
	 * 59.<br>
	 * ISO8583-1987,Base24, XML - Reserved for national use<br>
	 * AS2805 - Account balance, Cleared funds
	 */
	void setReserved59(int fieldNo);

	/**
	 * 60.<br>
	 * ISO8583-1987 - Reserved for national use<br>
	 * AS2805,ISG, XML - Reserved private<br>
	 * Base24 - Terminal Data
	 */
	void setTerminalData(int fieldNo);

	/**
	 * 61.<br>
	 * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
	 * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
	 * Data
	 */
	void setCiad(int fieldNo);

	/**
	 * 62.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - Postal Code
	 */
	void setPostalCode(int fieldNo);

	/**
	 * 63.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
	 * Base24 - ATM PIN Offset POS Additional Data
	 */
	void setAtmPinOffsetData(int fieldNo);

	/**
	 * 64.<br>
	 * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
	 * Base24 -Primary Message Authentication Code
	 */
	void setMsgAuthCode(int fieldNo);

	/**
	 * 65.<br>
	 * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
	 * Base24 -Reserved for ISO use
	 */
	void setExtendedBitmapIndicator(int fieldNo);

	/**
	 * 66.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Code
	 */
	void setSettlementCode(int fieldNo);

	/**
	 * 67.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Extended payment code
	 */
	void setExtendedPaymentCode(int fieldNo);

	/**
	 * 68.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
	 * mPOS - Transaction Country Code
	 */
	void setReceiverCountryCode(int fieldNo);

	/**
	 * 69.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
	 * 
	 */
	void setSettlementCountryCode(int fieldNo);

	/**
	 * 70.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
	 */
	void setNetworkMgmtInfoCode(int fieldNo);

	/**
	 * 71.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number
	 */
	void setMsgNo(int fieldNo);

	/**
	 * 72.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Number Last
	 */
	void setLastMsgNo(int fieldNo);

	/**
	 * 73.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Action Date
	 */
	void setActionDate(int fieldNo);

	/**
	 * 74.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Credits
	 */
	void setNoOfCredits(int fieldNo);

	/**
	 * 75.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
	 */
	void setCreditsReversalNo(int fieldNo);

	/**
	 * 76.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Debits
	 */
	void setNoOfDebits(int fieldNo);

	/**
	 * 77.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
	 */
	void setDebitsReversalNo(int fieldNo);

	/**
	 * 78.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Transfer
	 */
	void setTransferNo(int fieldNo);

	/**
	 * 79.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
	 */
	void setTransferReversalNo(int fieldNo);

	/**
	 * 80.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
	 */
	void setNoOfInquiries(int fieldNo);

	/**
	 * 81.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
	 */
	void setNoOfAuths(int fieldNo);

	/**
	 * 82.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
	 */
	void setCreditsProcessingFee(int fieldNo);

	/**
	 * 83.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
	 */
	void setCreditsTxnFee(int fieldNo);

	/**
	 * 84.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
	 */
	void setDebitsProcessingFee(int fieldNo);

	/**
	 * 85.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
	 */
	void setDebitsTxnFee(int fieldNo);

	/**
	 * 86.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Credits
	 */
	void setTotalCredits(int fieldNo);

	/**
	 * 87.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
	 */
	void setCreditsReversal(int fieldNo);

	/**
	 * 88.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Amount Debits
	 */
	void setTotalDebits(int fieldNo);

	/**
	 * 89.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
	 */
	void setDebitsReversal(int fieldNo);

	/**
	 * 90.<br>
	 * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
	 */
	void setOriginalDataElements(int fieldNo);

	/**
	 * 91.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Update Code
	 */
	void setFileUpdateCode(int fieldNo);

	/**
	 * 92.<br>
	 * ISO8583-1987, AS2805, Base24, XML - File Security Code
	 */
	void setFileSecurityCode(int fieldNo);

	/**
	 * 93.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Response Indicator
	 */
	void setResIndicator(int fieldNo);

	/**
	 * 94.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Service Indicator
	 */
	void setServiceIndicator(int fieldNo);

	/**
	 * 95.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
	 */
	void setReplacementAmts(int fieldNo);

	/**
	 * 96.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Message Security Code
	 */
	void setMsgSecurityCode(int fieldNo);

	/**
	 * 97.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
	 */
	void setNetSettlement(int fieldNo);

	/**
	 * 98.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Payee
	 */
	void setPayee(int fieldNo);

	/**
	 * 99.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
	 * Code
	 */
	void setSettlementIdCode(int fieldNo);

	/**
	 * 100.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
	 */
	void setReceiverIdCode(int fieldNo);

	/**
	 * 101.ISO8583-1987, AS2805, Base24, XML - File Name
	 */
	void setFileName(int fieldNo);

	/**
	 * 102.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
	 */
	void setAccId1(int fieldNo);

	/**
	 * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
	 */
	void setAccId2(int fieldNo);

	/**
	 * 104.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
	 * mPOS - transaction_type
	 */
	void setTxnDesc(int fieldNo);

	/**
	 * 105.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	void setReserved105(int fieldNo);

	/**
	 * 106.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	void setReserved106(int fieldNo);

	/**
	 * 107.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	void setReserved107(int fieldNo);

	/**
	 * 108.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */
	void setReserved108(int fieldNo);

	/**
	 * 109.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	void setReserved109(int fieldNo);

	/**
	 * 110.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	void setReserved110(int fieldNo);

	/**
	 * 111.<br>
	 * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
	 */
	void setReserved111(int fieldNo);

	/**
	 * 112.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use<br>
	 * AS2805 - Key Management data
	 */
	void setReserved112(int fieldNo);

	/**
	 * 113.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */
	void setReserved113(int fieldNo);

	/**
	 * 114.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */
	void setReserved114(int fieldNo);

	/**
	 * 115.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */
	void setReserved115(int fieldNo);

	/**
	 * 116.<br>
	 * ISO8583-1987, Base24, XML - Reserved For National Use
	 */
	void setReserved116(int fieldNo);

	/**
	 * 117. <br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Card Status Update Code
	 */
	void setReserved117(int fieldNo);

	/**
	 * 118.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */
	void setReserved118(int fieldNo);

	/**
	 * 119.<br>
	 * ISO8583-1987, XML - Reserved For National Use<br>
	 * AS2805 - Cash Total number
	 */
	void setReserved119(int fieldNo);

	/**
	 * 120.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
	 */
	void setReserved120(int fieldNo);

	/**
	 * 121. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS Authorization Indicators
	 */
	void setReserved121(int fieldNo);

	/**
	 * 122.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -Card Issuer Identification Code
	 */
	void setReserved122(int fieldNo);

	/**
	 * 123.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
	 * Invoice Data/Settlement Record
	 */
	void setReserved123(int fieldNo);

	/**
	 * 124.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
	 */
	void setReserved124(int fieldNo);

	/**
	 * 125.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
	 */
	void setReserved125(int fieldNo);

	/**
	 * 126. <br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
	 */
	void setReserved126(int fieldNo);

	/**
	 * 127.<br>
	 * ISO8583-1987,AS2805, XML - Reserved for private use<br>
	 * Base24 - POS User Data
	 */
	void setReserved127(int fieldNo);

	/**
	 * 128.<br>
	 * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
	 * Base24 - Secondary Message Authentication Code
	 */
	void setReserved128(int fieldNo);
}
