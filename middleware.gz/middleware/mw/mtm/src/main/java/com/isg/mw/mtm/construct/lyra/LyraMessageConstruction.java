package com.isg.mw.mtm.construct.lyra;

import com.isg.mw.core.utils.MaskingUtility;
import com.isg.mw.mtm.construct.IMessageConstruction;
import com.isg.mw.mtm.construct.SwitchBaseMessageConstruction;

import java.math.BigDecimal;

public class LyraMessageConstruction extends SwitchBaseMessageConstruction implements IMessageConstruction {

    @Override
    public void setIccData(int fieldNo) {
        // ICC data is not required for this implementation
    }

    public String setCardNumber() {
        String panNumber = this.sourceTmm.getPan().replaceAll(" ", "");
        String maskCardNumber = MaskingUtility.maskCardNumber(panNumber);
        this.targetTmm.getSmartRouteData().getLyraData().setCardNumber(maskCardNumber);
        return panNumber;
    }

    public String setTransactionId() {
        this.targetTmm.setTransactionId(this.sourceTmm.getTransactionId());
        return this.targetTmm.getTransactionId();
    }

    public String setTxnAmt() {
        this.targetTmm.setTxnAmt(this.sourceTmm.getTxnAmt());
        BigDecimal amount = getTotalAmountInPaisaIfCCSIinPaisa(this.sourceTmm);
        return amount.toString();
//        return this.targetTmm.getTxnAmt();
    }

    public String setTxnCurrencyCode() {
        String merchantCurrencyCode = this.sourceTmm.getTxnCurrencyCode() != null ? this.sourceTmm.getTxnCurrencyCode()
                : this.merchantData.getAcquirerCurrencyCode();
        this.targetTmm.setTxnCurrencyCode(merchantCurrencyCode);
        return this.targetTmm.getTxnCurrencyCode();
    }

    public String setExpMonth() {
        String dt = this.sourceTmm.getExpirationDate().replaceAll("\\s+", "");
//        this.targetTmm.getSmartRouteData().getLyraData().setExpMonth(dt.substring(0, 2));
        return dt.substring(0, 2);
    }

    public String setExpYear() {
        String dt = this.sourceTmm.getExpirationDate().replaceAll("\\s+", "").replaceAll("\u2002","");
//        this.targetTmm.getSmartRouteData().getLyraData().setExpYear(dt.substring(3, dt.length()));
//        return this.targetTmm.getSmartRouteData().getLyraData().getExpYear();
        return dt.substring(3, dt.length());
    }

    public String setCardHolderName() {
        this.targetTmm.getSmartRouteData().getLyraData().setCustomerName(this.sourceTmm.getSmartRouteData().getLyraData().getCustomerName());
        return this.targetTmm.getSmartRouteData().getLyraData().getCustomerName();
    }

    public String setCvv() {
        String cvv = this.sourceTmm.getCvv();
        //  this.targetTmm.getSmartRouteData().getLyraData().setCvv();
        return cvv;
    }

}
