package com.isg.mw.mtm.construct;

import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.constants.TransactionCategory;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.mtm.transform.TmmConstants;
import com.isg.mw.mtm.util.MtmUtil;

public final class MessageConstructionHelper {

    private MessageConstructionHelper() {
    }

    /**
     * Returns true if transaction is Moto Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isMoto(String msgType, String processingCode) {
        boolean isMotoMsgType = msgType.equals("0200") || msgType.equals("0210");
        boolean isMotoProcCode = extractTxnType(processingCode).equals("51");
        return isMotoMsgType && isMotoProcCode;
    }

    /**
     * Returns true if transaction is Purchase Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isPurchase(String msgType, String processingCode) {
        boolean isPurchaseMsgType = msgType.equals("0200") || msgType.equals("0210");
        boolean isPurchaseProcCode = extractTxnType(processingCode).equals("00");
        return isPurchaseMsgType && isPurchaseProcCode;
    }
    
    public static boolean isBqrPurchase(String msgType, String processingCode) {
        boolean isBqrPurchaseMsgType = msgType.equals("0200") || msgType.equals("0210") || msgType.equals("0100") || msgType.equals("0110");
        boolean isBqrPurchaseProcCode = extractTxnType(processingCode).equals("26") || extractTxnType(processingCode).equals("28");
        return isBqrPurchaseMsgType && isBqrPurchaseProcCode;
    }

    /**
     * Returns true if transaction is Cash Withdrawal Request/Response Transaction,
     * false otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isCashWithdrawal(String msgType, String processingCode) {
        boolean isCwMsgType = msgType.equals("0200") || msgType.equals("0210");
        boolean isCwProcCode = extractTxnType(processingCode).equals("01");
        return isCwMsgType && isCwProcCode;
    }

    /**
     * Returns true if transaction is Cash At POS Request/Response Transaction,
     * false otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isCashAtPos(String msgType, String processingCode) {
        boolean isCashAtPosMsgType = msgType.equals("0200") || msgType.equals("0210");
        boolean isCashAtPosProcCode = extractTxnType(processingCode).equals("09");
        return isCashAtPosMsgType && isCashAtPosProcCode;
    }

    /**
     * Returns true if transaction is Pre-Auth Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isPreAuth(String msgType, String processingCode) {
        boolean isPreAuthMsgType = msgType.equals("0100") || msgType.equals("0110");
        boolean isPreAuthProcCode = extractTxnType(processingCode).equals("00");
        return isPreAuthMsgType && isPreAuthProcCode;
    }

    public static boolean isPosPreAuthReq(String msgType, String processingCode) {
        boolean isPreAuthMsgType = msgType.equals("0100");
        boolean isPreAuthProcCode = extractTxnType(processingCode).equals("00");
        return isPreAuthMsgType && isPreAuthProcCode;
    }

    /**
     * Returns true if transaction is Refund Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isPosRefundReq(String msgType, String processingCode) {
        boolean isRefundMsgType = msgType.equals("0200");
        boolean isRefundProcCode = extractTxnType(processingCode).equals("20");
        return isRefundMsgType && isRefundProcCode;
    }

    /**
     * Returns true if transaction is Balance Enquiry Request/Response Transaction,
     * false otherwise.
     *
     * @param msgType        Transaction Message Type
     * @param processingCode Transaction Processing Code
     * @return True/False.
     */
    public static boolean isBalanceEnquiry(String msgType, String processingCode) {
        boolean isBalanceEnqMsgType = msgType.equals("0100") || msgType.equals("0110");
        boolean isBalanceEnqProcCode = extractTxnType(processingCode).equals("30") || extractTxnType(processingCode).equals("31");
        return isBalanceEnqMsgType && isBalanceEnqProcCode;
    }

    public static boolean isPosBalInqReq(String msgType, String processingCode) {
        boolean isBalanceEnqMsgType = msgType.equals("0100");
        boolean isBalanceEnqProcCode = extractTxnType(processingCode).equals("31");
        return isBalanceEnqMsgType && isBalanceEnqProcCode;
    }

    /**
     * Returns true if transaction is Balance Enquiry Request/Response Transaction,
     * false otherwise.
     *
     * @param msgType Transaction Message Type
     * @return True/False.
     */
    public static boolean isReversalRequest(String msgType) {
        return msgType.equals("0400") || msgType.equals("0420") || msgType.equals("0421") || msgType.equals("1420");
    }

    public static boolean isRepeatReversalRequest(String msgType) {
        return msgType.equals("0400") || msgType.equals("0421");
    }
    public static boolean isAllSchemeReversalRes(String msgType) {
        return msgType.equals("0410") || msgType.equals("0430");
    }

    /**
     * Returns true if transaction is Void Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @return True/False.
     */
    public static boolean isPosVoidRequest(String msgType, String msgTypeId) {
        boolean isVoidRequestMsgType = msgType.equals("0220");
        boolean isVoidRequestMsgTypeId = extractTxnType(msgTypeId).equals("22") || extractTxnType(msgTypeId).equals("02");
        return isVoidRequestMsgType && isVoidRequestMsgTypeId;
    }

    /**
     * Returns true if transaction is Void Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @return True/False.
     */
    public static boolean isVoidResponse(String msgType) {
        return msgType.equals("0410") || msgType.equals("0430");
    }

    public static boolean isPosVoidReq(String msgType, String msgTypeId) {
        boolean isVoidResponseMsgType = msgType.equals("0220");
        boolean isVoidResponseMsgTypeId = extractTxnType(msgTypeId).equals("22") || extractTxnType(msgTypeId).equals("02");
        return isVoidResponseMsgType && isVoidResponseMsgTypeId;
    }

    public static boolean isPosVoidResponse(String msgType, String msgTypeId) {
        boolean isVoidResponseMsgType = msgType.equals("0230");
        boolean isVoidResponseMsgTypeId = extractTxnType(msgTypeId).equals("22") || extractTxnType(msgTypeId).equals("02");
        return isVoidResponseMsgType && isVoidResponseMsgTypeId;
    }

    public static boolean isSignOnRequest(String msgType) {
        return msgType.equals("0800");
    }

    /**
     * Returns true if transaction is Void Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @return True/False.
     */
    public static boolean isSignOnResponse(String msgType) {
        return msgType.equals("0810") || msgType.equals("1814");
    }

    public static boolean isTipAdjustRequest(String msgType, String msgTypeId) {
        boolean isTipAdjustRequestMsgType = msgType.equals("0220");
        boolean isTipAdjustRequestMsgTypeId = extractTxnType(msgTypeId).equals("50");
        return isTipAdjustRequestMsgType && isTipAdjustRequestMsgTypeId;
    }

    public static boolean isPreAuthCompletionRequest(String msgType, String msgTypeId) {
        boolean isPreAuthCompRequestMsgType = msgType.equals("0220");
        boolean isPreAuthRequestMsgTypeId = extractTxnType(msgTypeId).equals("40");
        return isPreAuthCompRequestMsgType && isPreAuthRequestMsgTypeId;
    }

    public static boolean isOfflineRequest(String msgType, String msgTypeId) {
        boolean isOfflineRequestMsgType = msgType.equals("0220");
        boolean isOfflineRequestMsgTypeId = extractTxnType(msgTypeId).equals("00");
        return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
    }
    
    public static boolean isEftPosFinancialAdviceRequest(String msgType, String msgTypeId) {
        boolean isFinancialAdviseMsgType = msgType.equals("0220");
        boolean isFinancialAdviseMsgTypeId = extractTxnType(msgTypeId).equals("00");
        return isFinancialAdviseMsgType && isFinancialAdviseMsgTypeId;
    }

    public static boolean isMasterCardCashbackRequest(String msgType, String msgTypeId) {
        boolean isOfflineRequestMsgType = msgType.equals("0200");
        boolean isOfflineRequestMsgTypeId = extractTxnType(msgTypeId).equals("09");
        return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
    }

    public static boolean isEftposCashbackRequest(String msgType, String msgTypeId) {
        boolean isOfflineRequestMsgType = msgType.equals("0200");
        boolean isOfflineRequestMsgTypeId = extractTxnType(msgTypeId).equals("09");
        return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
    }

    public static boolean isBatchSettlementRequest(String msgType, String msgTypeId) {
        boolean isBatchSettlementMsgType = msgType != null && msgType.equals("0500");
        boolean isBatchSettlementMsgTypeId = extractTxnType(msgTypeId).equals("92") || extractTxnType(msgTypeId).equals("96") || extractTxnType(msgTypeId).equals("93");
        return isBatchSettlementMsgType && isBatchSettlementMsgTypeId;
    }

    public static boolean isBatchSettlementResponse(String msgType, String msgTypeId) {
        boolean isBatchSettlementMsgType = msgType.equals("0510");
        boolean isBatchSettlementMsgTypeId = extractTxnType(msgTypeId).equals("92") || extractTxnType(msgTypeId).equals("96") || extractTxnType(msgTypeId).equals("93");
        return isBatchSettlementMsgType && isBatchSettlementMsgTypeId;
    }

    public static boolean isAddMoneyRequest(String msgType, String msgTypeId) {
        boolean isAddMoneyMsgType = msgType.equals("0200");
        boolean isAddMoneyMsgTypeId = extractTxnType(msgTypeId).equals("28");
        return isAddMoneyMsgType && isAddMoneyMsgTypeId;
    }

    public static boolean isBalanceUpdateRequest(String msgType, String msgTypeId) {
        boolean isBalanceUpdateMsgType = msgType.equals("0200");
        boolean isBalanceUpdateMsgTypeId = extractTxnType(msgTypeId).equals("29");
        return isBalanceUpdateMsgType && isBalanceUpdateMsgTypeId;
    }

    public static boolean isBatchUploadRequest(String msgType) {
        return msgType != null && msgType.equals("0320");
    }

    public static boolean isPosRefundResponse(String msgType, String msgTypeId) {
        boolean isRefundResMsgType = msgType.equals("0210");
        boolean isRefundResMsgTypeId = extractTxnType(msgTypeId).equals("20");
        return isRefundResMsgType && isRefundResMsgTypeId;
    }

    public static boolean isPosPreAuthResponse(String msgType, String msgTypeId) {
        boolean isPreAuthResMsgType = msgType.equals("0110");
        boolean isPreAuthResMsgTypeId = extractTxnType(msgTypeId).equals("00");
        return isPreAuthResMsgType && isPreAuthResMsgTypeId;
    }

    public static boolean isPosBalEnqResponse(String msgType, String msgTypeId) {
        boolean isBalEnqResMsgType = msgType.equals("0110");
        boolean isBalEnqResMsgTypeId = extractTxnType(msgTypeId).equals("31");
        return isBalEnqResMsgType && isBalEnqResMsgTypeId;
    }

    private static String extractTxnType(String processingCode) {
        if (processingCode != null && processingCode.length() > 2) {
            processingCode = processingCode.substring(0, 2);
        }
        return processingCode != null ? processingCode : "";
    }

    public static boolean isSaleWithCashAtPosRequest(String msgType, String msgTypeId, String txnAmt, String additionalAmt) {
        boolean retVal = false;
        if (additionalAmt != null && !additionalAmt.isEmpty() && Double.valueOf(txnAmt).compareTo(Double.valueOf(additionalAmt)) > 0) {
            retVal = msgType.equals("0200") && extractTxnType(msgTypeId).equals("09");
        }
        return retVal;
    }

    public static boolean isCashAtPosRequest(String msgType, String msgTypeId, String txnAmt, String additionalAmt) {
        boolean retVal = false;
        if (additionalAmt != null && !additionalAmt.isEmpty() && Double.valueOf(txnAmt).compareTo(Double.valueOf(additionalAmt)) == 0) {
            retVal = msgType.equals("0200") && extractTxnType(msgTypeId).equals("09");
        }
        return retVal;
    }

    public static boolean isContactTxn(String posEntryModeFirstTwoDigit) {
        return MtmUtil.getContactTxn().contains(posEntryModeFirstTwoDigit);
    }

    public static boolean isContactlessTxn(String posEntryModeFirstTwoDigit) {
        return MtmUtil.getContactlessTxn().contains(posEntryModeFirstTwoDigit);
    }

    public static boolean isManualTxn(String posEntryModeFirstTwoDigit) {
        return MtmUtil.getManualAndMotoTxn().contains(posEntryModeFirstTwoDigit);
    }

    public static boolean isFallbackTxn(String posEntryModeFirstTwoDigit) {
        return MtmUtil.getFallbackTxn().contains(posEntryModeFirstTwoDigit);
    }
    
    public static boolean isMsrContactlessTxn(String posEntryMode) {
        return MtmUtil.getMsrContactlessTxn().contains(posEntryMode);
    }

    public static boolean isMasterCardSchemeInitiatedDynamicKeyExchange(TransactionMessageModel sourceTmm) {
        return TransactionCategory.DYNAMIC_KEY_EXCHANGE.equals(sourceTmm.getTransactionCategory()) &&
                TmmConstants.MASTERCARD_SCHEME_INIT_KEY_EXCHANGE_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode());
    }

    public static boolean isRupaySchemeInitiatedDynamicKeyExchange(TransactionMessageModel sourceTmm) {
        return TransactionCategory.DYNAMIC_KEY_EXCHANGE.equals(sourceTmm.getTransactionCategory()) &&
                TmmConstants.RUPAY_SCHEME_INIT_KEY_EXCHANGE_NW_MGMT_CODE.equals(sourceTmm.getNetworkMgmtInfoCode());
    }

    public static boolean isRupayCutOverMsg(TransactionMessageModel tmm) {
    	return ((isSignOnRequest(tmm.getMsgType()) || isSignOnResponse(tmm.getMsgType()))
    			&& TmmConstants.RUPAY_CUT_OVER_NW_MGMT_CODE.equals(tmm.getNetworkMgmtInfoCode())
    			&& tmm.getTargetType().equals(TargetType.Rupay));
    }

    public static boolean isRupayAddMoneyRequest(String msgType, String msgTypeId) {
        boolean isAddMoneyRequestMsgType = msgType.equals("0100");
        boolean isAddMoneyRequestMsgTypeId = extractTxnType(msgTypeId).equals("28");
        return isAddMoneyRequestMsgType && isAddMoneyRequestMsgTypeId;
    }

    public static boolean isRupayBalanceUpdateRequest(String msgType, String msgTypeId) {
        boolean isBalanceUpdateRequestMsgType = msgType.equals("0100");
        boolean isBalanceUpdateMsgTypeId = extractTxnType(msgTypeId).equals("29");
        return isBalanceUpdateRequestMsgType && isBalanceUpdateMsgTypeId;
    }

    public static boolean isRupayServiceCreationRequest(String msgType, String msgTypeId) {
        boolean isServiceCreationRequestMsgType = msgType.equals("0100");
        boolean isServiceCreationRequestMsgTypeId = extractTxnType(msgTypeId).equals("83");
        return isServiceCreationRequestMsgType && isServiceCreationRequestMsgTypeId;
    }

    public static boolean isVisaEchoResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.VISA_ECHO_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.HEARTBEAT.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isMasterCardSigOnResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.MASTERCARD_SIGNON_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.SIGNON.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isMasterCardSignOffResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.MASTERCARD_SIGNOFF_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.SIGNOFF.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isMasterCardEchoResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.MASTERCARD_ECHO_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.HEARTBEAT.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupaySignOnResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.RUPAY_SIGNON_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.SIGNON.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupaySignOffResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.RUPAY_SIGNOFF_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.SIGNOFF.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupayEchoResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.RUPAY_ECHO_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.HEARTBEAT.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupayEchoRequest(TransactionMessageModel sourceTmm) {
        return TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) &&
                TransactionCategory.HEARTBEAT.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupaySignOnRequest(TransactionMessageModel sourceTmm) {
        return TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) &&
                TransactionCategory.SIGNON.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupayDynamicKeyExchangeRequest(TransactionMessageModel sourceTmm) {
        return TmmConstants.REQ_NW_MGMT_MSG_TYPE.equals(sourceTmm.getMsgType()) &&
                TransactionCategory.DYNAMIC_KEY_EXCHANGE.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isRupayMacDeclineReversalReq(String resCode) {
        return TmmConstants.RES_CODE_INVALID_MAC.equals(resCode);
    }

    public static boolean isTimeoutReversalReq(String msgMTI, String authIdRes) {
        return TmmConstants.REVERSAL_REQUEST_MTI.equals(msgMTI) &&
                authIdRes == null;
    }

    public static boolean isLateRspReversalReq(String msgMTI, String authIdRes, String source) {
        /**
         * If source is null then the txn is initiated by switch.
         * */
        return TmmConstants.REVERSAL_REQUEST_MTI.equals(msgMTI) &&
                authIdRes != null && !authIdRes.isEmpty() && source == null;
    }

    public static boolean isPosReversalRequest(String msgMTI, String authIdRes, String source) {
        return TmmConstants.REVERSAL_REQUEST_MTI.equals(msgMTI) &&
                authIdRes != null && !authIdRes.isEmpty() && source != null;
    }

    /**
     * Returns true if transaction is isMagstripeWithPin Request/Response Transaction, false
     * otherwise.
     *
     * @param posEntryMode POS Entry Mode
     * @param pin          Pin
     * @return True/False.
     */
    public static boolean isMagstripeWithPin(String posEntryMode, String pin) {
        boolean isMagstripeWithPinPosEntryMode = posEntryMode.equals("02") || posEntryMode.equals("90") || posEntryMode.equals("91");
        return isMagstripeWithPinPosEntryMode && pin != null && pin.isEmpty() == false;
    }

    /**
     * Returns true if transaction is isMagstripeWithoutPin Request/Response Transaction, false
     * otherwise.
     *
     * @param posEntryMode POS Entry Mode
     * @param pin          Pin
     * @return True/False.
     */
    public static boolean isMagstripeWithoutPin(String posEntryMode, String pin) {
        boolean isMagstripeWithPinPosEntryMode = posEntryMode.equals("02") || posEntryMode.equals("90") || posEntryMode.equals("91");
        return isMagstripeWithPinPosEntryMode && (pin == null || pin.isEmpty() == true);
    }


    public static boolean isFallbackWithPin(String posEntryMode, String pin) {
        return isFallbackTxn(posEntryMode) && pin != null && pin.isEmpty() == false;
    }

    public static boolean isFallbackWithoutPin(String posEntryMode, String pin) {
        return isFallbackTxn(posEntryMode) && (pin == null || pin.isEmpty() == true);
    }

    public static boolean isVisaEchoMsg(String networkInfoCode) {
        return TmmConstants.VISA_ECHO_NW_INFO_CODE.equals(networkInfoCode);
    }

    public static boolean isVisaSigOn(String networkInfoCode) {
        return TmmConstants.VISA_SIGNON_NW_INFO_CODE.equals(networkInfoCode);
    }

    public static boolean isVisaSigOff(String networkInfoCode) {
        return TmmConstants.VISA_SIGNOFF_NW_INFO_CODE.equals(networkInfoCode);
    }

    public static boolean isMasterCardHostActivation(TransactionCategory transactionCategory, String msgType) {
        return TransactionCategory.HOST_SESSION_ACTIVATION.equals(transactionCategory) && isSignOnRequest(msgType);
    }

    public static boolean isMasterCardHostDeActivation(TransactionCategory transactionCategory, String msgType) {
        return TransactionCategory.HOST_SESSION_DEACTIVATION.equals(transactionCategory) && isSignOnRequest(msgType);
    }


    public static boolean isEftPosEchoResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.EFTPOS_HEARTBEAT_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.HEARTBEAT.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isEftPosSigOn(TransactionMessageModel sourceTmm) {
        return TmmConstants.EFTPOS_SIGNON_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.SIGNON.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isEftPosSignOffResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.EFTPOS_SIGNOFF_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.SIGNOFF.equals(sourceTmm.getTransactionCategory());
    }

    public static boolean isEftPosKeyExchangeResponse(TransactionMessageModel sourceTmm) {
        return TmmConstants.EFTPOS_KEYEXCHANE_NW_INFO_CODE.equals(sourceTmm.getNetworkMgmtInfoCode()) &&
                TransactionCategory.DYNAMIC_KEY_EXCHANGE.equals(sourceTmm.getTransactionCategory());
    }
    
    public static boolean isDccRateLookupRequest(String msgType, String msgTypeId) {
        boolean isDccRateLookupMsgType = msgType != null && msgType.equals("0600");
        boolean isDccRateLookupMsgTypeId = extractTxnType(msgTypeId).equals("00");
        return isDccRateLookupMsgType && isDccRateLookupMsgTypeId;
    }
    
    public static boolean isDccRateLookup(String msgType, String processingCode) {
        boolean isDccRateLookupMsgType = msgType.equals("0600") || msgType.equals("0610");
        boolean isDccRateLookupProcCode = extractTxnType(processingCode).equals("00");
        return isDccRateLookupMsgType && isDccRateLookupProcCode;
    }
    
    
    public static boolean isPosZvavReq(String msgType, String processingCode) {
        boolean isRefundMsgType = msgType.equals("0200");
        boolean isRefundProcCode = extractTxnType(processingCode).equals("33");
        return isRefundMsgType && isRefundProcCode;
    }
    
    public static boolean isPosZvavResponse(String msgType, String msgTypeId) {
        boolean isPreAuthResMsgType = msgType.equals("1110");
        boolean isPreAuthResMsgTypeId = extractTxnType(msgTypeId).equals("33");
        return isPreAuthResMsgType && isPreAuthResMsgTypeId;
    }

    public static boolean isPosTerminalInit(String msgType, String msgTypeId) {
        boolean isTerminalInitMsgType = msgType.equals("0800") || msgType.equals("0810") ;
        boolean isTerminalInitMsgTypeId = extractTxnType(msgTypeId).equals("01");
        return isTerminalInitMsgType && isTerminalInitMsgTypeId;
    }
}
