package com.isg.mw.mtm.parser.isofield;

import org.jpos.iso.HexNibblesPrefixer;
import org.jpos.iso.ISOBinaryFieldPackager;

import com.isg.mw.mtm.parser.interpreter.ISG_LiteralBinaryInterpreter;

public class ISG_IFB_LLHEX extends ISOBinaryFieldPackager {

	public ISG_IFB_LLHEX() {
        super(ISG_LiteralBinaryInterpreter.INSTANCE, HexNibblesPrefixer.LL);
    }

    public ISG_IFB_LLHEX (int len, String description) {
        super(len, description, ISG_LiteralBinaryInterpreter.INSTANCE, HexNibblesPrefixer.LL);
        checkLength(len, 99);
    }
    
    @Override
    public void setLength(int len) {
        checkLength(len, 99);
        super.setLength(len);
    }

}
