package com.isg.mw.core.aspects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.isg.mw.core.model.tlm.TransactionMessageModel;

@Aspect
@Component
public class TimeLogAspect {

	private Logger logger = null;

	@Around("@annotation(com.isg.mw.core.aspects.Timed)")
	public Object time(final ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		long start = System.currentTimeMillis();

		Object value = null;

		try {
			logger = LogManager.getLogger(proceedingJoinPoint.getSignature().getDeclaringType().getName());
			value = proceedingJoinPoint.proceed();
		} catch (Throwable throwable) {
			logger.debug(throwable.getMessage());
			throw throwable;
		} finally {
			long duration = System.currentTimeMillis() - start;

			Object[] args = proceedingJoinPoint.getArgs();
			if (args.length > 0 && args[0] instanceof TransactionMessageModel) {
				TransactionMessageModel tmm = (TransactionMessageModel) args[0];
				logger.trace("Load Test::Transaction {}, {}:: {}.{} took {} ms", tmm.getTransactionId(),
						tmm.getTlmMessageType(), proceedingJoinPoint.getSignature().getDeclaringType().getSimpleName(),
						proceedingJoinPoint.getSignature().getName(), duration);
			}
		}

		return value;
	}
}