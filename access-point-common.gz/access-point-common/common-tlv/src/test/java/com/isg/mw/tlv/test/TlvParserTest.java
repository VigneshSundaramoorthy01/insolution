package com.isg.mw.tlv.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.isg.mw.tlv.TlvParser;

/**
 * 
 * @author prasad_t026
 *
 */
public class TlvParserTest {


	@Test
	public void parseTlv01Test() {
		List<String> tags = new ArrayList<String>();
		tags.add("9F02");
		tags.add("9F03");
		tags.add("84");
		tags.add("82");
		tags.add("9f36");
		tags.add("9F07");
		tags.add("9F27");
		tags.add("9F26");
		tags.add("9F34");
		tags.add("9F1E");
		tags.add("9F10");
		tags.add("9f09");
		tags.add("9F33");
		tags.add("9F1A");
		tags.add("9f35");
		tags.add("95");
		tags.add("5F2A");
		tags.add("5F34");
		tags.add("9A");
		tags.add("9C");
		tags.add("9F37");
		tags.add("9F53");
		tags.add("9F41");

		Map<String, String> tlvs = new HashMap<String, String>();
		String data = "9F02060000000100009F03060000000000008407A0000000041010820238009F360200C09F0702FF009F26080179C2E81C5DEF949F2701809F34034203009F1E0831333032393737349F10120010A00001220000000000000000000000FF9F090200029F3303E0F0C89F1A0203569F350122950508000480005F2A0203565F3401019A032004309C01009F370479767B219F4104000000609F530152";
		TlvParser.parseTlv(data, tags, tlvs);
		System.out.println("tlv size(23): " + tlvs.size());
	}
	
	@Test
	public void parseTlv02Test() {
		List<String> tags = new ArrayList<String>();
		tags.add("9F02");
		tags.add("9F03");
		tags.add("84");
		tags.add("82");
		tags.add("9f36");
		tags.add("9F07");
		tags.add("9F27");
		tags.add("9F26");
		tags.add("9F34");
		tags.add("9F1E");
		tags.add("9F10");
		tags.add("9f09");
		tags.add("9F33");
		tags.add("9F1A");
		tags.add("9f35");
		tags.add("95");
		tags.add("5F2A");
		tags.add("5F34");
		tags.add("9A");
		tags.add("9C");
		tags.add("9F37");
		tags.add("9F53");
		tags.add("9F41");

		Map<String, String> tlvs = new HashMap<String, String>();
		String data = "9F02060000000100009F03060000000000008407A0000000041010";
		TlvParser.parseTlv(data, tags, tlvs);
		System.out.println("tlv size(23): " + tlvs.size());
	}

}
