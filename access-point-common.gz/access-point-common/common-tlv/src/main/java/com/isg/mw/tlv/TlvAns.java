package com.isg.mw.tlv;

import java.util.List;

public class TlvAns {

	private String tag;
	
	private String value;
	
	public TlvAns(String tag, String value) {
		this.tag = tag;
		this.value = value;
	}

	public String getTag() {
		return tag;
	}
	
	public String getValue() {
		return value;
	}
	
	public String toString() {
			return tag + lengthInDecimal() + value;
	}

	private String lengthInDecimal() {
		if(value.length() > 9) {
			return "" + value.length();
		}
		else {
			return "0" + value.length();
		}
	}
	
	public static String getBytes(List<TlvAns> list) {
		
		StringBuilder sb = new StringBuilder();
		for(TlvAns t: list) {
			sb.append(t.toString());
		}
		return sb.toString();
		
	}

}
