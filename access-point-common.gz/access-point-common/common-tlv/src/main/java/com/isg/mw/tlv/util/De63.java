package com.isg.mw.tlv.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.tlv.TlvParser;

public class De63 {

	private static final List<String> VISA_TAGS = new ArrayList<String>();

	private static final List<String> MC_TAGS = new ArrayList<String>();

	private static final List<String> RUPAY_TAGS = new ArrayList<String>();

	static {
		VISA_TAGS.add("0002");
		VISA_TAGS.add("0001");

		MC_TAGS.add("0002");
		MC_TAGS.add("0001");

		RUPAY_TAGS.add("0002");
		RUPAY_TAGS.add("0001");
	}

	private De63() {
	}

	public static List<String> getTags(TargetType targetType) {

		switch (targetType) {
		case Master:
			return MC_TAGS;
		case Rupay:
			return RUPAY_TAGS;
		case Visa:
			return VISA_TAGS;
		default:
			return null;
		}

	}

	public static Map<String, String> parse(String data, TargetType targetType) {
		Map<String, String> tlvs = new HashMap<String, String>();
		TlvParser.de63_parseTlv(data, getTags(targetType), tlvs);
		return tlvs;
	}

}
