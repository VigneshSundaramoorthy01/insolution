package com.isg.mw.tlv;

import java.util.List;
import java.util.Map;

import org.jpos.iso.ISOUtil;

/**
 * 
 * @author prasad_t026
 *
 */
public class TlvParser {

	public TlvParser() {
	}

	public static void parseTlv(String data, List<String> tags, Map<String, String> tlvs) {
		for (String tag : tags) {
			if (data.startsWith(tag.toLowerCase(), 0) || data.startsWith(tag.toUpperCase(), 0)) {
				String length = data.substring(tag.length(), tag.length() + 2);
				byte[] lx = ISOUtil.hex2byte(length);
				String value = data.substring(tag.length() + 2, tag.length() + 2 + lx[0] * 2);
				tlvs.put(tag.toUpperCase(), value);
				String dd = data.substring(tag.length() + 2 + lx[0] * 2);
				if (dd.length() > 0) {
					parseTlv(data.substring(tag.length() + 2 + lx[0] * 2), tags, tlvs);
				}
			}
		}
	}

	public static void de63_parseTlv(String data, List<String> tags, Map<String, String> tlvs) {
		for (String tag : tags) {
			if (data.startsWith(tag.toLowerCase(), 0) || data.startsWith(tag.toUpperCase(), 0)) {
				String length = data.substring(tag.length(), tag.length() + 2);
				byte[] lx = ISOUtil.hex2byte(length);
				String value = data.substring(tag.length() + 2, tag.length() + 2 + lx[0]);
				tlvs.put(tag.toUpperCase(), value);
				String dd = data.substring(tag.length() + 2 + lx[0]);
				if (dd.length() > 0) {
					parseTlv(data.substring(tag.length() + 2 + lx[0]), tags, tlvs);
				}
			}
		}
	}
}