package com.isg.mw.tlv.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.tlv.TlvParser;

public class De48 {

private static final List<String> VISA_TAGS = new ArrayList<String>();
	
	private static final List<String> MC_TAGS = new ArrayList<String>();

	private static final List<String> RUPAY_TAGS = new ArrayList<String>();
	
	static {
		VISA_TAGS.add("84");
		VISA_TAGS.add("88");
		VISA_TAGS.add("89");
		VISA_TAGS.add("26");
		VISA_TAGS.add("66");
		VISA_TAGS.add("43");
		VISA_TAGS.add("21");
		VISA_TAGS.add("61");
		VISA_TAGS.add("37");
		VISA_TAGS.add("65");

		MC_TAGS.add("84");
		MC_TAGS.add("88");
		MC_TAGS.add("89");
		MC_TAGS.add("26");
		MC_TAGS.add("66");
		MC_TAGS.add("43");
		MC_TAGS.add("21");
		MC_TAGS.add("61");
		MC_TAGS.add("37");
		MC_TAGS.add("65");

		RUPAY_TAGS.add("84");
		RUPAY_TAGS.add("88");
		RUPAY_TAGS.add("89");
		RUPAY_TAGS.add("26");
		RUPAY_TAGS.add("66");
		RUPAY_TAGS.add("43");
		RUPAY_TAGS.add("21");
		RUPAY_TAGS.add("61");
		RUPAY_TAGS.add("37");
		RUPAY_TAGS.add("65");
	}
	
	private De48() {
	}

	public static List<String> getTags(TargetType targetType){
		
		switch(targetType) {
			case Master: return MC_TAGS;
			case Rupay: return RUPAY_TAGS;
			case Visa: return VISA_TAGS;
			default: return null;
		}
		
	}
	
	public static Map<String, String> parse(String data, TargetType targetType){
		Map<String, String> tlvs = new HashMap<String, String>();
		TlvParser.parseTlv(data, getTags(targetType), tlvs);
		return tlvs;
	}
	
}
