package com.isg.mw.tlv;

import java.util.List;

import org.jpos.iso.ISOUtil;

public class Tlv {

	private String tagHex;
	
	private String valueHex;
	
	public Tlv(String tagHex, String valueHex) {
		this.tagHex = tagHex;
		this.valueHex = valueHex;
	}

	public String getTag() {
		return tagHex;
	}
	
	public String getValue() {
		return valueHex;
	}
	
	public String getTlv() {
		byte l = (byte) (valueHex.length()/2);
		byte length[] = new byte[] {l};
		return tagHex + ISOUtil.byte2hex(length) + valueHex;
	}
	
	// hex string
	public String toString() {
		return getTlv();
	}

	
	public static String getHexString(List<Tlv> list) {
		StringBuilder sb = new StringBuilder();
		for(Tlv t: list) {
			sb.append(t.toString());
		}
		return sb.toString();
	}
	
}
