package com.isg.bms.responseModels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
@ToString
public class BillFetchResponse implements Serializable {

    @JsonProperty(value = "BillFetchResponse")
    private BillFetchResponseBody billFetchResponse;

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BillFetchResponseBody implements Serializable {

        @JsonProperty(value = "Head")
        private Head head;

        @JsonProperty(value = "Reason")
        private Reason reason;

        @JsonProperty(value = "BillDetails")
        private BillDetails billDetails;

        @JsonProperty(value = "BillerResponse")
        private BillerResponse billerResponse;

        @JsonProperty(value = "AdditionalInfo")
        private List<AdditionalInfo> additionalInfos;

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Head implements Serializable {
            public String refId;
            public String msgId;
            public String origInst;
            public String ts;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Reason implements Serializable {
            private String approvalRefNum;
            public String responseCode;
            public String responseReason;
            public String complianceRespCd;
            public String complianceReason;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillDetails implements Serializable {
            public String billerId;
            @JsonProperty(value = "CustomerParams")
            public List<CustomerParams> customerParams;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class CustomerParams implements Serializable {
            public String name;
            public String value;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillerResponse implements Serializable {
            public String customerName;
            public String amount;
            public String dueDate;
            public String billDate;
            public String billNumber;
            public String billPeriod;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class AdditionalInfo implements Serializable {
            public String name;
            public String value;
        }
    }
}