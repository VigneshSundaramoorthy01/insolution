package com.isg.bms.commonModels;

/**
 *
 * @author pradip5798
 *
 */
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "head")
@Data
public class Head {

    @NotBlank(message = "Version not present")
    @Size(min = 3, max = 15, message = "Version Length Error")
    @XmlAttribute(name = "ver", required = true)
    private String ver;

    @NotBlank(message = "Time of request not present")
    @XmlAttribute(name = "ts", required = true)
    private String ts;

    @NotBlank(message = "origInst request not present")
    @XmlAttribute(name = "origInst", required = true)
    private String origInst;

    @NotBlank(message = "refId request not present")
    @XmlAttribute(name = "refId", required = true)
    private String refId;
}