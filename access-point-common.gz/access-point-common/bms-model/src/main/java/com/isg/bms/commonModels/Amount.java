package com.isg.bms.commonModels;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "amount")
@Data
public class Amount {

    @XmlElement(name = "Amt")
    @NotNull(message = "Amt not Present")
    protected Amt amt;

    @XmlElement(name = "SplitPayAmount")
    @NotNull(message = "splitPayAmount not Present")
    private String splitPayAmount;

    @XmlElement(name = "Tag", required = true)
    @NotNull(message = "Device Tags not Present")
    @Valid
    protected List<Tag> tag;

    //Getters & Setters
    public Amt getAmt() {
        if (amt == null) {
            amt = new Amt();
        }
        return this.amt;
    }

    public List<Tag> getTag() {
        if (tag == null) {
            tag = new ArrayList<Tag>();
        }
        return this.tag;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Amt {

        @NotBlank(message = "amount not present")
        @XmlAttribute(name = "amount", required = true)
        private String amount;

        @NotBlank(message = "custConvFee not present")
        @XmlAttribute(name = "custConvFee", required = true)
        private String custConvFee;

        @NotBlank(message = "currency not present")
        @XmlAttribute(name = "currency", required = true)
        private String currency;
    }
}
