package com.isg.bms.requestModels;

import com.isg.bms.commonModels.Head;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "billPaymentRequest", namespace = "http://bbps.org/schema")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class BillPayReversalNpciRequest {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn")
    protected Txn txn;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Txn {

        @NotBlank(message = "txnReferenceId not present")
        @XmlAttribute(name = "txnReferenceId", required = true)
        private String txnReferenceId;

        @NotBlank(message = "ts not present")
        @XmlAttribute(name = "ts", required = true)
        private String ts;

        @NotBlank(message = "type not present")
        @XmlAttribute(name = "type", required = true)
        private String type;

        @NotBlank(message = "msgId not present")
        @XmlAttribute(name = "msgId", required = true)
        private String msgId;
    }
}
