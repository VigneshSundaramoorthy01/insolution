package com.isg.bms.responseModels;


import com.isg.bms.commonModels.AdditionalInfo;
import com.isg.bms.commonModels.BillerResponse;
import com.isg.bms.commonModels.Head;
import com.isg.bms.commonModels.Tag;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "billFetchResponse")
@Data
public class BillFetchNpciResponse {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "Reason not present")
    @XmlElement(name = "Reason", required = true)
    protected Reason reason;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn", required = true)
    protected BillFetchNpciResponse.TxnType txn;

    @NotEmpty(message = "BillDetails not present")
    @XmlElement(name = "BillDetails", required = true)
    protected BillFetchNpciResponse.BillDetails billDetails;

    @NotEmpty(message = "BillerResponse not present")
    @XmlElement(name = "BillerResponse", required = true)
    protected BillerResponse billerResponse;

    @NotEmpty(message = "AdditionalInfo not present")
    @XmlElement(name = "AdditionalInfo", required = true)
    protected AdditionalInfo additionalInfo;

    //Txn Class
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "txnType")
    @Data
    public static class TxnType {

        @NotBlank(message = "Time not present in response")
        @XmlAttribute(name = "ts", required = true)
        private String ts;

        @NotBlank(message = "msg Id not present")
        @XmlAttribute(name = "msgId", required = true)
        private String msgId;

    }

    //BillDetails.CustomerParams Class
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class BillDetails {

        @XmlElement(name = "CustomerParams", required = true)
        @NotNull(message = "customerParams Tag not Present")
        @Valid
        protected BillFetchNpciResponse.BillDetails.CustomerParams customerParams;

        //getters
        public CustomerParams getCustomerParams() {
            if (customerParams == null) {
                customerParams = new CustomerParams();
            }
            return customerParams;
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class CustomerParams {

            @XmlElement(name = "Tag", required = true)
            @NotNull(message = "CustomerParams Tags not Present")
            @Valid
            protected List<Tag> tag;

            public List<Tag> getTag() {
                if (tag == null) {
                    tag = new ArrayList<Tag>();
                }
                return this.tag;
            }

            public void setTag(List<Tag> tag) {
                this.tag = tag;
            }
        }
    }
}
