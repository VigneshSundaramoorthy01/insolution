package com.isg.bms.requestModels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
public class BillPayRequest implements Serializable {

    @JsonProperty(value = "BillPaymentRequest")
    private BillPayRequestBody billPayRequest;


    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BillPayRequestBody implements Serializable {

        @JsonProperty(value = "Head")
        private Head head;

        @JsonProperty(value = "BillDetails")
        private BillDetails billDetails;

        @JsonProperty(value = "PaymentMethod")
        private PaymentMethod paymentMethod;

        @JsonProperty(value = "Amount")
        private Amount amount;

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Head implements Serializable {
            public String refId;
            public String msgId;
            public String txnReferenceId;
            public String origInst;
            public String ts;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillDetails implements Serializable {

            @JsonProperty(value = "Biller")
            public Biller biller;

            @JsonProperty(value = "CustomerParams")
            public List<CustomerParams> customerParams;

            @Getter
            @Setter
            @ToString
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Biller implements Serializable {
                public String id;
            }

            @Getter
            @Setter
            @ToString
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class CustomerParams implements Serializable {
                public String name;
                public String value;
            }
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class PaymentMethod implements Serializable {

            @JsonProperty(value = "OFFUSPay")
            public String OFFUSPay;
            public String paymentMode;
            public String quickPay;
            public String splitPay;
        }


        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Amount implements Serializable {

            @JsonProperty(value = "Amt")
            public Amt amt;

            @JsonProperty(value = "SplitPayAmount")
            public String SplitPayAmount;


            @Getter
            @Setter
            @ToString
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Amt implements Serializable {
                public String amount;
                public String custConvFee;
            }
        }
    }
}
