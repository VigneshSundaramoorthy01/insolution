package com.isg.bms.responseModels;

import com.isg.bms.commonModels.*;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ResDiagnostic")
@Data
public class DiagnosticNpciResponse {

    @XmlAttribute(name = "responseReason", required = true)
    protected String responseReason;

    @NotNull(message = "Head Tag not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @XmlElement(name = "errorMessages")
    protected List<ErrorMessage> errorMessages;

    @Data
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class ErrorMessage {

        @XmlElement(name = "errorCd")
        protected String errorCd;

        @XmlElement(name = "errorDtl")
        protected String errorDtl;
    }
}