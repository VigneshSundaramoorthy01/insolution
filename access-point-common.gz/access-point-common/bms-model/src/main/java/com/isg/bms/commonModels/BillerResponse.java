package com.isg.bms.commonModels;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillerResponse")
@Data
public class BillerResponse {

    @NotEmpty(message="Customer Name not present")
    @XmlAttribute(name = "customerName")
    private String customerName;

    @NotEmpty(message="Amount not present")
    @XmlAttribute(name = "amount")
    private String amount;

    @NotEmpty(message="Due Date not present")
    @XmlAttribute(name = "dueDate")
    private String dueDate;

    @NotEmpty(message="BillDate Name not present")
    @XmlAttribute(name = "billDate")
    private String billDate;

    @NotEmpty(message="BillNumber not present")
    @XmlAttribute(name = "billNumber")
    private String billNumber;

    @NotEmpty(message="BillPeriod not present")
    @XmlAttribute(name = "billPeriod")
    private String billPeriod;

    @NotEmpty(message="BillPeriod not present")
    @XmlAttribute(name = "custConvFee")
    private String custConvFee;

    @XmlElement(name = "Tag", required = true)
    @NotNull(message = "BillerResponse Tags not Present")
    @Valid
    protected List<Tag> tag;

    public List<Tag> getTag() {
        if (tag == null) {
            tag = new ArrayList<Tag>();
        }
        return this.tag;
    }
}
