package com.isg.bms.commonModels;

import lombok.Data;

import java.io.Serializable;

@Data
public class BmsTxnDataModel implements Serializable {
    private String refId;
    private String txnReferenceId;
    private String msgId;
    private String billerNumber;
    private String billPayStatus;
    private String billFetchStatus;
}
