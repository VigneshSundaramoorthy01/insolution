package com.isg.bms.requestModels;

import com.isg.bms.commonModels.*;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "billFetchResponse")
@Data
public class BillPayNpciRequest {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "PaymentMethod not present")
    @XmlElement(name = "PaymentMethod", required = true)
    protected PaymentMethod paymentMethod;

    @XmlElement(name = "Analytics")
    @NotEmpty(message = "Analytics not present")
    @Valid
    protected Analytics analytics;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn", required = true)
    protected Txn txn;

    @NotEmpty(message = "Customer not present")
    @XmlElement(name = "Customer", required = true)
    protected Customer customer;

    @NotEmpty(message = "Agent not present")
    @XmlElement(name = "Agent", required = true)
    protected AgentType agent;

    @NotEmpty(message = "BillDetails not present")
    @XmlElement(name = "BillDetails", required = true)
    protected BillDetails billDetails;

    @NotEmpty(message = "BillerResponse not present")
    @XmlElement(name = "BillerResponse", required = true)
    protected BillerResponse billerResponse;

    @NotEmpty(message = "AdditionalInfo not present")
    @XmlElement(name = "AdditionalInfo", required = true)
    protected AdditionalInfo additionalInfo;

    @NotEmpty(message = "Amount not present")
    @XmlElement(name = "Amount", required = true)
    protected Amount amount;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class PaymentMethod {

        @NotBlank(message = "quickPay not present")
        @XmlAttribute(name = "quickPay", required = true)
        private String quickPay;

        @NotBlank(message = "splitPay not present")
        @XmlAttribute(name = "splitPay", required = true)
        private String splitPay;

        @NotBlank(message = "OFFUSPay not present")
        @XmlAttribute(name = "OFFUSPay", required = true)
        private String OFFUSPay;

        @NotBlank(message = "paymentMode not present")
        @XmlAttribute(name = "paymentMode", required = true)
        private String paymentMode;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Head {

        @NotBlank(message = "Version not present")
        @Size(min = 3, max = 15, message = "Version Length Error")
        @XmlAttribute(name = "ver", required = true)
        private String ver;

        @NotBlank(message = "Time of request not present")
        @XmlAttribute(name = "ts", required = true)
        protected String ts;

        @NotBlank(message = "siTxn not present")
        @XmlAttribute(name = "siTxn", required = true)
        private String siTxn;

        @NotBlank(message = "origInst not present")
        @XmlAttribute(name = "origInst", required = true)
        private String origInst;

        @NotBlank(message = "refId not present")
        @XmlAttribute(name = "refId", required = true)
        private String refId;

        @NotBlank(message = "origRefId not present")
        @XmlAttribute(name = "origRefId", required = true)
        private String origRefId;
    }
}
