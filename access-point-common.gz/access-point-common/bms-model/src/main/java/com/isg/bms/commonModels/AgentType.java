package com.isg.bms.commonModels;

/**
 *
 * @author pradip5798
 *
 */

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "agent")
@Data
public class AgentType {

    @NotEmpty(message = "Id not present")
    @XmlAttribute(name = "id")
    private String id;

    @NotNull(message = "Device Tags not Present")
    @XmlElement(name = "Device", required = true)
    @Valid
    protected AgentType.Device device;

    public Device getDevice() {
        if (device == null) {
            device = new Device() ;
        }
        return device;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "device")
    @Data
    public static class Device {

        @XmlElement(name = "Tag", required = true)
        @NotNull(message = "Device Tags not Present")
        @Valid
        protected List<Tag> tag;

        //Getters & Setters
        public List<Tag> getTag() {
            if (tag == null) {
                tag = new ArrayList<Tag>();
            }
            return this.tag;
        }
    }
}
