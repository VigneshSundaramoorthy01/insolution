package com.isg.bms.commonModels;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tag")
public class Tag {

    @NotNull(message="Tag Name not present")
    @XmlAttribute(name = "name")
    private String name;

    @NotNull(message="Tag Value not present")
    @XmlAttribute(name = "value")
    protected String value;
}