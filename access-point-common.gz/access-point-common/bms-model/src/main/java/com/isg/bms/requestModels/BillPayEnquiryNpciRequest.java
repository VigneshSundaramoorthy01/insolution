package com.isg.bms.requestModels;

import com.isg.bms.commonModels.Head;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "billFetchResponse")
@Data
public class BillPayEnquiryNpciRequest {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn", required = true)
    protected BillPayEnquiryNpciRequest.Txn txn;

    @NotEmpty(message = "TxnStatusReq not present")
    @XmlElement(name = "TxnStatusReq", required = true)
    protected BillPayEnquiryNpciRequest.TxnStatusReq txnStatusReq;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Txn {

        @NotEmpty(message = "timestamp not present")
        @XmlAttribute(name = "ts", required = true)
        protected String ts;

        @NotEmpty(message = "xchangeId not present")
        @XmlAttribute(name = "xchangeId", required = true)
        protected String xchangeId;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class TxnStatusReq {

        @NotEmpty(message = "msgId not present")
        @XmlAttribute(name = "msgId", required = true)
        protected String msgId;

        @NotEmpty(message = "txnReferenceId not present")
        @XmlAttribute(name = "txnReferenceId", required = true)
        protected String txnReferenceId;
    }
}
