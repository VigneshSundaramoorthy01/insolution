package com.isg.bms.commonModels;

/**
 *
 * @author pradip5798
 *
 */

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "billDetails")
public class BillDetails {

    @XmlElement(name = "Biller", required = true)
    @NotNull(message = "Device Tags not Present")
    @Valid
    protected BillDetails.Biller biller;

    @XmlElement(name = "CustomerParams", required = true)
    @NotNull(message = "customerParams Tags not Present")
    @Valid
    protected BillDetails.CustomerParams customerParams;

    public Biller getBiller() {
//        if (biller == null) {
//            biller = new Biller();
//        }
        return this.biller;
    }

    public CustomerParams getCustomerParams() {
        if (customerParams == null) {
            customerParams = new CustomerParams();
        }
        return customerParams;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "biller")
    @Data
    public static class Biller {

        @NotBlank(message = "id of request not present")
        @XmlAttribute(name = "id", required = true)
        private String id;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "CustomerParams")
    @Data
    public static class CustomerParams {

        @XmlElement(name = "Tag", required = true)
        @NotNull(message = "CustomerParams Tags not Present")
        @Valid
        protected List<Tag> tag;

        public List<Tag> getTag() {
            if (tag == null) {
                tag = new ArrayList<Tag>();
            }
            return this.tag;
        }
    }
}
