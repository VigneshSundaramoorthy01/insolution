package com.isg.bms.responseModels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
public class BillPayEnquiryResponse implements Serializable {

    @JsonProperty(value = "TxnStatusResponse")
    private BillPayEnquiryResponseBody txnStatusResponse;

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BillPayEnquiryResponseBody implements Serializable {

        @JsonProperty(value = "Head")
        private Head head;

        @JsonProperty(value = "Reason")
        private Reason reason;

        @JsonProperty(value = "Txn")
        private Txn txn;

        @JsonProperty(value = "BillDetails")
        private BillDetails billDetails;

        @JsonProperty(value = "BillerResponse")
        private BillerResponse billerResponse;

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Head implements Serializable {
            public String refId;
            public String msgId;
            public String origInst;
            public String ts;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Reason implements Serializable {
            public String approvalRefNum;
            public String responseCode;
            public String responseReason;
            public String complianceRespCd;
            public String complianceReason;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Txn implements Serializable {
            public String txnReferenceId;
            public String type;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillDetails implements Serializable {
            public String billerId;
            @JsonIgnoreProperties(value = "CustomerParams")
            public List<CustomerParams> customerParams;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class CustomerParams implements Serializable {
            public String name;
            public String value;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillerResponse implements Serializable {
            public String customerName;
            public String amount;
            public String dueDate;
            public String billDate;
            public String billNumber;
            public String billPeriod;
        }
    }
}
