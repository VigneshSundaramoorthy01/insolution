package com.isg.bms.commonModels;


import javax.validation.Valid;
import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Ack")
public class XmlAckResponse {

    @XmlAttribute(name = "api")
    private String api;

    @XmlAttribute(name = "reqMsgId")
    private String reqMsgId;

    @XmlAttribute(name = "refId")
    private String refId;

    @XmlAttribute(name = "msgId")
    private String msgId;

    @XmlAttribute(name = "RspCd")
    private String rspCd;

    @XmlAttribute(name = "ts")
    private String ts;


    @XmlElement(name = "errorMessages", required = true)
    @Valid
    protected List<ErrorMessages> errorMessages;

    @XmlAccessorType(XmlAccessType.FIELD)
    private static class ErrorMessages{

        @XmlElement(name = "errorCode", required = true)
        private ErrorCode errorCode;

        @XmlElement(name = "errorDetails", required = true)
        private ErrorDetails errorDetails;


        public ErrorCode getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(ErrorCode errorCode) {
            this.errorCode = errorCode;
        }

        public ErrorDetails getErrorDetails() {
            return errorDetails;
        }

        public void setErrorDetails(ErrorDetails errorDetails) {
            this.errorDetails = errorDetails;
        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    private static class ErrorCode{

        @XmlValue
        protected String value;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    private static class ErrorDetails{

        @XmlValue
        protected String value;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

    }

    public List<ErrorMessages> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<ErrorMessages> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public String getApi() {
        return api;
    }

    public void setApi(String api) {
        this.api = api;
    }

    public String getReqMsgId() {
        return reqMsgId;
    }

    public void setReqMsgId(String reqMsgId) {
        this.reqMsgId = reqMsgId;
    }

    public String getTs() {
        return ts;
    }

    public void setTs(String ts) {
        this.ts = ts;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getRspCd() {
        return rspCd;
    }

    public void setRspCd(String rspCd) {
        this.rspCd = rspCd;
    }
}
