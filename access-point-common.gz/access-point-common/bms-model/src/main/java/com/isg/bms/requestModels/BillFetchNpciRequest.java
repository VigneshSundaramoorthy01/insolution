package com.isg.bms.requestModels;

/**
 *
 * @author pradip5798
 *
 */

import com.isg.bms.commonModels.*;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "BillFetchRequest")
@Data
public class BillFetchNpciRequest {

    @XmlElement(name = "Head", required = true)
    protected Head head;

    @XmlElement(name = "Analytics")
    @Valid
    protected Analytics analytics;

    @NotNull(message = "Txn Tag not present")
    @Valid
    @XmlElement(name = "Txn", required = true)
    protected TxnType txn;

    @NotNull(message = "Customer Tag not present")
    @XmlElement(name = "Customer", required = true)
    private Customer customer;


    @XmlElement(name = "Agent", required = true)
    private AgentType agent;

    @XmlElement(name = "BillDetails", required = true)
    private BillDetails billDetails;
}

