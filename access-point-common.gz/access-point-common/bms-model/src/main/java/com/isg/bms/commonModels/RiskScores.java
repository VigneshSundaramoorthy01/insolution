package com.isg.bms.commonModels;

/**
 *
 * @author pradip5798
 *
 */
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "riskScores", propOrder = {
        "score"
})
@Data
public class RiskScores {

    @XmlElement(name = "Score")
    @Valid
    protected List<Score> score;

    public List<Score> getScore() {
        if (score == null) {
            score = new ArrayList<Score>();
        }
        return score;
    }

    public void setScore(List<Score> score) {
        this.score = score;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Score {

        @XmlAttribute(name = "provider", required = true)
        @NotBlank(message = "Risk Score Provider Not Present")
        protected String provider;

        @NotBlank(message = "Risk Score type Not Present")
        @XmlAttribute(name = "type", required = true)
        protected String type;

        @NotBlank(message = "Risk Score value Not Present")
        @XmlAttribute(name = "value", required = true)
        protected String value;
    }

}
