package com.isg.bms.responseModels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.bms.requestModels.BillPayRequest;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Data
public class BillPayResponse implements Serializable {

    @JsonProperty(value = "BillPaymentResponse")
    private BillPayResponseBody billPayResponse;

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BillPayResponseBody implements Serializable {

        @JsonProperty(value = "Head")
        private BillPayRequest.BillPayRequestBody.Head head;

        @JsonProperty(value = "Reason")
        private Reason reason;

        @JsonProperty(value = "BillDetails")
        private BillPayRequest.BillPayRequestBody.BillDetails billDetails;

        @JsonProperty(value = "BillerResponse")
        private BillerResponse billerResponse;

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Reason implements Serializable {
            public String approvalRefNum;
            public String responseCode;
            public String responseReason;
            public String complianceRespCd;
            public String complianceReason;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillerResponse implements Serializable {
            public String amount;
            public String billDate;
            public String billNumber;
            public String billPeriod;
            public String customerName;
            public String dueDate;
        }

    }
}



