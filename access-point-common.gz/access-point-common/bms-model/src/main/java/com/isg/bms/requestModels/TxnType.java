package com.isg.bms.requestModels;


/**
 *
 * @author pradip5798
 *
 */
import lombok.Data;
import com.isg.bms.commonModels.*;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.*;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "txnType")
public class TxnType {

        @NotBlank(message = "Time of request not present")
        @XmlAttribute(name = "ts", required = true)
        private String ts;

        @NotEmpty(message = "MsgId not present")
        @XmlAttribute(name = "msgId")
        private String msgId;

        @NotEmpty(message = "DirectBillChannel not present")
        @XmlAttribute(name = "directBillChannel")
        private String directBillChannel;

        @XmlElement(name = "RiskScores")
        @Valid
        protected RiskScores riskScores;
}

