package com.isg.bms.requestModels;

import com.isg.bms.commonModels.RiskScores;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Txn")
@Data
public class Txn {

    @NotBlank(message = "txnReferenceId not present")
    @XmlAttribute(name = "txnReferenceId", required = true)
    private String txnReferenceId;

    @NotBlank(message = "ts not present")
    @XmlAttribute(name = "ts", required = true)
    private String ts;

    @NotBlank(message = "type not present")
    @XmlAttribute(name = "type", required = true)
    private String type;

    @NotBlank(message = "msgId not present")
    @XmlAttribute(name = "msgId", required = true)
    private String msgId;

    @NotBlank(message = "directBillChannel not present")
    @XmlAttribute(name = "directBillChannel", required = true)
    private String directBillChannel;

    @NotBlank(message = "directBillContentId not present")
    @XmlAttribute(name = "directBillContentId", required = true)
    private String directBillContentId;

    @NotBlank(message = "paymentRefId not present")
    @XmlAttribute(name = "paymentRefId", required = true)
    private String paymentRefId;

    @NotNull(message = "RiskScores not Present")
    @XmlElement(name = "RiskScores")
    private RiskScores riskScores;
}
