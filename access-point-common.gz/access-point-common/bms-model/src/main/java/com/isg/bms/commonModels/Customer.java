package com.isg.bms.commonModels;

/**
 *
 * @author pradip5798
 *
 */
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "customer")
@Data
public class Customer {

    @NotNull(message = "Mobile number must not be null")
    @XmlAttribute(name = "mobile", required = true)
    private String mobile;

    @XmlElement(name = "Tag", required = true)
    @NotNull(message = "Customer Tags not Present")
    @Valid
    protected List<Tag> tag;

    public List<Tag> getTag() {
        if (tag == null) {
            tag = new ArrayList<Tag>();
        }
        return this.tag;
    }
}
