package com.isg.bms.requestModels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
public class BillFetchRequest implements Serializable {

    @JsonProperty(value = "BillFetchRequest")
    private BillFetchRequestBody billFetchRequest;

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BillFetchRequestBody implements Serializable {

        @JsonProperty(value = "Head")
        private Head head;

        @JsonProperty(value = "BillDetails")
        private BillDetails billDetails;


        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Head implements Serializable {
            public String refId;
            public String msgId;
            public String origInst;
            public String ts;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class BillDetails implements Serializable {
            public String billerId;
            @JsonProperty(value = "CustomerParams")
            public List<CustomerParams> customerParams;
        }

        @Getter
        @Setter
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class CustomerParams implements Serializable {
            public String name;
            public String value;
        }
    }
}

