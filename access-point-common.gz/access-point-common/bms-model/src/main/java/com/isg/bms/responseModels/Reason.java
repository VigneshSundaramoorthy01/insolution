package com.isg.bms.responseModels;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reason")
public class Reason {

    @NotBlank(message = "approvalRefNum not present")
    @XmlAttribute(name = "approvalRefNum")
    private String approvalRefNum;

    @NotBlank(message = "responseCode not present")
    @XmlAttribute(name = "responseCode")
    private String responseCode;

    @NotBlank(message = "responseReason not present")
    @XmlAttribute(name = "responseReason")
    private String responseReason;

    @NotBlank(message = "complianceRespCd not present")
    @XmlAttribute(name = "complianceRespCd")
    private String complianceRespCd;

    @NotBlank(message = "complianceReason not present")
    @XmlAttribute(name = "complianceReason")
    private String complianceReason;
}
