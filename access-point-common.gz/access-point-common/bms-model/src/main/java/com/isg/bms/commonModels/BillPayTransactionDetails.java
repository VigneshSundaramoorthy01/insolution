package com.isg.bms.commonModels;

import lombok.Data;

import java.io.Serializable;

@Data
public class BillPayTransactionDetails implements Serializable {

    private String traceId;

    private String txdId;

    private String refId;

    private String txnReferenceId;

    private String paymentRefId;

    private String mobile;

    private String agentId;

    private String billerId;

    private String reqArrivalTime;

    private String customerName;

    private String amount;

    private String dueDate;

    private String billDate;

    private String billNumber;

    private String billPeriod;

    private String custConvFee;

    private String currency;

    private String paymentMode;

    private String quickPay;

    private String splitPay;

    private String SplitPayAmount;

    private String txnType;

    private String ifsc;

    private String msgId;

    private String reversalStatus;

    private String reversalTxnId;

    private String reversalStatusCode;

    private String status;//COMPLETED,PENDING,FAILED

    private String statusCode;

}
