package com.isg.bms.requestModels;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ReqDiagnostic",namespace = "http://bbps.org/schema")
@Data
public class DiagnosticNpciRequest {

    @NotNull(message = "Head Tag not present")
    @XmlElement(name = "Head", required = true)
    protected DiagnosticNpciRequest.Head head;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Head {

        @NotBlank(message = "Version not present")
        @Size(min = 3, max = 15, message = "Version Length Error")
        @XmlAttribute(name = "ver", required = true)
        private String ver;

        @NotBlank(message = "Time of request not present")
        @XmlAttribute(name = "ts", required = true)
        protected String ts;

        @NotBlank(message = "origInst not present")
        @XmlAttribute(name = "origInst", required = true)
        private String origInst;

        @NotBlank(message = "refId not present")
        @XmlAttribute(name = "refId", required = true)
        private String refId;
    }

}