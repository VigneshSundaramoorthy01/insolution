package com.isg.bms.commonModels;/*
package com.isg.npci.bbps;

import com.isg.npci.bbps.billPayRes.BillFetchResponse;
import com.isg.npci.bbps.billPayRes.Reason;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "billPaymentResponse")
@Data
public class BillPaymentResponse {

    @NotEmpty(message="Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message="Reason not present")
    @XmlElement(name = "Reason", required = true)
    protected Reason reason;

    @NotEmpty(message="Txn not present")
    @XmlElement(name = "Txn", required = true)
    protected BillPaymentResponse.Txn txn;

    @NotEmpty(message="BillDetails not present")
    @XmlElement(name = "BillDetails", required = true)
    protected BillFetchResponse.BillDetails billDetails;

    @NotEmpty(message="BillerResponse not present")
    @XmlElement(name = "BillerResponse", required = true)
    protected BillPaymentResponse.BillerResponse billerResponse;

    @NotEmpty(message="AdditionalInfo not present")
    @XmlElement(name = "AdditionalInfo", required = true)
    protected com.isg.npci.bbps.AdditionalInfo additionalInfo;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType
    @Data
    public static class Txn {

        @NotBlank(message = "txnReferenceId not present")
        @XmlAttribute(name = "txnReferenceId", required = true)
        private String txnReferenceId;

        @NotBlank(message = "ts not present")
        @XmlAttribute(name = "ts", required = true)
        private String ts;

        @NotBlank(message = "type not present")
        @XmlAttribute(name = "type", required = true)
        private String type;

        @NotBlank(message = "msgId not present")
        @XmlAttribute(name = "msgId", required = true)
        private String msgId;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType
    @Data
    public static class BillerResponse {

        @NotEmpty(message="Customer Name not present")
        @XmlAttribute(name = "customerName")
        private String customerName;

        @NotEmpty(message="Amount not present")
        @XmlAttribute(name = "amount")
        private String amount;

        @NotEmpty(message="Due Date not present")
        @XmlAttribute(name = "dueDate")
        private String dueDate;

        @NotEmpty(message="custConvFee Name not present")
        @XmlAttribute(name = "custConvFee")
        private String custConvFee;

        @NotEmpty(message="BillDate Name not present")
        @XmlAttribute(name = "billDate")
        private String billDate;

        @NotEmpty(message="BillNumber not present")
        @XmlAttribute(name = "billNumber")
        private String billNumber;

        @NotEmpty(message="BillPeriod not present")
        @XmlAttribute(name = "billPeriod")
        private String billPeriod;

    }
}
*/
