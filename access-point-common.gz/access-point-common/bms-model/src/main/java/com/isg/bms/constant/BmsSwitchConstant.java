package com.isg.bms.constant;

public interface BmsSwitchConstant {

    String BILL_FETCH_REQUEST = "BillFetchRequest";
    String BILL_PAY_REQUEST = "BillPaymentRequest";
    String BILL_PAY_REVERSAL = "BillPayReversalRequest";
    String BILL_STATUS_REQUEST = "TxnStatusRequest";
    String REQ_DIAGNOSTIC = "reqDiagnostic";
    String BMS_REQUEST_BODY = "requestBody";
    String END_POINT = "endPoint";

    String PAY_TXN_TYPE = "Pay";
    String REVERSAL_TXN_TYPE = "Reversal";


    //Redis Status
    String PENDING = "Pending";
    String SUCCESS = "Success";

    public static String npciRespDateFormat = "yyyy-MM-dd'T'HH:mm:ss'+05:30'";

    String KEY_SEPARATOR = "::";

}
