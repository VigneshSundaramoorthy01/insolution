package com.isg.bms.responseModels;

import com.isg.bms.commonModels.AdditionalInfo;
import com.isg.bms.commonModels.BillerResponse;
import com.isg.bms.commonModels.Head;
import com.isg.bms.commonModels.Tag;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "BillPaymentResponse")
@Data
public class BillPayNpciResponse {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "Reason not present")
    @XmlElement(name = "Reason", required = true)
    protected Reason reason;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn", required = true)
    protected BillPayNpciResponse.TxnType txn;

    @NotEmpty(message = "BillDetails not present")
    @XmlElement(name = "BillDetails", required = true)
    protected BillPayNpciResponse.BillDetails billDetails;

    @NotEmpty(message = "BillerResponse not present")
    @XmlElement(name = "BillerResponse", required = true)
    protected BillerResponse billerResponse;

    @NotEmpty(message = "AdditionalInfo not present")
    @XmlElement(name = "AdditionalInfo", required = true)
    protected AdditionalInfo additionalInfo;

    // Txn Class
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "txnType")
    @Data
    public static class TxnType {

        @NotBlank(message = "Transaction Reference ID not present")
        @XmlAttribute(name = "txnReferenceId", required = true)
        private String txnReferenceId;

        @NotBlank(message = "Time not present in response")
        @XmlAttribute(name = "ts", required = true)
        private String ts;

        @NotBlank(message = "Transaction type not present")
        @XmlAttribute(name = "type", required = true)
        private String type;

        @NotBlank(message = "Message ID not present")
        @XmlAttribute(name = "msgId", required = true)
        private String msgId;

    }

    // BillDetails.CustomerParams Class
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class BillDetails {

        @XmlElement(name = "CustomerParams", required = true)
        @NotNull(message = "CustomerParams Tag not present")
        @Valid
        protected BillPayNpciResponse.BillDetails.CustomerParams customerParams;

        // Getters
        public CustomerParams getCustomerParams() {
            if (customerParams == null) {
                customerParams = new CustomerParams();
            }
            return customerParams;
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        public static class CustomerParams {

            @XmlElement(name = "Tag", required = true)
            @NotNull(message = "CustomerParams Tags not present")
            @Valid
            protected List<Tag> tag;

            public List<Tag> getTag() {
                if (tag == null) {
                    tag = new ArrayList<Tag>();
                }
                return this.tag;
            }

            public void setTag(List<Tag> tag) {
                this.tag = tag;
            }
        }
    }
}
