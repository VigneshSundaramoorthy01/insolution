package com.isg.bms.requestModels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Data
public class BillPayEnquiryRequest implements Serializable {

    @JsonProperty(value = "TxnStatusRequest")
    private BillPayEnquiryRequestBody txnStatusRequest;

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class BillPayEnquiryRequestBody implements Serializable {

        @JsonProperty(value = "Head")
        private Head head;

        @JsonProperty(value = "txnStatusReq")
        private TxnStatusReq txnStatusReq;

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Head implements Serializable {
            public String refId;
            public String msgId;
            public String origInst;
            public String ts;
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class TxnStatusReq implements Serializable {
            public String txnReferenceId;
        }
    }
}
