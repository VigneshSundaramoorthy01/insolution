package com.isg.bms.responseModels;

import com.isg.bms.commonModels.AdditionalInfo;
import com.isg.bms.commonModels.Head;
import com.isg.bms.commonModels.Tag;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TxnStatusResponse", namespace = "http://bbps.org/schema")
public class BillPayEnquiryNpciResponse {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "Reason not present")
    @XmlElement(name = "Reason", required = true)
    protected Reason reason;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn", required = true)
    protected Txn txn;

    @NotEmpty(message = "BillDetails not present")
    @XmlElement(name = "BillDetails", required = true)
    protected BillDetails billDetails;

    @NotEmpty(message = "BillerResponse not present")
    @XmlElement(name = "BillerResponse", required = true)
    protected BillerResponse billerResponse;

    @NotEmpty(message = "AdditionalInfo not present")
    @XmlElement(name = "AdditionalInfo", required = true)
    protected AdditionalInfo additionalInfo;

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class Txn {

        @NotBlank(message = "txnReferenceId not present")
        @XmlAttribute(name = "txnReferenceId", required = true)
        private String txnReferenceId;

        @NotBlank(message = "ts not present")
        @XmlAttribute(name = "ts", required = true)
        private String ts;

        @NotBlank(message = "type not present")
        @XmlAttribute(name = "type", required = true)
        private String type;

        @NotBlank(message = "msgId not present")
        @XmlAttribute(name = "msgId", required = true)
        private String msgId;

        @NotBlank(message = "xchangeId not present")
        @XmlAttribute(name = "xchangeId", required = true)
        private String xchangeId;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class BillDetails {

        @XmlElement(name = "CustomerParams", required = true)
        @NotNull(message = "CustomerParams Tag not present")
        @Valid
        private CustomerParams customerParams;

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "")
        @Data
        public static class CustomerParams {

            @XmlElement(name = "Tag", required = true)
            @NotNull(message = "CustomerParams Tags not Present")
            @Valid
            protected List<Tag> tag;

            public List<Tag> getTag() {
                if (tag == null) {
                    tag = new ArrayList<Tag>();
                }
                return this.tag;
            }
        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    @Data
    public static class BillerResponse {

        @NotEmpty(message = "Customer Name not present")
        @XmlAttribute(name = "customerName")
        private String customerName;

        @NotEmpty(message = "Amount not present")
        @XmlAttribute(name = "amount")
        private String amount;

        @NotEmpty(message = "Due Date not present")
        @XmlAttribute(name = "dueDate")
        private String dueDate;

        @NotEmpty(message = "BillPeriod not present")
        @XmlAttribute(name = "custConvFee")
        private String custConvFee;

        @NotEmpty(message = "BillDate Name not present")
        @XmlAttribute(name = "billDate")
        private String billDate;

        @NotEmpty(message = "BillNumber not present")
        @XmlAttribute(name = "billNumber")
        private String billNumber;

        @NotEmpty(message = "BillPeriod not present")
        @XmlAttribute(name = "billPeriod")
        private String billPeriod;
    }
}
