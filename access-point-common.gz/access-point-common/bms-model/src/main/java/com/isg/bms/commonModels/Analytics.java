package com.isg.bms.commonModels;

/**
 *
 * @author pradip5798
 *
 */
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "analytics", propOrder = {
    "tag"
})
@Data
public class Analytics {

    @XmlElement(name = "Tag", required = true)
    @NotNull(message = "Device Tags not Present")
    @Valid
    protected List<Tag> tag;

    public void setTag(List<Tag> tag) {
        this.tag = tag;
    }

    public List<Tag> getTag() {
        if (tag == null) {
            tag = new ArrayList<Tag>();
        }
        return this.tag;
    }
}
