package com.isg.bms.responseModels;

import com.isg.bms.commonModels.*;
import com.isg.bms.requestModels.BillPayReversalNpciRequest;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "billPaymentResponse", namespace = "http://bbps.org/schema")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class BillPayReversalNpciResponse {

    @NotEmpty(message = "Head not present")
    @XmlElement(name = "Head", required = true)
    protected Head head;

    @NotEmpty(message = "Reason not present")
    @XmlElement(name = "Reason", required = true)
    protected Reason reason;

    @NotEmpty(message = "Txn not present")
    @XmlElement(name = "Txn")
    protected BillPayReversalNpciRequest.Txn txn;

}
