package com.isg.mw.crmgr.impl;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.isg.mw.crmgr.CamelRouterManager;

@Component("camelRouterManager")
public class CamelRouterManagerImpl implements InitializingBean, CamelRouterManager {

	private final Logger LOG = LogManager.getLogger(getClass());
	private DefaultCamelContext context;

	@Override
	public void afterPropertiesSet() throws Exception {
		init();
	}

	private void init() {
		context = new DefaultCamelContext();
		context.start();
		LOG.info("init() called....");
		LOG.info("context name: " + context.getName());
	}

	@Override
	public void add(RouteBuilder router, String id) throws Exception {
		context.addRoutes(router);
		LOG.info("successfully added router {}", id);
	}

	@Override
	public void start(String id) throws Exception {
		context.startRoute(id);
		LOG.info("successfully started router {}", id);
	}

	@Override
	public void stop(String id) throws Exception {
		context.stopRoute(id);
		LOG.info("successfully stoped router {} ", id);
	}

	@Override
	public void remove(String id) throws Exception {
		context.removeRoute(id);
		LOG.info("successfully removed router {} ", id);
	}

}