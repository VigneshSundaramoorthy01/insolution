package com.isg.mw.crmgr;

import org.apache.camel.builder.RouteBuilder;

public interface CamelRouterManager {

	public void add(RouteBuilder router, String id) throws Exception ;

	public void start(String id) throws Exception;

	public void stop(String id) throws Exception;

	public void remove(String id) throws Exception;

}