# Access Point - Common components

