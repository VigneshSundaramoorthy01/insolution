package com.isg.mw.dstm.service;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.util.Arrays;

import com.isg.mw.dstm.utils.HsmCommandUtility;

public class HsmClient {

	// initialize socket and input output streams
	private Socket socket = null;
	private OutputStream out = null;
	private InputStream in = null;

	public static void main(String args[]) {
		new HsmClient("192.168.83.122", 8888, "0101222200", "EE0602003e07adbbc260f6050F20020001FFFF0987654321000001020158401900030301020007");
		// new HsmClient("192.168.83.122", 8888);
	}

	public HsmClient(String address, int port, String header, String command) {
		try (Socket socket = new Socket(address, port);
				InputStream in = socket.getInputStream();
				OutputStream os = socket.getOutputStream()) {
			byte[] headerbytes = HsmCommandUtility.parseHexBinary(header);
			byte[] commandbytes = HsmCommandUtility.parseHexBinary(command);
			int headerLength = headerbytes.length;
			int lengthByte = 1;
			byte[] request = new byte[headerLength + lengthByte + commandbytes.length];
			System.arraycopy(headerbytes, 0, request, 0, headerbytes.length);
			System.out.println("request : " + HsmCommandUtility.printHexBinary(request));
			request[headerLength] = (byte) (commandbytes.length % 256);
			System.arraycopy(commandbytes, 0, request, headerLength + lengthByte, commandbytes.length);
			System.out.println("request : " + HsmCommandUtility.printHexBinary(request));
			os.write(request);
			os.flush();
			byte[] resHeader = new byte[headerLength + 1];
			in.read(resHeader);
			System.out.println("response header : " + HsmCommandUtility.printHexBinary(resHeader));
			int len = (resHeader[headerLength - 1] & 0xFF) * 256 + (resHeader[headerLength] & 0xFF); 
			
			System.out.println("response header length : " + len);
			byte[] response = new byte[len];
			in.read(response);
			System.out.println("response : " + HsmCommandUtility.printHexBinary(response));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// constructor to put ip address and port
	public HsmClient(String address, int port) {
		// establish a connection
		try {
			socket = new Socket(address, port);
			if (socket.isConnected()) {
				System.out.println("Connected");
			}
			DataInputStream input = new DataInputStream(System.in);
			// sends output to the socket
			out = new DataOutputStream(socket.getOutputStream());
			// takes input from socket
			in = new DataInputStream(socket.getInputStream());

			@SuppressWarnings("deprecation")
			String line = input.readLine();
			byte[] request = line.getBytes();
			String req = Arrays.toString(request);

			// sending data to server
			out.write("0101222200".getBytes());
			out.write(27);
			out.write(request);
			// printing request to console
			System.out.println("Sent to server : " + req);

			// Receiving reply from server
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte buffer[] = new byte[1024];
			baos.write(buffer, 0, in.read(buffer));

			byte result[] = baos.toByteArray();

			String res = Arrays.toString(result);

			// printing reply to console
			System.out.println("Recieved from server : " + res);
			// input.close();
			in.close();
			out.close();
			socket.close();
		} catch (ConnectException i) {
			System.out.println(i);
		}catch (Exception i) {
			System.out.println(i);
		}
	}

}
