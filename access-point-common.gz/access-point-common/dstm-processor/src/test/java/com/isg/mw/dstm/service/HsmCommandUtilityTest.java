package com.isg.mw.dstm.service;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.dstm.utils.HsmCommandUtility;

public class HsmCommandUtilityTest {

	@Test
	public void testFormatCommand() {
		Map<String, String> commandArg = new HashMap<>();
		commandArg.put(HsmCommandArg.Ksn.name(), "FFFF1000000000000000");
		commandArg.put(HsmCommandArg.Bdk.name(), "020001");
		commandArg.put(HsmCommandArg.Pinblock.name(), "2ED78BF17C697675");
		commandArg.put(HsmCommandArg.Pan.name(), "390003545902");
		commandArg.put(HsmCommandArg.Awk.name(), "020004");
		commandArg.put(HsmCommandArg.Ipek.name(), "020001");
		commandArg.put(HsmCommandArg.EncrptData.name(), "98121b340d3eab60080ec76396190da6");
		String key = "EE040C00{Ipek}0F20{Bdk}{Ksn}0200";
		System.out.println(HsmCommandUtility.formatCommand(key, commandArg));
		String pin = "EE060200{Pinblock}0F20{Bdk}{Ksn}0201{Pan}01{Awk}";
		System.out.println(HsmCommandUtility.formatCommand(pin, commandArg));
		String decrypt = "EE0801000F20{Bdk}{Ksn}0201000000000000000010{EncrptData}";
		System.out.println(HsmCommandUtility.formatCommand(decrypt, commandArg));
	}

	@Test
	public void testHsmCommandUtility() {
		String input = "AQEiIgAn7gYCAKm2wDUeh+//DyACAAH//5h2VDIQ4AADAgE5AANUWQABAgAE";
		System.out.println(HsmCommandUtility.base64Encoder(
				"010122220027EE060200A9B6C0351E87EFFF0F20020001FFFF9876543210E00003020139000354590001020004"));
		System.out.println(HsmCommandUtility.base64Decoder(input));
	}

	public static void main(String args[]) {
		String st = String.format("%02X", "01".getBytes());
		System.out.print(st);
	}

}
