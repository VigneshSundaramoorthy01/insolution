package com.isg.mw.dstm.configs;

import org.apache.camel.CamelContext;
import org.apache.camel.component.netty.NettyConfiguration;
import org.apache.camel.component.netty.NettyEndpoint;

import com.isg.mw.dstm.cache.HsmConfigCache;

public class DstmNettyConfig {

    private DstmNettyConfig() {

    }

    public static NettyEndpoint getProducerEndpoint(CamelContext camelContext, HsmConfigCache model) {
        NettyEndpoint nettyProducerEndpoint = camelContext.getEndpoint(getProducerUri(model), NettyEndpoint.class);
        nettyProducerEndpoint.setConfiguration(DstmNettyConfig.getProducerConfig(model));
        return nettyProducerEndpoint;
    }

    private static String getProducerUri(HsmConfigCache model) {
        return "netty:tcp://" + model.getIp() + ":" + model.getPort();
    }

    private static NettyConfiguration getProducerConfig(HsmConfigCache model) {
        NettyConfiguration nettyConfig = new NettyConfiguration();
        nettyConfig.setHost(model.getIp());
        nettyConfig.setPort(model.getPort());
        nettyConfig.setProtocol(model.getProtocol().toString());
        nettyConfig.addDecoder(new DstmByteStreamDecoder());
        nettyConfig.setSync(true);
        nettyConfig.setWorkerCount(model.getNettyConfig().getWorkerCount());
        nettyConfig.setRequestTimeout(model.getNettyConfig().getRequestTimeout());
        nettyConfig.setClientMode(true);
        nettyConfig.setReuseChannel(true);
        nettyConfig.setConnectTimeout(model.getNettyConfig().getConnectTimeout());
        nettyConfig.setDisconnect(false);
        nettyConfig.setDisconnectOnNoReply(false);
        nettyConfig.setKeepAlive(true);
        nettyConfig.setProducerPoolEnabled(true);
        nettyConfig.setUseByteBuf(true);
        nettyConfig.setProducerPoolMaxActive(model.getNettyConfig().getPoolMaxActive());
        nettyConfig.setProducerPoolMaxIdle(model.getNettyConfig().getPoolMaxIdle());
        nettyConfig.setProducerPoolMinEvictableIdle(model.getNettyConfig().getPoolMinEvictableIdle());
        nettyConfig.setProducerPoolMinIdle(model.getNettyConfig().getPoolMinIdle());
        return nettyConfig;
    }
    
    /*
     * For Hsm Utility
     * 
     */
    
    public static NettyEndpoint getHsmUtilityProducerEndpoint(CamelContext camelContext, HsmConfigCache model, String host, String port) {
		NettyEndpoint nettyProducerEndpoint = camelContext.getEndpoint(getHsmUtilityProducerUri(host, port), NettyEndpoint.class);
		nettyProducerEndpoint.setConfiguration(getHsmUtilityProducerConfig(model, host, port));
		return nettyProducerEndpoint;
	}

    private static String getHsmUtilityProducerUri(String host, String port) {
    	return "netty:tcp://"+host+":"+port;
    }
    
	private static NettyConfiguration getHsmUtilityProducerConfig(HsmConfigCache model, String host, String port) {
        NettyConfiguration nettyConfig = new NettyConfiguration();
        nettyConfig.setHost(host);
        nettyConfig.setPort(Integer.parseInt(port));
        nettyConfig.setProtocol(model.getProtocol().toString());
        nettyConfig.addDecoder(new DstmByteStreamDecoder());
        nettyConfig.setSync(true);
        nettyConfig.setWorkerCount(model.getNettyConfig().getWorkerCount());
        nettyConfig.setRequestTimeout(model.getNettyConfig().getRequestTimeout());
        nettyConfig.setClientMode(true);
        nettyConfig.setReuseChannel(true);
        nettyConfig.setConnectTimeout(model.getNettyConfig().getConnectTimeout());
        nettyConfig.setDisconnect(false);
        nettyConfig.setDisconnectOnNoReply(false);
        nettyConfig.setKeepAlive(true);
        nettyConfig.setProducerPoolEnabled(true);
        nettyConfig.setUseByteBuf(true);
        nettyConfig.setProducerPoolMaxActive(model.getNettyConfig().getPoolMaxActive());
        nettyConfig.setProducerPoolMaxIdle(model.getNettyConfig().getPoolMaxIdle());
        nettyConfig.setProducerPoolMinEvictableIdle(model.getNettyConfig().getPoolMinEvictableIdle());
        nettyConfig.setProducerPoolMinIdle(model.getNettyConfig().getPoolMinIdle());
        return nettyConfig;
    }
}
