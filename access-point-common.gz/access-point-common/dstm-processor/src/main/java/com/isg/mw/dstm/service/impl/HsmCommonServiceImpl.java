package com.isg.mw.dstm.service.impl;

import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.core.model.dstm.Keys;
import com.isg.mw.dstm.cache.HsmConfigCache;
import com.isg.mw.dstm.configs.DstmProducer;
import com.isg.mw.dstm.constants.HsmConstants;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.dstm.utils.HsmCommandUtility;
import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author sudharshan
 */
@Service
public class HsmCommonServiceImpl implements HsmCommonService {

    private final Logger LOG = LogManager.getLogger(getClass());

    public Map<String, HsmConfigCache> HSM_CONFIG_MAP = new ConcurrentHashMap<>();

    private Map<String, HsmVendor> HSM_VENDOR_MAP = new ConcurrentHashMap<>();

    @Autowired
    private DstmProducer dstmProducer;

    @Override
    public void init(List<HsmConfigModel> dstms) {

        for (HsmConfigModel hsmConfigModel : dstms) {
            updateHsmConfigInCache(hsmConfigModel);
        }
        initCamelContext();
    }

    @Override
    public HsmConfigCache getHsmConfigByEntityAndOwner(String entityId, String sourceOwnerName, String manufacture) {
        if (entityId != null && sourceOwnerName != null && manufacture != null) {
            return HSM_CONFIG_MAP.get(HsmCommandUtility.constructKey(entityId, sourceOwnerName, manufacture));
        }
        return null;
    }

    @Override
    public void updateHsmConfigInCache(HsmConfigModel hsmConfigModel) {
        Keys[] keylist = hsmConfigModel.getKeys();
        for (Keys keys : keylist) {
            HsmConfigCache configCache = getHsmConfigCache(hsmConfigModel);
            configCache.setSourceOwnerName(keys.getOwnerName());
            configCache.setBdk(keys.getOffsets().getBdk());
            configCache.setIpek(keys.getOffsets().getIpek());
            configCache.setAwks(keys.getOffsets().getAwks());
            configCache.setZmks(keys.getOffsets().getZmks());
            configCache.setZaks(keys.getOffsets().getZaks());
            HSM_CONFIG_MAP.put(configCache.getEntityId() + HsmConstants.KEY_SEPERATOR + configCache.getSourceOwnerName() + HsmConstants.KEY_SEPERATOR + configCache.getManufacture(), configCache);
			HSM_VENDOR_MAP.put(configCache.getEntityId(), HsmVendor.getConnectionVendor(configCache.getManufacture()));
        }
    }

    private HsmConfigCache getHsmConfigCache(HsmConfigModel hsmConfigModel) {
        HsmConfigCache configCache = new HsmConfigCache();
        configCache.setEntityId(hsmConfigModel.getEntityId());
        configCache.setName(hsmConfigModel.getName());
        configCache.setManufacture(hsmConfigModel.getManufacture());
        configCache.setModel(hsmConfigModel.getModel());
        configCache.setProtocol(hsmConfigModel.getProtocol());
        configCache.setIp(hsmConfigModel.getIp());
        configCache.setPort(hsmConfigModel.getPort());
        configCache.setType(hsmConfigModel.getType());
        configCache.setOffsetType(hsmConfigModel.getOffsetType());
        configCache.setHeader(hsmConfigModel.getHeader());
        configCache.setHsmServices(hsmConfigModel.getHsmServices());
        configCache.setNettyConfig(hsmConfigModel.getNettyConfig());
        return configCache;
	}

    private void initCamelContext() {
        CamelContext camelContext = new DefaultCamelContext();
        dstmProducer.initializeProducerTemplate(camelContext);
        camelContext.start();
    }

    @Override
    public HsmVendor getHsmVendorByEntityId(String entityId) {
        return HSM_VENDOR_MAP.get(entityId);
    }

}
