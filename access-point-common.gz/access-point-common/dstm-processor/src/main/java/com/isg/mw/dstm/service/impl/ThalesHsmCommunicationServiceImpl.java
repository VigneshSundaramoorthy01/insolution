package com.isg.mw.dstm.service.impl;

import com.isg.mw.dstm.cache.HsmConfigCache;
import com.isg.mw.dstm.configs.DstmNettyConfig;
import com.isg.mw.dstm.configs.DstmProducer;
import com.isg.mw.dstm.service.HsmCommunicationService;
import com.isg.mw.dstm.utils.HsmCommandUtility;

import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component("thales")
@PropertySource("${spring.config.location}routing-config.properties")
public class ThalesHsmCommunicationServiceImpl implements HsmCommunicationService {

    private static final Logger logger = LogManager.getLogger(ThalesHsmCommunicationServiceImpl.class);

    @Autowired
    private DstmProducer dstmProducer;
    
    @Value("${hsm.utility.host}")
    private String hsmUtilityHost;
    
    @Value("${hsm.utility.port}")
    private String hsmUtilityPort;

    @Override
    public String hsmConnectAndSendCommand(HsmConfigCache model, String hsmCommand) {
    	String commandResponse = "";

    	Object res = null;
    	NettyEndpoint producerEndpoint = DstmNettyConfig.getProducerEndpoint(dstmProducer.getProducerTemplate().getCamelContext(), model);
    	res = dstmProducer.sendMessage(requestProcess(model, hsmCommand.toUpperCase()), "dummy", producerEndpoint, model);
    	if (res != null) {
    		byte[] hsmResponse = (byte[]) res;

    		String hexBinary = HsmCommandUtility.printHexBinary(hsmResponse);

    		logger.debug("Response from HSM in HexBinary : {} ", hexBinary.substring(0, 20));

    		int responseLength = Integer.parseInt(hexBinary.substring(0, 4), 16);
    		logger.debug("Response length in decimal : {} ", responseLength);

    		byte[] response = new byte[responseLength];
    		// Read the response from hsm
    		System.arraycopy(hsmResponse, 2, response, 0, responseLength);
    		commandResponse = new String(response);
    		logger.debug("Response in ASCII: {}", commandResponse.substring(0, 8));
    	}

    	return commandResponse;
    }

    
    @Override
    public String hsmConnectAndSendCommandAmex(HsmConfigCache model, String hsmCommand) {
        String commandResponse = "";
        logger.info("Calling HSM Utility.. ");
        Object res = null;
        NettyEndpoint producerEndpoint = DstmNettyConfig.getHsmUtilityProducerEndpoint(dstmProducer.getProducerTemplate().getCamelContext(), model, hsmUtilityHost, hsmUtilityPort);
        
        res = dstmProducer.sendMessage(requestProcess(model, hsmCommand.toUpperCase()), "dummy", producerEndpoint, model);
        if (res != null) {
            byte[] hsmResponse = (byte[]) res;

            String hexBinary = HsmCommandUtility.printHexBinary(hsmResponse);

            logger.debug("Response from HSM in HexBinary : {} ", hexBinary.substring(0, 20));

            int responseLength = Integer.parseInt(hexBinary.substring(0, 4), 16);
            logger.debug("Response length in decimal : {} ", responseLength);

            byte[] response = new byte[responseLength];
            // Read the response from hsm
            System.arraycopy(hsmResponse, 2, response, 0, responseLength);
            commandResponse = new String(response);
            logger.debug("Response in ASCII: {}", commandResponse.substring(0, 8));
        }

        return commandResponse;
    }
    
    private static String hexToAscii(String hexStr) {
        StringBuilder output = new StringBuilder("");

        for (int i = 0; i < hexStr.length(); i += 2) {
            String str = hexStr.substring(i, i + 2);
            output.append((char) Integer.parseInt(str, 16));
        }

        return output.toString();
    }

    private byte[] requestProcess(HsmConfigCache model, String hsmCommand) {
        // Request processing
        // Convert the header in byte array
        String headerHex = getHex(model.getHeader());

        String commandHex = getHex(hsmCommand);
        

        int length = (headerHex + commandHex).length() / 2;
        String lengthHex = StringUtils.leftPad(Integer.toHexString(length), 4, '0');

        byte[] requestLengthByte = toBytesAsIs(StringUtils.leftPad(lengthHex, 4, '0'));

        byte[] headerbytes = HsmCommandUtility.parseHexBinary(headerHex);
        // length of header = header(5) length byte + request length byte
        int headerLength = headerbytes.length;

        // Convert the request in byte array
       
        byte[] commandbytes = HsmCommandUtility.parseHexBinary(commandHex);

        byte[] request = new byte[requestLengthByte.length + headerLength + commandbytes.length];

        System.arraycopy(requestLengthByte, 0, request, 0, requestLengthByte.length);

        // Copy the header to request byte array
        System.arraycopy(headerbytes, 0, request, requestLengthByte.length, headerbytes.length);

        // Copy the command after length of request
        System.arraycopy(commandbytes, 0, request, requestLengthByte.length + headerLength,
                commandbytes.length);
        
        return request;
    }

    public static byte[] toBytesAsIs(String str) {
        char[] charArray = str.toCharArray();
        byte[] asIsBytes = new byte[charArray.length / 2];
        int j = 0;
        for (int i = 0; i < charArray.length; i++) {
            byte charHex = twoDigitsHexToDecimal(charArray[i++], charArray[i]);
            asIsBytes[j] = charHex;
            j++;
        }
        return asIsBytes;
    }


    public static byte twoDigitsHexToDecimal(char c1, char c2) {
        byte ch = 0;

        ch = (byte) (ch | oneDigitHexToDec(c1));
        ch = (byte) (ch << 4);

        if (c2 != 'Z') {
            ch = (byte) (ch | oneDigitHexToDec(c2));
        }

        return ch;
    }

    public static int oneDigitHexToDec(char c) {
        int b = 0;
        switch (c) {
            case 'A':
                b = 10;
                break;
            case 'B':
                b = 11;
                break;
            case 'C':
                b = 12;
                break;
            case 'D':
                b = 13;
                break;
            case 'E':
                b = 14;
                break;
            case 'F':
                b = 15;
                break;
            case 'a':
                b = 10;
                break;
            case 'b':
                b = 11;
                break;
            case 'c':
                b = 12;
                break;
            case 'd':
                b = 13;
                break;
            case 'e':
                b = 14;
                break;
            case 'f':
                b = 15;
                break;
            default:
                b = c - '0';
                if (b < 0 || b > 10) {
                    logger.error("Invalid digit in raw message, can't convert to decimal");
                }
        }
        return b;
    }

    public String getHex(String ascii) {
        StringBuilder builder = new StringBuilder();
        for (char c : ascii.toCharArray()) {
            builder.append(String.format("%H", c));
        }
        return builder.toString();
    }
}
