package com.isg.mw.dstm.service;

import java.util.List;

import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.cache.HsmConfigCache;

/**
 * Hsm common services
 *
 * @author sudharshan
 */
public interface HsmCommonService {

    /**
     * initialize the HSM with list of configs
     *
     * @param dstms - List of HSM Configuration models
     */
    void init(List<HsmConfigModel> dstms);

    /**
     * convert the hsmconig model to cache and push to map
     *
     * @param model
     */
    void updateHsmConfigInCache(HsmConfigModel model);

    /**
     * Get hsm config based on hsmName
     *
     * @param entityId
     * @param sourceOwnerName
     * @param manufacture
     * @return HsmConfigCache
     */

    HsmConfigCache getHsmConfigByEntityAndOwner(String entityId, String sourceOwnerName, String manufacture);


    /**
     * @param entityId
     * @return VendorName
     */
    HsmVendor getHsmVendorByEntityId(String entityId);
}
