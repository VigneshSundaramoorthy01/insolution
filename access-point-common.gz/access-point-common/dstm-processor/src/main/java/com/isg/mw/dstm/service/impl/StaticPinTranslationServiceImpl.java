package com.isg.mw.dstm.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.HsmCommand;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.dstm.Awks;
import com.isg.mw.core.model.dstm.HsmServices;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.utils.ValidationUtility;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.dstm.cache.HsmConfigCache;
import com.isg.mw.dstm.constants.HsmConstants;
import com.isg.mw.dstm.constants.HsmServiceMsgKeys;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.dstm.service.HsmCommunicationService;
import com.isg.mw.dstm.service.IPinTranslationService;
import com.isg.mw.dstm.utils.HsmCommandUtility;

@Service
public class StaticPinTranslationServiceImpl implements IPinTranslationService {

    private final Logger logger = LogManager.getLogger(getClass());

    @Autowired
    private HsmCommonService hsmCommonService;

    @Autowired
    @Qualifier("safenet")
    private HsmCommunicationService hsmCommunicationService;

    @Override
    public String pinTranslation(String entityId, String sourceOwnerName, String targetOwnerName, String ksn,
                                 String pinblock, String pan, String dynamicKey, String bdkKey) {
        logger.debug(
                LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
                        ": pin translation for source:{}, target:{}, ksn:{}, pinblock:{}, pan:{}"),
                sourceOwnerName, targetOwnerName, ksn, StringUtils.isEmpty(pinblock) ? null : "PRESENT", StringUtils.isEmpty(pan) ? null : "PRESENT");
        String response = null;
        HsmServices services = null;
        try {
            ValidationUtility.validateInput(entityId, HsmServiceMsgKeys.ENTITYID_IS_INVALID);
            ValidationUtility.validateInput(sourceOwnerName, HsmServiceMsgKeys.SOURCE_IS_INVALID);
            ValidationUtility.validateInput(targetOwnerName, HsmServiceMsgKeys.TARGET_IS_INVALID);
            ValidationUtility.validateInput(ksn, HsmServiceMsgKeys.KSN_IS_INVALID);
            ValidationUtility.validateInput(pinblock, HsmServiceMsgKeys.PINBLOCK_IS_INVALID);
            ValidationUtility.validateInput(pan, HsmServiceMsgKeys.PAN_IS_INVALID);
            HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.SAFENET.name());
            if (model != null) {
                Map<String, String> commandArg = new HashMap<>();
                commandArg.put(HsmCommandArg.Ksn.name(),
                        HsmCommandUtility.leftPad(ksn, HsmConstants.KSN_LENGTH, HsmConstants.KSN_PADDING));
                commandArg.put(HsmCommandArg.Bdk.name(), model.getBdk());
                commandArg.put(HsmCommandArg.Pinblock.name(), pinblock);
                commandArg.put(HsmCommandArg.Pan.name(), pan.substring(pan.length() - 13, pan.length() - 1));
                commandArg.put(HsmCommandArg.Awk.name(), getAwk(targetOwnerName, model));
                services = getHsmServices(model.getHsmServices(), HsmCommand.PinTranslation);
                if (services != null && services.getCommandValue() != null) {
//					model.setCommand(HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg));
                    String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
                    response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
                    logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
                            ": pin translation response: {}"), response);
                    response = parsePinTranslationResponse(services, response);
                    logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
                            ": pin translation response after parsing: {}"), StringUtils.isEmpty(response) ? null : "PRESENT");
                } else {
                    logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_COMMAND_NOT_FOUND, entityId));
                }
            } else {
                logger.error("HSM configuration not found for entity: {}", entityId);
            }
        } catch (ValidationException e) {
            logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.VALIDATION_EXCEPTION_MSG), e);
        } catch (Exception e) {
            logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.EXCEPTION_MSG), e);
        }
        return response;
    }

    private String parsePinTranslationResponse(HsmServices services, String response) {
        if (services != null && services.getResponseCodeIndex() != 0) {
            String responseCode = response.substring(services.getResponseCodeIndex(),
                    services.getResponseCodeIndex() + HsmConstants.RESPONSE_CODE_LENGTH);
            logger.debug("Response Code : {}", response);
            if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
                return response.substring(services.getResponseIndex(), response.length());
            }
        } else {
            String responseCode = response.substring(HsmConstants.PIN_TRANSLATION_RES_CODE_INDEX,
                    HsmConstants.PIN_TRANSLATION_RES_CODE_INDEX + HsmConstants.RESPONSE_CODE_LENGTH);
            logger.debug("Response Code : {}", response);
            if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
                return response.substring(HsmConstants.PIN_TRANSLATION_RES_INDEX, response.length());
            }
        }
        return null;
    }

    private String getAwk(String targetOwnerName, HsmConfigCache model) {
        Awks[] awksList = model.getAwks();
        for (Awks awks : awksList) {
            if (awks.getOwnerName().equalsIgnoreCase(targetOwnerName)) {
                return awks.getAwk();
            }
        }
        return null;
    }


    private HsmServices getHsmServices(HsmServices[] serviceList, HsmCommand hsmCommand) {
        for (HsmServices services : serviceList) {
            if (services.getCommand().equals(hsmCommand)) {
                return services;
            }
        }
        return null;
    }

    @Override
    public PinTranslationType getPinTranslationType() {
        return PinTranslationType.STATIC;
    }

    @Override
    public HsmVendor getHsmVendorType() {
        return HsmVendor.SAFENET;
    }

    @Override
    public String pinTranslationAmex(String entityId, String sourceOwnerName, String targetOwnerName, String ksn, String pinblock, String pan, String dynamicKey, String bdkKey) {
        return null;
    }

}
