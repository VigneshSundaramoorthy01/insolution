package com.isg.mw.dstm.service;

import com.isg.mw.dstm.cache.HsmConfigCache;

/**
 * Connect the hsm with configuration, passing the command and get response.
 * 
 * @author sudharshan
 */
public interface HsmCommunicationService {

	String hsmConnectAndSendCommand(HsmConfigCache model, String hsmCommand);
	
	String hsmConnectAndSendCommandAmex(HsmConfigCache model, String hsmCommand);

}
