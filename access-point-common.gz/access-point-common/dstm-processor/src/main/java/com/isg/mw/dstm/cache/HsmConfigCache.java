package com.isg.mw.dstm.cache;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.HsmType;
import com.isg.mw.core.model.constants.Offset;
import com.isg.mw.core.model.constants.ProtocolType;
import com.isg.mw.core.model.dstm.Awks;
import com.isg.mw.core.model.dstm.HsmServices;
import com.isg.mw.core.model.dstm.Zmk;
import com.isg.mw.core.model.dstm.Zak;


import lombok.Data;

@Data
public class HsmConfigCache {

	private String entityId;
	private String name;
	private String manufacture;
	private String model;
	private ProtocolType protocol;
	private String ip;
	private Integer port;
	private HsmType type;
	private Offset offsetType;
	private String header;
	private String sourceOwnerName;
	private String bdk;
	private String ipek;
	private Awks[] awks;
	private HsmServices[] hsmServices;
	private String command;
	private Zmk[] zmks;
	private NettyConfig nettyConfig;
	private Zak[] zaks;
}
