package com.isg.mw.dstm.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.isg.mw.core.model.dstm.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.isg.mw.core.model.constants.HsmCommand;
import com.isg.mw.core.model.constants.HsmCommandArg;
import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.utils.ValidationUtility;
import com.isg.mw.core.utils.LogUtils;
import com.isg.mw.core.utils.PropertyUtils;
import com.isg.mw.dstm.cache.HsmConfigCache;
import com.isg.mw.dstm.constants.HsmConstants;
import com.isg.mw.dstm.constants.HsmServiceMsgKeys;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.dstm.service.HsmCommunicationService;
import com.isg.mw.dstm.service.HsmProcessorService;
import com.isg.mw.dstm.utils.HsmCommandUtility;

/**
 * HSM command processing with configuration
 *
 * @author sudharshan
 */
@Service
public class HsmProcessorServiceImpl implements HsmProcessorService {

	private final Logger logger = LogManager.getLogger(getClass());

	@Autowired
	private HsmCommonService hsmCommonService;

	@Autowired
	@Qualifier("safenet")
	private HsmCommunicationService hsmCommunicationService;

	@Override
	public String decrypt(String entityId, String sourceOwnerName, String ipekKey, String ksn, String encryptData) {
		logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
				": decrypting for ksn: {}, encryptData: {}"), ksn, encryptData);
		String response = null;
		HsmServices services = null;
		try {
			ValidationUtility.validateInput(entityId, HsmServiceMsgKeys.ENTITYID_IS_INVALID);
			ValidationUtility.validateInput(sourceOwnerName, HsmServiceMsgKeys.SOURCE_IS_INVALID);
			ValidationUtility.validateInput(ksn, HsmServiceMsgKeys.KSN_IS_INVALID);
			ValidationUtility.validateInput(encryptData, HsmServiceMsgKeys.ENCDATA_IS_INVALID);
			HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.SAFENET.name());
			if (model != null) {
				Map<String, String> commandArg = new HashMap<>();
				commandArg.put(HsmCommandArg.Ksn.name(),
						HsmCommandUtility.leftPad(ksn, HsmConstants.KSN_LENGTH, HsmConstants.KSN_PADDING));
				commandArg.put(HsmCommandArg.Bdk.name(), model.getBdk());
				commandArg.put(HsmCommandArg.EncrptData.name(), encryptData);
				commandArg.put(HsmCommandArg.Length.name(), HsmCommandUtility.toHexDecimal(encryptData.length() / 2));
				services = getHsmServices(model.getHsmServices(), HsmCommand.Decryption);
				if (services != null && services.getCommandValue() != null) {
					//model.setCommand(HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg));
					String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
					response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
					logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
							": decrypting data response: {}"), response.substring(0, 8));
					response = HsmCommandUtility.hexToString(parseDecryptResponse(services, response));
					response = response.replaceFirst("^0+(?!$)", "");
				} else {
					logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_COMMAND_NOT_FOUND, entityId));
				}
			} else {
				logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_CONFIG_NOT_FOUND, entityId));
			}
		} catch (ValidationException e) {
			logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.VALIDATION_EXCEPTION_MSG), e);
		} catch (Exception e) {
			logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.EXCEPTION_MSG), e);
		}
		return response;
	}
	@Override
	public String generateMac128ForEFTPOS(String entityId, String sourceOwnerName, EftposMacFields macFields, String targetOwnerName, String zakUnderLMK) {
		String response = null;
		HsmServices services = null;

		if (macFields != null) {
			StringBuilder macData = new StringBuilder();
			macData.append(macFields.getMsgType());
			macData.append(macFields.getBitmap());
//            macData.append(macFields.getPan());
//            macData.append(macFields.getProcessingCode());
//            macData.append(macFields.getTxnAmt());
			macData.append(macFields.getTransmissionTime());
			macData.append(macFields.getStan());
//            macData.append(macFields.getLocalTxnTime());
//            macData.append(macFields.getLocalTxnDate());
//            macData.append(macFields.getExpDate());
			macData.append(macFields.getSettlementDate());
//            macData.append(macFields.getMerchantType());
//            macData.append(macFields.getPosEntryMode());
//            macData.append(macFields.getCardSeqNo());
//            macData.append(macFields.getPosConditionCode());
			macData.append(macFields.getAcquirerCode());
			macData.append(macFields.getResCode());
//            macData.append(macFields.getTrack2Data());
//            macData.append(macFields.getRrn());
//            macData.append(macFields.getAuthIdRes());
//            macData.append(macFields.getTid());
//            macData.append(macFields.getMid());
//            macData.append(macFields.getCardAcepterInfo());
//            macData.append(macFields.getNationalData());
//            macData.append(macFields.getPrivateData());
//            macData.append(macFields.getPinData());
			macData.append(macFields.getSecurityControlInfo());
//            macData.append(macFields.getAdditionalAmount());
//            macData.append(macFields.getIccData());
//            macData.append(macFields.getReserved57());
//            macData.append(macFields.getOriginalDataElements());
			macData.append(macFields.getSettlementCode());
			macData.append(macFields.getNoOfCredits());
			macData.append(macFields.getCreditsReversalNo());
			macData.append(macFields.getNoOfDebits());
			macData.append(macFields.getCreditsTxnFee());
			macData.append(macFields.getDebitsTxnFee());
			macData.append(macFields.getDebitsReversalNo());
			macData.append(macFields.getNoOfInquiries());
			macData.append(macFields.getNoOfAuths());
			macData.append(macFields.getTotalCredits());
			macData.append(macFields.getCreditsReversal());
			macData.append(macFields.getTotalDebits());
			macData.append(macFields.getDebitsReversal());
			macData.append(macFields.getNetSettlement());
			macData.append(macFields.getSettlementIdCode());
			macData.append(macFields.getReserved118());
			macData.append(macFields.getReserved119());
			HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.THALES.name());
			logger.trace("HSM Config Model : {}", model);
			if (model != null) {
				logger.trace("model:{}", model);
				Map<String, String> commandArg = new HashMap<>();
				commandArg.put(HsmCommandArg.KeKey.name(),zakUnderLMK);
				commandArg.put(HsmCommandArg.Length.name(), StringUtils.leftPad(HsmCommandUtility.toHexDecimal(macData.toString().length()/2), 4, "0"));
				commandArg.put(HsmCommandArg.MacData.name(), macData.toString());
				services = getHsmServices(model.getHsmServices(), HsmCommand.MacGenerationForEftpos);
				logger.trace("HSM Service : {}", services);
				if (services != null && services.getCommandValue() != null) {
					String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
					response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);

					logger.info("generateMacForEFTPOSCommand==>{}, Response {}",hsmCommand,response);

					logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
							": mac data response: {}"), response);
				}
			}
		}

		return response;
	}
	@Override
	public String pinTranslation(String entityId, String sourceOwnerName, String targetOwnerName, String ksn,
			String pinblock, String pan) {
		logger.debug(
				LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
						": pin translation for source:{}, target:{}, ksn:{}, pinblock:{}, pan:{}"),
				sourceOwnerName, targetOwnerName, ksn, StringUtils.isEmpty(pinblock) ? null : "PRESENT", StringUtils.isEmpty(pan) ? null : "PRESENT");
		String response = null;
		HsmServices services = null;
		try {
			ValidationUtility.validateInput(entityId, HsmServiceMsgKeys.ENTITYID_IS_INVALID);
			ValidationUtility.validateInput(sourceOwnerName, HsmServiceMsgKeys.SOURCE_IS_INVALID);
			ValidationUtility.validateInput(targetOwnerName, HsmServiceMsgKeys.TARGET_IS_INVALID);
			ValidationUtility.validateInput(ksn, HsmServiceMsgKeys.KSN_IS_INVALID);
			ValidationUtility.validateInput(pinblock, HsmServiceMsgKeys.PINBLOCK_IS_INVALID);
			ValidationUtility.validateInput(pan, HsmServiceMsgKeys.PAN_IS_INVALID);
			HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.SAFENET.name());
			if (model != null) {
				Map<String, String> commandArg = new HashMap<>();
				commandArg.put(HsmCommandArg.Ksn.name(),
						HsmCommandUtility.leftPad(ksn, HsmConstants.KSN_LENGTH, HsmConstants.KSN_PADDING));
				commandArg.put(HsmCommandArg.Bdk.name(), model.getBdk());
				commandArg.put(HsmCommandArg.Pinblock.name(), pinblock);
				commandArg.put(HsmCommandArg.Pan.name(), pan.substring(pan.length() - 13, pan.length() - 1));
				commandArg.put(HsmCommandArg.Awk.name(), getAwk(targetOwnerName, model));
				services = getHsmServices(model.getHsmServices(), HsmCommand.PinTranslation);
				if (services != null && services.getCommandValue() != null) {
					//					model.setCommand(HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg));
					String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
					response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
					logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
							": pin translation response: {}"), response);
					response = parsePinTranslationResponse(services, response);
					logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
							": pin translation response after parsing: {}"), StringUtils.isEmpty(response) ? null : "PRESENT");
				} else {
					logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_COMMAND_NOT_FOUND, entityId));
				}
			} else {
				logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_CONFIG_NOT_FOUND, entityId));
			}
		} catch (ValidationException e) {
			logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.VALIDATION_EXCEPTION_MSG), e);
		} catch (Exception e) {
			logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.EXCEPTION_MSG), e);
		}
		return response;
	}

	@Override
	public String keyGenerator(String entityId, String sourceOwnerName, String ksn) {
		logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null, ": keyGenerator using ksn: {}"),
				ksn);
		final int kcvLength = 6;
		String response = null;
		HsmServices services = null;
		try {
			ValidationUtility.validateInput(entityId, HsmServiceMsgKeys.ENTITYID_IS_INVALID);
			ValidationUtility.validateInput(sourceOwnerName, HsmServiceMsgKeys.SOURCE_IS_INVALID);
			ValidationUtility.validateInput(ksn, HsmServiceMsgKeys.KSN_IS_INVALID);
			HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.SAFENET.name());
			if (model != null) {
				Map<String, String> commandArg = new HashMap<>();
				commandArg.put(HsmCommandArg.Ksn.name(),
						HsmCommandUtility.leftPad(ksn, HsmConstants.KSN_LENGTH, HsmConstants.KSN_PADDING));
				commandArg.put(HsmCommandArg.Bdk.name(), model.getBdk());
				commandArg.put(HsmCommandArg.Ipek.name(), model.getIpek());
				services = getHsmServices(model.getHsmServices(), HsmCommand.KeyGeneration);
				if (services != null && services.getCommandValue() != null) {
					//					model.setCommand(HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg));
					String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
					response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
					logger.debug("HSM Key generator response: {}", response);
					String kcv = getKcv(response, kcvLength);
					response = parseKeyGeneratorResponse(services, response);
					response = response + kcv;
					logger.trace("Parse key generator response: {}", response);
				} else {
					logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_COMMAND_NOT_FOUND, entityId));
				}
			} else {
				logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.HSM_CONFIG_NOT_FOUND, entityId));
			}
		} catch (ValidationException e) {
			logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.VALIDATION_EXCEPTION_MSG), e);
		} catch (Exception e) {
			logger.error(PropertyUtils.getMessage(HsmServiceMsgKeys.EXCEPTION_MSG), e);
		}
		return response;
	}

	private String getKcv(String response, final int kcvLength) {
		return response.substring(response.length() - kcvLength, response.length());
	}

	private String parseDecryptResponse(HsmServices services, String response) {
		if (services != null && services.getResponseCodeIndex() != 0) {
			String responseCode = response.substring(services.getResponseCodeIndex(),
					services.getResponseCodeIndex() + HsmConstants.RESPONSE_CODE_LENGTH);
			logger.debug("Response Code : {}", response.substring(0, 8));
			if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
				return response.substring(services.getResponseIndex(), response.length());
			}
		} else {
			String responseCode = response.substring(HsmConstants.DECRYPT_RES_CODE_INDEX,
					HsmConstants.DECRYPT_RES_CODE_INDEX + HsmConstants.RESPONSE_CODE_LENGTH);
			logger.debug("Response Code : {}", response.substring(0, 8));
			if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
				return response.substring(HsmConstants.DECRYPT_RES_INDEX, response.length());
			}
		}
		return null;
	}

	private String parsePinTranslationResponse(HsmServices services, String response) {
		if (services != null && services.getResponseCodeIndex() != 0) {
			String responseCode = response.substring(services.getResponseCodeIndex(),
					services.getResponseCodeIndex() + HsmConstants.RESPONSE_CODE_LENGTH);
			logger.debug("Response Code : {}", response);
			if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
				return response.substring(services.getResponseIndex(), response.length());
			}
		} else {
			String responseCode = response.substring(HsmConstants.PIN_TRANSLATION_RES_CODE_INDEX,
					HsmConstants.PIN_TRANSLATION_RES_CODE_INDEX + HsmConstants.RESPONSE_CODE_LENGTH);
			logger.debug("Response Code : {}", response);
			if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
				return response.substring(HsmConstants.PIN_TRANSLATION_RES_INDEX, response.length());
			}
		}
		return null;
	}

	private String parseKeyGeneratorResponse(HsmServices services, String response) {
		if (services != null && services.getResponseCodeIndex() != 0) {
			String responseCode = response.substring(services.getResponseCodeIndex(),
					services.getResponseCodeIndex() + HsmConstants.RESPONSE_CODE_LENGTH);
			logger.debug("Response Code : {}", responseCode);
			if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
				return response.substring(services.getResponseIndex(), response.length() - 6);
			}
		} else {
			String responseCode = response.substring(HsmConstants.IPEK_GENERATOR_RES_CODE_INDEX,
					HsmConstants.IPEK_GENERATOR_RES_CODE_INDEX + HsmConstants.RESPONSE_CODE_LENGTH);
			logger.debug("Response Code : {}", response);
			if (responseCode != null && responseCode.equalsIgnoreCase(HsmConstants.SUCCESS_RESPONSE)) {
				return response.substring(HsmConstants.IPEK_GENERATOR_RES_INDEX, response.length() - 6);
			}
		}
		return null;
	}

	private String getAwk(String targetOwnerName, HsmConfigCache model) {
		Awks[] awksList = model.getAwks();
		for (Awks awks : awksList) {
			if (awks.getOwnerName().equalsIgnoreCase(targetOwnerName)) {
				return awks.getAwk();
			}
		}
		return null;
	}

	private HsmServices getHsmServices(HsmServices[] serviceList, HsmCommand hsmCommand) {
		for (HsmServices services : serviceList) {
			if (services.getCommand().equals(hsmCommand)) {
				return services;
			}
		}
		return null;
	}


	private String getZak(String targetOwnerName, HsmConfigCache model) {
		Zak[] zaksList = model.getZaks();
		for (Zak zaks : zaksList) {
			if (zaks.getOwnerName().equalsIgnoreCase(targetOwnerName)) {
				return zaks.getZak();
			}
		}
		return null;
	}

	@Override
	public String generateMac(String entityId, String sourceOwnerName, MacFields macFields, String targetOwnerName) {
		String response = null;
		HsmServices services = null;
		if (macFields != null) {
			StringBuilder macData= new StringBuilder();
			macData.append(macFields.getMsgType());
			macData.append(macFields.getPan());
			macData.append(macFields.getMsgTypeId());
			macData.append(macFields.getTxnAmt());
			macData.append(macFields.getStan());
			macData.append(macFields.getLocalTxnTime());
			macData.append(macFields.getRrn());
			if(macFields.getAuthCode()!=null)
			{
				macData.append(macFields.getAuthCode());
			}
			if(macFields.getResCode()!=null){
				macData.append(macFields.getResCode());
			}
			HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.SAFENET.name());
			if (model != null) {
				logger.trace("model:{}",model);
				Map<String, String> commandArg = new HashMap<>();
				commandArg.put(HsmCommandArg.Zak.name(), getZak(targetOwnerName, model));
				commandArg.put(HsmCommandArg.MacData.name(),HsmCommandUtility.convertStringToHex(macData.toString()));
				commandArg.put(HsmCommandArg.Length.name(), HsmCommandUtility.toHexDecimal(HsmCommandUtility.convertStringToHex(macData.toString()).length() / 2));
				services = getHsmServices(model.getHsmServices(), HsmCommand.MacGeneration);
				if (services != null && services.getCommandValue() != null) {
					//					model.setCommand(HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg));
					String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
					response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
					logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
							": mac data response: {}"), response);
				}
			}
		}

		return response;
	}

	// For Eftpos
	@Override
	public String randamKeyGeneration(String entityId, String sourceOwnerName, String requestType, String DataElement48) {
		String response = null;
		HsmServices services = null;

		HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId,"EftPos", HsmVendor.THALES.name());
		logger.trace("HSM Config Model : {}", model);

		if (model != null) {
			logger.trace("model:{}", model);

			Map<String, String> commandArg = new HashMap<>();
			if("0800".equalsIgnoreCase(requestType)) {
				commandArg.put("commandCode", "E0");
				commandArg.put(HsmCommandArg.KeKey.name(),getKeks(sourceOwnerName, model));
				commandArg.put("KREncryptedByKEK", "");
			}
			services = getHsmServices(model.getHsmServices(), HsmCommand.RandomNumberGeneration);
			logger.trace("HSM Service : {}", services);
			if (services != null && services.getCommandValue() != null) {
				String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
				response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
				logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,": randam key generation data response: {}"), response);
			}
		}
		return response;
	}

	@Override
	public String validateRandamKeyGeneration(String entityId, String sourceOwnerName, String requestType, String DataElement48) {
		String response = null;
		HsmServices services = null;

		HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId,"EftPos", HsmVendor.THALES.name());
		logger.trace("HSM Config Model : {}", model);

		if (model != null) {
			logger.trace("model:{}", model);

			Map<String, String> commandArg = new HashMap<>();
			if ("0800".equalsIgnoreCase(requestType)) {
				commandArg.put("commandCode", "E2");
				commandArg.put(HsmCommandArg.KeKey.name(), getKekr(sourceOwnerName, model));
				commandArg.put("KREncryptedByKEK", DataElement48.toUpperCase());
			}
			services = getHsmServices(model.getHsmServices(), HsmCommand.RandomNumberGeneration);
			logger.trace("HSM Service : {}", services);
			if (services != null && services.getCommandValue() != null) {
				String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
				response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
				logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,": Validate randam key generation data response: {}"), response);
			}
		}
		return response;
	}

	@Override
	public String generateZPKAndZaK(String entityId, String sourceOwnerName, String requestType, String DataElement48) {
		String response = null;
		HsmServices services = null;

		HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, "EftPos", HsmVendor.THALES.name());
		logger.trace("HSM Config Model : {}", model);
		if (model != null) {
			logger.trace("model:{}", model);
			Map<String, String> commandArg = new HashMap<>();
			if("0820".equalsIgnoreCase(requestType)) {
				commandArg.put("commandCode", "OI");
				commandArg.put(HsmCommandArg.KeKey.name(),getKeks(sourceOwnerName, model));
				commandArg.put("KREncryptedByKEK", "");
				services = getHsmServices(model.getHsmServices(), HsmCommand.GenerateZPKAndZaKs);
			}
			if (services != null && services.getCommandValue() != null) {
				String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
				response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
				logger.trace("HSM Service : {}, HSM  ZPK and ZAK Generate Command : {}, Response Data : {}", services, commandArg, response);
				logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,": generateZPKAndZaKs Key data response: {}"), response);
			}
		}
		return response;
	}

	@Override
	public String validateZPKAndZaK(String entityId, String sourceOwnerName, String requestType, String DataElement48) {
		String response = null;
		HsmServices services = null;

		HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, "EftPos", HsmVendor.THALES.name());
		logger.trace("HSM Config Model : {}", model);
		if (model != null) {
			logger.trace("model:{}", model);
			Map<String, String> commandArg = new HashMap<>();
			if ("0820".equalsIgnoreCase(requestType)) {
				commandArg.put("commandCode", "OK");
				commandArg.put(HsmCommandArg.KeKey.name(), getKekr(sourceOwnerName, model));
				commandArg.put("ZAKr", DataElement48.substring(32,64).toUpperCase());
				commandArg.put("ZPKr", DataElement48.substring(0,32).toUpperCase());
				services = getHsmServices(model.getHsmServices(), HsmCommand.ValidateZPKAndZaKr);
				logger.trace("HSM Service : {}", services);
			}
			if (services != null && services.getCommandValue() != null) {
				String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
				response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
				logger.trace("HSM Service : {}, HSM Validate ZPK and ZAK Command : {}, Response Data : {}", services, commandArg, response);
				logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,": generateZPKAndZaKs Key data response: {}"), response);
			}
		}
		return response;
	}

    private String getKeks(String targetOwnerName, HsmConfigCache model) {
        Zmk[] zmks = model.getZmks();
        for (Zmk zmk : zmks) {
            if (zmk.getOwnerName().equalsIgnoreCase(targetOwnerName)) {
                return zmk.getKeks();
            }
        }
        return null;
    }

    private String getKekr(String targetOwnerName, HsmConfigCache model) {
        Zmk[] zmks = model.getZmks();
        for (Zmk zmk : zmks) {
            if (zmk.getOwnerName().equalsIgnoreCase(targetOwnerName)) {
                return zmk.getKekr();
            }
        }
        return null;
    }

	@Override
	public String generateMacForEFTPOS(String entityId, String sourceOwnerName, String macData, String targetOwnerName,String zakUnderLMK) {
		String response = null;
		HsmServices services = null;

		HsmConfigCache model = hsmCommonService.getHsmConfigByEntityAndOwner(entityId, sourceOwnerName, HsmVendor.THALES.name());
			logger.trace("HSM Config Model : {}", model);
			if (model != null) {
				logger.trace("model:{}", model);
				Map<String, String> commandArg = new HashMap<>();
				commandArg.put(HsmCommandArg.KeKey.name(),zakUnderLMK);
				commandArg.put(HsmCommandArg.Length.name(), StringUtils.leftPad(HsmCommandUtility.toHexDecimal(macData.length()/2), 4, "0").toUpperCase());
				commandArg.put(HsmCommandArg.MacData.name(), macData);
				services = getHsmServices(model.getHsmServices(), HsmCommand.MacGenerationForEftpos);
				logger.trace("HSM Service : {}", services);
				if (services != null && services.getCommandValue() != null) {
					String hsmCommand = HsmCommandUtility.formatCommand(services.getCommandValue(), commandArg);
					response = hsmCommunicationService.hsmConnectAndSendCommand(model, hsmCommand);
					logger.debug(LogUtils.buildLogMessage(entityId, sourceOwnerName, null, null,
							": mac data response: {}"), response);
				}
			}

		return response;
	}

	@Override
	public HsmVendor getHsmVendorType() {
		return HsmVendor.SAFENET;
	}


}