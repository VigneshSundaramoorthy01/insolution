package com.isg.mw.dstm.constants;

/**
 * HSM command process constants
 * 
 * @author sudharshan
 */
public interface HsmConstants {

	public static final String SUCCESS_RESPONSE = "00";
	public static final int RESPONSE_CODE_LENGTH = 2;
	public static final int KSN_LENGTH = 20;
	public static final char KSN_PADDING = 'F';
	public static final String KEY_SEPERATOR = "::";
	public static final String START_INDEX = "{";
	public static final String END_INDEX = "}";

	// COMMAND(6)
	public static final int IPEK_GENERATOR_RES_CODE_INDEX = 6;
	// COMMAND(6) + RESPONSE(2) + LENGTH_DATA(2) -
	public static final int IPEK_GENERATOR_RES_INDEX = 10;

	// COMMAND(6)
	public static final int PIN_TRANSLATION_RES_CODE_INDEX = 6;
	// COMMAND(6) + RESPONSE(2)
	public static final int PIN_TRANSLATION_RES_INDEX = 8;

	// COMMAND(6)
	public static final int DECRYPT_RES_CODE_INDEX = 6;
	// COMMAND(6) + RESPONSE(2)
	public static final int DECRYPT_RES_INDEX = 26;

	// COMMAND(6)
	public static final int KEY_TRANSLATION_RES_CODE_INDEX = 6;
	// COMMAND(6) + RESPONSE(2)
	public static final int KEY_TRANSLATION_RES_INDEX = 8;


}
