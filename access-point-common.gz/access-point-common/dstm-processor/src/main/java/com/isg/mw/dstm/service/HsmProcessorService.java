package com.isg.mw.dstm.service;

import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.dstm.EftposMacFields;
import com.isg.mw.core.model.dstm.MacFields;

/**
 * Data security translation services
 * 
 * @author sudharshan
 */
public interface HsmProcessorService {

	/**
	 * Decrypt the encrypt data with hsm command
	 * 
	 * @param entityId
	 * @param sourceOwnerName
	 * @param ksn
	 * @param encryptData
	 * @return String
	 */
	String decrypt(String entityId, String sourceOwnerName, String ipekKey, String ksn, String encryptData);

	/**
	 * Pin translation with source and target keys
	 * 
	 * @param entityId
	 * @param sourceOwnerName
	 * @param targetOwnerName
	 * @param ksn
	 * @param pinblock
	 * @param pan
	 * @return String
	 */
	String pinTranslation(String entityId, String sourceOwnerName, String targetOwnerName, String ksn, String pinblock,
			String pan);

	/**
	 * Generate the IPEK for source
	 * 
	 * @param entityId
	 * @param sourceOwnerName
	 * @param manufacture
	 * @param ksn
	 * @return String
	 */
	String keyGenerator(String entityId, String sourceOwnerName, String ksn);

	/**
	 * Generate the mac
	 *
	 * @param entityId
	 * @param sourceOwnerName
	 * @param msgType
	 * @param pan
	 * @param msgTypeId
	 * @param txnAmt
	 * @param stan
	 * @param localTxnTime
	 * @param rrn
	 */

	String generateMac (String entityId, String sourceOwnerName, MacFields macFields, String targetOwnerName);
	
	
	String randamKeyGeneration(String entityId, String sourceOwnerName, String requestType, String dataElement48);

	String validateRandamKeyGeneration(String entityId, String sourceOwnerName, String requestType, String dataElement48);
	
	String generateZPKAndZaK(String entityId, String sourceOwnerName,String requestType, String dataElement48);

	String validateZPKAndZaK(String entityId, String sourceOwnerName,String requestType, String dataElement48);

	String generateMacForEFTPOS(String entityId, String sourceOwnerName, String macFields, String targetOwnerName, String zakUnderLMK);


	String generateMac128ForEFTPOS(String entityId, String sourceOwnerName, EftposMacFields macFields, String targetOwnerName, String zakUnderLMK);


	/**
	 * @return
	 */
	HsmVendor getHsmVendorType();

}
