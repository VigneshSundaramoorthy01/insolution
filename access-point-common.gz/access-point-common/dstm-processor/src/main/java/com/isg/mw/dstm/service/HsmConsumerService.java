package com.isg.mw.dstm.service;

import com.isg.mw.core.model.dstm.HsmConfigModel;

/**
 * Consume the hsm configuration from kafka
 * 
 * @author sudharshan
 */
public interface HsmConsumerService {

	/**
	 * Consume hsm configuration from kafka
	 * 
	 * @param model
	 */
	void updateHsmConfigByUsingKafka(HsmConfigModel model);

	/**
	 * Consume hsm configuration through api
	 * 
	 * @param model
	 */
	void updateHsmConfigByUsingApi(HsmConfigModel model);

}
