package com.isg.mw.dstm.constants;

/**
 * constants to refer keys from message resource bundle
 * 
 * @author sudharshan
 */
public interface HsmServiceMsgKeys {

	static final String ENTITYID_IS_INVALID = "hsm.services.field.entityid.is.invalid";
	static final String SOURCE_IS_INVALID = "hsm.services.field.sourcename.is.invalid";
	static final String TARGET_IS_INVALID = "hsm.services.field.targetname.is.invalid";
	static final String KSN_IS_INVALID = "hsm.services.field.ksn.is.invalid";
	static final String PINBLOCK_IS_INVALID = "hsm.services.field.pinblock.is.invalid";
	static final String PAN_IS_INVALID = "hsm.services.field.pan.is.invalid";
	static final String DYNAMIC_KEY_IS_INVALID = "hsm.services.field.dynamic.key.is.invalid";
	static final String ENCDATA_IS_INVALID = "hsm.services.field.encryptdata.is.invalid";
	static final String EXCEPTION_MSG = "hsm.services.exception.msg";
	static final String VALIDATION_EXCEPTION_MSG = "hsm.services.validation.exception.msg";
	static final String COMMUNICATION_EX_MSG = "hsm.services.communication.exception.msg";
	static final String HSM_CONFIG_NOT_FOUND = "hsm.services.hsmconfig.notfound.msg";
	static final String HSM_COMMAND_NOT_FOUND = "hsm.services.hsmcommand.notfound.msg";
	static final String HSM_KEYS_NOT_FOUND = "hsm.services.hsmkeys.notfound.msg";

}
