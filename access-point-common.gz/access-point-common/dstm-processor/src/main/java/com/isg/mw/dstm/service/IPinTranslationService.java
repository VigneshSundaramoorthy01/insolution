package com.isg.mw.dstm.service;

import com.isg.mw.core.model.constants.HsmVendor;
import com.isg.mw.core.model.constants.PinTranslationType;

/**
 * 
 * @author rahul3983
 *
 */
public interface IPinTranslationService {

	default String keyTranslation(String entityId, String sourceOwnerName, String targetOwnerName, String dynamicKey) {
		return null;
	}

	String pinTranslation(String entityId, String sourceOwnerName, String targetOwnerName, String ksn, String pinblock,
			String pan, String dynamicKey, String bdkKey);

	PinTranslationType getPinTranslationType();

	HsmVendor getHsmVendorType();

	public String pinTranslationAmex(String entityId, String sourceOwnerName, String targetOwnerName, String ksn,
									 String pinblock, String pan, String dynamicKey, String bdkKey) ;
	
	default String keyTranslationAmex(String entityId, String sourceOwnerName, String targetOwnerName, String dynamicKey) {
		return null;
	}
	
	
	default String bdkTranslationAmex(String entityId, String sourceOwnerName, String targetOwnerName, String bdk) {
		return null;
	}
}
