package com.isg.mw.dstm.configs;

import com.isg.mw.dstm.cache.HsmConfigCache;
import lombok.Getter;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.camel.spi.Synchronization;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
public class DstmProducer {

    private Logger logger = LogManager.getLogger(this.getClass());

    @Getter
    private ProducerTemplate producerTemplate;

    /**
     * Returns instance of <code>ProducerTemplate</code>
     *
     * @return
     */
    public ProducerTemplate initializeProducerTemplate(CamelContext camelContext) {
        if (producerTemplate == null) {
            producerTemplate = camelContext.createProducerTemplate();
        }
        return producerTemplate;
    }

    /**
     * Sends a given message to endpoint and on completion a synchronization
     * callback is invoked.
     *
     * @param message       A message to be sent to endpoint.
     * @param correlationId
     * @param model
     */
    public Object sendMessage(Object message, String correlationId, NettyEndpoint nettyEndpoint, HsmConfigCache model) {
        Object resObj = null;
        CompletableFuture<Exchange> response = this.producerTemplate.asyncCallback(nettyEndpoint, exchange -> {
            exchange.getIn().getHeaders().put("correlationId", correlationId);
            exchange.getIn().setBody(message);
            exchange.getIn().getHeaders().put("dstmModel", model);
        }, new Synchronization() {

            @Override
            public void onFailure(Exchange exchange) {
                logger.error("Could not receive response from HSM", exchange.getException());
                throw new RuntimeException("HSM not available");
            }

            @Override
            public void onComplete(Exchange exchange) {
                logger.debug("Message reached to target");
            }
        });

        try {
            resObj = ((Exchange) response.get()).getIn().getBody();
        } catch (InterruptedException | ExecutionException e) {
            logger.error("Error while getting the response from target", e);
            throw new RuntimeException("HSM not available");
        }
        return resObj;
    }
}
