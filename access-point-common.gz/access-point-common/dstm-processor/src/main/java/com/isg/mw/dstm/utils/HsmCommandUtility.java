package com.isg.mw.dstm.utils;

import java.util.Base64;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;

import com.isg.mw.dstm.constants.HsmConstants;

/**
 * This Utility class used for format and parse the hsm commands
 * 
 * @author sudharshan
 */
public class HsmCommandUtility {

	private HsmCommandUtility() {
	}

	public static String leftPad(String str, int size, char padChar) {
		return StringUtils.leftPad(str, size, padChar);
	}

	public static String rightPad(String str, int size, char padChar) {
		return StringUtils.rightPad(str, size, padChar);
	}

	public static String toHexDecimal(int number) {
		return Integer.toHexString(number);
	}

	public static String base64Decoder(String input) {
		return new String(Base64.getDecoder().decode(input));
	}

	public static String base64Encoder(String input) {
		return Base64.getEncoder().encodeToString(input.getBytes());
	}

	public static String printHexBinary(byte[] array) {
		return DatatypeConverter.printHexBinary(array);
	}

	public static byte[] parseHexBinary(String hexString) {
		return DatatypeConverter.parseHexBinary(hexString);
	}

	public static String convertStringToHex(String str) {

		StringBuffer hex = new StringBuffer();

		// loop chars one by one
		for (char temp : str.toCharArray()) {

			// convert char to int, for char `a` decimal 97
			int decimal = (int) temp;

			// convert int to hex, for decimal 97 hex 61
			hex.append(Integer.toHexString(decimal));
		}

		return hex.toString();

	}

	public static String hexToString(String hexString) {
		return hexString != null ? new String(DatatypeConverter.parseHexBinary(hexString)) : "";
	}

	public static byte[] parseBase64Binary(String hexString) {
		return DatatypeConverter.parseBase64Binary(hexString);
	}

	public static String constructKey(String entityId, String sourceOwnerName, String manufacture) {
		return entityId + HsmConstants.KEY_SEPERATOR + sourceOwnerName + HsmConstants.KEY_SEPERATOR + manufacture ;
	}

	public static String formatCommand(String command, Map<String, String> commandArg) {
		for (Map.Entry<String, String> entry : commandArg.entrySet()) {
			command = replaceParam(command, entry.getKey(), entry.getValue().trim());
		}
		return command;
	}

	private static String replaceParam(String command, String param, String paramValue) {
		return command.replace(HsmConstants.START_INDEX + param + HsmConstants.END_INDEX, paramValue);
	}
}
