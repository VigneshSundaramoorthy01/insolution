package com.isg.mw.dstm.service.impl;

import org.apache.camel.component.netty.NettyEndpoint;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.isg.mw.dstm.cache.HsmConfigCache;
import com.isg.mw.dstm.configs.DstmNettyConfig;
import com.isg.mw.dstm.configs.DstmProducer;
import com.isg.mw.dstm.service.HsmCommunicationService;
import com.isg.mw.dstm.utils.HsmCommandUtility;

@Component("safenet")
@PropertySource("${spring.config.location}routing-config.properties")
public class HsmCommunicationServiceImpl implements HsmCommunicationService {

	private static final Logger logger = LogManager.getLogger(HsmCommunicationServiceImpl.class);

	@Autowired
	private DstmProducer dstmProducer;

	@Value("${hsm.utility.host}")
	private String hsmUtilityHost;

	@Value("${hsm.utility.port}")
	private String hsmUtilityPort;

	@Override
	public String hsmConnectAndSendCommand(HsmConfigCache model, String hsmCommand) {
		String commandResponse = "";
		NettyEndpoint producerEndpoint = DstmNettyConfig
				.getProducerEndpoint(dstmProducer.getProducerTemplate().getCamelContext(), model);
		Object res = dstmProducer.sendMessage(requestProcess(model, hsmCommand.toUpperCase()), "dummy", producerEndpoint, model);
		if (res != null) {
			byte[] hsmResponse = (byte[]) res;

			logger.debug("Response from HSM : {} ", HsmCommandUtility.printHexBinary(hsmResponse).substring(0, 20));

			// header length
			int headerLength = model.getHeader().length() / 2;
			byte[] header = new byte[headerLength + 1];
			System.arraycopy(hsmResponse, 0, header, 0, header.length);
			// Read the header from hsm
			logger.debug("Response header : {} ", HsmCommandUtility.printHexBinary(header));
			// Get response length
			int responseLength = (header[headerLength - 1] & 0xFF) * 256 + (header[headerLength] & 0xFF);
			logger.debug("Response length : {} ", responseLength);
			byte[] response = new byte[responseLength];
			// Read the response from hsm
			System.arraycopy(hsmResponse, header.length, response, 0, responseLength);

			logger.debug("Response : {} ", HsmCommandUtility.printHexBinary(response).substring(0, 8));
			commandResponse = HsmCommandUtility.printHexBinary(response);
		}

		return commandResponse;
	}


	@Override
	public String hsmConnectAndSendCommandAmex(HsmConfigCache model, String hsmCommand) {
		String commandResponse = "";
		logger.info("Calling HSM Utility.. ");
		Object res = null;
		NettyEndpoint producerEndpoint = DstmNettyConfig.getHsmUtilityProducerEndpoint(dstmProducer.getProducerTemplate().getCamelContext(), model, hsmUtilityHost, hsmUtilityPort);

		res = dstmProducer.sendMessage(requestProcess(model, hsmCommand.toUpperCase()), "dummy", producerEndpoint, model);
		if (res != null) {
			byte[] hsmResponse = (byte[]) res;

			logger.debug("Response from HSM : {} ", HsmCommandUtility.printHexBinary(hsmResponse).substring(0, 20));

			// header length
			int headerLength = model.getHeader().length() / 2;
			byte[] header = new byte[headerLength + 1];
			System.arraycopy(hsmResponse, 0, header, 0, header.length);
			// Read the header from hsm
			logger.debug("Response header : {} ", HsmCommandUtility.printHexBinary(header));
			// Get response length
			int responseLength = (header[headerLength - 1] & 0xFF) * 256 + (header[headerLength] & 0xFF);
			logger.debug("Response length : {} ", responseLength);
			byte[] response = new byte[responseLength];
			// Read the response from hsm
			System.arraycopy(hsmResponse, header.length, response, 0, responseLength);

			logger.debug("Response : {} ", HsmCommandUtility.printHexBinary(response).substring(0, 8));
			commandResponse = HsmCommandUtility.printHexBinary(response);
		}

		return commandResponse;
	}

	private static byte[] requestProcess(HsmConfigCache model, String hsmCommand) {
		// Request processing
		// Convert the header in byte array
		byte[] headerbytes = HsmCommandUtility.parseHexBinary(model.getHeader());
		// length of header = header(5) length byte + request length byte
		int headerLength = headerbytes.length;
		int lengthByte = 1;
		// Convert the request in byte array
		
		byte[] commandbytes = HsmCommandUtility.parseHexBinary(hsmCommand);

		// define the total request = header + length + request
		byte[] request = new byte[headerLength + lengthByte + commandbytes.length];
		// Copy the header to request byte array
		System.arraycopy(headerbytes, 0, request, 0, headerbytes.length);
		// Set the request length in hex
		request[headerLength] = (byte) (commandbytes.length % 256);
		// Copy the command after length of request
		System.arraycopy(commandbytes, 0, request, headerLength + lengthByte, commandbytes.length);
		
		return request;
	}

}
