package com.isg.mw.dstm.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

import com.isg.kafka.consumer.KafkaConsumer;
import com.isg.mw.core.model.dstm.HsmConfigModel;
import com.isg.mw.dstm.configs.HsmKafkaConfigs;
import com.isg.mw.dstm.service.HsmCommonService;
import com.isg.mw.dstm.service.HsmConsumerService;

@Service("hsmConsumerService")
public class HsmConsumerServiceImpl implements HsmConsumerService, ApplicationRunner {

	private static final Logger LOG = LogManager.getLogger(HsmConsumerServiceImpl.class);

	@Autowired
	private HsmKafkaConfigs hsmKafkaConfigs;

	@Autowired
	private HsmCommonService hsmCommonService;

	@Override
	public void updateHsmConfigByUsingKafka(HsmConfigModel model) {
		hsmCommonService.updateHsmConfigInCache(model);
	}

	@Override
	public void updateHsmConfigByUsingApi(HsmConfigModel model) {
		hsmCommonService.updateHsmConfigInCache(model);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		LOG.info("Kafka Consumer Method Call");
		try {
			KafkaConsumer consumer = new KafkaConsumer(hsmKafkaConfigs.getKafkaConfig(), this.getClass(),
					"updateHsmConfigByUsingKafka");
			consumer.init();
			LOG.info("intialization done");
		} catch (Exception e) {
			LOG.error("Exception While Consumeing: {} ", e);
			throw e;
		}
	}

}
