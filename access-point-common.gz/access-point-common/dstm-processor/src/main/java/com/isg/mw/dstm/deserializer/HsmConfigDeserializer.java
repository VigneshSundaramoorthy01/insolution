package com.isg.mw.dstm.deserializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.isg.mw.core.model.dstm.HsmConfigModel;

public class HsmConfigDeserializer implements Deserializer<HsmConfigModel> {

	private final Logger LOG = LogManager.getLogger(getClass());

	@Override
	public HsmConfigModel deserialize(String topic, byte[] data) {
		HsmConfigModel model = null;
		ByteArrayInputStream bis = new ByteArrayInputStream(data);
		ObjectInputStream ois;
		try {
			ois = new ObjectInputStream(bis);
			model = (HsmConfigModel) ois.readObject();
			ois.close();
		} catch (IOException e) {
			LOG.error("Error while deserializing object: {}", e);
		} catch (ClassNotFoundException e) {
			LOG.error("Class in which the object to be deserialized not found: {}", e);
		}
		return model;
	}

}
