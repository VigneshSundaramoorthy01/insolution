package com.isg.mw.dstm.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.isg.kafka.config.KafkaConfig;
import com.isg.mw.dstm.deserializer.HsmConfigDeserializer;

import lombok.Data;

/**
 * HSM kafka properties
 *
 * @author sudharshan
 */
@Data
@Configuration
@PropertySource(value = "${spring.config.location}kafka-config.properties", ignoreResourceNotFound = true)
public class HsmKafkaConfigs {

    @Value("${kafka.hsm.topic}")
    private String topicName;

    @Value("${kafka.brokers}")
    private String brokers;

    @Value("${kafka.clientid}")
    private String clientId;

    @Value("${kafka.auto.comit.enabled}")
    private boolean autoCommitEnable;

    @Value("${kafka.consumers.count}")
    private int consumersCount;

    @Value("${kafka.use.original.message}")
    private boolean useOriginalMessage;

    @Value("${kafka.max.failed.msg.redeliveries}")
    private int maxFailedMsgRedeliveries;

    @Value("${kafka.max.failed.msg.redelivery.delay}")
    private long maxFailedMsgRedeliveryDelay;

    @Value("${kafka.retries}")
    private int retries;

    @Value("${kafka.request.required.acks}")
    private String requestRequiredAcks;

    @Value("${kafka.record.metadata}")
    private boolean recordMetadata;

    @Value("${kafka.security.enabled:false}")
    private boolean kafkaSecurityEnabled;

    @Value("${kafka.truststore.location:}")
    private String trustStoreLocation;

    @Value("${kafka.truststore.password:}")
    private String trustStorePassword;

    @Value("${kafka.set.protocol:}")
    private String protocol;

    @Value("${kafka.set.sasl.mechanism:}")
    private String saslMechanism;

    @Value("${kafka.truststore.type:}")
    private String trustStoreType;

    @Value("${kafka.jaas.config:}")
    private String saslJaasConfig;
    
    @Value("${kafka.max.poll.records:100}")
    private int maxPollRecords;

    @Value("${kafka.max.poll.interval.ms:300000}")
    private long maxPollIntervalMs;

    public KafkaConfig getKafkaConfig() {
        KafkaConfig kafkaConfig = new KafkaConfig();
        kafkaConfig.setTopicName(topicName);
        kafkaConfig.setBrokers(brokers);
        kafkaConfig.setAutoCommitEnable(autoCommitEnable);
        kafkaConfig.setConsumersCount(consumersCount);
        kafkaConfig.setMaxFailedMsgRedeliveries(maxFailedMsgRedeliveries);
        kafkaConfig.setMaxFailedMsgRedeliveryDelay(maxFailedMsgRedeliveryDelay);
        kafkaConfig.setRetries(retries);
        kafkaConfig.setRequestRequiredAcks(requestRequiredAcks);
        kafkaConfig.setRecordMetadata(recordMetadata);
        kafkaConfig.setValueDeserializer(HsmConfigDeserializer.class);
        kafkaConfig.setMaxPollRecords(maxPollRecords);
        kafkaConfig.setMaxPollIntervalMs(maxPollIntervalMs);

        kafkaConfig.setKafkaSecurityEnabled(kafkaSecurityEnabled);
        kafkaConfig.setTrustStoreLocation(trustStoreLocation);
        kafkaConfig.setTrustStorePassword(trustStorePassword);
        kafkaConfig.setProtocol(protocol);
        kafkaConfig.setSaslMechanism(saslMechanism);
        kafkaConfig.setTrustStoreType(trustStoreType);
        kafkaConfig.setSaslJaasConfig(saslJaasConfig);
        return kafkaConfig;
    }

}
