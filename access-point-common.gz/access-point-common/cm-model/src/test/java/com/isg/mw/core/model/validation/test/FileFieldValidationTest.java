package com.isg.mw.core.model.validation.test;



import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.validation.FileFieldValidation;

public class FileFieldValidationTest {

	@Test
	public void testSample() {
		String data = "Visa";
		String fieldName = "name";

		boolean mandatory = false;
		int length = 30;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			FileFieldValidation.alphaFileValidation(data, fieldName, mandatory, length, 0, 0);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}
	
	@Test
	public void testSample1() {
		String data = "Ganesha soc. Apt-10, Mumbai";
		String fieldName = "address";

		boolean mandatory = true;
		int length = 30;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
		//	FileFieldValidation.ansFileValidation(data, fieldName, mandatory, length, 0, 0);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}

	
	
	
	
}
