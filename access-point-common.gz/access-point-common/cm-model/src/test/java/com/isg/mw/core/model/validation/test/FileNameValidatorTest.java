package com.isg.mw.core.model.validation.test;


import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.validation.FileNameValidator;

/**
 * 
 * @author prasad_t026
 *
 */
public class FileNameValidatorTest {

	@Test
	public void testFileNameValidatorP01() {
		
		String fileName = "BIN_VISA_23052020_0001.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNull(value);
		
	}

	@Test
	public void testFileNameValidatorP02() {
		
		String fileName = "BIN_VISA_02072020_0001.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNull(value);
		
	}

	@Test
	public void testFileNameValidatorP03() {
		
		String fileName = "MERCHANT_ENTITYID123_02072020_0001.csv";
		String type = "MERCHANT";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNull(value);
		
	}

	@Test
	public void testFileNameValidatorN01() {
		
		String fileName = "BIN_VISA_03072025_0001.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN02() {
		
		String fileName = "BINN_VISA_02072020_0001.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN03() {
		
		String fileName = "BIN_MASTER_02072020_0001.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN04() {
		
		String fileName = "BIN_VISA_02072020_001.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN05() {
		
		String fileName = "BIN_VISA_02072020_000a.csv";
		String type = "BIN";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN06() {
		
		String fileName = "MERCHANTA_VISA_02072020_0001.csv";
		String type = "MERCHANT";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN07() {
		
		String fileName = "MERCHANT_VISA_02072020_00001.csv";
		String type = "MERCHANT";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN08() {
		
		String fileName = "MERCHANT_ENTITYIDTOOBIGENTITYIDTOOBIGENTITYIDTOOBIGENTITYIDTOOBIG_02072020_0001.csv";
		String type = "MERCHANT";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN09() {
		
		String fileName = "MERCHANT_ENTITYID_123_02072020_0001.csv";
		String type = "MERCHANT";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testFileNameValidatorN10() {
		
		String fileName = "MERCHANT_ENTITYID123_41072020_0001.csv";
		String type = "MERCHANT";
		String value = FileNameValidator.validateFileName(fileName, type);
		assertNotNull(value);
		
	}

	@Test
	public void testValidateFileDateP01() throws Exception {
		
		String fd = "23052020";
		String fs = "0011";
		String dd = "23052020";
		int ds = 10;
		String value = FileNameValidator.validateFileDate(fd, fs, dd, ds);
		assertNull(value);
		
	}

	@Test
	public void testValidateFileDateP02() throws Exception {
		
		String fd = "24052020";
		String fs = "0009";
		String dd = "23052020";
		int ds = 10;
		String value = FileNameValidator.validateFileDate(fd, fs, dd, ds);
		assertNull(value);
		
	}

	@Test
	public void testValidateFileDateN01() throws Exception {
		
		String fd = "24052020";
		String fs = "0009";
		String dd = "24052020";
		int ds = 10;
		String value = FileNameValidator.validateFileDate(fd, fs, dd, ds);
		assertNotNull(value);
		
	}

	@Test
	public void testValidateFileDateN02() throws Exception {
		
		String fd = "24052020";
		String fs = "0010";
		String dd = "24052020";
		int ds = 10;
		String value = FileNameValidator.validateFileDate(fd, fs, dd, ds);
		assertNotNull(value);
		
	}

	@Test
	public void testValidateFileDateN03() throws Exception {
		
		String fd = "23052020";
		String fs = "0015";
		String dd = "24052020";
		int ds = 10;
		String value = FileNameValidator.validateFileDate(fd, fs, dd, ds);
		assertNotNull(value);
		
	}

}
