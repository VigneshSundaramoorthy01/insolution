package com.isg.mw.core.model.validation.test;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.model.validation.UserDataValidations;

/**
 * 
 * @author prasad_t026
 *
 */
public class UserDataValidationsTest {

	@Test
	public void testSample() {
		String data = "";
		String fieldName = "name";

		String expression = "[a-zA-Z_0-9]*";
		boolean mandatory = false;
		int length = 30;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}

	/**
	 * name expression positive test
	 */
	@Test
	public void testStringDataValidationP01() {

		String data = "";
		String fieldName = "name";

		String expression = "[a-zA-Z_0-9]*";
		boolean mandatory = false;
		int length = 30;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
			data = "sample";
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
			data = "SAMPLE";
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
			data = "Sample";
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
			data = "_Sample_";
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
			data = "_Sample_1234";
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
			data = "_1234";
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	/**
	 * name expression negative test (special characters not allowed)
	 */
//	@Test
	public void testStringDataValidationN01() {

		String data = "1234%";
		String fieldName = "name";
		String expression = "[a-zA-Z_0-9]*";
		boolean mandatory = false;
		int length = 30;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringDataValidation(data, null, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.expression");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], expression);

	}

	/**
	 * name expression negative test (mandatory is true)
	 */
//	@Test
	public void testStringDataValidationN02() {

		String data = "";
		String fieldName = "name";
		String expression = "[a-zA-Z_0-9]*";
		boolean mandatory = true;
		int length = 30;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringDataValidation(data, null, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], fieldName);

	}

	/**
	 * name expression negative test (exceeded the length)
	 */
//	@Test
	public void testStringDataValidationN03() {

		String data = "1234dfjdslfjdslf%";
		String fieldName = "name";
		String expression = "[a-zA-Z_0-9]*";
		boolean mandatory = false;
		int length = 10;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringDataValidation(data, null, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.length.exceeded");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], 10);

	}

//	@Test
	public void testUserNameValidations() {
		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.userNameValidations(data, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}

	/**
	 * name expression positive test
	 */
//	@Test
	public void testUserNameValidationP01() {
		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.userNameValidations(data, mandatory);
			data = "sample";
			UserDataValidations.userNameValidations(data, mandatory);
			data = "SAMPLE";
			UserDataValidations.userNameValidations(data, mandatory);
			data = "Sample";
			UserDataValidations.userNameValidations(data, mandatory);
			data = "Sample1234";
			UserDataValidations.userNameValidations(data, mandatory);
			data = "1234";
			UserDataValidations.userNameValidations(data, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	/**
	 * name expression negative test (mandatory is true)
	 */
//	@Test
	public void testUserNameValidationN01() {
		String data = "";
		String fieldName = "createdBy / updatedBy";
		boolean mandatory = true;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.userNameValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], fieldName);

	}

	/**
	 * name expression negative test (exceeded the length)
	 */
//	@Test
	public void testUserNameValidationN02() {
		String data = "JswitchSample";
		String fieldName = "createdBy / updatedBy";
		String expression = "^[A-Za-z_-].*$";
		boolean mandatory = false;
		int length = 10;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.userNameValidations(data, mandatory);
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.length.exceeded");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], length);

	}

	/**
	 * name expression negative test (special characters not allowed)
	 */
//	@Test
	public void testUserNameValidationN03() {
		String data = "1234%";
		String fieldName = "createdBy / updatedBy";
		String expression = "^[a-zA-Z0-9]*";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.userNameValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.expression");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], expression);

	}

	@Test
	public void testNameValidations() {
		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.nameValidations(data, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}

	/**
	 * name expression positive test
	 */
	@Test
	public void testNameValidationsP01() {
		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.nameValidations(data, mandatory);
			data = "sample";
			UserDataValidations.nameValidations(data, mandatory);
			data = "SAMPLE";
			UserDataValidations.nameValidations(data, mandatory);
			data = "Sample";
			UserDataValidations.nameValidations(data, mandatory);
			data = "_Sample_";
			UserDataValidations.nameValidations(data, mandatory);
			data = "_Sample_1234";
			UserDataValidations.nameValidations(data, mandatory);
			data = "_1234";
			UserDataValidations.nameValidations(data, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	/**
	 * name expression negative test (mandatory is true)
	 */
//	@Test
	public void testNameValidationsN01() {
		String data = "";
		String fieldName = "name";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.nameValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], fieldName);

	}

	/**
	 * name expression negative test (exceeded the length)
	 */
//	@Test
	public void testNameValidationsN02() {
		String data = "JswitchSample";
		String fieldName = "name";
		String expression = "^[A-Za-z_-].*$";
		boolean mandatory = false;
		int length = 10;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.nameValidations(data, mandatory);
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.length.exceeded");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], length);

	}

	/**
	 * name expression negative test (special characters not allowed)
	 */
//	@Test
	public void testNameValidationsN03() {
		String data = "#$gh%";
		String fieldName = "name";
		String expression = "^[A-Za-z0-9-_.]*";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.nameValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.expression");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], expression);

	}

//	@Test
	public void testEntityIdValidations() {
		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.entityIdValidations(data, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}

	/**
	 * name expression positive test
	 */
//	@Test
	public void testEntityIdValidationsP01() {
		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.entityIdValidations(data, mandatory);
			data = "sample";
			UserDataValidations.entityIdValidations(data, mandatory);
			data = "SAMPLE";
			UserDataValidations.entityIdValidations(data, mandatory);
			data = "Sample";
			UserDataValidations.entityIdValidations(data, mandatory);
			data = "Sample1234";
			UserDataValidations.entityIdValidations(data, mandatory);
			data = "1234";
			UserDataValidations.entityIdValidations(data, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	/**
	 * name expression negative test (mandatory is true)
	 */
//	@Test
	public void testEntityIdValidationsN01() {
		String data = "";
		String fieldName = "entityId";
		boolean mandatory = true;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.entityIdValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], fieldName);

	}

	/**
	 * name expression negative test (exceeded the length)
	 */
//	@Test
	public void testEntityIdValidationsN02() {
		String data = "JswitchSample";
		String fieldName = "name";
		String expression = "^[a-zA-Z0-9]*$";
		boolean mandatory = false;
		int length = 10;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.entityIdValidations(data, mandatory);
			UserDataValidations.stringDataValidation(data, expression, fieldName, mandatory, length);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.length.exceeded");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], length);

	}

	/**
	 * name expression negative test (special characters not allowed)
	 */
//	@Test
	public void testEntityIdValidationsN03() {
		String data = "1234%";
		String fieldName = "entityId";
		String expression = "^[a-zA-Z0-9]*";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.entityIdValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.expression");
		assertEquals(errorArgs[0], fieldName);
		assertEquals(errorArgs[1], expression);

	}

	@Test
	public void testStringPreDefiendDataValidation() {
		String data = "";
		String[] values = { "Locked", "Unlocked" };
		String fieldName = "lockedState";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);
	}

	/**
	 * name expression positive test
	 */
	// @Test
	public void testStringPreDefiendDataValidationP01() {
		String data = "";
		String[] values = { "Locked", "Unlocked" };
		String fieldName = "lockedState";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
			data = "Locked";
			UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
			data = "Unlocked";
			UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	/**
	 * name expression negative test (mandatory is true)
	 */
	// @Test
	public void testStringPreDefiendDataValidationN01() {
		String data = "";
		String[] values = { "Locked", "Unlocked" };
		String fieldName = "lockedState";
		boolean mandatory = true;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], fieldName);

	}

	/**
	 * name expression negative test (exceeded the length)
	 */
	// @Test
	public void testStringPreDefiendDataValidationN02() {
		String data = "locked";
		String[] values = { "Locked", "Unlocked" };
		String fieldName = "lockedState";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.predefined");
		assertEquals(errorArgs[0], fieldName);
	}

	// @Test
	public void testUrlValidationsP01() {

		String data = "https://gitlab.insolutionsglobal.com/";

		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.urlValidations(data, mandatory);
			data = "https://www.techiedelight.com/validate-url-java/";
			UserDataValidations.urlValidations(data, mandatory);
			data = "http://www.domainname.com/folder-name/web";
			UserDataValidations.urlValidations(data, mandatory);
			data="ftp://joe_bozo:bl@123internet.address.edu/path/file.gz";
			UserDataValidations.urlValidations(data, mandatory);
			data = "https://www.google.com/search?q=ftp+url&ie=utf-8&oe=utf-8";
			UserDataValidations.urlValidations(data, mandatory);
			
		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	// @Test
	public void testUrlValidationsN01() {

		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			data = "www.domainname.com/folder-name/web page-file-name.htm";
			UserDataValidations.urlValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.expression");
		assertEquals(errorArgs[0], FieldsInfo.URL_FN);
		assertEquals(errorArgs[1], FieldsInfo.URL_EX);

	}

	// @Test
	public void testUrlValidationsN02() {

		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			data = "http://chart.apis.google.com/chart?chs=500x500&chma=0,0,100,100&cht=p&chco=FF0000chs=500x500&chma=0,0,100,100&cht=p&chco=FF0000%2CFFFF00%7CFF8000%2C00FF00%7C00FF00%2C0000FF&chd=t%3A122%2C42%2C17%2C10%2C8%2C7%2C7%2C7%2C7%2C6%2C6%2C6%2C6%2C5%2C5&chl=122%7C42%7C17%7C10%7C8%7C7"
					+ "%2CFFFF00%7CFF8000%2C00FF00%7C00F"
					+ "F00%2C0000FF&chd=t%3A122%2C42%2C17%2C10%2C8%2C7%2C7%2C7%2C7%2C6%2C6%2C6%2C6%2C5%2C5&chl=122%7C42%7C17%7C10%7C8%7C7chs=500x500&chma=0,0,100,100&cht=p&chco=FF0000%2CFFFF00%7CFF8000%2C00FF00%7C00FF00%2C0000FF&chd=t%3A122%2C42%2C17%2C10%2C8%2C7%2C7%2C7%2C7%2C6%2C6%2C6%2C6%2C5%2C5&chl=122%7C42%7C17%7C10%7C8%7C7"
					+ "%7C7%7C7%7C7%7C6%7C6%7C6%7C6%7C5%7C5&chdl=android%7"
					+ "Cjava%7Cstack-trace%7Cbroadcastreceiver%7Candroid-ndk%7Cuser-agent%"
					+ "7Candroid-webview%7Cwebview%7Cbackground%7Cmultithreading%7Candroid-source";
			UserDataValidations.urlValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.length.exceeded");
		assertEquals(errorArgs[0], FieldsInfo.URL_FN);
		assertEquals(errorArgs[1], FieldsInfo.URL_FL);

	}
	// @Test
	public void testUrlValidationsN03() {

		String data = "";
		boolean mandatory = true;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.urlValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], FieldsInfo.URL_FN);

	}
	
//	@Test
	public void testIpAddressValidationsP01() {

		String data = "192.168.37.25";

		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.ipAddressValidations(data, mandatory);
			data = "192.1.25.255";
			UserDataValidations.ipAddressValidations(data, mandatory);
			data = "19.2.4.2";
			UserDataValidations.ipAddressValidations(data, mandatory);
			data="127.0.0.1";
			UserDataValidations.ipAddressValidations(data, mandatory);

		} catch (ValidationException ex) {
			ex.printStackTrace();
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertNull(errorMsg);
		assertNull(errorArgs);

	}

	
//	@Test
	public void testipAddressValidationsN02() {

		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			data = "192.168.37.256.142";
			UserDataValidations.ipAddressValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.length.exceeded");
		assertEquals(errorArgs[0], FieldsInfo.IP_ADDRESS_FN);
		assertEquals(errorArgs[1], FieldsInfo.IP_ADDRESS_FL);

	}
//	@Test
	public void testipAddressValidationsN03() {

		String data = "";
		boolean mandatory = true;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			UserDataValidations.ipAddressValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.data.validation.field.mandatory");
		assertEquals(errorArgs[0], FieldsInfo.IP_ADDRESS_FN);
	}
//	@Test
	public void testipAddressValidationsN04() {

		String data = "";
		boolean mandatory = false;

		String errorMsg = null;
		Object errorArgs[] = null;

		try {
			data = "192.168.37.256";
			UserDataValidations.ipAddressValidations(data, mandatory);
		} catch (ValidationException ex) {
			errorMsg = ex.getMessage();
			errorArgs = ex.getArgs();
		}
		assertEquals(errorMsg, "user.validation.data.expression");
		assertEquals(errorArgs[0], FieldsInfo.IP_ADDRESS_FN);
		assertEquals(errorArgs[1], FieldsInfo.IP_ADDRESS_EX);

	}
		
	
}