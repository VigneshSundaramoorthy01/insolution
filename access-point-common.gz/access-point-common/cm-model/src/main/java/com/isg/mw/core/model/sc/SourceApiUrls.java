package com.isg.mw.core.model.sc;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SourceApiUrls implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Urls> urls;

	private MosambeeData mosambeeData;

	private String merchantOnboardFlag;
	@Getter
	@Setter
	public static class MosambeeData implements Serializable{
		private String encryptionUrl;
		private String hmacUrl;
		private String registrationUrl;
		private String registrationEditUrl;
		private String updateStatusUrl;
		private String registerTidUrl;
		private String secretKey;
		private String nonce;
		private String hmacKey;
		private String clientId;
	}
}
