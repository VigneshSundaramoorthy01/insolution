package com.isg.mw.core.model.upi;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Data
@Getter
@Setter
public class DeviceEntityAcq implements Serializable {

    private Long deviceId;

    private String id;

    private String mobileNo;

    private String location;

    private String geoCode;

    private String app;

    private String telecom;

    private String capability;

    private String ipAddress;

    private String mmId;

    private String status;

}