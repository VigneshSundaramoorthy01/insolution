/**
 * 
 */
package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 *
 */
public enum ConfigStateResponse {

	Success("00"),

	Locked("01"),

	NotExists("02");

	private String code;

	private ConfigStateResponse(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public static ConfigStateResponse getConfigStateResponse(String code) {
		if (Success.getCode().equals(code)) {
			return Success;
		} else if (Locked.getCode().equals(code)) {
			return Locked;
		} else if (NotExists.getCode().equals(code)) {
			return NotExists;
		}
		return null;
	}
}
