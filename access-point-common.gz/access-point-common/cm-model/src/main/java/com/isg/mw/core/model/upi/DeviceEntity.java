package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class DeviceEntity {

    private String mobileNo;

    private List<UserEntity> userEntities = new ArrayList<>();


}
