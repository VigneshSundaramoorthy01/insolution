package com.isg.mw.core.model.constants;

/**
 * transaction message listen type from merchant or to switch
 * 
 * @author prasad_t026
 *
 */
public enum ConnectionType {

	WEB,

	ISO,
	
	API;

	/**
	 * converts String object to ConnectionType constant
	 * 
	 * @param type - type of the connection in simple String
	 * @return - ConnectionType Enum constant
	 */
	public static ConnectionType getConnectionType(String type) {
		if (WEB.name().equals(type)) {
			return WEB;
		}else if (ISO.name().equals(type)) {
			return ISO;
		}else if (API.name().equals(type)) {
			return API;
		}
		return null;
	}

}