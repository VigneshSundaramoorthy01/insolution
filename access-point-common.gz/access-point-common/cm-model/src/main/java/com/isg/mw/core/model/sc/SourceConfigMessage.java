package com.isg.mw.core.model.sc;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ConfigAction;
import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
public class SourceConfigMessage extends AcpTraceIdModel {

	private ConfigAction action;

	private SourceConfigModel model;

}
