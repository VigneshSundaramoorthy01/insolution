/**
 * 
 */
package com.isg.mw.core.model.constants;

/**
 * purpose of the enum is to refer aiType in file record field aiType 
 * A - Acquirer
 * I - Issuer
 * 
 * @author prasad_t026
 *
 */
public enum AiType {

	A,

	I;

	/**
	 * converts String object to AiType constant
	 * 
	 * @param name - string value of the AiType
	 * @return - AiType Enum constant
	 */
	public static AiType getAiType(String name) {
		if (A.name().equals(name)) {
			return A;
		} else if (I.name().equals(name)) {
			return I;
		}

		return null;
	}

}
