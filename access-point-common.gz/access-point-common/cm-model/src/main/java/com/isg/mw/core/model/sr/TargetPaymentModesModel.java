package com.isg.mw.core.model.sr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class TargetPaymentModesModel implements Serializable {

    @ToString.Exclude
    private OffsetDateTime createdAt;

    @ToString.Exclude
    private OffsetDateTime updatedAt;

    @ToString.Exclude
    private String createdBy;

    @ToString.Exclude
    private String updatedBy;

    //PK
    private Long targetPaymentModeId;

    private Long targetId;

    private Long paymentModeId;

    private OffsetDateTime startDate;

    private OffsetDateTime endDate;

    private String integrationType;

    private String status;

    private String entityId;

    private TargetPaymentModesAdditionalData additionalData;

    private String remarks;
}
