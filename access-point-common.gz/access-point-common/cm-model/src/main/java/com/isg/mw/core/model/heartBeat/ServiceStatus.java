package com.isg.mw.core.model.heartBeat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceStatus {

    private String message;
    private boolean status;
    private String serviceName;
    private String url;

    @Override
    public String toString() {
        return "{" +
                "message='" + message + '\'' +
                ", status=" + status +
                ", serviceName='" + serviceName + '\'' +
                ", url='" + url + '\'' +
                '}';
    }

}
