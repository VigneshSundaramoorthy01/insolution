package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 *
 */
public enum OwnerType {

	SOURCE,

	TARGET,

	ISG_VANILLA;

	/**
	 * converts String object to Owner Type constant
	 * 
	 * @param name - name of the action
	 * @return OwnerType Enum constant
	 */
	public static OwnerType getOwnerType(String name) {

		if (SOURCE.name().equals(name)) {
			return SOURCE;
		} else if (TARGET.name().equals(name)) {
			return TARGET;
		} else if (ISG_VANILLA.name().equals(name)) {
			return ISG_VANILLA;
		}

		return null;

	}

}
