package com.isg.mw.core.model.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NettyCommonUtility {

	private static final Logger LOG = LogManager.getLogger(NettyCommonUtility.class);

	/**
	 * Default constructor It should not access from out side
	 */
	private NettyCommonUtility() {
	}

	public static NettyConfig convertStringToNettyConfig(String nettyConfig) {
		ObjectMapper mapper = new ObjectMapper();
		NettyConfig nettyConfigObj = null;
		try {
			if (nettyConfig != null) {
				nettyConfigObj = mapper.readValue(nettyConfig, NettyConfig.class);
			}
		} catch (JsonMappingException e) {
			LOG.error("An error occurred! {}", e);
		} catch (JsonProcessingException e) {
			LOG.error("An error occurred! {}", e);
		}

		return nettyConfigObj;
	}

	public static String nettyConfigToString(NettyConfig nettyConfig) {
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(nettyConfig);
		} catch (Exception e) {
			LOG.error("An error occurred! {}", e);
		}
		return json;
	}

}
