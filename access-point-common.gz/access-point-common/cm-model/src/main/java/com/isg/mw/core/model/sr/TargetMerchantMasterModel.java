package com.isg.mw.core.model.sr;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class TargetMerchantMasterModel implements Serializable {

    private Long targetMerchantMasterId;

    private String mid;

    private String tid;

    private Long targetId;

    private String targetMid;

    private String status;

    private String merchantVpa;

    private String key;

    private String salt;

    private String prodApiKey;

    private String testApiKey;

    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;
    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;

    private String exceptionMessage;

    private String dpaId;

    private Integer retryCount;

    private String integrationType;
}
