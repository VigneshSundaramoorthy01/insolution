package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class UdirOrgTransactionDetails {

    private String txnId;

    private String payeeId;

    private String payerId;

    private String scrReqBody;

    private String amount;

    //private String payeeAccNum;

    //private String payerAccNum;

    private String reqJsonString;

    private String orgTxnStatus;

    private String revTxnStatus;
}
