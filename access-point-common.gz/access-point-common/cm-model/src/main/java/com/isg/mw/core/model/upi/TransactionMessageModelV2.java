package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@ToString
public class TransactionMessageModelV2 implements Serializable {

    private static final long serialVersionUID = 1L;

    private String txn_id;

    private String entity_id;
    private String payee_id;
    private String payee_sub_id;
    private String payer_id;
    private String src_txn_id;

    private String tgt_txn_id;

    private String traceability_txn_id;

    private Date src_req_arrival_time;
    private Date src_res_dispatch_time;
    private Date tgt_req_dispatch_time;
    private Date tgt_rsp_arrival_time;

    private String invoice_no;
    private String src_batch_no;

    private String amount;

    private int status;
    private String batch_no;

    private String src_type;
    private String tgt_type;

    private String src_res_code;
    private String tgt_res_code;
    private String orgTxnId;
    private String src_currency_code;
    private String tgt_currency_code;

    private String txnType;

    private String apiType;

    private String traceId;

    private String mid;

    private String tid;

    private String rrn;

    private String txnStatus;

    private String msgId;

    private TransactionExtensionMessageModelV2 transactionExtensionMessageModelV2;

}
