package com.isg.mw.core.model.constants;

/**
 * purpose of the enum is to refer bin type in file record field active flag 
 * Y - Yes
 * N - No
 * 
 * @author sanchita_3984
 *
 */
public enum ActiveFlag {
	
	Y,

	N;

	/**
	 * converts String object to active flag constant
	 * 
	 * @param name - string value of the Active flag
	 * @return - Active flag Enum constant
	 */
	public static ActiveFlag getActiveFlag(String name) {
		if (Y.name().equals(name)) {
			return Y;
		} else if (N.name().equals(name)) {
			return N;
		}

		return null;
	}

}
