package com.isg.mw.core.model.sr;


import com.isg.mw.core.model.common.AcpTraceIdModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class PaymentModeOptionsModel extends AcpTraceIdModel implements Serializable {

    private Long paymentModeOptionId;

    private Long paymentModeId;

    private String modeOptionName;

    private String modeOptionDesc;

    private Boolean defaultEnabledFlag;

    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;

    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;



}
