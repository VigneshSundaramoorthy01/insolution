package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class UpiAcqTransactionDetails {

    private String txnId;

    private String srcTxnId;

    private String tgtTxnId;

    private String payeeId;

    private String payerId;

    private String amount;

    private String txnStatus;

    private String tgtReqBody;

    private String tgtRespBody;
}
