package com.isg.mw.core.model.sr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class TargetLCRConfigModel implements Serializable {

    private Long lcrConfigId;
    private String createdBy;
    private OffsetDateTime createdAt;
    private String updatedBy;
    private OffsetDateTime updatedAt;
    private Long targetId;
    private Long paymentModeId;
    private String cardType;
    private String mccCategory;
    private Double pricePct;
    private Double priceFixed;
    private Double below2000PricePct;
    private Double below2000PriceFixed;
    private Long paymentModeOptionId;
    private String status;
    private OffsetDateTime startDate;
    private OffsetDateTime endDate;
    private String entityId;
    private String remarks;


}
