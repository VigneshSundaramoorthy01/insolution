package com.isg.mw.core.model.upi;

public class AuthorizationTransactionRequestDTO {

   String traceId;
   String upiTranId;
   String ccAccountId;
   String payerVPA;
   String payeeVPA;
   String merchantName;
   int mcc;
   int currCode;
   Long transactionAmount;
   String  transactionDate;
   String transactionTime;
   String mid;
   String tid;
   int rrn;
   String tranType;

   public String getTraceId() {
      return traceId;
   }

   public void setTraceId(String traceId) {
      this.traceId = traceId;
   }

   public String getUpiTranId() {
      return upiTranId;
   }

   public void setUpiTranId(String upiTranId) {
      this.upiTranId = upiTranId;
   }

   public String getCcAccountId() {
      return ccAccountId;
   }

   public void setCcAccountId(String ccAccountId) {
      this.ccAccountId = ccAccountId;
   }

   public String getPayerVPA() {
      return payerVPA;
   }

   public void setPayerVPA(String payerVPA) {
      this.payerVPA = payerVPA;
   }

   public String getPayeeVPA() {
      return payeeVPA;
   }

   public void setPayeeVPA(String payeeVPA) {
      this.payeeVPA = payeeVPA;
   }

   public String getMerchantName() {
      return merchantName;
   }

   public void setMerchantName(String merchantName) {
      this.merchantName = merchantName;
   }

   public int getMcc() {
      return mcc;
   }

   public void setMcc(int mcc) {
      this.mcc = mcc;
   }

   public int getCurrCode() {
      return currCode;
   }

   public void setCurrCode(int currCode) {
      this.currCode = currCode;
   }

   public Long getTransactionAmount() {
      return transactionAmount;
   }

   public void setTransactionAmount(Long transactionAmount) {
      this.transactionAmount = transactionAmount;
   }

   public String getTransactionDate() {
      return transactionDate;
   }

   public void setTransactionDate(String transactionDate) {
      this.transactionDate = transactionDate;
   }

   public String getTransactionTime() {
      return transactionTime;
   }

   public void setTransactionTime(String transactionTime) {
      this.transactionTime = transactionTime;
   }

   public String getMid() {
      return mid;
   }

   public void setMid(String mid) {
      this.mid = mid;
   }

   public String getTid() {
      return tid;
   }

   public void setTid(String tid) {
      this.tid = tid;
   }

   public int getRrn() {
      return rrn;
   }

   public void setRrn(int rrn) {
      this.rrn = rrn;
   }

   public String getTranType() {
      return tranType;
   }

   public void setTranType(String tranType) {
      this.tranType = tranType;
   }

   @Override
   public String toString() {
      return "AuthorizationTransactionRequestDTO{" +
              "traceId='" + traceId + '\'' +
              ", upiTranId='" + upiTranId + '\'' +
              ", ccAccountId='" + ccAccountId + '\'' +
              ", payerVPA='" + payerVPA + '\'' +
              ", payeeVPA='" + payeeVPA + '\'' +
              ", merchantName='" + merchantName + '\'' +
              ", mcc=" + mcc +
              ", currCode=" + currCode +
              ", transactionAmount=" + transactionAmount +
              ", transactionDate='" + transactionDate + '\'' +
              ", transactionTime='" + transactionTime + '\'' +
              ", mid='" + mid + '\'' +
              ", tid='" + tid + '\'' +
              ", rrn=" + rrn +
              ", tranType='" + tranType + '\'' +
              '}';
   }
}
