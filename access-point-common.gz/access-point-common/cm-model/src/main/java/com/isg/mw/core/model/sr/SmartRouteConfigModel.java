package com.isg.mw.core.model.sr;

import java.time.OffsetDateTime;
import java.util.List;

import com.isg.mw.core.model.common.SmartRouteTargetDefinition;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.RouteType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author shital3986
 *
 */
@Getter
@Setter
@ToString
public class SmartRouteConfigModel {

	private Long id;
	
	private Long sourceId;
	
	private RouteType routeType;
	
	private Long successRatioInterval;
	
	private Double successRatioMaxTxns;
	
	private Double routeSwitchingPercent;
	
	private Double successThreshold;
	
	private List<SmartRouteTargetDefinition> targetRouteConfig;
	
	private String status;
	
	private LockedState lockedState;
	
	/**
	 * Created date and time
	 */
	private OffsetDateTime createdAt;

	/**
	 * Updated Date and time
	 */
	private OffsetDateTime updatedAt;

	/**
	 * Created by
	 */
	private String createdBy;

	/**
	 * Updated by
	 */
	private String updatedBy;
	
	private String remarks;

	private String entityId;
}
