package com.isg.mw.core.model.constants;

public enum StatsType {

    CALCULATION_INTERVAL,
    PRIMARY_SWITCH_OVER,
    FAIL_OVER
}
