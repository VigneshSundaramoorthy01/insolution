package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ConfigAction;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class TargetPaymentModeOptionsMessage extends AcpTraceIdModel implements Serializable {

    private ConfigAction action;

    private TargetPaymentModeOptionsModel model;

    private TargetPaymentModesModel targetPaymentModesModel;
}
