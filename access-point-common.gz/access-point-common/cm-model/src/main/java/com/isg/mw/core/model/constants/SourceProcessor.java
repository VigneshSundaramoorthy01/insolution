package com.isg.mw.core.model.constants;

public enum SourceProcessor {
    POS_SWITCH,
    PG_SWITCH,
    SMART_ROUTE,
    BQR_SWITCH,
    UPI_SWITCH,
    UPI_ACQ_SWITCH,
    EFTPOS,
    BBPSOU_BILLER
}

