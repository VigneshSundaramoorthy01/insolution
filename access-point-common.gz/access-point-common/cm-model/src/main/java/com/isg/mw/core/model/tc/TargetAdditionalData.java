package com.isg.mw.core.model.tc;

import java.io.Serializable;
import java.util.List;

import com.isg.mw.core.model.constants.TargetProcessor;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class TargetAdditionalData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String acquirerId;

	private String fwdInstId;
	
	private TargetApiInfo apiInfo;
	
	private TargetProcessor targetProcessor;

	private String merchantOnboardFlag;

	private String paymentSource;

	private String stationId;

	private String signOnId;

	private List<String> integrationTypes;
}
