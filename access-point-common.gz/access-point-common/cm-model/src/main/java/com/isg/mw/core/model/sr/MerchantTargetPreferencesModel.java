package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.ConfigAction;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;
@Getter
@Setter
@ToString
public class MerchantTargetPreferencesModel implements Serializable {

    private Long mcPreferenceId;

    private Long merchantMasterId;

    private String mid;

    private Long targetId;

    private Long paymentModeId;

    private OffsetDateTime startDate;

    private OffsetDateTime endDate;

    private ActiveInactiveFlag status;

    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;

    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;


}
