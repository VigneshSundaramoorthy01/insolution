package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 *
 */
public enum LockedState {

	Locked,

	Unlocked;

	/**
	 * converts String object to LockedState constant
	 * 
	 * @param name - name of the state
	 * @return - LockedState Enum constant
	 */
	public static LockedState getState(String name) {
		if (Locked.name().equals(name)) {
			return Locked;
		} else if (Unlocked.name().equals(name)) {
			return Unlocked;
		}

		return null;
	}

}
