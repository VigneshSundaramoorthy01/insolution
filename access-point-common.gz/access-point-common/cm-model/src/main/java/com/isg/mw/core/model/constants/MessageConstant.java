package com.isg.mw.core.model.constants;

public class MessageConstant {
    public static final String SUCCESS_CODE = "00";
    public static final String SUCCESS_DESC = "SUCCESS";

    public static final String FAIL_CODE = "01";
    public static final String FAIL_DESC = "FAILED";

    public static final String INTERNAL_SERVER_CODE = "500";
    public static final String INTERNAL_SERVER_ERROR="Internal Server Error";


    public static final String EXPECTATION_FAILED_ERROR = "Expectation Failed";
    public static final String EXPECTATION_FAILED_CODE = "417";

    public static final String NO_CONTENT = "No Content";

    public static final String NO_DATA_FOUND = "No Data Found";

}
