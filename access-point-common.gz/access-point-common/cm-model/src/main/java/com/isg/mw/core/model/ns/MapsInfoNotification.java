package com.isg.mw.core.model.ns;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
public class MapsInfoNotification implements Serializable {

	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;

}