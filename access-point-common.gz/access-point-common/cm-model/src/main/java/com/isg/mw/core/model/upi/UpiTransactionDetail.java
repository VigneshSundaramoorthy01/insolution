package com.isg.mw.core.model.upi;


import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UpiTransactionDetail implements Serializable {

    private String traceId;

    private String txdId;

    private String  entityId;

    private String  payeeId;

    private String  payerId;

    private String srcArrivalTime;

    private String srcDispatchTime;

    private String tgtDispatchTime;

    private String tgtArrivalTime;

    private String invoiceNo;

    private String sourceBatchNo;

    private String batchNo;

    private String amount;

    private String srcType;


    private String tgtType;

    private String txnSubType;

    private String srcResCode;


    private String  tgtResCode;


    private String status;//COMPLETED,PENDING,FAILED


    private String statusCode;

    private String srcCurrencyCode;


    private String tgtCurrencyCode;

    private String payerAccNum;


    private String payeeAccNum;
    private String name;

    private String type;


    private String ifsc;

    private String accType;
    
    private String msgId;

    private String reversalStatus;

    private String reversalTxnId;

    private String reversalStatusCode;

    private String orgTxnResult;

    private String revTxnResult;

    private String mcc;

    private String mid;

    private String tid;

    private String merchantName;

    private String custRefNo;

    private String revTxnCustRefNo;

    private String revTxnDateTime;

    private String txnCurrency;

    private String authCode;

    private String purposeCode;

    private String initiationMode;

    private String revTxnAuthCode;

    private String revTxnPurposeCode;

    private String revTxnInitiationMode;

    private String revCustRefNo;

    private String txnType;

    private Boolean CreditFlag;


    private String txnNote;

    private String orgTxnDate;

    private String errCode;

    private String payerRespCode;

    private String payeeRespCode;

    private String payerRevRespCode;

    private String payeeRevRespCode;

    private String payerAccNo;

    private String payerIfsc;

    private String payerName;

    private String payerAccType;

    private String approvalNumber;

    private String srcTxnId;

    private String umn;
}
