package com.isg.mw.core.model.constants;

public enum Tokenize {

    Y,

    N;

    public static Tokenize getTokenize(String name) {
        if (Y.name().equals(name)) {
            return Y;
        } else if (N.name().equals(name)) {
            return N;
        }

        return null;
    }
}
