package com.isg.mw.core.model.heartBeat;


import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class kafkaTopicDetails {

    @Getter
    @Setter
    List<kafkaTopicPartitionInfo> partitionInfo = new ArrayList<kafkaTopicPartitionInfo>();



}
