package com.isg.mw.core.model.bi;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigInteger;


@Getter
@Setter
public class AidSchemeModel extends AcpTraceIdModel implements Serializable {
    /**
     * Database auto generated value
     */

    private Long id;
    /**
     * Entity Id
     */
    private String entityId;


    /**
     * Aid
     */
    private String aid;

//    /**
//     * targetid
//     */
//    @Column(name = "target_id")
//    private TargetConfigModel target;

    /**
     * targetid
     */
    private String targetId;

    /**
     * Active Flag
     */
    private ActiveFlag activeFlag;


    /**
     * Aid
     */
    private String remark;

    @Override
    public String toString() {
        return "BinInfoModel{" +
                "acpTraceId=" + getAcpTraceId() +
                "entityId='" + entityId + '\'' +
                ", aid=" + aid +

                ", targetId='" + targetId + '\'' +
                ", activeFlag='" + activeFlag + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }



}
