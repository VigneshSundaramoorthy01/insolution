package com.isg.mw.core.model.heartBeat;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class kafkaTopicPartitionInfo {

    private int partition;
    private kafkaNodes leader;
    private  List<kafkaNodes> replicas;
    private  List<kafkaNodes> isr;

    private long commitedOffset;
    private long endOffset;
    private long lag;

}
