package com.isg.mw.core.model.upi;

import java.util.Arrays;

public enum MandateTypes {

    WEEKLY,
    MONTHLY,
    BIOMONTHLY,
    QUARTERLY,
    HALFYEARLY,
    YEARLY,
    FORTNIGHTLY;
   public static boolean byNameIgnoreCase(String givenName) {
        return Arrays.stream(values()).filter(it -> it.name().equalsIgnoreCase(givenName)).findAny().isPresent();
    }
}
