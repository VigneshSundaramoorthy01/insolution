package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 *
 */
public enum ValidationStatus {

	Success,

	Failed;

	/**
	 * converts String object to ValidationStatus constant
	 * 
	 * @param name - name of the state
	 * @return - ValidationStatus Enum constant
	 */
	public static ValidationStatus getStatus(String name) {
		if (Success.name().equals(name)) {
			return Success;
		} else if (Failed.name().equals(name)) {
			return Failed;
		}

		return null;
	}

}
