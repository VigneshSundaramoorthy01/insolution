package com.isg.mw.core.model.constants;

public enum DataFileType {
	
    Bin("Bin"),
    Maps("Maps");

    private String str;

    DataFileType(String str){
       this.str = str;
    }

    public String getStr() {
       return str;
    }


}
