package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class MerchantPaymentModeOptionsModel implements Serializable {

    private Long merchantPayModeOptionId;

    private Long merchantPaymentModeId;

    private Long paymentModeOptionId;

    private OffsetDateTime startDate;

    private OffsetDateTime endDate;

    private String status;

    private MerchantPaymentModeOptionsAdditionalData additionalData;

    private String remarks;
    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;
    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;


}
