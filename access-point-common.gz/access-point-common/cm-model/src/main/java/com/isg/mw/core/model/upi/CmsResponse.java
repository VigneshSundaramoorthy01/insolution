package com.isg.mw.core.model.upi;

import lombok.Data;

@Data
public class CmsResponse {

    private String statusCode;

    private String statusDesc;

}
