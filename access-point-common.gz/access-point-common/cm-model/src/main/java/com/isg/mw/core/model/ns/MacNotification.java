package com.isg.mw.core.model.ns;

import java.io.Serializable;

import com.isg.mw.core.model.constants.ConfigAction;
import com.isg.mw.core.model.sc.SourceConfigModel;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
public class MacNotification implements Serializable {

	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * config action
	 */
	private ConfigAction action;

	/**
	 * merchant aggregator config details
	 */
	private SourceConfigModel macConfig;

}