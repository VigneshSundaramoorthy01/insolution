package com.isg.mw.core.model.constants;

/**
 * purpose of the enum to refer Target in TargetConfigModel
 * 
 * @author rahul3983
 *
 */
public enum Target {

	Scheme,

	Issuer;

	public static Target getTarget(String target) {
		if (Scheme.name().equals(target)) {
			return Scheme;
		} else if (Issuer.name().equals(target)) {
			return Issuer;
		}
		return null;

	}

}
