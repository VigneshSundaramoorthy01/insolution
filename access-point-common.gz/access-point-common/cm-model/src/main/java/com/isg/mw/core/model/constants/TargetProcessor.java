package com.isg.mw.core.model.constants;

public enum TargetProcessor {

	BQRPROCESSOR;
	
	
	public static TargetProcessor getTargetProcessor(String processor) {
		if (BQRPROCESSOR.name().equals(processor)) {
			return BQRPROCESSOR;
		}
		return null;
	}
}
