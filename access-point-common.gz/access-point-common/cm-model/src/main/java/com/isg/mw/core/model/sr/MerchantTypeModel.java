package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class MerchantTypeModel implements Serializable {

    private String mcc;

    private String midCategorySmall;

    private String midCategoryLarge;

    private String merchantSector;

    private String midType;

    private String productService;
}
