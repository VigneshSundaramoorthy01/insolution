package com.isg.mw.core.model.mf;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasadj_t026
 *
 */
@Setter
@Getter
public class BusinessRule {

	String className;

	String methodName;

}
