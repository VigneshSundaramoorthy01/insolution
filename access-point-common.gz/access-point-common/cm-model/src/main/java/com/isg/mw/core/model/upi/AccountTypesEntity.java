package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccountTypesEntity {

    private String bankId;

    private String account_type;

    private String maxTxnAmountLimit;

    private String npciOrgId;

    private String bankOrgId;


    private String idPrefix;


    private String ifsc;


    private String credsFormat;


    private Integer pinRetiresAllowed;


    private Integer dailyTxnFrequency;


    private Integer credsLength;

    private String type;


}
