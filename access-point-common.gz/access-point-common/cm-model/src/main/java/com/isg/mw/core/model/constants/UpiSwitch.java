package com.isg.mw.core.model.constants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class UpiSwitch {

    //public static HashMap<String, String> statusMap;
    @Autowired
    private static Environment env;

    public static  String listPsp="ListPsp";
    public static  String listKey="ListPSPKeys";
    public static  String listAccPvd="ListAccPvd";
    public static  String listVae="ListVae";

    public static String reqPayEndPointUri = "reqPay";

    public static String reqBalEnqEndPointUri = "reqBalEnq";

    public static int timer = 5000;
    public static String reqListAccEndPointUri = "reqListAcc";

    public static String reqListAccEndPoint = "ReqListAccount";
    public static String createMandateRespPath = "RespMandate";
    public static String npciOrgId = "NPCI";

    public static String reqListCMSPath = "listOfAccounts";

    public static String respListNPCIPath = "RespListAccount";

    public static String reqRegMobileEndPointUri = "regMobile";

    public static String reqRegApi = "ReqRegMob";

    public static String reqRegMobEndPoint = "RegMobile";

    public static String reqBalEndPoint = "ReqBalEnq";

    public static String reqBalCCMSPath = "balanceEnquiry";

    public static String respReqBalNPCIPath = "RespBalEnq";

    public static String reqRegMobileCmsPath = "cardValidate";

    public static String respRegMobNPCIPath = "RespRegMob";

    public static String reqOtpApi = "ReqOtp";

    public static String respOtpNPCIPath = "RespOtp";

    public static String npciRespDateFormat = "yyyy-MM-dd'T'HH:mm:ss'+05:30'";

    public static String success = "SUCCESS";

    public static String failed = "FAILED";

    public static String reqPayApi = "ReqPay";

    public static String typeDebit = "DEBIT";

    public static String typeCredit = "CREDIT";


    public static String typeRefund = "REFUND";

    public static String typeCollect = "COLLECT";

    public static String typePay = "PAY";
    public static String typeReversal = "REVERSAL";
    public static String typeChkTxn = "ChkTxn";
    public static String reqPayCMSPath = "authorizeTransaction";

    public static String respPayNPCIPath = "RespPay";

    public static String typePayer = "PAYER";
    public static String typePayee = "PAYEE";

    public static String typeAutoUpdate = "AutoUpdate";

    public static String typeMandateNotification = "MandateNotification";

    public static String chkTxnEndpoint = "ReqChkTxn";

    public static String respChkTxnNPCIPath = "RespChkTxn";

    public static String reqSetCreds = "ReqSetCreds";

    public static String respSetCredsNPCIPath = "RespSetCre";

    public static String udirChkTxnEndpoint = "UdirReqChkTxn";

    public static String tlmOrgTxnDataPath = "getOrgTxnData";

    public static String tlmUpiAcqTxnDataPath = "getUpiAcqTxnData";


    public static String tlmTxnStatusPath = "getTxnStatus";
    public static String cmsUDIRAuthTxnPath = "udirAuthTxn";
    public static String chkTxnPath = "chktnx";

    public static String chkVpaPath = "chkvpa";

    public static String chkVpaPathNPCI = "ReqValAdd";
    public static String respValAddPath = "RespValAdd";
    public static String chkVpaPathResp = "chkvpaResp";

    public static String payTxnPath = "pay";
    public static String pgRespPayPath="payResp";

    public static String collectTxnPath = "collect";
    public static String reqPayCreditNPCI = "ReqPayCredit";

    public static String respPayCreditNPCI = "RespPayCredit";
    public static String pgRespCollectPath="RespCollect";
    public static String pgRespCallbackPath = "RespCallbackPg";

    public static String createMandatePath = "createMandate";

    public static String mandateUpdatePath="mandateUpdate";

    public static String revokeMandatePath="mandateRevoke";

    public static String refundMandatePath="refundMandate";

    public static String mandateRespPath = "RespMandate";

    public static String ReqTxnConfirmation="ReqTxnConfirmation";
    public static String RespTxnConfirmation="RespTxnConfirmation";
    public static String pendingStatus = "Pending";
    public static String successStatus = "Success";

    public static String reqMandateConfirmationPath = "ReqMandateConfirmation";

    public static String exeMandatePath = "recurrPayment";
    public static String pgExeMandateRespPath="RespExeMandate";
    public static String pgExeMandateRespCallbackPath = "RespCallbackExeMandate";


    public static String respAuthDetails= "RespAuthDetails";
    public static String reqAuthDetail= "ReqAuthDetails";

    public static String reqListVae= "ReqListVae";
    public static String respListVae= "RespListVae";

    public static String reqListKeys= "ReqListKeys";
    public static String respListKeys= "RespListKeys";

    public static String reqListAccPvd= "ReqListAccPvd";
    public static String respListAccPvd= "RespListAccPvd";

    public static String reqListPsps= "ReqListPsp";
    public static String respListPsp= "RespListPsp";

    public static  String ManageVae="ManageVae";
    public static  String reqManageVae ="ReqManageVae";
    public static  String respManageVae ="RespManageVae";

    public static String notifyMandatePath = "notifyMandate";
    public static String reqValCustNPCIPath="ReqValCust";
    public static String respValCustPath="RespValCust";
    public static String notifyMandateRespPath = "RespNotifyMandate";
    public static String reqAuthMandate= "ReqAuthMandate";
    public static String respAuthMandate= "RespAuthMandate";

    public static String balEnqNpciRespPath = "RespBalEnq";

    public static String reqMandate = "ReqMandate";
    public static String reqHbtAcq= "ReqHbtAcq";
    public static String reqOtpAcq= "ReqOtpAcq";
    public static String respOtp= "RespOtp";
    public static String reqSetCre= "ReqSetCre";
    public static String respSetCre= "RespSetCre";

    public static String reqBalEnq= "ReqBalEnq";
    public static String respBalEnq= "RespBalEnq";
    public static String reqReqMob= "ReqRegMob";

    public static String respRegMob= "RespRegMob";
    public static String listAccountReqPG= "listAccount";
    public static String respListAccountPG= "respListAccount";
    public static String reqListAccountNPCI= "ReqListAccount";
    public static String respListAccountNPCI= "RespListAccount";
    public static String reqAuthValCust = "ReqAuthValCust";
    public static String respAuthValCust  = "RespAuthValCust";

    public static String billFetchRequest  = "BillFetchRequest";
    public static String billFetchResponse  = "BillFetchResponse";
    public static String reqFetchBillBBPSPath  = "BillFetchResponse";
    public static String billPayRequest = "BillPaymentRequest";
    public static String billPayReversal = "billPayReversal";
    public static String txnStatusRequest = "txnStatusRequest";

}
