package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class TransactionExtensionMessageModelV2 implements Serializable {


    private String txnId;

    private String srcReqData;

    private String srcResData;

    private String tgtReqData;

    private String tgtResData;

    private String revTxnReqData;

    private String revTxnRespData;

    private String udirTxnReqData;

    private String udirTxnRespData;



}
