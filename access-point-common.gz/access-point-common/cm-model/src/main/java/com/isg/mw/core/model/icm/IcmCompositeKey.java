package com.isg.mw.core.model.icm;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class IcmCompositeKey extends AcpTraceIdModel implements Serializable {

    private String schemeIndentifier;
    private String currencyCode;

    public IcmCompositeKey() {
    }

    public IcmCompositeKey(String schemeIndentifier, String currencyCode) {
        this.schemeIndentifier = schemeIndentifier;
        this.currencyCode = currencyCode;
    }

    @Override
    public String toString() {
        return "IcmCompositeKey{" +
                "schemeIndentifier='" + schemeIndentifier + '\'' +
                ", currencyCode='" + currencyCode + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        IcmCompositeKey currencyConversion = (IcmCompositeKey) o;
        return this.getSchemeIndentifier().equals(currencyConversion.getSchemeIndentifier()) 
        		&& this.getCurrencyCode().equals(currencyConversion.getCurrencyCode());
    }

    @Override
    public int hashCode() {
        return Integer.parseInt(String.valueOf(this.getSchemeIndentifier()));
    }
}
