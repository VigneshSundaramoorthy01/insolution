package com.isg.mw.core.model.upi;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UpiValidation {

    private String errorCode;

    private boolean check;

    private String mandateFlag;

}
