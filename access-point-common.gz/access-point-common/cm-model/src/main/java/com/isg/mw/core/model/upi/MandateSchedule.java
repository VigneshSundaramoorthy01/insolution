package com.isg.mw.core.model.upi;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MandateSchedule {

    private String scheduleStartDate;
    
    private String scheduleEndDate;

    private String scheduleOrder;

    private String status;

    private String txnId;

    private String txnDte;

    private String umn;
}
