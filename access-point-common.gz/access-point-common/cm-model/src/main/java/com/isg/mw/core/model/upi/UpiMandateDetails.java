package com.isg.mw.core.model.upi;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class UpiMandateDetails implements Serializable {

    private String vpa;

    private String type;

    private String startDate;

    private String endDate;

    private String frequency;

    private double amount;

    private String status;

    private String mandateCreationStatus;

    private String mobileNum;

    private String mandateSignature;

    private String blockFundFlag;

    private String addr;

    private String amountRule;

    private String mandateRuleValue;

    private String mandateRuleType;

    private int sequence;

    //private String accNum;

   // private String ifsc;


}
