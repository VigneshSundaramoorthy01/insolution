package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.Objects;

@Getter
@Setter
@ToString
public class MerchantPaymentModesModel implements Serializable {

    private Long merchantPaymentModeId;

    private Long merchantMasterId;

    private Long paymentModeId;

    private OffsetDateTime startDate;

    private OffsetDateTime endDate;

    private String entityId;

    private String status;

    private String remarks;

    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;
    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MerchantPaymentModesModel that = (MerchantPaymentModesModel) o;
        return merchantMasterId.equals(that.merchantMasterId) && paymentModeId.equals(that.paymentModeId) && entityId.equals(that.entityId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(merchantMasterId, paymentModeId, entityId);
    }
}
