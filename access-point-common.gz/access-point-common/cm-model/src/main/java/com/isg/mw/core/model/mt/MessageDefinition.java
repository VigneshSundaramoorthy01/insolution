package com.isg.mw.core.model.mt;

import com.isg.mw.core.model.constants.TargetType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Message definition model
 *
 * @author prasad_t026
 */
@Getter
@Setter
@ToString
public class MessageDefinition {

    private TargetType targetType;

    private String msgType;

    private String msgTypeId;

    private String apiPath;

    private String httpMethod = "post";

}
