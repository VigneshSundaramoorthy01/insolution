package com.isg.mw.core.model.sr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class TargetPaymentModeOptionsModel implements Serializable {
    @ToString.Exclude
    private OffsetDateTime createdAt;

    @ToString.Exclude
    private OffsetDateTime updatedAt;

    @ToString.Exclude
    private String createdBy;

    @ToString.Exclude
    private String updatedBy;

    //PK
    private Long targetPayModeOptionId;

    private Long targetPaymentModeId;

    private Long paymentModeOptionId;

    private OffsetDateTime startDate;

    private OffsetDateTime endDate;

    private String status;

    private TargetPaymentModeOptionsAdditionalData additionalData;

    private String remarks;
}
