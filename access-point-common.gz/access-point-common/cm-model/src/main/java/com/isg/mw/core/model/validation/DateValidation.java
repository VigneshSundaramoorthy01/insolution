package com.isg.mw.core.model.validation;

import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.utils.DateFormatUtils;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateValidation {

    private DateValidation() {
    }

    public static void endDateValidations(String startDate, String endDate) throws DateTimeParseException {
        OffsetDateTime sDate = OffsetDateTime.parse(startDate, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        OffsetDateTime eDate = OffsetDateTime.parse(endDate, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        OffsetDateTime currentOffsetDateTime = OffsetDateTime.now(DateFormatUtils.getTimeZone().toZoneId());
        if (eDate.isBefore(currentOffsetDateTime)) {
            throw new ValidationException("End date : "+eDate+" is before the current date and time : "+currentOffsetDateTime);
        }
        if (eDate.isBefore(sDate)) {
            throw new ValidationException("End date : "+eDate+" is before the start date and time : "+sDate);
        }
    }

    public static void startDateValidations(String startDate) throws DateTimeParseException {
        OffsetDateTime sDate = OffsetDateTime.parse(startDate, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        OffsetDateTime currentOffsetDateTime = OffsetDateTime.now(DateFormatUtils.getTimeZone().toZoneId());
        if (sDate.isBefore(currentOffsetDateTime)) {
            throw new ValidationException("Start date : "+sDate+" is before the current date and time : "+currentOffsetDateTime);
        }
    }

    public static boolean isDateInBetweenEndPoints(OffsetDateTime min, OffsetDateTime max, OffsetDateTime date){
        return !(date.isBefore(min) || date.isAfter(max));
    }
}
