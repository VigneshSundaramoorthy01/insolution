package com.isg.mw.core.model.constants;

public enum ActiveInactiveFlag {
	Active,

	Inactive,

	Inprogress,

	Failed,

	Pending_Exp,

	Pending,

	Exported;

	/**
	 * converts String object to ActiveInactiveFlag constant
	 * 
	 * @param name - string value of the ActiveInactiveFlag
	 * @return - ActiveInactiveFlag Enum constant
	 */
	public static ActiveInactiveFlag getActiveInactiveFlag(String name) {
		if (Active.name().equals(name)) {
			return Active;
		} else if (Inprogress.name().equals(name)) {
			return Inprogress;
		}else if (Failed.name().equals(name)) {
			return Failed;
		}else if (Pending_Exp.name().equals(name)) {
			return Pending_Exp;
		}else if (Exported.name().equals(name)) {
			return Exported;
		}else if (Inactive.name().equals(name)) {
			return Inactive;
		}else if (Pending.name().equals(name)) {
			return Pending;
		}
		return null;
	}

}
