package com.isg.mw.core.model.validation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import com.isg.mw.core.model.constants.CommonConstants;
import com.isg.mw.core.model.constants.FieldsInfo;

/**
 * 
 * @author prasad_t026
 *
 */
public class FileNameValidator implements CommonConstants {

	public static String BIN = "BIN";
	
	public static String MERCHANT = "MERCHANT";
	
	public static String ONUSBIN = "ONUSBIN";

	public static String AID = "AID";

	public static String BINONUS = "BINONUS";


	public static String BINEXCEPTIONS = "BINEXCEPTION";
	
	public FileNameValidator() {
		
	}

	public static String validateFileName(String fileName, String type) {

		if(fileName.indexOf(DOT) < 0) {
			return INVALID_FILE_NAME + fileName;
		}

		String extn = fileName.substring(fileName.lastIndexOf(DOT) + 1);
		String name = fileName.substring(0, fileName.lastIndexOf(DOT));
		String[] split = name.split(UNDER_SCORE);
		
		if(!CSV.equalsIgnoreCase(extn)) {
			return INVALID_FILE_EXTN + extn;
		}
		
		if(split.length != 4) {
			return INVALID_FILE_NAME + fileName;
		}
		
		if(BIN.equals(type)) {
			if(!BIN.equals(split[0])) {
				return INVALID_FILE_PREFIX + split[0];
			}
		}
		if(MERCHANT.equals(type)) {
			if(!MERCHANT.equals(split[0])) {
				return INVALID_FILE_PREFIX + split[0];
			}
		}
		else if(ONUSBIN.equals(type)) {
			if(!ONUSBIN.equals(split[0])) {
				return INVALID_FILE_PREFIX + split[0];
			}
		}
		
		if(BIN.equals(type)) {
			if(split[1].length() != 4 || !Pattern.matches(FieldsInfo.ALPHA_EX, split[1])) {
				return INVALID_SCHEME_PREFIX + split[1];
			}
		}
		else if(MERCHANT.equals(type) || ONUSBIN.equals(type)) {
			if(split[1].length() > 32 || !Pattern.matches(FieldsInfo.ENTITY_ID_EX, split[1])) {
				return INVALID_ENTITY_ID + split[1];
			}
		}

		if( !validateFileDate( split[2] ) ) {
			return INVALID_FILE_DATE + split[2];
		}

		if(split[3].length() != 4 || !Pattern.matches(FieldsInfo.NUMERIC_EX, split[3])) {
			return INVALID_SEQUENCE + split[3];
		}
		
		return null;
		
	}
	
	public static boolean validateFileDate(String strDate) {
		
		SimpleDateFormat sdfrmt = new SimpleDateFormat(CommonConstants.FILE_DATE);
	    sdfrmt.setLenient(false);
	    try {
	        Date javaDate = sdfrmt.parse(strDate); 
	        
	        if( javaDate.after(new Date()) ) {
	        	return false;
	        }
	    }
	    catch (ParseException e) {
	        return false;
	    }
		return true;
		
	}
	
	public static String validateFileDate(String fileDateStr, String fileSq, String dbDateStr, int dbSq) throws ParseException {
		SimpleDateFormat sdfrmt = new SimpleDateFormat(CommonConstants.FILE_DATE);
		sdfrmt.setLenient(false);
		Date fileDate = sdfrmt.parse(fileDateStr);
		Date dbDate = sdfrmt.parse(dbDateStr);

		 if( fileDate.after(dbDate) ) {
			 return null;
		 }
		 else if( dbDate.after(fileDate)) {
			 return INVALID_FILE_OLD_DATE + dbDate;
		 }
		 else {
			 if( Integer.parseInt(fileSq) <= dbSq) {
				 return INVALID_FILE_OLD_SEQ + dbSq;
			 }
		 }
		return null;
	}
	
}
