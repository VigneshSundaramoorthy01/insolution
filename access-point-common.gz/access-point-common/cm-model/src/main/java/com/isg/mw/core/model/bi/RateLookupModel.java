package com.isg.mw.core.model.bi;

import java.io.Serializable;
import java.time.OffsetDateTime;

import com.isg.mw.core.model.constants.ActiveFlag;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class RateLookupModel implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String entityId;
    
    private Double dccExchangeRate;
    
    private Double dccMarkUpPercent;
    
    private Integer dccTxnIsoCurrencyCode;

    private String dccTxnIsoCurrency;
    
    private Integer dccNoOfDecimals;

    private OffsetDateTime exchangeRateRecordCreationTime;
    		
    private OffsetDateTime exchangeRateExpiredateAndTime;//[Numeric, DDMMYYYYHH24MMSS]
    				
    private ActiveFlag status; // (Active, Inactive) [Alphabetic, 1]
    				
    private String remarks; //(e.g. Delay in receiving files for maker and checker) [Alphanumeric & Special characters, 100]
}