package com.isg.mw.core.model.eftpos;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class TempKeyModel implements Serializable {

    private String zpkUnderLMK;
    private String zpkUnderZMK;
    private String zpkKCV;
    private String zakUnderLMK;
    private String zakUnderZMK;
    private String zakKCV;
    private String zekUnderLMK;
    private String zekUnderZMK;
    private String zekKCV;

}
