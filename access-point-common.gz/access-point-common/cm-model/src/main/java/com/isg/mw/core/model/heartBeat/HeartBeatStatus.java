package com.isg.mw.core.model.heartBeat;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class HeartBeatStatus {

    private KafkaStatus kafkaStatus;
    private boolean status;
    private List<ServiceStatus> serviceStatus;
    private List<String> downService;
    private List<TargetStatus> targetStatuses;

    @Override
    public String toString() {
        return "{" +
                "kafkaStatus=" + kafkaStatus +
                ", status=" + status +
                ", serviceStatus=" + serviceStatus +
                ", downService=" + downService +
                ", endpointStatus=" + targetStatuses +
                '}';
    }

}
