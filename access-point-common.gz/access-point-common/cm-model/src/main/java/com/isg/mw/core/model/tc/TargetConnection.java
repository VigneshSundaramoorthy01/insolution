package com.isg.mw.core.model.tc;

import com.isg.mw.core.model.constants.ConnectionType;

import lombok.Getter;
import lombok.Setter;

/**
 * Switch configuration details
 * 
 * @author prasadj_t026
 *
 */

@Setter
@Getter
public class TargetConnection {

	private ConnectionType type;

	private String urlOrIp;

	private String portOrHeaders;

}
