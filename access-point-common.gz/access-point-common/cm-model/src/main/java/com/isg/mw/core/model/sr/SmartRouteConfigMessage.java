package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ConfigAction;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author shital3986
 *
 */
@Getter
@Setter
public class SmartRouteConfigMessage extends AcpTraceIdModel {

	private ConfigAction action;

	private SmartRouteConfigModel model;
}
