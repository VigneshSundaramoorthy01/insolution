package com.isg.mw.core.model.maps;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.isg.mw.core.model.constants.ActiveFlag;
import lombok.*;

/**
 * MerchantPanData
 *
 * @author husain
 */
@Getter
@Setter
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantPanData implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * Scheme Type
     */
    private String schemeType;

    /**
     * Merchant Pan
     */
    private  String mpan;

    /**
     * Active Flag
     */
    private ActiveFlag active;

}
