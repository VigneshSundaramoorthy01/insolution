package com.isg.mw.core.model.heartBeat;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TargetStatus {

    private Long targetId;
    private boolean tgtAlive;
    private boolean isSignon;
    private String targetIp;
    private String connectionName;



}

