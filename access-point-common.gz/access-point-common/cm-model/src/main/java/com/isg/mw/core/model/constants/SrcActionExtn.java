package com.isg.mw.core.model.constants;

/**
 * Source Action Extentions
 * 
 * @author rahul3983
 *
 */
public enum SrcActionExtn {

	ON,

	OFF,

	DEBUG,
	
	ON_NO_BATCH;

	/**
	 * converts String object to Source Action constant
	 * 
	 * 
	 * @param name - name of the action
	 * @return SrcActionExtn Enum constant
	 */
	public static SrcActionExtn getSrcActionExtn(String name) {
		if (ON.name().equals(name)) {
			return ON;
		} else if (OFF.name().equals(name)) {
			return OFF;
		} else if (DEBUG.name().equals(name)) {
			return DEBUG;
		} else if (ON_NO_BATCH.name().equals(name)) {
			return ON_NO_BATCH;
		}

		return null;

	}

}
