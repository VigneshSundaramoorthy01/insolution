package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class UserEntity {

    private String bankId;

    private String vpa;

    private String Name;

    private String aadharNo;

    private String emailId;

    private String userType;

    private String mId;

    private String tId;

    private String source;

    private List<UserAccountsEntity> userAccountsEntities;

     private UserMandates userMandates;

     private String status;

     private String type;

     private DeviceEntityAcq deviceEntity;

}
