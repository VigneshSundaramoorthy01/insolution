package com.isg.mw.core.model.mf;

import com.isg.mw.core.model.constants.ConfigStatus;
import com.isg.mw.core.model.constants.EditStatus;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.OwnerType;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Setter
@Getter
public class ConfigSummary {

	private String entityId;

	private String configName;

	private OwnerType ownerType;

	private boolean masterExists;

	private ConfigStatus configStatus;

	private LockedState lockedState;

	private boolean editCopyExists;

	private EditStatus editStatus;
}
