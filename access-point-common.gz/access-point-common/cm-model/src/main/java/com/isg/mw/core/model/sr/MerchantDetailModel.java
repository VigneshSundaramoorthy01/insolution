package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantDetailModel {
    private String mid;

    private String tid;

    private ActiveInactiveFlag merchantStatus;

    private String entityId;

    private Long targetId;

    private String targetMid;

    private String exceptionMessage;

    private String targetMerchantstatus;

    private String merchantName;

    private Long targetMerchantMasterId;

}
