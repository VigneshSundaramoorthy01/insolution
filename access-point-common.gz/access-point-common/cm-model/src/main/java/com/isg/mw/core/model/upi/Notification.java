package com.isg.mw.core.model.upi;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Notification implements Serializable {


    private static final long serialVersionUID = -295422703255886286L;

    private int templateId;
    private String comunicationMode;
    private String comunicationString;
    private String mobileNos;
    private String toEmailIds;
    private String ccEmailIds;
    private String bccEmailIds;
    private String serviceRequestId;
    private String serviceRequestNo;
    private int languageId=1;
    private String bankId;
    private String productCode;
    private String dataElements;
    private String subjectLine;

    private String msgStringDataElements;


}
