package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantPaymentModeDetails {

    private String mid;

    private String tid;

    private ActiveInactiveFlag status;

    private String merchantName;

    private String paymentMode;


}
