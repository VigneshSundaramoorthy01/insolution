package com.isg.mw.core.model.constants;

public enum PinTranslationType {

	STATIC,

	DYNAMIC;

	public static PinTranslationType getPinTranslationType(String type) {
		if (STATIC.name().equals(type)) {
			return STATIC;
		} else if (DYNAMIC.name().equals(type)) {
			return DYNAMIC;
		}
		return null;
	}

}
