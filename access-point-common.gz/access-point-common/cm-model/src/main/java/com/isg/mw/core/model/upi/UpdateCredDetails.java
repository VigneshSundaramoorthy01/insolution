package com.isg.mw.core.model.upi;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateCredDetails {

    private String oldCreds;

    private String newCreds;

    private String deviceId;

    private String vpa;

    private String accNum;

    private String mobileNo;

}
