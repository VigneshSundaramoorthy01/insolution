package com.isg.mw.core.model.constants;

/**
 * Merchant preferences for switch selection
 * 
 * @author prasad_t026
 *
 */
public enum MerchantPreference {

	ONUS,

	PRICING,

	MERCHANT_CHOICE;

	/**
	 * converts String object to MerchantPreference constant
	 * 
	 * @param mp - merchant preference in simple String
	 * @return - MerchantPreference Enum constant
	 */
	public static MerchantPreference getMerchantPreference(String mp) {
		if (ONUS.name().equals(mp)) {
			return ONUS;
		} else if (PRICING.name().equals(mp)) {
			return PRICING;
		} else if (MERCHANT_CHOICE.name().equals(mp)) {
			return MERCHANT_CHOICE;
		}

		return null;
	}
}