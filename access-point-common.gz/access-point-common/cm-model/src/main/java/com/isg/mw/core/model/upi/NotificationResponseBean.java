package com.isg.mw.core.model.upi;

public class NotificationResponseBean {

    private String statusCode;

    private String statusDesc;

    private String data;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "NotificationResponseBean{" +
                "statusCode='" + statusCode + '\'' +
                ", statusDesc='" + statusDesc + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}
