package com.isg.mw.core.model.sr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class TargetPaymentModesAdditionalData implements Serializable {
    private String statusUrl;
    private String externalIdentifier;
}
