package com.isg.mw.core.model.constants;

/**
 * Configuration actions
 * 
 * @author prasad_t026
 *
 */
public enum ConfigAction {

	ADD,

	MODIFY,

	INACTIVE,

	ACTIVATE,

	LOCKED,

	UN_LOCKED;

	/**
	 * converts String object to ConfigAction constant
	 * 
	 * @param name - name of the action
	 * @return - ConfigAction Enum constant
	 */
	public static ConfigAction getAction(String name) {
		if (ADD.name().equals(name)) {
			return ADD;
		} else if (MODIFY.name().equals(name)) {
			return MODIFY;
		} else if (INACTIVE.name().equals(name)) {
			return INACTIVE;
		} else if (ACTIVATE.name().equals(name)) {
			return ACTIVATE;
		} else if (LOCKED.name().equals(name)) {
			return LOCKED;
		} else if (UN_LOCKED.name().equals(name)) {
			return UN_LOCKED;
		}

		return null;
	}

}