package com.isg.mw.core.model.mt;

import java.time.OffsetDateTime;
import java.util.List;

import com.isg.mw.core.model.constants.LockedState;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Route Definition edit copy entity
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
@ToString
public class MessageTransformationConfigModel {

	/**
	 * Primary id of the route definition
	 */
	private Long id;

	/**
	 * entity id
	 */
	private String entityId;

	/**
	 * name of the route definition
	 */
	private String name;

	/**
	 * route definition rules
	 */
	private List<MessageMappingDefinition> rules;

	/**
	 * description about message format
	 */
	private String description;

	/**
	 * Created date and time
	 */
	private OffsetDateTime createdAt;

	/**
	 * Updated Date and time
	 */
	private OffsetDateTime updatedAt;

	/**
	 * Created by
	 */
	private String createdBy;

	/**
	 * Updated by
	 */
	private String updatedBy;

	/**
	 * Status of the routing definition
	 */
	private String status;

	/**
	 * Locked state of the routing definition
	 */
	private LockedState lockedState;
	
	private String remarks;
	
	private Long sourceId;

}
