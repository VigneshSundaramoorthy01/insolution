package com.isg.mw.core.model.tc;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.model.sc.SourceApiUrls;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TargetApiInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private Cybs cybs;
    private Amex amex;
    private Tpsl tpsl;
    private PayU payU;
    private IciciUpi iciciUpi;
    private Lyra lyra;
    private WibmoUrls wibmoUrls;
    private VizPay vizPay;
    private Hitachi hitachi;
    private MosambeeData mosambeeData;
    private Bms bms;



    @Getter
    @Setter
    public static class CommonFields implements Serializable {
        private String txnUrl;
        private String requestHost;
        private String techErrorCodes;
        private String returnUrl;
        private String encReturnUrl;
        private String apikey;
    }

    @Getter
    @Setter
    public static class Cybs extends CommonFields {
        private String merchantId;
        private String merchantKeyId;
        private String merchantSecretKey;
    }

    @Getter
    @Setter
    public static class Amex extends CommonFields {
        private String country;
        private String region;
        private String origin;
        private String routeIndicator;
        private String merchantId;
    }

    @Getter
    @Setter
    public static class Tpsl extends CommonFields {
        private String productCode;
        private String key;
        private String iv;
        private String merchantUrl;
        private String refundUrl;
        private String txnStatusUrl;
        private String lid;
    }

    @Getter
    @Setter
    public static class PayU extends CommonFields {
        private String tokenUrl;
        private String merchantUrl;
        private String refundUrl;
        private String clientId;
        private String clientSecret;
        private String checkTxnStatusUrl;
    }

    @Getter
    @Setter
    public static class IciciUpi extends CommonFields {
        private String createVpaUrl;
        private String merchantUrl;
        private String refundUrl;
        private String iciciNbCorporateUrl;
        private String iciciNbRetailUrl;
        private String qrApiUrl;
        private String checkTxnStatusUrl;
        private String merchantApiKey;
        private String verifyVPAUrl;
        private String retailMasterKey;
        private String accountDetailsUrl;
    }
    
    @Getter
    @Setter
    public static class Lyra extends CommonFields {
        private String chargeUrl;
        private String submitCardUrl;
        private String merchantUrl;
        private String merchantUpdateUrl;
        private String refundUrl;
        private String webHookUrl;
        private String txnStatusUrl;
        private String generateOtpUrl;
        private String verifyOtpUrl;
        private String merchantAuthUsername;
        private String merchantAuthPassword;
        private String merchantApiKey;
        private String posMerchantUrl;
        private String posUpdateMerchantUrl;
        private String posMerchantAuthUsername;
        private String posMerchantAuthPassword;
        private String posMerchantApiKey;
        @JsonProperty("return")
        private Return returnData;

        @Getter
        @Setter
        @ToString
        public static class Return implements Serializable{
            private String method = "POST";
            private String url;
            private String timeout = "600";
        }
    }

    @Getter
    @Setter
    @ToString
    public static class WibmoUrls implements Serializable{
        private String wibmoMerchantUrl;
        private String wibmoApiKey;
        private String clientId;
        private String clientApiUser;
        private String clientApiKey;
        private String salt;
        private String tokenizationUrl;
        private String tokenizationSecretKey;
        private String genAccessTokenApiUrl;
        private String genAccessTokenApiKey;
        private String genAccessTokenAuthUserName;
        private String genAccessTokenAuthPassword;
    }

    @Getter
    @Setter
    @ToString
    public static class VizPay implements Serializable{
        private String sourceId;
        private String participantId;
        private String clientName;
        private String clientKey;
        private String vizpayApiKey;
        private String accessTokenApiUrl;
        private String uploadTerminalApiUrl;
    }


    @Getter
    @Setter
    @ToString
    public static class Hitachi implements Serializable{
        private String sourceId;
        private String loginId;
        private String loginPassword;
        private String accessTokenApiUrl;
        private String hitachiMerchantUrl;
    }

    @Getter
    @Setter
    @ToString
    public static class MosambeeData implements Serializable{
        private String encryptionUrl;
        private String hmacUrl;
        private String registrationUrl;
        private String registrationEditUrl;
        private String updateStatusUrl;
        private String registerTidUrl;
        private String secretKey;
        private String nonce;
        private String hmacKey;
        private String clientId;
    }


    @Getter
    @Setter
    @ToString
    public static class Bms implements Serializable{
        private String initiateBmsRequestUrl;
    }
}
