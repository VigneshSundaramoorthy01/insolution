package com.isg.mw.core.model.upi;

import com.isg.npci.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Random;

@Component
public class SwitchUtil {

    @Autowired
    Environment environment;

    private final Logger logger = LogManager.getLogger(SwitchUtil.class);


    public String getProperty(String property){
        return ((environment.getProperty(property)==null) ? "UB" : environment.getProperty(property));
    }


    public <T>String getDeviceDetailValueFromKey(List<T> tags, String type, String key) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        DeviceType.Tag tag = new DeviceType.Tag();
        for(T obj : tags){
            String name = (String) obj.getClass().getMethod(getGetterMethodName(type)).invoke(obj);
            if(name.equalsIgnoreCase(key)){
                tag = (DeviceType.Tag)obj;
            }
        }
        return tag.getValue();

    }

    public <T>String getAccountDetailValueFromKey(List<T> details, String type,String key)  {
        AccountType.Detail detail = new AccountType.Detail();
        try {
            logger.debug("Entry in getAccountDetailValueFromKey with list::::" + details.toString() + " type:::" + type + " and key:::" + key);

            for (T obj : details) {
                String name = (String) obj.getClass().getMethod(getGetterMethodName(type)).invoke(obj);
                if (name.equalsIgnoreCase(key)) {
                    detail = (AccountType.Detail) obj;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return detail.getValue();
    }



    public <T>String getCredsDetailValueFromKey(List<T> creds, String type, String key) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        logger.debug("Entry in getCredsDetailValueFromKey with list::::"+creds.toString()+" type:::"+type+" and key:::"+key);
        CredsType.Cred cred= new CredsType.Cred();
        String credType = null;
        for(T obj : creds){
            credType  = (String) obj.getClass().getMethod(getGetterMethodName(type)).invoke(obj);
            if(credType.equalsIgnoreCase(key)){
                cred = (CredsType.Cred)obj;
            }
        }
        return cred.getData().getValue();
    }

    public <T> Ref getRefTagFromType(List<T> refs, String type) {
        logger.debug("Entry in getAccountDetailValueFromKey with list::::"+refs.toString()+" and type:::"+type);
        return refs.stream()
                .filter(obj -> obj instanceof Ref)
                .map(obj -> (Ref) obj)
                .filter(ref -> ref.getType().equals(type))
                .findFirst()
                .orElse(null);
    }

    public <T> PayeeType getPayeeTagFromType(List<T> payees, String type) {
        logger.debug("Entry in getAccountDetailValueFromKey with list::::"+payees.toString()+" and type:::"+type);
        return payees.stream()
                .filter(obj -> obj instanceof PayeeType)
                .map(obj -> (PayeeType) obj)
                .filter(payee -> payee.getType().equals(type))
                .findFirst()
                .orElse(null);
    }

    public <T> String getIdDetailValueFromKey(List<T> details, String key) {
        logger.debug("Entry in getIdDetailValueFromKey with list::::"+details.toString()+" and key:::"+key);
        return details.stream()
                .filter(obj -> obj instanceof RespValCust.Detail)
                .map(obj -> (RespValCust.Detail) obj)
                .filter(detail -> detail.getName().equalsIgnoreCase(key))
                .map(RespValCust.Detail::getValue)
                .findFirst()
                .orElse(null);
    }

    public <T>String getRegAccountDetailValueFromKey(List<T> details, String type,String key) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        logger.debug("Entry in getRegAccountDetailValueFromKey with list::::"+details.toString()+" type:::"+type+" and key:::"+key);

        ReqRegMob.RegDetails.Detail detail= new ReqRegMob.RegDetails.Detail();
        for(T obj : details){
            String name = (String) obj.getClass().getMethod(getGetterMethodName(type)).invoke(obj);
            logger.debug("In Itteration of name:::::::::"+name);
            if(name.equalsIgnoreCase(key)){
                logger.debug("Matched Name::::::"+key);
                detail = (ReqRegMob.RegDetails.Detail)obj;
            }
        }
        logger.debug("Data returned::::::"+detail.getValue());
        return detail.getValue();
    }
    private static String getGetterMethodName(String key) {
        return "get" + key.substring(0, 1).toUpperCase() + key.substring(1);
    }


    public String generateOTP(Integer otpLength) {
        // Generate random 4-digit OTP
        Random random = new Random();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < Long.valueOf(otpLength); i++) {
            otp.append(random.nextInt(10)); // Append a random digit (0-9)
        }

        return otp.toString();
    }

}
