package com.isg.mw.core.model.constants;

public interface LookupCodeFieldsInfo {
    /**
     * field name
     */
    String LOOKUP_CODE_NAME_FN = "Lookup Code";

    /**
     * name field data length
     */
    int LOOKUP_CODE_NAME_FL = 64;

    /**
     * name expression
     */
    String LOOKUP_CODE_EX = "^[A-Za-z0-9-_.' ]*";

    /**
     * field name
     */
    String LOOKUP_CODE_VALUE_NAME_FN = "Lookup Code Value";

    /**
     * name field data length
     */
    int LOOKUP_CODE_VALUE_NAME_FL = 64;

    /**
     * name expression
     */
    String LOOKUP_CODE_VALUE_EX = "^[A-Za-z0-9-_.' ]*";

    String ID_FN = "id";

    String LOOKUP_CODE_ID = "LookupCodeId";
    int LOOKUP_CODE_ID_FL = 18;



}
