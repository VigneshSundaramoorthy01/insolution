package com.isg.mw.core.model.maps;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;

import lombok.*;

/**
 * MapsInfoModel
 * 
 * @author sudharshan
 */
@Getter
@Setter
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MapsInfoModel extends AcpTraceIdModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Primary Id
	 */
	private Long id;

	/**
	 * Entity Id
	 */
	private String entityId;

	/**
	 * Merchant Identification Number
	 * Position 1 (Index 0)
	 */
	private String mid;

	/**
	 * Terminal identification Number
	 * Position 2 (Index 1)
	 */
	private String tid;

	/**
	 * Merchant Name
	 * Position 3 (Index 2)
	 */
	private String merchantName;
	
	/**
	 * Merchant Address
	 * Position 4 (Index 3)
	 */
	private String merchantAddress;

	/**
	 * Merchant City
	 * Position 5 (Index 4)
	 */
	private String merchantCity;

	/**
	 * Acquiring Institution Country Code
	 * Position 6 (Index 5)
	 */
	private String acquiringInstitutionCountryCode;

	/**
	 * Merchant Zip Code
	 * Position 7 (Index 6)
	 */
	private String merchantZipCode;
	
	/**
	 * Acquirer Currency code
	 * Position 8 (Index 7)
	 */
    private String acquirerCurrencyCode;

    /**
	 * Merchant Type (MCC)
	 * Position 9 (Index 8)
	 */
	private String merchantType;
	
	/**
	 * Terminal Category Code (TCC)
	 * Position 10 (Index 9)
	 */
    private String terminalCategoryCode;
	
    /**
	 * Aggregator Flag
	 * Position 11 (Index 10)
	 */
	private String aggregatorFlag;
	
	/**
	 * Payment Facilitator Id
	 * Position 12 (Index 11)
	 */
	private String paymentFacilitatorId;
	
	/**
	 * Payment Facilitator Name
	 * Position 13 (Index 12)
	 */
	private String paymentFacilitatorName;
	
	/**
	 * Independent sale organization Id
	 * Position 14 (Index 13)
	 */
	private String independentSaleOrganizationId;

	/**
	 * Per Transaction Limit
	 * Position 15 (Index 14)
	 */
	private Long perTransactionLimit;

	/**
	 * Daily Limit
	 * Position 16 (Index 15)
	 */
	private Long dailyLimit;

	/**
	 * Weekly Limit
	 * Position 17 (Index 16)
	 */
	private Long weeklyLimit;

	/**
	 * Monthly Limit
	 * Position 18 (Index 16)
	 */
	private Long monthlyLimit;

	/**
	 * Merchant Status 
	 * Position 19 (Index 18)
	 */
	private ActiveInactiveFlag merchantStatus;

	/**
	 * Terminal Status
	 * Position 20 (Index 21)
	 */
	private ActiveInactiveFlag terminalStatus;
	
	/**
	 * Key Serial Number
	 * Position 21 (Index 20)
	 */
	private String ksn;

	/**
	 * Merchant currency code
	 * Position 22 (Index 21)
	 */
	private String merchantCurrencyCode;
	
	/**
	 * Merchant country code
	 * Position 23 (Index 22)
	 */
	private String merchantCountryCode; 
	
	/**
	 * Merchant state code
	 * Position 24 (Index 23)
	 */
	private String merchantStateCode;
	
	/**
	 * Merchant Short Country Code
	 * Position 25 (Index 24)
	 */
	private String merchantShortCountryCode;
	
	private ActiveInactiveFlag capStatus;

    private String capCity;

    private Long capCityLimit;

    private Long capMerLimit;

 	private OffsetDateTime createdAt;

	private OffsetDateTime updatedAt;

	private String merchantEmail;

	private String merchantPhoneNo;

	private List<MerchantPanData> merchantPanData;

	private String integrationType;
	
	private ActiveInactiveFlag posRefundStatus;
	
	private String mpgId;
	
	private Long tempRefundAmountLimit;
	
	private Long tempRefundCountLimit;
	
	private String tempRefundLimitExpiry;

    private Long defaultRefundAmountLimit;

    private Long defaultRefundCountLimit;

	private String turnover;

	private String signatoryPan;

	private String riskApproved;

	private String sbLanguage;

	private String emiAllowedFlag;

	private String merchantState;

	private String tradingName;

	private String seNumber;

	private String authorizedSignerDateOfBirth;
}
