package com.isg.mw.core.model.sr;
import com.isg.mw.core.model.constants.ActiveInactiveFlag;
import com.isg.mw.core.model.constants.TargetType;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class MerchantMasterModel implements Serializable {

    private Long merchantMasterId;

    private String mid;

    private String tid;

    private String merchantName;

    private String merchantEmail;

    private String merchantMobNo;

    private String merchantAddress;

    private Long merchantPincode;

    private String entityId;

    private String mcrEnabled;

    private Long mcrDefaultTargetId;

    private String secretKey;

    private String encryptionKey;

    private ActiveInactiveFlag convFeeFlag;

    private ActiveInactiveFlag status;

    private String merchantVpa;

    private String merchantStoreId;

    private String accountNo;

    private String ownershipType;

    private String merchantClass;

    private String accessCode;

    private String bankName;

    private String ifsc;

    private String accountType;

    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;
    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;

    private String terminalType;

    private String terminalModel;

    private String deviceSerialNo;

    private String valueAddedService;

    private String mccCode;

    //new
    private String merchantSector;

    private String gstNumber;

    private String websiteURL;

    private String panNumber;

    private String purposeOfPG;

    private String contactPerson;

    private String expectedNoOfTransactions;

    private String averageTicketSize;

    private String midCategory;

    private String entityType;

    private String businessType;

    private String productServices;

    private String websiteStatus;

    private String termsAndConditions;

    private String privacyPolicy;

    private String refundsAndCancellationPolicy;

    private String contactDetailsAvailable;

    private String productDetailAndPricingStructure;

    private String midType;

    private String merchantURL;

    private String countryName;

    private String integrationType;

    private Boolean isOnboardEnable = false;
    
    private Boolean isMosambeeAddEnable = false;

    private Boolean isMosambeeUpdateEnable = false;

    private Boolean isMosambeeTidRegEnable = false;

    private List<TargetType> targetTypes;

    private String merchantCity;

    private String merchantStateCode;

    private String merchantShortCountryCode;

    private String turnover;

    private String signatoryPan;

    private String riskApproved;

    private String sbLanguage;

    private String emiAllowedFlag;

    private String merchantState;

    private String tradingName;

    private String seNumber;

    private String authorizedSignerDateOfBirth;

    private int endOfset;
}

