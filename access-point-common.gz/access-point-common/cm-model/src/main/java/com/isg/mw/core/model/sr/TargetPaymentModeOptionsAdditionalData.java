package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.sc.SourceApiUrls;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class TargetPaymentModeOptionsAdditionalData implements Serializable {

    private String externalIdentifier;

}
