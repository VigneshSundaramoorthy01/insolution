package com.isg.mw.core.model.mf;

import com.isg.mw.core.model.constants.ConfigStateResponse;
import com.isg.mw.core.model.constants.OwnerType;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Setter
@Getter
public class ValidationSummary {

	private String entityId;

	/**
	 * configuration name
	 */
	private String ownerName;

	/*
	 * configuration type
	 */
	private OwnerType ownerType;

	private ConfigStateResponse response;

}
