package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserAccountsEntity {


    private String dailyTotalTxnLimit;

    private String accountRefNumber;

    private String maskedAccNumber;

    private String ifscCode;

    private AccountTypesEntity accountTypesEntity;

    private PinStoreEntity pinStoreEntity;


}
