package com.isg.mw.core.model.audit;

import java.io.Serializable;
import java.time.OffsetDateTime;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import lombok.Getter;
import lombok.Setter;

/**
 * AuditInfoModel
 * 
 * @author sudharshan
 */
@Getter
@Setter
public class AuditInfoModel extends AcpTraceIdModel implements Serializable {

	private static final long serialVersionUID = 1L;

	// Created by
	private String createdBy;

	// Updated by
	private String updatedBy;

	// Created date
	private OffsetDateTime createdAt;

	// Updated date
	private OffsetDateTime updatedAt;

}
