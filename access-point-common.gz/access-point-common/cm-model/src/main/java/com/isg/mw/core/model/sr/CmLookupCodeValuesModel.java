package com.isg.mw.core.model.sr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Getter
@Setter
@ToString
public class CmLookupCodeValuesModel implements Serializable {

    private Long lookupCodeValueId;

    private Long lookupCodeId;

    private String lookupCodeValue;
    /**
     * Created date and time
     */
    private OffsetDateTime createdAt;

    /**
     * Updated Date and time
     */
    private OffsetDateTime updatedAt;

    /**
     * Created by
     */
    private String createdBy;

    /**
     * Updated by
     */
    private String updatedBy;


}
