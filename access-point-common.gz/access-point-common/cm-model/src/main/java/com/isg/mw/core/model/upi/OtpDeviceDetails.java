package com.isg.mw.core.model.upi;


import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class OtpDeviceDetails implements Serializable {

    private String deviceId;

    private String mobNumber;

    private String otp;

    private String app;

    private String acNum;

    private String acType;

    private String ifsc;

   private int optCounter;
    

}
