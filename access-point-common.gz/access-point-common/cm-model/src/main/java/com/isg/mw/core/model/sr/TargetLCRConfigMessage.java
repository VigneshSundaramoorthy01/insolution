package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ConfigAction;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * 
 * @author shital3986
 *
 */
@Getter
@Setter
public class TargetLCRConfigMessage extends AcpTraceIdModel implements Serializable {

	private ConfigAction action;

	private TargetLCRConfigModel model;
}
