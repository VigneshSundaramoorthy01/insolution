package com.isg.mw.core.model.constants;

public interface TargetLCRFieldsInfo {

    String ALPHA_EX = "^[a-zA-Z]*";

    String ALPHA_NUMERIC_EX = "^[a-zA-Z0-9]*";

    String NUMERIC_EX = "^[0-9]*";

    String ANS_EX = "^[a-zA-Z0-9 ]*";

    /**
     * field Remarks
     */
    String REMARKS_FN = "Remarks";


    /**
     * update status values
     */
    String[] UPDATE_STATUS_VALUES = { EditStatus.Inprogress.name(), ConfigStatus.Active.name(),
            ConfigStatus.Inactive.name() };

    /**
     * field name status ( used in verify api
     */
    String UPDATE_STATUS_FN = "status";


    /**
     * field targetId
     */
    String TARGET_ID_FN = "targetId";

    /**
     * targetId field data length
     */
    int TARGET_ID_FL = 18;

    /**
     * field targetId
     */
    String PAYMENT_MODE_ID_FN = "paymentModeId";
    /**
     * targetId field data length
     */
    int PAYMENT_MODE_ID_FL = 18;

    /**
     * field paymentModeOptionId
     */
    String PAYMENT_MODE_OPTION_ID_FN = "paymentModeOptionId";
    /**
     * paymentModeOptionId field data length
     */
    int PAYMENT_MODE_OPTION_ID_FL = 18;

    /**
     * field cardType
     */
    String CARD_TYPE_FN = "cardType";
    /**
     * cardType data length
     */
    int CARD_TYPE_FL = 64;
    String MCC_CATGORY_FN = "mccCategory";
    /**
     * mccCategory field data length
     */
    int MCC_CATGORY_FL = 64;
    /**
     * field pricePct
     */
    String PRICE_PCT_FN = "pricePct";

    /**
     * pricePct field data length
     */
    int PRICE_PCT_FL = 10;

    /**
     * field priceFixed
     */
    String PRICE_FIXED_FN = "priceFixed";
    /**
     * priceFixed field data length
     */
    int PRICE_FIXED_FL = 10;

    /**
     * field below2000PricePct
     */
    String BELOW_2000_PRICE_PCT_FN = "below2000PricePct";
    /**
     * below2000PricePct field data length
     */
    int BELOW_2000_PRICE_PCT_FL = 10;

    /**
     * field below2000PriceFixed
     */
    String BELOW_2000_PRICE_FIXED_FN = "below2000PriceFixed";
    /**
     * below2000PriceFixed field data length
     */
    int BELOW_2000_PRICE_FIXED_FL = 10;

    /**
     * field status
     */
    String STATUS_FN = "status";
    /**
     * status field data length
     */
    int STATUS_FL = 10;

    String ID_FN = "id";

    String START_DATE_FN = "startDate";
    String END_DATE_FN = "endDate";

}
