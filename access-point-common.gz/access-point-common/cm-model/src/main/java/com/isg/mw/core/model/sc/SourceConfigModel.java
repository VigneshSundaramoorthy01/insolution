package com.isg.mw.core.model.sc;

import java.time.OffsetDateTime;
import java.util.List;

import com.isg.mw.core.model.constants.ConnectionType;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.SourceProcessor;
import com.isg.mw.core.model.constants.SrcActionExtn;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;

import lombok.Getter;
import lombok.Setter;

/**
 * source configuration details
 *
 * @author prasad_t026
 */
@Getter
@Setter
public class SourceConfigModel {

    private Long id;

    private String entityId;

    private String name;

    private String defaultTarget;

    private String[] targetPreferences;

    private ConnectionType connectionType;

    private String portOrUri;

    private OffsetDateTime createdAt;

    private OffsetDateTime updatedAt;

    private String createdBy;

    private String updatedBy;

    private String status;

    private boolean merchantValidation;

    private boolean issuerBinValidation;

    private boolean acquirerBinValidation;

    private boolean dataSecurityModule;

    private boolean msgTransfomation;

    private SrcActionExtn txnLogging;

    private LockedState lockedState;

    private List<MessageFormatConfigModel> messageFormats;

    private TargetType sourceType;

    private int requestTimeout;

    private String preAuthPerLimit;

    private String preAuthTimePeriod;

    private SourceProcessor sourceProcessor;

    private String remarks;

    private List<SourceSftpParams> sftp_params;
    
    private SourceAdditionalData additionalData;
}
