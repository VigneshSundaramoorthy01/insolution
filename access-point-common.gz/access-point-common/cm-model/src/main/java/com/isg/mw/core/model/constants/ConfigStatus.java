package com.isg.mw.core.model.constants;

/**
 * Config status
 * 
 * @author prasad_t026
 */
public enum ConfigStatus {

	Inactive,

	Active;

	/**
	 * converts String object to ConfigStatus constant
	 * 
	 * @param name - name of the status
	 * @return - ConfigStatus Enum constant
	 */
	public static ConfigStatus getStatus(String name) {
		if (Inactive.name().equals(name)) {
			return Inactive;
		} else if (Active.name().equals(name)) {
			return Active;
		}

		return null;
	}

}