package com.isg.mw.core.model.heartBeat;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class KafkaStatus {

    private String message;
    private boolean status;
    private List<KafkaTopicStatus> kafkaTopicStatus = new ArrayList<>();
    private String clusterId;
    private String controller;

    public String toString() {
        return "{" +
                "message='" + message + '\'' +
                ", status=" + status +
                ", kafkaTopicStatus=" + kafkaTopicStatus +
                '}';
    }

}
