package com.isg.mw.core.model.mf;

import java.time.OffsetDateTime;

import com.isg.mw.core.model.constants.OwnerType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author prasadj_t026
 *
 */
@Setter
@Getter
@ToString
public class MessageFormatConfigModel {

	private Long id;

	private Long ownerId;

	private OwnerType ownerType;

	private String msgType;

	private String msgFormat;

	private String description;

	private String createdBy;

	private String updatedBy;

	private OffsetDateTime createdAt;

	private OffsetDateTime updatedAt;

	private BusinessRule businessRule;

}
