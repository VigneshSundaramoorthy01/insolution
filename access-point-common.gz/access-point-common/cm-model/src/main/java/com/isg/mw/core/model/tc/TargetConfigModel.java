package com.isg.mw.core.model.tc;

import java.time.OffsetDateTime;
import java.util.List;

import com.isg.mw.core.model.common.NettyConfig;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.PinTranslationType;
import com.isg.mw.core.model.constants.Target;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.mf.MessageFormatConfigModel;

import lombok.Getter;
import lombok.Setter;

/**
 * Switch configuration details
 * 
 * @author prasadj_t026
 *
 */

@Setter
@Getter
public class TargetConfigModel {

	private Long Id;

	private String entityId;

	private String name;

	private TargetType targetType;

	private OffsetDateTime createdAt;

	private OffsetDateTime updatedAt;

	private String status;

	private String createdBy;

	private String updatedBy;

	private LockedState lockedState;

	private List<TargetConnection> connections;

	private List<MessageFormatConfigModel> messageFormats;

	private boolean signonRequired = true;

	private int heartBeatDelay = 30000;

	private String groupSignonId;

	private int requestTimeout;

	private int connectTimeout;
	
	private PinTranslationType pinTranslationType;
	
	private NettyConfig nettyParameters;
	
	private Target target;
	
	private String remarks;

	private TargetAdditionalData additionalData;

	private Double processingFee;

	private boolean heartBeatStatus = false;
	
	private boolean isConnectionAlive = false;

}
