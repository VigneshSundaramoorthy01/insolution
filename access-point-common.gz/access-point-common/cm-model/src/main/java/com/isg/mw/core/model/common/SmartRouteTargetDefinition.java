package com.isg.mw.core.model.common;

import com.isg.mw.core.model.constants.TargetPriority;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author shital3986
 *
 */
@Getter
@Setter
public class SmartRouteTargetDefinition {

	private Long targetId;
	
	private TargetPriority targetPriority;
	
	private Long switchToPrimaryInterval;
	
	private Double defaultRouteShare;
	
	private Double minRouteShare;
	
	private Double targetCost;
}
