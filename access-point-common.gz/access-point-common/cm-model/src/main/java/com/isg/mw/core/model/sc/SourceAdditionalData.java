package com.isg.mw.core.model.sc;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SourceAdditionalData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private SourceApiUrls apiUrls;
	
	private String cutOffTime;
	
	private String mpgid;

	private String merchantOnboardFlag;

	private List<String> integrationTypes;

}
