package com.isg.mw.core.model.bi;

import java.io.Serializable;
import java.math.BigInteger;

import com.isg.mw.core.model.constants.TargetType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class BillingCurrencyModel implements Serializable {
	private static final long serialVersionUID = 1L;

	private TargetType schemeName;// [Alphabetic, 15 ]

	private String fileIdentifier;//[Alphanumeric, 20]
	
	private BigInteger accountLowRange;//[Numeric, 18]
	
	private BigInteger accountHighRange;//[Numeric, 18]
	
	private Integer billingIsoCurrencyCode;// [Numeric, 3]
	
	private int dccIndicator;//[Numeric 1]
}
