package com.isg.mw.core.model.constants;

public enum RouteType {

	SUCCESS_RATIO_STATIC,

	SUCCESS_RATIO_DYNAMIC,

	LEAST_COST,

	SUCCESS_RATIO_DYNAMIC_LCR;

	public static RouteType getRouteType(String name) {
		if (SUCCESS_RATIO_STATIC.name().equals(name)) {
			return SUCCESS_RATIO_STATIC;
		} else if (SUCCESS_RATIO_DYNAMIC.name().equals(name)) {
			return SUCCESS_RATIO_DYNAMIC;
		} else if (LEAST_COST.name().equals(name)) {
			return LEAST_COST;
		}else if (SUCCESS_RATIO_DYNAMIC_LCR.name().equals(name)) {
			return SUCCESS_RATIO_DYNAMIC_LCR;
		}

		return null;
	}
}
