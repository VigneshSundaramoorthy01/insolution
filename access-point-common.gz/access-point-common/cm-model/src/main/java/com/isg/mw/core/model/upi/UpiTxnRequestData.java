package com.isg.mw.core.model.upi;

import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UpiTxnRequestData implements Serializable {


    private String traceId;

    private String txnId;

    private String requestDataDetails;

    private String requestType;

    private String responseDataDetails;
}

