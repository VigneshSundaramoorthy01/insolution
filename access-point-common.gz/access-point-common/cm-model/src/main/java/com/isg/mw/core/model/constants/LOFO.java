package com.isg.mw.core.model.constants;

/**
 * purpose of the enum is to refer bin type in file record field LOFO 
 * L - Local Bin
 * F - International Bin
 * 
 * @author prasad_t026
 *
 */
public enum LOFO {

	L,

	F;

	/**
	 * converts String object to LOFO constant
	 * 
	 * @param name - string value of the LOFO
	 * @return - LOFO Enum constant
	 */
	public static LOFO getLofo(String name) {
		if (L.name().equals(name)) {
			return L;
		} else if (F.name().equals(name)) {
			return F;
		}

		return null;
	}


}
