package com.isg.mw.core.model.upi;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@ToString

public class OtpReqModel implements Serializable {

    private String deviceId;

    private String mobNum;

    private String accNum;

    public OtpReqModel() {
    }
}
