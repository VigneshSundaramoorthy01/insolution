package com.isg.mw.core.model.sc;

import lombok.Getter;
import lombok.Setter;

/**
 * SftpParams configuration details
 *
 * @author harika4294
 */
@Getter
@Setter
public class SourceSftpParams {

    private String username;

    private String password;

    private String key;

    private String location;

    private String eftposfilelocation;

}