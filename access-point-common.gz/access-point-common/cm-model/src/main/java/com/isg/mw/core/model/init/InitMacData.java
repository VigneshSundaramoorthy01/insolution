package com.isg.mw.core.model.init;

import java.io.Serializable;
import java.util.List;

import com.isg.mw.core.model.sc.SourceConfigModel;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class InitMacData implements Serializable {
	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;

	private String message;

	private List<SourceConfigModel> macList;

}