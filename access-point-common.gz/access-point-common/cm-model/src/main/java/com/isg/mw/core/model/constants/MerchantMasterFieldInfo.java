package com.isg.mw.core.model.constants;

public interface MerchantMasterFieldInfo {

    String MID_FN = "mid";
    int MID_FL = 15;
    String MID_EX = null;

    String ENTITY_ID_EX ="^[a-zA-Z0-9]*";
    String ENTITY_ID_FN = "entityId";
    int ENTITY_ID_FL = 32;

    String MCR_ENABLED_EX = "^[YN]$";

    String MCR_ENABLED_FN = "mcrEnabled";
    int MCR_ENABLED_FL = 1;

    String MCR_DEFAULT_TARGET_ID_FN ="mcrDefaulTargetId" ;
    int MCR_DEFAULT_TARGET_FL = 18;

    String ID_FN="merchantMasterId";

    int ID_FL = 18;

    String TARGET_ID_FN = "targetId";
    int TARGET_ID_FL = 18;

    String SECRET_KEY_EX = null;
    String SECRET_KEY_FN = "secretKey";
    int SECRET_KEY_FL = 1024 ;
    boolean SECRET_KEY_MA = false ;
    String ENCRYPTION_KEY_EX = null ;
    String ENCRYPTION_KEY_FN = "encryptionKey";
    int ENCRYPTION_KEY_FL = 1024;
    boolean ENCRYPTION_KEY_MA = false;
    String CONV_FEE_FLAG_FN = "convFeeFlag";
    int PAY_MODE_ID_FL = 10;
    String PAY_MODE_ID_FN ="paymentModeId" ;

    int PAY_MODE_OPTIONS_ID_FL = 10;
    String PAY_MODE_OPTIONS_ID_FN ="paymentModeOptionsId" ;
    String  MERCHANT_PAYMENT_MODE_ID_FN ="merchantPaymentModeId";

    int  MERCHANT_PAYMENT_MODE_ID_FL =18;

    String UPDATE_STATUS_FN = "status";
    String[] UPDATE_STATUS_VALUES = {  ConfigStatus.Active.name(),
            ConfigStatus.Inactive.name(),EditStatus.Inprogress.name() };
    String  MERCHANT_PAYMENT_MODE_OPTIONS_ID_FN ="merchantPaymentModeOptionsId";


    String STATUS_FN ="status";

    String TARGET_MID_FN = "targetMid";
    int TARGET_MID_FL = 15;
    String TARGET_MID_EX = null;
    String TARGET_MERCHANT_MASTERID_FN="targetMerchantMasterId";

    String MERCHANT_NAME_EX=null;
    String MERCHANT_NAME_FN="merchantName";
    int MERCHANT_NAME_FL=128;

    //String MERCHANT_EMAIL_EX="(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
    String MERCHANT_EMAIL_EX=null;
    String MERCHANT_EMAIL_FN="merchantEmail";
    int MERCHANT_EMAIL_FL=128;

    //String MERCHANT_MOB_NO_EX="^(\\+\\d{1,3}( )?)?((\\(\\d{1,3}\\))|\\d{1,3})[- .]?\\d{3,4}[- .]?\\d{4}$";
    String MERCHANT_MOB_NO_EX=null;
    String MERCHANT_MOB_NO_FN="merchantMobNo";
    int MERCHANT_MOB_NO_FL=28;


    String MERCHANT_ADDRESS_EX=null;
    String MERCHANT_ADDRESS_FN="merchantAddress";
    int MERCHANT_ADDRESS_FL=1000;

    String MERCHANT_PINCODE_FN="merchantPincode";
    int MERCHANT_PINCODE_FL=10;

    String MERCHANT_VPA_EX=null;
    String MERCHANT_VPA_FN="merchantEmail";
    int MERCHANT_VPA_FL=200;

    String MERCHANT_STORE_ID_EX=null;
    String MERCHANT_STORE_ID_FN="merchantEmail";
    int MERCHANT_STORE_ID_FL=512;

    String ACCOUNT_NO_EX = null;
    String ACCOUNT_NO_FN = "accountNo";
    int ACCOUNT_NO_FL = 64;
    String OWNERSHIP_TYPE_EX = null ;
    String OWNERSHIP_TYPE_FN ="ownershipType" ;
    int OWNERSHIP_TYPE_FL = 128;
    boolean OWNERSHIP_TYPE_MA = false;
    String MERCHANT_CLASS_EX = null;
    String MERCHANT_CLASS_FN = "merchantClass";
    int MERCHANT_CLASS_FL = 64;
    String ACCESS_CODE_EX =null ;
    String ACCESS_CODE_FN = "accessCode";
    int ACCESS_CODE_FL = 100;
    boolean ACCESS_CODE_MA = false;


    String MERCHNAT_VPA_FN = "merchantVpa";
    int MERCHNAT_VPA_FL = 200;
    String MERCHNAT_VPA_EX = null;

    String KEY_FN = "key";
    int KEY_FL = 1024;
    String KEY_EX = null;

    String SALT_FN = "SALT";
    int SALT_FL = 1024;
    String SALT_EX = null;


    // FIELDS BELONGS TO MERCHANT MASTER
    //String GST_EX = "^[a-zA-Z0-9]*$";
    String GST_EX = null;
    String GST_NO_FN = "GST number";
    boolean GST_NO_MA = false;
    int GST_NO_FL = 15;

    // String WEBSITE_URL_EX = "^[a-zA-Z0-9;,\\?/:@&=+\\$_.!~*'()#-]*$";
    String WEBSITE_URL_EX = null;
    String WEBSITE_URL_NO_FN = "Website URL";
    boolean WEBSITE_URL_NO_MA = false;
    int WEBSITE_URL_NO_FL = 500;

    //String CONTACT_PERSON_EX = "^[a-zA-Z0-9&/(').;-]*$";
    String CONTACT_PERSON_EX = null;
    String CONTACT_PERSON_FN = "Contact Person";
    boolean CONTACT_PERSON_MA = false;
    int CONTACT_PERSON_FL = 128;

    //String PAN_NUMBER_EX = "^[a-zA-Z0-9]*$";
    String PAN_NUMBER_EX = null;
    String PAN_NUMBER_FN = "Pan Number";
    boolean PAN_NUMBER_MA = false;
    int PAN_NUMBER_FL = 10;

    String BUSINESS_TYPE_EX = null;
    String BUSINESS_TYPE_FN = "Business Type";
    boolean BUSINESS_TYPE_MA = false;
    int BUSINESS_TYPE_FL = 100;

    // String MERCHANT_URL_EX = "^[a-zA-Z0-9;,\\?/:@&=+\\$_.!~*'()#-]*$";
    String MERCHANT_URL_EX = null;
    String MERCHANT_URL_FN = "Merchant Url";
    boolean MERCHANT_URL_MA = false;
    int MERCHANT_URL_FL = 500;

    String TERMINAL_TYPE_EX = null;
    String TERMINAL_TYPE_FN = "Terminal Type";
    boolean TERMINAL_TYPE_MA = false;
    int TERMINAL_TYPE_FL = 100;

    String TURNOVER_EX =null ;
    String TURNOVER_FN = "turnover";
    int TURNOVER_FL = 128;
    boolean TURNOVER_MA = true;

    String SIGNATORY_PAN_EX =null ;
    String SIGNATORY_PAN_FN = "signatoryPan";
    int SIGNATORY_PAN_FL = 30;
    boolean SIGNATORY_PAN_MA = true;

    String SE_NUMBER_EX ="^[a-zA-Z0-9]*$" ;
    String SE_NUMBER_FN = "seNumber";
    int SE_NUMBER_FL = 100;
    boolean SE_NUMBER_MA = false;

    String AUTHORIZED_SIGNER_DATE_OF_BIRTH_EX ="\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])*" ;
    String AUTHORIZED_SIGNER_DATE_OF_BIRTH_FN = "authorizedSignerDateOfBirth";
    int AUTHORIZED_SIGNER_DATE_OF_BIRTH_FL = 10;
    boolean AUTHORIZED_SIGNER_DATE_OF_BIRTH_MA = false;

    String TRADING_NAME_EX =null ;
    String TRADING_NAME_FN = "tradingName";
    int TRADING_NAME_FL = 128;
    boolean TRADING_NAME_MA = false;
}
