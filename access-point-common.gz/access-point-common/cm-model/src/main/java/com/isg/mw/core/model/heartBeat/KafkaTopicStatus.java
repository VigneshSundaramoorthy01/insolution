package com.isg.mw.core.model.heartBeat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KafkaTopicStatus {

    private boolean status;
    private String topicName;
    private String message;
    private kafkaTopicDetails kafkaTopicDetails;


    @Override
    public String toString() {
        return "{" +
                "status=" + status +
                "message=" + message +
                ", topicName='" + topicName + '\'' +
                ", details='" + kafkaTopicDetails + '\'' +
                '}';
    }

}
