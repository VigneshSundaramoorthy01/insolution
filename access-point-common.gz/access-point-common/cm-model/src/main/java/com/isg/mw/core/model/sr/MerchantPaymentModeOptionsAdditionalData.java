package com.isg.mw.core.model.sr;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantPaymentModeOptionsAdditionalData implements Serializable {

    private String statusUrl;
    private String externalIdentifier;

}
