/**
 * 
 */
package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 *
 */
public enum EditStatus {

	Inprogress,

	Submitted,
	
	Rejected;

	/**
	 * converts String object to EditStatus constant
	 * 
	 * @param name - name of the status
	 * @return - EditStatus Enum constant
	 */
	public static EditStatus getStatus(String name) {
		if (Inprogress.name().equals(name)) {
			return Inprogress;
		} else if (Submitted.name().equals(name)) {
			return Submitted;
		}else if (Rejected.name().equals(name)) {
			return Rejected;
		}

		return null;
	}

}
