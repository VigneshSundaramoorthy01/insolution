package com.isg.mw.core.model.eftpos;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Map;

@Getter
@Setter
@ToString
public class EFTPOSKeyModel implements Serializable {

    private static final long serialVersionUID = 1L;
    private String keySetId ="0000000000000002";
    private boolean signonKey = false;
    private boolean trxnLimitExceededKey = false;
    private boolean timeLimitExceededKey = false;
    private Map<String, Integer> targetName;
    private Map<String, KeyModel> targetKey;


}
