package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PinStoreEntity {

    private String pinOffset;//pin
}
