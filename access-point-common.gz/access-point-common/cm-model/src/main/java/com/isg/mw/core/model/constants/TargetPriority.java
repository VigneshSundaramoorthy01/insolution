package com.isg.mw.core.model.constants;

/**
 * 
 * @author shital3986
 *
 */
public enum TargetPriority {

	PRIMARY,

	SECONDARY;

	public static TargetPriority getTargetPriority(String name) {
		if (PRIMARY.name().equals(name)) {
			return PRIMARY;
		} else if (SECONDARY.name().equals(name)) {
			return SECONDARY;
		}
		return null;
	}
}
