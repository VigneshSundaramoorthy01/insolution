package com.isg.mw.core.model.md;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * CurrencyInfoModel
 * 
 * @author sudharshan
 */
@Getter
@Setter
public class CurrencyInfoModel implements Serializable {
	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ISO Numeric Currency Code
	 */
	private String currencyCode;

	/**
	 * ISO Alpha Currency Code
	 */
	private String currencyCodeAlpha;

	/**
	 * ISO Currency Name
	 */
	private String currencyName;

	/**
	 * Exponent
	 */
	private Integer exponent;

	/**
	 * Currency Decimals
	 */
	private Integer currencyDecimals;

}