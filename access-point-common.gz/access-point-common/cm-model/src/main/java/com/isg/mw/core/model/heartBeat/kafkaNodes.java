package com.isg.mw.core.model.heartBeat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class kafkaNodes {

    private int id;
    private String host;
    private int port;

}