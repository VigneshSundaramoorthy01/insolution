package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 *
 */
public interface RegularExpressionConstants {

	String URL_EX = "/((([A-Za-z]{3,9}:(?:\\/\\/)?)(?:[-;:&=\\+\\$,\\w]+@)?[A-Za-z0-9.-]+(:[0-9]+)?|(?:www.|[-;:&=\\+\\$,\\w]+@)[A-Za-z0-9.-]+)((?:\\/[\\+~%\\/.\\w-_]*)?\\??(?:[-\\+=&;%@.\\w_]*)#?(?:[\\w]*))?)/";

	String NAME_EX = "";

	String ENTITY_ID_EX = "";

	String USER_NAME_EX = ""; // use for creadedby or updatedby

	String IP_ADDRESS_EX = "";

	String PORT_EX = "";

}
