package com.isg.mw.core.model.upi;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserMandates {


    private Long user_mandate_id;

    private String startData;

    private String endDate;


    private String amount;


    private String amountRule;


    private String recurrencePattern;

    private String recurrenceRule;


    private String recurrenceRuleType;

    private String status;

    private String type;

}
