package com.isg.mw.core.model.constants;

/**
 * Source Validation Actions
 * 
 * @author rahul3983
 */

public enum SrcAction {

	ON,

	OFF;

	/**
	 * converts String object to Source Action constant
	 * 
	 * @param name - name of the action
	 * @return SrcAction Enum constant
	 */
	public static SrcAction getSrcAction(String name) {
		if (ON.name().equals(name)) {
			return ON;
		} else if (OFF.name().equals(name)) {
			return OFF;
		}

		return null;

	}

}
