package com.isg.mw.core.model.upi;


import lombok.Data;


@Data
public class OdirReqData {

    private String txnId;

    private String enquiryType;

}
