package com.isg.mw.core.model.bi;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * Scheme Destination Info Model
 * 
 * @author sudharshan
 */
@Getter
@Setter
public class SchemeDestinationInfoModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Scheme Name
	 */
	private String schemeName;
	/**
	 * Destination Id
	 */
	private String destinationId;
	/**
	 * Entity Id
	 */
	private String entityId;
}
