package com.isg.mw.core.model.icm;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Bin Info Model
 *
 * @author sudharshan
 * ICM Currency Conversion Model
 */
@Getter
@Setter
public class IcmCurrencyConversion extends AcpTraceIdModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private IcmCompositeKey icmCompositeKey;

    private String businessDate;

    private Double buyRate;

    private Double midRate;

    private Double sellRate;

    private String baseCurrencyCode;

    private Integer exponent;

    private String processId;


    @Override
    public String toString() {
        return "IcmCurrencyConversion{" +
                "acpTraceId=" + getAcpTraceId() +
                ", icmCompositeKey='" + icmCompositeKey + '\'' +
                ", businessDate=" + businessDate +
                ", buyRate=" + buyRate +
                ", midRate='" + midRate + '\'' +
                ", sellRate='" + sellRate + '\'' +
                ", baseCurrencyCode='" + baseCurrencyCode + '\'' +
                ", exponent='" + exponent + '\'' +
                ", processId='" + processId + '\'' +
                '}';
    }
}
