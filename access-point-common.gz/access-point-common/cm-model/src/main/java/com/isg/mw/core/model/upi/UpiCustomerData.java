package com.isg.mw.core.model.upi;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class UpiCustomerData implements Serializable {

    private String mobileNo; //ok

    private String vpa; //ok

    private String bankId;//rr

    private String deviceStatus; //nr

    private String userStatus; //nr

    private String userAccStatus; //nr

    private String source; //ok


    private String account_type; //rr

    private String daily_total_trx_amount_limit;//ok

    private String max_trx_amount_limit;//rr

    private String accRefNum;//ok

    private String masked_acc_number;//ok

    private String offset;//rr

    private String accountNo;//ok


    private Integer txnLimitFreq;

    private String ifsc;
}
