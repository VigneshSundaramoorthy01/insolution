package com.isg.mw.core.model.bi;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.OffsetDateTime;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.ActiveFlag;
import com.isg.mw.core.model.constants.LOFO;

import com.isg.mw.core.model.constants.Tokenize;
import lombok.Getter;
import lombok.Setter;

/**
 * Bin Info Model
 *
 * @author sudharshan
 */
@Getter
@Setter
public class BinInfoModel extends AcpTraceIdModel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * Primary Id
     */
    private Long id;
    /**
     * Scheme Name (Visa, Mastercard, Rupay)
     * Position 1 (Index 0)
     */
    private String schemeName;

    /**
     * Bin Number
     * Position 2 (Index 1)
     */
    private BigInteger binNumber;

    /**
     * Bin Low
     * Position 3 (Index 2)
     */
    private BigInteger binLow;

    /**
     * Bin High
     * Position 4 (Index 3)
     */
    private BigInteger binHigh;

    /**
     * Card Category (Consumer, Premium)
     * Position 5 (Index 4)
     */
    private String cardCategory;

    /**
     * Card Program (Debit, Credit, Prepaid, EMI)
     * Position 6 (Index 5)
     */
    private String cardProgram;

    /**
     * Card Brand (Classic, Platinum, Gold )
     * Position 7 (Index 6)
     */
    private String cardBrand;

    /**
     * Country Code (Numeric)
     * Position 8 (Index 7)
     */
    private String countryCodeN;

    /**
     * Country Code (Alpha)
     * Position 9 (Index 8)
     */
    private String countryCodeA;

    /**
     * Active Flag
     * Position 10 (Index 9)
     */
    private ActiveFlag activeFlag;

    /**
     * LOFO (‘L’ or ‘F' L – Local Bin F – International Bin)
     * Position 11 (Index 10)
     */
    private LOFO lofo;

    /**
     * Tokenize
     * Position 12 (Index 11)
     */
    private Tokenize tokenize;

    /**
     * Target Id
     */
    private String targetId;
    /**
     * Target Name
     */
    private String targetName;

    private OffsetDateTime createdAt;

    private OffsetDateTime updatedAt;

    private ActiveFlag leastCostActiveFlag;

    private BigInteger batchNumber;


    @Override
    public String toString() {
        return "BinInfoModel{" +
                "acpTraceId=" + getAcpTraceId() +
                "schemeName='" + schemeName + '\'' +
                ", binNumber=" + binNumber +
                ", binLow=" + binLow +
                ", binHigh=" + binHigh +
                ", targetId='" + targetId + '\'' +
                ", targetName='" + targetName + '\'' +
                ", activeFlag='" + activeFlag + '\'' +
                ", cardProgram='" + cardProgram + '\'' +
                ", batchNumber='" + batchNumber + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BinInfoModel binModel = (BinInfoModel) o;
        return this.getBinLow().compareTo(binModel.getBinLow()) > -1 && this.getBinLow().compareTo(binModel.getBinHigh()) < 1;
    }

    @Override
    public int hashCode() {
        return Integer.parseInt(String.valueOf(this.getBinLow()).substring(0, 6));
    }

}
