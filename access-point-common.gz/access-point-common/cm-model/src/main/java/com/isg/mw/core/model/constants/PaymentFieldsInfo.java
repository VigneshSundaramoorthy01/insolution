package com.isg.mw.core.model.constants;

public interface PaymentFieldsInfo {

    String PAYMENT_MODE_NAME_FN = "name";

    int PAYMENT_MODE_NAME_FL = 64;

    String PAYMENT_MODE_NAME_EX = "^[A-Za-z0-9-_.' ]*";

    String PAY_MODE_ID = "payModeId";

    int PAY_MODE_ID_FL = 18;

    String ID_FN = "id";

    String PAYMENT_MODE_DESC_EX = null;

    String PAYMENT_MODE_DESC_FN = "payModeDesc";

    int PAYMENT_MODE_DESC_FL = 1024;

    String MODE_OPTION_NAME_EX ="^[A-Za-z0-9-_.' ]*";

    String MODE_OPTION_NAME_FN = "name";

    int MODE_OPTION_NAME_FL = 64;

    String MODE_OPTION_DESC_EX = "^[A-Za-z0-9-_.' ]*";

    String MODE_OPTION_DESC_FN = "Description" ;

    int MODE_OPTION_DESC_FL = 1024;

    String MODE_OPTION_ID = "payModeOptionId";

    int MODE_OPTION_ID_FL = 18;

    String MODE_OPTION_FN = "id";
}
