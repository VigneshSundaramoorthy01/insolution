package com.isg.mw.core.model.mt;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Message mapping definition model
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
@ToString
public class MessageMappingDefinition {

	private String name;

	private MessageDefinition src;

	private MessageDefinition dest;

}
