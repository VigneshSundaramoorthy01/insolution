package com.isg.mw.core.model.md;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * CountryInfoModel
 * 
 * @author sudharshan
 */
@Getter
@Setter
public class CountryInfoModel implements Serializable {
	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ISO Numeric Country Code
	 */
	private String countryCode;

	/**
	 * ISO Country Name
	 */
	private String countryName;

	/**
	 * ISO Alpha Country (2-character) Code
	 */
	private String countryCodeAlpha2;

	/**
	 * ISO Alpha Country (3-character) Code
	 */
	private String countryCodeAlpha3;

	/**
	 * default currency code matching with currency id
	 */
	private String defaultCurrency;

}