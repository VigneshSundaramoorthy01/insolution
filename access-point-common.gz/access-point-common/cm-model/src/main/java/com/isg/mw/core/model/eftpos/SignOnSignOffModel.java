package com.isg.mw.core.model.eftpos;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class SignOnSignOffModel  implements Serializable {

    private boolean isSignOff = false;
    private boolean isReSignOn = false;
    private String targetIp;
}
