package com.isg.mw.core.model.sc;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Urls implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String url;
	
	private String object;
}