package com.isg.mw.core.model.common;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NettyConfig {

	/**
	 * Hsm netty parameters
	 */
	private int workerCount = 5;

	private Long requestTimeout = 10000L;

	private int connectTimeout = 15000;

	private int poolMaxActive= -1;

	private int poolMaxIdle= 100;

	private int poolMinEvictableIdle= 300000;

	private int poolMinIdle= 0;

	/**
	 * Target netty parameters
	 */
	private int packetLengthOffset;

	private int packetLengthFieldLength;

	private int packetLengthFieldAdjustment;

	private int packetInitialBytesToStrip;
	
	private int packetMaxFrameLength;

}
