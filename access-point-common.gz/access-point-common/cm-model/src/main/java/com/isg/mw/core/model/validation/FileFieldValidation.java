package com.isg.mw.core.model.validation;

import java.math.BigInteger;
import java.util.regex.Pattern;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.exception.ValidationException;

public class FileFieldValidation {


	public static final String FILE_FILED_DATA_MNDY_ERROR = "file.field.mndy.invalid.data";

	public static final String FILE_FILED_DATA_LENGTH_ERROR = "file.field.length.invalid.data";

	public static final String FILE_FILED_DATA_EXPR_ERROR = "file.field.expr.invalid.data";

	public static final String KSN_FILED_DATA_LENGTH_ERROR = "ksn.field.length.invalid.data";

	private static final String FILE_FILED_INVALID_DATA_ERROR = "file.field.invalid.data.error";

	public static void alphaFileValidation(String data, String fieldName, boolean mandatory,
										   int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_EX, fieldName, mandatory, length, index, rc );
	}

	public static void alphaNumaricFileValidtion(String data, String fieldName, boolean mandatory,
												 int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_NUMERIC_EX, fieldName, mandatory, length, index, rc );
	}

	public static void numaricFileValidation(String data, String fieldName, boolean mandatory,
											 int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.NUMERIC_EX, fieldName, mandatory, length, index, rc );
	}

	public static void numaricFileValidation(BigInteger data, String fieldName, boolean mandatory,
											 int length, int index, int rc) {
		fileRecordLongFieldValidation(data, FieldsInfo.NUMERIC_EX, fieldName, mandatory, length, index, rc );

	}

	public static void ansFileValidation(String data, String fieldName, boolean mandatory,
										 int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.ANS_EX, fieldName, mandatory, length, index, rc );
	}

	public static void alphaPreDefiendActiveFlagFileValidation(String data, String fieldName, boolean mandatory,
															   int length, int index, int rc) {
		UserDataValidations.stringPreDefiendDataValidation(data, FieldsInfo.ACTIVE_FLAG_VALUES, fieldName, mandatory);
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_EX, fieldName, mandatory, length, index, rc );
	}
	public static void alphaPreDefiendLofoFileValidation(String data, String fieldName, boolean mandatory,
														 int length, int index, int rc) {
		UserDataValidations.stringPreDefiendDataValidation(data, FieldsInfo.LOFO_VALUES, fieldName, mandatory);
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_EX, fieldName, mandatory, length, index, rc );
	}

	public static void alphaPreDefiendAITypeFileValidation(String data, String fieldName, boolean mandatory,
														   int length, int index, int rc) {
		UserDataValidations.stringPreDefiendDataValidation(data, FieldsInfo.AI_TYPE_VALUES, fieldName, mandatory);
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_EX, fieldName, mandatory, length, index, rc );
	}

	public static void alphaPreDefiendSchemeTypeFileValidation(String data, String[] values, String fieldName, boolean mandatory,
														 int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_EX, fieldName, mandatory, length, index, rc );
		UserDataValidations.stringPreDefiendDataValidation(data, values, fieldName, mandatory);
	}

	public static void alphaPreDefiendActiveFileValidation(String data, String fieldName, boolean mandatory,
															   int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.ALPHA_EX, fieldName, mandatory, length, index, rc );
		UserDataValidations.stringPreDefiendDataValidation(data, FieldsInfo.ACTIVE_FLAG_VALUES, fieldName, mandatory);
	}

	public static void fileHeadersValidation(String headerName, String headerConstant) {
		UserDataValidations.headerValidations(headerName,headerConstant);
	}

	public static void merchantAddFileValidation(String data, String fieldName, boolean mandatory,
												 int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.MERCHANT_ADDRESS_EX, fieldName, mandatory, length, index, rc );
	}

	public static void merchantNameFileValidation(String data, String fieldName, boolean mandatory,
												  int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.MERCHANT_NAME_EX, fieldName, mandatory, length, index, rc );
	}


	public static void ksnValidation(String data, String fieldName, boolean mandatory,
									 int length, int index, int rc) {
		fileRecordFieldValidation( data, FieldsInfo.NUMERIC_EX, fieldName, mandatory, length, index, rc );
		if(data.length() % 8 != 0 ) {
			throw new ValidationException(KSN_FILED_DATA_LENGTH_ERROR, fieldName, index, rc, data);
		}
	}


	public static void fileRecordFieldValidation(String data, String expression, String fieldName, boolean mandatory,
												 int length, int index, int rc ) {

		if (mandatory) {
			if (data == null || data.isEmpty()) {
				throw new ValidationException(FILE_FILED_DATA_MNDY_ERROR, fieldName, index, rc, data);
			}
		} else if (data == null || data.isEmpty()) {
			return;
		}
		if (data.length() > length) {
			throw new ValidationException(FILE_FILED_DATA_LENGTH_ERROR, fieldName, index, rc, data);
		}
		if (expression != null) {
			if (!Pattern.matches(expression, data)) {
				throw new ValidationException(FILE_FILED_DATA_EXPR_ERROR, fieldName, index, rc, data);
			}
		}

	}

	public static void fileRecordLongFieldValidation(BigInteger data, String expression, String fieldName, boolean mandatory,
													 int length, int index, int rc ) {

		if (mandatory) {
			if (data == BigInteger.ZERO) {
				throw new ValidationException(FILE_FILED_DATA_MNDY_ERROR, fieldName, index, rc, data);
			}
		} else if (data == BigInteger.ZERO) {
			return;
		}
		if (length != 0) {
			if (!isDataIsInGivenLength(data, length)) {
				throw new ValidationException(FILE_FILED_DATA_LENGTH_ERROR, fieldName, index, rc, data);
			}
		}
		if (data.compareTo(BigInteger.ZERO) == 0 || data.compareTo(BigInteger.ZERO) == -1){
			throw new ValidationException(FILE_FILED_INVALID_DATA_ERROR, fieldName, index, rc, data);
		}

	}

	private static boolean isDataIsInGivenLength(BigInteger data, int length) {
		int dataLength = data.toString().length();
		if (dataLength > length ) {
			return false;
		}
		return true;

	}

	public static String[] getTruncatedArray(String[] inData) {

		String[] outData = new String[inData.length];
		if(inData.length > 0) {
			for(int i = 0; i < inData.length; i++) {
				outData[i] = inData[i].trim();
			}
		}
		return outData;
	}
	public static void merchantEmailValidation(String data, String fieldName, boolean mandatory,
											   int length, int index, int rc){
	fileRecordFieldValidation(data, FieldsInfo.MERCHANT_EMAIL_EX, fieldName, mandatory, length, index, rc );
	}

	public static void merchantPhoneNoValidation(String data, String fieldName, boolean mandatory,
											   int length, int index, int rc){
		fileRecordFieldValidation(data, FieldsInfo.MERCHANT_PHONE_NO_EX, fieldName, mandatory, length,  index, rc );
	}

	public static void withoutExpressionFileValidtion(String data, String fieldName, boolean mandatory,
												 int length, int index, int rc) {
		fileRecordFieldValidation( data, null, fieldName, mandatory, length, index, rc );
	}

}
