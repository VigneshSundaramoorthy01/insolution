package com.isg.mw.core.model.constants;

/**
 *
 * @author prasad_t026
 *
 */
public interface FieldsInfo {

	String ALPHA_EX = "^[a-zA-Z]*";

	String ALPHA_NUMERIC_EX = "^[a-zA-Z0-9]*";

	String NUMERIC_EX = "^[0-9]*";

	String ANS_EX = "^[a-zA-Z0-9 ]*";


	/**
	 * field name it self name it refers configuration (Source/Target) name
	 */
	String NAME_FN = "name";

	/**
	 * name field data length
	 */
	int NAME_FL = 64;

	/**
	 * name expression
	 */
	String NAME_EX = "^[A-Za-z0-9-_.]*";

	/**
	 * field name is entityId all over the application is used as this name to refer
	 * entityId
	 */
	String ENTITY_ID_FN = "entityId";

	/**
	 * entity id data length
	 */
	int ENTITY_ID_FL = 32;

	/**
	 * entity id expression
	 */
	String ENTITY_ID_EX = "^[a-zA-Z0-9]*";

	/**
	 * field name it created by or updated by it refers name of the user who is
	 * doing the activity
	 */
	String USER_NAME_FN = "createdBy / updatedBy";

	/**
	 * user name field data length
	 */
	int USER_NAME_FL = 30;

	/**
	 * user name expression
	 */
	String USER_NAME_EX = "^[a-zA-Z0-9]*";

	/**
	 * field name is url
	 */
	String URL_FN = "url";

	/**
	 * url field data length
	 */
	int URL_FL = 800;

	/**
	 * url expression
	 */
	String URL_EX = "^(((((ht|f)tp(s?)))://)(%[0-9A-Fa-f]{2}|[-()_.!~*';/?:@&=+$,A-Za-z0-9])+)([).!';/?:,][[:blank:]])?$";
	/**
	 * field name is uri
	 */
	String URI_FN = "uri";

	/**
	 * uri field data length
	 */
	int URI_FL = 64;

	/**
	 * uri expression
	 */
	String URI_EX = "^[a-zA-Z0-9_]*";

	/**
	 * field name is ip address
	 */
	String IP_ADDRESS_FN = "ipAddress";

	/**
	 * ip address field data length
	 */
	int IP_ADDRESS_FL = 15;

	/**
	 * ip address expression
	 */
	// String IP_ADDRESS_EX = "[0-9.]*";
	String IP_ADDRESS_EX = "(^([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])\\.([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])\\.([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])\\.([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])$)";
	/**
	 * field name is port
	 */
	String PORT_FN = "port";

	/**
	 * port field data length
	 */
	int PORT_FL = 5;

	/**
	 * port expression
	 */
	String PORT_EX = "[0-9]*";

	/**
	 * field name ownerType
	 */
	String OWNER_TYPE_FN = "ownerType";

	/**
	 * field name SchemeType
	 */
	String SCHEME_TYPE_FN = "schemeType";

	/**
	 * field name lockedState
	 */
	String LOCKED_STATE_FN = "lockedState";

	/**
	 * field name encryptionKey
	 */
	String ENCRYPTION_KEY_FN = "encruyptionKey";

	/**
	 * field name decryptionKey
	 */
	String DECRYPTION_KEY_FN = "decruyptionKey";

	/**
	 * crypto key length
	 */
	int CRYPTO_KEY_LN = 128;

	/**
	 * field name connections
	 */
	String TARGET_CONNECTIONS_TYPE_FN = "connection.type";

	/**
	 * field name connections
	 */
	String TARGET_CONNECTIONS_FN = "connections";

	/**
	 * connection data length
	 */
	int TARGET_CONNECTIONS_LN = 4000;

	/**
	 * update status values
	 */
	String[] UPDATE_STATUS_VALUES = { EditStatus.Inprogress.name(), ConfigStatus.Active.name(),
			ConfigStatus.Inactive.name() };

	/**
	 * field name status ( used in verify api
	 */
	String UPDATE_STATUS_FN = "status";

	/**
	 * PinTranslation Type
	 */
	String[] PIN_TRANSLATION_TYPE_VALUES = { PinTranslationType.STATIC.name(), PinTranslationType.DYNAMIC.name() };

	/**
	 * field name pinTranslationType ( used in verify api
	 */
	String PIN_TRANSLATION_TYPE_FN = "pinTranslationType";

	/**
	 * field name is Default target
	 */
	String DEFAULT_TARGET_FN = "defaultTarget";

	/**
	 * field name is merchantPreferences
	 */
	String MERCHANT_PREFERENCES_FN = "merchantPreferences";

	/**
	 * field name is targetPreferences
	 */
	String TARGET_PREFERENCES_FN = "targetPreferences";

	/**
	 * field name type
	 */
	String SOURCE_CONECTION_TYPE_FN = "type";

	/**
	 * field name headerInfo
	 */
	String HEADER_INFO_FN = "headerInfo";

	/**
	 * header info field length
	 */
	int HEADER_INFO_FL = 400;

	/**
	 * field name txnLogging
	 */
	String TXN_LOGGING_FN = "txnLogging";

	/**
	 * field name is id all over the application is used as this name to refer
	 * database id
	 */
	String DB_ID_FN = "id";

	/**
	 * bdk length
	 */
	int BDK_FL = 32;

	/**
	 * Ipek length
	 */
	int IPEK_FL = 32;

	/**
	 * Awk length
	 */
	int AWK_FL = 32;

	/**
	 * Command Value length
	 */
	int COMMAND_VALUE_FL = 500;

	/**
	 * Hsm Command Value Expression
	 */
	String COMMAND_VALUE_EX = "^[a-zA-Z0-9{}]*";

	/**
	 * field name is group signon Id
	 */
	String GROUP_SIGNON_ID_FN = "groupSignonId";

	/**
	 * group signon Id field data length
	 */
	int GROUP_SIGNON_ID_FL = 32;

	/**
	 * group signon id expression
	 */
	String GROUP_SIGNON_ID_EX = "^[a-zA-Z0-9]*";

	/**
	 * Active flag Value
	 */
	String[] ACTIVE_FLAG_VALUES = { ActiveFlag.Y.name(), ActiveFlag.N.name() };

	/**
	 * Lofo Value
	 */
	String[] AI_TYPE_VALUES = { AiType.A.name(), AiType.I.name() };

	/**
	 * AI Value
	 */
	String[] LOFO_VALUES = { LOFO.F.name(), LOFO.L.name() };

	/**
	 * field name is cashAtPosLimit
	 */
	String CASH_AT_POS_LIMIT = "cashAtPosLimit";

	/**
	 * field Remarks
	 */
	String REMARKS_FN = "Remarks";

	/**
	 * status values
	 */
	String[] CONFIG_BY_STATUS_VALUES = {EditStatus.Inprogress.name(), EditStatus.Rejected.name(), EditStatus.Submitted.name(), ConfigStatus.Active.name(), ConfigStatus.Inactive.name(), LockedState.Unlocked.name(), LockedState.Locked.name()};

	/**
	 * field name status
	 */
	String CONFIG_BY_STATUS_FN = "status";

	static final String MANUFACTURE_MSG = "Configuration manufacture";
	static final String MODEL_MSG = "Configuration model";
	static final String HEADER_MSG = "Header";
	static final String PROTOCOL_MSG = "Protocol";
	static final String TYPE_MSG = "Type";
	static final String OFFSET_MSG = "Offset";
	static final String STATUS_MSG = "Configuration status";
	static final String IP_ADDRESS_MSG = "Socket ip address";
	static final String PORT_MSG = "Socket port number";
	static final String IP_ADDRESS_EXPR = "(\\b\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\b)";
	static final int PORT_VALUE = 99999;
	static final String SOURCE_OWNER_NAME_MSG = "Source Owner Name";
	static final String TARGET_OWNER_NAME_MSG = "Target Owner Name";
	static final String BDK_MSG = "Bdk";
	static final String IPEK_MSG = "Ipek";
	static final String AWK_MSG = "Awk";
	static final String HSMCOMMAND_MSG = "HsmCommand";
	static final String HSM_COMMAND_ARG_MSG = "Hsm Command Argument";
	static final String HSM_COMMAND_VALUE_MSG = "HsmService Command Value";
	static final String PACKET_LENGTH_OFFSET = "Packet length offset";
	static final String PACKET_LENGTH_FIELD_LENGTH = "Packet length field length";
	static final String PACKET_LENGTH_FIELD_ADJUSTMENT = "Packet length field adjustment";
	static final String PACKET_INITIAL_BYTES_TO_STRIP = "Packet initial bytes to strip";
	static final String PACKET_MAX_FRAME_LENGTH = "Packet max frame length";

	String ID_FN = "id";

	String SRC_ID_FN = "scrId";

	String[] ROUTE_TYPE_VALUES = {RouteType.SUCCESS_RATIO_STATIC.name(), RouteType.SUCCESS_RATIO_DYNAMIC.name(), RouteType.LEAST_COST.name()};

	String ROUTE_TYPE_FN = "routeType";

	String SUCCESS_RATIONAL_INTERVAL_FN = "successRatioInterval";

	int SUCCESS_RATIONAL_INTERVAL_FL = 12;

	String SUCCESS_RATIONAL_MAXTXNS_FN = "successRatioMaxTxns";

	int SUCCESS_RATIONAL_MAXTXNS_FL = 10;

	String ROURE_SWITCHING_PERCENT_FN = "routeSwitchingPercent";

	int ROURE_SWITCHING_PERCENT_FL = 10;

	String SUCCESS_THRESHOLD_FN = "successThreshold";

	int SUCCESS_THRESHOLD_FL = 12;

	String TARGET_ROUTE_CONFIG_FN = "targetRouteConfig";

	int TARGET_ROUTE_CONFIG_FL = 2000;

	String[] TARGET_PRIORITY_VALUES = {TargetPriority.PRIMARY.name(), TargetPriority.SECONDARY.name()};

	String TARGET_PRIORITY_FN = "targetPriorty";

	String TARGET_ID_FN = "targetId";

	/**
	 * field name is acquirerId 
	 */
	String ACQUIRER_ID_FN = "acquirerId";

	/**
	 * acquirer Id data length
	 */
	int ACQUIRER_ID_FL = 20;

	/**
	 * acquirer Id expression
	 */
	String ACQUIRER_ID_EX = "^[0-9]*";

	/**
	 * Alphanumeric with Possible Characters &/(').;-
	 */
	//String MERCHANT_ADDRESS_EX = "^[a-zA-Z0-9&/(').;-]*$";
	String MERCHANT_ADDRESS_EX = null;

	//String MERCHANT_NAME_EX = "^[a-zA-Z0-9&/(').;-]*$";
	String MERCHANT_NAME_EX = null;

	int SRC_ID_FL = 18;

	int TARGET_ID_FL = 18;
	
	 /**
		 * field name is fwdInstId 
		 */
		String FWDINSTID_FN = "fwdInstId";

		/**
		 * fwdInstId Id data length
		 */
		int FWDINSTID_FL = 20;

		/**
		 * fwdInstId Id expression
		 */
		String FWDINSTID_EX = "^[0-9]*";
		
		/**
		 * field name is Http method
		 */
		String HTTP_METHOD_NAME_FN = "httpMethod";

		/**
		 * Http method data length
		 */
		int HTTP_METHOD_NAME_FL = 10;

		/**
		 * Http method expression
		 */
		String HTTP_METHOD_NAME_EX = "^[A-Z]*";
		
		/**
		 * field name is businessClassName 
		 */
		String TARGET_URL_FN = "targetUrl";
		
		/**
		 * field name is url 
		 */
		String URLS_FN = "url";

		/**
		 * url Id data length
		 */
		int URLS_FL = 80;

		/**
		 * url Id expression
		 */
		String URLS_EX = null;
		
		/**
		 * field name is object 
		 */
		String OBJECT_FN = "object";

		/**
		 * object Id data length
		 */
		int OBJECT_FL = 32;

		/**
		 * object Id expression
		 */
		String OBJECT_EX = "^[a-zA-Z.]*";
		
		/**
		 * field name is targetMethod 
		 */
		String TARGET_METHOD_FN = "targetMethod";

		/**
		 * targetMethod Id data length
		 */
		int TARGET_METHOD_FL = 32;

		/**
		 * targetMethod Id expression
		 */
		String TARGET_METHOD_EX = "^[a-zA-Z/]*";


	//String MERCHANT_EMAIL_EX="(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
	//String MERCHANT_EMAIL_EX="^(?=.{1,64}@)[A-Za-z0-9_-]+(\\\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\\\.[A-Za-z0-9-]+)*(\\\\.[A-Za-z]{2,})$";
	String MERCHANT_EMAIL_EX = null;
	String MERCHANT_EMAIL_FN = "MerchantEmail";
	int MERCHANT_EMAIL_FL = 320;

	//String MERCHANT_PHONE_NO_EX="^(\\+\\d{1,3}( )?)?((\\(\\d{1,3}\\))|\\d{1,3})[- .]?\\d{3,4}[- .]?\\d{4}$";
	//String MERCHANT_PHONE_NO_EX="^[0-9]+$";
	String MERCHANT_PHONE_NO_EX = null;
	String MERCHANT_PHONE_NO_FN = "MerchantPhoneNo";
	int MERCHANT_PHONE_NO_FL = 15;

	//String MERCHANT_ACCOUNT_NO_EX="^[a-zA-Z0-9]*$";
	String MERCHANT_ACCOUNT_NO_EX = null;
	//String MERCHANT_CITY_EX = "^[a-zA-Z0-9&/(').;-]*$";
	String MERCHANT_CITY_EX = null;

}
