package com.isg.mw.core.model.validation;

import java.math.BigInteger;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.isg.mw.core.model.constants.FieldsInfo;
import com.isg.mw.core.model.constants.LockedState;
import com.isg.mw.core.model.constants.MerchantPreference;
import com.isg.mw.core.model.constants.OwnerType;
import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.constants.TargetType;
import com.isg.mw.core.model.exception.ValidationException;

public class UserDataValidations {

	private UserDataValidations() {
	}

	public static final String MANDATORY_DATA_ERROR = "user.data.validation.field.mandatory";

	public static final String EXCEEDED_DATA_LENGTH_ERROR = "user.validation.length.exceeded";

	public static final String FAILED_DATA_EXPRESSION_ERROR = "user.validation.data.expression";

	public static final String PREDEFINED_DATA_ERROR = "user.validation.data.predefined";

	public static final String FAILED_DATA_VALUE_ERROR = "user.validation.data.value.not.in.range";

	public static final String INVALID_DATA_ERROR = "user.validation.invalid.data";
	
	public static final String INVALID_HEADER_ERROR = "user.validation.invalid.header";

	public static void stringDataValidation(String data, String expression, String fieldName, boolean mandatory,
			int length) {
		if (mandatory) {
			if (data == null || data.isEmpty()) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == null || data.isEmpty()) {
			return;
		}
		if (data.length() > length) {
			throw new ValidationException(EXCEEDED_DATA_LENGTH_ERROR, fieldName, length);
		}
		if (expression != null) {
			if (!Pattern.matches(expression, data)) {
				throw new ValidationException(FAILED_DATA_EXPRESSION_ERROR, fieldName, expression);
			}
		}

	}

	public static void userNameValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.USER_NAME_EX, FieldsInfo.USER_NAME_FN, m, FieldsInfo.USER_NAME_FL);
	}

	public static void ipAddressValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.IP_ADDRESS_EX, FieldsInfo.IP_ADDRESS_FN, m, FieldsInfo.IP_ADDRESS_FL);
	}

	public static void portValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		int port = 0;
		stringDataValidation(data, FieldsInfo.PORT_EX, FieldsInfo.PORT_FN, m, FieldsInfo.PORT_FL);
		try {
			port = Integer.parseInt(data);
		} catch (Exception ex) {
		}
		if (port > 64255) {
			throw new ValidationException(FAILED_DATA_EXPRESSION_ERROR, FieldsInfo.PORT_FN);
		}
	}

	public static void urlValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.URL_EX, FieldsInfo.URL_FN, m, FieldsInfo.URL_FL);
	}

	public static void uriValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.URI_EX, FieldsInfo.URI_FN, m, FieldsInfo.URI_FL);
	}

	public static void nameValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.NAME_EX, FieldsInfo.NAME_FN, m, FieldsInfo.NAME_FL);
	}

	public static void entityIdValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.ENTITY_ID_EX, FieldsInfo.ENTITY_ID_FN, m, FieldsInfo.ENTITY_ID_FL);
	}

	public static void stringPreDefiendDataValidation(String data, String[] values, String fieldName,
			boolean mandatory) {

		if (mandatory) {
			if (StringUtils.isBlank(data)) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == null) {
			return;
		}
		if (!StringUtils.isBlank(data)) {
			if (!isDataExistInValues(values, data)) {
				throw new ValidationException(PREDEFINED_DATA_ERROR, fieldName);
			}
		}
	}

	public static void intDataValidations(int data, int maxRange, String fieldName, boolean mandatory) {
		if (mandatory) {
			if (data == 0) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == 0) {
			return;
		}
		if (!isDataIsInRange(data, maxRange)) {
			throw new ValidationException(FAILED_DATA_VALUE_ERROR, fieldName);
		}

	}

	public static void ownerTypeValidations(OwnerType ot, boolean... mandatory) {

		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (ot == null) {
				throw new ValidationException(MANDATORY_DATA_ERROR, FieldsInfo.OWNER_TYPE_FN);
			}
		}

	}

	public static void schemeTypeValidations(TargetType st, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (st == null) {
				throw new ValidationException(MANDATORY_DATA_ERROR, FieldsInfo.SCHEME_TYPE_FN);
			}
		}

	}

	public static void cryptoValidations(byte[] data, String fieldName, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (data == null) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == null) {
			return;
		}
		
		if (data.length > FieldsInfo.CRYPTO_KEY_LN) {
			throw new ValidationException(EXCEEDED_DATA_LENGTH_ERROR, fieldName, FieldsInfo.CRYPTO_KEY_LN);
		}
	}

	public static void lockedStateValidations(LockedState ls, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (ls == null) {
				throw new ValidationException(MANDATORY_DATA_ERROR, FieldsInfo.LOCKED_STATE_FN);
			}
		}

	}

	public static void idValidations(Long id, boolean mandatory) {

		if (mandatory) {
			if (id == null) {
				throw new ValidationException(MANDATORY_DATA_ERROR, FieldsInfo.DB_ID_FN);
			}
		} else if (id == null) {
			return;
		}

		if (id <= 0) {
			throw new ValidationException(INVALID_DATA_ERROR, FieldsInfo.DB_ID_FN);
		}

	}

	public static void cashAtPosLimitValidations(int data, boolean mandatory) {

		if (mandatory) {
			if (data == 0) {
				throw new ValidationException(MANDATORY_DATA_ERROR, FieldsInfo.CASH_AT_POS_LIMIT);
			}
		} else if (data == 0) {
			return;
		}

		if (data <= 0) {
			throw new ValidationException(INVALID_DATA_ERROR, FieldsInfo.CASH_AT_POS_LIMIT);
		}

	}

	public static boolean duplicateCheck(String[] strs) {

		boolean rst = false;
		for (int i = 0; i < strs.length; i++) {
			for (int j = i + 1; j > i && j < strs.length; j++) {
				if (strs[i].equals(strs[j])) {
					return true;
				}
			}
		}
		return rst;

	}

	public static boolean duplicateCheck(MerchantPreference[] strs) {

		boolean rst = false;
		for (int i = 0; i < strs.length; i++) {
			for (int j = i + 1; j > i && j < strs.length; j++) {
				if (strs[i] == strs[j]) {
					return true;
				}
			}
		}
		return rst;

	}

	private static boolean isDataIsInRange(int data, int maxRange) {
		if (data >= 0 && data <= maxRange) {
			return true;
		}
		return false;
	}

	private static boolean isDataExistInValues(String[] values, String data) {
		for (String value : values) {
			if (value.equals(data)) {
				return true;
			}
		}
		return false;
	}

	public static void groupSignonIdValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.GROUP_SIGNON_ID_EX, FieldsInfo.GROUP_SIGNON_ID_FN, m,
				FieldsInfo.GROUP_SIGNON_ID_FL);
	}

	public static void intTargetNettyConfigDataValidations(int data, int maxRange, String fieldName,
			boolean mandatory) {
		if (mandatory) {
			if (data == -1) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == -1) {
			return;
		}
		if (!isTargetNettyDataIsInRange(data, maxRange)) {
			throw new ValidationException(FAILED_DATA_VALUE_ERROR, fieldName);
		}

	}
	
	public static void headerValidations(String headerName, String headerConstant) {
		if (!headerConstant.equals(headerName)) {
			throw new ValidationException(INVALID_HEADER_ERROR, headerName);
		}
	}
	
	

	private static boolean isTargetNettyDataIsInRange(int data, int maxRange) {
		if (data >= -1 && data <= maxRange) {
			return true;
		}
		return false;
	}

	public static void longDataValidations(Long data, String fieldName, int length, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		dataValidation(data, fieldName, m, length);
	}
	

	public static void dataValidation(Long data, String fieldName, boolean mandatory, int length) {

		if (mandatory) {
			if (data == 0) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == 0) {
			return;
		}
		if (length != 0) {
			if (!isDataIsInGivenLength(data, length)) {
				throw new ValidationException(FAILED_DATA_VALUE_ERROR, fieldName);
			}
		}
		if (data <= 0) {
			throw new ValidationException(INVALID_DATA_ERROR, fieldName);
		}

	}
	
	private static boolean isDataIsInGivenLength(Long data, int length) {
	    int dataLength = data.toString().length();
	    if (dataLength > length ) {
	    	return false;
	    }
	    return true;

	}
	
	public static void bigIntegerDataValidations(BigInteger data, String fieldName, int length, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		bigIntegerValidation(data, fieldName, m, length);
	}
	

	public static void bigIntegerValidation(BigInteger data, String fieldName, boolean mandatory, int length) {

		if (mandatory) {
			if (data == BigInteger.ZERO) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == BigInteger.ZERO) {
			return;
		}
		if (length != 0) {
			if (!isbigIntDataIsInGivenLength(data, length)) {
				throw new ValidationException(FAILED_DATA_VALUE_ERROR, fieldName);
			}
		}
		if (data.compareTo(BigInteger.ZERO) == 0 || data.compareTo(BigInteger.ZERO) == -1) {
			throw new ValidationException(INVALID_DATA_ERROR, fieldName);
		}

	}
	
	private static boolean isbigIntDataIsInGivenLength(BigInteger data, int length) {
	    int dataLength = data.toString().length();
	    if (dataLength > length ) {
	    	return false;
	    }
	    return true;

	}

	public static void enumTypeValidations(RouteType rt, String fieldName, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (rt == null) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		}

	}
	
	public static void doubleDataValidations(Double data, int length, String fieldName, boolean mandatory) {
		if (mandatory) {
			if (data == 0 ) {
				throw new ValidationException(MANDATORY_DATA_ERROR, fieldName);
			}
		} else if (data == 0) {
			return;
		}
		if (!isDataIsInRange(data, length)) {
			throw new ValidationException(FAILED_DATA_VALUE_ERROR, fieldName);
		}
		if (data <= 0) {
			throw new ValidationException(INVALID_DATA_ERROR, fieldName);
		}
		

	}
	
	private static boolean isDataIsInRange(Double data, int length) {
		String[] splitter = data.toString().split("\\.");
		int beforeDecimalCount = splitter[0].length();   
		int afterDecimalCount = splitter[1].length(); 
		if ((beforeDecimalCount+afterDecimalCount) > length ) {
			return false;
		}
	    return true;
	}
	
	public static void acquirerIdValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.ACQUIRER_ID_EX, FieldsInfo.ACQUIRER_ID_FN, m, FieldsInfo.ACQUIRER_ID_FL);
	}
	
	public static void fwdInstIdValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.FWDINSTID_EX, FieldsInfo.FWDINSTID_FN, m, FieldsInfo.FWDINSTID_FL);
	}
	
	public static void httpMethodValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		stringDataValidation(data, FieldsInfo.HTTP_METHOD_NAME_EX, FieldsInfo.HTTP_METHOD_NAME_FN, m, FieldsInfo.HTTP_METHOD_NAME_FL);
	}

	public static void ipAndPortOrUrlValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		if(data.startsWith("http")) {
		stringDataValidation(data, FieldsInfo.URL_EX, FieldsInfo.TARGET_URL_FN, m, FieldsInfo.URL_FL);
		} else {
			String[] ipAndPort = data.split(":");
			if (ipAndPort.length == 2) {
				if (ipAndPort[0] != null) {
					stringDataValidation(ipAndPort[0], FieldsInfo.IP_ADDRESS_EX, FieldsInfo.TARGET_URL_FN, m,
							FieldsInfo.IP_ADDRESS_FL);
				}
				if (ipAndPort[1] != null) {
					stringDataValidation(ipAndPort[1], FieldsInfo.PORT_EX, FieldsInfo.TARGET_URL_FN, m, FieldsInfo.PORT_FL);
					if (Integer.parseInt(ipAndPort[1]) > 64255) {
						throw new ValidationException(FAILED_DATA_EXPRESSION_ERROR, FieldsInfo.TARGET_URL_FN);
					}
				}

			} else {
				throw new ValidationException(INVALID_DATA_ERROR, FieldsInfo.TARGET_URL_FN);
			}
		}
		
	}

}
