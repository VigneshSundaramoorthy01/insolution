package com.isg.mw.security.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;

import javax.crypto.SecretKey;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.isg.mw.security.algorithms.AES;
import com.isg.mw.security.loder.KeyProviderLoader;
import com.isg.mw.security.security.Decryptor;
import com.isg.mw.security.service.impl.SecurityLibConfigs;

/**
 * 
 * @author prasad_t026
 *
 */
//@RunWith(SpringRunner.class)
//@SpringBootTest
public class AesDecryptorTest {

	/*
	 * @Autowired private SecurityLibConfigs securityLibConfigs;
	 * 
	 * @Test public void decryptionTest() { String aesSeretKeyProvider =
	 * securityLibConfigs.getSecretKeyProvider(); Decryptor<AES, SecretKey>
	 * encryptor = new Decryptor<AES, SecretKey>(KeyProviderLoader.readProvider(new
	 * File(aesSeretKeyProvider))); String data =
	 * "018003786c98d463f1855c2b9127c7335ff63347005f000100156177732d63727970746f2d7075626c69632d6b65790044417456703276455678426a677175616c7a414f72436842794e393464635142594e725462793756574d6b454a5a4463794b355441557239654d682f367635784d61413d3d00010003495347001a736563726574000000800000000cf09a9eadbcdc7444f6320c2e0030bf034eb92ab6357e78baaf68349a07d50e4f91290706e595747cdc13a57cf47008f31e1d14ee9fe2bcd93a7360d69e0802000000000c00001000000000000000000000000000e1a6dd65c6348ce5a19510020947b4c5ffffffff0000000100000000000000000000000100000010c17da698d2845a92dbc508742634ff6e22b108181a338c06f9b506cf448b565c00673065023100f118cfc81553d3ae9eaecb43ad9e5c8c15a721c5c4e6c7d3fc4f80d7b1610a578b1fe87a547ea357b8523837f04f552a02305978de8f5db1218be411bbf207d2cadeab657512a4c04abad2fc271e1df683edc326e0555ee4a09545b2d0f4401eb495";
	 * String decryptionValue = encryptor.decrypt(data);
	 * System.out.println("aesSeretKeyProvider from configuration file: " +
	 * aesSeretKeyProvider); System.out.println("data: " + data);
	 * System.out.println("aes decryptionValue: " + decryptionValue); String
	 * expectedValue = "1234567890123456";
	 * System.out.println("aes expectedValue  : " + expectedValue);
	 * assertEquals(expectedValue, decryptionValue); }
	 * 
	 * @Test public void decryptionTest02() { String aesSeretKeyProvider =
	 * securityLibConfigs.getSecretKeyProvider(); Decryptor<AES, SecretKey>
	 * encryptor = new Decryptor<AES, SecretKey>(aesSeretKeyProvider); String data =
	 * "018003786c98d463f1855c2b9127c7335ff63347005f000100156177732d63727970746f2d7075626c69632d6b65790044417456703276455678426a677175616c7a414f72436842794e393464635142594e725462793756574d6b454a5a4463794b355441557239654d682f367635784d61413d3d00010003495347001a736563726574000000800000000cf09a9eadbcdc7444f6320c2e0030bf034eb92ab6357e78baaf68349a07d50e4f91290706e595747cdc13a57cf47008f31e1d14ee9fe2bcd93a7360d69e0802000000000c00001000000000000000000000000000e1a6dd65c6348ce5a19510020947b4c5ffffffff0000000100000000000000000000000100000010c17da698d2845a92dbc508742634ff6e22b108181a338c06f9b506cf448b565c00673065023100f118cfc81553d3ae9eaecb43ad9e5c8c15a721c5c4e6c7d3fc4f80d7b1610a578b1fe87a547ea357b8523837f04f552a02305978de8f5db1218be411bbf207d2cadeab657512a4c04abad2fc271e1df683edc326e0555ee4a09545b2d0f4401eb495";
	 * String decryptionValue = encryptor.decrypt(data);
	 * System.out.println("aesSeretKeyProvider from configuration file: " +
	 * aesSeretKeyProvider); System.out.println("data: " + data);
	 * System.out.println("aes decryptionValue: " + decryptionValue); String
	 * expectedValue = "1234567890123456";
	 * System.out.println("aes expectedValue  : " + expectedValue);
	 * assertEquals(expectedValue, decryptionValue); }
	 */

}
