package com.isg.mw.security.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.security.PrivateKey;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.isg.mw.security.algorithms.RSA;
import com.isg.mw.security.loder.KeyProviderLoader;
import com.isg.mw.security.security.Decryptor;
import com.isg.mw.security.service.impl.SecurityLibConfigs;

/**
 * 
 * @author prasad_t026
 *
 */
//@RunWith(SpringRunner.class)
//@SpringBootTest

public class RsaDecryptorTest {

	/*
	 * @Autowired private SecurityLibConfigs securityLibConfigs;
	 * 
	 * @Test public void decryptionTest() { String rsaPrivateKeyProvider =
	 * securityLibConfigs.getPrivateKeyProvider(); Decryptor<RSA, PrivateKey>
	 * decryptor = new Decryptor<RSA, PrivateKey>(KeyProviderLoader.readProvider(new
	 * File(rsaPrivateKeyProvider))); String data =
	 * "01800378e424661763623f99686a63c6464d9a1e005f000100156177732d63727970746f2d7075626c69632d6b65790044417845686c4e477357426e51756f307947714378657a4e79536d57544c34357554637453673950474443746c2f6353764972726c4a78416e546a43526859466b39773d3d00010003495347000c6d797365727665726365727400803e87215694cf53490bd85fb8dd396d6354b0342556c539fa6095917a0a6453a5a02fb3bc4dedb618e586b6c7a3376ba60f28163499104ba352c815ad956aa238a170831513b3980dd9daf19ffc1c34d2541fb992084d0e742e85a16b1ae9a950e44bfafb24a8504e60fef322564a2c35e172cf5ec5f3534bc3348f08eb3f287602000000000c00001000000000000000000000000000b185f29450e6af2517dd1d6dd3852bc2ffffffff0000000100000000000000000000000100000010de9abdc31da992f2a7860c86dca3693e6f6f158e4664c8a7b860e9daf18239db006730650230209efbd48d7899b759e3351ec33f05ace38624196ddeb0b9fc2443b2955058459fb61915155b61be9aa34b88eeb3c11d023100e1ea83212397936d073d4bc74ea8f2364df06e57768b8994a89cdd77efa22c90daf1c1ad2087d4dbec894a748132b7db";
	 * String decryptionValue = decryptor.decrypt(data);
	 * System.out.println("rsaPrivateKeyProvider from configuration file: " +
	 * rsaPrivateKeyProvider); System.out.println("data (encrypted): " + data);
	 * System.out.println("rsa decryptionValue: " + decryptionValue); String
	 * expectedValue = "1234567890123456"; assertEquals(expectedValue,
	 * decryptionValue); }
	 * 
	 * @Test public void decryptionTest02() { String rsaPrivateKeyProvider =
	 * securityLibConfigs.getPrivateKeyProvider(); Decryptor<RSA, PrivateKey>
	 * decryptor = new Decryptor<RSA, PrivateKey>(rsaPrivateKeyProvider); String
	 * data =
	 * "0180037882821305df35a535e9c9ee4356f5f768005f000100156177732d63727970746f2d7075626c69632d6b65790044413074376266516e4d3639506a787a7663504e48594c5450692f6d7359554b625557444c676a78484d696b6c754a6267504b525257543553544b4a756e4c66636e773d3d00010003495347000c6d79736572766572636572740080a992be6d47930306ae82d1a0ac8640a15e20ec4460071c621faf1a3b8ba3ba5f8ad35e4d270135503e537eb3b4b84f5f3448057609d2e25b55254e4c4106ec93f021aa1f91988613cc9a40801cf8651a60ee486efa836a862a0e77636dcdbd23f292faae1d1fe601488edf65b99ab18bd7c6c66ceb20ac3e9d29f47dc3a8958602000000000c00001000000000000000000000000000948bdb4231419458a1533272efa5349fffffffff00000001000000000000000000000001000000102d187792cf003e0c1afd5b069a4aaf46e636e021eb65d95fb965e23911507c4300673065023100b6c45df70d62fbd66add43a2b924f97bab4e5503af61e6d6c16fcf9da0b3dcf290ec9f4cf87b4861cf4a1a4540fdf532023028e46b9537dbb07dac0ec6cfad12afe67f9cc4d8f57d6e180dff9b95759fbf52cc5f3099b4a330cf6d22b565aefbdfde";
	 * String decryptionValue = decryptor.decrypt(data);
	 * System.out.println("rsaPrivateKeyProvider from configuration file: " +
	 * rsaPrivateKeyProvider); System.out.println("data (encrypted): " + data);
	 * System.out.println("rsa decryptionValue: " + decryptionValue); String
	 * expectedValue = "1234567890123456"; assertEquals(expectedValue,
	 * decryptionValue); }
	 */

}
