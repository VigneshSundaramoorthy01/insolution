package com.isg.mw.security.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;


import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.isg.mw.security.security.PasswordHashing;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class PasswordHashingTest {
	/*
	 * @Test public void hashTestPT01() { PasswordHashing pHashing = new
	 * PasswordHashing(); String plainText = "Asdf$123"; String hash =
	 * pHashing.hash(plainText); boolean result = pHashing.verify(plainText, hash);
	 * assertEquals(true, result);
	 * 
	 * }
	 * 
	 * @Test public void hashTestPT02() { PasswordHashing pHashing = new
	 * PasswordHashing("SHA-256", 1100, 8); String plainText = "Zxcv@654"; String
	 * hash = pHashing.hash(plainText); boolean result = pHashing.verify(plainText,
	 * hash); assertEquals(true, result);
	 * 
	 * }
	 * 
	 * @Test public void hashTestNT01() { PasswordHashing pHashing = new
	 * PasswordHashing(); String plainText = "Asdf$123"; pHashing.hash(plainText);
	 * String wrongHash =
	 * "kKZCkj3T6qPI0lNAdP8aWzWPQRrQI/eyZ4R4fcGlF8uFUQQ+cRoQLCg4bACDnU74/MmpHzMC0QYmslFc4xKZU89WLLFYdmO/BrdSu8+iH6w=";
	 * boolean result = pHashing.verify(plainText, wrongHash); assertNotEquals(true,
	 * result);
	 * 
	 * }
	 * 
	 * @Test public void hashTestNT02() { PasswordHashing pHashing = new
	 * PasswordHashing("SHA-256", 1100, 8); String plainText = "Zxcv@654";
	 * pHashing.hash(plainText); String wrongHash =
	 * "+wJxVe4STT/7V1YNt8AwQUOyGyPQ7E1sbbYQGEgJRn/EGMJRYEg5Lw=="; boolean result =
	 * pHashing.verify(plainText, wrongHash); assertNotEquals(true, result);
	 * 
	 * }
	 * 
	 * @Test public void hashTestNT03() { PasswordHashing pHashing = new
	 * PasswordHashing(); String plainText = "Asdf$123"; String hash =
	 * pHashing.hash(plainText); String wrongPlainText = "Qwerty$123"; boolean
	 * result = pHashing.verify(wrongPlainText, hash); assertNotEquals(true,
	 * result);
	 * 
	 * }
	 * 
	 * @Test public void hashTestNT04() { PasswordHashing pHashing = new
	 * PasswordHashing("SHA-256", 1100, 8); String plainText = "Zxcv@654"; String
	 * hash = pHashing.hash(plainText); String wrongPlainText = "Qwerty@654";
	 * boolean result = pHashing.verify(wrongPlainText, hash); assertNotEquals(true,
	 * result);
	 * 
	 * }
	 */

}
