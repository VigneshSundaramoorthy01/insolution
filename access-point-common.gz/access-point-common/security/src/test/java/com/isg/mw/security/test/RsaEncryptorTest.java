package com.isg.mw.security.test;

import java.io.File;
import java.security.PublicKey;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.isg.mw.security.algorithms.RSA;
import com.isg.mw.security.loder.KeyProviderLoader;
import com.isg.mw.security.security.Encryptor;
import com.isg.mw.security.service.impl.SecurityLibConfigs;

/**
 * 
 * @author prasad_t026
 *
 */
//@RunWith(SpringRunner.class)
//@SpringBootTest
public class RsaEncryptorTest {

	/*
	 * @Autowired private SecurityLibConfigs securityLibConfigs;
	 * 
	 * @Test public void encryptionTest() { String rsaPublicKeyProvider =
	 * securityLibConfigs.getPublicKeyProvider(); Encryptor<RSA, PublicKey>
	 * encryptor = new Encryptor<RSA, PublicKey>(KeyProviderLoader.readProvider(new
	 * File(rsaPublicKeyProvider))); String data = "1234567890123456"; String
	 * encryptionValue = encryptor.encrypt(data);
	 * System.out.println("rsaPublicKeyProvider from configuration file: " +
	 * rsaPublicKeyProvider); System.out.println("data: " + data);
	 * System.out.println("rsa encryptionValue: " + encryptionValue); String
	 * expectedValue =
	 * "0180037875db95d83f562336e51a41741aa49b15005f000100156177732d63727970746f2d7075626c69632d6b6579004441716b35384378686233546b6a47557256535047705935656659657235654872394c4b7246543373314977482b583943495a7432613077644f5249504f6430306c773d3d00010003495347000c6d7973657276657263657274008006f4e18366909028a77bd93ce063fb88ffa31904fc2f8f61fa685edc5cb1a90180c02fc2e05866be43591fa3e4ef760fa615f3a80eb84712c7a39b2badc0331ded36f0b540ee5c4eee45ff3c288dfc1508efd8f0166169428fb3995b304e50855894169819b8a105d357fe33f5fd7df70211a729d8396a0c74a5920d7ca8afd202000000000c00001000000000000000000000000000d389fba01d3ac8e569f25d3f4c69dd16ffffffff000000010000000000000000000000010000001068ceb1935f348d2efc56148dff5f4648af35401424c5655814ff8b1768adfbe100673065023100b521add082207e25ed415746df5182e32eb3dbafacd9af322a8c1d74a3dbdf452e44eea47eaeb3405c76271231b707ff023014438893bfd37d6b93bd15824f43f626b863ea1700b69f0a475960b2105a24d1fccf9d951e5f5213a4a15e43cd7811be";
	 * System.out.println("rsa expectedValue  : " + expectedValue);
	 * //assertEquals(expectedValue, encryptionValue); }
	 * 
	 * @Test public void sampleTest() {
	 * 
	 * }
	 */
	
}
