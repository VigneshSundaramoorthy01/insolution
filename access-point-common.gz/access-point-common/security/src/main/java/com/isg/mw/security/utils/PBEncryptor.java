package com.isg.mw.security.utils;

import org.jasypt.util.text.AES256TextEncryptor;

/**
 * Utility class which uses Jasypt library to encrypt/decrypt data using a secret password.<br>
 * <p>
 * This class internally holds a StandardPBEStringEncryptor configured this way:
 * Algorithm: PBEWithHMACSHA512AndAES_256".
 * Key obtention iterations: 1000.
 */
public final class PBEncryptor {

    private PBEncryptor() {
    }

    /**
     * @param dataToEncrypt      Data to be encrypted
     * @param encryptionPassword Secret password used to encrypt the data
     * @return Returns the encrypted data
     */
    public static String encrypt(String dataToEncrypt, String encryptionPassword) {
        AES256TextEncryptor textEncryptor = new AES256TextEncryptor();
        textEncryptor.setPassword(encryptionPassword);
        return textEncryptor.encrypt(dataToEncrypt);
    }

    /**
     * @param encryptedData      Encrypted data
     * @param encryptionPassword Secret password used to decrypt the data
     * @return Returns the decrypted data
     */
    public static String decrypt(String encryptedData, String encryptionPassword) {
        AES256TextEncryptor textEncryptor = new AES256TextEncryptor();
        textEncryptor.setPassword(encryptionPassword);
        return textEncryptor.decrypt(encryptedData);
    }
}
