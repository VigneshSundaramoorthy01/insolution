package com.isg.mw.security.algorithms;

public abstract class SupportedAlgorithms {
	
}
