package com.isg.mw.security.exceptions;

public class UnsupportedKeyException extends Throwable {
    public UnsupportedKeyException(String msg) {
        super(msg);
    }
}
