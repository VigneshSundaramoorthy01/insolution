package com.isg.mw.security.security;

import org.jasypt.digest.config.SimpleDigesterConfig;
import org.jasypt.util.password.ConfigurablePasswordEncryptor;

/**
 * This class which uses Jasypt library to hash plain text and verify plain text with hash.<br>
 * <br>
 * This class hold internally ConfigurablePasswordEncryptor configured this way:<br> 
 * Algorithm: SHA_512<br>
 * Hash Iteration=1000<br>
 * Salt Size = 16  
 * @author akshay3978
 */
public class PasswordHashing {
	/**
	 * Configurable password encryptor uses salt size with hash iteration
	 * and Algorithm . This encryptor should be used for Password Hashing and
	 * Checking
	 */
	private ConfigurablePasswordEncryptor cfgPasswordEncryptor;

	/**
	 * This is the Default PasswordHashing Constructor. which consist Configurable Password Encryptor
	 * instance with salt size, hash iteration and algorithm.
	 */
	public PasswordHashing() {
		cfgPasswordEncryptor = new ConfigurablePasswordEncryptor();

		SimpleDigesterConfig config = new SimpleDigesterConfig();

		config.setAlgorithm("SHA-512");
		config.setIterations(1000);
		config.setSaltSizeBytes(16);
		cfgPasswordEncryptor.setConfig(config);
	}

	/**
	 *This is with argument PasswordHashing Constructor. which consist Configurable Password Encryptor
	 * instance with salt size, hash iteration and algorithm. 
	 * @param algorithm   Algorithm 
	 * @param itrations   Hash iterations 
	 * @param saltSizeBytes Salt size
	 */
	public PasswordHashing(String algorithm, int itrations, int saltSizeBytes) {
		cfgPasswordEncryptor = new ConfigurablePasswordEncryptor();

		SimpleDigesterConfig config = new SimpleDigesterConfig();

		config.setAlgorithm(algorithm);
		config.setIterations(itrations);
		config.setSaltSizeBytes(saltSizeBytes);
		cfgPasswordEncryptor.setConfig(config);

	}

	/**
	 * This method used for convert plain text into hash.<br>
	 * @param plainText Data to hashing
	 * @return Return hash data
	 */
	public String hash(String plainText) {
		return cfgPasswordEncryptor.encryptPassword(plainText);
	}

	/**
	 * This method used for checked the plain text and hash is matching or not.<br>
	 * @param plainText Plain Text to compare
	 * @param hash      Hash to compare
	 * @return Return boolean value if plain text and hash matched.
	 */
	public boolean verify(String plainText, String hash) {
		return cfgPasswordEncryptor.checkPassword(plainText, hash);
	}

}
