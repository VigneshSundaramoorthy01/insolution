package com.isg.mw.security.model;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KeyProvider {

	private String name;

	private String builderType;
	
	private SecurityKeyType keyType;
	
	private Map<String, String> configs;

}
