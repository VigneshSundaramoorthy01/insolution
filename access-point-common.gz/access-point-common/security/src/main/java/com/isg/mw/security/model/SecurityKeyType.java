package com.isg.mw.security.model;


/**
 * @author prasad_t026
 *
 */
public enum SecurityKeyType {

	SECRET,
	
	PUBLIC,

	PRIVATE;

	/**
	 * converts String object to SecurityKeyType constant
	 * 
	 * @param name - string value of the SecurityKeyType
	 * @return - SecurityKeyType Enum constant
	 */
	public static SecurityKeyType getKeyType(String name) {
		if (PUBLIC.name().equals(name)) {
			return PUBLIC;
		} else if (PRIVATE.name().equals(name)) {
			return PRIVATE;
		} else if (SECRET.name().equals(name)) {
			return SECRET;
		}

		return null;
	}

}
