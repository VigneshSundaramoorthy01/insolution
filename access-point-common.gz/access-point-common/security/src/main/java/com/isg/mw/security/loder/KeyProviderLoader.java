package com.isg.mw.security.loder;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.isg.mw.security.model.KeyProvider;

/**
 * 
 * @author prasad_t026
 *
 */
public class KeyProviderLoader {

    private static Logger LOG = LogManager.getLogger(KeyProviderLoader.class);

	public static List<KeyProvider> load( String path ) {
		
		List<KeyProvider> providers = new ArrayList<>();
		try {
			File folder = new File(path);
			if(folder.canRead() && folder.isDirectory()) {
				File[] listOfFiles = folder.listFiles();
				List<KeyProvider> sublist = null;
				for (File file : listOfFiles) {
				    if (file.isFile() && file.canRead()) {
				    	sublist = readProviders( file );
				    	if(sublist != null && !sublist.isEmpty()) {
				    		providers.addAll(sublist);
				    	}
				    }
				}
			}
			else {
				LOG.info("given path can't be readable or it's not a folder: " + folder.getAbsolutePath());
			}
		}
		catch(Exception ex) {
			LOG.info(ex.getMessage());
			LOG.trace(ex.getStackTrace());
		}
		return providers;
		
	}
	
	public static List<KeyProvider> readProviders(File file) {
		
		ObjectMapper mapper = new ObjectMapper();
		KeyProvider[] value = null;
        try {
            value = mapper.readValue(file, KeyProvider[].class);
        } catch (Exception ex) {
			LOG.info(ex.getMessage());
			LOG.trace(ex.getStackTrace());
        }   
         
        if (value != null) {
        	return Arrays.asList(value);
        }
        return null;
        
	}

	public static KeyProvider readProvider(File file) {
		
		ObjectMapper mapper = new ObjectMapper();
		 
		KeyProvider value = null;
        try {
            value = mapper.readValue(file, KeyProvider.class);
        } catch (Exception ex) {
			LOG.info(ex.getMessage());
			LOG.trace(ex.getStackTrace());
        }   
         
        return value;
        
	}

	public static void saveInFile(String path, String fileName, KeyProvider provider) {
 
        try {
            ObjectMapper mapper = new ObjectMapper();
            KeyProvider[] kps = {provider};
            //mapper.writeValue(new File(path, fileName), kps);//Plain JSON
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(path, fileName ), kps);//Prettified JSON
        } catch (Exception ex) {
			LOG.info(ex.getMessage());
			LOG.trace(ex.getStackTrace());
        }

	}
	
}
