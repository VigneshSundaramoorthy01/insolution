package com.isg.mw.security.builder;

import com.amazonaws.encryptionsdk.MasterKeyProvider;
import com.amazonaws.encryptionsdk.multi.MultipleProviderFactory;
import com.isg.mw.security.algorithms.SupportedAlgorithms;
import com.isg.mw.security.exceptions.UnsupportedAlgoException;
import com.isg.mw.security.exceptions.UnsupportedKeyException;
import com.isg.mw.security.loder.KeyProviderLoader;
import com.isg.mw.security.model.KeyProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

/**
 * Read application properties file to get Master Key Providers config file name
 * Read MasterKeyProviders config file to build all types of Master Key Providers
 * And add all of them into one MultipleProviderFactory
 * <p>
 * ====Master Key Providers Config file format====
 * {
 * "providers": [
 * {
 * "name": "JavaKeyStore",
 * "builderType": "JceMasterKeyProviderBuilder", //The class name of specific implementation
 * "config": {
 * //This config can be understood only by the builderType parameter
 * "provider": "ISG",
 * "keyId": "myKeyId",
 * "algorithm": "RSA", //Only RSA and AES are supported
 * "wrappingAlgo": ""RSA/ECB/PKCS1Padding",
 * "keyStorePath": "/Users/vs/mykeystore"
 * "keyStoreCred": "password"
 * }
 * },
 * {
 * "name": "AwsKms",
 * "builderType": "AwsKmsMasterKeyProviderBuilder", //The class name of specific implementation
 * "config": {}
 * },
 * {
 * "name": "AzureKms",
 * "builderType": "AzureKmsMasterKeyProviderBuilder", //The class name of specific implementation
 * "config": {}
 * },
 * {
 * "name": "IsgKms",
 * "builderType": "IsgKmsMasterKeyProviderBuilder", //The class name of specific implementation
 * "config": {}
 * }
 * ]
 * }
 * ====End of Master Key Providers Config file format=====
 */
public class MasterKeyProviderBuilder<A extends SupportedAlgorithms, K extends Key> {

    private MasterKeyProvider<?> masterKeyProvider = null;

    private static final Logger logger = LogManager.getLogger(MasterKeyProviderBuilder.class);

    public MasterKeyProviderBuilder(File providerFile) {
        masterKeyProvider = MultipleProviderFactory.buildMultiProvider(getMasterKeyList(KeyProviderLoader.readProviders(providerFile)));
    }

    public MasterKeyProviderBuilder(String providerPath) {
        masterKeyProvider = MultipleProviderFactory.buildMultiProvider(getMasterKeyList(KeyProviderLoader.readProviders(new File(providerPath))));
    }

    public MasterKeyProviderBuilder(String providerPath, String secretKey) {
        masterKeyProvider = MultipleProviderFactory.buildMultiProvider(getMasterKeyList(KeyProviderLoader.readProviders(new File(providerPath)), secretKey));
    }

    public MasterKeyProviderBuilder(String secretKey, String algorithm, String keydata) throws InvalidKeyException, UnrecoverableKeyException, InvalidKeySpecException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, UnsupportedAlgoException, UnsupportedKeyException {
        MasterKeyProvider<?> mkp = null;
        JceMasterKeyProviderBuilder<A, K> jmk = new JceMasterKeyProviderBuilder<A, K>(secretKey);
        mkp = jmk.getMasterKeyProvider();
        masterKeyProvider = MultipleProviderFactory.buildMultiProvider(mkp);
    }

    public MasterKeyProviderBuilder(List<KeyProvider> providers) {
        ArrayList<MasterKeyProvider<?>> lmkp = new ArrayList<>();
        for (KeyProvider provider : providers) {
            lmkp.add(getMasterKey(provider));
        }
        masterKeyProvider = MultipleProviderFactory.buildMultiProvider(lmkp);
    }

    public MasterKeyProviderBuilder(KeyProvider provider) {
        masterKeyProvider = MultipleProviderFactory.buildMultiProvider(getMasterKey(provider));
    }

    public MasterKeyProvider<?> getMasterKeyProvider() {
        return masterKeyProvider;
    }

    public List<MasterKeyProvider<?>> getMasterKeyList(List<KeyProvider> providers) {
        ArrayList<MasterKeyProvider<?>> lmkp = new ArrayList<>();
        for (KeyProvider provider : providers) {
            lmkp.add(getMasterKey(provider));
        }
        return lmkp;
    }

    public List<MasterKeyProvider<?>> getMasterKeyList(List<KeyProvider> providers, String secretKey) {
        ArrayList<MasterKeyProvider<?>> lmkp = new ArrayList<>();
        for (KeyProvider provider : providers) {
            lmkp.add(getMasterKey(provider, secretKey));
        }
        return lmkp;
    }

    private MasterKeyProvider<?> getMasterKey(KeyProvider provider) {
        MasterKeyProvider<?> mkp = null;
        if ("JceMasterKeyProviderBuilder".equals(provider.getBuilderType())) {
            JceMasterKeyProviderBuilder<A, K> jmk = null;
            try {
                jmk = new JceMasterKeyProviderBuilder<A, K>(
                        provider.getKeyType(),
                        provider.getConfigs().get("keyStorePath"),
                        provider.getConfigs().get("keyStoreCred"),
                        provider.getConfigs().get("provider"),
                        provider.getConfigs().get("keyId"),
                        provider.getConfigs().get("wrappingAlgo"),
                        provider.getConfigs().get("secretKey"));
            } catch (InvalidKeySpecException | NoSuchAlgorithmException | IOException | UnsupportedAlgoException | InvalidKeyException | UnsupportedKeyException | UnrecoverableKeyException | KeyStoreException | CertificateException e) {
                logger.error("Failed to create Master Key Provider", e);
                logger.trace(e.getStackTrace());
            }
            mkp = jmk.getMasterKeyProvider();
        } else if ("JceMasterKeyProviderBuilder-AES".equals(provider.getBuilderType())) {
            JceMasterKeyProviderBuilder<A, K> jmk = null;
            try {
                jmk = new JceMasterKeyProviderBuilder<A, K>(provider.getConfigs().get("secretKey"));
            } catch (UnsupportedAlgoException | UnsupportedKeyException e) {
                logger.error("Failed to create Master Key Provider", e);
                logger.trace(e.getStackTrace());
            }
            mkp = jmk.getMasterKeyProvider();
        }
        return mkp;
    }

    private MasterKeyProvider<?> getMasterKey(KeyProvider provider, String secretKey) {
        MasterKeyProvider<?> mkp = null;
        if ("JceMasterKeyProviderBuilder".equals(provider.getBuilderType())) {
            JceMasterKeyProviderBuilder<A, K> jmk = null;
            try {
                jmk = new JceMasterKeyProviderBuilder<A, K>(provider.getKeyType(), provider.getConfigs().get("keyStorePath"), provider.getConfigs().get("keyStoreCred"), provider.getConfigs().get("provider"), provider.getConfigs().get("keyId"), provider.getConfigs().get("wrappingAlgo"), secretKey);
            } catch (InvalidKeySpecException | NoSuchAlgorithmException | IOException | UnsupportedAlgoException | InvalidKeyException | UnsupportedKeyException | UnrecoverableKeyException | KeyStoreException | CertificateException e) {
                logger.error("Failed to create Master Key Provider", e);
                logger.trace(e.getStackTrace());
            }
            mkp = jmk.getMasterKeyProvider();
        } else if ("JceMasterKeyProviderBuilder-AES".equals(provider.getBuilderType())) {
            JceMasterKeyProviderBuilder<A, K> jmk = null;
            try {
                jmk = new JceMasterKeyProviderBuilder<>(secretKey);
            } catch (UnsupportedAlgoException | UnsupportedKeyException e) {
                logger.error("Failed to create Master Key Provider", e);
            }
            mkp = jmk.getMasterKeyProvider();
        }
        return mkp;
    }

}