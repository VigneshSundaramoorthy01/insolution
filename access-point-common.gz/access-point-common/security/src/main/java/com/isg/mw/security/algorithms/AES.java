package com.isg.mw.security.algorithms;

public class AES extends SupportedAlgorithms {
}
