package com.isg.mw.security.security;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bouncycastle.util.encoders.Hex;

import com.amazonaws.encryptionsdk.CryptoInputStream;
import com.amazonaws.encryptionsdk.CryptoResult;
import com.amazonaws.encryptionsdk.MasterKeyProvider;
import com.amazonaws.util.IOUtils;
import com.isg.mw.security.algorithms.SupportedAlgorithms;
import com.isg.mw.security.builder.MasterKeyProviderBuilder;
import com.isg.mw.security.exceptions.UnsupportedAlgoException;
import com.isg.mw.security.exceptions.UnsupportedKeyException;
import com.isg.mw.security.model.KeyProvider;
import org.springframework.core.io.ClassPathResource;

public class Decryptor<A extends SupportedAlgorithms, K extends Key> extends BaseSecurity<A, K> {

    private MasterKeyProvider<?> masterKeyProvider;
    private static final Logger logger = LogManager.getLogger(Decryptor.class);

    public Decryptor(String secretKey, String algorithm, String keydata)
            throws InvalidKeyException, UnrecoverableKeyException, InvalidKeySpecException, NoSuchAlgorithmException,
            KeyStoreException, CertificateException, IOException, UnsupportedAlgoException, UnsupportedKeyException {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(secretKey, algorithm, keydata).getMasterKeyProvider();
    }

    public Decryptor(String providerPath, String secretKey) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(providerPath, secretKey).getMasterKeyProvider();
    }

    public Decryptor(String providerPath) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(providerPath).getMasterKeyProvider();
    }

    public Decryptor(KeyProvider keyProvider) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(keyProvider).getMasterKeyProvider();
    }

    public Decryptor(List<KeyProvider> keyProviders) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(keyProviders).getMasterKeyProvider();
    }

    public Decryptor(File providerFile) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(providerFile).getMasterKeyProvider();
    }

    public String decrypt(final String data) {
        CryptoResult<byte[], ?> cr = crypto.decryptData(masterKeyProvider, Hex.decode(data));
        return new String(cr.getResult());
    }

    public File decryptFile(File inputFile) {
        File outputFile;
        try {
            outputFile = new File(inputFile.getAbsolutePath().replace("encrypted", "decrypted"));
            FileInputStream is = new FileInputStream(inputFile);
            CryptoInputStream<?> decryptingStream = this.crypto.createDecryptingStream(masterKeyProvider, is);
            FileOutputStream out = new FileOutputStream(outputFile);
            IOUtils.copy(decryptingStream, out);
            decryptingStream.close();
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        return outputFile;
    }

    public File decryptFileUtil(File inputFile) {
        File outputFile;
        try {
            FileInputStream is;
            outputFile = new File(inputFile.getAbsolutePath().replace(".encrypted", ""));
            try {
                is = new FileInputStream(inputFile);
            } catch (FileNotFoundException e) {
                ClassPathResource classPathResource = new ClassPathResource(inputFile.getPath());
                File keyStoreFile = new File(System.getProperty("user.home") + File.separator + "tmp");
                Files.copy(classPathResource.getInputStream(), keyStoreFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                is = new FileInputStream(keyStoreFile);
            }
            CryptoInputStream<?> decryptingStream = this.crypto.createDecryptingStream(masterKeyProvider, is);
            FileOutputStream out = new FileOutputStream(outputFile);
            IOUtils.copy(decryptingStream, out);
            decryptingStream.close();
            out.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        return outputFile;
    }
}