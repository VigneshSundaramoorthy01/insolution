package com.isg.mw.security.security;

import com.isg.mw.security.algorithms.SupportedAlgorithms;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.jcajce.JcaPGPObjectFactory;
import org.bouncycastle.openpgp.operator.bc.*;
import org.springframework.stereotype.Component;

import java.io.*;
import java.security.Key;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Iterator;

@Component
public class GpgEncryptor<A extends SupportedAlgorithms, K extends Key> extends BaseSecurity<A, K> {

    private String gpgPublicKeyPath;

    public GpgEncryptor() {
    }

    public GpgEncryptor(String publicKeyPath) {
        this.gpgPublicKeyPath = publicKeyPath;
    }

    public void encryptFile(String outputEncryptedFilePath, String fileToEncryptPath, String publicKeyPath)
            throws IOException, PGPException {
        PGPPublicKey encKey = readPublicKey(publicKeyPath);
        Security.addProvider(new BouncyCastleProvider());
        ByteArrayOutputStream bOut = new ByteArrayOutputStream();
        PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZIP);
        PGPUtil.writeFileToLiteralData(comData.open(bOut), PGPLiteralData.BINARY, new File(fileToEncryptPath));
        comData.close();

        PGPEncryptedDataGenerator cPk = new PGPEncryptedDataGenerator(
                new BcPGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.TRIPLE_DES)
                        .setSecureRandom(new SecureRandom()));
        cPk.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));
        byte[] bytes = bOut.toByteArray();
        OutputStream outputEncryptedStream = new FileOutputStream(outputEncryptedFilePath);
        OutputStream cOut = cPk.open(outputEncryptedStream, bytes.length);
        cOut.write(bytes);
        cOut.close();
        outputEncryptedStream.close();
    }

    public File encryptFile(File fileToEncrypt) {
        FileOutputStream outputStream = null;
        File outputEncryptedFile = null;
        try {
            Security.addProvider(new BouncyCastleProvider());
            ByteArrayOutputStream bOut = new ByteArrayOutputStream();
            PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZIP);
            PGPUtil.writeFileToLiteralData(comData.open(bOut), PGPLiteralData.BINARY, fileToEncrypt);
            comData.close();

            PGPEncryptedDataGenerator cPk = new PGPEncryptedDataGenerator(
                    new BcPGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.TRIPLE_DES)
                            .setSecureRandom(new SecureRandom()));
            PGPPublicKey encKey = readPublicKey(gpgPublicKeyPath);
            cPk.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));
            byte[] bytes = bOut.toByteArray();
            outputEncryptedFile = new File(fileToEncrypt.getName() + ".encrypted.gpg");
            outputStream = new FileOutputStream(outputEncryptedFile);
            OutputStream cOut = cPk.open(outputStream, bytes.length);
            cOut.write(bytes);
            cOut.close();
        } catch (IOException | PGPException e) {
            e.printStackTrace();
        } finally {
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return outputEncryptedFile;
    }

    public void decryptFile(String encryptedFilepath, String privateKeyPath,
                            String outputFilePath, char[] pass) throws IOException, PGPException {
        InputStream in = new FileInputStream(encryptedFilepath);
        Security.addProvider(new BouncyCastleProvider());
        PGPSecretKey secKey;
        in = PGPUtil.getDecoderStream(in);
        JcaPGPObjectFactory pgpFact;
        PGPObjectFactory pgpF = new PGPObjectFactory(in, new BcKeyFingerprintCalculator());
        Object o = pgpF.nextObject();
        PGPEncryptedDataList encList;

        if (o instanceof PGPEncryptedDataList) {
            encList = (PGPEncryptedDataList) o;
        } else {
            encList = (PGPEncryptedDataList) pgpF.nextObject();
        }

        Iterator<PGPPublicKeyEncryptedData> itt = encList.getEncryptedDataObjects();
        PGPPrivateKey sKey = null;
        PGPPublicKeyEncryptedData encP = null;
        while (sKey == null && itt.hasNext()) {
            encP = itt.next();
            secKey = readSecretKey(new FileInputStream(privateKeyPath), encP.getKeyID());
            sKey = secKey.extractPrivateKey(
                    new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider()).build(pass));
        }
        if (sKey == null) {
            throw new IllegalArgumentException("Secret key for message not found.");
        }

        InputStream clear = encP.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));
        pgpFact = new JcaPGPObjectFactory(clear);
        PGPCompressedData c1 = (PGPCompressedData) pgpFact.nextObject();
        pgpFact = new JcaPGPObjectFactory(c1.getDataStream());
        PGPLiteralData ld = (PGPLiteralData) pgpFact.nextObject();
        ByteArrayOutputStream bOut = new ByteArrayOutputStream();

        InputStream inLd = ld.getDataStream();
        int ch;
        while ((ch = inLd.read()) >= 0) {
            bOut.write(ch);
        }
        bOut.writeTo(new FileOutputStream(outputFilePath + ld.getFileName() + ".decrypted.gpg"));
    }

    public PGPPublicKey readPublicKey(String publicKeyPath) throws IOException, PGPException {
        FileInputStream fileInputStream = new FileInputStream(publicKeyPath);
        InputStream in = PGPUtil.getDecoderStream(fileInputStream);
        PGPPublicKeyRingCollection pgpPub = new PGPPublicKeyRingCollection(in, new BcKeyFingerprintCalculator());
        PGPPublicKey key = null;
        Iterator rIt = pgpPub.getKeyRings();
        while (key == null && rIt.hasNext()) {
            PGPPublicKeyRing kRing = (PGPPublicKeyRing) rIt.next();
            Iterator kIt = kRing.getPublicKeys();
            while (key == null && kIt.hasNext()) {
                PGPPublicKey k = (PGPPublicKey) kIt.next();
                if (k.isEncryptionKey()) {
                    key = k;
                }
            }
        }
        if (key == null) {
            throw new IllegalArgumentException("Can't find encryption key in key ring.");
        }
        return key;
    }

    private PGPSecretKey readSecretKey(InputStream in, long keyId) throws IOException, PGPException {
        in = PGPUtil.getDecoderStream(in);
        PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(in, new BcKeyFingerprintCalculator());
        PGPSecretKey key = pgpSec.getSecretKey(keyId);
        if (key == null) {
            throw new IllegalArgumentException("Can't find encryption key in key ring.");
        }
        return key;
    }

}
