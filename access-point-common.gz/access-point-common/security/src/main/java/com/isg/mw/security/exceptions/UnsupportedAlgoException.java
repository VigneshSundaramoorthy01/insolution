package com.isg.mw.security.exceptions;

public class UnsupportedAlgoException extends Throwable {
    public UnsupportedAlgoException(String msg) {
        super(msg);
    }
}
