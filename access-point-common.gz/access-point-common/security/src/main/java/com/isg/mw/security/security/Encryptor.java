package com.isg.mw.security.security;

import com.amazonaws.encryptionsdk.CryptoInputStream;
import com.amazonaws.encryptionsdk.CryptoResult;
import com.amazonaws.encryptionsdk.MasterKeyProvider;
import com.amazonaws.util.IOUtils;
import com.isg.mw.security.algorithms.SupportedAlgorithms;
import com.isg.mw.security.builder.MasterKeyProviderBuilder;
import com.isg.mw.security.model.KeyProvider;
import org.bouncycastle.util.encoders.Hex;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.security.Key;
import java.util.List;

public class Encryptor<A extends SupportedAlgorithms, K extends Key> extends BaseSecurity<A, K> {

    private MasterKeyProvider<?> masterKeyProvider;

    public Encryptor(String providerPath) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(providerPath).getMasterKeyProvider();
    }

    public Encryptor(String providerPath,String secretKey) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(providerPath, secretKey).getMasterKeyProvider();
    }

    public Encryptor(KeyProvider keyProvider) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(keyProvider).getMasterKeyProvider();
    }

    public Encryptor(List<KeyProvider> keyProviders) {
        super();
        masterKeyProvider = new MasterKeyProviderBuilder<A, K>(keyProviders).getMasterKeyProvider();
    }

    public String encrypt(String data) {
        try {
            CryptoResult<byte[], ?> cr = this.crypto.encryptData(masterKeyProvider, data.getBytes());
            byte[] b = cr.getResult();
            return Hex.toHexString(b);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public File encryptFile(File inputFile) {
        File outputFile = null;
        CryptoInputStream<?> encryptingStream = null;
        try {
            outputFile = new File(inputFile.getName() + ".encrypted");
            FileInputStream is = new FileInputStream(inputFile);
            encryptingStream = this.crypto.createEncryptingStream(masterKeyProvider, is);
            FileOutputStream out = new FileOutputStream(inputFile.getParent() + "/" + outputFile);
            IOUtils.copy(encryptingStream, out);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                encryptingStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return outputFile;
    }

}
