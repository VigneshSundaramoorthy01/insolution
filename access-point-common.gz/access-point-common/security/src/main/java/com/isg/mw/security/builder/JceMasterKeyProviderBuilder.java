package com.isg.mw.security.builder;

import com.amazonaws.encryptionsdk.MasterKeyProvider;
import com.amazonaws.encryptionsdk.jce.JceMasterKey;
import com.isg.mw.security.algorithms.AES;
import com.isg.mw.security.algorithms.SupportedAlgorithms;
import com.isg.mw.security.exceptions.UnsupportedAlgoException;
import com.isg.mw.security.exceptions.UnsupportedKeyException;
import com.isg.mw.security.model.SecurityKeyType;
import com.isg.mw.security.security.Decryptor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;


/**
 * Builds JceMasterKey from Java Key Store
 *
 * @param <A>
 * @param <K>
 */
public class JceMasterKeyProviderBuilder<A extends SupportedAlgorithms, K extends Key> {

    private static Logger LOG = LogManager.getLogger(JceMasterKeyProviderBuilder.class);

    /**
     * Read RSA_WRAPPING_ALGORITHM, RSA_KEY_SIZE, ESCROW_PROVIDER, ESCROW_KEYID from
     * properties file
     */
    private static final String DEFAULT_RSA_WRAPPING_ALGORITHM = "RSA/ECB/PKCS1Padding";
    private static final String DEFAULT_ESCROW_PROVIDER = "escrow-isg";
    private static final String DEFAULT_ESCROW_KEYID = "escrow-isg-keyid";
    private static final String AES_ALORITHM = "AES/GCM/NoPadding";

    private final String escrowProvider;
    private final String escrowKeyId;
    private final String escrowAlgo;
    private final String keyStorePath;
    private String keyStoreCred;
    private SecurityKeyType keyType;
    private String secretKey;
    private MasterKeyProvider<?> masterKeyProvider;

    private KeyStore keystore;

    JceMasterKeyProviderBuilder(SecurityKeyType keyType, String ksPath, String ksCred, String escrowProvider, String escrowKeyId, String escrowAlgo, String secretKey) throws UnsupportedAlgoException, InvalidKeySpecException, NoSuchAlgorithmException, UnsupportedKeyException, IOException, InvalidKeyException, UnrecoverableKeyException, KeyStoreException, CertificateException {
        this.keyType = keyType;
        this.keyStorePath = ksPath;
        this.keyStoreCred = ksCred;
        this.escrowProvider = escrowProvider;
        this.escrowKeyId = escrowKeyId;
        this.escrowAlgo = escrowAlgo;
        this.secretKey = secretKey;
        buildMasterKey();
    }

    JceMasterKeyProviderBuilder(String ksPath, String ksCred) throws UnsupportedAlgoException, InvalidKeySpecException, NoSuchAlgorithmException, UnsupportedKeyException, IOException, InvalidKeyException, UnrecoverableKeyException, KeyStoreException, CertificateException {
        escrowProvider = DEFAULT_ESCROW_PROVIDER;
        escrowKeyId = DEFAULT_ESCROW_KEYID;
        escrowAlgo = DEFAULT_RSA_WRAPPING_ALGORITHM;
        keyStorePath = ksPath;
        keyStoreCred = ksCred;
        buildMasterKey();
    }

    JceMasterKeyProviderBuilder(String secretKey) throws UnsupportedAlgoException, UnsupportedKeyException {
        escrowProvider = DEFAULT_ESCROW_PROVIDER;
        escrowKeyId = DEFAULT_ESCROW_KEYID;
        escrowAlgo = DEFAULT_RSA_WRAPPING_ALGORITHM;
        keyStorePath = null;
        keyStoreCred = null;
        this.secretKey = secretKey;
        buildAESMasterKey(secretKey);
    }

    public MasterKeyProvider<?> getMasterKeyProvider() {
        return masterKeyProvider;
    }

    private void buildAESMasterKey(String secretKey) {
        masterKeyProvider = buildAESMasterkey(secretKey);
    }

    private void buildMasterKey() throws InvalidKeySpecException, NoSuchAlgorithmException, UnsupportedKeyException, IOException, UnsupportedAlgoException, InvalidKeyException, KeyStoreException, CertificateException, UnrecoverableKeyException {

        keystore = KeyStore.getInstance("JCEKS");
        Decryptor<AES, SecretKey> decryptor;
        FileInputStream stream;
        File decryptedKeyStoreFile = null;

        if (keyType == SecurityKeyType.PRIVATE) {
            decryptor = new Decryptor<>(secretKey, "AES", null);
            decryptedKeyStoreFile = decryptor.decryptFileUtil(new File(keyStorePath));
            stream = new FileInputStream(decryptedKeyStoreFile);
        } else if (keyType == SecurityKeyType.SECRET) {
            decryptor = new Decryptor<>(secretKey, "AES", null);
            decryptedKeyStoreFile = decryptor.decryptFileUtil(new File(keyStorePath));
            stream = new FileInputStream(decryptedKeyStoreFile);
        } else {
            stream = new FileInputStream(keyStorePath);
        }

        if (keyStoreCred != null) {
            keystore.load(stream, keyStoreCred.toCharArray());
        } else {
            keystore.load(stream, null);
        }

        if (escrowAlgo.startsWith("RSA")) {
            masterKeyProvider = buildRSAMasterKey();
        } else if (escrowAlgo.startsWith("AES")) {
            final byte[] ksBytes = Files.readAllBytes(new File(keyStorePath).toPath());
            masterKeyProvider = buildAESMasterKey(ksBytes);
        } else {
            throw new UnsupportedAlgoException("Should never come here");
        }
        if (decryptedKeyStoreFile != null) {
            //deleting the decrypted JKS file, as it is not needed not disk once loaded into memory
            decryptedKeyStoreFile.delete();
        }
    }

    /**
     * Load the RSA public key from a pkcs#12 file and make a MasterKey from it.
     */
    private JceMasterKey buildRSAMasterKey() throws NoSuchAlgorithmException, UnsupportedKeyException, KeyStoreException, UnrecoverableKeyException {

        Certificate cert = keystore.getCertificate(escrowKeyId);
        final PublicKey rsaPubKey = cert.getPublicKey();

        JceMasterKey rsaMasterKey = null;
        if (keyType == SecurityKeyType.PRIVATE) {
            final PrivateKey privateKey = (PrivateKey) keystore.getKey(escrowKeyId, keyStoreCred.toCharArray());
            rsaMasterKey = JceMasterKey.getInstance(null, privateKey, escrowProvider, escrowKeyId, escrowAlgo);
            LOG.info("Created Master Key with RSA Private Key...");
        } else if (keyType == SecurityKeyType.PUBLIC) {
            rsaMasterKey = JceMasterKey.getInstance(rsaPubKey, null, escrowProvider, escrowKeyId, escrowAlgo);
            LOG.info("Created Master Key with RSA Public Key...");
        } else {
            LOG.info("Unknown security key type...");
            throw new UnsupportedKeyException("Should never come here");
        }
        return rsaMasterKey;
    }

    /**
     * Load the AES key from a pkcs#12 file and make a MasterKey from it.
     *
     * @param aesBytes byte[]
     */
    private JceMasterKey buildAESMasterKey(byte[] aesBytes) throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException {

        final SecretKey secretKey = (SecretKey) keystore.getKey(escrowKeyId, keyStoreCred.toCharArray());
        LOG.info("Created Master Key with AES security Key...");
        return JceMasterKey.getInstance(secretKey, escrowProvider, escrowKeyId, escrowAlgo);

    }

    private JceMasterKey buildAESMasterkey(String secretKey) {

        byte[] decodedKey = Base64.getDecoder().decode(secretKey);
        SecretKey secKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
        LOG.info("Created Master Key with AES security Key for file encryption and decryption...");
        return JceMasterKey.getInstance(secKey, DEFAULT_ESCROW_PROVIDER, DEFAULT_ESCROW_KEYID, AES_ALORITHM);
    }

}