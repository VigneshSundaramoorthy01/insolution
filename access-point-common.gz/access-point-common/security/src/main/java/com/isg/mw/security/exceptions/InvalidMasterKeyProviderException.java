package com.isg.mw.security.exceptions;

public class InvalidMasterKeyProviderException extends RuntimeException {
    public InvalidMasterKeyProviderException(String msg) {
        super(msg);
    }
}
