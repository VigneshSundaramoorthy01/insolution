package com.isg.mw.security.security;

import java.security.Key;

import com.amazonaws.encryptionsdk.AwsCrypto;
import com.isg.mw.security.algorithms.SupportedAlgorithms;

public abstract class BaseSecurity<A extends SupportedAlgorithms, K extends Key> {
	
    protected AwsCrypto crypto;

    protected BaseSecurity() {
        crypto = new AwsCrypto();
    }
}
