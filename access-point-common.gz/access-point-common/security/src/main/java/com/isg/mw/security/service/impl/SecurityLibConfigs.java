package com.isg.mw.security.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author prasad_t026
 *
 */
@PropertySource("classpath:securitylib.properties")
@Configuration
@Setter
@Getter
public class SecurityLibConfigs {

	@Value("${security.providers.publickey}")
	private String publicKeyProvider;

	@Value("${security.providers.privatekey}")
	private String privateKeyProvider;

	@Value("${security.providers.secretkey}")
	private String secretKeyProvider;

}
