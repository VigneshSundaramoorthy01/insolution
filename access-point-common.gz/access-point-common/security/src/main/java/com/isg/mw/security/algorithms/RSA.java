package com.isg.mw.security.algorithms;

public class RSA extends SupportedAlgorithms {
}
