package com.isg.lang.config;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

import com.isg.mw.core.utils.StringUtils;

@Configuration
@PropertySource("${spring.config.location}appconfig.properties")
public class LocaleResolver extends AcceptHeaderLocaleResolver implements WebMvcConfigurer {

	@Value("${resource.message.bundle.path:}")
	private String path;

	@Value("${resource.bundle.basename:messages}")
	private String basename;

	@Value("${character.encoding:UTF-8}")
	private String charEncoding;

	@Value("${cache.time.second:3600}")
	private Integer cacheSeconds;

	private static final String FILE = "file:";


	@Override
	public Locale resolveLocale(HttpServletRequest request) {
		String language = request.getHeader("Accept-Language");
		return StringUtils.isBlank(language) ? Locale.getDefault()
				: Locale.lookup(Locale.LanguageRange.parse(language), getLocales());
	}

	private List<Locale> getLocales() {
		return Arrays.asList(Locale.getISOLanguages()).stream().map(Locale::new).collect(Collectors.toList());
	}

	@Bean
	public ReloadableResourceBundleMessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasename(new StringBuilder().append(FILE).append(path).append(File.separatorChar).append(basename).toString());
		messageSource.setDefaultEncoding(charEncoding);
		messageSource.setCacheSeconds(cacheSeconds);
		messageSource.setUseCodeAsDefaultMessage(true);
		return messageSource;
	}
}
