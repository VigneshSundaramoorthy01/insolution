package com.isg.mw.core.model.pos;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class MosambeeRegTidResponseModel implements Serializable {

    private String result;
    private String message;
    private String responseCode;
    private String midRefId;
    private String resMessage;
    private List<TidDetailResponseModel> tidDetails;

    @Data
    public static class TidDetailResponseModel implements Serializable {
        private String responseCode;
        private String message;
        private String tid;
        private String userName;
        private String tidRefId;
    }
}