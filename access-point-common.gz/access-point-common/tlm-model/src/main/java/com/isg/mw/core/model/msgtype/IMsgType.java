package com.isg.mw.core.model.msgtype;

public interface IMsgType {

	public boolean equals(String msgType, String msgSubType);
}