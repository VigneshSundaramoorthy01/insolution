package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.utils.DateFormatUtils;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
public class MerchantRefundRes extends CommonMerchantPayReq{

    @JsonProperty("PassCode")
    private String passCode;

    @JsonProperty("RefundAmount")
    private String refundAmount;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("Message")
    private String message;

    @JsonProperty("RetRefNo")
    private String retRefNo;

    @JsonProperty("AuthCode")
    private String authCode;

    @JsonProperty("refCancelId")
    private String RefCancelId;

    @JsonProperty("BatchNo")
    private String batchNo;

    @JsonProperty("RespDate")
    private String respDate;

    @JsonProperty("RespTime")
    private String respTime;

    public void setRespDate(OffsetDateTime respDate) {
        if(respDate == null){
            respDate = OffsetDateTime.now();
        }
        this.respDate = DateFormatUtils.getISODateOrTime(respDate,"dd-MM-yyyy");
    }

    public void setRespTime(OffsetDateTime respTime) {
        if(respTime == null){
            respTime = OffsetDateTime.now();
        }
        this.respTime = DateFormatUtils.getISODateOrTime(respTime,"HH:mm");;
    }

    @Override
    public String toString() {
        return "MerchantRefundRes{" +
                "passCode='" + passCode + '\'' +
                ", refundAmount='" + refundAmount + '\'' +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", retRefNo='" + retRefNo + '\'' +
                ", authCode='" + authCode + '\'' +
                ", RefCancelId='" + RefCancelId + '\'' +
                ", batchNo='" + batchNo + '\'' +
                ", respDate='" + respDate + '\''+
                ", respTime='" + respTime + '\''+
                "} " + super.toString();
    }

    public MerchantRefundRes getMerchantRefundDataRes(MerchantCheckStatusAndRefundReq req) {
        MerchantRefundRes res = new MerchantRefundRes();
        res.setBankId(req.getBankId());
        res.setMerchantId(req.getMerchantId());
        res.setTerminalId(req.getTerminalId());
        res.setTxnRefNo(req.getTxnRefNo());
        res.setTxnType(req.getTxnType());
        res.setRefundAmount(req.getRefundAmount());
        res.setRetRefNo(req.getRetRefNo());
        res.setAuthCode(req.getAuthCode());
        res.setPassCode(req.getPassCode());
        res.setRefCancelId(req.getRefCancelId());
        res.setSecureHash(req.getSecureHash());
        return res;
    }
}