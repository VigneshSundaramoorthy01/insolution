package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MerchantInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MerchantDescriptor merchantDescriptor;
    private String domainName;
    private String salesOrganizationId;
    private String categoryCode;
    private String categoryCodeDomestic;
    private String taxId;
    private String vatRegistrationNumber;
    private String cardAcceptorReferenceNumber;
    private String transactionLocalDateTime;
    private ServiceFeeDescriptor serviceFeeDescriptor;
    private String merchantName;
}