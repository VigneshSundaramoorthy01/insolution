package com.isg.mw.core.model.constants;

public enum EpType {
    SOURCE,

    TARGET;

    public boolean isSource(String epType) {
        return EpType.SOURCE.name().equals(epType);
    }

    public boolean isTarget(String epType) {
        return EpType.TARGET.name().equals(epType);
    }
}
