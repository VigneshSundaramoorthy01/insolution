package com.isg.mw.core.model.payu;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;

import java.util.Date;

@Data
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@JsonTypeName("merchant")
public class PayUMerchantModel {
    @JsonProperty("name")
    String name;
    @JsonProperty("email")
    String email;
    @JsonProperty("registered_mobile")
    String registeredMobile;
    @JsonProperty("mid")
    int mid;
    @JsonProperty("product")
    String product;
    @JsonProperty("business_type")
    String businessType;
    @JsonProperty("business_name")
    String businessName;
    @JsonProperty("pancard_name")
    String pancardName;
    @JsonProperty("pancard_number")
    String pancardNumber;
    @JsonProperty("website_url")
    String websiteUrl;
    @JsonProperty("android_url")
    String androidUrl;
    @JsonProperty("ios_url")
    String iosUrl;
    @JsonProperty("gst_number")
    String gstNumber;
    @JsonProperty("created_at")
    Date createdAt;
    @JsonProperty("mobile")
    String mobile;
    @JsonProperty("blocked")
    boolean blocked;
    @JsonProperty("first_name")
    String firstName;
    @JsonProperty("last_name")
    String lastName;
    @JsonProperty("bank_detail")
    BankDetail bankDetail;
    @JsonProperty("operating_address")
    OperatingAddress operatingAddress;
    @JsonProperty("registration_address")
    RegistrationAddress registrationAddress;
    @JsonProperty("business_entity")
    String businessEntity;
    @JsonProperty("status")
    String status;
    @JsonProperty("partner_source")
    String partnerSource;
    @JsonProperty("pan_verification_status")
    String pan_verificationStatus;
    @JsonProperty("website_approval_status")
    String website_approvalStatus;
    @JsonProperty("notification_email")
    String notificationEmail;
    @JsonProperty("settlement_status")
    String settlementStatus;
    @JsonProperty("is_service_agreement_accepted")
    boolean isServiceAgreementAccepted;
    @JsonProperty("is_authorisation_letter_required")
    boolean isAuthorisationLetterRequired;
    @JsonProperty("monthly_expected_volume")
    String monthlyExpectedVolume;
    @JsonProperty("business_category")
    String businessCategory;
    @JsonProperty("business_sub_category")
    String businessSubCategory;
    @JsonProperty("bank_verification_status")
    String bankVerificationStatus;
    @JsonProperty("uuid")
    String uuid;
    @JsonProperty("penny_deposit_status")
    String pennyDepositStatus;
    @JsonProperty("document_status")
    String documentStatus;
    @JsonProperty("service_intent")
    String serviceIntent;
    @JsonProperty("kyc_status")
    public KycStatus kyc_status;
    @JsonProperty("agreement_status")
    public String agreement_status;
    @JsonProperty("integration_type")
    public String integration_type;

    public String resMessage;

    public static class OperatingAddress {
        @JsonProperty("address_line")
        String addressLine;
        @JsonProperty("city")
        String city;
        @JsonProperty("state")
        String state;
        @JsonProperty("pincode")
        String pinCode;
    }

    public static class RegistrationAddress {
        @JsonProperty("address_line")
        String addressLine;
        @JsonProperty("city")
        String city;
        @JsonProperty("state")
        String state;
        @JsonProperty("pincode")
        String pinCode;
    }

    public static class BankDetail {
        @JsonProperty("bank_account_number")
        String bankAccountNumber;
        @JsonProperty("ifsc_code")
        String ifscCode;
        @JsonProperty("holder_name")
        String holderName;
        @JsonProperty("nodal_code")
        String nodalCode;
        @JsonProperty("nodal_status")
        String nodalStatus;
    }

    public static class KycStatus {
        @JsonProperty("status")
        public String status;
        @JsonProperty("kyc_status")
        public String kycStatus;
    }

}
