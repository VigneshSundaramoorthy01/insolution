package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
public class CommonMerchantEncReqRes {
    @JsonProperty("BankId")
    private String bankId;

    @JsonProperty("MerchantId")
    private String merchantId;

    @JsonProperty("TerminalId")
    private String terminalId;

    @JsonProperty("TxnRefNo")
    private String txnRefNo;

    @JsonProperty("MCC")
    private String mcc;

    @JsonProperty("PassCode")
    private String passCode;

    @JsonProperty("Currency")
    private String currency;

    @JsonProperty("Amount")
    private String amount;

    @JsonProperty("OrderInfo")
    private String orderInfo;

    @JsonProperty("payOpt")
    private String payOpt;

    @JsonProperty("FirstName")
    private String firstName;

    @JsonProperty("LastName")
    private String lastName;

    @JsonProperty("Street")
    private String street;

    @JsonProperty("City")
    private String city;

    @JsonProperty("State")
    private String state;

    @JsonProperty("ZIP")
    private String zip;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("Phone")
    private String phone;

    @JsonProperty("UDF01")
    private String udf01;

    @JsonProperty("UDF02")
    private String udf02;

    @JsonProperty("UDF03")
    private String udf03;

    @JsonProperty("UDF04")
    private String udf04;

    @JsonProperty("UDF05")
    private String udf05;

    @JsonProperty("UDF06")
    private String udf06;

    @JsonProperty("UDF07")
    private String udf07;

    @JsonProperty("UDF08")
    private String udf08;

    @JsonProperty("UDF09")
    private String udf09;

    @JsonProperty("UDF10")
    private String udf10;

    @JsonProperty("chUserID")
    private String chUserID;

    @JsonProperty("CardTokenReferenceNo")
    private String cardTokenReferenceNo;

    @JsonProperty("SecureHash")
    private String secureHash;

    @JsonProperty("Version")
    private String version;

    @Override
    public String toString() {
        return  "  bankId='" + bankId + '\'' +
                ", merchantId='" + merchantId + '\'' +
                ", terminalId='" + terminalId + '\'' +
                ", txnRefNo='" + txnRefNo + '\'' +
                ", mcc='" + mcc + '\'' +
                ", passCode='" + passCode + '\'' +
                ", currency='" + currency + '\'' +
                ", amount='" + amount + '\'' +
                ", orderInfo='" + orderInfo + '\'' +
                ", payOpt='" + payOpt + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zip='" + zip + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", udf01='" + udf01 + '\'' +
                ", udf02='" + udf02 + '\'' +
                ", udf03='" + udf03 + '\'' +
                ", udf04='" + udf04 + '\'' +
                ", udf05='" + udf05 + '\'' +
                ", udf06='" + udf06 + '\'' +
                ", udf07='" + udf07 + '\'' +
                ", udf08='" + udf08 + '\'' +
                ", udf09='" + udf09 + '\'' +
                ", udf10='" + udf10 + '\'' +
                ", chUserID='" + chUserID + '\'' +
                ", cardTokenReferenceNo='" + cardTokenReferenceNo + '\'' +
                ", secureHash='" + secureHash + '\'' +
                ", version='" + version + '\'' +
                ']';
    }
}
