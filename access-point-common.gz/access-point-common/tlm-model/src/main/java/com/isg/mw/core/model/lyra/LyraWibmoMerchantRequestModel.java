package com.isg.mw.core.model.lyra;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LyraWibmoMerchantRequestModel implements Serializable {
    public String trTsp;
    public String merchantId;
    public String merchantLegalName;
    public String merchantTradeName;
    public String companyCity;
    public String companyCountryCode;
    public String dpaUri;
    public List<String> originDomains;
    public List<AcquirerData> acquirerData;
    public String clientReferenceId;

    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AcquirerData implements Serializable {
        public String acquirerMerchantId;
        public String acquirerIca;
        public String acquiredBin;
    }
}