package com.isg.mw.core.model.tpsl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.model.common.FundTransferRequestModel;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class TpslRefundRequestModel {

    @JsonProperty("merchant")
    public Merchant merchant = new Merchant();

    @JsonProperty("cart")
    public Cart cart = new Cart();

    @JsonProperty("transaction")
    public Transaction transaction = new Transaction();

    @Data
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Merchant {
        private String identifier;
    }

    @Data
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Cart {
    }

    @Data
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Transaction {
        private String deviceIdentifier;

        private String amount;

        private String currency;

        private String dateTime;

        private String token;

        private String requestType;
    }
}
