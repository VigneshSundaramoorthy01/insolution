package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class AmountDetail implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String totalAmount;
    private String currency;
    private String discountAmount;
    private String dutyAmount;
    private String gratuityAmount;
    private String taxAmount;
    private String nationalTaxIncluded;
    private String taxAppliedAfterDiscount;
    private String taxAppliedLevel;
    private String taxTypeCode;
    private String freightAmount;
    private String foreignAmount;
    private String foreignCurrency;
    private String exchangeRate;
    private String exchangeRateTimeStamp;
    private Surcharge surcharge;
    private String settlementAmount;
    private String settlementCurrency;
    private List<AmexAdditionalAmount> amexAdditionalAmounts;
    private List<TaxDetail> taxDetails;
    private String serviceFeeAmount;
    private String originalAmount;
    private String originalCurrency;
    private String cashbackAmount;
    private CurrencyConversion currencyConversion;
    private String amountType;
    private String amount;
}