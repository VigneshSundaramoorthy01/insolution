package com.isg.mw.core.model.tlm;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.PaymentStatus;
import com.isg.mw.core.utils.OffsetDateTimeOptionalZoneDeserializer;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class PaymentLinksModel extends AcpTraceIdModel implements Serializable {

    private String paymentLinkId;

    private String linkHashId;

    private String mid;

    private String tid;

    private String entityId;

    private String orderId;

    private String amount;

    private String remark;

    private String mobileNo;

    private String emailId;

    /*
    Status will be (pending/failed/success/expired)
    */
    private PaymentStatus status;

    @JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private OffsetDateTime linkExpiryDate;

    @JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private OffsetDateTime statusDate;

    private Integer paymentAttemptCounter = 0;

    private String paymentLink;

    private String udf01;

    private String udf02;

    private String udf03;

    private String udf04;

    private String udf05;

    private String udf06;

    private String udf07;

    private String udf08;

    private String udf09;

    private String udf10;

    private String fileName;

    private String staticFileName;

    private String refNo;

    private String numberOfFileRecord;

    private String shortnerId;

    private String smsEnabled;

    private String partialPay;

    private String emailEnabled;

    private String secureHash;

    //private int endOfset;
    private String responseCode;

    private String message;

    private int endOfset;


    public PaymentLinksModel getMerchantPaymentLinksDataRes(PaymentLinksModel req){
        PaymentLinksModel response = new PaymentLinksModel();
        response.setEntityId(req.getEntityId());
        response.setMid(req.getMid());
        response.setTid(req.getTid());
        response.setPaymentLinkId(req.getPaymentLinkId());
        response.setPaymentLink(req.getPaymentLink());
        response.setRemark(req.getRemark());
        response.setOrderId(req.getOrderId());
        response.setSecureHash(req.getSecureHash());
        response.setUdf01(req.getUdf01());
        response.setUdf02(req.getUdf02());
        response.setUdf03(req.getUdf03());
        response.setUdf04(req.getUdf04());
        response.setUdf05(req.getUdf05());
        response.setUdf06(req.getUdf06());
        response.setUdf07(req.getUdf07());
        response.setUdf08(req.getUdf08());
        response.setUdf09(req.getUdf09());
        response.setUdf10(req.getUdf10());
        return response;
    }
}

