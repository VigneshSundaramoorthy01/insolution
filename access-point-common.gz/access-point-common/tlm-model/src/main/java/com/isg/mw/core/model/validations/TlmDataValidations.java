package com.isg.mw.core.model.validations;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.TimeZone;
import java.util.regex.Pattern;

import com.isg.mw.core.model.constants.TlmFieldsInfo;
import com.isg.mw.core.model.constants.TxnDataType;
import com.isg.mw.core.model.exception.ValidationException;
import com.isg.mw.core.utils.DateFormatUtils;

public class TlmDataValidations {

	private TlmDataValidations() {

	}

	public static final String MANDATORY_TLM_DATA_ERROR = "tlm.data.validation.field.mandatory";

	public static final String EXCEEDED_TLM_DATA_LENGTH_ERROR = "tlm.validation.length.exceeded";

	public static final String FAILED_TLM_DATA_EXPRESSION_ERROR = "tlm.validation.data.expression";

	public static final String INVALID_TLM_DATA_ERROR = "tlm.validation.invalid.data";

	public static final String INVALID_TLM_AFTER_DATE = "tlm.validation.invalid.after.date";

	public static final String INVALID_TLM_BEFORE_DATE = "tlm.validation.invalid.before.date";

	public static final String PRECISE_TLM_DATA_LENGTH_ERROR = "tlm.validation.length.precise";

	
	public static void tlmFieldValidation(String data, String expression, String fieldName, boolean mandatory,
			int length) {

		if (mandatory) {
			if (data == null || data.isEmpty()) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, fieldName);
			}
		} else if (data == null || data.isEmpty()) {
			return;
		}
		if (data.length() > length) {
			throw new ValidationException(EXCEEDED_TLM_DATA_LENGTH_ERROR, fieldName,length);
		}
		if (expression != null) {
			if (!Pattern.matches(expression, data)) {
				throw new ValidationException(FAILED_TLM_DATA_EXPRESSION_ERROR, fieldName);
			}
		}

	}
	
	public static void optionalValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		if (data.length() <= TlmFieldsInfo.RRN_FL) {
			rrnTxnIdDataValidation(data, TlmFieldsInfo.RRN_EX, TlmFieldsInfo.RRN_FN, m, TlmFieldsInfo.RRN_FL);
		}
		rrnTxnIdDataValidation(data, TlmFieldsInfo.TXN_ID_EX, TlmFieldsInfo.TXN_ID_FN, m, TlmFieldsInfo.TXN_ID_FL);

	}

	public static void dcfFileTypeValiations(String fileType, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (fileType == null) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, TlmFieldsInfo.DCF_TYPE_FN);
			}
		}

	}

	public static void txnDataTypeValiations(TxnDataType txnDataType, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}

		if (m) {
			if (txnDataType == null) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, TlmFieldsInfo.TXN_DATA_TYPE);
			}
		}

	}
	
	public static void dateToValidations(String dateFrom, String dateTo) throws DateTimeParseException {
		OffsetDateTime dFrom = OffsetDateTime.parse(dateFrom, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
		OffsetDateTime dto = OffsetDateTime.parse(dateTo, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
		TimeZone timeZone = DateFormatUtils.getTimeZone();
		if (dto.isAfter(OffsetDateTime.now(timeZone.toZoneId()))) {
			throw new ValidationException(INVALID_TLM_AFTER_DATE, dto);
		}
		if (dto.isBefore(dFrom)) {
			throw new ValidationException(INVALID_TLM_BEFORE_DATE, dto);
		}

	}

	public static void dateFromValidations(String dateFrom) throws DateTimeParseException {

		OffsetDateTime javaDate = OffsetDateTime.parse(dateFrom, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
		TimeZone timeZone = DateFormatUtils.getTimeZone();
		if (javaDate.isAfter(OffsetDateTime.now(timeZone.toZoneId()))) {
			throw new ValidationException(INVALID_TLM_AFTER_DATE, javaDate);
		}
	}

	public static void entityIdValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		tlmFieldValidation(data, TlmFieldsInfo.ENTITY_ID_EX, TlmFieldsInfo.ENTITY_ID_FN, m,
				TlmFieldsInfo.ENTITY_ID_FL);

	}

	public static void loginUserValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		tlmFieldValidation(data, TlmFieldsInfo.LOGIN_USER_EX, TlmFieldsInfo.LOGIN_USER_FN, m,
				TlmFieldsInfo.LOGIN_USER_FL);

	}

	public static void rrnTxnIdDataValidation(String data, String expression, String fieldName, boolean mandatory,
			int length) {

		if (mandatory) {
			if (data == null || data.isEmpty()) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, fieldName);
			}
		} else if (data == null || data.isEmpty()) {
			return;
		}
		if (data.length() < TlmFieldsInfo.RRN_FL || data.length() > TlmFieldsInfo.TXN_ID_FL) {
			throw new ValidationException(PRECISE_TLM_DATA_LENGTH_ERROR, fieldName, length);
		}
		if (expression != null) {
			if (!Pattern.matches(expression, data)) {
				throw new ValidationException(FAILED_TLM_DATA_EXPRESSION_ERROR, fieldName, expression);
			}
		}

	}
	
	public static void idValidations(Long id, boolean mandatory) {
		if (mandatory) {
			if (id == null) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, TlmFieldsInfo.ID_FN);
			}
		}
		if (id <= 0) {
			throw new ValidationException(INVALID_TLM_DATA_ERROR, TlmFieldsInfo.ID_FN);
		}
	} 
	
	public static void pageSizeValidations(Integer pageSize, boolean mandatory) {
		if (mandatory) {
			if (pageSize == 0) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, TlmFieldsInfo.PAGE_SIZE_FN);
			}
		} else if (pageSize == 0) {
			return;
		}

		if (pageSize <= 0) {
			throw new ValidationException(INVALID_TLM_DATA_ERROR, TlmFieldsInfo.PAGE_SIZE_FN);
		}

	}

	public static void pageNoValidations(Integer pageNo, boolean mandatory) {
		if (mandatory) {
			if (pageNo == -1) {
				throw new ValidationException(MANDATORY_TLM_DATA_ERROR, TlmFieldsInfo.PAGE_NO_FN);
			}
		} else if (pageNo == -1) {
			return;
		}

		if (pageNo <= -1) {
			throw new ValidationException(INVALID_TLM_DATA_ERROR, TlmFieldsInfo.PAGE_NO_FN);
		}

	}

	public static void ansOptionalDataValidation(String data, String fieldName, boolean mandatory, int length) {
		tlmFieldValidation(data, TlmFieldsInfo.ANS_EX, fieldName, mandatory, length);
	}
	
	public static void acquireIdValidations(String data, boolean... mandatory) {
		boolean m = false;
		if (mandatory != null && mandatory.length != 0) {
			m = mandatory[0];
		}
		tlmFieldValidation(data, TlmFieldsInfo.ACQUIRER_ID_CODE_EX, TlmFieldsInfo.ACQUIRER_ID_CODE_FN, m,
				TlmFieldsInfo.ACQUIRER_ID_CODE_FL);

	}



}
