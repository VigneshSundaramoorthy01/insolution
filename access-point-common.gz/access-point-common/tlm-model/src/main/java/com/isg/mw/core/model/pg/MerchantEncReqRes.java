package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class MerchantEncReqRes implements Serializable {

    @JsonProperty("MerchantId")
    private String merchantId;

    @JsonProperty("TerminalId")
    private String terminalId;

    @JsonProperty("BankId")
    private String bankId;

    @JsonProperty("EncData")
    private String encData;

    @JsonProperty("DomainUrl")
    private String domainUrl;

    @JsonProperty("RetryFlag")
    private String retryFlag;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        getStringData("merchantId", merchantId, sb);
        getStringData("terminalId", terminalId, sb);
        getStringData("bankId", bankId, sb);
        getStringData("encData", encData, sb);
        getStringData("domainUrl", domainUrl, sb);
        sb.append("\"retryFlag\":").append(getValueString(retryFlag));
        sb.append('}');
        return sb.toString();
    }

    public static String getStringData(String key, Object value, StringBuilder sb, Boolean... noAppendComma) {
        boolean nac = false;
        if (noAppendComma != null && noAppendComma.length != 0) {
            nac = noAppendComma[0];
        }
        if (nac && (value != null)) {
            sb.append("\"" + key + "\":").append(getValueString(value));
        } else if (value != null) {
            sb.append("\"" + key + "\":").append(getValueString(value)).append(',');
        }
        return sb.toString();
    }

    private static String getValueString(Object value) {
        if(value != null){
            StringBuilder sb = new StringBuilder();
            return sb.append("\"").append(value).append("\"").toString();
        }
        return  null;
    }
}
