package com.isg.mw.core.model.construct.pos;

import com.isg.mw.core.model.msgtype.IMsgTypeHelper;

public final class PosMsgTypeHelper implements IMsgTypeHelper {

	private PosMsgTypeHelper() {
	}

	private static boolean equals(PosMsgType pReq, PosMsgType pRes, String m, String mt) {
		boolean retVal = false;
		if (mt != null) {
			String pc = mt.substring(0, 2);
			retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
		}
		return retVal;
	}

	private static boolean equals(PosMsgType pReq, PosMsgType pRes, String m) {
		boolean retVal = false;
		if (m != null) {

			retVal = pReq.equals(m) || pRes.equals(m);
		}
		return retVal;
	}

	/**
	 * Returns true if transaction is Moto Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isMoto(String msgType, String processingCode) {
		return equals(PosMsgType.MotoRequest, PosMsgType.MotoResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Purchase Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isPurchase(String msgType, String processingCode) {
		return equals(PosMsgType.PurchaseRequest, PosMsgType.PurchaseResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Cash Withdrawal Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isCashWithdrawal(String msgType, String processingCode) {
		return equals(PosMsgType.CashWithdrawalRequest, PosMsgType.CashWithdrawalResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Cash At POS Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isCashAtPos(String msgType, String processingCode) {
		return equals(PosMsgType.CashAtPosRequest, PosMsgType.CashAtPosResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Pre-Auth Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isPreAuth(String msgType, String processingCode) {
		return equals(PosMsgType.PreAuthRequest, PosMsgType.PreAuthResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Refund Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isRefund(String msgType, String processingCode) {
		return equals(PosMsgType.RefundRequest, PosMsgType.RefundResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Balance Enquiry Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isBalanceEnquiry(String msgType, String processingCode) {
		return equals(PosMsgType.BalanceEnqRequest, PosMsgType.BalanceEnqResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Balance Enquiry Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isReversalRequest(String msgType) {
		return PosMsgType.ReversalRequest.msgType.equals(msgType);
	}

	public static boolean isReversalResponse(String msgType) {
		return PosMsgType.ReversalResponse.msgType.equals(msgType);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isVoidRequest(String msgType, String msgTypeId) {
		return PosMsgType.VoidRequest.msgType.equals(msgType) && msgTypeId != null
				&& PosMsgType.VoidRequest.msgSubType.equals(msgTypeId);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isVoidResponse(String msgType) {
		return PosMsgType.VoidResponse.msgType.equals(msgType);
	}

	public static boolean isSignOnRequest(String msgType) {
		return PosMsgType.SignonRequest.msgType.equals(msgType);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isSignOnResponse(String msgType) {
		return PosMsgType.SignonResponse.msgType.equals(msgType);
	}

	public static boolean isTipAdjustRequest(String msgType, String msgTypeId) {
		boolean isTipAdjustRequestMsgType = PosMsgType.TipAdjustRequest.msgType.equals(msgType);
		boolean isTipAdjustRequestMsgTypeId = msgTypeId != null
				&& PosMsgType.TipAdjustRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustRequestMsgType && isTipAdjustRequestMsgTypeId;
	}

	
	public static boolean isTipAdjustResponse(String msgType, String msgTypeId) {
		boolean isTipAdjustResponseMsgType = PosMsgType.TipAdjustResponse.msgType.equals(msgType);
		boolean isTipAdjustResponseMsgTypeId = msgTypeId != null
				&& PosMsgType.TipAdjustResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustResponseMsgType && isTipAdjustResponseMsgTypeId;
	}

	public static boolean isPreAuthCompletionRequest(String msgType, String msgTypeId) {
		boolean isPreAuthCompRequestMsgType = PosMsgType.PreAuthCompletionRequest.msgType.equals(msgType);
		boolean isPreAuthRequestMsgTypeId = msgTypeId != null
				&& PosMsgType.PreAuthCompletionRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompRequestMsgType && isPreAuthRequestMsgTypeId;
	}

	public static boolean isPreAuthCompletionResponse(String msgType, String msgTypeId) {
		boolean isPreAuthCompResponseMsgType = PosMsgType.PreAuthCompletionResponse.msgType.equals(msgType);
		boolean isPreAuthResponseMsgTypeId = msgTypeId != null
				&& PosMsgType.PreAuthCompletionResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompResponseMsgType && isPreAuthResponseMsgTypeId;
	}

	public static boolean isOfflineRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = PosMsgType.OfflineRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null && PosMsgType.OfflineRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isOfflineResponse(String msgType, String msgTypeId) {
		boolean isOfflineResponseMsgType = PosMsgType.OfflineResponse.msgType.equals(msgType);
		boolean isOfflineResponseMsgTypeId = msgTypeId != null
				&& PosMsgType.OfflineResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineResponseMsgType && isOfflineResponseMsgTypeId;
	}

	public static boolean isMasterCardCashbackRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = PosMsgType.MasterCardCashbackRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& PosMsgType.MasterCardCashbackRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isBatchSettlementRequest(String msgType, String msgTypeId) {
		boolean isBatchSettlementMsgType = PosMsgType.BatchSettlementRequest.msgType.equals(msgType);
		boolean isBatchSettlementMsgTypeId = msgTypeId != null
				&& (PosMsgType.BatchSettlementRequest.msgSubType.equals(msgTypeId)
						|| PosMsgType.SettlementAfterBatchUploadRequest.msgSubType.equals(msgTypeId));
		return isBatchSettlementMsgType && isBatchSettlementMsgTypeId;
	}

	public static boolean isBatchUploadRequest(String msgType) {
		return msgType != null && PosMsgType.BatchUploadRequest.msgType.equals(msgType);
	}



	/**
	 * Returns true if transaction is Refund Request/Response Transaction, false
	 * otherwise.
	 *
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isEftPosAcquirerReconciliationAdviseTxn(String msgType,String processingCode) {
		return equals(PosMsgType.AcquirerReconciliationAdviseRequest, PosMsgType.AcquirerReconciliationAdviseResponse, msgType,processingCode);
	}


	/**
	 * Returns true if transaction is Refund Request/Response Transaction, false
	 * otherwise.
	 *
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isEftPosAcquirerReconciliationAdviseRepeatTxn(String msgType,String processingCode) {
		return equals(PosMsgType.AcquirerReconciliationAdviseRepeatRequest, PosMsgType.AcquirerReconciliationAdviseRepeatResponse, msgType,processingCode);
	}

	/**
	 * Returns true if transaction is Refund Request/Response Transaction, false
	 * otherwise.
	 *
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isEftPosFinancialAdviceTxn(String msgType) {
		return equals(PosMsgType.FinancialAdviceRequest, PosMsgType.FinancialAdviceResponse, msgType);
	}
}
