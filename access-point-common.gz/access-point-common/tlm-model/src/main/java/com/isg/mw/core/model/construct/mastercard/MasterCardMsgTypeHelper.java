package com.isg.mw.core.model.construct.mastercard;

import com.isg.mw.core.model.msgtype.IMsgTypeHelper;

public final class MasterCardMsgTypeHelper implements IMsgTypeHelper {

	private MasterCardMsgTypeHelper() {
	}

	private static boolean equals(MasterCardMsgType pReq, MasterCardMsgType pRes, String m, String mt) {
		boolean retVal = false;
		if (mt != null) {
			String pc = mt.substring(0, 2);
			retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
		}
		return retVal;
	}

	/**
	 * Returns true if transaction is Moto Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isMoto(String msgType, String processingCode) {
		return equals(MasterCardMsgType.MotoRequest, MasterCardMsgType.MotoResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Purchase Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isPurchase(String msgType, String processingCode) {
		return equals(MasterCardMsgType.PurchaseRequest, MasterCardMsgType.PurchaseResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Cash Withdrawal Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isCashWithdrawal(String msgType, String processingCode) {
		return equals(MasterCardMsgType.CashWithdrawalRequest, MasterCardMsgType.CashWithdrawalResponse, msgType,
				processingCode);
	}

	/**
	 * Returns true if transaction is Cash At POS Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isCashAtPos(String msgType, String processingCode) {
		return equals(MasterCardMsgType.CashAtPosRequest, MasterCardMsgType.CashAtPosResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Pre-Auth Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isPreAuth(String msgType, String processingCode) {
		return equals(MasterCardMsgType.PreAuthRequest, MasterCardMsgType.PreAuthResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Refund Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isRefund(String msgType, String processingCode) {
		return equals(MasterCardMsgType.RefundRequest, MasterCardMsgType.RefundResponse, msgType, processingCode);

	}

	/**
	 * Returns true if transaction is Balance Enquiry Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isBalanceEnquiry(String msgType, String processingCode) {
		return equals(MasterCardMsgType.BalanceEnqRequest, MasterCardMsgType.BalanceEnqResponse, msgType,
				processingCode);
	}

	/**
	 * Returns true if transaction is Balance Enquiry Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isReversalRequest(String msgType) {
		return MasterCardMsgType.ReversalRequest.msgType.equals(msgType);
	}

	public static boolean isReversalResponse(String msgType) {
		return MasterCardMsgType.ReversalResponse.msgType.equals(msgType);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isVoidRequest(String msgType, String msgTypeId) {
		return MasterCardMsgType.VoidRequest.msgType.equals(msgType) && msgTypeId != null
				&& MasterCardMsgType.VoidRequest.msgSubType.equals(msgTypeId);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isVoidResponse(String msgType) {
		return MasterCardMsgType.VoidResponse.msgType.equals(msgType);
	}

	public static boolean isSignOnRequest(String msgType) {
		return MasterCardMsgType.SignOnRequest.msgType.equals(msgType);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isSignOnResponse(String msgType) {
		return MasterCardMsgType.SignOnResponse.msgType.equals(msgType);
	}

	public static boolean isTipAdjustRequest(String msgType, String msgTypeId) {
		boolean isTipAdjustRequestMsgType = MasterCardMsgType.TipAdjustRequest.msgType.equals(msgType);
		boolean isTipAdjustRequestMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.TipAdjustRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustRequestMsgType && isTipAdjustRequestMsgTypeId;
	}

	public static boolean isTipAdjustResponse(String msgType, String msgTypeId) {
		boolean isTipAdjustResponseMsgType = MasterCardMsgType.TipAdjustResponse.msgType.equals(msgType);
		boolean isTipAdjustResponseMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.TipAdjustResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustResponseMsgType && isTipAdjustResponseMsgTypeId;
	}

	public static boolean isPreAuthCompletionRequest(String msgType, String msgTypeId) {
		boolean isPreAuthCompRequestMsgType = MasterCardMsgType.PreAuthCompletionRequest.msgType.equals(msgType);
		boolean isPreAuthRequestMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.PreAuthCompletionRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompRequestMsgType && isPreAuthRequestMsgTypeId;
	}

	public static boolean isPreAuthCompletionResponse(String msgType, String msgTypeId) {
		boolean isPreAuthCompResponseMsgType = MasterCardMsgType.PreAuthCompletionResponse.msgType.equals(msgType);
		boolean isPreAuthResponseMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.PreAuthCompletionResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompResponseMsgType && isPreAuthResponseMsgTypeId;
	}

	public static boolean isOfflineRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = MasterCardMsgType.OfflineRequest.msgType.equals("0220");
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.OfflineRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isOfflineResponse(String msgType, String msgTypeId) {
		boolean isOfflineResponseMsgType = MasterCardMsgType.OfflineResponse.msgType.equals(msgType);
		boolean isOfflineResponseMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.OfflineResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineResponseMsgType && isOfflineResponseMsgTypeId;
	}

	public static boolean isMasterCardCashbackRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = MasterCardMsgType.MasterCardCashbackRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& MasterCardMsgType.MasterCardCashbackRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isBatchSettlementRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isBatchUploadRequest(String msgType) {
		return false;
	}

}
