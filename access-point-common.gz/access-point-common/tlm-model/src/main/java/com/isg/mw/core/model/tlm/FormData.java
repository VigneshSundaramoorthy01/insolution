package com.isg.mw.core.model.tlm;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class FormData implements Serializable {
    private String key;
    private String value;
}
