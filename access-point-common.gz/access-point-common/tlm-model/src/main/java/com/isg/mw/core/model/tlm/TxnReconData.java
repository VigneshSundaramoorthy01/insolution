package com.isg.mw.core.model.tlm;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@ToString
public class TxnReconData implements Serializable {

    private static final long serialVersionUID = 1L;

    private String transactionID;
    private String customerReferenceNumber;
    private Date transactionDateAndTime;
    private String transactionAmount;
    private String remitterAccountNumber;
    private String poolAccountNumber;
    private String beneficiaryAccountNumber;
    private String transactionStatus;
    private String DBCR;
    private String MCC;
    private String responseCode;
    private Date businessDate;
    private String recordType;
    private String LOFO;
    private String TID;
    private String MID;
    private String surchargeFee;
    private String surchargeGST;
    private String tranactionCurrency;
    private String billingCurrency;
    private String settlementCurrency;
    private String markupFee;
    private String accountType;
    private String UMN;
    private String LRN;
    private String authCode;
    private String purposeCode;
    private String branchCode;
    private String iFSCCode;
    private String initiationMode;
    private String UDIRRaisedStatus;
    private String UDIRResponsefromBene;
    private String UDIRChargebackstatus;
    private String UDIRChargebackResponsefromBene;
    private String UDIRDRCRequestfromNPCI;
    private String UDIRDRCResponsebySwitch;
    private String UDIROnlineRefundStatus;
    private String Cycle;
    private String transactionCategory;

    private String entityId;
    
    private String billerId;
    private String messageId;

}

