package com.isg.mw.core.model.construct.payu;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum PayUMsgType implements IMsgType {
    Pay("Pay", null),
    Refund("Refund", null),
    CreateMerchant("CM", null),
    CheckTxnStatus("CheckTxnStatus",null);

    public final String msgType;
    public final String msgSubType;

    PayUMsgType(String m, String ms) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals(String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }
}
