package com.isg.mw.core.model.construct.icici;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum IciciMsgType implements IMsgType {
    Pay("Pay", null),
    VerifyVPA("VerifyVPA",null),
    TransactionStatus("TransactionStatus",null),
    GetAutoCreatedVPA("AutoCreatedVPA",null),
    UpiRefund("Refund",null),
    NbCorpPay("NbCorpPay",null),
    NbRetailPay("NbRetailPay",null),
    NbCorpRefund("Refund",null),
    NbRetailRefund("Refund",null),
    NbTransactionStatus("TransactionStatus",null),
    UpiQR("UpiQR",null),
    CallbackStatus("CallbackStatus",null),
    UpiReversal("Reversal",null);

    public final String msgType;
    public final String msgSubType;

    IciciMsgType(String m, String ms) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals(String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }
}
