package com.isg.mw.core.model.tlm;

import com.isg.mw.core.model.pg.ApiTxnModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class PaymentLinkRequestModel implements Serializable {

    private String entityId;

    private String remark;

    private String txnAmt;

    private String merchantTxnRefNo;

    private String customerMobNo;

    private String linkExpiryDate;

    private String customerEmail;

    private String udf01;

    private String udf02;

    private String udf03;

    private String udf04;

    private String udf05;

    private String udf06;

    private String udf07;

    private String udf08;

    private String udf09;

    private String udf10;

    private String fileName;

    private String staticFileName;

    private String refNo;


    public ApiTxnModel toApiTxnModel() {
        ApiTxnModel model = new ApiTxnModel();
        model.setEntityId(this.getEntityId());
        model.setRemark(this.getRemark());
        model.setTxnAmt(this.getTxnAmt());
        model.setMerchantTxnRefNo(this.getMerchantTxnRefNo());
        model.setCustomerMobNo(this.getCustomerMobNo());
        model.setLinkExpiryDate(this.getLinkExpiryDate());
        model.setCustomerEmail(this.getCustomerEmail());
        model.setUdf01(this.getUdf01());
        model.setUdf02(this.getUdf02());
        model.setUdf03(this.getUdf03());
        model.setUdf04(this.getUdf04());
        model.setUdf05(this.getUdf05());
        model.setUdf06(this.getUdf06());
        model.setUdf07(this.getUdf07());
        model.setUdf08(this.getUdf08());
        model.setUdf09(this.getUdf09());
        model.setUdf10(this.getUdf10());
        model.setFileName(this.getFileName());
        model.setStaticFileName(this.getStaticFileName());
        model.setRefNo(this.getRefNo());
        return model;
    }
}
