package com.isg.mw.core.model.sr;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.isg.mw.core.utils.OffsetDateTimeOptionalZoneDeserializer;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.time.OffsetDateTime;

@Data
@AllArgsConstructor
public class SourceInfo implements Serializable {
	
	private Integer totalTxnCount;

	@JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.[SSS]xxx")
	private OffsetDateTime lastCalculatedDate;

	public SourceInfo() {
		this.totalTxnCount = 0;
	}
}
