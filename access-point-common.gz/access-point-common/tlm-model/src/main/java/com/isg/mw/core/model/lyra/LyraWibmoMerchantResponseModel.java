package com.isg.mw.core.model.lyra;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LyraWibmoMerchantResponseModel  implements Serializable {
    public String status;
    public String merchantId;
    public String mdesSrciDpaId;
    public String companyPrimaryLegalName;
    public String errorDesc;
    public String errorCode;
    public String clientReferenceId;
    public String resMessage;

}