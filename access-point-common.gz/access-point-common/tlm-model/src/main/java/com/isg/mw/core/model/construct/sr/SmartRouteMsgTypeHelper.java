package com.isg.mw.core.model.construct.sr;

import com.isg.mw.core.model.construct.icici.IciciMsgType;
import com.isg.mw.core.model.construct.payu.PayUMsgType;

public class SmartRouteMsgTypeHelper {

    private SmartRouteMsgTypeHelper() {
    }

    private static boolean equals(String pReq, String m) {
        boolean retVal = false;
        retVal = pReq.equals(m);
        return retVal;
    }

    /**
     * Returns true if transaction is Purchase Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isPay(String msgType, String txnType) {
        return equals(PayUMsgType.Pay.msgType, msgType);
    }

    public static boolean isRetailPay(String msgType, String txnType) {
        return equals(IciciMsgType.NbRetailPay.msgType, msgType);
    }

    public static boolean isCorpPay(String msgType, String txnType) {
        return equals(IciciMsgType.NbCorpPay.msgType, msgType);
    }

    public static boolean isRetailRefund(String msgType, String txnType) {
        return equals(IciciMsgType.NbRetailRefund.msgType, msgType);

    }

    public static boolean isCorpRefund(String msgType, String txnType) {
        return equals(IciciMsgType.NbCorpRefund.msgType, msgType);

    }

    /**
     * Returns true if transaction is Pre-Auth Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isRefund(String msgType, String txnType) {
        return equals(PayUMsgType.Refund.msgType, msgType);

    }

    public static boolean isReversal(String msgType, String txnType) {
        return equals(IciciMsgType.UpiReversal.msgType, msgType);
    }

    public static boolean isUpiQrPay(String msgType, String txnType) {
        return equals(IciciMsgType.UpiQR.msgType, msgType);
    }
}
