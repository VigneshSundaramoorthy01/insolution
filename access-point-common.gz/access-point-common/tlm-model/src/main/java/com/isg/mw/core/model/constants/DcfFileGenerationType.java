package com.isg.mw.core.model.constants;

public enum DcfFileGenerationType {

	SINGLE,
	
	MULTIPLE;
	
	/**
	 * converts String object to DcfFileType constant
	 * 
	 * @param name - string value of the DcfFileType
	 * @return - DcfFileGenerationType Enum constant
	 */
	public static DcfFileGenerationType getDcfFileGenerationType(String name) {
		if (SINGLE.name().equals(name)) {
			return SINGLE;
		} else if (MULTIPLE.name().equals(name)) {
			return MULTIPLE;
		}

		return null;
	}
}
