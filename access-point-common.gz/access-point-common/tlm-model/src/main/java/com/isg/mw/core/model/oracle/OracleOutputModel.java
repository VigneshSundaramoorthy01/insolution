package com.isg.mw.core.model.oracle;


import lombok.Data;

@Data
public class OracleOutputModel {

    private String convfeeFlag;
    private Integer templateId;
    private Integer mappingId;
    private Integer rateSrNo;
    private String chargeType;
    private Double mdrRate;
    private Double mdrFixed;
    private Double commission;
    private Integer mdrTmplSrNo;
    private String commIdf;
    private Double cgstAmt;
    private Double sgstAmt;
    private Double igstAmt;
}
