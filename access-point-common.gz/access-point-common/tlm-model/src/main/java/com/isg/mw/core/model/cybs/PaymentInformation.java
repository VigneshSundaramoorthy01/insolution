package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PaymentInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Card card;
    private TokenizedCard tokenizedCard;
    private FluidData fluidData;
    private Customer customer;
    private PaymentInstrument paymentInstrument;
    private InstrumentIdentifier instrumentIdentifier;
    private ShippingAddress shippingAddress;
    private LegacyToken legacyToken;
    private Bank bank;
    private PaymentType paymentType;
    private String initiationChannel;
}