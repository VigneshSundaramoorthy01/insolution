package com.isg.mw.core.model.pg;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.model.icici.UpiResponse;
import com.isg.mw.core.model.tlm.PaymentLinksModel;
import com.isg.mw.core.model.tlm.TransactionMessageModel;

import com.isg.mw.core.utils.MaskingUtility;
import lombok.Data;

import java.io.Serializable;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiTxnModel extends TransactionMessageModel.PayUData implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String posEntryMode;
    private String msgType;
    private String processingCode;
    private String cardNo;
    private String txnAmt;
    private String expiryDate;
    private String cvv2;
    private String merchantType;
    private String tid;
    private String mid;
    private String stan;
    private String avv;
    private String pgTxnRefNo;
    private String ecommerceIndicator;
    private String originalTxnPgid;
    private String frmIpAddress;
    private String pgId;
    private String dsVersion;
    private String bankName;
    private String cancelationId;
    private String tavv;
    private String tokenRequestorId;
    private String onlineRefundResCode;
    private String onlineRefundAuthIdRes;
    private String field41;
    private String dsTransactionId;
    private String dsMsgCategory;
    private String dsAddMatchIndicator;
    private String dsSecureIndicator;
    private String cofTxnOrigin;
    private String resCode;
    private String resMessage;
    private String txnCurrencyCode;
    private String localTxnDate;
    private String localTxnTime;
    private String retrievalRefNo;
    private String authIdRes;
    private String cvvResult;
    private String mac;
    private String reconciliationId;
    private String cardHolderBillingAmt;
    private String cardHolderBillingCurrencyCode;
    private String cval;
    private String dval;
    private String checksum;
    private String payModeId;
    private String payModeOptionId;
    private String mcc;
    private String merchantTxnRefNo;
    private String transactionId;
    private String returnUrl;
    private String orderInfo;
    private String originalHashedTxnId;
    private String customerVpa;
    private String upiTxnNotes;
    private String merchantReturnUrl;
    private String customerMobNo;
    private String customerName;
    private String linkHashReturnUrl;
    private String txnFailedReturnUrl;
    private String msg;
    private String merchantName;
    //POS REFUND
    private String invoiceNo;
    private String targetTxnId;
    //POS REFUND


    //Convenience Fee Request Fields
    private String schemeType;
    private String drCrFlag = "";
    private String ownLoFo = "";;
    private String txnCat = "";
    private String cardCategory = "";
    private String network = "";
    private String txnType;
    private String cgstPer = "9";
    private String sgstPer = "9";
    private String igstPer = "0";
    private String curCode = "356";
    private String curExp = "2";
    private String curRate = "0.01";
    private String orderTotalAmt;
    private String qrVendor = "";
    private String wallet = "";
    private String offlinePaymentMode = "";

    //Convenience Fee Request Fields

    //Convenience Fee Response Fields
    private String convfeeFlag;
    private String templateId;
    private String mappingId;
    private String rateSrNo;
    private String chargeType;
    private String mdrRate;
    private String mdrFixed;
    private String commission = "0.00";
    private String mdrTmplSrNo;
    private String commIdf;
    private String cgstAmt = "0.00";
    private String sgstAmt = "0.00";
    private String igstAmt = "0.00";
    private String convenienceFee="0.00";
    //Convenience Fee Response Fields

    @JsonProperty("tpsl_mrct_cd")
    private String tpslMerchantCode;

    @JsonProperty("unmappedstatus")
    private String unmappedStatus;

    @JsonProperty("addedon")
    private String addedOn;

    @JsonProperty("net_amount_debit")
    private String netAmountDebit;

    @JsonProperty("payment_source")
    private String paymentSource;

    @JsonProperty("PG_TYPE")
    private String pgType;

    @JsonProperty("bank_ref_num")
    private String bankRefNum;

    @JsonProperty("error_Message")
    private String errorMsg;

    @JsonProperty("VirtualAccountNumber")
    private String vanNumber;

    @JsonProperty("cms_reference")
    private String cmsReference;

    @JsonProperty("deposit_date")
    private String depositDate;

    private String chequeDate;

    private String chequeNumber;

    // Lyra Request Fields
    private String uuid;
    private String otp;
    private String ipAddress;
    private String currency;
    private String date;
    private String due;
    private String fee;
    private String orderId;
    private String paid;
    private String paymentFamily;
    private String refunded;
    private String saleTrnsAmount;
    private String shopId;
    private String shopName;
    private String tax;
    @JsonProperty("amount")
    private String lyraAmount;
    private String externalId;
    private String authResponseCode;
    private String transactionUuid;
    private String origTxnAmt;
    // Lyra Request Fields

    //Payment Links Request Fields
    private String entityId;
    private String linkHashId;
    private String linkExpiryDate;
    private String customerEmail;
    private String paymentAttemptCounter;
    private String remark;
    private String udf01;
    private String udf02;
    private String udf03;
    private String udf04;
    private String udf05;
    private String udf06;
    private String udf07;
    private String udf08;
    private String udf09;
    private String udf10;
    private String fileName;
    private String StaticFileName;
    private String refNo;
    private String noOfFileRecord;


    //DCF REQUIRED FIELDS
    private String txnSource;
    private String latitude;
    private String longitude;
    private String browserName;
    private String browserVersion;
    private String osName;
    //DCF REQUIRED FIELDS

    //Icici -UPI
    private String originalBankRRN;
    private String upiMerchantId;
    private String bankRRN;
    private String timer;

    //Icici -RETAIL
    @JsonProperty("ES")
    private String es;
    //Icici -RETAIL

    //Icici - Corporate
    @JsonProperty("PRN")
    private String prn;

    @JsonProperty("ITC")
    private String itc;

    @JsonProperty("AMT")
    private String corporateAmount;

    @JsonProperty("CRN")
    private String crn;

    @JsonProperty("PAID")
    private String corporatePaid;

    @JsonProperty("BID")
    private String bid;
    //Icici - Corporate

    //Encryption and Decryption Request Fields
    private String encryptionEnable;
    //Encryption and Decryption Request Fields

    //Offline Transaction -NEFT
    @JsonProperty("ClientCode")
    private String clientCode;

    @JsonProperty("Mode")
    private String mode;

    @JsonProperty("UTR")
    private String utr;

    @JsonProperty("SenderRemark")
    private String senderRemark;

    @JsonProperty("ClientAccountNo")
    private String clientAccountNo;

    @JsonProperty("Amount")
    private String amount;

    @JsonProperty("PayerName")
    private String payerName;

    @JsonProperty("PayerAccNumber")
    private String payerAccNumber;

    @JsonProperty("PayerBankIFSC")
    private String payerBankIFSC;

    @JsonProperty("PayerPaymentDate")
    private String payerPaymentDate;

    @JsonProperty("BankInternalTransactionNumber")
    private String bankInternalTransactionNumber;

    @JsonProperty("payOpt")
    private String payOpt;

    //Payment Links Request Fields
    @JsonProperty("smsEnabled")
    private String smsEnabled;

    @JsonProperty("partialPay")
    private String partialPay;

    @JsonProperty("emailEnabled")
    private String emailEnabed;

    @JsonProperty("secureHash")
    private String secureHash;
    //Payment Links Request Fields

    //Offline Transaction -NEFT

    //TPSL Check Status

    private String requestReceivedTime;
    //TPSL Check Status
    
    private TransactionMessageModel tmmModel;

    public TransactionMessageModel buildTmm() {
        tmmModel = new TransactionMessageModel();
        tmmModel.setPosEntryMode(this.getPosEntryMode());
        tmmModel.setMsgType(this.getMsgType());
        tmmModel.setProcessingCode(this.getProcessingCode());
        tmmModel.setCardAcceptorId(this.getMid());
        tmmModel.setCardAcceptorTerminalId(this.getTid());
        tmmModel.setPan(this.getCardNo());
        tmmModel.setMaskedPan(MaskingUtility.maskCardNumber(this.getCardNo()));
        tmmModel.setExpirationDate(this.getExpiryDate());
        tmmModel.setTxnCurrencyCode(this.getTxnCurrencyCode());
        tmmModel.setTerminalStan(this.getStan());
        tmmModel.setStan(this.getStan());
        tmmModel.setSchemeStan(this.getStan());
        tmmModel.setPgData(getPgData());
        tmmModel.setCybsData(getCybsData());
        tmmModel.setTxnAmt(this.getTxnAmt());
        tmmModel.setRetrievalRefNo(this.retrievalRefNo);
        tmmModel.setCardHolderBillingAmt(this.getCardHolderBillingAmt());
        tmmModel.setCardHolderBillingCurrencyCode(this.getCardHolderBillingCurrencyCode());
        tmmModel.setTransactionId(this.getTransactionId());
        tmmModel.setOriginalHashedTxnId(this.getOriginalHashedTxnId());
        tmmModel.setSmartRouteData(this.getSmartRouteData());
        tmmModel.setResCode(this.getResCode());
        tmmModel.setCvv(this.getCvv2());
        tmmModel.setMerchantTxnRefNo(this.getMerchantTxnRefNo());
        tmmModel.setLinkHashId(this.getLinkHashId());
        tmmModel.setTxnSource(this.getTxnSource());
        tmmModel.setIpAddress(this.getIpAddress());
        tmmModel.setLatitude(this.getLatitude());
        tmmModel.setLongitude(this.getLongitude());
        tmmModel.setBrowserName(this.getBrowserName());
        tmmModel.setBrowserVersion(this.getBrowserVersion());
        tmmModel.setOsName(this.getOsName());
        tmmModel.setIgst(this.getIgstAmt());
        tmmModel.setCgst(this.getCgstAmt());
        tmmModel.setSgst(this.getSgstAmt());
        tmmModel.setConvenienceFee(this.getConvenienceFee());
        tmmModel.setTargetTxnId(this.getTargetTxnId());
        tmmModel.setRequestReceivedTime(trimDate(this.getRequestReceivedTime()));
        tmmModel.setEntityId(this.getEntityId());
        return tmmModel;
    }

    private TransactionMessageModel.SmartRouteData getSmartRouteData() {
        TransactionMessageModel.SmartRouteData smartRouteData = new TransactionMessageModel.SmartRouteData();
        smartRouteData.setPayModeId(this.getPayModeId());
        smartRouteData.setPayModeOptionId(this.getPayModeOptionId());
        smartRouteData.setMerchantTxnRefNo(this.getMerchantTxnRefNo());
        smartRouteData.setReturnUrl(this.getReturnUrl());
        smartRouteData.setOrderInfo(this.getOrderInfo());
        smartRouteData.setCustomerMobNo(this.getCustomerMobNo());
        smartRouteData.setEncryptionEnable(this.getEncryptionEnable());
        smartRouteData.setPayOpt(this.getPayOpt());
        UpiResponse upiResponse = new UpiResponse();
        upiResponse.setPayerVpa(this.getCustomerVpa());
        upiResponse.setBankRRN(this.getBankRRN());
//        setIciciUpiData(iciciUpiData);
        smartRouteData.setUpiResponse(upiResponse);
        TransactionMessageModel.PayUData payUData = new TransactionMessageModel.PayUData();
        setPayUData(payUData);
        smartRouteData.setPayUData(payUData);

        TransactionMessageModel.LyraData lyraData = new TransactionMessageModel.LyraData();
        setLyraData(lyraData);
        smartRouteData.setLyraData(lyraData);

        TransactionMessageModel.OfflineTransactionData offlineData = new TransactionMessageModel.OfflineTransactionData();
        offlineData.setChequeNumber(this.getChequeNumber());
        offlineData.setChequeDate(this.getChequeDate());
        smartRouteData.setOfflineTxnData(offlineData);
        return smartRouteData;
    }

//    private void setIciciUpiData(TransactionMessageModel.IciciUpiData iciciUpiData) {
////        iciciUpiData.setPayerVpa(this.getCustomerVpa());
////        iciciUpiData.setUpiTxnNotes(this.getUpiTxnNotes());
////        iciciUpiData.setOriginalBankRRN(this.getOriginalBankRRN());
////        iciciUpiData.setMerchantId(this.getUpiMerchantId());
//    }

    private void setPayUData(TransactionMessageModel.PayUData payUData) {
        if (this.getMihpayid() != null) {
            payUData.setMihpayid(this.getMihpayid());
            payUData.setMode(this.getMode());
            payUData.setStatus(this.getStatus());
            payUData.setUnmappedStatus(this.getUnmappedStatus());
            payUData.setKey(this.getKey());
            tmmModel.setTransactionId(this.getTxnid());
            tmmModel.setTxnAmt(this.getAmount());
            payUData.setDiscount(this.getDiscount());
            payUData.setNetAmountDebit(this.getNetAmountDebit());
            payUData.setAddedOn(this.getAddedOn());
            payUData.setProductinfo(this.getProductinfo());
            payUData.setFirstname(this.getFirstname());
            payUData.setLastname(this.getLastname());
            payUData.setAddress1(this.getAddress1());
            payUData.setAddress2(this.getAddress2());
            payUData.setCity(this.getCity());
            payUData.setState(this.getState());
            payUData.setCountry(this.getCountry());
            payUData.setZipcode(this.getZipcode());
            payUData.setEmail(this.getEmail());
            payUData.setPhone(this.getPhone());
            payUData.setUdf1(this.getUdf1());
            payUData.setUdf2(this.getUdf2());
            payUData.setUdf3(this.getUdf3());
            payUData.setUdf4(this.getUdf4());
            payUData.setUdf5(this.getUdf5());
            payUData.setUdf6(this.getUdf6());
            payUData.setUdf7(this.getUdf7());
            payUData.setUdf8(this.getUdf8());
            payUData.setUdf9(this.getUdf9());
            payUData.setUdf10(this.getUdf10());
            payUData.setHash(this.getHash());
            payUData.setField1(this.getField1());
            payUData.setField2(this.getField2());
            payUData.setField3(this.getField3());
            payUData.setField4(this.getField4());
            payUData.setField5(this.getField5());
            payUData.setField6(this.getField6());
            payUData.setField7(this.getField7());
            payUData.setField8(this.getField8());
            payUData.setField9(this.getField9());
            payUData.setPaymentSource(this.getPaymentSource());
            payUData.setPgType(this.getPgType());
            payUData.setBankRefNum(this.getBankRefNum());
            payUData.setBankcode(this.getBankcode());
            payUData.setError(this.getError());
            payUData.setErrorMsg(this.getErrorMsg());
            payUData.setCommand(this.getCommand());
        }
    }

    private TransactionMessageModel.PgData getPgData() {
        TransactionMessageModel.PgData pgData = new TransactionMessageModel.PgData();
        pgData.setCvv2(this.getCvv2());
        pgData.setAvv(this.getAvv());
        pgData.setCvvResult(this.getCvvResult());
        pgData.setPgTxnRefNo(this.getPgTxnRefNo());
        pgData.setEcommerceIndicator(this.getEcommerceIndicator());
        pgData.setOriginalTxnPgid(this.getOriginalTxnPgid());
        pgData.setFrmIpAddress(this.getFrmIpAddress());
        pgData.setPgId(this.getPgId());
        pgData.setDsVersion(this.getDsVersion());
        pgData.setBankName(this.getBankName());
        pgData.setCancelationId(this.getCancelationId());
        pgData.setMac(this.getMac());
        pgData.setAvv(this.getAvv());
        pgData.setTokenRequestorId(this.getTokenRequestorId());
        pgData.setOnlineRefundResCode(this.getOnlineRefundResCode());
        pgData.setOnlineRefundAuthIdRes(this.getOnlineRefundAuthIdRes());
        pgData.setField41(this.getField41());
        pgData.setDsTransactionId(this.getDsTransactionId());
        pgData.setDsMsgCategory(this.getDsMsgCategory());
        pgData.setDsAddMatchIndicator(this.getDsAddMatchIndicator());
        pgData.setDsSecureIndicator(this.getDsSecureIndicator());
        pgData.setCofTxnOrigin(this.getCofTxnOrigin());
        return pgData;
    }

    private TransactionMessageModel.CybsData getCybsData() {
        TransactionMessageModel.CybsData cybsData = new TransactionMessageModel.CybsData();
        cybsData.setReconciliationId(this.reconciliationId);
        return cybsData;
    }

    public TransactionMessageModel getTmm() {
        return this.tmmModel;
    }
    
    private void setLyraData(TransactionMessageModel.LyraData lyraData) {
        tmmModel.setTransactionId(this.getTxnid());
        lyraData.setCustomerName(this.customerName);
    	lyraData.setCustomerEmail(this.getEmail());
        lyraData.setUuid(this.getUuid());
        lyraData.setIpAddress(this.getIpAddress());
        lyraData.setOtp(this.getOtp());
        lyraData.setCurrency(this.getCurrency());
        lyraData.setDate(this.getDate());
        lyraData.setDue(this.getDue());
        lyraData.setFee(this.getFee());
        lyraData.setOrderId(this.getOrderId());
        lyraData.setPaid(this.getPaid());
        lyraData.setPaymentFamily(this.getPaymentFamily());
        lyraData.setRefunded(this.getRefunded());
        lyraData.setSaleTrnsAmount(this.getSaleTrnsAmount());
        lyraData.setShopId(this.getShopId());
        lyraData.setShopName(this.getShopName());
        lyraData.setTax(this.getTax());
        lyraData.setStatus(this.getStatus());
        lyraData.setAmount(this.getLyraAmount());
        lyraData.setExternalId(this.getExternalId());
        lyraData.setAuthResponseCode(this.getAuthResponseCode());
        tmmModel.setRetrievalRefNo(this.getExternalId());
        lyraData.setTransactionUuid(this.getTransactionUuid());
    }

    public PaymentLinksModel toPaymentLinkModel(){
        PaymentLinksModel model = new PaymentLinksModel();
        model.setMid(this.getMid());
        model.setTid(this.getTid());
        model.setEntityId(this.getEntityId());
        model.setOrderId(this.getMerchantTxnRefNo());
        model.setAmount(this.getTxnAmt());
        model.setRemark(this.getRemark());
        model.setLinkExpiryDate(trimGmtDate(this.getLinkExpiryDate()));
        model.setLinkHashId(this.getLinkHashId());
        model.setUdf01(this.getUdf01());
        model.setUdf02(this.getUdf02());
        model.setUdf03(this.getUdf03());
        model.setUdf04(this.getUdf04());
        model.setUdf05(this.getUdf05());
        model.setUdf06(this.getUdf06());
        model.setUdf07(this.getUdf07());
        model.setUdf08(this.getUdf08());
        model.setUdf09(this.getUdf09());
        model.setUdf10(this.getUdf10());
        model.setMobileNo(this.getCustomerMobNo());
        model.setEmailId(this.getCustomerEmail());
        model.setFileName(this.getFileName());
        model.setStaticFileName(this.getStaticFileName());
        model.setRefNo(this.getRefNo());
        model.setNumberOfFileRecord(this.getNoOfFileRecord());


        model.setSmsEnabled(this.getSmsEnabled());
        model.setPartialPay(this.getPartialPay());
        model.setEmailEnabled(this.getEmailEnabed());
        model.setSecureHash(this.getSecureHash());
        return model;
    }

    public  OffsetDateTime trimGmtDate(String input) {
        OffsetDateTime output = null;
        if (input != null && !input.equals("")) {
            try {
                ZoneOffset gmtOffset = ZoneOffset.ofHoursMinutes(0, 0);
                OffsetDateTime parse = OffsetDateTime.parse(input.trim(), DateTimeFormatter.ISO_DATE_TIME);
                return parse.withOffsetSameInstant(gmtOffset);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }else{
            try {
                //Input format "2023-08-23"
                LocalDate ldt = LocalDate.now();
                // Change the ZoneId as required e.g. ZoneId.of("Europe/London")
                ZoneId zoneId = ZoneId.systemDefault();
                OffsetDateTime offsetDateTime = ldt.atTime(LocalTime.MIDNIGHT).atZone(zoneId).toOffsetDateTime().plusDays(180);
                return trimGmtDate(offsetDateTime.toString());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return output;
    }

    public static OffsetDateTime trimDate(String input) {
        OffsetDateTime output = null;
//        To Convert string into offset date time
//        OffsetDateTime.parse(input.trim(), DateTimeFormatter.ISO_DATE_TIME);
        if (input != null && !input.equals("")) {
            try {
                if (isValidOffsetDateTime(input)) {
                    return OffsetDateTime.parse(input);
                } else if (isValidLocalDate(input)) {
                    //Input format "2023-08-23"
                    LocalDate ldt = LocalDate.parse(input);
                    // Change the ZoneId as required e.g. ZoneId.of("Europe/London")
                    ZoneId zoneId = ZoneId.systemDefault();
                    return ldt.atTime(LocalTime.MIDNIGHT).atZone(zoneId).toOffsetDateTime();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            try {
                //Input format "2023-08-23"
                LocalDate ldt = LocalDate.now();
                // Change the ZoneId as required e.g. ZoneId.of("Europe/London")
                ZoneId zoneId = ZoneId.systemDefault();
                return ldt.atTime(LocalTime.MIDNIGHT).atZone(zoneId).toOffsetDateTime().plusDays(180);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return output;
    }

    public static boolean isValidOffsetDateTime(String dateStr) {
        try {
            OffsetDateTime.parse(dateStr);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

    public static boolean isValidLocalDate(String dateStr) {
        try {
            LocalDate.parse(dateStr);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }



}
