package com.isg.mw.core.model.lyra;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Data
@Getter
@Setter
public class LyraCheckTxnStatusResponseModel  implements Serializable{

        public String uuid;
        public String date;
        public String dueDate;
        public String expiryDate;
        public String status;
        public String orderId;
        public String currency;
        public int amount;
        public int paid;
        public int due;
        public int refunded;
        public Customer customer;
        public String orderInfo;
        public int attempts;
        public boolean testMode;
        public String paymentLink;
        public int maxAttempts;
        public boolean surcharge;
        public List<Transaction> transactions;

    @Getter
    @Setter
    public static class Transaction implements Serializable {
        public String uuid;
        public String payment_option;
        public String scheme;
        public String status;
        public String date;
        public String externalId;
        public String authNum;
        public String authResponseCode;
    }

    @Getter
    @Setter
    public static class Customer implements Serializable {
        public String name;
        public String phone;
        public String email;
    }

}
