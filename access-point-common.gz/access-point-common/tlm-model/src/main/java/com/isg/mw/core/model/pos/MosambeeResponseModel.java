package com.isg.mw.core.model.pos;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class MosambeeResponseModel implements Serializable {

    private String result;
    private MidDetailsResponseModel midDetails;
    private String message;
    private String merchantRefNo;
    private String responseCode;
    public String resMessage;

    @Data
    public static class MidDetailsResponseModel implements Serializable {
        private String responseCode;
        private String result;
        private String message;
        private String midRefId;
        private List<TidDetailResponseModel> tidDetails;
    }

    @Data
    public static class TidDetailResponseModel implements Serializable {
        private String responseCode;
        private String result;
        private String message;
        private String terminalId;
        private String userName;
        private String tidRefId;
    }
}