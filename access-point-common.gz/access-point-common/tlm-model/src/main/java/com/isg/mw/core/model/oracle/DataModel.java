package com.isg.mw.core.model.oracle;

import lombok.Data;

@Data
public class DataModel {

    private ResponseModel data;
}
