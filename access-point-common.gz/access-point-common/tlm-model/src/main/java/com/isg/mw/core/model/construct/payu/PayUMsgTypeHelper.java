package com.isg.mw.core.model.construct.payu;

import com.isg.mw.core.model.construct.pg.PgMsgType;

public class PayUMsgTypeHelper {
    private PayUMsgTypeHelper() {
    }

    private static boolean equals(PayUMsgType pReq, PayUMsgType pRes, String m, String mt) {
        boolean retVal = false;
        if (mt != null) {
            String pc = mt.substring(0, 2);
            retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
        }
        return retVal;
    }

    /**
     * Returns true if transaction is Purchase Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isNetBanking(String msgType, String txnType) {
        return equals(PayUMsgType.Pay, PayUMsgType.Pay, msgType, txnType);
    }

    /**
     * Returns true if transaction is Pre-Auth Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isRefund(String msgType, String txnType) {
        return equals(PayUMsgType.Refund, PayUMsgType.Refund, msgType, txnType);
    }

}
