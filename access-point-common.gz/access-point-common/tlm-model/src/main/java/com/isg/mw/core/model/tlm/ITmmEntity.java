package com.isg.mw.core.model.tlm;

/**
 * A generic interface to convert TransactionMessageModel to respective Entity
 * WIll be implemented inside TLM (Transaction Log Manager service) based on type of Entity
 * @param <T>
 */
public interface ITmmEntity <T> {
    T toEntity();
}
