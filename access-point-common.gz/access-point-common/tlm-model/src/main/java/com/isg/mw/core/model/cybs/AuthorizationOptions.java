package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class AuthorizationOptions implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String authType;
    private String verbalAuthCode;
    private String verbalAuthTransactionId;
    private String authIndicator;
    private boolean partialAuthIndicator;
    private boolean balanceInquiry;
    private boolean ignoreAvsResult;
    private List<String> declineAvsFlags;
    private boolean ignoreCvResult;
    private Initiator initiator;
    private boolean billPayment;
    private String billPaymentType;
    private boolean redemptionInquiry;
    private String transportationMode;
    private String aggregatedAuthIndicator;
    private String debtRecoveryIndicator;
    private boolean deferredAuthIndicator;
}