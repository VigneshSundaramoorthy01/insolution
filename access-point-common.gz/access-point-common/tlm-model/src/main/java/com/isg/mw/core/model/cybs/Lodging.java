package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class Lodging implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String checkInDate;
    private String checkOutDate;
    private List<Room> room;
    private String smokingPreference;
    private String numberOfRooms;
    private String numberOfGuests;
    private String roomBedType;
    private String roomTaxType;
    private String roomRateType;
    private String guestName;
    private String customerServicePhoneNumber;
    private String corporateClientCode;
    private String additionalDiscountAmount;
    private String roomLocation;
    private String specialProgramCode;
    private String totalTaxAmount;
    private String prepaidCost;
    private String foodAndBeverageCost;
    private String roomTaxAmount;
    private String adjustmentAmount;
    private String phoneCost;
    private String restaurantCost;
    private String roomServiceCost;
    private String miniBarCost;
    private String laundryCost;
    private String miscellaneousCost;
    private String giftShopCost;
    private String movieCost;
    private String healthClubCost;
    private String valetParkingCost;
    private String cashDisbursementCost;
    private String nonRoomCost;
    private String businessCenterCost;
    private String loungeBarCost;
    private String transportationCost;
    private String gratuityAmount;
    private String conferenceRoomCost;
    private String audioVisualCost;
    private String banquestCost;
    private String nonRoomTaxAmount;
    private String earlyCheckOutCost;
    private String internetAccessCost;
}
