package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class DeviceInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String hostName;
    private String ipAddress;
    private String userAgent;
    private String fingerprintSessionId;
    private List<RawData> rawData;
    private String httpAcceptBrowserValue;
    private String httpAcceptContent;
    private String httpBrowserEmail;
    private String httpBrowserLanguage;
    private boolean httpBrowserJavaEnabled;
    private boolean httpBrowserJavaScriptEnabled;
    private String httpBrowserColorDepth;
    private String httpBrowserScreenHeight;
    private String httpBrowserScreenWidth;
    private String httpBrowserTimeDifference;
    private String userAgentBrowserValue;
}
