package com.isg.mw.core.model.construct.amex;


public final class AmexMsgTypeHelper {

    private AmexMsgTypeHelper() {
    }

    private static boolean equals(AmexMsgType pReq, AmexMsgType pRes, String m, String mt) {
        boolean retVal = false;
        if (mt != null) {
            String pc = mt.substring(0, 2);
            retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
        }
        return retVal;
    }

    private static boolean equals(AmexMsgType pReq,  String m) {
        boolean retVal = false;

        retVal = pReq.equals(m);

        return retVal;
    }

    public static boolean isRefund(String msgType, String processingCode) {
        return equals(AmexMsgType.RefundRequest, AmexMsgType.RefundRequest, msgType, processingCode);
    }
    
    public static boolean isSignOnRequest(String msgType) {
		return AmexMsgType.SignOnRequest.msgType.equals(msgType);
	}
	
	public static boolean isSignOnResponse(String msgType) {
		return AmexMsgType.SignOnResponse.msgType.equals(msgType);
	}

    public static boolean isAuthResquest(String msgType, String processingCode) {
        return equals(AmexMsgType.AuthRequest, AmexMsgType.AuthRequest, msgType, processingCode);
    }

    public static boolean isAuthResponse(String msgType) {
        return equals(AmexMsgType.AuthResponse, msgType);
    }

    public static boolean isReversalResponse(String msgType) {
        return equals(AmexMsgType.ReversalResponse, msgType);
    }

    public static boolean isAavResquest(String msgType, String processingCode) {
        return equals(AmexMsgType.AavRequest, AmexMsgType.AavRequest, msgType, processingCode);
    }

    public static boolean isPurchaseAavResquest(String msgType, String processingCode) {
        return equals(AmexMsgType.PurchaseAavRequest, AmexMsgType.PurchaseAavRequest, msgType, processingCode);
    }

    public static boolean isRefundAavResquest(String msgType, String processingCode) {
        return equals(AmexMsgType.RefundAavRequest, AmexMsgType.RefundAavRequest, msgType, processingCode);
    }

}
