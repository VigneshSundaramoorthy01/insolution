package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class RiskInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Profile profile;
    private String eventType;
    private BuyerHistory buyerHistory;
    private List<AuxiliaryData> auxiliaryData;
}
