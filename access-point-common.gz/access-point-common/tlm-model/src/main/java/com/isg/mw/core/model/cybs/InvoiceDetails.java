package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class InvoiceDetails implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String invoiceNumber;
    private String barcodeNumber;
    private String expirationDate;
    private String purchaseOrderNumber;
    private String purchaseOrderDate;
    private String purchaseContactName;
    private boolean taxable;
    private String vatInvoiceReferenceNumber;
    private String commodityCode;
    private String merchandiseCode;
    private List<TransactionAdviceAddendum> transactionAdviceAddendum;
    private String referenceDataCode;
    private String referenceDataNumber;
    private String salesSlipNumber;
    private String invoiceDate;
}
