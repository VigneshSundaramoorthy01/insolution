package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BuyerHistory implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private CustomerAccount customerAccount;
    private AccountHistory accountHistory;
    private String accountPurchases;
    private String addCardAttempts;
    private boolean priorSuspiciousActivity;
    private String paymentAccountHistory;
    private String paymentAccountDate;
    private String transactionCountDay;
    private String transactionCountYear;
}