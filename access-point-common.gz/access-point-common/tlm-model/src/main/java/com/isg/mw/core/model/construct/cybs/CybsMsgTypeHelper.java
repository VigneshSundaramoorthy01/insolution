package com.isg.mw.core.model.construct.cybs;

public class CybsMsgTypeHelper {

    private CybsMsgTypeHelper() {
    }

    private static boolean equals(CybsMsgType pReq, CybsMsgType pRes, String m, String mt) {
        boolean retVal = false;
        if (mt != null) {
            String pc = mt.substring(0, 2);
            retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
        }
        return retVal;
    }

    public static boolean isCybsReversal(String msgType) {
        return msgType.equals("reversal_pay");
    }

    public static boolean isCapture(String msgType) {
        return msgType.equals("capture_pay");
    }

    public static boolean isRefund(String msgType) {
        return msgType.equals("refund_pay");
    }

    public static boolean isReversalTimeout(String msgType) {
        return msgType.equals("reversal_timeout");
    }

}
