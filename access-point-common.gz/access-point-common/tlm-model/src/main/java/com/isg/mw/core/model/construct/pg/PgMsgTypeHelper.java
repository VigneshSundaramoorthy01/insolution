package com.isg.mw.core.model.construct.pg;

import com.isg.mw.core.model.msgtype.IMsgTypeHelper;

public class PgMsgTypeHelper implements IMsgTypeHelper {
    private PgMsgTypeHelper() {
    }

    private static boolean equals(PgMsgType pReq, PgMsgType pRes, String m, String mt) {
        boolean retVal = false;
        if (mt != null) {
            String pc = mt.substring(0, 2);
            retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
        }
        return retVal;
    }

    /**
     * Returns true if transaction is Purchase Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isPurchase(String msgType, String txnType) {
        return equals(PgMsgType.PurchaseRequest, PgMsgType.PurchaseResponse, msgType, txnType);
    }

    public static boolean isVisaBqrPurchase(String msgType, String txnType) {
        return equals(PgMsgType.VisaBqrPurchaseRequest, PgMsgType.VisaBqrPurchaseResponse, msgType, txnType);
    }

    public static boolean isMasterBqrPurchase(String msgType, String txnType) {
        return equals(PgMsgType.MasterBqrPurchaseRequest, PgMsgType.MasterBqrPurchaseResponse, msgType, txnType);
    }

    /**
     * Returns true if transaction is Pre-Auth Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isPreAuth(String msgType, String txnType) {
        return equals(PgMsgType.PreAuthRequest, PgMsgType.PreAuthResponse, msgType, txnType);
    }

    /**
     * Returns true if transaction is Refund Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isRefund(String msgType, String txnType) {
        return equals(PgMsgType.RefundRequest, PgMsgType.RefundResponse, msgType, txnType);
    }

    public static boolean isReversal(String msgType, String txnType) {
        return equals(PgMsgType.ReversalRequest, PgMsgType.ReversalResponse, msgType, txnType);
    }

    public static boolean isCapture(String msgType, String txnType) {
        return equals(PgMsgType.CaptureRequest, PgMsgType.CaptureResponse, msgType, txnType);

    }
    public static boolean isRP(String msgType, String txnType) {
        return equals(PgMsgType.RPRequest, PgMsgType.RPResponse, msgType, txnType);

    }
    public static boolean isAmexSI(String msgType, String txnType) {
        return equals(PgMsgType.SIAmexRequest, PgMsgType.SIAmexResponse, msgType, txnType);

    }

    public static boolean isRPAav(String msgType, String txnType) {
        return equals(PgMsgType.RPAavRequest, PgMsgType.RPAavResponse, msgType, txnType);

    }
    public static boolean isAmexSIAav(String msgType, String txnType) {
        return equals(PgMsgType.SIAmexAavRequest, PgMsgType.SIAmexAavResponse, msgType, txnType);

    }

    public static boolean isSI(String msgType, String txnType) {
        return equals(PgMsgType.SIRequest, PgMsgType.SIResponse, msgType, txnType);
    }
    public static boolean isOfflineRefund(String msgType, String txnType) {
        return equals(PgMsgType.OfflineRefundRequest, PgMsgType.OfflineRefundResponse, msgType, txnType);

    }

    public static boolean isOnlineOfflineRefund(String msgType, String txnType) {
        return equals(PgMsgType.OnlineOfflineRefundRequest, PgMsgType.OnlineOfflineRefundResponse, msgType, txnType);

    }

    public static boolean isMotoSale(String msgType, String txnType) {
        return equals(PgMsgType.MotoSaleRequest, PgMsgType.MotoSaleResponse, msgType, txnType);
    }

    public static boolean isMotoSaleAav(String msgType, String txnType) {
        return equals(PgMsgType.MotoSaleRequest, PgMsgType.MotoSaleResponse, msgType, txnType);
    }
    public static boolean isMotoReversal(String msgType, String txnType) {
        return equals(PgMsgType.MotoReversalRequest, PgMsgType.MotoReversalResponse, msgType, txnType);
    }

    public static boolean isMotoOnlineOfflineRefund(String msgType, String txnType) {
        return equals(PgMsgType.MotoOnlineOfflineRefundRequest, PgMsgType.MotoOnlineOfflineRefundResponse, msgType, txnType);
    }

    public static boolean isMoSale(String msgType, String txnType) {
        return equals(PgMsgType.MoSaleRequest, PgMsgType.MoSaleResponse, msgType, txnType);
    }
    public static boolean isAav(String msgType, String txnType) {
        return equals(PgMsgType.AavRequest, PgMsgType.AavResponse, msgType, txnType);
    }
    public static boolean isPurchaseAav(String msgType, String txnType) {
        return equals(PgMsgType.PurchaseAavRequest, PgMsgType.PurchaseAavResponse, msgType, txnType);
    }
    public static boolean isOnlineRefund(String msgType, String txnType) {
        return equals(PgMsgType.OnlineRefundRequest, PgMsgType.OnlineRefundResponse, msgType, txnType);
    }
    public static boolean isRefundAav(String msgType, String txnType) {
        return equals(PgMsgType.RefundAavRequest, PgMsgType.RefundAavResponse, msgType, txnType);
    }
    public static boolean isPreauthReversal(String msgType, String txnType) {
        return equals(PgMsgType.PreAuthReversalRequest, PgMsgType.PreAuthReversalResponse, msgType, txnType);
    }

    public static boolean isToSale(String msgType, String txnType) {
        return equals(PgMsgType.ToSaleRequest, PgMsgType.ToSaleResponse, msgType, txnType);
    }

    public static boolean isMoRefund(String msgType, String txnType) {
        return equals(PgMsgType.MoRefundRequest, PgMsgType.MoRefundResponse, msgType, txnType);
    }

    public static boolean isToRefund(String msgType, String txnType) {
        return equals(PgMsgType.ToRefundRequest, PgMsgType.ToRefundResponse, msgType, txnType);
    }


    public static boolean isMoReversal(String msgType, String txnType) {
        return equals(PgMsgType.MoReversalRequest, PgMsgType.MoReversalResponse, msgType, txnType);
    }

    public static boolean isToReversal(String msgType, String txnType) {
        return equals(PgMsgType.ToReversalRequest, PgMsgType.ToReversalResponse, msgType, txnType);
    }

    public static boolean isMoSaleAav(String msgType, String txnType) {
        return equals(PgMsgType.MoSaleAavRequest, PgMsgType.MoSaleAavResponse, msgType, txnType);
    }

    public static boolean isToSaleAav(String msgType, String txnType) {
        return equals(PgMsgType.ToSaleAavRequest, PgMsgType.ToSaleAavResponse, msgType, txnType);
    }

    public static boolean isPreAuthAav(String msgType, String txnType) {
        return equals(PgMsgType.PreAuthAavRequest, PgMsgType.PreAuthAavResponse, msgType, txnType);
    }
    
    /**
     * Returns true if transaction is Moto Pre-Auth Request/Response Transaction, false
     * otherwise.
     *
     * @param msgType Transaction Message Type
     * @param txnType Transaction Processing Code
     * @return True/False.
     */
    public static boolean isMotoPreAuth(String msgType, String txnType) {
        return equals(PgMsgType.MotoPreAuthRequest, PgMsgType.MotoPreAuthResponse, msgType, txnType);
    }
    
    public static boolean isMotoCapture(String msgType, String txnType) {
        return equals(PgMsgType.MotoCaptureRequest, PgMsgType.MotoCaptureResponse, msgType, txnType);
    }
    
    public static boolean isZvavPurchase(String msgType, String txnType) {
        return equals(PgMsgType.ZvavPurchaseRequest, PgMsgType.ZvavPurchaseResponse, msgType, txnType);
    }
    
    public static boolean isZvavPurchaseAav(String msgType, String txnType) {
        return equals(PgMsgType.ZvavPurchaseAavRequest, PgMsgType.ZvavPurchaseAavResponse, msgType, txnType);
    }
}
