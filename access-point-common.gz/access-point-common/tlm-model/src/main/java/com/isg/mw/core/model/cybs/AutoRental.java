package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AutoRental implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean noShowIndicator;
    private String customerName;
    private String vehicleClass;
    private String distanceTravelled;
    private String distanceUnit;
    private String returnDateTime;
    private String rentalDateTime;
    private String maxFreeDistance;
    private boolean insuranceIndicator;
    private String programCode;
    private ReturnAddress returnAddress;
    private RentalAddress rentalAddress;
    private String agreementNumber;
    private String odometerReading;
    private String vehicleIdentificationNumber;
    private String companyId;
    private String numberOfAdditionalDrivers;
    private String driverAge;
    private String specialProgramCode;
    private String vehicleMake;
    private String vehicleModel;
    private String timePeriod;
    private String commodityCode;
    private String customerServicePhoneNumber;
    private TaxDetail taxDetails;
    private String insuranceAmount;
    private String oneWayDropOffAmount;
    private String adjustedAmountIndicator;
    private String adjustedAmount;
    private String fuelCharges;
    private String weeklyRentalRate;
    private String dailyRentalRate;
    private String ratePerMile;
    private String mileageCharge;
    private String extraMileageCharge;
    private String lateFeeAmount;
    private String towingCharge;
    private String extraCharge;
    private String gpsCharge;
    private String phoneCharge;
    private String parkingViolationCharge;
    private String otherCharges;
}
