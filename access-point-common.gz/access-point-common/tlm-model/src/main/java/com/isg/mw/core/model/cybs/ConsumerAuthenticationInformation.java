package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ConsumerAuthenticationInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cavv;
    private String cavvAlgorithm;
    private String eciRaw;
    private String paresStatus;
    private String veresEnrolled;
    private String xid;
    private String ucafCollectionIndicator;
    private String ucafAuthenticationData;
    private StrongAuthentication strongAuthentication;
    private String directoryServerTransactionId;
    private String paSpecificationVersion;
    private String authenticationType;
    private String responseAccessToken;
    private String acsTransactionId;
    private String acsWindowSize;
    private String alternateAuthenticationData;
    private String alternateAuthenticationDate;
    private String alternateAuthenticationMethod;
    private String authenticationDate;
    private String authenticationTransactionId;
    private String challengeCancelCode;
    private String challengeCode;
    private String challengeStatus;
    private String customerCardAlias;
    private String decoupledAuthenticationIndicator;
    private String decoupledAuthenticationMaxTime;
    private boolean defaultCard;
    private String deviceChannel;
    private String installmentTotalCount;
    private String merchantFraudRate;
    private boolean marketingOptIn;
    private String marketingSource;
    private String mcc;
    private String merchantScore;
    private String messageCategory;
    private String networkScore;
    private String npaCode;
    private String overridePaymentMethod;
    private String overrideCountryCode;
    private String priorAuthenticationData;
    private String priorAuthenticationMethod;
    private String priorAuthenticationReferenceId;
    private String priorAuthenticationTime;
    private String productCode;
    private String returnUrl;
    private String requestorId;
    private String requestorInitiatedAuthenticationIndicator;
    private String requestorName;
    private String referenceId;
    private String sdkMaxTimeout;
    private String secureCorporatePaymentIndicator;
    private String transactionMode;
    private String whiteListStatus;
    private String effectiveAuthenticationType;
    private String signedParesStatusReason;
    private String signedPares;
}
