package com.isg.mw.core.model.msgtype;

public interface IMsgTypeHelper {
	static boolean isMoto(String msgType, String msgSubType) {
		return false;
	}

	static boolean isPurchase(String msgType, String msgSubType) {
		return false;
	}

	public static boolean isCashWithdrawal(String msgType, String processingCode) {
		return false;
	}

	public static boolean isCashAtPos(String msgType, String processingCode) {
		return false;
	}

	public static boolean isPreAuth(String msgType, String processingCode) {
		return false;
	}

	public static boolean isRefund(String msgType, String processingCode) {
		return false;
	}

	public static boolean isBalanceEnquiry(String msgType, String processingCode) {
		return false;
	}

	public static boolean isReversalRequest(String msgType) {
		return false;
	}

	public static boolean isReversalResponse(String msgType) {
		return false;
	}

	public static boolean isVoidRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isVoidResponse(String msgType) {
		return false;
	}

	public static boolean isSignOnRequest(String msgType) {
		return false;
	}

	public static boolean isSignOnResponse(String msgType) {
		return false;
	}

	public static boolean isTipAdjustRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isPreAuthCompletionRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isOfflineRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isMasterCardCashbackRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isBatchSettlementRequest(String msgType, String msgTypeId) {
		return false;
	}

	public static boolean isBatchUploadRequest(String msgType) {
		return false;
	}
}