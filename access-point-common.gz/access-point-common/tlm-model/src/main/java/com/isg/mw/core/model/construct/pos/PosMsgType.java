package com.isg.mw.core.model.construct.pos;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum PosMsgType implements IMsgType {
    SignonRequest("0800", "99"),
    SignonResponse("0810", "99"),
    PurchaseRequest("0200", "00"),
    PurchaseResponse("0210", "00"),
    CashWithdrawalRequest("0200", "01"),
    CashWithdrawalResponse("0210", "01"),
    CashAtPosRequest("0200", "09"),
    CashAtPosResponse("0210", "09"),
    PurCashAtPosRequest("0200","09"),
    PurCashAtPosResponse("0210","09"),
    MotoRequest("0200", "51"),
    MotoResponse("0210", "51"),
    PreAuthRequest("0100", "00"),
    PreAuthResponse("0110", "00"),
    RefundRequest("0200", "20"),
    RefundResponse("0210", "20"),
    BalanceEnqRequest("0100", "31"),
    BalanceEnqResponse("0110", "31"),
    ReversalRequest("0400", null),
    ReversalResponse("0410", null),
    VoidRequest("0220", "22"),
    VoidResponse("0230", "22"),
    TipAdjustRequest("0220","50"),  
    TipAdjustResponse("0230","50"),
	PreAuthCompletionRequest("0220","40"),
	PreAuthCompletionResponse("0230","40"),
	OfflineRequest("0220","00"),
	OfflineResponse("0230","00"),	
	MasterCardCashbackRequest("0200","09"),
	BatchSettlementRequest("0500","92"),
	SettlementAfterBatchUploadRequest("0500","96"),
	BatchUploadRequest("0320",null),
    FinancialAdviceResponse("0230", null),
    FinancialAdviceRequest("0220", null),

    AcquirerReconciliationAdviseResponse("0530", null),
    AcquirerReconciliationAdviseRequest("0520", null),
    AcquirerReconciliationAdviseRepeatResponse("0530", null),
    AcquirerReconciliationAdviseRepeatRequest("0521", null),
    FinancialAdvicePurchaseRequest("0220", "00"),
    FinancialAdvicePurchaseResponse("0230", "00"),
    FinancialAdviceCashAtPosRequest("0220", "01"),
    FinancialAdviceCashAtPosResponse("0230", "01"),
    FinancialAdvicePurchaseAndCashAtPosRequest("0220", "09"),
    FinancialAdvicePurchaseAndCashAtPosResponse("0230", "09");
    ;

    public final String msgType;
    public final String msgSubType;

    private PosMsgType(String m, String ms ) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals (String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }


    public boolean equals (String msgType) {
        return (this.msgType.equals(msgType));
    }
}
