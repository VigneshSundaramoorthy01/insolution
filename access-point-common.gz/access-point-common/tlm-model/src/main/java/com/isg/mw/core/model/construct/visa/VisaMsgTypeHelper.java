package com.isg.mw.core.model.construct.visa;

import com.isg.mw.core.model.msgtype.IMsgTypeHelper;

public class VisaMsgTypeHelper implements IMsgTypeHelper {

	private VisaMsgTypeHelper() {
	}

	private static boolean equals(VisaMsgType pReq, VisaMsgType pRes, String m, String mt) {
		boolean retVal = false;
		if (mt != null) {
			String pc = mt.substring(0, 2);
			retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
		}
		return retVal;
	}

	public static boolean isMoto(String msgType, String processingCode) {
		return equals(VisaMsgType.MotoRequest, VisaMsgType.MotoResponse, msgType, processingCode);
	}

	public static boolean isPurchase(String msgType, String msgSubType) {
		return equals(VisaMsgType.PurchaseRequest, VisaMsgType.MotoResponse, msgType, msgSubType);
	}

	public static boolean isCashWithdrawal(String msgType, String processingCode) {
		return equals(VisaMsgType.CashWithdrawalRequest, VisaMsgType.CashWithdrawalResponse, msgType, processingCode);
	}

	public static boolean isCashAtPos(String msgType, String processingCode) {
		return equals(VisaMsgType.CashAtPosRequest, VisaMsgType.CashAtPosResponse, msgType, processingCode);
	}

	public static boolean isPreAuth(String msgType, String processingCode) {
		return equals(VisaMsgType.PreAuthRequest, VisaMsgType.PreAuthResponse, msgType, processingCode);
	}

	public static boolean isRefund(String msgType, String processingCode) {
		return equals(VisaMsgType.RefundRequest, VisaMsgType.RefundResponse, msgType, processingCode);
	}

	public static boolean isBalanceEnquiry(String msgType, String processingCode) {
		return equals(VisaMsgType.BalanceEnqRequest, VisaMsgType.BalanceEnqResponse, msgType, processingCode);
	}

	public static boolean isReversalRequest(String msgType) {
		return VisaMsgType.ReversalRequest.msgType.equals(msgType);
	}

	public static boolean isReversalResponse(String msgType) {
		return VisaMsgType.ReversalResponse.msgType.equals(msgType);
	}

	public static boolean isVoidRequest(String msgType, String msgTypeId) {
		return VisaMsgType.VoidRequest.msgType.equals(msgType) && msgTypeId != null
				&& VisaMsgType.VoidRequest.msgSubType.equals(msgTypeId);
	}

	public static boolean isVoidResponse(String msgType) {
		return VisaMsgType.VoidResponse.msgType.equals(msgType);
	}

	public static boolean isSignOnRequest(String msgType) {
		return VisaMsgType.SignonRequest.msgType.equals(msgType);
	}

	public static boolean isSignOnResponse(String msgType) {
		return VisaMsgType.SignonResponse.msgType.equals(msgType);
	}

	public static boolean isTipAdjustRequest(String msgType, String msgTypeId) {
		boolean isTipAdjustRequestMsgType = VisaMsgType.TipAdjustRequest.msgType.equals(msgType);
		boolean isTipAdjustRequestMsgTypeId = msgTypeId != null
				&& VisaMsgType.TipAdjustRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustRequestMsgType && isTipAdjustRequestMsgTypeId;
	}


	public static boolean isTipAdjustResponse(String msgType, String msgTypeId) {
		boolean isTipAdjustResponseMsgType = VisaMsgType.TipAdjustResponse.msgType.equals(msgType);
		boolean isTipAdjustResponseMsgTypeId = msgTypeId != null
				&& VisaMsgType.TipAdjustResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustResponseMsgType && isTipAdjustResponseMsgTypeId;
	}

	public static boolean isPreAuthCompletionRequest(String msgType, String msgTypeId) {
		boolean isPreAuthCompRequestMsgType = VisaMsgType.PreAuthCompletionRequest.msgType.equals(msgType);
		boolean isPreAuthRequestMsgTypeId = msgTypeId != null
				&& VisaMsgType.PreAuthCompletionRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompRequestMsgType && isPreAuthRequestMsgTypeId;
	}

	public static boolean isPreAuthCompletionResponse(String msgType, String msgTypeId) {
		boolean isPreAuthCompResponseMsgType = VisaMsgType.PreAuthCompletionResponse.msgType.equals(msgType);
		boolean isPreAuthResponseMsgTypeId = msgTypeId != null
				&& VisaMsgType.PreAuthCompletionResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompResponseMsgType && isPreAuthResponseMsgTypeId;
	}

	public static boolean isOfflineRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = VisaMsgType.OfflineRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& VisaMsgType.OfflineRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}
	
	public static boolean isOfflineResponse(String msgType, String msgTypeId) {
		boolean isOfflineResponseMsgType = VisaMsgType.OfflineResponse.msgType.equals(msgType);
		boolean isOfflineResponseMsgTypeId = msgTypeId != null
				&& VisaMsgType.OfflineResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineResponseMsgType && isOfflineResponseMsgTypeId;
	}

	public static boolean isMasterCardCashbackRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = VisaMsgType.MasterCardCashbackRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& VisaMsgType.MasterCardCashbackRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isBatchSettlementRequest(String msgType, String msgTypeId) {
		boolean isBatchSettlementMsgType = VisaMsgType.BatchSettlementRequest.msgType.equals(msgType);
		boolean isBatchSettlementMsgTypeId = msgTypeId != null
				&& (VisaMsgType.BatchSettlementRequest.msgSubType.equals(msgTypeId)
						|| VisaMsgType.SettlementAfterBatchUploadRequest.msgSubType.equals(msgTypeId));
		return isBatchSettlementMsgType && isBatchSettlementMsgTypeId;
	}

	public static boolean isBatchUploadRequest(String msgType) {
		return msgType != null && VisaMsgType.BatchUploadRequest.msgType.equals(msgType);
	}
}
