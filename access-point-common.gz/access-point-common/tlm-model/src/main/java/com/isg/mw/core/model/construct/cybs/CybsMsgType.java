package com.isg.mw.core.model.construct.cybs;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum CybsMsgType implements IMsgType {

    Pay("pay", null),
    IncrementPay("increment_pay", null),
    ReversalPay("reversal_pay", null),
    ReversalTimeout("reversal_timeout", null),
    CapturePay("capture_pay", null),
    RefundPay("refund_pay", null),
    RefundCapture("refund_capture", null),
    Credit("credit", null),
    VoidPay("void_pay", null),
    VoidCapture("void_capture", null),
    VoidRefund("void_refund", null),
    VoidCredit("void_credit", null),
    VoidTimeout("void_timeout", null),
    Preauthpay("preauth_pay", null);

    public final String msgType;
    public final String msgSubType;

    CybsMsgType(String m, String ms) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals(String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }
}
