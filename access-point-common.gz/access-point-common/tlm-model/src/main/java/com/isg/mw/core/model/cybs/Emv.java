package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Emv implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tags;
    private String cardholderVerificationMethodUsed;
    private String cardSequenceNumber;
    private boolean fallback;
    private String fallbackCondition;
}