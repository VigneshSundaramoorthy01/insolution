package com.isg.mw.core.model.tlm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.*;
import com.isg.mw.core.model.icici.UpiResponse;
import com.isg.mw.core.model.pg.MerchantEncReqRes;
import com.isg.mw.core.utils.MaskingUtility;
import lombok.*;

import java.io.Serializable;
import java.time.OffsetDateTime;

/**
 * Basic model of the Transaction Message All transaction messages
 * (Request/Response) are converted to this model
 *
 * @author prasad_t026
 */

@Getter
@Setter
@NoArgsConstructor
public class TransactionMessageModel extends AcpTraceIdModel implements Serializable {
    /**
     * Default serialized version ID
     */
    private static final long serialVersionUID = 1L;

    /**
     * 1.<br>
     * ISO8583 -1987, AS2805 - Secondary bitmap <br>
     * Base24, ISG, XML - Bit map
     */

    private String bitMap;

    /**
     * 2.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Primary
     * Account Number
     */
    private transient String pan;

    /**
     * 3. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Processing Code
     * <br>
     * mPOS - Transaction Type
     */
    private String processingCode;

    /**
     * 4. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Transaction Amount <br>
     * CyberSource API - AuthorizedAmount
     */
    private String txnAmt;

    /**
     * 5.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Amount
     */
    private String settlementAmt;

    /**
     * 6.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Amount
     */
    private String cardHolderBillingAmt;

    /**
     * 7. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transmission Date And Time
     */
    private String transmissionTime;

    /**
     * 8. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Fee Amount
     */
    private String cardHolderBillingFee;

    /**
     * 9. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Conversion Rate
     */
    private String settlementConversionRate;

    /**
     * 10. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Card Holder Billing Conversion Rate
     */
    private String cardHolderBillingConversionRate;

    /**
     * 11. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - System Trace Audit Number
     * <br>
     * CyberSource API - T id
     */
    private String stan;

    /**
     * 12. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Time <br>
     * CyberSource API - Transaction Local Date Time
     */
    private String localTxnTime;

    /**
     * 13. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Local Transaction Date
     */
    private String localTxnDate;

    /**
     * 14. <br>
     * IISO8583 -1987, AS2805, Base24, ISG, CyberSource API, mPOS, XML - Expiration
     * Date
     */
    private String expirationDate;

    /**
     * 15. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Date
     */
    private String settlementDate;

    /**
     * 16. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Currency Conversion Date
     */
    private String conversionDate;

    /**
     * 17. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Capture date
     */
    private String captureDate;

    /**
     * 18.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Merchant Yype <br>
     * ISO8583 -1987, CyberSource API - Category Code
     */
    private String merchantType;

    /**
     * 19. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Acquiring Institution
     * Country Code <br>
     * mPOS - terminalCountryCode
     */
    private String aquirerCountryCode;

    /**
     * 20. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number Extended Country
     * code
     */
    private String panExtendedCountryCode;

    /**
     * 21. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Country Code
     */
    private String panForwardingCountryCode;

    /**
     * 22. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Point Of Service
     * Entry Mode <br>
     * mPOS - NFC Enabled
     */
    private String posEntryMode;

    /**
     * 23. <br>
     * ISO8583 -1987, AS2805, Base24, CyberSource API, XML - Card Sequence Number
     */
    private String cardSeqNo;

    /**
     * 24. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Network International ID <br>
     * CyberSource API - Type
     */
    private String niiId;

    /**
     * 25. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Point of service condition code
     */
    private String posConditionCode;

    /**
     * 26. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Point Of Service PIN Capture Code
     */
    private String posCaptureCode;

    /**
     * 27. <br>
     * ISO8583 -1987, AS2805, Base24, XML -Authorisation Identification Response
     * length
     */
    private String authIdResLength;

    /**
     * 28. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Fee Amount
     */
    private String txnFee;

    /**
     * 29. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Settlement Fee Amount
     */
    private String settlementFee;

    /**
     * 30. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Transaction Processing Fee Amount
     */
    private String txnProcessingFee;

    /**
     * 31.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Amount Settlement Processing Fee
     */
    private String settlementProcessingFee;

    /**
     * 32. <br>
     * ISO8583 -1987, AS2805, Base24, XML - Acquiring Institution Identification
     * Code
     */
    private String aquirerIdCode;

    /**
     * 33.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Forwarding Institution Identification
     * Code
     */
    private String forwardingInstIdCode;

    /**
     * 34.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Primary Account Number(PAN) Extended
     */
    private String panExtended;

    /**
     * 35.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Track 2 Data
     */
    private transient String track2Data;

    /**
     * 36.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Track 3 Data
     */
    private transient String track3Data;

    /**
     * 37.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, mPOS, XML - Retrieval Reference
     * Number<br>
     * CyberSource API - TransactionId
     */
    private String retrievalRefNo;

    /**
     * 38.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Authorization Identification
     * Response<br>
     * mPOS - AuthCode
     */
    private String authIdRes;

    /**
     * 39.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Response Code<br>
     * mPOS - Status Code
     */
    private String resCode;

    /**
     * 40.<br>
     * ISO8583 -1987, AS2805, Base24, XML - Service Restriction Code
     */
    private String serviceRestrictionCode;

    /**
     * 41.<br>
     * ISO8583 -1987, AS2805, Base24, ISG, XML - Card Acceptor Terminal
     * Identification
     */
    private String cardAcceptorTerminalId;

    /**
     * 42. <br>
     * ISO8583 -1987, AS2805, Base24, ISG, CyberSource API, XML - Card Acceptor
     * Identification code<br>
     * mPOS - TxnId
     */
    private String cardAcceptorId;

    /**
     * 43.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API,mPOS, XML - Card Acceptor
     * Name/Location
     */
    private String cardAcceptorInfo;

    /**
     * 44.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Response Data
     */
    private String additionalResData;

    /**
     * 45.<br>
     * ISO8583-1987, AS2805, Base24, ISG, CyberSource API, XML - Track 1 Data
     */
    private transient String track1Data;

    /**
     * 46.ISO8583-1987, AS2805, Base24, XML - Additional Data ISO
     */
    private String isoAd;

    /**
     * 47.<br>
     * ISO8583-1987, AS2805, Base24, XML - Additional Data National
     */
    private String nationalAd;

    /**
     * 48.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML -Additional Data Private
     */
    private String privateAd;

    /**
     * 49.<br>
     * ISO8583-1987, AS2805, Base24, CyberSource API, XML - Transaction Currency
     * Code
     */
    private String txnCurrencyCode;

    /**
     * 50.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Currency Code
     */
    private String settlementCurrenyCode;

    /**
     * 51.<br>
     * CISO8583-1987, AS2805, Base24, XML - Card holder Billing Currency Code
     */
    private String cardHolderBillingCurrencyCode;

    /**
     * 52.<br>
     * ISO8583-1987, AS2805, Base24, ISG,mPOS, XML - Personal Identification Number
     * (PIN) Data<br>
     * CyberSource API - Encrypted Pin
     */
    private String pin;

    /**
     * 53.<br>
     * ISO8583-1987, AS2805, Base24, ISG, mPOS, XML - Security Related Control
     * Information<br>
     * CyberSource API - Encrypted Key Serial Number
     */
    private String securityControlInfo;

    /**
     * 54.<br>
     * ISO8583-1987, AS2805, Base24, ISG, XML - Additional Amount
     */
    private String additionalAmounts;

    /**
     * 55.<br>
     * ISO8583-1987, AS2805,ISG, XML - Integrated Circuit Card Related Data<br>
     * Base24 - ISO Reserved<br>
     * CyberSource API- EMV
     */
    private String iccData;

    /**
     * 56.<br>
     * ISO8583-1987, AS2805, Base24, XML - ISO Reserved
     */
    private String reserved56;

    /**
     * 57.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Amount cash
     */
    private String reserved57;

    /**
     * 58.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Ledger balance
     */
    private String reserved58;

    /**
     * 59.<br>
     * ISO8583-1987,Base24, XML - Reserved for national use<br>
     * AS2805 - Account balance, Cleared funds
     */
    private String reserved59;

    /**
     * 60.<br>
     * ISO8583-1987 - Reserved for national use<br>
     * AS2805,ISG, XML - Reserved private<br>
     * Base24 - Terminal Data
     */
    private String terminalData;

    /**
     * 61.<br>
     * ISO8583-1987, AS2805,ISG, XML - Reserved private<br>
     * Base24 - POS Card Issuer and Authorizer Data , ATM Card Issuer and Authorizer
     * Data
     */
    private String ciad;

    /**
     * 62.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - Postal Code mPos - Invoice Number
     */
    private String postalCode;

    /**
     * 63.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved private<br>
     * Base24 - ATM PIN Offset POS Additional Data
     */
    private String atmPinOffsetData;

    /**
     * 64.<br>
     * ISO8583-1987, AS2805, XML - Message Authentication Code Field<br>
     * Base24 -Primary Message Authentication Code
     */
    private String msgAuthCode;

    /**
     * 65.<br>
     * ISO8583-1987, AS2805, XML - Extended Bitmap Indicator<br>
     * Base24 -Reserved for ISO use
     */
    private String extendedBitmapIndicator;

    /**
     * 66.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Code
     */
    private String settlementCode;

    /**
     * 67.<br>
     * ISO8583-1987, AS2805, Base24, XML - Extended payment code
     */
    private String extendedPaymentCode;

    /**
     * 68.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving institution country code<br>
     * mPOS - Transaction Country Code
     */
    private String receiverCountryCode;

    /**
     * 69.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Country Code
     */
    private String settlementCountryCode;

    /**
     * 70.<br>
     * ISO8583-1987, AS2805, Base24, XML - Network Management Information Code
     */
    private String networkMgmtInfoCode;

    /**
     * 71.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number
     */
    private String msgNo;

    /**
     * 72.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Number Last
     */
    private String lastMsgNo;

    /**
     * 73.<br>
     * ISO8583-1987, AS2805, Base24, XML - Action Date
     */
    private String actionDate;

    /**
     * 74.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Credits
     */
    private String noOfCredits;

    /**
     * 75.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Credits
     */
    private String creditsReversalNo;

    /**
     * 76.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Debits
     */
    private String noOfDebits;

    /**
     * 77.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Debits
     */
    private String debitsReversalNo;

    /**
     * 78.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Transfer
     */
    private String transferNo;

    /**
     * 79.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Number Transfer
     */
    private String transferReversalNo;

    /**
     * 80.<br>
     * ISO8583-1987, AS2805, Base24, XML - Number Inquiries
     */
    private String noOfInquiries;

    /**
     * 81.<br>
     * ISO8583-1987, AS2805, Base24, XML -Number Authorizations
     */
    private String noOfAuths;

    /**
     * 82.<br>
     * ISO8583-1987, AS2805, Base24, XML - Processing Fee Amount Credits
     */
    private String creditsProcessingFee;

    /**
     * 83.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Credits
     */
    private String creditsTxnFee;

    /**
     * 84.<br>
     * ISO8583-1987, AS2805, Base24, XML -Processing Fee Amount Debits
     */
    private String debitsProcessingFee;

    /**
     * 85.<br>
     * ISO8583-1987, AS2805, Base24, XML -Transaction Fee Amount Debits
     */
    private String debitsTxnFee;

    /**
     * 86.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Credits
     */
    private String totalCredits;

    /**
     * 87.<br>
     * ISO8583-1987, AS2805, Base24, XML -Reversal Amount Credits
     */
    private String creditsReversal;

    /**
     * 88.<br>
     * ISO8583-1987, AS2805, Base24, XML -Amount Debits
     */
    private String totalDebits;

    /**
     * 89.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reversal Amount Debits
     */
    private String debitsReversal;

    /**
     * 90.<br>
     * ISO8583-1987, AS2805, Base24, XML -Original Data Elements
     */
    private String originalDataElements;

    /**
     * 91.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Update Code
     */
    private String fileUpdateCode;

    /**
     * 92.<br>
     * ISO8583-1987, AS2805, Base24, XML - File Security Code
     */
    private String fileSecurityCode;

    /**
     * 93.<br>
     * ISO8583-1987, AS2805, Base24, XML - Response Indicator
     */
    private String resIndicator;

    /**
     * 94.<br>
     * ISO8583-1987, AS2805, Base24, XML - Service Indicator
     */
    private String serviceIndicator;

    /**
     * 95.<br>
     * ISO8583-1987, AS2805, Base24, XML - Replacement Amounts
     */
    private String replacementAmts;

    /**
     * 96.<br>
     * ISO8583-1987, AS2805, Base24, XML - Message Security Code
     */
    private String msgSecurityCode;

    /**
     * 97.<br>
     * ISO8583-1987, AS2805, Base24, XML - Net Settlement Amount
     */
    private String netSettlement;

    /**
     * 98.<br>
     * ISO8583-1987, AS2805, Base24, XML - Payee
     */
    private String payee;

    /**
     * 99.<br>
     * ISO8583-1987, AS2805, Base24, XML - Settlement Institution Identification
     * Code
     */
    private String settlementIdCode;

    /**
     * 100.<br>
     * ISO8583-1987, AS2805, Base24, XML - Receiving Institution Identification Code
     */
    private String receiverIdCode;

    /**
     * 101.ISO8583-1987, AS2805, Base24, XML - File Name
     */
    private String fileName;

    /**
     * 102.<br>
     * ISO8583-1987, AS2805, Base24, XML - Account Identification 1
     */
    private String accId1;

    /**
     * 103.ISO8583-1987, AS2805, Base24, XML - Account Identification 2
     */
    private String accId2;

    /**
     * 104.<br>
     * ISO8583-1987, AS2805, Base24, XML - Transaction Description<br>
     * mPOS - transaction_type
     */
    private String txnDesc;

    /**
     * 105.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    private String reserved105;

    /**
     * 106.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    private String reserved106;

    /**
     * 107.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    private String reserved107;

    /**
     * 108.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */
    private String reserved108;

    /**
     * 109.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    private String reserved109;

    /**
     * 110.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    private String reserved110;

    /**
     * 111.<br>
     * ISO8583-1987, AS2805, Base24, XML - Reserved for ISO use
     */
    private String reserved111;

    /**
     * 112.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use<br>
     * AS2805 - Key Management data
     */
    private String reserved112;

    /**
     * 113.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    private String reserved113;

    /**
     * 114.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    private String reserved114;

    /**
     * 115.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    private String reserved115;

    /**
     * 116.<br>
     * ISO8583-1987, Base24, XML - Reserved For National Use
     */
    private String reserved116;

    /**
     * 117. <br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Card Status Update Code
     */
    private String reserved117;

    /**
     * 118.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */
    private String reserved118;

    /**
     * 119.<br>
     * ISO8583-1987, XML - Reserved For National Use<br>
     * AS2805 - Cash Total number
     */
    private String reserved119;

    /**
     * 120.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Terminal Address Branch Region ,POS Terminal Address-Branch
     */
    private String reserved120;

    /**
     * 121. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS Authorization Indicators
     */
    private String reserved121;

    /**
     * 122.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -Card Issuer Identification Code
     */
    private String reserved122;

    /**
     * 123.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - Cryptographic Service Message , ATM Deposit Credit Amount , POS
     * Invoice Data/Settlement Record
     */
    private String reserved123;

    /**
     * 124.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - ATM Repository Type POS Batch and Shift Data/Settlement Record 2
     */
    private String reserved124;

    /**
     * 125.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM account indicator POS Settlement Data/Settlement Record 3
     */
    private String reserved125;

    /**
     * 126. <br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 -ATM Additional Data POS PreAuthorization And Charge back Data
     */
    private String reserved126;

    /**
     * 127.<br>
     * ISO8583-1987,AS2805, XML - Reserved for private use<br>
     * Base24 - POS User Data
     */
    private String reserved127;

    /**
     * 128.<br>
     * ISO8583-1987,AS2805, XML - Message authentication code (MAC) field<br>
     * Base24 - Secondary Message Authentication Code
     */
    private String reserved128;

    /**
     * tlm message type (REQUEST/RESPONSE)
     */
    private TlmMessageType tlmMessageType;

    /**
     * Transaction Id
     */
    private String transactionId;

    /**
     * Request received time
     */
    private OffsetDateTime requestReceivedTime;

    /**
     * Request sent time
     */
    private OffsetDateTime requestSentTime;

    /**
     * Response received time
     */
    private OffsetDateTime responseReceivedTime;

    /**
     * Response sent time
     */
    private OffsetDateTime responseSentTime;

    /**
     * Source type
     */
    private MessageFormat sourceType;

    /**
     * Destination type
     */
    private MessageFormat destinationType;

    /**
     * Merchant / Aggregator Configuration
     */
    private String source;

    /**
     * Switch Configuration
     */
    private String target;

    /**
     * Raw request
     */
    private String rawRequest;

    /**
     * Raw request
     */
    private String rawResponse;

    /**
     * Entity Id
     */
    private String entityId;

    /**
     * Name of the transaction, should be same as in routing definition
     */
    private String transactionName;

    /**
     * Category of the transaction (SIGNON, HEARTBEAT, NORMAL etc)
     */
    private TransactionCategory transactionCategory;

    /**
     * Message type of the transaction (e.g. 0800 - sign on)
     */
    private String msgType;

    /**
     * Host batch number
     */
    private Long hostBatchNo;

    /**
     * Terminal batch number
     */
    private String terminalBatchNo;

    private TargetType targetType;

    private EpType epType;

    // TODO: to revisit stan properties
    private String terminalStan;

    private String schemeStan;


    /**
     * Settlements Totals
     */
    private String saleCount;

    private String saleAmount;

    private String refundCount;

    private String refundAmount;

    private String posApplicationDetails;

    /**
     * Settlement Date
     */
    private OffsetDateTime batchSettlementDate;

    /**
     * Batch upload details
     */

    private String batchStatus;

    private String hardwareSerialNo;

    private String batchUploadStan;

    private String batchUploadTransactionId;

    private String batchUploadMsgType;

    private String drcrFlag;

    private TransactionMessageModel originalTmm;

    /**
     * Masked Pan
     */
    private String maskedPan;

    /**
     * Encrypted Pan
     */
    private String encryptedPan;

    /**
     * Encrypted ExpirationDate
     */
    private String encryptedExpirationDate;

    /**
     * Target Ip and Port
     */
    private String targetIpAndPort;

    private SourceProcessor sourceProcessor;

    private PgData pgData;

    private Double dependentTotTxnAmt;
    
    private Long dependentTotTxnCount;

    private ConnectionType connectionType;

    private CybsData cybsData;

    private UpiResponse upiResponse;

    private String iciciNbCorporateUrl;

    /**
     * KSN to decrypt card number
     */
    private String cardNumberKsn;

    /**
     * KSN to decrypt pinblock
     */
    private String pinblockKsn;

    /**
     * Device manufacturer
     */
    private String deviceMftr;
    
    private String posCid;
    
    private String posAavData;
    
    private String posTridData;

    private String maskedTransactionId;

    private String hashedTransactionId;

    private String originalHashedTxnId;

    private SmartRouteData smartRouteData = new SmartRouteData();

    private SmartRouteData resSmartRouteData = new SmartRouteData();

    private String vanNumber;

    private String senderRefNumber;

    private String customerPan;

    private String customerName;

    private String cvv;

    private Integer currencyDecimals;

    private int failedCount = 0;

    private int txnSequenceNo;

    private String merchantTxnRefNo;

    private String targetMid;

    private String linkHashId;

    private String txnSource;

    private String ipAddress;

    private String targetTxnId;

    private String latitude;

    private String longitude;

    private String convenienceFeeAmt;

    //Icici-UPI
    private String originalBankRRN;
    
    
    //DCC Rate LookUp fields
    private String dccCurrencyName;
    
    private String dccRateLookRrn;
    
    private String dccAmount;
    
    private String dccExchangeRate;
    
    private String dccMarkUpPercent;
    
    private String dccTxnCurrCode;
    
    private String dccNoOfDecimals;
    
    private String dccIndicator;

    private String dccData;

    private MerchantEncReqRes merchantIntegrationReqRes;

    private String originalTransactionId;
    
    // for bin changes
    private String applicationIdentifier;

    //BI Posting
    private String mobileNo;

    private String email;

    private String firstName;

    private String lastName;

    private String street;

    private String city;

    private String state;

    private String zip;

    @JsonProperty("UDF01")
    private String UDF01;

    @JsonProperty("UDF02")
    private String UDF02;

    @JsonProperty("UDF03")
    private String UDF03;

    @JsonProperty("UDF04")
    private String UDF04;

    @JsonProperty("UDF05")
    private String UDF05;

    @JsonProperty("UDF06")
    private String UDF06;

    @JsonProperty("UDF07")
    private String UDF07;

    @JsonProperty("UDF08")
    private String UDF08;

    @JsonProperty("UDF09")
    private String UDF09;

    @JsonProperty("UDF10")
    private String UDF10;

    private String international;

    private String debitCreditFlag;

    private String cardType;

    private String browserName;

    private String browserVersion;

    private String osName;

    private String remark;

    private String cgst;

    private String igst;

    private String sgst;

    private String convenienceFee;

    private String reasonCode;

    private String errorDescription;

    private String originalTargetTransactionId;
    
    private String stationId;

    private String signOnId;

    private String networkLink;

    private DbMessageType dbMessageType;

    private DbMessageType dbMessageTypeId;

    private String customerRemarks;

    private String sourceMpgId;

    /**
     * merchantCountryCode,secretKey,encryptionKey,merchantURL
     */

    private String merchantCountryCode;

    private String merchantURL;

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        getStringData("bitMap",bitMap,sb);
        getStringData("pan",MaskingUtility.maskCardNumber(pan),sb);
        getStringData("bitMap",bitMap,sb);
        getStringData("processingCode",processingCode,sb);
        getStringData("txnAmt",txnAmt,sb);
        getStringData("settlementAmt",settlementAmt,sb);
        getStringData("cardHolderBillingAmt",cardHolderBillingAmt,sb);
        getStringData("transmissionTime",transmissionTime,sb);
        getStringData("cardHolderBillingFee",cardHolderBillingFee,sb);
        getStringData("settlementConversionRate",settlementConversionRate,sb);
        getStringData("cardHolderBillingConversionRate",cardHolderBillingConversionRate,sb);
        getStringData("stan",stan,sb);
        getStringData("localTxnTime",localTxnTime,sb);
        getStringData("localTxnDate",localTxnDate,sb);
        getStringData("expirationDate",MaskingUtility.maskDataElement(expirationDate),sb);
        getStringData("settlementDate",settlementDate,sb);
        getStringData("conversionDate",conversionDate,sb);
        getStringData("captureDate",captureDate,sb);
        getStringData("merchantType",merchantType,sb);
        getStringData("aquirerCountryCode",aquirerCountryCode,sb);
        getStringData("panExtendedCountryCode",panExtendedCountryCode,sb);
        getStringData("panForwardingCountryCode",panForwardingCountryCode,sb);
        getStringData("posEntryMode",posEntryMode,sb);
        getStringData("cardSeqNo",cardSeqNo,sb);
        getStringData("niiId",niiId,sb);
        getStringData("posConditionCode",posConditionCode,sb);
        getStringData("posCaptureCode",posCaptureCode,sb);
        getStringData("authIdResLength",authIdResLength,sb);
        getStringData("txnFee",txnFee,sb);
        getStringData("settlementFee",settlementFee,sb);
        getStringData("txnProcessingFee",txnProcessingFee,sb);
        getStringData("settlementProcessingFee",settlementProcessingFee,sb);
        getStringData("aquirerIdCode",aquirerIdCode,sb);
        getStringData("forwardingInstIdCode",forwardingInstIdCode,sb);
        getStringData("panExtended",panExtended,sb);
        getStringData("track2Data",MaskingUtility.maskDataElement(track2Data),sb);
        getStringData("track3Data",track3Data,sb);
        getStringData("retrievalRefNo",retrievalRefNo,sb);
        getStringData("authIdRes",authIdRes,sb);
        getStringData("resCode",resCode,sb);
        getStringData("serviceRestrictionCode",serviceRestrictionCode,sb);
        getStringData("cardAcceptorTerminalId",cardAcceptorTerminalId,sb);
        getStringData("cardAcceptorId",cardAcceptorId,sb);
        getStringData("cardAcceptorInfo",cardAcceptorInfo,sb);
        getStringData("additionalResData",additionalResData,sb);
        getStringData("track1Data",MaskingUtility.maskDataElement(track1Data),sb);
        getStringData("isoAd",isoAd,sb);
        getStringData("nationalAd",nationalAd,sb);
        getStringData("privateAd",privateAd,sb);
        getStringData("txnCurrencyCode",txnCurrencyCode,sb);
        getStringData("settlementCurrenyCode",settlementCurrenyCode,sb);
        getStringData("cardHolderBillingCurrencyCode",cardHolderBillingCurrencyCode,sb);
        getStringData("pin",MaskingUtility.maskDataElement(pin),sb);
        getStringData("securityControlInfo",securityControlInfo,sb);
        getStringData("additionalAmounts",additionalAmounts,sb);
        getStringData("iccData",iccData,sb);
        getStringData("reserved56",reserved56,sb);
        getStringData("reserved57",reserved57,sb);
        getStringData("reserved58",reserved58,sb);
        getStringData("reserved59",reserved59,sb);
        getStringData("terminalData",terminalData,sb);
        getStringData("ciad",MaskingUtility.maskDataElement(ciad),sb);
        getStringData("postalCode",postalCode,sb);
        getStringData("atmPinOffsetData",atmPinOffsetData,sb);
        getStringData("msgAuthCode",msgAuthCode,sb);
        getStringData("extendedBitmapIndicator",extendedBitmapIndicator,sb);
        getStringData("settlementCode",settlementCode,sb);
        getStringData("extendedPaymentCode",extendedPaymentCode,sb);
        getStringData("receiverCountryCode",receiverCountryCode,sb);
        getStringData("settlementCountryCode",settlementCountryCode,sb);
        getStringData("networkMgmtInfoCode",networkMgmtInfoCode,sb);
        getStringData("msgNo",msgNo,sb);
        getStringData("lastMsgNo",lastMsgNo,sb);
        getStringData("actionDate",actionDate,sb);
        getStringData("noOfCredits",noOfCredits,sb);
        getStringData("creditsReversalNo",creditsReversalNo,sb);
        getStringData("noOfDebits",noOfDebits,sb);
        getStringData("debitsReversalNo",debitsReversalNo,sb);
        getStringData("transferNo",transferNo,sb);
        getStringData("transferReversalNo",transferReversalNo,sb);
        getStringData("noOfInquiries",noOfInquiries,sb);
        getStringData("noOfAuths",noOfAuths,sb);
        getStringData("creditsProcessingFee",creditsProcessingFee,sb);
        getStringData("creditsTxnFee",creditsTxnFee,sb);
        getStringData("debitsProcessingFee",debitsProcessingFee,sb);
        getStringData("debitsTxnFee",debitsTxnFee,sb);
        getStringData("totalCredits",totalCredits,sb);
        getStringData("creditsReversal",creditsReversal,sb);
        getStringData("totalDebits",totalDebits,sb);
        getStringData("debitsReversal",debitsReversal,sb);
        getStringData("originalDataElements",originalDataElements,sb);
        getStringData("fileUpdateCode",fileUpdateCode,sb);
        getStringData("fileSecurityCode",fileSecurityCode,sb);
        getStringData("resIndicator",resIndicator,sb);
        getStringData("serviceIndicator",serviceIndicator,sb);
        getStringData("replacementAmts",replacementAmts,sb);
        getStringData("msgSecurityCode",msgSecurityCode,sb);
        getStringData("netSettlement",netSettlement,sb);
        getStringData("payee",payee,sb);
        getStringData("settlementIdCode",settlementIdCode,sb);
        getStringData("receiverIdCode",receiverIdCode,sb);
        getStringData("fileName",fileName,sb);
        getStringData("accId1",accId1,sb);
        getStringData("accId2",accId2,sb);
        getStringData("txnDesc",txnDesc,sb);
        getStringData("reserved105",reserved105,sb);
        getStringData("reserved106",reserved106,sb);
        getStringData("reserved107",reserved107,sb);
        getStringData("reserved108",reserved108,sb);
        getStringData("reserved109",reserved109,sb);
        getStringData("reserved110",reserved110,sb);
        getStringData("reserved111",reserved111,sb);
        getStringData("reserved112",reserved112,sb);
        getStringData("reserved113",reserved113,sb);
        getStringData("reserved114",reserved114,sb);
        getStringData("reserved115",reserved115,sb);
        getStringData("reserved116",reserved116,sb);
        getStringData("reserved117",reserved117,sb);
        getStringData("reserved118",reserved118,sb);
        getStringData("reserved119",reserved119,sb);
        getStringData("reserved120",reserved120,sb);
        getStringData("reserved121",reserved121,sb);
        getStringData("reserved122",reserved122,sb);
        getStringData("reserved123",reserved123,sb);
        getStringData("reserved124",reserved124,sb);
        getStringData("reserved125",reserved125,sb);
        getStringData("reserved126",reserved126,sb);
        getStringData("reserved127",reserved127,sb);
        getStringData("reserved128",reserved128,sb);
        getStringData("tlmMessageType",tlmMessageType,sb);
        getStringData("transactionId",transactionId,sb);
        getStringData("requestReceivedTime",requestReceivedTime,sb);
        getStringData("requestSentTime",requestSentTime,sb);
        getStringData("responseReceivedTime",responseReceivedTime,sb);
        getStringData("responseSentTime",responseSentTime,sb);
        getStringData("sourceType",sourceType,sb);
        getStringData("destinationType",destinationType,sb);
        getStringData("source",source,sb);
        getStringData("target",target,sb);
        getStringData("rawRequest",MaskingUtility.maskDataElement(rawRequest),sb);
        getStringData("rawResponse",MaskingUtility.maskDataElement(rawResponse),sb);
        getStringData("entityId",entityId,sb);
        getStringData("transactionName",transactionName,sb);
        getStringData("transactionCategory",transactionCategory,sb);
        getStringData("msgType",msgType,sb);
        getStringData("hostBatchNo",hostBatchNo,sb);
        getStringData("terminalBatchNo",terminalBatchNo,sb);
        getStringData("targetType",targetType,sb);
        getStringData("epType",epType,sb);
        getStringData("terminalStan",terminalStan,sb);
        getStringData("schemeStan",schemeStan,sb);
        getStringData("saleCount",saleCount,sb);
        getStringData("saleAmount",saleAmount,sb);
        getStringData("refundCount",refundCount,sb);
        getStringData("refundAmount",refundAmount,sb);
        getStringData("posApplicationDetails",posApplicationDetails,sb);
        getStringData("batchSettlementDate",batchSettlementDate,sb);
        getStringData("batchStatus",batchStatus,sb);
        getStringData("hardwareSerialNo",hardwareSerialNo,sb);
        getStringData("batchUploadStan",batchUploadStan,sb);
        getStringData("batchUploadTransactionId",batchUploadTransactionId,sb);
        getStringData("batchUploadMsgType",batchUploadMsgType,sb);
        getStringData("drcrFlag",drcrFlag,sb);
        getStringData("originalTmm",originalTmm,sb);
        getStringData("maskedPan",maskedPan,sb);
        getStringData("encryptedPan",MaskingUtility.maskDataElement(encryptedPan),sb);
        getStringData("encryptedExpirationDate",MaskingUtility.maskDataElement(encryptedExpirationDate),sb);
        getStringData("targetIpAndPort",targetIpAndPort,sb);
        getStringData("sourceProcessor",sourceProcessor,sb);
        sb.append("\"pgData\":").append(pgData).append(',');
        getStringData("dependentTotTxnAmt",dependentTotTxnAmt,sb);
        getStringData("connectionType",connectionType,sb);
        sb.append("\"cybsData\":").append(cybsData).append(',');
        sb.append("\"upiResponse\":").append(upiResponse).append(',');;
        getStringData("iciciNbCorporateUrl",iciciNbCorporateUrl,sb);
        getStringData("cardNumberKsn",cardNumberKsn,sb);
        getStringData("pinblockKsn",pinblockKsn,sb);
        getStringData("deviceMftr",deviceMftr,sb);
        getStringData("maskedTransactionId",maskedTransactionId,sb);
        getStringData("hashedTransactionId",MaskingUtility.maskDataElement(hashedTransactionId),sb);
        getStringData("originalHashedTxnId",originalHashedTxnId,sb);
        sb.append("\"smartRouteData\":").append(smartRouteData).append(',');
        sb.append("\"resSmartRouteData\":").append(resSmartRouteData).append(',');
        getStringData("vanNumber",vanNumber,sb);
        getStringData("senderRefNumber",senderRefNumber,sb);
        getStringData("customerPan",customerPan,sb);
        getStringData("customerName",customerName,sb);
        getStringData("cvv",cvv,sb);
        getStringData("currencyDecimals",currencyDecimals,sb);
        getStringData("failedCount",failedCount,sb);
        getStringData("merchantTxnRefNo",merchantTxnRefNo,sb);
        getStringData("targetMid",targetMid,sb);
        getStringData("linkHashId",linkHashId,sb);
        getStringData("txnSource",txnSource,sb);
        getStringData("ipAddress",ipAddress,sb);
        getStringData("targetTxnId",targetTxnId,sb);
        getStringData("latitude",latitude,sb);
        getStringData("longitude",longitude,sb);
        getStringData("convenienceFeeAmt",convenienceFeeAmt,sb);
        getStringData("originalBankRRN",originalBankRRN,sb);
        sb.append("\"merchantIntegrationReqRes\":").append(merchantIntegrationReqRes).append(',');
        getStringData("originalTransactionId",originalTransactionId,sb);
        getStringData("mobileNo",mobileNo,sb);
        getStringData("email",email,sb);
        getStringData("firstName",firstName,sb);
        getStringData("lastName",lastName,sb);
        getStringData("street",street,sb);
        getStringData("city",city,sb);
        getStringData("state",state,sb);
        getStringData("zip",zip,sb);
        getStringData("UDF01",UDF01,sb);
        getStringData("UDF02",UDF02,sb);
        getStringData("UDF03",UDF03,sb);
        getStringData("UDF04",UDF04,sb);
        getStringData("UDF05",UDF05,sb);
        getStringData("UDF06",UDF06,sb);
        getStringData("UDF07",UDF07,sb);
        getStringData("UDF08",UDF08,sb);
        getStringData("UDF09",UDF09,sb);
        getStringData("UDF10",UDF10,sb);
        getStringData("international",international,sb);
        getStringData("debitCreditFlag",debitCreditFlag,sb);
        getStringData("cardType",cardType,sb);
        getStringData("browserName",browserName,sb);
        getStringData("browserVersion",browserVersion,sb);
        getStringData("osName",osName,sb);
        getStringData("remark",remark,sb);
        getStringData("cgst",cgst,sb);
        getStringData("igst",igst,sb);
        getStringData("sgst",sgst,sb);
        getStringData("convenienceFee",convenienceFee,sb);
        getStringData("reasonCode",reasonCode,sb);
        getStringData("errorDescription",errorDescription,sb);
        getStringData("originalTargetTransactionId",originalTargetTransactionId,sb);
        getStringData("stationId",stationId,sb);
        getStringData("signOnId",signOnId,sb);
        getStringData("networkLink",networkLink,sb);
        getStringData("dbMessageType",dbMessageType,sb);
        getStringData("customerRemarks",customerRemarks,sb);
        getStringData("merchantCountryCode", merchantCountryCode, sb);
        getStringData("merchantURL", merchantURL, sb);
        getStringData("sourceMpgId",sourceMpgId,sb);
        sb.append("\"dbMessageTypeId\":").append(getValueString(dbMessageTypeId));
        sb.append('}');
        return sb.toString();
    }

    public static String getStringData(String key, Object value, StringBuilder sb, Boolean... noAppendComma) {
        boolean nac = false;
        if (noAppendComma != null && noAppendComma.length != 0) {
            nac = noAppendComma[0];
        }
        if (nac && (value != null)) {
            sb.append("\"" + key + "\":").append(getValueString(value));
        } else if (value != null) {
            sb.append("\"" + key + "\":").append(getValueString(value)).append(',');
        }
        return sb.toString();
    }

    private static String getValueString(Object value) {
        if(value != null){
            StringBuilder sb = new StringBuilder();
            return sb.append("\"").append(value).append("\"").toString();
        }
        return  null;
    }



    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PgData implements Serializable {

        /**
         * 7.<br>
         * cvv2
         */
        private String cvv2;

        /**
         * 12.<br>
         * avv
         */
        private String avv;

        /**
         * 18.<br>
         * cvvResult
         */
        private String cvvResult;

        /**
         * 19.<br>
         * pgTxnRefNo
         */
        private String pgTxnRefNo;

        /**
         * 20.<br>
         * ecommerceIndicator
         */
        private String ecommerceIndicator;

        /**
         * 21.<br>
         * originalTxnPgid
         */
        private String originalTxnPgid;

        /**
         * 22.<br>
         * frmIpAddress
         */
        private String frmIpAddress;

        /**
         * 29.<br>
         * pgId
         */
        private String pgId;

        /**
         * 33.<br>
         * dsVersion
         */
        private String dsVersion;

        /**
         * 34.<br>
         * bankName
         */
        private String bankName;

        /**
         * 35.<br>
         * cancelationId
         */
        private String cancelationId;

        /**
         * 36.<br>
         * mac
         */
        private String mac;

        /**
         * 39.<br>
         * tavv
         */
        private String tavv;

        /**
         * 40.<br>
         * tokenRequestorId
         */
        private String tokenRequestorId;

        /**
         * onlineRefundResCode
         */
        private String onlineRefundResCode;

        /**
         * onlineRefundAuthIdRes
         */
        private String onlineRefundAuthIdRes;

        /**
         * 41.<br>
         * field41
         */
        private String field41;

        /**
         * 42.<br>
         * dsTransactionId
         */
        private String dsTransactionId;

        /**
         * 43.<br>
         * dsMsgCategory
         */
        private String dsMsgCategory;

        /**
         * 44.<br>
         * dsAddMatchIndicator
         */
        private String dsAddMatchIndicator;

        /**
         * 45.<br>
         * dsSecureIndicator
         */
        private String dsSecureIndicator;

        /**
         * 46.<br>
         * cofTxnOrigin
         */
        private String cofTxnOrigin;

        /**
         * 47.<br>
         * mastercardPosData
         */
        private String mastercardPosData;

        //FOR AMEX

        /**
         * 48.<br>
         * mastercardPosData
         */
        private String cid;

        /**
         * 49.<br>
         * aevvValidationResult
         */
        private String aevvValidationResult;

        /**
         * 50.<br>
         * aavCardMemberBillingPostalCode
         */
        private String aavCardMemberBillingPostalCode;

        /**
         * 51.<br>
         * aavCardMemberBillingAddress
         */
        private String aavCardMemberBillingAddress;

        /**
         * 52.<br>
         * avvCardMemberBillingFirstName
         */
        private String aavCardMemberBillingFirstName;

        /**
         * 53.<br>
         * aavCardMemberBillingLastName
         */
        private String aavCardMemberBillingLastName;

        /**
         * 54.<br>
         * aavCardMemberBillingPhoneNumber
         */
        private String aavCardMemberBillingPhoneNumber;

        /**
         * 55.<br>
         * aavShipToPostalCode
         */
        private String aavShipToPostalCode;

        /**
         * 56.<br>
         * aavShipToAddress
         */
        private String aavShipToAddress;

        /**
         * 57.<br>
         * aavShipToFirstName
         */
        private String aavShipToFirstName;

        /**
         * 58.<br>
         * aavShipToLastName
         */
        private String aavShipToLastName;

        /**
         * 59.<br>
         * aavShipToPhoneNumber
         */
        private String aavShipToPhoneNumber;

        /**
         * 60.<br>
         * aavShipToCountryCode
         */
        private String aavShipToCountryCode;

        /**
         * 61.<br>
         * aavResponseVerificationCode
         */
        private String aavResponseVerificationCode;

        /**
         * 62.<br>
         * mastercardPosData
         */
        private String reversalMessageReasonCode;

        /**
         * 63.<br>
         * customerEmail
         */
        private String customerEmail;

        /**
         * 64.<br>
         * customerHostname
         */
        private String customerHostname;

        /**
         * 65.<br>
         * httpBrowserType
         */
        private String httpBrowserType;

        /**
         * 66.<br>
         * shipToCountry
         */
        private String shipToCountry;

        /**
         * 67.<br>
         * shippingMethod
         */
        private String shippingMethod;

        /**
         * 68.<br>
         * merchantProductSku
         */
        private String merchantProductSku;

        /**
         * 69.<br>
         * customerIp
         */
        private String customerIp;

        /**
         * 70.<br>
         * customerAni
         */
        private String customerAni;

        /**
         * 71.<br>
         * customerIIDigits
         */
        private String customerIIDigits;

        /**
         * 72.<br>
         * responseVerificationCodeForTelephoneEmail
         */
        private String responseVerificationCodeForTelephoneEmail;

        /**
         * 73.<br>
         * transactionIdentifier
         */
        private String transactionIdentifier;

        /**
         * 74.<br>
         * departureDate
         */
        private String departureDate;

        /**
         * 75.<br>
         * airlinePassangerName
         */
        private String airlinePassangerName;

        /**
         * 76.<br>
         * origin
         */
        private String origin;

        /**
         * 77.<br>
         * destination
         */
        private String destination;

        /**
         * 78.<br>
         * noOfCities
         */
        private String noOfCities;

        /**
         * 79.<br>
         * routingCities
         */
        private String routingCities;

        /**
         * 80.<br>
         * noOfAirlineCarriers
         */
        private String noOfAirlineCarriers;

        /**
         * 81.<br>
         * airlineCarriers
         */
        private String airlineCarriers;

        /**
         * 82.<br>
         * fareBasis
         */
        private String fareBasis;

        /**
         * 83.<br>
         * noOfPassangers
         */
        private String noOfPassangers;

        /**
         * 84.<br>
         * multiPurposeMerIndicator
         */
        private String multiPurposeMerIndicator;

        /**
         * 85.<br>
         * multiPurposeMerIndicator
         */
        private String paymentAcctReference;

        /**
         * 86.<br>
         * securityServicesAddData
         */
        private String securityServicesAddData;


        /**
         * 87.<br>
         * merchantPaymentGatewayId
         */
        private String merchantPaymentGatewayId;

        /**
         * 89.<br>
         * recurringPaymentIndicator
         */
        private String recurringPaymentIndicator;

        /**
         * 90.<br>
         * authenticationOutageIndicator
         */
        private String authenticationOutageIndicator;

        private String refundOriginalTxnPgid;



        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("cvv2", cvv2, sb);
            getStringData("avv", avv, sb);
            getStringData("cvvResult", cvvResult, sb);
            getStringData("pgTxnRefNo", pgTxnRefNo, sb);
            getStringData("ecommerceIndicator", ecommerceIndicator, sb);
            getStringData("originalTxnPgid", originalTxnPgid, sb);
            getStringData("frmIpAddress", frmIpAddress, sb);
            getStringData("pgId", pgId, sb);
            getStringData("dsVersion", dsVersion, sb);
            getStringData("bankName", bankName, sb);
            getStringData("cancelationId", cancelationId, sb);
            getStringData("mac", mac, sb);
            getStringData("tavv", tavv, sb);
            getStringData("tokenRequestorId", tokenRequestorId, sb);
            getStringData("onlineRefundResCode", onlineRefundResCode, sb);
            getStringData("onlineRefundAuthIdRes", onlineRefundAuthIdRes, sb);
            getStringData("field41", field41, sb);
            getStringData("dsTransactionId", dsTransactionId, sb);
            getStringData("dsMsgCategory", dsMsgCategory, sb);
            getStringData("dsAddMatchIndicator", dsAddMatchIndicator, sb);
            getStringData("dsSecureIndicator", dsSecureIndicator, sb);
            getStringData("cofTxnOrigin", cofTxnOrigin, sb);
            getStringData("mastercardPosData", mastercardPosData, sb);
            getStringData("cid", cid, sb);
            getStringData("aevvValidationResult", aevvValidationResult, sb);
            getStringData("aavCardMemberBillingPostalCode", aavCardMemberBillingPostalCode, sb);
            getStringData("aavCardMemberBillingAddress", aavCardMemberBillingAddress, sb);
            getStringData("aavCardMemberBillingFirstName", aavCardMemberBillingFirstName, sb);
            getStringData("aavCardMemberBillingLastName", aavCardMemberBillingLastName, sb);
            getStringData("aavCardMemberBillingPhoneNumber", aavCardMemberBillingPhoneNumber, sb);
            getStringData("aavShipToPostalCode", aavShipToPostalCode, sb);
            getStringData("aavShipToAddress", aavShipToAddress, sb);
            getStringData("aavShipToFirstName", aavShipToFirstName, sb);
            getStringData("aavShipToLastName", aavShipToLastName, sb);
            getStringData("aavShipToPhoneNumber", aavShipToPhoneNumber, sb);
            getStringData("aavShipToCountryCode", aavShipToCountryCode, sb);
            getStringData("aavResponseVerificationCode", aavResponseVerificationCode, sb);
            getStringData("reversalMessageReasonCode", reversalMessageReasonCode, sb);
            getStringData("customerEmail", customerEmail, sb);
            getStringData("customerHostname", customerHostname, sb);
            getStringData("httpBrowserType", httpBrowserType, sb);
            getStringData("shipToCountry", shipToCountry, sb);
            getStringData("shippingMethod", shippingMethod, sb);
            getStringData("merchantProductSku", merchantProductSku, sb);
            getStringData("customerIp", customerIp, sb);
            getStringData("customerAni", customerAni, sb);
            getStringData("customerIIDigits", customerIIDigits, sb);
            getStringData("responseVerificationCodeForTelephoneEmail", responseVerificationCodeForTelephoneEmail, sb);
            getStringData("transactionIdentifier", transactionIdentifier, sb);
            getStringData("departureDate", departureDate, sb);
            getStringData("airlinePassangerName", airlinePassangerName, sb);
            getStringData("origin", origin, sb);
            getStringData("destination", destination, sb);
            getStringData("noOfCities", noOfCities, sb);
            getStringData("routingCities", routingCities, sb);
            getStringData("noOfAirlineCarriers", noOfAirlineCarriers, sb);
            getStringData("airlineCarriers", airlineCarriers, sb);
            getStringData("fareBasis", fareBasis, sb);
            getStringData("noOfPassangers", noOfPassangers, sb);
            getStringData("multiPurposeMerIndicator", multiPurposeMerIndicator, sb);
            getStringData("recurringPaymentIndicator", recurringPaymentIndicator, sb);
            getStringData("authenticationOutageIndicator", authenticationOutageIndicator, sb);
            getStringData("refundOriginalTxnPgid", refundOriginalTxnPgid, sb);
            sb.append("\"merchantPaymentGatewayId\":").append(getValueString(merchantPaymentGatewayId));
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @ToString
    public static class CybsData implements Serializable {
        private String clientReferenceCode;
        private String networkTransactionId;
        private String transactionId;
        private String reconciliationId;
        private String status;
        private String cardType;
        private String reason;
        private String errorDetails;


        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("clientReferenceCode",clientReferenceCode,sb);
            getStringData("networkTransactionId",networkTransactionId,sb);
            getStringData("transactionId",transactionId,sb);
            getStringData("reconciliationId",reconciliationId,sb);
            getStringData("status",status,sb);
            getStringData("cardType",cardType,sb);
            getStringData("reason",reason,sb);
            sb.append("\"errorDetails\":").append(getValueString(errorDetails));
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @ToString
    public static class PayUData implements Serializable {
        private String key;
        private String txnid;
        private String amount;
        private String firstname;
        private String email;
        private String phone;
        private String productinfo;
        private String pg;
        private String bankcode;
        private String surl;
        private String furl;
        private String hash;
        private String command;
        private String var1;
        private String var2;
        private String var3;
        private String var4;
        private String var5;
        private String var6;
        private String var7;
        private String var8;

        private String mihpayid;
        private String mode;
        private String status;
        private String unmappedStatus;
        private String discount;
        private String netAmountDebit;
        private String addedOn;
        private String lastname;
        private String address1;
        private String address2;
        private String city;
        private String state;
        private String country;
        private String zipcode;
        private String udf1;
        private String udf2;
        private String udf3;
        private String udf4;
        private String udf5;
        private String udf6;
        private String udf7;
        private String udf8;
        private String udf9;
        private String udf10;
        private String field1;
        private String field2;
        private String field3;
        private String field4;
        private String field5;
        private String field6;
        private String field7;
        private String field8;
        private String field9;
        private String paymentSource;
        private String pgType;
        private String bankRefNum;
        private String error;
        private String errorMsg;

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("key",key,sb);
            getStringData("txnid",txnid,sb);
            getStringData("amount",amount,sb);
            getStringData("firstname",firstname,sb);
            getStringData("email",email,sb);
            getStringData("phone",phone,sb);
            getStringData("productinfo",productinfo,sb);
            getStringData("pg",pg,sb);
            getStringData("bankcode",bankcode,sb);
            getStringData("surl",surl,sb);
            getStringData("furl",furl,sb);
            getStringData("hash",hash,sb);
            getStringData("command",command,sb);
            getStringData("var1",var1,sb);
            getStringData("var2",var2,sb);
            getStringData("var3",var3,sb);
            getStringData("var4",var4,sb);
            getStringData("var5",var5,sb);
            getStringData("var6",var6,sb);
            getStringData("var7",var7,sb);
            getStringData("var8",var8,sb);
            getStringData("mihpayid",mihpayid,sb);
            getStringData("mode",mode,sb);
            getStringData("status",status,sb);
            getStringData("unmappedStatus",unmappedStatus,sb);
            getStringData("discount",discount,sb);
            getStringData("netAmountDebit",netAmountDebit,sb);
            getStringData("addedOn",addedOn,sb);
            getStringData("lastname",lastname,sb);
            getStringData("address1",address1,sb);
            getStringData("address2",address2,sb);
            getStringData("city",city,sb);
            getStringData("state",state,sb);
            getStringData("country",country,sb);
            getStringData("zipcode",zipcode,sb);
            getStringData("udf1",udf1,sb);
            getStringData("udf2",udf2,sb);
            getStringData("udf3",udf3,sb);
            getStringData("udf4",udf4,sb);
            getStringData("udf5",udf5,sb);
            getStringData("udf6",udf6,sb);
            getStringData("udf7",udf7,sb);
            getStringData("udf8",udf8,sb);
            getStringData("udf9",udf9,sb);
            getStringData("udf10",udf10,sb);
            getStringData("field1",field1,sb);
            getStringData("field2",field2,sb);
            getStringData("field3",field3,sb);
            getStringData("field4",field4,sb);
            getStringData("field5",field5,sb);
            getStringData("field6",field6,sb);
            getStringData("field7",field7,sb);
            getStringData("field8",field8,sb);
            getStringData("field9",field9,sb);
            getStringData("paymentSource",paymentSource,sb);
            getStringData("pgType",pgType,sb);
            getStringData("bankRefNum",bankRefNum,sb);
            getStringData("error",error,sb);
            sb.append("\"errorMsg\":").append(getValueString(errorMsg));
            sb.append('}');
            return sb.toString();
        }
    }


    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SmartRouteData implements Serializable {
        private String payModeId;
        private String payModeOptionId;
        private String merchantTxnRefNo;
        private String redirectUrl;
        private String returnUrl;
        private Object redirectData;
        private String orderInfo;
        private String customerMobNo;
        private String encryptionEnable;
        private PayUData payUData = new PayUData();
        //        private IciciUpiData iciciUpiData = new IciciUpiData();
        private UpiResponse upiResponse = new UpiResponse();
        private TpslData tpslData = new TpslData();
        private LyraData lyraData = new LyraData();
        private IciciRetailData iciciRetailData= new IciciRetailData();
        private OfflineTransactionData offlineTxnData = new OfflineTransactionData();
        private String issuerName;
        private String payOpt;

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("payModeId",payModeId,sb);
            getStringData("payModeOptionId",payModeOptionId,sb);
            getStringData("merchantTxnRefNo",merchantTxnRefNo,sb);
            getStringData("redirectUrl",redirectUrl,sb);
            getStringData("returnUrl",returnUrl,sb);
            getStringData("redirectData",redirectData,sb);
            getStringData("orderInfo",orderInfo,sb);
            getStringData("customerMobNo",customerMobNo,sb);
            getStringData("encryptionEnable",encryptionEnable,sb);
            sb.append("\"payUData\":").append(payUData).append(',');
            sb.append("\"upiResponse\":").append(upiResponse).append(',');
            sb.append("\"tpslData\":").append(tpslData).append(',');
            sb.append("\"lyraData\":").append(lyraData).append(',');
            sb.append("\"iciciRetailData\":").append(iciciRetailData).append(',');
            sb.append("\"offlineTxnData\":").append(offlineTxnData).append(',');
            getStringData("issuerName",issuerName,sb);
            sb.append("\"payOpt\":").append(getValueString(payOpt));
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class IciciRetailData implements Serializable {
        private String prn;
        private String itc;
        private String amount;
        private String crn;
        private String paid;
        private String bid;

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("prn",prn,sb);
            getStringData("itc",itc,sb);
            getStringData("amount",amount,sb);
            getStringData("crn",crn,sb);
            getStringData("paid",paid,sb);
            sb.append("\"bid\":").append(getValueString(bid));
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OfflineTransactionData implements Serializable {
        private String chequeDate;
        private String chequeNumber;
        private String micrCode;
        private String bankName;
        private String branchName;
        private String instrumentNo;
        private String instrumentDate;
        private String userId;
        private String accountNumber;
        private String ifscCode;
        private String mktgPageLink;


        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("chequeDate",chequeDate,sb);
            getStringData("chequeNumber",chequeNumber,sb);
            getStringData("micrCode",micrCode,sb);
            getStringData("bankName",bankName,sb);
            getStringData("branchName",branchName,sb);
            getStringData("instrumentNo",instrumentNo,sb);
            getStringData("instrumentDate",instrumentDate,sb);
            getStringData("userId",userId,sb);
            getStringData("accountNumber",accountNumber,sb);
            getStringData("ifscCode",ifscCode,sb);
            sb.append("\"mktgPageLink\":").append(getValueString(mktgPageLink));
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class IciciNbData implements Serializable {

        @JsonIgnoreProperties
        @JsonProperty("Action.ShoppingMall.Login.Init")
        public String actionShoppingMallLoginUnit;

        @JsonIgnoreProperties
        @JsonProperty("BankId")
        public String bankId;

        @JsonIgnoreProperties
        @JsonProperty("USER_LANG_ID")
        public String userLangId;

        @JsonIgnoreProperties
        @JsonProperty("AppType")
        public String appType;

        @JsonIgnoreProperties
        @JsonProperty("UserType")
        public String userType;

        @JsonIgnoreProperties
        @JsonProperty("ShowOnSamePage")
        public String showOnSamePage;

        @JsonIgnoreProperties
        @JsonProperty("IWQRYTASKOBJNAME")
        public String Login;

        @JsonIgnoreProperties
        @JsonProperty("BAY_BANKID")
        public String bayBankId;

        @JsonProperty("MD")
        public String modeOfPayment;

        @JsonProperty("PID")
        public String payeeId;

        @JsonProperty("PRN")
        public String uniqueRefNo;

        @JsonProperty("ITC")
        public String itcRefNo;

        @JsonProperty("AMT")
        public String amount;

        @JsonProperty("CRN")
        public String currency;

        @JsonProperty("CG")
        public String gatewayParameter;

        @JsonProperty("CYBERR")
        public String cyberReceiptPage;

        @JsonProperty("RU")
        public String returnUrl;

        @JsonProperty("payopt")
        public String payOpt;

        @JsonProperty("redeemgc")
        public String redeeMgc;

        @JsonProperty("gcertno")
        public String gcertNo;

        @JsonProperty("PMT-DATE")
        public String pmtDate;

        @JsonProperty("BID")
        public String bid;

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("actionShoppingMallLoginUnit",actionShoppingMallLoginUnit,sb);
            getStringData("bankId",bankId,sb);
            getStringData("userLangId",userLangId,sb);
            getStringData("appType",appType,sb);
            getStringData("userType",userType,sb);
            getStringData("showOnSamePage",showOnSamePage,sb);
            getStringData("Login",Login,sb);
            getStringData("bayBankId",bayBankId,sb);
            getStringData("modeOfPayment",modeOfPayment,sb);
            getStringData("payeeId",payeeId,sb);
            getStringData("uniqueRefNo",uniqueRefNo,sb);
            getStringData("itcRefNo",itcRefNo,sb);
            getStringData("amount",amount,sb);
            getStringData("currency",currency,sb);
            getStringData("gatewayParameter",gatewayParameter,sb);
            getStringData("cyberReceiptPage",cyberReceiptPage,sb);
            getStringData("returnUrl",returnUrl,sb);
            getStringData("payOpt",payOpt,sb);
            getStringData("redeeMgc",redeeMgc,sb);
            getStringData("pmtDate",pmtDate,sb);
            getStringData("bid",bid,sb);
            sb.append("\"gcertNo\":").append(getValueString(gcertNo));
            sb.append('}');
            return sb.toString();
        }

    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class TpslData implements Serializable {
        private String txnStatus;
        private String txnMsg;
        private String txnErrMsg;
        private String clientTxnRef;
        private String tpslBankCode;
        private String tpslTxnId;
        private String clientReqMeta;
        private String tpslTxnTime;
        private String tpslRfndId;
        private String balAmt;
        private String requestToken;
        private String hash;
        private String refundResponseToken;


        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("txnStatus",txnStatus,sb);
            getStringData("txnMsg",txnMsg,sb);
            getStringData("txnErrMsg",txnErrMsg,sb);
            getStringData("clientTxnRef",clientTxnRef,sb);
            getStringData("tpslBankCode",tpslBankCode,sb);
            getStringData("tpslTxnId",tpslTxnId,sb);
            getStringData("clientReqMeta",clientReqMeta,sb);
            getStringData("tpslTxnTime",tpslTxnTime,sb);
            getStringData("tpslRfndId",tpslRfndId,sb);
            getStringData("balAmt",balAmt,sb);
            getStringData("requestToken",requestToken,sb);
            getStringData("hash",hash,sb);
            sb.append("\"refundResponseToken\":").append(getValueString(refundResponseToken));
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LyraData implements Serializable {
        private String cardNumber;
        private String customerName;
        private String customerEmail;
        private String expMonth;
        private String expYear;
        private String cardHolderName;
        private String cvv;
        private String uuid;
        private String date;
        private String status;
        private String due;
        private String paid;
        private String refunded;
        private String customerAddress;
        private String customerCity;
        private String customerState;
        private String customerZipCode;
        private String customerCountry;
        private String attempts;
        private String maxAttempts;
        private String testMode;
        private String surcharge;
        private String otp;
        private String ipAddress;
        private String currency;
        private String orderId;
        private String fee;
        private String paymentFamily;
        private String saleTrnsAmount;
        private String shopId;
        private String shopName;
        private String tax;
        private String amount;
        private String refundRef;
        private String externalId;
        private String authResponseCode;
        private String transactionUuid;


        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("cardNumber",cardNumber,sb);
            getStringData("customerName",customerName,sb);
            getStringData("customerEmail",customerEmail,sb);
            getStringData("expMonth",expMonth,sb);
            getStringData("expYear",expYear,sb);
            getStringData("cardHolderName",cardHolderName,sb);
            getStringData("cvv",cvv,sb);
            getStringData("uuid",uuid,sb);
            getStringData("date",date,sb);
            getStringData("status",status,sb);
            getStringData("due",due,sb);
            getStringData("paid",paid,sb);
            getStringData("refunded",refunded,sb);
            getStringData("customerAddress",customerAddress,sb);
            getStringData("customerCity",customerCity,sb);
            getStringData("customerState",customerState,sb);
            getStringData("customerZipCode",customerZipCode,sb);
            getStringData("customerCountry",customerCountry,sb);
            getStringData("attempts",attempts,sb);
            getStringData("maxAttempts",maxAttempts,sb);
            getStringData("testMode",testMode,sb);
            getStringData("surcharge",surcharge,sb);
            getStringData("otp",otp,sb);
            getStringData("ipAddress",ipAddress,sb);
            getStringData("currency",currency,sb);
            getStringData("orderId",orderId,sb);
            getStringData("fee",fee,sb);
            getStringData("paymentFamily",paymentFamily,sb);
            getStringData("saleTrnsAmount",saleTrnsAmount,sb);
            getStringData("shopId",shopId,sb);
            getStringData("shopName",shopName,sb);
            getStringData("tax",tax,sb);
            getStringData("amount",amount,sb);
            getStringData("refundRef",refundRef,sb);
            getStringData("externalId",externalId,sb);
            getStringData("authResponseCode",authResponseCode,sb);
            sb.append("\"transactionUuid\":").append(getValueString(transactionUuid));
            sb.append('}');
            return sb.toString();
        }

    }

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LyraResData implements Serializable {

        /**
         *
         */
        private static final long serialVersionUID = 1L;

        @JsonProperty("headers")
        public String headers;

        @JsonProperty("uuid")
        public String uuid;

        @JsonProperty("instructionName")
        public String instructionName;

        @JsonProperty("method")
        public String method;

        @JsonProperty("cardScheme")
        public String cardScheme;

        @JsonProperty("params")
        public Params params;

        @JsonProperty("url")
        public String url;

        @JsonProperty("target2")
        public String target2;

        @JsonProperty("timeout")
        public String timeout;

        @JsonProperty("target")
        public String target;

        @JsonProperty("transactionUuid")
        public String transactionUuid;

        @JsonProperty("protocol")
        public String protocol;

        @JsonProperty("iframeWidth")
        public String iframeWidth;

        @JsonProperty("iframeHeight")
        public String iframeHeight;

        @JsonProperty("iframeVisible")
        public String iframeVisible;

        @JsonProperty("popupSupport")
        public String popupSupport;

        @JsonProperty("authenticationMode")
        public String authenticationMode;

        private String externalId;


        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("headers",headers,sb);
            getStringData("uuid",uuid,sb);
            getStringData("instructionName",instructionName,sb);
            getStringData("method",method,sb);
            getStringData("cardScheme",cardScheme,sb);
            sb.append("\"params\":").append(params);
            getStringData("url",url,sb);
            getStringData("target2",target2,sb);
            getStringData("timeout",timeout,sb);
            getStringData("target",target,sb);
            getStringData("transactionUuid",transactionUuid,sb);
            getStringData("protocol",protocol,sb);
            getStringData("iframeWidth",iframeWidth,sb);
            getStringData("iframeHeight",iframeHeight,sb);
            getStringData("iframeVisible",iframeVisible,sb);
            getStringData("popupSupport",popupSupport,sb);
            getStringData("authenticationMode",authenticationMode,sb);
            sb.append("\"externalId\":").append(getValueString(externalId)).append(',');
            sb.append('}');
            return sb.toString();
        }
    }

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Params implements Serializable {
        /**
         *
         */
        private static final long serialVersionUID = 1L;

        @JsonProperty("PaReq")
        public String PaReq;

        @JsonProperty("TermUrl")
        public String TermUrl;

        @JsonProperty("AccuCardholderId")
        public String AccuCardholderId;

        @JsonProperty("AccuReturnURL")
        public String AccuReturnURL;

        @JsonProperty("session")
        public String session;

        @JsonProperty("AccuGuid")
        public String AccuGuid;

        @JsonProperty("AccuRequestId")
        public String AccuRequestId;

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("{");
            getStringData("PaReq",PaReq,sb);
            getStringData("TermUrl",TermUrl,sb);
            getStringData("AccuCardholderId",AccuCardholderId,sb);
            getStringData("AccuReturnURL",AccuReturnURL,sb);
            getStringData("session",session,sb);
            getStringData("AccuGuid",AccuGuid,sb);
            sb.append("\"AccuRequestId\":").append(getValueString(AccuRequestId));
            sb.append('}');
            return sb.toString();
        }
    }
}

