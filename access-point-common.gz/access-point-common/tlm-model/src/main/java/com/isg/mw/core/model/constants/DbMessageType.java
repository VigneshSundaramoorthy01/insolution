package com.isg.mw.core.model.constants;

import java.util.ArrayList;
import java.util.List;

public enum DbMessageType {
    INSERT,
    UPDATE,
    IN_REQ,
    IN_RES,
    UP_REQ,
    UP_RES;

    public static final List<String> dbMsgTypeInsertList = new ArrayList<>();
    public static final List<String> dbMsgTypeUpdateList = new ArrayList<>();

    static {
        dbMsgTypeInsertList.add(DbMessageType.IN_REQ.name());
        dbMsgTypeInsertList.add(DbMessageType.IN_RES.name());
        dbMsgTypeUpdateList.add(DbMessageType.UP_REQ.name());
        dbMsgTypeUpdateList.add(DbMessageType.UP_RES.name());
    }


    public static DbMessageType getValue(DbMessageType dbMessageTypeId) {
        switch (dbMessageTypeId) {
            case IN_REQ:
            case IN_RES:
                return DbMessageType.INSERT;
            case UP_REQ:
            case UP_RES:
                return DbMessageType.UPDATE;
        }
        return null;
    }

    public static String getDbMessageTypeString(String key) {
        for (DbMessageType value : DbMessageType.values()) {
            if (value.name().equals(key)) {
                return value.name();
            }
        }
        return null;
    }

    public static DbMessageType getDbMessageType(String key) {
        for (DbMessageType value : DbMessageType.values()) {
            if (value.name().equals(key)) {
                return value;
            }
        }
        return null;
    }
}


