package com.isg.mw.core.model.tlm;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.RouteType;
import com.isg.mw.core.model.constants.StatsType;
import com.isg.mw.core.model.sr.SourceInfoStatistics;
import com.isg.mw.core.model.sr.TargetInfoStatistics;

import com.isg.mw.core.utils.OffsetDateTimeOptionalZoneDeserializer;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author shital3986
 *
 */
@ToString
@Getter
@Setter
@NoArgsConstructor
public class SmartRouteStatisticsModel extends AcpTraceIdModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int totalOffset;
	
	private String entityId;

	private RouteType routeType;
	
	private StatsType statsType;
	
	private Long sourceId;
	
	private SourceInfoStatistics sourceInfoStats;
	
	private List<TargetInfoStatistics> targets;

	@JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
	private OffsetDateTime calculationDate;

	@JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
	private OffsetDateTime createdAt;
}
