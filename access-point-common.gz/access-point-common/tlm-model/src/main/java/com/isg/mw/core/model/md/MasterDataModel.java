package com.isg.mw.core.model.md;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * currency Details details
 * 
 * @author prasad_t026
 *
 */
@Getter
@Setter
public class MasterDataModel implements Serializable {
	
	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * countries list
	 */
	List<CountryModel> countries;
	
	/*
	 * currencies list
	 */
	List<CurrencyModel> currencies;

}
