package com.isg.mw.core.model.lyra;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LyraMerchantRequestModel implements Serializable {

    public Business business;
    public BankDetails bankDetails;
    public Risk risk;
    public List<Pos> pos;
    public Amex amex;


    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Business implements Serializable{
        public String name;
        public String dbaName;
        public String integrationType;
        public String dateOfEstablishment;
        public String address;
        public String city;
        public String state;
        public String zipcode;
        public String country;
        public String ownership;
        public String salesPerson;
        public String gstNo;
        public String panNo;
        public String mcc;
        public String mid;
        public String tid;
//        public String registrationId;
        public Contact contact;
        public String websiteUrl = "https://www.onboard.com/";
        public String masterMerchant;
//        public String remarks;
        public String createdBy;
        public String updatedBy;
    }

    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Contact implements Serializable{
//        public String designation;
        public String name;
        public List<String> phone;
        public String email;
    }

    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class BankDetails implements Serializable{
        public String ifsc;
        public String bankName;
        public String accountName;
        public String accountNo;
        public String accountType;
    }

    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Risk implements Serializable{
        public String avgTicketSize;
        public String txCap;
        public String dailyCap;
        public String dailyCount;
    }

    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Pos implements Serializable {
        public String terminalType;
        public String terminalModel;
        public String deviceSerialNo;
        public String valueAddedService;
        public String mid;
        public String tid;
        public String vpa;
    }

    @Getter
    @Setter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Amex implements Serializable {
        public String seNumber;
        public String sellerId;
        public String authorizedSignerFirstName;
        public String authorizedSignerLastName;
        public String authorizedSignerDateOfBirth;
    }
}

