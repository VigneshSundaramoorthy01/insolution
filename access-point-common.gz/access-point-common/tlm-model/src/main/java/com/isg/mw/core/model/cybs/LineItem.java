package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class LineItem implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String productCode;
    private String productName;
    private String productSku;
    private String quantity;
    private String unitPrice;
    private String unitOfMeasure;
    private String totalAmount;
    private String taxAmount;
    private String taxRate;
    private String taxAppliedAfterDiscount;
    private String taxStatusIndicator;
    private String taxTypeCode;
    private String amountIncludesTax;
    private String typeOfSupply;
    private String commodityCode;
    private String discountAmount;
    private String discountApplied;
    private String discountRate;
    private String invoiceNumber;
    private List<TaxDetail> taxDetails;
    private String fulfillmentType;
    private String weight;
    private String weightIdentifier;
    private String weightUnit;
    private String referenceDataCode;
    private String referenceDataNumber;
    private String productDescription;
    private String giftCardCurrency;
    private String shippingDestinationTypes;
    private String gift;
    private Passenger passenger;
}
