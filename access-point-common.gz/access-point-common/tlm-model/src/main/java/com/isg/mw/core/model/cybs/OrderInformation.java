package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class OrderInformation implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private AmountDetail amountDetails;
    private BillTo billTo;
    private ShipTo shipTo;
    private List<LineItem> lineItems;
    private InvoiceDetails invoiceDetails;
    private ShippingDetails shippingDetails;
    private boolean returnsAccepted;
    private String preOrder;
    private String preOrderDate;
    private boolean reordered;
    private String totalOffersCount;
}