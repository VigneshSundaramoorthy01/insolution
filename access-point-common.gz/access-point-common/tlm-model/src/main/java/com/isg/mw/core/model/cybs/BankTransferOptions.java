package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BankTransferOptions implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String declineAvsFlags;
    private String secCode;
    private String terminalCity;
    private String terminalState;
    private String effectiveDate;
    private String partialPaymentId;
    private String customerMemo;
    private String paymentCategoryCode;
    private String settlementMethod;
    private String fraudScreeningLevel;
    private String customerPresent;
}
