package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class RecurringPaymentInformation implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String endDate;
    private String frequency;
    private String numberOfPayments;
    private String originalPurchaseDate;
    private String sequenceNumber;
}