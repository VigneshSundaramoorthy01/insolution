package com.isg.mw.core.model.hitachi;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class HitachiMerchantResponseModel  implements Serializable {

    @JsonProperty("ResponseCode")
    public String responseCode;

    @JsonProperty("ResponseMessage")
    public String responseMessage;


    public String resMessage;
}
