package com.isg.mw.core.model.constants;

/**
 * @author prasad_t026
 */
public enum TransactionCategory {

	SIGNON, 
	
	HEARTBEAT, 
	
	NORMAL, 
	
	VOID_REVERSAL, 
	
	BATCH,

	DYNAMIC_KEY_EXCHANGE,
	
	SIGNOFF,

	CUTOVER,

	HOST_SESSION_ACTIVATION,

	DYNAMIC_KEY_EXCHANGE_SIGNOFF,
	
	HOST_SESSION_DEACTIVATION;
	
	/**
	 * converts String object to TransactionCategory constant
	 * 
	 * @param name - name of the TransactionCategory
	 * @return - TransactionCategory Enum constant
	 */
	public static TransactionCategory getTransacionCategory(String name) {
		
		if (SIGNON.name().equals(name)) {
			return SIGNON;
		} else if (HEARTBEAT.name().equals(name)) {
			return HEARTBEAT;
		} else if (NORMAL.name().equals(name)) {
			return NORMAL;
		} else if (VOID_REVERSAL.name().equals(name)) {
			return VOID_REVERSAL;
		} else if (BATCH.name().equals(name)) {
			return BATCH;
		} else if (DYNAMIC_KEY_EXCHANGE.name().equals(name)) {
			return DYNAMIC_KEY_EXCHANGE;
		} else if (SIGNOFF.name().equals(name)) {
			return SIGNOFF;
		}else if (CUTOVER.name().equals(name)) {
			return CUTOVER;
		} else if(HOST_SESSION_ACTIVATION.name().equals(name)) {
			return HOST_SESSION_ACTIVATION;
		} else if(HOST_SESSION_DEACTIVATION.name().equals(name)) {
			return HOST_SESSION_DEACTIVATION;
		}else if(DYNAMIC_KEY_EXCHANGE_SIGNOFF.name().equals(name)) {
			return DYNAMIC_KEY_EXCHANGE_SIGNOFF;
		}
		return null;
		
	}


}
