package com.isg.mw.core.model.sr;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.isg.mw.core.utils.CoreUtils.round;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SourceInfoStatistics implements Serializable {

    private String sourceName;

    private Double tps;

    private Double successRatioThreshold;

    private SourceInfo sourceInfo;

    public void setTps(Double tps) {
        this.tps = round(tps);
    }
}
