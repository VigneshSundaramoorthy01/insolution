package com.isg.mw.core.model.tpsl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class TpslCheckTxnStatusResponseModel implements Serializable {

        public String merchantCode;
        public String merchantTransactionIdentifier;
        public String merchantTransactionRequestType;
        public String responseType;
        public String transactionState;
        public PaymentMethod paymentMethod;

        @Getter
        @Setter
    public static class PaymentMethod implements Serializable{
        public String token;
        public String instrumentAliasName;
        public String instrumentToken;
        public String bankSelectionCode;
        public ACS aCS;
        public OTP oTP;
        public PaymentTransaction paymentTransaction;
        public Authentication authentication;
        public Error error;
    }

    @Getter
    @Setter
    public static class ACS implements Serializable{
        public String bankAcsFormName;
        public String bankAcsHttpMethod;
        public List<Object> bankAcsParams;
        public String bankAcsUrl;
    }

    @Getter
    @Setter
    public static class OTP implements Serializable{
        public String initiator;
        public String message;
        public String numberOfDigit;
        public String target;
        public String type;
    }

    @Getter
    @Setter
    public static class Authentication implements Serializable{
        public String type;
        public String subType;
    }

    @Getter
    @Setter
    public static class PaymentTransaction implements Serializable{
        public String amount;
        public String balanceAmount;
        public String bankReferenceIdentifier;
        public String dateTime;
        public String errorMessage;
        public String identifier;
        public String refundIdentifier;
        public String statusCode;
        public String statusMessage;
        public Instruction instruction;
    }
    @Getter
    @Setter
    public static class Instruction implements Serializable{
        public String id;
        public String statusCode;
        public String errorcode;
        public String errordesc;
    }
}
