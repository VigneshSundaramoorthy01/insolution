package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class InstallmentInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String amount;
    private String frequency;
    private String planType;
    private String sequence;
    private String totalAmount;
    private String totalCount;
    private String firstInstallmentDate;
    private String invoiceData;
    private String paymentType;
    private String eligibilityInquiry;
    private String gracePeriodDuration;
    private String gracePeriodDurationType;
    private String firstInstallmentAmount;
    private String validationIndicator;
    private String identifier;
}