package com.isg.mw.core.model.sr;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Targets implements Serializable{


	private List<Target> targets;
}


