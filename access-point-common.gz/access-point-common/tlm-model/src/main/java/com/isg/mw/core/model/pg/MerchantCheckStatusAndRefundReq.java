package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantCheckStatusAndRefundReq extends CommonMerchantPayReq{

    @JsonProperty("PassCode")
    private String passCode;
    /*
       Refund Status Request:
       {
	    "BankId": "24520",
	    "MerchantId": "10000012345",
	    "PassCode": "TSFC9767",
	    "SecureHash": "B8CAB46E036927B9D506439BB889D56FF2220960FD218E93A8D4BC91E6930C29",
	    "TerminalId": "1000001",
	    "TxnRefNo": "1699888114305",
	    "TxnType": "Refund"
     }
     */
    @JsonProperty("MCC")
    private String mcc;

    /*
     Refund Request:
    {
	"BankId": "24520",
	"MerchantId": "10000012345",
	"PassCode": "TSFC9767",
	"RefCancelId": "1699888114305",
	"RefundAmount": "100",
	"RetRefNo": "139186379439781421",
	"SecureHash": "F00BA6F24579C18AE414F2BD115E1A46F501B5ACD77B2A21CB260912E9DB5985",
	"TerminalId": "1000001",
	"TxnRefNo": "1699888114305",
	"TxnType": "Refund"
    }
     */
    @JsonProperty("RefundAmount")
    private String refundAmount;

    @JsonProperty("RetRefNo")
    private String retRefNo;

    @JsonProperty("AuthCode")
    private String authCode;

    @JsonProperty("RefCancelId")
    private String refCancelId;

    @Override
    public String toString() {
        return "MerchantCheckStatusAndRefundReq{" +
                "passCode='" + passCode + '\'' +
                ", mcc='" + mcc + '\'' +
                ", refundAmount='" + refundAmount + '\'' +
                ", retRefNo='" + retRefNo + '\'' +
                ", authCode='" + authCode + '\'' +
                ", refCancelId='" + refCancelId + '\'' +
                "} " + super.toString();
    }
}
