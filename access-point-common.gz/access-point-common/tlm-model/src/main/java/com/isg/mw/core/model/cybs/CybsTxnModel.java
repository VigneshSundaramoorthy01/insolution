package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class CybsTxnModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ClientReferenceInformation clientReferenceInformation;
    private ProcessingInformation processingInformation;
    private IssuerInformation issuerInformation;
    private PaymentInformation paymentInformation;
    private OrderInformation orderInformation;
    private BuyerInformation buyerInformation;
    private RecipientInformation recipientInformation;
    private DeviceInformation deviceInformation;
    private MerchantInformation merchantInformation;
    private AggregatorInformation aggregatorInformation;
    private ConsumerAuthenticationInformation consumerAuthenticationInformation;
    private PointOfSaleInformation pointOfSaleInformation;
    private List<MerchantDefinedInformation> merchantDefinedInformation;
    private InstallmentInformation installmentInformation;
    private TravelInformation travelInformation;
    private HealthCareInformation healthCareInformation;
    private PromotionInformation promotionInformation;
    private TokenInformation tokenInformation;
    private RiskInformation riskInformation;
    private AcquirerInformation acquirerInformation;
    public RecurringPaymentInformation recurringPaymentInformation;
    
}
