package com.isg.mw.core.model.hitachi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class HitachiMerchantRequestModel implements Serializable {
    public String mid;
    public String tid;
    @JsonProperty("bank_emi_flag")
    public String bankEemiFlag;
    @JsonProperty("cc_emi_flag")
    public String ccEmiFlag;
    @JsonProperty("dc_emi_flag")
    public String dcEmiFlag;
    @JsonProperty("brand_emi_flag")
    public String brandEmiFlag;
    @JsonProperty("brand_cc_emi_flag")
    public String brandCcEmiFlag;
    @JsonProperty("brand_dc_emi_flag")
    public String brandDcEmiFlag;
    @JsonProperty("KYC_flag")
    public String kycFlag;
    @JsonProperty("mcc_code")
    public String mccCode;
    @JsonProperty("mcc_desc")
    public String mccDesc;
    public String pincode;
    public String state;
    public String city;
    @JsonProperty("sponsor_bank_code")
    public String sponsorBankCode;
    @JsonProperty("GST")
    public String gst;
    @JsonProperty("aggregator_code")
    public String aggregatorCode;
    @JsonProperty("PAN")
    public String pan;
    public String status;
    @JsonProperty("acq_bank")
    public String acqBank;
    @JsonProperty("req_timestamp")
    public String reqTimestamp;
    public String src;
    @JsonProperty("Merchant_Name")
    public String merchantName;
    @JsonProperty("Email_Id")
    public String emailId;
    @JsonProperty("Mobile_No")
    public String mobileNo;
    @JsonProperty("Operation")
    public String operation;
    @JsonProperty("terminaltype")
    public String terminalType;
    @JsonProperty("terminalmodel")
    public String terminalModel;

}
