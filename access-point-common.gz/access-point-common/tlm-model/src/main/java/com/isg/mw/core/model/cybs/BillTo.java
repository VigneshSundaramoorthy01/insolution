package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BillTo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName;
    private String lastName;
    private String middleName;
    private String nameSuffix;
    private String title;
    private Company company;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String locality;
    private String administrativeArea;
    private String postalCode;
    private String country;
    private String district;
    private String buildingNumber;
    private String email;
    private String emailDomain;
    private String phoneNumber;
    private String phoneType;
}
