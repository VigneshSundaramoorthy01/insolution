package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class Leg implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String carrierCode;
    private String flightNumber;
    private String originatingAirportCode;
    @JsonProperty("class") 
    private String myclass;
    private String stopoverIndicator;
    private String departureDate;
    private String destinationAirportCode;
    private String fareBasis;
    private String departTaxAmount;
    private String conjunctionTicket;
    private String exchangeTicketNumber;
    private String couponNumber;
    private String departureTime;
    private String departureTimeMeridian;
    private String arrivalTime;
    private String arrivalTimeMeridian;
    private String endorsementsRestrictions;
    private String totalFareAmount;
    private String feeAmount;
    private String taxAmount;
}