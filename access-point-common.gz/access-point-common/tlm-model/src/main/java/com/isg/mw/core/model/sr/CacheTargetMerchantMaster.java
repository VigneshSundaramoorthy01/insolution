package com.isg.mw.core.model.sr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class CacheTargetMerchantMaster implements Serializable {

    private String targetMid;
    private String merchantVpa;
    private String key;
    private String salt;
    private String status;
    private String prodApiKey;
    private String testApiKey;
    private String dpdId;
}
