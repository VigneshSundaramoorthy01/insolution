package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CaptureOptions implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String captureSequenceNumber;
    private String totalCaptureCount;
    private String dateToCapture;
}
