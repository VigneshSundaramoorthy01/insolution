package com.isg.mw.core.model.tlm;

import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Basic model of the Transaction Message All transaction messages
 * (Request/Response) are converted to this model
 *
 * @author vidyas
 */

@NoArgsConstructor
public abstract class BaseTmmEntity<T> extends TransactionMessageModel implements Serializable, ITmmEntity {
    public T toEntity() {
        throw new RuntimeException("Undefined implementation of method toEntity()");
    }
}

