package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class BuyerInformation implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String merchantCustomerId;
	private String dateOfBirth;
	private String vatRegistrationNumber;
	private String companyTaxId;
	private List<PersonalIdentification> personalIdentification;
	private String hashedPassword;
	private String mobilePhone;
}