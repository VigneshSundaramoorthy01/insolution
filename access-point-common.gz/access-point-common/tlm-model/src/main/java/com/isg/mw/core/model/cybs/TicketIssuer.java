package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TicketIssuer implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code;
    private String name;
    private String address;
    private String locality;
    private String administrativeArea;
    private String postalCode;
    private String country;
}
