package com.isg.mw.core.model.construct.rupay;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum RupayMsgType implements IMsgType {
	SignOnRequest("0800",null),
	SignOnResponse("0810",null),
    PurchaseRequest("0100", "00"),
    PurchaseResponse("0110", "00"),
    CashWithdrawalRequest("0100", "01"),
    CashWithdrawalResponse("0110", "01"),
    CashAtPosRequest("0100", "01"),
    CashAtPosResponse("0110", "01"),
    PurCashAtPosRequest("0100","09"),
    PurCashAtPosResponse("0110","09"),
    MotoRequest("0100", "00"),
    MotoResponse("0110", "00"),
    PreAuthRequest("0100", "00"),
    PreAuthResponse("0110", "00"),
    RefundRequest("0100", "20"),
    RefundResponse("0110", "20"),
    BalanceEnqRequest("0100", "31"),
    BalanceEnqResponse("0110", "31"),
    ReversalRequest("0420",null),
    ReversalResponse("0430",null),
    VoidRequest("0420", null),
    VoidResponse("0430", null),
	TipAdjustRequest("0220","50"),
	TipAdjustResponse("0230","50"),
	PreAuthCompletionRequest("0220","40"),
	PreAuthCompletionResponse("0230","40"),
	OfflineRequest("0220","00"),
	OfflineResponse("0230","00"),
	MasterCardCashbackRequest("0200","09"),
	BatchSettlementRequest("0500","92"),
	SettlementAfterBatchUploadRequest("0500","96"),
	BatchUploadRequest("0320",null);

    public final String msgType;
    public final String msgSubType;

    private RupayMsgType(String m, String ms ) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals (String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }
}
