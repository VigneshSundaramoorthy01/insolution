package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Passenger implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String type;
    private String status;
    private String phone;
    private String firstName;
    private String lastName;
    private String id;
    private String email;
    private String nationality;
}
