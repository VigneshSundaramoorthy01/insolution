package com.isg.mw.core.model.construct.amex;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum AmexMsgType implements IMsgType {
    RefundRequest("1100", "20"),
    RefundResponse("1110", "20"),
    SignOnRequest("1804", null),
    SignOnResponse("1814", null),
    AuthRequest("1100", "00"),
    AuthResponse("1110", "00"),
    ReversalResponse("1430", "00"),
    PurchaseAavRequest("1100", "21"),
    RefundAavRequest("1100", "23"),
    AavRequest("1100", "22");

    public final String msgType;
    public final String msgSubType;

    private AmexMsgType(String m, String ms) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals(String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }
}
