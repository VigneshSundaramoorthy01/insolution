package com.isg.mw.core.model.constants;

public enum TxnDataType {

	SETTLED,

	UNSETTLED,

	UNSETTLED_SETTLED;

	private static final String unsettledDbTxnDataType = "0";
	private static final String settledDbTxnDataType = "1";
	
	
	public static String getDbTxnDataType(String name) {
		String retVal = null;
		if (SETTLED.name().equals(name)) {
			retVal = settledDbTxnDataType;
		} else if (UNSETTLED.name().equals(name)) {
			retVal = unsettledDbTxnDataType;
		}
		return retVal;
	}
	
	public static TxnDataType getTxnDataType(String name) {
		if (SETTLED.name().equals(name)) {
			return SETTLED;
		} else if (UNSETTLED.name().equals(name)) {
			return UNSETTLED;
		} else if (UNSETTLED_SETTLED.name().equals(name)) {
			return UNSETTLED_SETTLED;
		}
		return null;
	}
}