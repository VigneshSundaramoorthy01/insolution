package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.utils.DateFormatUtils;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.OffsetDateTime;

@Getter
@Setter
public class MerchantEncDataResponse extends CommonMerchantEncReqRes {


    @JsonProperty("MaskedCardNumber")
    private String maskedCardNumber;

    @JsonProperty("ResponseCode")
    private String responseCode;

    @JsonProperty("Message")
    private String message;

    @JsonProperty("RetRefNo")
    private String retRefNo;

    @JsonProperty("AuthCode")
    private String authCode;

    @JsonProperty("CardTokenResponseCode")
    private String cardTokenResponseCode;

    @JsonProperty("CardTokenResponseMessage")
    private String cardTokenResponseMessage;

    @JsonProperty("UCAP")
    private String ucap;

    @JsonProperty("CAVV")
    private String cavv;

    @JsonProperty("ENROLLED")
    private String enrolled;

    @JsonProperty("AuthStatus")
    private String authStatus;

    //NEW RES DATA
    @JsonProperty("TxnType")
    private String txnType;

    @JsonProperty("BatchNo")
    private String batchNo;

    @JsonProperty("pgTxnId")
    private String pgTxnId;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("RefundAmount")
    private String refundAmount;

    @JsonProperty("RefCancelId")
    private String refCancelId;

    @JsonProperty("AccessCode")
    private String accessCode;

    @JsonProperty("RupayTranId")
    private String rupayTranId;

    @JsonProperty("Command")
    private String command;

    @JsonProperty("RespDate")
    private String respDate;

    @JsonProperty("RespTime")
    private String respTime;

    public void setRespDate(OffsetDateTime respDate) {
        if(respDate == null){
            respDate = OffsetDateTime.now();
        }
        this.respDate = DateFormatUtils.getISODateOrTime(respDate,"dd-MM-yyyy");
    }

    public void setRespTime(OffsetDateTime respTime) {
        if(respTime == null){
            respTime = OffsetDateTime.now();
        }
        this.respTime = DateFormatUtils.getISODateOrTime(respTime,"HH:mm");;
    }

    @Override
    public String toString() {
        return "MerchantEncDataResponse [" +
                ", maskedCardNumber='" + maskedCardNumber + '\'' +
                ", responseCode='" + responseCode + '\'' +
                ", message='" + message + '\'' +
                ", retRefNo='" + retRefNo + '\'' +
                ", authCode='" + authCode + '\'' +
                ", cardTokenResponseCode='" + cardTokenResponseCode + '\'' +
                ", cardTokenResponseMessage='" + cardTokenResponseMessage + '\'' +
                ", ucap='" + ucap + '\'' +
                ", cavv='" + cavv + '\'' +
                ", enrolled='" + enrolled + '\'' +
                ", authStatus='" + authStatus + '\'' +
                ", txnType='" + txnType + '\'' +
                ", batchNo='" + batchNo + '\'' +
                ", pgTxnId='" + pgTxnId + '\'' +
                ", status='" + status + '\'' +
                ", refundAmount='" + refundAmount + '\'' +
                ", refCancelId='" + refCancelId + '\'' +
                ", accessCode='" + accessCode + '\''+
                ", rupayTranId='" + rupayTranId + '\''+
                ", command='" + command + '\''+
                ", respDate='" + respDate + '\''+
                ", respTime='" + respTime + '\''+
                ","+ super.toString();
    }

    public MerchantEncDataResponse getMerchantRefundDataRes(MerchantEncDataRequest req){
        MerchantEncDataResponse res = new MerchantEncDataResponse();
        res.setBankId(req.getBankId());
        res.setMerchantId(req.getMerchantId());
        res.setTerminalId(req.getTerminalId());
        res.setTxnRefNo(req.getTxnRefNo());
        res.setPassCode(req.getPassCode());
        res.setTxnType(req.getTxnType());
        res.setRefundAmount(req.getRefundAmount());
        res.setRetRefNo(req.getRetRefNo());
        res.setAuthCode(req.getAuthCode());
        res.setRefCancelId(req.getRefCancelId());
        res.setSecureHash(req.getSecureHash());
        return res;
    }

    public MerchantEncDataResponse getMerchantTxnStatusDataRes(MerchantEncDataRequest req){
        MerchantEncDataResponse res = new MerchantEncDataResponse();
        res.setBankId(req.getBankId());
        res.setMerchantId(req.getMerchantId());
        res.setTerminalId(req.getTerminalId());
        res.setTxnRefNo(req.getTxnRefNo());
        res.setPassCode(req.getPassCode());
        res.setTxnType(req.getTxnType());
        res.setMcc(req.getMcc());
        res.setSecureHash(req.getSecureHash());
        return res;
    }

    public MerchantEncDataResponse getMerchantDataRes(MerchantEncDataRequest merchantEncDataRequest) {
        MerchantEncDataResponse res = new MerchantEncDataResponse();
        res.setBankId(merchantEncDataRequest.getBankId());
        res.setMerchantId(merchantEncDataRequest.getMerchantId());
        res.setTerminalId(merchantEncDataRequest.getTerminalId());
        res.setTxnRefNo(merchantEncDataRequest.getTxnRefNo());
        res.setMcc(merchantEncDataRequest.getMcc());
        res.setPassCode(merchantEncDataRequest.getPassCode());
        res.setCurrency(merchantEncDataRequest.getCurrency());
        res.setAmount(merchantEncDataRequest.getAmount());
        res.setOrderInfo(merchantEncDataRequest.getOrderInfo());
        res.setPayOpt(merchantEncDataRequest.getPayOpt());
        res.setFirstName(merchantEncDataRequest.getFirstName());
        res.setLastName(merchantEncDataRequest.getLastName());
        res.setStreet(merchantEncDataRequest.getStreet());
        res.setCity(merchantEncDataRequest.getCity());
        res.setState(merchantEncDataRequest.getState());
        res.setZip(merchantEncDataRequest.getZip());
        res.setEmail(merchantEncDataRequest.getEmail());
        res.setPhone(merchantEncDataRequest.getPhone());
        res.setUdf01(merchantEncDataRequest.getUdf01());
        res.setUdf02(merchantEncDataRequest.getUdf02());
        res.setUdf03(merchantEncDataRequest.getUdf03());
        res.setUdf04(merchantEncDataRequest.getUdf04());
        res.setUdf05(merchantEncDataRequest.getUdf05());
        res.setUdf06(merchantEncDataRequest.getUdf06());
        res.setUdf07(merchantEncDataRequest.getUdf07());
        res.setUdf08(merchantEncDataRequest.getUdf08());
        res.setUdf09(merchantEncDataRequest.getUdf09());
        res.setUdf10(merchantEncDataRequest.getUdf10());
        res.setChUserID(merchantEncDataRequest.getChUserID());
        res.setCardTokenReferenceNo(merchantEncDataRequest.getCardTokenReferenceNo());
        res.setSecureHash(merchantEncDataRequest.getSecureHash());
        res.setVersion(merchantEncDataRequest.getVersion());
        return res;
    }


}
