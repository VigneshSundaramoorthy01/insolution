package com.isg.mw.core.model.tlm;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.model.common.AcpTraceIdModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class SmartRoutePostTransactionMessageModel implements Serializable {
    /**
     * Default serialized version ID
     */
    private static final long serialVersionUID = 1L;

    private String transactionId;

    private String retrievalRefNo;

    private String originalTransactionId;

    private String originalRetrievalRefNo;

    private String targetTransactionId;

    private transient String pan;

    private String cardAcceptorId;

    private String cardAcceptorTerminalId;

    private String cardType;

    private String txnCurrencyCode;

    private String txnAmt;

    private String requestReceivedTime;

    private String responseSentTime;

    private String resCode;

    private String messageType;

    private String messageTypeId;

    private String transactionName;

    private String posEntryMode;

    private String posConditionCode;

    private String authIdRes;

    private String terminalBatchNo;

    private String hostBatchNo;

    private String invoiceNo;

    private String terminalStan;

    private String schemeStan;

    private String batchStatus;

    private String merchantType;

    private String cardAcceptorInfo;

    private String acquirerCountryCode;

    private String acquirerIdCode;

    private String forwardingInstIdCode;

    private String source;

    private String target;

    private String drcrFlag;

    private String cardHolderBillingAmt;

    private String cardHolderBillingConversionRate;

    private String cardHolderBillingCurrencyCode;

    private String conversionDate;

    private String entityId;

    private String maskedTransactionId;

    private String hashedTransactionId;

    private String createdAt;

    private String paymentModeId;

    private String paymentModeOptionId;

    private String targetMid;

    private String mobileNo;

    private String email;

    private String netPromoterScore;

    private String firstName;

    private String lastName;

    private String street;

    private String city;

    private String state;

    @JsonProperty("ZIP")
    private String ZIP;

    @JsonProperty("UDF01")
    private String UDF01;

    @JsonProperty("UDF02")
    private String UDF02;

    @JsonProperty("UDF03")
    private String UDF03;

    @JsonProperty("UDF04")
    private String UDF04;

    @JsonProperty("UDF05")
    private String UDF05;

    @JsonProperty("UDF06")
    private String UDF06;

    @JsonProperty("UDF07")
    private String UDF07;

    @JsonProperty("UDF08")
    private String UDF08;

    @JsonProperty("UDF09")
    private String UDF09;

    @JsonProperty("UDF10")
    private String UDF10;

    private String domint;

    private String cardInfo;

    private String browserName;

    private String browserVersion;

    private String osName;

    @JsonProperty("cGst")
    private String cgst;

    @JsonProperty("iGst")
    private String igst;

    @JsonProperty("sGst")
    private String sgst;

    private String convenienceFee;

    private String reasonCode;

    private String errorDescription;

    private String customerRemarks;


}
