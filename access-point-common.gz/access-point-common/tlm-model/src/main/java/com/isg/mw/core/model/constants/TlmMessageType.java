/**
 * 
 */
package com.isg.mw.core.model.constants;

/**
 * Transaction Message request types 
 * 
 * @author prasad_t026
 *
 */
public enum TlmMessageType {

	REQUEST,
	
	RESPONSE;
	
}
