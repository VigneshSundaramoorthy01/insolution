package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.isg.mw.core.model.tlm.TransactionMessageModel;
import com.isg.mw.core.utils.DateFormatUtils;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
@Data
public class MerchantPayAndRefundStatusRes extends CommonMerchantPayReq{

    /*
    Comman status sale and refund status
     */
    @JsonProperty("Message")
    private String message;

    @JsonProperty("RetRefNo")
    private String retRefNo;

    /*
    sale status
     */
    @JsonProperty("ResponseCode")
    private String responseCode;

    @JsonProperty("AuthCode")
    private String authCode;

    @JsonProperty("amount")
    private String Amount;

    @JsonProperty("BatchNo")
    private String batchNo;

    @JsonProperty("AuthStatus")
    private String authStatus;

    @JsonProperty("Cavv")
    private String cavv;

    @JsonProperty("Enrolled")
    private String enrolled;

    @JsonProperty("Ucap")
    private String ucap;

    @JsonProperty("pgTxnId")
    private String pgTxnId;

    @JsonProperty("UDF01")
    private String udf01;

    @JsonProperty("UDF02")
    private String udf02;

    @JsonProperty("UDF03")
    private String udf03;

    @JsonProperty("UDF04")
    private String udf04;

    @JsonProperty("UDF05")
    private String udf05;

    @JsonProperty("UDF06")
    private String udf06;

    @JsonProperty("UDF07")
    private String udf07;

    @JsonProperty("UDF08")
    private String udf08;

    @JsonProperty("UDF09")
    private String udf09;

    @JsonProperty("UDF10")
    private String udf10;

    /*
    Refund Status
     */
    @JsonProperty("Status")
    private String status;

    @JsonProperty("AccessCode")
    private String accessCode;

    @JsonProperty("RefundAmount")
    private String refundAmount;

    @JsonProperty("MaskedCardNumber")
    private String maskedCardNumber;

    @JsonProperty("RefCancelId")
    private String refCancelId;

    @JsonProperty("RespDate")
    private String respDate;

    @JsonProperty("RespTime")
    private String respTime;

    public void setRespDate(OffsetDateTime respDate) {
        if(respDate == null){
            respDate = OffsetDateTime.now();
        }
        this.respDate = DateFormatUtils.getISODateOrTime(respDate,"dd-MM-yyyy");
    }

    public void setRespTime(OffsetDateTime respTime) {
        if(respTime == null){
            respTime = OffsetDateTime.now();
        }
        this.respTime = DateFormatUtils.getISODateOrTime(respTime,"HH:mm");;
    }

    @Override
    public String toString() {
        return "MerchantPayAndRefundStatusRes{" +
                "message='" + message + '\'' +
                ", retRefNo='" + retRefNo + '\'' +
                ", responseCode='" + responseCode + '\'' +
                ", authCode='" + authCode + '\'' +
                ", Amount='" + Amount + '\'' +
                ", batchNo='" + batchNo + '\'' +
                ", authStatus='" + authStatus + '\'' +
                ", cavv='" + cavv + '\'' +
                ", enrolled='" + enrolled + '\'' +
                ", ucap='" + ucap + '\'' +
                ", pgTxnId='" + pgTxnId + '\'' +
                ", udf01='" + udf01 + '\'' +
                ", udf02='" + udf02 + '\'' +
                ", udf03='" + udf03 + '\'' +
                ", udf04='" + udf04 + '\'' +
                ", udf05='" + udf05 + '\'' +
                ", udf06='" + udf06 + '\'' +
                ", udf07='" + udf07 + '\'' +
                ", udf08='" + udf08 + '\'' +
                ", udf09='" + udf09 + '\'' +
                ", udf10='" + udf10 + '\'' +
                ", status='" + status + '\'' +
                ", accessCode='" + accessCode + '\'' +
                ", refundAmount='" + refundAmount + '\'' +
                ", maskedCardNumber='" + maskedCardNumber + '\'' +
                ", refCancelId='" + refCancelId + '\'' +
                ", respDate='" + respDate + '\''+
                ", respTime='" + respTime + '\''+
                "} " + super.toString();
    }

    public MerchantPayAndRefundStatusRes getMerchantTxnPayStatusDataRes(MerchantEncDataRequest req) {
        MerchantPayAndRefundStatusRes res = new MerchantPayAndRefundStatusRes();
        res.setBankId(req.getBankId());
        res.setMerchantId(req.getMerchantId());
        res.setTerminalId(req.getTerminalId());
        res.setTxnRefNo(req.getTxnRefNo());
        res.setTxnType(req.getTxnType());
        res.setSecureHash(req.getSecureHash());
        return res;
    }

    public MerchantPayAndRefundStatusRes getMerchantTxnRefundStatusDataRes(MerchantEncDataRequest req) {
        MerchantPayAndRefundStatusRes res = new MerchantPayAndRefundStatusRes();
        res.setBankId(req.getBankId());
        res.setMerchantId(req.getMerchantId());
        res.setTerminalId(req.getTerminalId());
        res.setTxnRefNo(req.getTxnRefNo());
        res.setTxnType(req.getTxnType());
        res.setSecureHash(req.getSecureHash());
        res.setRefCancelId(req.getRefCancelId());
        return res;
    }

    public void setPayStatusAdditionalData(MerchantPayAndRefundStatusRes res, TransactionMessageModel txnModel,MerchantEncDataRequest encDataRequest) {
        if (txnModel != null) {
            res.setRetRefNo(txnModel.getTransactionId());
            res.setAmount(Integer.valueOf(txnModel.getTxnAmt()).toString());
            res.setUdf01(encDataRequest.getUdf01());
            res.setUdf02(encDataRequest.getUdf02());
            res.setUdf03(encDataRequest.getUdf03());
            res.setUdf04(encDataRequest.getUdf04());
            res.setUdf05(encDataRequest.getUdf05());
            res.setUdf06(encDataRequest.getUdf06());
            res.setUdf07(encDataRequest.getUdf07());
            res.setUdf08(encDataRequest.getUdf08());
            res.setUdf09(encDataRequest.getUdf09());
            res.setUdf10(encDataRequest.getUdf10());
        }
    }

    public void setRefundStatusAdditionalData(MerchantPayAndRefundStatusRes res, TransactionMessageModel txnModel) {
        if (txnModel != null) {
            res.setRetRefNo(txnModel.getTransactionId());
            res.setRefundAmount(Integer.valueOf(txnModel.getTxnAmt()).toString());
            res.setMaskedCardNumber(txnModel.getMaskedPan());
        }
    }
}