package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class ProcessingInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> actionList;
    private List<String> actionTokenTypes;
    private boolean capture;
    private String processorId;
    private String businessApplicationId;
    private String commerceIndicator;
    private String paymentSolution;
    private String reconciliationId;
    private String linkId;
    private String purchaseLevel;
    private String reportGroup;
    private String visaCheckoutId;
    private String industryDataType;
    private AuthorizationOptions authorizationOptions;
    private CaptureOptions captureOptions;
    private RecurringOptions recurringOptions;
    private BankTransferOptions bankTransferOptions;
    private PurchaseOptions purchaseOptions;
    private ElectronicBenefitsTransfer electronicBenefitsTransfer;
    private LoanOptions loanOptions;
    private String walletType;
    private String nationalNetDomesticData;
    private JapanPaymentOptions japanPaymentOptions;
    private String mobileRemotePaymentType;
    private String extendedCreditTotalCount;
    private String networkRoutingOrder;
    private boolean payByPointsIndicator;
}
