package com.isg.mw.core.model.oracle;


import lombok.Data;

@Data
public class InputOracleModel {

    private String mid;
    private Integer txnAmt;
    private String schemeType;
    private String drCrFlag;
    private String ownLoFo;
    private String txnCat;
    private String cardCategory;
    private String network;
    private String txnType;
    private Double cgstAmt;
    private Double sgstAmt;
    private Double igstAmt;
    private Integer curCode;
    private Integer curExp;
    private Double curRate;
    private String bankName;
    private String qrVendor;
    private String wallet;
    private String offlinePaymentMode;

}
