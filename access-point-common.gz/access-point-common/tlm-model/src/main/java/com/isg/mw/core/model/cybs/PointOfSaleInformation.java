package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class PointOfSaleInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String terminalId;
    private String terminalSerialNumber;
    private String laneNumber;
    private String catLevel;
    private String entryMode;
    private String terminalCapability;
    private String operatingEnvironment;
    private Emv emv;
    private String amexCapnData;
    private String trackData;
    private String storeAndForwardIndicator;
    private List<String> cardholderVerificationMethod;
    private List<String> terminalInputCapability;
    private String terminalCardCaptureCapability;
    private String terminalOutputCapability;
    private String terminalPinCapability;
    private String deviceId;
    private String pinBlockEncodingFormat;
    private String encryptedPin;
    private String encryptedKeySerialNumber;
    private String partnerSdkVersion;
    private String emvApplicationIdentifierAndDedicatedFileName;
    private String terminalCompliance;
    private String isDedicatedHardwareTerminal;
    private String terminalModel;
    private String terminalMake;
}
