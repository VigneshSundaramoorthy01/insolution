package com.isg.mw.core.model.oracle;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ResponseModel {

    @JsonProperty(value = "Status")
    private String status;
}
