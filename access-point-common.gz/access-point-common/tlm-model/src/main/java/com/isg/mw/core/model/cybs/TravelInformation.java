package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TravelInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String duration;
    private Agency agency;
    private AutoRental autoRental;
    private Lodging lodging;
    private Transit transit;
}
