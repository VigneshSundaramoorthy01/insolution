package com.isg.mw.core.model.tpsl;

import lombok.Data;

@Data
public class TpslMerchantResponseModel {
    public String UniqueId;
    public String LID;
    public String MerchantName;
    public String Key;
    public String IV;
    public String SchemeCode;
    public String ErrorCode;
    public String ErrorDesc;
    public String CheckSumValue;
    public String AdditionalParameter1;
    public String AdditionalParameter2;
    public String resMessage;
}
