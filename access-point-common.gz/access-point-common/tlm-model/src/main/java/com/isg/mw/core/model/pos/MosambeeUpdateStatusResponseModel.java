package com.isg.mw.core.model.pos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MosambeeUpdateStatusResponseModel {
    private String result;
    private String message;
    private String responseCode;
    private String resMessage;
}
