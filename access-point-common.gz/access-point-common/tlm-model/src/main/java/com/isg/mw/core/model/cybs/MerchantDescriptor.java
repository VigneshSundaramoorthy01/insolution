package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MerchantDescriptor implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
    private String alternateName;
    private String contact;
    private String address1;
    private String locality;
    private String country;
    private String postalCode;
    private String administrativeArea;
    private String phone;
    private String url;
}
