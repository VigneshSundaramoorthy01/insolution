package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class Airline implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bookingReferenceNumber;
    private String carrierName;
    private TicketIssuer ticketIssuer;
    private String ticketNumber;
    private String checkDigit;
    private String restrictedTicketIndicator;
    private String transactionType;
    private String extendedPaymentCode;
    private String passengerName;
    private String customerCode;
    private String documentType;
    private String documentNumber;
    private String documentNumberOfParts;
    private String invoiceNumber;
    private String invoiceDate;
    private String additionalCharges;
    private String totalFeeAmount;
    private String clearingSequence;
    private String clearingCount;
    private String totalClearingAmount;
    private String numberOfPassengers;
    private String reservationSystemCode;
    private String processIdentifier;
    private String ticketIssueDate;
    private boolean electronicTicketIndicator;
    private String originalTicketNumber;
    private String purchaseType;
    private String creditReasonIndicator;
    private String ticketChangeIndicator;
    private String planNumber;
    private String arrivalDate;
    private String restrictedTicketDesciption;
    private String exchangeTicketAmount;
    private String exchangeTicketFeeAmount;
    private String reservationType;
    private String boardingFeeAmount;
    private List<Leg> legs;
    private AncillaryInformation ancillaryInformation;
}
