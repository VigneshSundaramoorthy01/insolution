package com.isg.mw.core.model.construct;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum LyraMsgType implements IMsgType {
    Pay("Pay", null),
    Refund("Refund",null),
    Reversal("Reversal",null);


    public final String msgType;
    public final String msgSubType;

    LyraMsgType(String m, String ms) {
        this.msgType = m;
        this.msgSubType = ms;
    }

    @Override
    public boolean equals(String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
    }
}
