
package com.isg.mw.core.model.pos;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class MosambeeUpdateStatusRequestModel implements Serializable{
    private String refId;
    private String refType;
    private String acquirer;
    private String tg;
    private String instrument;
    private String instrumentCode;
    private String status;
    private String remark;

}
