package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class JapanPaymentOptions implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String paymentMethod;
    private String installments;
    private String terminalId;
    private String firstBillingMonth;
    private String businessName;
    private String businessNameKatakana;
    private String jis2TrackData;
    private String businessNameAlphaNumeric;
}