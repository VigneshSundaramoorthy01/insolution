
package com.isg.mw.core.model.pos;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class MosambeeRequestModel implements Serializable{

    private String merchantName;
    private String isEnterprise;
    private String enterpriseCode;
    private String enterpriseLevel;
    private String enterpiseLevelName;
    private String merchantDba;
    private String mobileNumber;
    private String businessEmail;
    private String spocName;
    private String merchantAddress;
    private String city;
    private String state;
    private String country;
    private String programType;
    private Long businessPin;
    private String mccCode;
    private String isIntegrated;
    private MidRequest midRequest;

    @Data
    public static class MidRequest implements Serializable {
        private String mid;
        private String processingMid;
        private String acquirer;
        private String tg;
        private String instrument;
        private String instrumentCode;
        private String midRef1;
        private String midRef2;
        private String midRef3;
        private List<TidDetail> tidDetails;
    }

    @Data
    public static class TidDetail implements Serializable {
        private String tid;
        private String processingTid;
        private String userName;
        private String tidType;
        private String storeName;
        private String terminalLocation;
        private String posTerminalSupported;
        private String devicePairFlag;
        private String deviceSerialNo;
        private String terminalAuthType;
        private String terminalKeyValue;
        private String terminalSpocName;
        private String terminalContactNo;
        private String terminalEmail;
        private String terminalRef1;
        private String terminalRef2;
        private String terminalRef3;
        private String amexEnable;
    }
}
