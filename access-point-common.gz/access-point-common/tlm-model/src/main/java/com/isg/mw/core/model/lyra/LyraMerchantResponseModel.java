package com.isg.mw.core.model.lyra;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class LyraMerchantResponseModel implements Serializable{

    public Business business;
    public LyraMerchantRequestModel.BankDetails bankDetails;
    public LyraMerchantRequestModel.Risk risk;
    public List<Pos> pos;
    public Shop shop;
    public Poi poi;
    public List<PaymentOption> paymentOption;
    public String resMessage;
    public String message;
    public String causes;


    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Business implements Serializable {
        public String name;
        public String dbaName;
        public String integrationType;
        public String dateOfEstablishment;
        public String address;
        public String city;
        public String state;
        public String zipcode;
        public String country;
        public String ownership;
        public String salesPerson;
        public String gstNo;
        public String panNo;
        public String mcc;
        public String registrationId;
        public LyraMerchantRequestModel.Contact contact;
        public String websiteUrl;
        public String masterMerchant;
        public String mid;
        public String tid;
        public String remarks;
        public String status;
        public String updatedBy;
        public String creationDate;
        public String dsRequesterIds;
        public String tokenRequesterIds;
    }

//    @Getter
//    @Setter
//    @ToString
//    public static class Contact implements Serializable{
//        public String designation;
//        public String name;
//        public List<String> phone;
//        public List<String> email;
//        public String vpa;
//    }

//    @Getter
//    @Setter
//    @ToString
//    public static class BankDetails implements Serializable{
//        public String ifsc;
//        public String bankName;
//        public String accountName;
//        public String accountNo;
//        public String accountType;
//    }

//    @Getter
//    @Setter
//    @ToString
//    public static class Risk implements Serializable{
//        public String avgTicketSize;
//        public String txCap;
//        public String dailyCap;
//        public String dailyCount;
//    }



    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Shop implements Serializable{
        public String shopId;
        public String apiKeyProd;
        public String apiKeyTest;
        public String formKeyProd;
        public String formKeyTest;
    }

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Poi implements Serializable{
        public String type;
        public String gateway;
        public String acquirer;
        public String mid;
        public String tid;
        public String vpa;
        public Object params;
    }

    @Getter
    @Setter
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Pos implements Serializable {
        public String terminalType;
        public String terminalModel;
        public String deviceSerialNo;
        public String valueAddedService;
        public String mid;
        public String tid;
        public String vpa;
    }

    @Getter
    @Setter
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PaymentOption implements Serializable{
        public String type;
        public String gateway;
        public String acquirer;
        public String mid;
        public String tid;
        public String vpa;
        public Object params;
//        public String payApp;
//        public String contractUid;
//        public Object shopId;
    }

    @Getter
    @Setter
    @ToString
    public static class Params{
        public String category;
        public String mcc;
    }

//    public String registrationId;
//    public String merchantName;
//    public String creationDate;
//    public String mid;
//    public String tid;
//    public String status;
//    public String errorCode;
//    public String errorDescription;
//    public Fault fault;
//    public String resMessage;
//
//    @Data
//    public class Fault {
//        public String faultstring;
//        public Detail detail;
//
//        @Data
//        public class Detail {
//            public String errorcode;
//        }
//    }
}
