package com.isg.mw.core.model.construct.rupay;

import com.isg.mw.core.model.msgtype.IMsgTypeHelper;

public final class RupayMsgTypeHelper implements IMsgTypeHelper {

	private RupayMsgTypeHelper() {
	}

	private static boolean equals(RupayMsgType pReq, RupayMsgType pRes, String m, String mt) {
		boolean retVal = false;
		if (mt != null) {
			String pc = mt.substring(0, 2);
			retVal = pReq.equals(m, pc) || pRes.equals(m, pc);
		}
		return retVal;
	}

	/**
	 * Returns true if transaction is Moto Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isMoto(String msgType, String processingCode) {
		return equals(RupayMsgType.MotoRequest, RupayMsgType.MotoResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Purchase Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isPurchase(String msgType, String processingCode) {
		return equals(RupayMsgType.PurchaseRequest, RupayMsgType.PurchaseResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Cash Withdrawal Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isCashWithdrawal(String msgType, String processingCode) {
		return equals(RupayMsgType.CashWithdrawalRequest, RupayMsgType.CashWithdrawalResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Cash At POS Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isCashAtPos(String msgType, String processingCode) {
		return equals(RupayMsgType.CashAtPosRequest, RupayMsgType.CashAtPosResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Pre-Auth Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isPreAuth(String msgType, String processingCode) {
		return equals(RupayMsgType.PreAuthRequest, RupayMsgType.PreAuthResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Refund Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isRefund(String msgType, String processingCode) {
		return equals(RupayMsgType.RefundRequest, RupayMsgType.RefundResponse, msgType, processingCode);

	}

	/**
	 * Returns true if transaction is Balance Enquiry Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType        Transaction Message Type
	 * @param processingCode Transaction Processing Code
	 * @return True/False.
	 */
	public static boolean isBalanceEnquiry(String msgType, String processingCode) {
		return equals(RupayMsgType.BalanceEnqRequest, RupayMsgType.BalanceEnqResponse, msgType, processingCode);
	}

	/**
	 * Returns true if transaction is Balance Enquiry Request/Response Transaction,
	 * false otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isReversalRequest(String msgType) {
		return RupayMsgType.ReversalRequest.msgType.equals(msgType);

	}

	public static boolean isReversalResponse(String msgType) {
		return RupayMsgType.ReversalResponse.msgType.equals(msgType);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isVoidRequest(String msgType, String msgTypeId) {
		return RupayMsgType.VoidRequest.msgType.equals(msgType) && msgTypeId != null
				&& RupayMsgType.VoidRequest.msgSubType.equals(msgTypeId);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isVoidResponse(String msgType) {
		return RupayMsgType.VoidResponse.msgType.equals(msgType);
	}

	public static boolean isSignOnRequest(String msgType) {
		return RupayMsgType.SignOnRequest.msgType.equals(msgType);
	}

	/**
	 * Returns true if transaction is Void Request/Response Transaction, false
	 * otherwise.
	 * 
	 * @param msgType Transaction Message Type
	 * @return True/False.
	 */
	public static boolean isSignOnResponse(String msgType) {
		return RupayMsgType.SignOnResponse.msgType.equals(msgType);
	}

	public static boolean isTipAdjustRequest(String msgType, String msgTypeId) {
		boolean isTipAdjustRequestMsgType = RupayMsgType.TipAdjustRequest.msgType.equals(msgType);
		boolean isTipAdjustRequestMsgTypeId = msgTypeId != null
				&& RupayMsgType.TipAdjustRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustRequestMsgType && isTipAdjustRequestMsgTypeId;
	}

	public static boolean isTipAdjustResponse(String msgType, String msgTypeId) {
		boolean isTipAdjustResponseMsgType = RupayMsgType.TipAdjustResponse.msgType.equals(msgType);
		boolean isTipAdjustResponseMsgTypeId = msgTypeId != null
				&& RupayMsgType.TipAdjustResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isTipAdjustResponseMsgType && isTipAdjustResponseMsgTypeId;
	}

	public static boolean isPreAuthCompletionRequest(String msgType, String msgTypeId) {
		boolean isPreAuthCompRequestMsgType = RupayMsgType.PreAuthCompletionRequest.msgType.equals(msgType);
		boolean isPreAuthRequestMsgTypeId = msgTypeId != null
				&& RupayMsgType.PreAuthCompletionRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompRequestMsgType && isPreAuthRequestMsgTypeId;
	}

	public static boolean isPreAuthCompletionResponse(String msgType, String msgTypeId) {
		boolean isPreAuthCompResponseMsgType = RupayMsgType.PreAuthCompletionResponse.msgType.equals(msgType);
		boolean isPreAuthResponseMsgTypeId = msgTypeId != null
				&& RupayMsgType.PreAuthCompletionResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isPreAuthCompResponseMsgType && isPreAuthResponseMsgTypeId;
	}

	public static boolean isOfflineRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = RupayMsgType.OfflineRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& RupayMsgType.OfflineRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isOfflineResponse(String msgType, String msgTypeId) {
		boolean isOfflineResponseMsgType = RupayMsgType.OfflineResponse.msgType.equals(msgType);
		boolean isOfflineResponseMsgTypeId = msgTypeId != null
				&& RupayMsgType.OfflineResponse.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineResponseMsgType && isOfflineResponseMsgTypeId;
	}

	public static boolean isMasterCardCashbackRequest(String msgType, String msgTypeId) {
		boolean isOfflineRequestMsgType = RupayMsgType.MasterCardCashbackRequest.msgType.equals(msgType);
		boolean isOfflineRequestMsgTypeId = msgTypeId != null
				&& RupayMsgType.MasterCardCashbackRequest.msgSubType.equals(msgTypeId.substring(0, 2));
		return isOfflineRequestMsgType && isOfflineRequestMsgTypeId;
	}

	public static boolean isBatchSettlementRequest(String msgType, String msgTypeId) {
		boolean isBatchSettlementMsgType = RupayMsgType.BatchSettlementRequest.msgType.equals(msgType);
		boolean isBatchSettlementMsgTypeId = msgTypeId != null
				&& (RupayMsgType.BatchSettlementRequest.msgSubType.equals(msgTypeId)
						|| RupayMsgType.SettlementAfterBatchUploadRequest.msgSubType.equals(msgTypeId));
		return isBatchSettlementMsgType && isBatchSettlementMsgTypeId;
	}

	public static boolean isBatchUploadRequest(String msgType) {
		return msgType != null && RupayMsgType.BatchUploadRequest.msgType.equals(msgType);
	}

}
