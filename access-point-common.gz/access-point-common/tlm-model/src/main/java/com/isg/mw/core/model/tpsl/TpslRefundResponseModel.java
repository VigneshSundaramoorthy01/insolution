package com.isg.mw.core.model.tpsl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class TpslRefundResponseModel {

    public String merchantCode;
    public String merchantTransactionIdentifier;
    public String merchantTransactionRequestType;
    public String responseType;
    public String transactionState;
    public String merchantAdditionalDetails;
    public PaymentMethod paymentMethod;
    public String error;
    public String merchantResponseString;

    @Data
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PaymentMethod {
        public String token;
        public String instrumentAliasName;
        public String instrumentToken;
        public String bankSelectionCode;
        public ACS aCS;
        public OTP oTP;
        public PaymentTransaction paymentTransaction;
        public Authentication authentication;
        public Error error;

        @Data
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class ACS {
            public String bankAcsFormName;
            public String bankAcsHttpMethod;
            public List<String> bankAcsParams;
            public String bankAcsUrl;
        }

        @Data
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class OTP {
            public String initiator;
            public String message;
            public String numberOfDigit;
            public String target;
            public String type;
        }

        @Data
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class PaymentTransaction {
            public String amount;
            public String balanceAmount;
            public String bankReferenceIdentifier;
            public String dateTime;
            public String errorMessage;
            public String identifier;
            public String refundIdentifier;
            public String statusCode;
            public String statusMessage;
            public Instruction instruction;
            public String reference;

            @Data
            @ToString
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Instruction {
                public String id;
                public String statusCode;
                public String errorcode;
                public String errordesc;
            }
        }

        @Data
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Authentication {
            public String type;
            public String subType;
        }

        @Data
        @ToString
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Error {
            public String code;
            public String desc;
        }
    }
}
