package com.isg.mw.core.model.constants;

public enum DcfGenerationStatus {

	 INPROGRESS,

    COMPLETED,

    FAILED;

    /**
     * converts String object to DcfGenerationStatus constant
     *
     * @param name - string value of the DcfGenerationStatus
     * @return - DcfGenerationStatus Enum constant
     */
    public static DcfGenerationStatus getDcfGenerationStatus(String name) {

        DcfGenerationStatus dcfGenerationStatus = null;

        for(DcfGenerationStatus obj: DcfGenerationStatus.values()) {
            if(obj.name().equals(name)) {
                dcfGenerationStatus = obj;
                break;
            }
        }
        return dcfGenerationStatus;
    }
}