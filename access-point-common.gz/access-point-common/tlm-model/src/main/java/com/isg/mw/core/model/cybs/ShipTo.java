package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ShipTo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName;
    private String lastName;
    private String address1;
    private String address2;
    private String locality;
    private String administrativeArea;
    private String postalCode;
    private String country;
    private String district;
    private String buildingNumber;
    private String phoneNumber;
    private String company;
    private String destinationTypes;
    private String destinationCode;
    private String method;
}
