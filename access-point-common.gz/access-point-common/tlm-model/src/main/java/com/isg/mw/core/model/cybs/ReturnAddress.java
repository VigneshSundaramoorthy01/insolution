package com.isg.mw.core.model.cybs;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReturnAddress implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String city;
    private String state;
    private String country;
    private String locationId;
    private String location;
}