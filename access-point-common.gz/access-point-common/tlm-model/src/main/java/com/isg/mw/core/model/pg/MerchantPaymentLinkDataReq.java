package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class MerchantPaymentLinkDataReq {

    @JsonProperty("mid")
    private String mid;

    @JsonProperty("tid")
    private String tid;

    @JsonProperty("entityId")
    private String entityId;

    @JsonProperty("txnAmt")
    private String txnAmt;

    @JsonProperty("merchantTxnRefNo")
    private String merchantTxnRefNo;

    @JsonProperty("customerMobNo")
    private String customerMobNo;

    @JsonProperty("customerEmail")
    private String customerEmail;

    @JsonProperty("linkExpiryDate")
    private String linkExpiryDate;

    @JsonProperty("smsEnabled")
    private String smsEnabled;

    @JsonProperty("emailEnabled")
    private String emailEnabled;

    @JsonProperty("secureHash")
    private String secureHash;

    @JsonProperty("udf01")
    private String udf01;

    @JsonProperty("udf02")
    private String udf02;

    @JsonProperty("udf03")
    private String udf03;

    @JsonProperty("udf04")
    private String udf04;

    @JsonProperty("udf05")
    private String udf05;

    @JsonProperty("udf06")
    private String udf06;

    @JsonProperty("udf07")
    private String udf07;

    @JsonProperty("udf08")
    private String udf08;

    @JsonProperty("udf09")
    private String udf09;

    @JsonProperty("udf10")
    private String udf10;


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("MerchantPaymentLinkDataReq{");
        sb.append("mid='").append(mid).append('\'');
        sb.append(", tid='").append(tid).append('\'');
        sb.append(", entityId='").append(entityId).append('\'');
        sb.append(", txnAmt='").append(txnAmt).append('\'');
        sb.append(", merchantTxnRefNo='").append(merchantTxnRefNo).append('\'');
        sb.append(", customerMobNo='").append(customerMobNo).append('\'');
        sb.append(", customerEmail='").append(customerEmail).append('\'');
        sb.append(", linkExpiryDate='").append(linkExpiryDate).append('\'');
        sb.append(", smsEnabled='").append(smsEnabled).append('\'');
        sb.append(", emailEnabled='").append(emailEnabled).append('\'');
        sb.append(", secureHash='").append(secureHash).append('\'');
        sb.append(", udf01='").append(udf01).append('\'');
        sb.append(", udf02='").append(udf02).append('\'');
        sb.append(", udf03='").append(udf03).append('\'');
        sb.append(", udf04='").append(udf04).append('\'');
        sb.append(", udf05='").append(udf05).append('\'');
        sb.append(", udf06='").append(udf06).append('\'');
        sb.append(", udf07='").append(udf07).append('\'');
        sb.append(", udf08='").append(udf08).append('\'');
        sb.append(", udf09='").append(udf09).append('\'');
        sb.append(", udf10='").append(udf10).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
