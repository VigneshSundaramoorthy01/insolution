package com.isg.mw.core.model.tpsl;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TpslMerchantRequestModel {

    public String uniqueId;
    public String merchantName;
    public String merchantSector;
    @JsonProperty("CorporateAddress")
    public String corporateAddress;
    @JsonProperty("CorporateAddressPincode")
    public String corporateAddressPincode;
    @JsonProperty("CorporateAddressCountry")
    public String corporateAddressCountry;
    @JsonProperty("PurposeOfPG")
    public String purposeOfPG;
    @JsonProperty("MerchantPAN")
    public String merchantPAN;
    @JsonProperty("SignatoryPAN")
    public String signatoryPAN;
    @JsonProperty("MerchantGSTNo")
    public String merchantGSTNo;
    @JsonProperty("ContactPerson")
    public String contactPerson;
    @JsonProperty("Telephone")
    public String telephone;
    @JsonProperty("Email")
    public String email;
    @JsonProperty("ExpectedNoOfTransactions")
    public String expectedNoOfTransactions;
    @JsonProperty("AverageTicketSize")
    public String averageTicketSize;
    @JsonProperty("MIDCategory")
    public String midCategory;
    @JsonProperty("LegalRegisteredAddress")
    public String legalRegisteredAddress;
    @JsonProperty("RegisteredAddPincode")
    public String registeredAddPincode;
    @JsonProperty("RegisteredAddCountry")
    public String registeredAddCountry;
    @JsonProperty("EntityType")
    public String entityType;
    @JsonProperty("BusinessType")
    public String businessType;
    @JsonProperty("ProductServices")
    public String productServices;
    @JsonProperty("WebsiteStatus")
    public String websiteStatus;
    @JsonProperty("TermsAndConditions")
    public String termsAndConditions;
    @JsonProperty("PrivacyPolicy")
    public String privacyPolicy;
    @JsonProperty("RefundsAndCancellationPolicy")
    public String refundsAndCancellationPolicy;
    @JsonProperty("ContactDetailsAvailable")
    public String contactDetailsAvailable;
    @JsonProperty("ProductDetailAndPricingStructure")
    public String productDetailAndPricingStructure;
    @JsonProperty("MIDType")
    public String midType;
    @JsonProperty("MerchantURL")
    public String merchantURL;
    public String checkSumValue;

}
