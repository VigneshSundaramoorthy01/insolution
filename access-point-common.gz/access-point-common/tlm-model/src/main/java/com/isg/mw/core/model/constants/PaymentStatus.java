package com.isg.mw.core.model.constants;

public enum PaymentStatus {

    PENDING,

    INITIATED,

    FAILED,

    SUCCESS,

    EXPIRED;

    public static PaymentStatus fromValue(String v) {
        for (PaymentStatus c: PaymentStatus.values()) {
            if (c.name().equals(v)) {
                return c;
            }
        }
        return null;
    }

}
