package com.isg.mw.core.model.cybs;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class AncillaryInformation implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ticketNumber;
    private String passengerName;
    private String connectedTicketNumber;
    private String creditReasonIndicator;
    private List<Service> service;
}

