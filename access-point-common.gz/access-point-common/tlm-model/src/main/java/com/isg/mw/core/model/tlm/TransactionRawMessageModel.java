package com.isg.mw.core.model.tlm;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.MessageFormat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Basic model of the Transaction Raw Message which is used for debug
 * 
 * @author prasad_t026
 *
 */

@Getter
@Setter
@NoArgsConstructor
public class TransactionRawMessageModel extends AcpTraceIdModel implements Serializable {
	/**
	 * Default serialized version ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Primary Key
	 */
	private long id;

	/**
	 * Transaction Id
	 */
	private String transactionId;

	/**
	 * Request Sent Time
	 */
	private LocalDateTime requestTime;

	/**
	 * Source Type
	 */
	private MessageFormat sourceType;

	/**
	 * Merchant / Aggregator Configuration
	 */
	private Long mac;

	/**
	 * Raw Message
	 */
	private byte[] rawMessage;
	
}