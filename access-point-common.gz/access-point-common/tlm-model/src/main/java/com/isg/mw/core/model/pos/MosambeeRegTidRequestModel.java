
package com.isg.mw.core.model.pos;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class MosambeeRegTidRequestModel implements Serializable{

    private String midRefId;
    private String mid;
    private String instrumentCode;
    private String acquirer;
    private String tg;
    private String instrument;
    private List<TidDetail> tidDetails;

    @Data
    public static class TidDetail implements Serializable {
        private String tid;
        private String processingTid;
        private String userName;
        private String tidType;
        private String storeName;
        private String terminalLocation;
        private String posTerminalSupported;
        private String devicePairFlag;
        private String deviceSerialNo;
        private String terminalAuthType;
        private String terminalKeyValue;
        private String terminalSpocName;
        private String terminalContactNo;
        private String terminalEmail;
        private String terminalRef1;
        private String terminalRef2;
        private String terminalRef3;
        private String amexEnable;
    }
}
