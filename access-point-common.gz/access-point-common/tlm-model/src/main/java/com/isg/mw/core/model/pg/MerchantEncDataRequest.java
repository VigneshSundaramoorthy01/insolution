package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
public class MerchantEncDataRequest extends CommonMerchantEncReqRes {

    @JsonProperty("TxnType")
    private String txnType;

    @JsonProperty("CardNumber")
    private String cardNumber;

    @JsonProperty("ExpiryDate")
    private String expiryDate;

    @JsonProperty("CardSecurityCode")
    private String cardSecurityCode;

    @JsonProperty("ReturnURL")
    private String returnURL;

    @JsonProperty("BankCode")
    private String bankCode;

    @JsonProperty("chTokenizationConsent")
    private String chTokenizationConsent;

    @JsonProperty("CardTokenPan")
    private String cardTokenPan;

    @JsonProperty("CardTokenExpiry")
    private String cardTokenExpiry;

    @JsonProperty("CardTokenCrypto")
    private String cardTokenCrypto;

    @JsonProperty("MerchantTRID")
    private String merchantTRID;

    @JsonProperty("LinkHashId")
    private String linkHashId;

    //NEW RES DATA
    @JsonProperty("RefCancelId")
    private String refCancelId;

    @JsonProperty("RefundAmount")
    private String refundAmount;

    @JsonProperty("RetRefNo")
    private String retRefNo;

    @JsonProperty("AuthCode")
    private String authCode;

    @JsonProperty("PanSource")
    private String panSource;



    @Override
    public String toString() {
        return "MerchantEncDataRequest [" +
                "txnType='" + txnType + '\'' +
                ", cardNumber='" + cardNumber + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", cardSecurityCode='" + cardSecurityCode + '\'' +
                ", returnURL='" + returnURL + '\'' +
                ", bankCode='" + bankCode + '\'' +
                ", chTokenizationConsent='" + chTokenizationConsent + '\'' +
                ", cardTokenPan='" + cardTokenPan + '\'' +
                ", cardTokenExpiry='" + cardTokenExpiry + '\'' +
                ", cardTokenCrypto='" + cardTokenCrypto + '\'' +
                ", merchantTRID='" + merchantTRID + '\'' +
                ", linkHashId='" + linkHashId + '\'' +
                ", refCancelId='" + refCancelId + '\'' +
                ", refundAmount='" + refundAmount + '\'' +
                ", retRefNo='" + retRefNo + '\'' +
                ", authCode='" + authCode + '\'' +
                ", panSource='" + panSource + '\'' +
                ","+ super.toString();
    }
}
