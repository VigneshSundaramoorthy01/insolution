package com.isg.mw.core.model.constants;

public enum TransactionStatus {
    SUCCESS,
    FAILED;

    public static TransactionStatus getTransactioStatus(String name) {
        if (SUCCESS.name().equals(name)) {
            return SUCCESS;
        } else if (FAILED.name().equals(name)) {
            return FAILED;
        }

        return null;
    }
}
