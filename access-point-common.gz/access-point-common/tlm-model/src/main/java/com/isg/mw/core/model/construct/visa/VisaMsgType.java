package com.isg.mw.core.model.construct.visa;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum VisaMsgType implements IMsgType{
    SignonRequest("0800", null),
    SignonResponse("0810", null),
    PurchaseRequest("0100", "00"),
    PurchaseResponse("0110", "00"),
    CashWithdrawalRequest("0100", "01"),
    CashWithdrawalResponse("0110", "01"),
    CashAtPosRequest("0100", "00"),
    CashAtPosResponse("0110", "00"),
    PurCashAtPosRequest("0100","00"),
    PurCashAtPosResponse("0110","00"),
    MotoRequest("0100", "00"),
    MotoResponse("0110", "00"),
    PreAuthRequest("0100", "00"),
    PreAuthResponse("0110", "00"),
    RefundRequest("0100", "20"),
    RefundResponse("0110", "20"),
    BalanceEnqRequest("0100", "30"),
    BalanceEnqResponse("0110", "30"),
    ReversalRequest("0400", null),
    ReversalResponse("0410", null),
    VoidRequest("0400", null),
    VoidResponse("0410",null),
	TipAdjustRequest("0220","50"),
	TipAdjustResponse("0230","50"),
	PreAuthCompletionRequest("0220","40"),
	PreAuthCompletionResponse("0230","40"),
	OfflineRequest("0220","00"),
	OfflineResponse("0230","00"),
	MasterCardCashbackRequest("0200","09"),
	BatchSettlementRequest("0500","92"),
	SettlementAfterBatchUploadRequest("0500","96"),
	BatchUploadRequest("0320",null);

   

    public final String msgType;
    public final String msgSubType;

    private VisaMsgType(String m, String ms ) {
        this.msgType = m;
        this.msgSubType = ms;
    }

	@Override
	public boolean equals(String msgType, String msgSubType) {
		return (this.msgType.equals(msgType) && this.msgSubType.equals(msgSubType));
	}
	
	

}
