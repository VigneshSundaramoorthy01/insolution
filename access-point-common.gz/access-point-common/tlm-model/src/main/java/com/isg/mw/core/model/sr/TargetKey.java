package com.isg.mw.core.model.sr;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@AllArgsConstructor
@Data
public class TargetKey implements Serializable {

 
	private String targetId;
}
