package com.isg.mw.core.model.constants;

public interface TlmFieldsInfo {
	/**
	 * field name is pageNo
	 */
	String PAGE_NO_FN = "pageNo";

	/**
	 * field name is pageSize
	 */
	String PAGE_SIZE_FN = "pageSize";

	/**
	 * field name is entityId
	 */
	String ENTITY_ID_FN = "entityId";
	
	/**
	 * entity id expression
	 */
	String ENTITY_ID_EX = "^[a-zA-Z0-9]*";
	

	/**
	 * entity id data length
	 */
	int ENTITY_ID_FL = 32;

	/**
	 * field name is id
	 */
	String ID_FN = "id";

	/**
	 * id data length
	 */
	int ID_FL = 32;

	/**
	 * id expression
	 */
	String ID_EX = "^[0-9]*";

	/**
	 * field name is rrn
	 */
	String RRN_FN = "rrn";

	/**
	 * rrn data length
	 */
	int RRN_FL = 12;

	/**
	 * rrn expression
	 */
	String RRN_EX = "^[0-9]*";

	/**
	 * field name is txnId
	 */
	String TXN_ID_FN = "txnId";

	/**
	 * txnId data length
	 */
	int TXN_ID_FL = 19;

	/**
	 * txnId expression
	 */
	String TXN_ID_EX = "^[0-9]*";
	
	/**
	 * field name txnDataType
	 */
	String TXN_DATA_TYPE = "txnType";

	/**
	 * field name fileType
	 */
	String DCF_TYPE_FN = "fileType";

	/**
	 * field name MID
	 */
	String MID_FN = "MID";
	/**
	 * field MID mandatory
	 */
	boolean MID_MA = false;
	/**
	 * field MID length
	 */
	int MID_FL = 15;

	/**
	 * field name TID
	 */
	String TID_FN = "TID";
	/**
	 * field TID mandatory
	 */
	boolean TID_MA = false;
	/**
	 * field TID length
	 */
	int TID_FL = 8;
	/**
	 * field Alpha numeric special character
	 */
	String ANS_EX = null;

	/**
	 * failed to parse date
	 */
	String DATE_TLM_PARSE_ERROR = "tlm.validation.date.parse";
	
	/**
	 * field name is entityId
	 */
	String  ACQUIRER_ID_CODE_FN = "acquirerIdCode";

	/**
	 * entity id data length
	 */
	int ACQUIRER_ID_CODE_FL = 6;

	/**
	 * entity id expression
	 */
	String ACQUIRER_ID_CODE_EX = "^[0-9]*";

	/**
	 * field name is loginUser
	 */
	String LOGIN_USER_FN = "loginUser";
	
	/**
	 * login user expression
	 */
	String LOGIN_USER_EX = "^[a-zA-Z]*";

	/**
	 * login user data length
	 */
	int LOGIN_USER_FL = 32;


}
