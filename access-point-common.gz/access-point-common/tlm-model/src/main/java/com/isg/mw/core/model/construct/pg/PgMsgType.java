package com.isg.mw.core.model.construct.pg;

import com.isg.mw.core.model.msgtype.IMsgType;

public enum PgMsgType implements IMsgType {

    //msgType and transaction Type
    PurchaseRequest("0200", "01"),
    PurchaseResponse("0210", "01"),
    PreAuthRequest("0200", "02"),
    PreAuthResponse("0210", "02"),
    PreAuthAavRequest("0200", "29"),
    PreAuthAavResponse("0210", "29"),
    RefundRequest("0220", "12"),
    RefundResponse("0230", "12"),
    ReversalRequest("0400", "05"),
    ReversalResponse("0410", "05"),
    VoidRequest("0220", "22"),
    VoidResponse("0230", "22"),
    CaptureRequest("0220", "03"),
    CaptureResponse("0230", "03"),
    SIAmexRequest("0200", "27"),
    SIAmexResponse("0210", "27"),
    SIRequest("0200", "11"),
    SIResponse("0210", "11"),
    RPRequest("0200", "28"),
    RPResponse("0210", "28"),
    SIAmexAavRequest("0200", "30"),
    SIAmexAavResponse("0210", "30"),
    RPAavRequest("0200", "31"),
    RPAavResponse("0210", "31"),
    OfflineRefundRequest("0220","04"),
    OfflineRefundResponse("0230","04"),
    OnlineOfflineRefundRequest("0220","13"),
    OnlineOfflineRefundResponse("0230","13"),
    OnlineRefundRequest("0220","12"),
    OnlineRefundResponse("0230","12"),
    MotoSaleRequest("0200", "15"),
    MotoSaleResponse("0210", "15"),
    MotoReversalRequest("0400", "16"),
    MotoReversalResponse("0410", "16"),
    MotoOnlineOfflineRefundRequest("0220", "17"),
    MotoOnlineOfflineRefundResponse("0230", "17"),
    MoSaleRequest("0200", "18"),
    MoSaleResponse("0210", "18"),
    ToSaleRequest("0200", "19"),
    ToSaleResponse("0210", "19"),
    MoSaleAavRequest("0200", "32"),
    MoSaleAavResponse("0210", "32"),
    ToSaleAavRequest("0200", "33"),
    ToSaleAavResponse("0210", "33"),
    MoRefundRequest("0220", "20"),
    MoRefundResponse("0230", "20"),
    ToRefundRequest("0220", "24"),
    ToRefundResponse("0230", "24"),
    MoReversalRequest("0400", "25"),
    MoReversalResponse("0410", "25"),
    ToReversalRequest("0400", "26"),
    ToReversalResponse("0410", "26"),
    AavRequest("0200","22"),
    PurchaseAavRequest("0200","21"),
    RefundAavRequest("0220","23"),
    AavResponse("0210","22"),
    PurchaseAavResponse("0210","21"),
    RefundAavResponse("0230","23"),
    PreAuthReversalRequest("0400", "14"),
    PreAuthReversalResponse("0410", "14"),
    VisaBqrPurchaseRequest("0200","26"),
    VisaBqrPurchaseResponse("0210","26"),
    MasterBqrPurchaseRequest("0100","28"),
    MasterBqrPurchaseResponse("0110","28"),
    MotoPreAuthRequest("0200", "34"),
    MotoPreAuthResponse("0210", "34"),
    MotoCaptureRequest("0220", "35"),
    MotoCaptureResponse("0230", "35"),
    ZvavPurchaseRequest("0200","36"),
    ZvavPurchaseResponse("0210","36"),
    ZvavPurchaseAavRequest("0200","37"),
	ZvavPurchaseAavResponse("0210","37");
	
    public final String msgType;
    public final String txnType;

    private PgMsgType(String m, String ms) {
        this.msgType = m;
        this.txnType = ms;
    }

    @Override
    public boolean equals(String msgType, String msgSubType) {
        return (this.msgType.equals(msgType) && this.txnType.equals(msgSubType));
    }

}
