package com.isg.mw.core.model.sr;

import com.isg.mw.core.model.constants.TargetPriority;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import static com.isg.mw.core.utils.CoreUtils.round;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class TargetInfo implements Serializable {
    private String targetName;
    private Integer totalTxnCount;
    private Integer totalTxnFailed;
    private Double currentSuccessRatio;
    private Double previousSuccessRatio;
    private boolean isAlive;

    private StaticTargetInfo staticTargetInfo = new StaticTargetInfo();
    private DynamicTargetInfo dynamicTargetInfo = new DynamicTargetInfo();

    public TargetInfo(String targetName) {
        this.targetName = targetName;
        this.totalTxnCount = 0;
        this.totalTxnFailed = 0;
        this.currentSuccessRatio = 0d;
        this.previousSuccessRatio = 0d;
    }

    public void setCurrentSuccessRatio(Double currentSuccessRatio) {
        this.currentSuccessRatio = round(currentSuccessRatio);
    }

    @Data
    @NoArgsConstructor
    public class StaticTargetInfo implements Serializable {
        private TargetPriority priority;
        private Boolean currentTarget;
    }

    @Data
    @NoArgsConstructor
    public class DynamicTargetInfo implements Serializable {
        /**
         * This value is set after calculating the success ratio,
         * which indicates the current maximum routing percent for the target
         */
        private Double currentRoutingPercent;

        private Double initialRoutingPercent;

        private TrendIndicator rpTrendIndicator;

        public void setCurrentRoutingPercent(Double currentRoutingPercent) {
            this.currentRoutingPercent = round(currentRoutingPercent);
        }

        public void setInitialRoutingPercent(Double initialRoutingPercent) {
            this.initialRoutingPercent = round(initialRoutingPercent);
        }
    }

    public enum TrendIndicator {
        UP, DOWN, NO_CHANGE
    }
}
