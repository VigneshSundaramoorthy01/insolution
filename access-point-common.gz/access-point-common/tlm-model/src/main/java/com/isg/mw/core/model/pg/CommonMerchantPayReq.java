package com.isg.mw.core.model.pg;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommonMerchantPayReq {
    /*
    Sale Status Request:
       {
	    "BankId": "24520",
	    "MCC": "5411",
	    "MerchantId": "10000012345",
	    "PassCode": "TSFC9767",
	    "SecureHash": "A4A5808EC2BCA3E89C4F9BB58B9DBC76874CCA319472EDEEA6B6685D02A1E7F5",
	    "TerminalId": "1000001",
	    "TxnRefNo": "1699888114304",
	    "TxnType": "Pay"
        }
    */
    @JsonProperty("BankId")
    private String bankId;

    @JsonProperty("MerchantId")
    private String merchantId;

    @JsonProperty("TerminalId")
    private String terminalId;

    @JsonProperty("TxnRefNo")
    private String txnRefNo;

    @JsonProperty("TxnType")
    private String txnType;

    @JsonProperty("SecureHash")
    private String secureHash;

    @Override
    public String toString() {
        return "CommonMerchantPayReq{" +
                "bankId='" + bankId + '\'' +
                ", merchantId='" + merchantId + '\'' +
                ", terminalId='" + terminalId + '\'' +
                ", txnRefNo='" + txnRefNo + '\'' +
                ", txnType='" + txnType + '\'' +
                ", secureHash='" + secureHash + '\'' +
                '}';
    }
}