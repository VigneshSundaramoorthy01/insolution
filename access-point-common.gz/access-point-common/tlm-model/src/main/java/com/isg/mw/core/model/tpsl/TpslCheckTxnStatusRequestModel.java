package com.isg.mw.core.model.tpsl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class TpslCheckTxnStatusRequestModel {

    @JsonProperty("merchant")
    public Merchant merchant = new Merchant();

    @JsonProperty("transaction")
    public Transaction transaction = new Transaction();

    @Data
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Merchant {
        private String identifier;
    }

    @Data
    @ToString
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Transaction {
        private String deviceIdentifier;

        private String amount;

        private String currency;

        private String dateTime;

        private String identifier;

        private String requestType;
    }
}
