package com.isg.mw.core.model.tlm;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.isg.mw.core.model.common.AcpTraceIdModel;
import com.isg.mw.core.model.constants.PaymentStatus;
import com.isg.mw.core.utils.OffsetDateTimeOptionalZoneDeserializer;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.OffsetDateTime;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class PaymentFileDetailsModel extends AcpTraceIdModel implements Serializable {
    private Long fileId;

    private String fileName;

    private String refNo;

    private String mid;

    private String tid;

    private String numberOfRecord;

    private PaymentStatus status;

    private String createdBy;

    private String updatedBy;

    @JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private OffsetDateTime createdAt;

    @JsonDeserialize(using = OffsetDateTimeOptionalZoneDeserializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private OffsetDateTime updatedAt;
}
